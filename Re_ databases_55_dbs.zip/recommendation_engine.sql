-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: recommendation_engine
-- ------------------------------------------------------
-- Server version	8.0.44-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tb_ApplicationMasterDtl`
--

DROP TABLE IF EXISTS `tb_ApplicationMasterDtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_ApplicationMasterDtl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `createdDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `applicationId` varchar(50) NOT NULL,
  `applicationName` varchar(150) NOT NULL,
  `applicationDesc` text,
  `userId` int NOT NULL,
  `userEmail` varchar(125) NOT NULL,
  `updatedDate` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_IndexMasterDtl`
--

DROP TABLE IF EXISTS `tb_IndexMasterDtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_IndexMasterDtl` (
  `indexId` int NOT NULL AUTO_INCREMENT,
  `applicationId` varchar(25) DEFAULT NULL,
  `indexName` varchar(150) NOT NULL,
  `indexDesc` text,
  `importflag` int DEFAULT NULL,
  `connectorsId` int DEFAULT NULL,
  `uploadDtl` json DEFAULT NULL,
  `fileSize` varchar(20) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime DEFAULT NULL,
  `records` int DEFAULT NULL,
  PRIMARY KEY (`indexId`),
  UNIQUE KEY `tb_IndexMasterDtl_Unique` (`applicationId`,`indexName`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_IndexuploadjsonDtl`
--

DROP TABLE IF EXISTS `tb_IndexuploadjsonDtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_IndexuploadjsonDtl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `applicationId` varchar(25) DEFAULT NULL,
  `fk_indexId` int DEFAULT NULL,
  `productUnique` varchar(40) DEFAULT NULL,
  `productJson` json DEFAULT NULL,
  PRIMARY KEY (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_StoreConnection`
--

DROP TABLE IF EXISTS `tb_StoreConnection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_StoreConnection` (
  `storeconnId` int NOT NULL AUTO_INCREMENT,
  `conId` int NOT NULL,
  `shopDomain` varchar(100) DEFAULT NULL,
  `accessToken` varchar(250) DEFAULT NULL,
  `isConnected` tinyint DEFAULT NULL,
  `connectorName` varchar(100) DEFAULT NULL,
  `token` longtext,
  `userName` varchar(150) DEFAULT NULL,
  `pwd` varchar(100) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `updatedDate` datetime DEFAULT NULL,
  PRIMARY KEY (`storeconnId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_connectorsList`
--

DROP TABLE IF EXISTS `tb_connectorsList`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_connectorsList` (
  `conid` int NOT NULL,
  `connector_name` varchar(100) DEFAULT NULL,
  `imageUrl` varchar(500) DEFAULT NULL,
  `createdAt` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`conid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_login_master_log`
--

DROP TABLE IF EXISTS `tb_login_master_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_login_master_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(250) DEFAULT NULL,
  `password` varchar(250) DEFAULT NULL,
  `errcode` int DEFAULT NULL,
  `errmsg` varchar(250) DEFAULT NULL,
  `create_date` datetime(3) DEFAULT NULL,
  `login_source` varchar(50) DEFAULT NULL,
  `login_device_id` varchar(100) DEFAULT NULL,
  `login_ipaddress` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_users_dtl`
--

DROP TABLE IF EXISTS `tb_users_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_users_dtl` (
  `userId` int NOT NULL AUTO_INCREMENT,
  `firstName` varchar(100) DEFAULT NULL,
  `lastName` varchar(100) DEFAULT NULL,
  `emailAddress` varchar(250) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `status` int DEFAULT '1',
  `is_verified` tinyint DEFAULT '0',
  `verify_code` varchar(10) DEFAULT NULL,
  `expiry_time` int DEFAULT NULL,
  `companyName` varchar(150) DEFAULT NULL,
  `websiteUrl` text,
  `productSize` varchar(10) DEFAULT NULL,
  `industry` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `profpicUrl` text,
  `createDate` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`userId`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping routines for database 'recommendation_engine'
--
/*!50003 DROP PROCEDURE IF EXISTS `re_create_signup_user_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`javateam`@`%` PROCEDURE `re_create_signup_user_dtl`(
       p_email 		VARCHAR(250)
       )
Begin
       
          DECLARE v_verifyCode 	VARCHAR(10) default 0;
          DECLARE v_errcode 	INT DEFAULT -1; 
          DECLARE v_errmsg 		VARCHAR(250) DEFAULT '';
       
          sp_exit:
          BEGIN
       
             IF EXISTS(SELECT 1 FROM tb_users_dtl WHERE emailAddress = p_email AND is_verified = 1 LIMIT 1) 
             THEN
                SET v_errcode = -1;
                SET v_errmsg = 'This email address already verified';
                LEAVE sp_exit;
             END IF;
       
             SET v_verifyCode = right(FORMAT(RAND(),7),6);
       
             IF EXISTS(SELECT 1 FROM tb_users_dtl WHERE emailAddress = p_email AND is_verified = 0 LIMIT 1) 
				 THEN
					UPDATE 	tb_users_dtl 
					SET 	verify_code 	= v_verifyCode
							,expiry_time 	= 15
                            ,updatedAt		= NOW()
					WHERE 	emailAddress 	= p_email 
					AND 	is_verified 	= 0;
					
					IF ROW_COUNT() > 0 
                    THEN
					   SET v_errcode 	= 0;
					   SET v_errmsg 	= 'success';
					   LEAVE sp_exit;
					END IF;
             ELSE 
				INSERT INTO tb_users_dtl(emailAddress,verify_code,is_verified,expiry_time,updatedAt)
       			values(p_email,v_verifyCode,0,15,NOW());
                   SET v_errcode 	= 0;
                   SET v_errmsg 	= 'success to generate pin';
             END IF;
             
          END;
     
          select v_errcode as errcode,v_errmsg as errmsg, v_verifyCode as verify_code;
       
       End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `re_delete_ProductDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `re_delete_ProductDtl`(
	p_applicationId VARCHAR(25),
 	p_fk_indexId INT,
	p_productUnique VARCHAR(40)
)
BEGIN
		DECLARE v_errCode	INT DEFAULT -1;
        DECLARE v_errMsg	VARCHAR(100) DEFAULT "Failed";
        
        IF EXISTS(SELECT 1 FROM tb_IndexuploadjsonDtl 
			WHERE applicationId = p_applicationId AND fk_indexId = p_fk_indexId AND productUnique =  p_productUnique)
        THEN 
        
DELETE FROM tb_IndexuploadjsonDtl 
WHERE
    applicationId = p_applicationId
    AND fk_indexId = p_fk_indexId
    AND productUnique = p_productUnique;
        
        
			SET v_errCode = 1;
            SET v_errMsg = "Deleted Successfully";
		END IF;
        
        
SELECT v_errCode AS errCode, v_errMsg AS errMsg;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `re_forget_password_user_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`javateam`@`%` PROCEDURE `re_forget_password_user_dtl`(
       p_email VARCHAR(250)
       )
Begin
       
          DECLARE v_verifyCode 	VARCHAR(10) DEFAULT 0;
          DECLARE v_errcode 	INT DEFAULT -1; 
          DECLARE v_errmsg 		VARCHAR(250) DEFAULT '';
       
          sp_exit:
          BEGIN
       
             IF NOT EXISTS(SELECT 1 FROM tb_users_dtl WHERE emailAddress = p_email LIMIT 1) THEN
                SET v_errcode 	= -1;
                SET v_errmsg 	= 'This email address not found';
                LEAVE sp_exit;
             END IF;
       
             SET v_verifyCode = right(FORMAT(RAND(),7),6);
       
             IF EXISTS(SELECT 1 FROM tb_users_dtl WHERE emailAddress = p_email LIMIT 1) 
             THEN
                UPDATE tb_users_dtl
                SET verify_code = v_verifyCode
                , 	expiry_time = 15
                ,	is_verified = 0
                ,	updatedAt	= NOW()
                WHERE emailAddress = p_email;
                
                IF ROW_COUNT() > 0 
                THEN
                   SET v_errcode = 0;
                   SET v_errmsg = 'success to generate pin';
                   LEAVE sp_exit;
                END IF;
             END IF;
             
          END;
     
          select v_errcode as errcode,v_errmsg as errmsg, v_verifyCode as verify_code;
       
       End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `re_getApplicationDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `re_getApplicationDtl`(
  	p_applicationId VARCHAR(150)
  )
BEGIN
  
  	
 		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
 
          SELECT  AM.createdDate,AM.applicationId,AM.applicationName,AM.applicationDesc,AM.userId,AM.userEmail
          ,IM.indexId,IM.applicationId,IM.indexName,IM.indexDesc,IM.importflag,IM.connectorsId,IM.uploadDtl,IM.createdAt,IM.updatedAt
          , IM.records
          FROM tb_ApplicationMasterDtl AM
          JOIN tb_IndexMasterDtl IM ON AM.applicationId = IM.applicationId
          WHERE AM.applicationId = p_applicationId;
      
 		SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
         
             
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `re_getIndexDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `re_getIndexDtl`(p_indexId		INT)
BEGIN

	IF p_indexId IS NOT NULL THEN
    
		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
		
			SELECT * FROM tb_IndexMasterDtl  WHERE indexId = p_indexId;
		
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
	
    ELSE 
			
            SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
		
			SELECT * FROM tb_IndexMasterDtl;
		
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
        
	END IF;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `re_getUploadProductDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `re_getUploadProductDtl`(p_applicationId VARCHAR(25),
	p_fk_indexId INT,
    p_productUnique VARCHAR(40)
)
BEGIN
	
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	
	SELECT 
    *
FROM
    tb_IndexuploadjsonDtl
WHERE
    applicationId = p_applicationId
        AND fk_indexId = p_fk_indexId
        AND (productUnique = p_productUnique
        OR IFNULL(p_productUnique, '') = '');
    
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
    

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `re_getUserEmailApplication` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `re_getUserEmailApplication`(
p_userEmail VARCHAR(125)
)
BEGIN
	
    DECLARE v_errMsg VARCHAR(50) DEFAULT "Id should be vaild and authenticated";
    DECLARE v_errCode INT DEFAULT -1;
	DECLARE v_check INT DEFAULT 0;
    
    IF p_userEmail IS NULL THEN SET v_check = 1; END IF;
   


    
    IF v_check != 1 THEN
		
		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        
		SELECT createdDate, applicationId, applicationName, applicationDesc, userId, userEmail FROM tb_ApplicationMasterDtl
        WHERE userEmail = p_userEmail;
        
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
	ELSE
    
    SELECT v_errCode AS errCode, v_errMsg AS errMsg;
    
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `re_insertApplicationDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `re_insertApplicationDtl`(
	p_applicationId		VARCHAR(50),
    p_applicationName	VARCHAR(150),
    p_applicationDesc	TEXT,
    p_userId			INT,
    p_userEmail			VARCHAR(125)
)
BEGIN
		DECLARE v_errCode		INT DEFAULT -1;
        DECLARE v_errMsg		VARCHAR(50) DEFAULT "Failed";
        DECLARE v_newInsertId	INT DEFAULT -1;
        
	  IF NOT EXISTS(SELECT 1 FROM tb_ApplicationMasterDtl WHERE applicationId = p_applicationId) THEN
		
        INSERT INTO tb_ApplicationMasterDtl(applicationId, applicationName, applicationDesc, userId, userEmail) 
			VALUES(p_applicationId, p_applicationName, p_applicationDesc , p_userId, p_userEmail);
            
		IF row_count() > 0 THEN 
			SET v_newInsertId = LAST_INSERT_ID();
			SET v_errCode = 0;
            SET v_errMsg = "Success";
		END IF;
        
	 END IF; 
     
     SELECT v_errCode AS errCode , v_errMsg AS errMsg , v_newInsertId AS newInsertId;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `re_insertConnectorsListDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `re_insertConnectorsListDtl`(
		p_conid		INT,
		p_connector_name 	VARCHAR(100),
		p_imageUrl 			VARCHAR(500)
)
BEGIN

		DECLARE  v_errCode	INT DEFAULT -1;
        DECLARE  v_errMsg	VARCHAR(50) DEFAULT "Failed";
        DECLARE  v_lastInsertedId	INT DEFAULT -1;
        
		IF NOT EXISTS(SELECT 1 FROM tb_connectorsList WHERE conid = p_conid) THEN
				INSERT INTO tb_connectorsList (conid, connector_name, imageUrl)
					VALUES(p_conid, p_connector_name, p_imageUrl);
                    
				IF ROW_COUNT()> 0 THEN
                
					SET v_lastInsertedId = last_insert_id();
                    SET v_errCode = 0;
                    SET v_errMsg = "Inserted Successfully";
                
                END IF;
        END IF;
        
        SELECT v_errCode AS errCode, v_errMsg AS errMsg, v_lastInsertedId AS lastInsertedId;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `re_InsertUpdateIndexDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `re_InsertUpdateIndexDtl`(	
 	p_indexId				INT,
     p_applicationId			VARCHAR(25),
     p_indexName				VARCHAR(150),
     p_indexDesc				TEXT,
     p_importflag			INT,			
     p_connectorsId			INT,
     p_uploadDtl				JSON,
     p_records				INT
    )
BEGIN
 		DECLARE v_errCode	INT DEFAULT -1;
         DECLARE v_errMsg	VARCHAR(50) DEFAULT "Failed";
         DECLARE v_lastInsertedId	INT DEFAULT -1;
         
 	DECLARE EXIT HANDLER FOR SQLEXCEPTION
     BEGIN
         SELECT v_errCode AS errCode, v_errMsg AS errMsg;
     END;
     
     IF p_indexId IS NULL THEN
 		
         IF NOT EXISTS (SELECT 1 FROM tb_IndexMasterDtl WHERE  applicationId = p_applicationId AND indexId = p_indexId) THEN
 			INSERT INTO tb_IndexMasterDtl( applicationId, indexName, indexDesc, importflag, connectorsId, uploadDtl, records) 
 				VALUES(p_applicationId, p_indexName, p_indexDesc, p_importflag, p_connectorsId, p_uploadDtl, p_records);
 			
             IF ROW_COUNT() > 0 THEN
                 SET v_lastInsertedId = LAST_INSERT_ID();
 				SET v_errCode	 = 0;
 				SET v_errMsg 	= "Success";
 			END IF;
             
         END IF;
 		
 	ELSE 
 		        
 		 IF EXISTS (SELECT 1 FROM tb_IndexMasterDtl WHERE  applicationId = p_applicationId AND indexId = p_indexId) THEN
 			UPDATE tb_IndexMasterDtl 
 				SET importflag 			= 	IFNULL(p_importflag, importflag), 
 					connectorsId		=	IFNULL(p_connectorsId, connectorsId) 
 				 	,uploadDtl      		=   IFNULL(p_uploadDtl, uploadDtl)
                  , records  			= IFNULL(p_records, records)
                  , indexName  			= IFNULL(p_indexName, indexName)
                  , indexDesc  			= IFNULL(p_indexDesc, indexDesc)
 			WHERE applicationId = p_applicationId AND indexId = p_indexId;
         
 			 IF ROW_COUNT() > 0 THEN
                 SET v_lastInsertedId = p_indexId;
 				SET v_errCode	 = 1;
 				SET v_errMsg 	= "Updated";
 			END IF;
 		
 		END IF;
     
     END IF;
 		SELECT v_errCode AS errCode, v_errMsg AS errMsg, v_lastInsertedId AS lastInsertedId; 
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `re_InsertUpdateStoreConnectionDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `re_InsertUpdateStoreConnectionDtl`(
  p_conId int,
  p_shopDomain varchar(100),
  p_accessToken varchar(250),
  p_isConnected tinyint,
  p_connectorName varchar(100),
  p_token longtext,
  p_userName varchar(150) ,
  p_pwd varchar(100)
)
BEGIN

	DECLARE v_errCode INT DEFAULT -1;
    DECLARE v_errMsg VARCHAR(50) DEFAULT "Failed";
    DECLARE v_lastId INT DEFAULT -1;	
	
    INSERT INTO tb_StoreConnection (conId ,shopDomain , accessToken, isConnected , connectorName , token , userName , pwd)
    VALUES(p_conId , p_shopDomain , p_accessToken, p_isConnected , p_connectorName , p_token , p_userName , p_pwd );
    
    IF ROW_COUNT() > 0 THEN
     SET v_errCode = 0;
     SET v_errMsg = "Success";
     SET v_lastId = last_insert_id();
     
    END IF;
    
    SELECT v_errCode AS errCode, v_errMsg AS errMsg  , v_lastId AS lastId;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `re_insert_login_master_log` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`javateam`@`%` PROCEDURE `re_insert_login_master_log`(  
  p_email 			VARCHAR(250),  
  p_password 		VARCHAR(250),  
  p_errcode 		INT,   
  p_errmsg 			VARCHAR(250),
  p_source			VARCHAR(50),
  p_login_device_id VARCHAR(100)
  )
Begin  
    
   DECLARE 	v_now DATETIME(3); 
   DECLARE 	v_MyAcc_Password VARCHAR(100);  
   SET 		v_now = now(3);  
    
   insert into tb_login_master_log (email,password,errcode,errmsg,create_date,login_source,login_device_id)  
   values(p_email,p_password,p_errcode,p_errmsg,v_now,p_source,p_login_device_id);  
    
  End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `re_insert_product_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `re_insert_product_dtl`(
p_fk_indexId int 
,p_applicationId varchar(25) 
,p_productUnique varchar(40) 
,p_productJson json
)
Begin
	declare v_errcode int default -1;
    declare v_errmsg varchar(50) default 'Failure';
    
    insert into tb_IndexuploadjsonDtl(applicationId, fk_indexId, productUnique, productJson)
    values(p_applicationId, p_fk_indexId, p_productUnique, p_productJson);
    
    if row_count()>0 then
		set v_errcode = 0;
        set v_errmsg = 'Inserted';
    End if;
    
    select v_errcode as errcode, v_errmsg as errmsg;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `re_insert_update_user_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`javateam`@`%` PROCEDURE `re_insert_update_user_dtl`(
     p_firstName 	VARCHAR(100),
     p_lastName 	VARCHAR(100),
     p_emailAddress VARCHAR(100),
     p_password	 	VARCHAR(50),
     p_companyName 	VARCHAR(150),
     p_websiteUrl	TEXT,
     p_productSize 	VARCHAR(10),
     p_industry 	VARCHAR(100),
     p_country 		VARCHAR(100),
     p_profpicUrl 	TEXT
	)
Begin
     
  		DECLARE v_errcode 	INT;
  		DECLARE v_errmsg 	VARCHAR(50);
		DECLARE v_userid 	INT;
		DECLARE v_user_Id 	INT;
         
  		DECLARE EXIT HANDLER FOR SQLEXCEPTION
  		BEGIN
  			SHOW ERRORS;
  			ROLLBACK;   
  		END; 
           START TRANSACTION;
           
		SELECT userId INTO v_user_Id
		FROM tb_users_dtl WHERE emailAddress = p_emailAddress;
           
     	IF v_user_Id IS NULL
        THEN
     		INSERT INTO tb_users_dtl (firstName,lastName,emailAddress,password,companyName,websiteUrl,productSize,industry,country,profpicUrl,createDate,updatedAt)
			VALUES(p_firstName, p_lastName, p_emailAddress, p_password, p_companyName, p_websiteUrl,p_productSize, p_industry, p_country, p_profpicUrl,NOW(),NOW());
             
             SET  v_userid = LAST_INSERT_ID();
             
             IF ROW_COUNT()>0 THEN
     			SET v_errcode = 0;
				SET v_errmsg = 'User Details Inserted Successfully';           
             END IF;
     	ELSE
     		UPDATE tb_users_dtl
     		SET  
				firstName 		= ifnull(p_firstName, firstName)
				,lastName 		= ifnull(p_lastName, lastName)
				,password 		= ifnull(p_password,password)
				,companyName	= ifnull(p_companyName, companyName)
				,websiteUrl 	= ifnull(p_websiteUrl, websiteUrl)
				,productSize 	= ifnull(p_productSize,productSize)
				,industry 		= ifnull(p_industry,industry)
				,country 		= ifnull(p_country,country)
				,profpicUrl 	= ifnull(p_profpicUrl,profpicUrl)
     		WHERE userId 		= v_user_Id;
     
     		IF ROW_COUNT()>0 THEN
     			SET v_errcode = 0;
     			SET v_errmsg = 'Updated';
     		END IF;
		END IF;
         
         COMMIT;    
     	select v_errcode as errcode, v_errmsg as errmsg,ifnull(v_userid,0) as userid;
     End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `re_update_user_password_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`javateam`@`%` PROCEDURE `re_update_user_password_dtl`(
	p_emailAddress 	VARCHAR(100),
	p_password 		VARCHAR(50)
)
Begin
		DECLARE v_errcode 	INT DEFAULT -1;
  		DECLARE v_errmsg 	VARCHAR(50) DEFAULT 'No record found';

		sp_exit:begin
		IF NOT EXISTS(SELECT 1 FROM tb_users_dtl WHERE emailAddress = p_emailAddress LIMIT 1) 
        THEN
			SET v_errcode 	= -1;
			SET v_errmsg 	= 'This email address not found';
			LEAVE sp_exit;
        END IF;
        
			UPDATE 	tb_users_dtl
			SET 	password 		= ifnull(p_password,password)
			WHERE 	emailAddress 	= p_emailAddress;
            
            SET v_errcode = 0;
			SET v_errmsg = 'Updated';
			
		End;

			select v_errcode as errcode, v_errmsg as errmsg; 
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `re_user_login_validation` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`javateam`@`%` PROCEDURE `re_user_login_validation`(
   	 p_email 		VARCHAR(250)
   	,p_password 	VARCHAR(50)
    ,p_source 		VARCHAR(50)
   	,p_signintype 	TINYINT 
	,p_device_id 	VARCHAR(50)
   )
sp_return: Begin
          
   	   DECLARE v_found 		INT;
   	   DECLARE v_company_id INT;

		IF NOT EXISTS(SELECT 1 FROM tb_users_dtl WHERE emailAddress = p_email limit 1)
        THEN
			SELECT -1 AS errcode, 'User not found' AS errmsg;
			LEAVE sp_return;
		END IF;
	   
	   IF p_signintype = 0 THEN
			IF EXISTS(SELECT 1 FROM tb_users_dtl where emailAddress = p_email and BINARY password <> p_password) then
				SELECT -1 AS errcode, 'Incorrect Password' AS errmsg;
				LEAVE sp_return;
			END IF;
	
			SELECT 1 INTO v_found FROM tb_users_dtl WHERE emailAddress = p_email AND BINARY password = p_password AND status = 1 ;
			
			IF v_found IS NULL 
            THEN
				SELECT -1 AS errcode, 'Inactive / wrong Password' AS errmsg;
				LEAVE sp_return;
			END IF;
		END IF;
			
		SELECT 0 AS errcode, 'Login successfully' as errmsg,a.*
		FROM tb_users_dtl a                     
		WHERE a.emailAddress = p_email 
		AND ((BINARY a.password = p_password and p_signintype = 0) or (p_signintype = 1))
		AND status = 1 ; 
		 
		call re_insert_login_master_log(p_email,p_password,0,'Login successfully',p_source,p_device_id);
          
	End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `re_validate_signup_user_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`javateam`@`%` PROCEDURE `re_validate_signup_user_dtl`(
       p_email 			VARCHAR(250),
       p_verify_code 	VARCHAR(10)
       )
Begin
       
          DECLARE v_errcode 	INT; 
          DECLARE v_errmsg 		VARCHAR(250);
          DECLARE v_Timediff 	INT; 
          DECLARE v_expiry_time INT; 
          DECLARE v_updatedAt 	DATETIME(3);
          
          sp_exit:
          BEGIN
             SET v_errcode 	= -1;
             SET v_errmsg 	= '';
             
             IF NOT EXISTS(SELECT 1 FROM tb_users_dtl WHERE emailAddress = p_email LIMIT 1) 
             THEN
                SET v_errcode = 0;
                SET v_errmsg = 'Incorrect email address';
                LEAVE sp_exit;
             END IF;
             
             IF EXISTS(SELECT 1 FROM tb_users_dtl WHERE emailAddress = p_email and verify_code <> p_verify_code LIMIT 1) 
             THEN
                SET v_errcode = 0;
                SET v_errmsg 	= 'Invalid OTP';
                LEAVE sp_exit;
             END IF;
             
             IF EXISTS(SELECT 1 FROM tb_users_dtl WHERE emailAddress = p_email AND verify_code = p_verify_code AND is_verified = 0 LIMIT 1) 
             THEN
     			SELECT expiry_time, updatedAt INTO v_expiry_time, v_updatedAt
     			FROM 	tb_users_dtl 
                WHERE 	emailAddress 	= p_email 
                AND 	verify_code 	= p_verify_code;
     
     			SET v_Timediff = timestampdiff(MINUTE,v_updatedAt,now(3));  
     
     			IF v_expiry_time <  v_Timediff 
                THEN  
     				SET v_errcode = -1;  
     				SET v_errmsg = 'OTP has expired, please click on Resend code to continue';  
     				LEAVE sp_exit;
     			END IF;  
                 
                SET v_errcode = 0;
                SET v_errmsg = 'Success : Email verified';
                
                UPDATE tb_users_dtl 
                SET 	is_verified = 1
                where 	emailAddress = p_email AND verify_code = p_verify_code;
                LEAVE sp_exit;
             END IF;
          END;
          select v_errcode as errcode,v_errmsg as errmsg; 
       End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-21  9:56:28
