-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: npopr_uk
-- ------------------------------------------------------
-- Server version	8.0.44-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `npopr_uk`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `npopr_uk` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `npopr_uk`;

--
-- Table structure for table `HOMENBRANGE`
--

DROP TABLE IF EXISTS `HOMENBRANGE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `HOMENBRANGE` (
  `IDX` int NOT NULL,
  `FIRSTNB` varchar(30) NOT NULL,
  `LASTNB` varchar(30) NOT NULL,
  `RCID` varchar(30) DEFAULT NULL,
  UNIQUE KEY `INDEX_1` (`IDX`),
  UNIQUE KEY `PK_HOMENBRANGE` (`FIRSTNB`,`LASTNB`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `LLOM_NUMBER_CONFIG`
--

DROP TABLE IF EXISTS `LLOM_NUMBER_CONFIG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `LLOM_NUMBER_CONFIG` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `FIRSTNB` varchar(20) NOT NULL,
  `LASTNB` varchar(20) NOT NULL,
  `RCID` varchar(20) DEFAULT NULL,
  `STATUS` int DEFAULT NULL,
  PRIMARY KEY (`FIRSTNB`,`LASTNB`),
  UNIQUE KEY `ID` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `NPCOUNTRY`
--

DROP TABLE IF EXISTS `NPCOUNTRY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `NPCOUNTRY` (
  `PREFIX` varchar(30) NOT NULL,
  `SITECODE` char(3) NOT NULL,
  `HOMEOPERATORID` varchar(5) DEFAULT NULL,
  `COUNTRY` varchar(32) DEFAULT NULL,
  `HOMEOPERATORRCID` varchar(20) DEFAULT NULL,
  UNIQUE KEY `PK_NPCOUNTRY` (`PREFIX`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `PORTING`
--

DROP TABLE IF EXISTS `PORTING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PORTING` (
  `IDX` int NOT NULL AUTO_INCREMENT,
  `FIRSTNB` varchar(30) NOT NULL,
  `LASTNB` varchar(30) NOT NULL,
  `PORTEDFLAG` int NOT NULL,
  `RCID` varchar(30) NOT NULL,
  `flag` int DEFAULT NULL,
  PRIMARY KEY (`FIRSTNB`,`LASTNB`,`PORTEDFLAG`),
  UNIQUE KEY `IDX` (`IDX`),
  UNIQUE KEY `INDEX_3` (`IDX`),
  KEY `idx0` (`PORTEDFLAG`,`FIRSTNB`,`LASTNB`,`RCID`),
  KEY `idx1` (`FIRSTNB`,`LASTNB`,`PORTEDFLAG`,`RCID`),
  KEY `INDEX_2` (`RCID`)
) ENGINE=InnoDB AUTO_INCREMENT=5696833 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `rcid_forward`
--

DROP TABLE IF EXISTS `rcid_forward`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rcid_forward` (
  `RCID` varchar(20) NOT NULL,
  `PrefixDid` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`RCID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping events for database 'npopr_uk'
--

--
-- Dumping routines for database 'npopr_uk'
--
/*!50003 DROP PROCEDURE IF EXISTS `MNP_GET_INFO` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `MNP_GET_INFO`(
  nb varchar(30)
  )
begin    
  
  	
       
  	declare mnp_number varchar(30);     
  	declare portedflag int;     
  	declare rcid varchar(20) ;   
  	declare isOnward int;
  
  	call MNP_GET_NUMBER (nb, mnp_number , portedflag , rcid , isonward ); 
  	
  	select mnp_number as mnp_number,  isonward as is_Onward, portedflag as portedflag, rcid as rcid ;      
       
  end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `MNP_GET_NUMBER` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `MNP_GET_NUMBER`(nb VARCHAR(30),  
    OUT mnp_number VARCHAR(30) ,  
    OUT portedflag INT ,  
    OUT rcid VARCHAR(20) ,  
    OUT isOnward INT)
begin
  
    
    
     DECLARE nbcc VARCHAR(30);  
     DECLARE v_home_rcid VARCHAR(20);  
      
     DECLARE v_llom_rcid VARCHAR(20);  
     DECLARE v_llom_found INT;
     DECLARE Swv_RowCount INT;   
   
     set rcid = '';  
     set portedflag = 0;  
     set isOnward = 0;  
      
     set v_llom_found = 0;  
    
     SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
     select   CONCAT(country,right(nb, CHAR_LENGTH(nb) - CHAR_LENGTH(prefix))), rtrim(ltrim(homeOperatorRcid)) 
     INTO nbcc,v_home_rcid 
     from  NPCOUNTRY  where left(nb, CHAR_LENGTH(prefix)) = prefix limit 1;
     SET Swv_RowCount = ROW_COUNT();
     SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
    
     if Swv_RowCount > 0 then
    
        set rcid = null;  
         
       
        SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        select   ltrim(RTRIM(a.rcid)), 1 INTO rcid,portedflag from   PORTING  a where a.firstnb = nbcc and a.portedflag = 1    LIMIT 1;
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
    
       
        if rcid is null then
           SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
           select   ltrim(RTRIM(b.rcid)), 0 INTO rcid,portedflag from PORTING b where b.portedflag = 0 and nbcc between b.firstnb and b.lastnb    LIMIT 1;
           SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
        end if;  
    
       
        if portedflag = 1 then
       
           if exists(select * from  HOMENBRANGE a where a.firstnb <= nbcc and a.lastnb >= nbcc) and
           rcid <> v_home_rcid then
              set isOnward = 1;
           end if;  
         
           set mnp_number = CONCAT_WS('',rcid,nbcc);
           IF EXISTS(SELECT  1 FROM   rcid_forward b where b.RCID = rcid AND b.PrefixDid LIKE 'mt%' LIMIT 1) then
         
              set isOnward = 1;
           end if;
        else
           if (rcid = v_home_rcid) then  
           
              set mnp_number = CONCAT_WS('',rcid,nbcc);
           else
              set mnp_number = nb;
           end if;
        end if;  
         
       
        SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        select   1, a.RCID INTO v_llom_found,v_llom_rcid from   LLOM_NUMBER_CONFIG a where nbcc between a.FIRSTNB and a.LASTNB and status = 1;
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
        if v_llom_found = 1 and IFNULL(v_llom_rcid,'') <> '' then
           
           set mnp_number = CONCAT_WS('',v_llom_rcid,nbcc);
           set rcid = v_llom_rcid;
        end if;
     else
        set mnp_number = nb;
     end if;  
  end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-21  9:52:15
