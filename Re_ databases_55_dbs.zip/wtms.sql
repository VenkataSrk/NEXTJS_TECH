-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: wtms
-- ------------------------------------------------------
-- Server version	8.0.44-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `wtms`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `wtms` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `wtms`;

--
-- Table structure for table `UTMS_WEB_RATE_CONFIG`
--

DROP TABLE IF EXISTS `UTMS_WEB_RATE_CONFIG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UTMS_WEB_RATE_CONFIG` (
  `id` int NOT NULL AUTO_INCREMENT,
  `calling_type` varchar(50) NOT NULL,
  `country` varchar(250) NOT NULL,
  `prefix` varchar(20) NOT NULL,
  `fixed_rate` varchar(150) DEFAULT NULL,
  `mobile_rate` varchar(150) DEFAULT NULL,
  `create_date` datetime(3) DEFAULT NULL,
  `create_by` varchar(150) DEFAULT NULL,
  `rate` varchar(150) DEFAULT NULL,
  `Type` varchar(250) NOT NULL,
  `filename` varchar(250) DEFAULT NULL,
  UNIQUE KEY `id` (`id`),
  KEY `idx1_UTMS_WEB_RATE_CONFIG` (`calling_type`,`country`,`Type`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=1507161 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `WTMS_WEB_RATE_CONFIG`
--

DROP TABLE IF EXISTS `WTMS_WEB_RATE_CONFIG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WTMS_WEB_RATE_CONFIG` (
  `id` int NOT NULL AUTO_INCREMENT,
  `calling_type` varchar(50) NOT NULL,
  `country` varchar(250) NOT NULL,
  `prefix` varchar(20) NOT NULL,
  `fixed_rate` varchar(150) DEFAULT NULL,
  `mobile_rate` varchar(150) DEFAULT NULL,
  `create_date` datetime(3) DEFAULT NULL,
  `create_by` varchar(150) DEFAULT NULL,
  `rate` varchar(150) DEFAULT NULL,
  `Type` varchar(250) NOT NULL,
  `filename` varchar(250) DEFAULT NULL,
  UNIQUE KEY `id` (`id`),
  KEY `idx1_WTMS_WEB_RATE_CONFIG` (`calling_type`,`country`,`Type`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=1502561 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `call_Logs_Reports`
--

DROP TABLE IF EXISTS `call_Logs_Reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `call_Logs_Reports` (
  `s_no` int NOT NULL AUTO_INCREMENT,
  `ext` int DEFAULT NULL,
  `sipId` int DEFAULT NULL,
  `LogDetails` json DEFAULT NULL,
  PRIMARY KEY (`s_no`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `prod_disc_details`
--

DROP TABLE IF EXISTS `prod_disc_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prod_disc_details` (
  `prod_id` int DEFAULT NULL,
  `prod_name` int NOT NULL,
  `prod_description` varchar(555) DEFAULT NULL,
  `disc_percent` float DEFAULT NULL,
  `disc_percent_status` int DEFAULT NULL,
  `created_date` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`prod_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `product_category_master`
--

DROP TABLE IF EXISTS `product_category_master`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_category_master` (
  `catg_id` int NOT NULL AUTO_INCREMENT,
  `fk_prod_id` int DEFAULT NULL,
  `category_name` varchar(100) DEFAULT NULL,
  `category_description` varchar(100) DEFAULT NULL,
  `category_status` int DEFAULT '1',
  `read_access` int DEFAULT '0',
  `write_access` int DEFAULT '0',
  `sub_product_code` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`catg_id`),
  KEY `FK__product_c__fk_pr__1E7F62FBIdx` (`fk_prod_id`),
  CONSTRAINT `FK__product_c__fk_pr__1E7F62FB` FOREIGN KEY (`fk_prod_id`) REFERENCES `product_master` (`prod_id`),
  CONSTRAINT `product_category_master_ibfk_1` FOREIGN KEY (`fk_prod_id`) REFERENCES `product_master` (`prod_id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `product_discount_details`
--

DROP TABLE IF EXISTS `product_discount_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_discount_details` (
  `prod_id` int NOT NULL,
  `prod_description` varchar(555) DEFAULT NULL,
  `disc_percent` float DEFAULT NULL,
  `disc_percent_status` int DEFAULT NULL,
  `created_date` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`prod_id`),
  KEY `FK__product_d__prod___421DA4F3Idx` (`prod_id`),
  CONSTRAINT `FK__product_d__prod___421DA4F3` FOREIGN KEY (`prod_id`) REFERENCES `product_master` (`prod_id`),
  CONSTRAINT `product_discount_details_ibfk_1` FOREIGN KEY (`prod_id`) REFERENCES `product_master` (`prod_id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `product_master`
--

DROP TABLE IF EXISTS `product_master`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_master` (
  `prod_id` int NOT NULL AUTO_INCREMENT,
  `prod_name` varchar(100) DEFAULT NULL,
  `prod_status` int DEFAULT '1',
  `Description` varchar(100) DEFAULT NULL,
  `sub_prod_available` int DEFAULT NULL,
  `prod_code` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`prod_id`),
  KEY `FK__wtms_tier__fk_pr__3BDABBB8Idx2` (`prod_id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ref_worktual_dir_domain`
--

DROP TABLE IF EXISTS `ref_worktual_dir_domain`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ref_worktual_dir_domain` (
  `domain_id` int NOT NULL,
  `domain_name` varchar(50) DEFAULT NULL,
  `prefix` varchar(8) DEFAULT NULL,
  `active` int DEFAULT NULL,
  `is_migrate` int DEFAULT NULL,
  PRIMARY KEY (`domain_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tariff_upload_info`
--

DROP TABLE IF EXISTS `tariff_upload_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tariff_upload_info` (
  `trffclass` varchar(4) NOT NULL,
  `access_type` int NOT NULL,
  `upload_type` int DEFAULT NULL,
  `esp_idx` int DEFAULT NULL,
  `filename` varchar(250) DEFAULT NULL,
  `temp_filename` varchar(250) DEFAULT NULL,
  `create_by` varchar(150) DEFAULT NULL,
  `create_date` datetime(3) DEFAULT NULL,
  `last_update` datetime(3) DEFAULT NULL,
  `update_by` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`trffclass`,`access_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ur_access_type_Config`
--

DROP TABLE IF EXISTS `ur_access_type_Config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ur_access_type_Config` (
  `access_type` int NOT NULL,
  `access_type_name` varchar(150) DEFAULT NULL,
  `sitecode` varchar(3) DEFAULT NULL,
  PRIMARY KEY (`access_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `worktual_bundle_master`
--

DROP TABLE IF EXISTS `worktual_bundle_master`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `worktual_bundle_master` (
  `bundle_id` int NOT NULL AUTO_INCREMENT,
  `bundle_name` varchar(100) DEFAULT NULL,
  `bundle_description` varchar(200) DEFAULT NULL,
  `status` int DEFAULT NULL,
  `create_date` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`bundle_id`),
  KEY `FK__worktual___fk_bu__346EA41AIdx2` (`bundle_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1012 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `worktual_bundle_prod_subprod_mapping`
--

DROP TABLE IF EXISTS `worktual_bundle_prod_subprod_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `worktual_bundle_prod_subprod_mapping` (
  `bundle_id` int DEFAULT NULL,
  `bundle_name` varchar(100) NOT NULL,
  `bundle_description` varchar(200) DEFAULT NULL,
  `status` int DEFAULT NULL,
  `prod_id` varchar(100) NOT NULL,
  `sub_prod_id` varchar(100) NOT NULL,
  `prod_name` longtext,
  `sub_products` longtext,
  PRIMARY KEY (`bundle_name`,`prod_id`,`sub_prod_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `worktual_bundle_product_master`
--

DROP TABLE IF EXISTS `worktual_bundle_product_master`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `worktual_bundle_product_master` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fk_bundle_id` int DEFAULT NULL,
  `fk_prod_id` int DEFAULT NULL,
  `fk_sub_prod_id` int DEFAULT NULL,
  `create_date` datetime(3) DEFAULT NULL,
  `update_date` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK__worktual___fk_su__3656EC8CIdx` (`fk_sub_prod_id`),
  KEY `FK__worktual___fk_pr__3562C853Idx` (`fk_prod_id`),
  KEY `FK__worktual___fk_bu__346EA41AIdx` (`fk_bundle_id`),
  CONSTRAINT `FK__worktual___fk_bu__346EA41A` FOREIGN KEY (`fk_bundle_id`) REFERENCES `worktual_bundle_master` (`bundle_id`),
  CONSTRAINT `FK__worktual___fk_pr__3562C853` FOREIGN KEY (`fk_prod_id`) REFERENCES `product_master` (`prod_id`),
  CONSTRAINT `FK__worktual___fk_su__3656EC8C` FOREIGN KEY (`fk_sub_prod_id`) REFERENCES `product_category_master` (`catg_id`),
  CONSTRAINT `worktual_bundle_product_master_ibfk_1` FOREIGN KEY (`fk_bundle_id`) REFERENCES `worktual_bundle_master` (`bundle_id`),
  CONSTRAINT `worktual_bundle_product_master_ibfk_2` FOREIGN KEY (`fk_prod_id`) REFERENCES `product_master` (`prod_id`),
  CONSTRAINT `worktual_bundle_product_master_ibfk_3` FOREIGN KEY (`fk_sub_prod_id`) REFERENCES `product_category_master` (`catg_id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `worktual_currency_master_dtl`
--

DROP TABLE IF EXISTS `worktual_currency_master_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `worktual_currency_master_dtl` (
  `curr_id` int NOT NULL AUTO_INCREMENT,
  `curr_name` varchar(3) NOT NULL,
  `curr_status` int NOT NULL,
  `curr_created_date` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`curr_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1005 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `worktual_groups_master_dtl`
--

DROP TABLE IF EXISTS `worktual_groups_master_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `worktual_groups_master_dtl` (
  `group_id` int NOT NULL AUTO_INCREMENT,
  `group_name` varchar(155) DEFAULT NULL,
  `group_status` int NOT NULL,
  `group_created_date` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`group_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `worktual_plan_summary_info`
--

DROP TABLE IF EXISTS `worktual_plan_summary_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `worktual_plan_summary_info` (
  `summaryid` int NOT NULL AUTO_INCREMENT,
  `plan_id` int DEFAULT NULL,
  `fk_category_id` int DEFAULT NULL,
  `summary_notes` longtext,
  `sum_status` int DEFAULT NULL,
  `create_date` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`summaryid`),
  KEY `fk_category_id` (`fk_category_id`),
  CONSTRAINT `worktual_plan_summary_info_ibfk_1` FOREIGN KEY (`fk_category_id`) REFERENCES `worktual_sum_category_master` (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `worktual_roles_master_dtl`
--

DROP TABLE IF EXISTS `worktual_roles_master_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `worktual_roles_master_dtl` (
  `role_id` int NOT NULL AUTO_INCREMENT,
  `role_name` varchar(155) DEFAULT NULL,
  `role_status` int NOT NULL,
  `role_created_date` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `worktual_sum_category_master`
--

DROP TABLE IF EXISTS `worktual_sum_category_master`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `worktual_sum_category_master` (
  `category_id` int NOT NULL AUTO_INCREMENT,
  `category_name` varchar(100) DEFAULT NULL,
  `category_status` int DEFAULT NULL,
  `created_date` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `worktual_user_dtl`
--

DROP TABLE IF EXISTS `worktual_user_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `worktual_user_dtl` (
  `sip_login_id` int NOT NULL,
  `email` varchar(250) NOT NULL,
  `password` varchar(50) DEFAULT NULL,
  `firstname` varchar(150) DEFAULT NULL,
  `lastname` varchar(150) DEFAULT NULL,
  `pin` varchar(10) DEFAULT NULL,
  `create_date` datetime(3) DEFAULT NULL,
  `created_by` varchar(250) DEFAULT NULL,
  `last_update` datetime(3) DEFAULT NULL,
  `last_updatedby` varchar(250) DEFAULT NULL,
  `deviceid` varchar(100) DEFAULT NULL,
  `ip_address` varchar(20) DEFAULT NULL,
  `expiry_time` int DEFAULT NULL,
  `sip_password` varchar(15) DEFAULT NULL,
  `is_migrate` int DEFAULT '0',
  `domain_id` int DEFAULT NULL,
  `dp_password` varchar(255) DEFAULT NULL,
  `is_mongodb_status` int DEFAULT '0',
  PRIMARY KEY (`email`),
  UNIQUE KEY `sip_login_id` (`sip_login_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wtms_Role_Menu_Mapping`
--

DROP TABLE IF EXISTS `wtms_Role_Menu_Mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wtms_Role_Menu_Mapping` (
  `Fk_Role_ID` int DEFAULT NULL,
  `Fk_Menu_ID` int DEFAULT NULL,
  `Last_update` datetime(3) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`),
  KEY `Fk_Menu_ID` (`Fk_Menu_ID`),
  KEY `Fk_Role_ID` (`Fk_Role_ID`),
  CONSTRAINT `wtms_Role_Menu_Mapping_ibfk_1` FOREIGN KEY (`Fk_Menu_ID`) REFERENCES `wtms_tbl_Menu` (`Pk_Menu_Id`),
  CONSTRAINT `wtms_Role_Menu_Mapping_ibfk_2` FOREIGN KEY (`Fk_Role_ID`) REFERENCES `worktual_roles_master_dtl` (`role_id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wtms_config_type`
--

DROP TABLE IF EXISTS `wtms_config_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wtms_config_type` (
  `configid` int NOT NULL AUTO_INCREMENT,
  `config_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`configid`),
  KEY `FK__wtms_feat__fk_co__5FE31204Idx2` (`configid`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wtms_contract_period_master`
--

DROP TABLE IF EXISTS `wtms_contract_period_master`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wtms_contract_period_master` (
  `cop_id` int NOT NULL AUTO_INCREMENT,
  `cop_cont_id` int DEFAULT NULL,
  `cop_period` int DEFAULT NULL,
  `cop_description` varchar(50) DEFAULT NULL,
  `create_date` datetime(3) DEFAULT NULL,
  `status` int DEFAULT NULL,
  PRIMARY KEY (`cop_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wtms_contract_pricing_dtl`
--

DROP TABLE IF EXISTS `wtms_contract_pricing_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wtms_contract_pricing_dtl` (
  `tier_id` int NOT NULL,
  `fk_user_type_id` int NOT NULL,
  `fk_contract_period_id` int NOT NULL,
  `discount1` float DEFAULT NULL,
  `price1` float DEFAULT NULL,
  `min_user` int DEFAULT NULL,
  `create_by` varchar(100) DEFAULT NULL,
  `create_date` datetime(3) DEFAULT NULL,
  `price2` float DEFAULT NULL,
  `discount2` float DEFAULT NULL,
  `price3` float DEFAULT NULL,
  `months1` int DEFAULT NULL,
  `months2` int DEFAULT NULL,
  `max_user` int DEFAULT NULL,
  PRIMARY KEY (`tier_id`,`fk_user_type_id`,`fk_contract_period_id`),
  KEY `FK__wtms_cont__fk_co__10F05DB3Idx` (`fk_contract_period_id`),
  KEY `FK__wtms_cont__fk_us__0FFC397AIdx` (`fk_user_type_id`),
  CONSTRAINT `FK__wtms_cont__fk_co__10F05DB3` FOREIGN KEY (`fk_contract_period_id`) REFERENCES `wtms_contract_period_master` (`cop_id`),
  CONSTRAINT `FK__wtms_cont__fk_us__0FFC397A` FOREIGN KEY (`fk_user_type_id`) REFERENCES `wtms_no_of_users_master` (`nof_id`),
  CONSTRAINT `wtms_contract_pricing_dtl_ibfk_1` FOREIGN KEY (`fk_contract_period_id`) REFERENCES `wtms_contract_period_master` (`cop_id`),
  CONSTRAINT `wtms_contract_pricing_dtl_ibfk_2` FOREIGN KEY (`fk_user_type_id`) REFERENCES `wtms_no_of_users_master` (`nof_id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wtms_contract_pricing_dtl_MT`
--

DROP TABLE IF EXISTS `wtms_contract_pricing_dtl_MT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wtms_contract_pricing_dtl_MT` (
  `tier_id` int NOT NULL,
  `fk_user_type_id` int NOT NULL,
  `fk_contract_period_id` int NOT NULL,
  `discount1` float DEFAULT NULL,
  `price1` float DEFAULT NULL,
  `min_user` int DEFAULT NULL,
  `create_by` varchar(100) DEFAULT NULL,
  `create_date` datetime(3) DEFAULT NULL,
  `price2` float DEFAULT NULL,
  `discount2` float DEFAULT NULL,
  `price3` float DEFAULT NULL,
  `months1` int DEFAULT NULL,
  `months2` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  `max_user` int DEFAULT NULL,
  PRIMARY KEY (`idpk`)
) ENGINE=InnoDB AUTO_INCREMENT=5055 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wtms_copy_of_tier_management_temp`
--

DROP TABLE IF EXISTS `wtms_copy_of_tier_management_temp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wtms_copy_of_tier_management_temp` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fk_tier_id` int DEFAULT NULL,
  `tier_name` varchar(100) DEFAULT NULL,
  `tier_description` varchar(250) DEFAULT NULL,
  `tier_type` int DEFAULT NULL,
  `prod_type_id` int DEFAULT NULL,
  `bund_prd_type` int DEFAULT NULL,
  `fk_purpose_id` int DEFAULT NULL,
  `status` int DEFAULT NULL,
  `min_users` int DEFAULT NULL,
  `free_trial` int DEFAULT NULL,
  `free_trial_days` int DEFAULT NULL,
  `apply_new_exist_cust` int DEFAULT NULL,
  `free_or_paid` int DEFAULT NULL,
  `currency` int DEFAULT NULL,
  `create_date` datetime(3) DEFAULT NULL,
  `modify_date` datetime(3) DEFAULT NULL,
  `no_of_users` varchar(50) DEFAULT NULL,
  `contract_period` varchar(50) DEFAULT NULL,
  `per_addn_user` float DEFAULT NULL,
  `per_addn_user_currency` int DEFAULT NULL,
  `product_id` varchar(50) DEFAULT NULL,
  `sub_product_id` varchar(50) DEFAULT NULL,
  `is_review` int DEFAULT NULL,
  `country_id` int DEFAULT NULL,
  `module_id` varchar(150) DEFAULT NULL,
  `sub_module_id` varchar(150) DEFAULT NULL,
  `reseller_id` text,
  `pro_user_count` int DEFAULT NULL,
  `standard_user_count` int DEFAULT NULL,
  `basic_user_count` int DEFAULT NULL,
  `free_trail_status` int DEFAULT (0),
  `free_trail_days` int DEFAULT NULL,
  `free_trial_amount` float DEFAULT NULL,
  `double_up` int DEFAULT '0',
  `Installation_cost` float DEFAULT NULL,
  `Installation_cost_free_count` float DEFAULT NULL,
  `platform_fee` float DEFAULT NULL,
  `messages_count` int DEFAULT NULL,
  `sessions_count` int DEFAULT NULL,
  `Type_of_plan` int DEFAULT NULL,
  `Custom_status` int DEFAULT NULL,
  `platform_fee_year` float DEFAULT NULL,
  `booking_user_count` int DEFAULT NULL,
  `booking_user_price` float DEFAULT NULL,
  `platform_fee_json_info` json DEFAULT NULL,
  `parent_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK__wtms_copy__fk_ti__2A461B62Idx` (`fk_tier_id`),
  CONSTRAINT `FK__wtms_copy__fk_ti__2A461B62` FOREIGN KEY (`fk_tier_id`) REFERENCES `wtms_tier_management` (`tier_id`),
  CONSTRAINT `wtms_copy_of_tier_management_temp_ibfk_1` FOREIGN KEY (`fk_tier_id`) REFERENCES `wtms_tier_management` (`tier_id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=180 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wtms_country_list`
--

DROP TABLE IF EXISTS `wtms_country_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wtms_country_list` (
  `id` int NOT NULL AUTO_INCREMENT,
  `country_name` varchar(250) DEFAULT NULL,
  `status` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wtms_feature_category`
--

DROP TABLE IF EXISTS `wtms_feature_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wtms_feature_category` (
  `category_id` int NOT NULL AUTO_INCREMENT,
  `category_Name` varchar(255) NOT NULL,
  `fk_prod_id` int NOT NULL,
  `fk_sub_prod` int NOT NULL,
  `category_description` varchar(255) DEFAULT NULL,
  `category_status` int DEFAULT '1',
  `category_position` int DEFAULT NULL,
  `create_date` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`category_id`),
  KEY `FK__wtms_ref___fk_pr__54A66982Idx` (`fk_prod_id`),
  KEY `FK__wtms_feat__fk_ca__59361475Idx2` (`category_id`),
  CONSTRAINT `FK__wtms_ref___fk_pr__54A66982` FOREIGN KEY (`fk_prod_id`) REFERENCES `product_master` (`prod_id`),
  CONSTRAINT `wtms_feature_category_ibfk_1` FOREIGN KEY (`fk_prod_id`) REFERENCES `product_master` (`prod_id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=163 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wtms_feature_field_map_details`
--

DROP TABLE IF EXISTS `wtms_feature_field_map_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wtms_feature_field_map_details` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fk_feature_id` int DEFAULT NULL,
  `fk_config_id` int DEFAULT NULL,
  `value` varchar(100) DEFAULT NULL,
  `value_Desc` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK__wtms_feat__fk_co__5FE31204Idx` (`fk_config_id`),
  KEY `FK__wtms_feat__fk_fe__5EEEEDCBIdx` (`fk_feature_id`),
  CONSTRAINT `FK__wtms_feat__fk_co__5FE31204` FOREIGN KEY (`fk_config_id`) REFERENCES `wtms_config_type` (`configid`),
  CONSTRAINT `FK__wtms_feat__fk_fe__5EEEEDCB` FOREIGN KEY (`fk_feature_id`) REFERENCES `wtms_feature_info` (`feature_id`),
  CONSTRAINT `wtms_feature_field_map_details_ibfk_1` FOREIGN KEY (`fk_config_id`) REFERENCES `wtms_config_type` (`configid`),
  CONSTRAINT `wtms_feature_field_map_details_ibfk_2` FOREIGN KEY (`fk_feature_id`) REFERENCES `wtms_feature_info` (`feature_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9303 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wtms_feature_info`
--

DROP TABLE IF EXISTS `wtms_feature_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wtms_feature_info` (
  `feature_id` int NOT NULL AUTO_INCREMENT,
  `fk_category_id` int DEFAULT NULL,
  `fk_level_id` int DEFAULT NULL,
  `feature_name` varchar(500) DEFAULT NULL,
  `feature_description` text,
  `feature_usability` int DEFAULT NULL,
  `fk_config_id` int DEFAULT NULL,
  `no_fields` int DEFAULT NULL,
  `tariff` varchar(10) DEFAULT NULL,
  `price` float DEFAULT NULL,
  `status` int DEFAULT NULL,
  `user_type` varchar(20) DEFAULT NULL,
  `create_date` datetime(3) DEFAULT NULL,
  `category_name` varchar(100) DEFAULT NULL,
  `create_by` varchar(10) DEFAULT NULL,
  `max_user_in_grp` int DEFAULT NULL,
  `accessibility` int DEFAULT NULL,
  `main_menu_id` int DEFAULT NULL,
  `sub_menu_id` int DEFAULT NULL,
  `addon_bundle_id` int DEFAULT NULL,
  `feature_type_status` int DEFAULT '0',
  `summary_notes` text,
  `position` int DEFAULT NULL,
  PRIMARY KEY (`feature_id`),
  KEY `FK__wtms_feat__fk_co__5B1E5CE7Idx` (`fk_config_id`),
  KEY `FK__wtms_feat__fk_ca__59361475Idx` (`fk_category_id`),
  KEY `FK__wtms_feat__fk_le__5A2A38AEIdx` (`fk_level_id`),
  KEY `FK__wtms_feat__fk_fe__5EEEEDCBIdx2` (`feature_id`),
  KEY `id_feature_id` (`feature_id`),
  KEY `idx_feature_usability` (`feature_usability`),
  KEY `idx_status` (`status`),
  CONSTRAINT `FK__wtms_feat__fk_ca__59361475` FOREIGN KEY (`fk_category_id`) REFERENCES `wtms_feature_category` (`category_id`),
  CONSTRAINT `FK__wtms_feat__fk_co__5B1E5CE7` FOREIGN KEY (`fk_config_id`) REFERENCES `wtms_config_type` (`configid`),
  CONSTRAINT `FK__wtms_feat__fk_le__5A2A38AE` FOREIGN KEY (`fk_level_id`) REFERENCES `wtms_ref_feature_level` (`level_id`),
  CONSTRAINT `wtms_feature_info_ibfk_1` FOREIGN KEY (`fk_category_id`) REFERENCES `wtms_feature_category` (`category_id`),
  CONSTRAINT `wtms_feature_info_ibfk_2` FOREIGN KEY (`fk_config_id`) REFERENCES `wtms_config_type` (`configid`),
  CONSTRAINT `wtms_feature_info_ibfk_3` FOREIGN KEY (`fk_level_id`) REFERENCES `wtms_ref_feature_level` (`level_id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=1113 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wtms_feature_prod_wise_category`
--

DROP TABLE IF EXISTS `wtms_feature_prod_wise_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wtms_feature_prod_wise_category` (
  `category_id` int NOT NULL AUTO_INCREMENT,
  `category_Name` varchar(255) NOT NULL,
  `fk_prod_id` int NOT NULL,
  `category_description` varchar(255) DEFAULT NULL,
  `category_status` int DEFAULT '1',
  `category_position` int DEFAULT NULL,
  `create_date` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`category_id`),
  KEY `FK__wtms_ref___fk_pr__54A66982Idx` (`fk_prod_id`),
  KEY `FK__wtms_feat__fk_ca__59361475Idx2` (`category_id`),
  CONSTRAINT `FK__wtms_ref___fk_pr__54A66983` FOREIGN KEY (`fk_prod_id`) REFERENCES `product_master` (`prod_id`),
  CONSTRAINT `wtms_feature_prod_wise_category_ibfk_1` FOREIGN KEY (`fk_prod_id`) REFERENCES `product_master` (`prod_id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=115 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wtms_module_info`
--

DROP TABLE IF EXISTS `wtms_module_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wtms_module_info` (
  `mod_id` int NOT NULL AUTO_INCREMENT,
  `module_name` varchar(250) DEFAULT NULL,
  `status` int DEFAULT NULL,
  PRIMARY KEY (`mod_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wtms_no_of_users_master`
--

DROP TABLE IF EXISTS `wtms_no_of_users_master`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wtms_no_of_users_master` (
  `nof_id` int NOT NULL AUTO_INCREMENT,
  `nof_from` int DEFAULT NULL,
  `nof_to` int DEFAULT NULL,
  `nof_users_description` varchar(50) DEFAULT NULL,
  `nof_min_user` int DEFAULT NULL,
  `status` int DEFAULT NULL,
  `create_date` datetime(3) DEFAULT NULL,
  `user_type` int DEFAULT NULL,
  PRIMARY KEY (`nof_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wtms_prod_wise_feature_info`
--

DROP TABLE IF EXISTS `wtms_prod_wise_feature_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wtms_prod_wise_feature_info` (
  `addon_feature_id` int NOT NULL AUTO_INCREMENT,
  `fk_category_id` int DEFAULT NULL,
  `fk_level_id` int DEFAULT NULL,
  `tier_id` varchar(150) DEFAULT NULL,
  `addon_feature_name` varchar(500) DEFAULT NULL,
  `addon_feature_description` varchar(500) DEFAULT NULL,
  `addon_feature_usability` int DEFAULT NULL,
  `price` float DEFAULT NULL,
  `status` int DEFAULT NULL,
  `user_type` varchar(20) DEFAULT NULL,
  `create_date` datetime(3) DEFAULT NULL,
  `category_name` varchar(100) DEFAULT NULL,
  `create_by` varchar(10) DEFAULT NULL,
  `bundle_id` int DEFAULT NULL,
  `image_name` varchar(200) DEFAULT NULL,
  `lang_code` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`addon_feature_id`),
  KEY `FK__wtms_feat__fk_ca__59361475Idx` (`fk_category_id`),
  KEY `FK__wtms_feat__fk_le__5A2A38AEIdx` (`fk_level_id`),
  KEY `FK__wtms_feat__fk_fe__5EEEEDCBIdx2` (`addon_feature_id`),
  CONSTRAINT `FK__wtms_feat__fk_ca__59361476` FOREIGN KEY (`fk_category_id`) REFERENCES `wtms_feature_prod_wise_category` (`category_id`),
  CONSTRAINT `FK__wtms_feat__fk_le__5A2A38AF` FOREIGN KEY (`fk_level_id`) REFERENCES `wtms_ref_feature_level` (`level_id`),
  CONSTRAINT `wtms_feature_info_ibfk_4` FOREIGN KEY (`fk_level_id`) REFERENCES `wtms_ref_feature_level` (`level_id`),
  CONSTRAINT `wtms_feature_info_ibfk_6` FOREIGN KEY (`fk_category_id`) REFERENCES `wtms_feature_prod_wise_category` (`category_id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=832 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wtms_ref_feature_level`
--

DROP TABLE IF EXISTS `wtms_ref_feature_level`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wtms_ref_feature_level` (
  `level_id` int NOT NULL AUTO_INCREMENT,
  `level_Desc` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`level_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wtms_ref_tier_purpose`
--

DROP TABLE IF EXISTS `wtms_ref_tier_purpose`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wtms_ref_tier_purpose` (
  `purpose_id` int NOT NULL AUTO_INCREMENT,
  `purpose_name` varchar(100) DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `status` int DEFAULT '1',
  PRIMARY KEY (`purpose_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wtms_ref_tier_type`
--

DROP TABLE IF EXISTS `wtms_ref_tier_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wtms_ref_tier_type` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `create_date` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK__wtms_tier__fk_ti__68785805Idx2` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wtms_sub_module_info`
--

DROP TABLE IF EXISTS `wtms_sub_module_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wtms_sub_module_info` (
  `sub_mod_id` int NOT NULL AUTO_INCREMENT,
  `fk_mod_id` int DEFAULT NULL,
  `sub_module_name` varchar(250) DEFAULT NULL,
  `status` int DEFAULT NULL,
  `sub_module_name_url` varchar(255) DEFAULT NULL,
  `module_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`sub_mod_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wtms_tbl_Menu`
--

DROP TABLE IF EXISTS `wtms_tbl_Menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wtms_tbl_Menu` (
  `Pk_Menu_Id` int NOT NULL AUTO_INCREMENT,
  `Menu_Name` varchar(250) DEFAULT NULL,
  `Menu_link` varchar(250) DEFAULT NULL,
  `status` int DEFAULT '1',
  `position` int DEFAULT NULL,
  PRIMARY KEY (`Pk_Menu_Id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wtms_tier_approval_management`
--

DROP TABLE IF EXISTS `wtms_tier_approval_management`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wtms_tier_approval_management` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fk_tier_id` int DEFAULT NULL,
  `approver_1_userid` int DEFAULT NULL,
  `approver_1_user_group_name` varchar(10) DEFAULT NULL,
  `approver_1_status` varchar(50) DEFAULT NULL,
  `approver_1_approved_on` datetime(3) DEFAULT NULL,
  `approver_1_remarks` varchar(250) DEFAULT NULL,
  `approver_2_userid` int DEFAULT NULL,
  `approver_2_user_group_name` varchar(10) DEFAULT NULL,
  `approver_2_status` varchar(50) DEFAULT NULL,
  `approver_2_approved_on` datetime(3) DEFAULT NULL,
  `approver_2_remarks` varchar(250) DEFAULT NULL,
  `approver_1_username` varchar(50) DEFAULT NULL,
  `approver_2_username` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK__wtms_tier__fk_ti__1DE0447DIdx` (`fk_tier_id`),
  CONSTRAINT `FK__wtms_tier__fk_ti__1DE0447D` FOREIGN KEY (`fk_tier_id`) REFERENCES `wtms_tier_management` (`tier_id`),
  CONSTRAINT `wtms_tier_approval_management_ibfk_1` FOREIGN KEY (`fk_tier_id`) REFERENCES `wtms_tier_management` (`tier_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4595 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wtms_tier_category_position`
--

DROP TABLE IF EXISTS `wtms_tier_category_position`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wtms_tier_category_position` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fk_tier_id` int DEFAULT NULL,
  `catg_id` int DEFAULT NULL,
  `catg_pos` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK__wtms_tier__catg___74DE2EEAIdx` (`catg_id`),
  KEY `FK__wtms_tier__fk_ti__73EA0AB1Idx` (`fk_tier_id`),
  CONSTRAINT `FK__wtms_tier__catg___74DE2EEA` FOREIGN KEY (`catg_id`) REFERENCES `wtms_feature_category` (`category_id`),
  CONSTRAINT `FK__wtms_tier__fk_ti__73EA0AB1` FOREIGN KEY (`fk_tier_id`) REFERENCES `wtms_tier_management` (`tier_id`),
  CONSTRAINT `wtms_tier_category_position_ibfk_1` FOREIGN KEY (`catg_id`) REFERENCES `wtms_feature_category` (`category_id`),
  CONSTRAINT `wtms_tier_category_position_ibfk_2` FOREIGN KEY (`fk_tier_id`) REFERENCES `wtms_tier_management` (`tier_id`)
) ENGINE=InnoDB AUTO_INCREMENT=23469 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wtms_tier_category_position_MT`
--

DROP TABLE IF EXISTS `wtms_tier_category_position_MT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wtms_tier_category_position_MT` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fk_tier_id` int DEFAULT NULL,
  `catg_id` int DEFAULT NULL,
  `catg_pos` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21626 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wtms_tier_catg_feature_mapping_info`
--

DROP TABLE IF EXISTS `wtms_tier_catg_feature_mapping_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wtms_tier_catg_feature_mapping_info` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tier_id` int DEFAULT NULL,
  `tiertype` int DEFAULT NULL,
  `product_id` int DEFAULT NULL,
  `sub_product_id` int DEFAULT NULL,
  `categoryid` int DEFAULT NULL,
  `featureid` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=62668 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wtms_tier_catg_feature_mapping_info_MT`
--

DROP TABLE IF EXISTS `wtms_tier_catg_feature_mapping_info_MT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wtms_tier_catg_feature_mapping_info_MT` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tier_id` int DEFAULT NULL,
  `tiertype` int DEFAULT NULL,
  `product_id` int DEFAULT NULL,
  `sub_product_id` int DEFAULT NULL,
  `categoryid` int DEFAULT NULL,
  `featureid` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=59678 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wtms_tier_feature_mapping_xml`
--

DROP TABLE IF EXISTS `wtms_tier_feature_mapping_xml`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wtms_tier_feature_mapping_xml` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tier_id` int DEFAULT NULL,
  `tiertype` int DEFAULT NULL,
  `bundle_id` int DEFAULT NULL,
  `product_id` int DEFAULT NULL,
  `sub_product_id` int DEFAULT NULL,
  `categoryid` int DEFAULT NULL,
  `featureid` int DEFAULT NULL,
  `value1` text,
  `value2` text,
  `value3` text,
  `value4` text,
  `value5` text,
  `value6` text,
  `value7` text,
  `value8` text,
  `value9` text,
  `value10` text,
  PRIMARY KEY (`id`),
  KEY `idx_wtms_tier_feature_mapping_xml_featureid` (`featureid`),
  KEY `idx_tier_id` (`tier_id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=202965 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wtms_tier_feature_mapping_xml_MT`
--

DROP TABLE IF EXISTS `wtms_tier_feature_mapping_xml_MT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wtms_tier_feature_mapping_xml_MT` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tier_id` int DEFAULT NULL,
  `tiertype` int DEFAULT NULL,
  `bundle_id` int DEFAULT NULL,
  `product_id` int DEFAULT NULL,
  `sub_product_id` int DEFAULT NULL,
  `categoryid` int DEFAULT NULL,
  `featureid` int DEFAULT NULL,
  `value1` text,
  `value2` text,
  `value3` text,
  `value4` text,
  `value5` text,
  `value6` text,
  `value7` text,
  `value8` text,
  `value9` text,
  `value10` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=208558 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wtms_tier_management`
--

DROP TABLE IF EXISTS `wtms_tier_management`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wtms_tier_management` (
  `tier_id` int NOT NULL AUTO_INCREMENT,
  `tier_name` varchar(150) DEFAULT NULL,
  `tier_description` varchar(250) DEFAULT NULL,
  `tier_type` int DEFAULT NULL,
  `prod_type_id` int DEFAULT NULL,
  `bund_prd_type` int DEFAULT NULL,
  `fk_purpose_id` int DEFAULT NULL,
  `status` int DEFAULT NULL,
  `min_users` int DEFAULT NULL,
  `free_trial` int DEFAULT NULL,
  `free_trial_days` int DEFAULT NULL,
  `apply_new_exist_cust` varchar(10) DEFAULT NULL,
  `free_or_paid` int DEFAULT NULL,
  `currency` int DEFAULT NULL,
  `create_date` datetime(3) DEFAULT NULL,
  `modify_date` datetime(3) DEFAULT NULL,
  `no_of_users` varchar(50) DEFAULT NULL,
  `contract_period` varchar(50) DEFAULT NULL,
  `per_addn_user` float DEFAULT NULL,
  `per_addn_user_currency` int DEFAULT NULL,
  `product_id` varchar(50) DEFAULT NULL,
  `sub_product_id` varchar(50) DEFAULT NULL,
  `is_review` int DEFAULT NULL,
  `module_id` varchar(150) DEFAULT NULL,
  `sub_module_id` varchar(150) DEFAULT NULL,
  `country_id` int DEFAULT NULL,
  `reseller_id` text,
  `pro_user_count` int DEFAULT NULL,
  `standard_user_count` int DEFAULT NULL,
  `basic_user_count` int DEFAULT NULL,
  `free_trail_status` int DEFAULT (0),
  `free_trail_days` int DEFAULT NULL,
  `free_trial_amount` float DEFAULT NULL,
  `double_up` int DEFAULT '0',
  `Installation_cost` float DEFAULT NULL,
  `Installation_cost_free_count` float DEFAULT NULL,
  `platform_fee` float DEFAULT NULL,
  `messages_count` int DEFAULT NULL,
  `sessions_count` int DEFAULT NULL,
  `Type_of_plan` int DEFAULT NULL,
  `Custom_status` int DEFAULT NULL,
  `platform_fee_year` float DEFAULT NULL,
  `booking_user_count` int DEFAULT NULL,
  `booking_user_price` float DEFAULT NULL,
  `platform_fee_json_info` json DEFAULT NULL,
  `parent_id` int DEFAULT NULL,
  PRIMARY KEY (`tier_id`),
  KEY `FK__wtms_tier__prod___3621E262Idx` (`prod_type_id`),
  KEY `FK__wtms_tier__curre__22A4F99AIdx` (`currency`),
  KEY `FK__wtms_tier__tier___352DBE29Idx` (`tier_type`),
  KEY `FK__wtms_tier__fk_ti__1DE0447DIdx2` (`tier_id`),
  KEY `fk_purpose_id` (`fk_purpose_id`),
  CONSTRAINT `FK__wtms_tier__curre__22A4F99A` FOREIGN KEY (`currency`) REFERENCES `worktual_currency_master_dtl` (`curr_id`),
  CONSTRAINT `FK__wtms_tier__prod___3621E262` FOREIGN KEY (`prod_type_id`) REFERENCES `product_master` (`prod_id`),
  CONSTRAINT `FK__wtms_tier__tier___352DBE29` FOREIGN KEY (`tier_type`) REFERENCES `wtms_ref_tier_type` (`id`),
  CONSTRAINT `wtms_tier_management_ibfk_1` FOREIGN KEY (`currency`) REFERENCES `worktual_currency_master_dtl` (`curr_id`),
  CONSTRAINT `wtms_tier_management_ibfk_2` FOREIGN KEY (`tier_type`) REFERENCES `wtms_ref_tier_type` (`id`),
  CONSTRAINT `wtms_tier_management_ibfk_3` FOREIGN KEY (`prod_type_id`) REFERENCES `product_master` (`prod_id`),
  CONSTRAINT `wtms_tier_management_ibfk_4` FOREIGN KEY (`fk_purpose_id`) REFERENCES `wtms_ref_tier_purpose` (`purpose_id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=200 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wtms_tier_management_log`
--

DROP TABLE IF EXISTS `wtms_tier_management_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wtms_tier_management_log` (
  `tier_id` int DEFAULT NULL,
  `tier_name` varchar(150) DEFAULT NULL,
  `tier_description` varchar(250) DEFAULT NULL,
  `tier_type` int DEFAULT NULL,
  `prod_type_id` int DEFAULT NULL,
  `bund_prd_type` int DEFAULT NULL,
  `product_id` varchar(50) DEFAULT NULL,
  `sub_product_id` varchar(200) DEFAULT NULL,
  `fk_purpose_id` int DEFAULT NULL,
  `status` int DEFAULT NULL,
  `apply_new_exist_cust` varchar(10) DEFAULT NULL,
  `free_or_paid` int DEFAULT NULL,
  `currency` int DEFAULT NULL,
  `no_of_users` varchar(50) DEFAULT NULL,
  `min_users` int DEFAULT NULL,
  `contract_period` varchar(50) DEFAULT NULL,
  `per_addn_user` float DEFAULT NULL,
  `per_addn_user_currency` int DEFAULT NULL,
  `User_Range_xml` longtext,
  `tier_summary_map` longtext,
  `catg_position_xml` longtext,
  `feature_mapping` longtext,
  `create_date` datetime(3) DEFAULT NULL,
  `create_by` varchar(20) DEFAULT NULL,
  `is_review` int DEFAULT NULL,
  `processtype` int DEFAULT NULL,
  `catg_feature_map_xml` longtext,
  `client_ip` varchar(20) DEFAULT NULL,
  `id` int NOT NULL AUTO_INCREMENT,
  `sub_module_id` varchar(150) DEFAULT NULL,
  `module_id` varchar(150) DEFAULT NULL,
  `country_id` int DEFAULT NULL,
  `reseller_id` text,
  `pro_user_count` int DEFAULT NULL,
  `standard_user_count` int DEFAULT NULL,
  `basic_user_count` int DEFAULT NULL,
  `free_trail_status` int DEFAULT (0),
  `free_trail_days` int DEFAULT NULL,
  `double_up` int DEFAULT '0',
  `Installation_cost` float DEFAULT NULL,
  `Installation_cost_free_count` float DEFAULT NULL,
  `platform_fee` float DEFAULT NULL,
  `messages_count` int DEFAULT NULL,
  `sessions_count` int DEFAULT NULL,
  `Type_of_plan` int DEFAULT NULL,
  `Custom_status` int DEFAULT NULL,
  `platform_fee_year` float DEFAULT NULL,
  `booking_user_count` int DEFAULT NULL,
  `booking_user_price` float DEFAULT NULL,
  `platform_fee_json_info` json DEFAULT NULL,
  `parent_id` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=1905 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wtms_tier_platform_fee_info`
--

DROP TABLE IF EXISTS `wtms_tier_platform_fee_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wtms_tier_platform_fee_info` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tier_id` int DEFAULT NULL,
  `platform_fee_name` varchar(100) DEFAULT NULL,
  `platform_fee_month_price` float DEFAULT NULL,
  `platform_fee_yearly_price` float DEFAULT NULL,
  `platform_fee_count` int DEFAULT NULL,
  `createdate` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4339 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wtms_tier_reseller_info`
--

DROP TABLE IF EXISTS `wtms_tier_reseller_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wtms_tier_reseller_info` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tier_id` int DEFAULT NULL,
  `Reseller_id` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2135 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wtms_tier_sub_product_master`
--

DROP TABLE IF EXISTS `wtms_tier_sub_product_master`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wtms_tier_sub_product_master` (
  `fk_tier_id` int DEFAULT NULL,
  `fk_tier_type` int DEFAULT NULL,
  `fk_prod_id` int DEFAULT NULL,
  `fk_sub_prod_id` int DEFAULT NULL,
  `create_date` datetime(3) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`),
  KEY `FK__wtms_tier__fk_pr__3BDABBB8Idx` (`fk_prod_id`),
  KEY `FK__wtms_tier__fk_ti__3AE6977FIdx` (`fk_tier_type`),
  KEY `FK__wtms_tier__fk_ti__39F27346Idx` (`fk_tier_id`),
  CONSTRAINT `FK__wtms_tier__fk_pr__3BDABBB8` FOREIGN KEY (`fk_prod_id`) REFERENCES `product_master` (`prod_id`),
  CONSTRAINT `FK__wtms_tier__fk_ti__39F27346` FOREIGN KEY (`fk_tier_id`) REFERENCES `wtms_tier_management` (`tier_id`),
  CONSTRAINT `FK__wtms_tier__fk_ti__3AE6977F` FOREIGN KEY (`fk_tier_type`) REFERENCES `wtms_ref_tier_type` (`id`),
  CONSTRAINT `wtms_tier_sub_product_master_ibfk_1` FOREIGN KEY (`fk_prod_id`) REFERENCES `product_master` (`prod_id`),
  CONSTRAINT `wtms_tier_sub_product_master_ibfk_2` FOREIGN KEY (`fk_tier_id`) REFERENCES `wtms_tier_management` (`tier_id`),
  CONSTRAINT `wtms_tier_sub_product_master_ibfk_3` FOREIGN KEY (`fk_tier_type`) REFERENCES `wtms_ref_tier_type` (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=1888 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wtms_tier_sub_product_master_MT`
--

DROP TABLE IF EXISTS `wtms_tier_sub_product_master_MT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wtms_tier_sub_product_master_MT` (
  `fk_tier_id` int DEFAULT NULL,
  `fk_tier_type` int DEFAULT NULL,
  `fk_prod_id` int DEFAULT NULL,
  `fk_sub_prod_id` int DEFAULT NULL,
  `create_date` datetime(3) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) ENGINE=InnoDB AUTO_INCREMENT=1747 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wtms_tier_summaries_master_dtl`
--

DROP TABLE IF EXISTS `wtms_tier_summaries_master_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wtms_tier_summaries_master_dtl` (
  `summary_id` int NOT NULL AUTO_INCREMENT,
  `fk_prod_id` int DEFAULT NULL,
  `fk_sub_prod` int DEFAULT NULL,
  `fk_bundle_id` int DEFAULT NULL,
  `summary_name` varchar(155) DEFAULT NULL,
  `summary_desc` text,
  `Summary_url` text,
  `summary_status` int DEFAULT NULL,
  `summary_create_date` datetime(3) DEFAULT NULL,
  `fk_tier_id` int DEFAULT NULL,
  PRIMARY KEY (`summary_id`),
  KEY `FK__wtms_tier__fk_ti__68785805Idx` (`fk_tier_id`),
  CONSTRAINT `FK__wtms_tier__fk_ti__68785805` FOREIGN KEY (`fk_tier_id`) REFERENCES `wtms_ref_tier_type` (`id`),
  CONSTRAINT `wtms_tier_summaries_master_dtl_ibfk_1` FOREIGN KEY (`fk_tier_id`) REFERENCES `wtms_ref_tier_type` (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=397 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wtms_tier_summary_map`
--

DROP TABLE IF EXISTS `wtms_tier_summary_map`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wtms_tier_summary_map` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fk_tier_id` int DEFAULT NULL,
  `tiertype` int DEFAULT NULL,
  `bundle_id` int DEFAULT NULL,
  `product_id` int DEFAULT NULL,
  `sub_product_id` int DEFAULT NULL,
  `summary_id` int DEFAULT NULL,
  `position` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK__wtms_tier__produ__7C7F50B2Idx` (`product_id`),
  KEY `FK__wtms_tier__tiert__7A970840Idx` (`tiertype`),
  KEY `FK__wtms_tier__fk_ti__79A2E407Idx` (`fk_tier_id`),
  CONSTRAINT `FK__wtms_tier__fk_ti__79A2E407` FOREIGN KEY (`fk_tier_id`) REFERENCES `wtms_tier_management` (`tier_id`),
  CONSTRAINT `FK__wtms_tier__produ__7C7F50B2` FOREIGN KEY (`product_id`) REFERENCES `product_master` (`prod_id`),
  CONSTRAINT `FK__wtms_tier__tiert__7A970840` FOREIGN KEY (`tiertype`) REFERENCES `wtms_ref_tier_type` (`id`),
  CONSTRAINT `wtms_tier_summary_map_ibfk_1` FOREIGN KEY (`fk_tier_id`) REFERENCES `wtms_tier_management` (`tier_id`),
  CONSTRAINT `wtms_tier_summary_map_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `product_master` (`prod_id`),
  CONSTRAINT `wtms_tier_summary_map_ibfk_3` FOREIGN KEY (`tiertype`) REFERENCES `wtms_ref_tier_type` (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=20181 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wtms_tier_summary_map_MT`
--

DROP TABLE IF EXISTS `wtms_tier_summary_map_MT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wtms_tier_summary_map_MT` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fk_tier_id` int DEFAULT NULL,
  `tiertype` int DEFAULT NULL,
  `bundle_id` int DEFAULT NULL,
  `product_id` int DEFAULT NULL,
  `sub_product_id` int DEFAULT NULL,
  `summary_id` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=18304 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wtms_tier_summary_position`
--

DROP TABLE IF EXISTS `wtms_tier_summary_position`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wtms_tier_summary_position` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fk_tier_id` int DEFAULT NULL,
  `summary_id` int DEFAULT NULL,
  `position` int DEFAULT NULL,
  `summary_name` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1069 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wtms_user_group_details`
--

DROP TABLE IF EXISTS `wtms_user_group_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wtms_user_group_details` (
  `id` int NOT NULL AUTO_INCREMENT,
  `Fk_user_group_id` int DEFAULT NULL,
  `fk_menu_id` int DEFAULT NULL,
  `is_menu` int DEFAULT NULL,
  `is_create` int DEFAULT NULL,
  `is_edit` int DEFAULT NULL,
  `is_view` int DEFAULT NULL,
  `is_copy` int DEFAULT NULL,
  `is_approve_reject_rfm` int DEFAULT NULL,
  `create_date` datetime(3) DEFAULT NULL,
  `status` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK__wtms_user__fk_me__2F3FDAA9Idx` (`fk_menu_id`),
  KEY `FK__wtms_user__Fk_us__2E4BB670Idx` (`Fk_user_group_id`),
  CONSTRAINT `FK__wtms_user__fk_me__2F3FDAA9` FOREIGN KEY (`fk_menu_id`) REFERENCES `wtms_tbl_Menu` (`Pk_Menu_Id`),
  CONSTRAINT `FK__wtms_user__Fk_us__2E4BB670` FOREIGN KEY (`Fk_user_group_id`) REFERENCES `wtms_user_group_hdr` (`user_group_id`),
  CONSTRAINT `wtms_user_group_details_ibfk_1` FOREIGN KEY (`fk_menu_id`) REFERENCES `wtms_tbl_Menu` (`Pk_Menu_Id`),
  CONSTRAINT `wtms_user_group_details_ibfk_2` FOREIGN KEY (`Fk_user_group_id`) REFERENCES `wtms_user_group_hdr` (`user_group_id`)
) ENGINE=InnoDB AUTO_INCREMENT=209 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wtms_user_group_hdr`
--

DROP TABLE IF EXISTS `wtms_user_group_hdr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wtms_user_group_hdr` (
  `user_group_id` int NOT NULL AUTO_INCREMENT,
  `Fk_role_id` int DEFAULT NULL,
  `fk_group_id` int DEFAULT NULL,
  `user_group_name` varchar(25) DEFAULT NULL,
  `status` int DEFAULT '1',
  `create_date` datetime(3) DEFAULT NULL,
  `created_by` varchar(10) DEFAULT NULL,
  `modify_date` datetime(3) DEFAULT NULL,
  `modify_by` varchar(10) DEFAULT NULL,
  `approve_1` int DEFAULT NULL,
  `approve_2` int DEFAULT NULL,
  PRIMARY KEY (`user_group_id`),
  KEY `FK__wtms_user__fk_gr__2B6F49C5Idx` (`fk_group_id`),
  KEY `FK__wtms_user__Fk_ro__2A7B258CIdx` (`Fk_role_id`),
  KEY `FK__wtms_user__user___30F318F1Idx2` (`user_group_id`),
  CONSTRAINT `FK__wtms_user__fk_gr__2B6F49C5` FOREIGN KEY (`fk_group_id`) REFERENCES `worktual_groups_master_dtl` (`group_id`),
  CONSTRAINT `FK__wtms_user__Fk_ro__2A7B258C` FOREIGN KEY (`Fk_role_id`) REFERENCES `worktual_roles_master_dtl` (`role_id`),
  CONSTRAINT `wtms_user_group_hdr_ibfk_1` FOREIGN KEY (`fk_group_id`) REFERENCES `worktual_groups_master_dtl` (`group_id`),
  CONSTRAINT `wtms_user_group_hdr_ibfk_2` FOREIGN KEY (`Fk_role_id`) REFERENCES `worktual_roles_master_dtl` (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wtms_user_master_dtl`
--

DROP TABLE IF EXISTS `wtms_user_master_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wtms_user_master_dtl` (
  `userid` int NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) DEFAULT NULL,
  `lastname` varchar(150) DEFAULT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(60) DEFAULT NULL,
  `user_role` int DEFAULT NULL,
  `user_group` int DEFAULT NULL,
  `user_group_name` int DEFAULT NULL,
  `status` int DEFAULT NULL,
  `create_date` datetime(3) DEFAULT NULL,
  `modify_date` datetime(3) DEFAULT NULL,
  `created_by` varchar(50) DEFAULT NULL,
  `last_login_ip` varchar(100) DEFAULT NULL,
  `last_login_date` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`username`),
  UNIQUE KEY `userid` (`userid`),
  KEY `FK__wtms_user__user___1FFD9719Idx` (`user_group`),
  KEY `FK__wtms_user__user___1F0972E0Idx` (`user_role`),
  KEY `FK__wtms_user__user___30F318F1Idx` (`user_group_name`),
  CONSTRAINT `FK__wtms_user__user___1F0972E0` FOREIGN KEY (`user_role`) REFERENCES `worktual_roles_master_dtl` (`role_id`),
  CONSTRAINT `FK__wtms_user__user___1FFD9719` FOREIGN KEY (`user_group`) REFERENCES `worktual_groups_master_dtl` (`group_id`),
  CONSTRAINT `FK__wtms_user__user___30F318F1` FOREIGN KEY (`user_group_name`) REFERENCES `wtms_user_group_hdr` (`user_group_id`),
  CONSTRAINT `wtms_user_master_dtl_ibfk_1` FOREIGN KEY (`user_role`) REFERENCES `worktual_roles_master_dtl` (`role_id`),
  CONSTRAINT `wtms_user_master_dtl_ibfk_2` FOREIGN KEY (`user_group`) REFERENCES `worktual_groups_master_dtl` (`group_id`),
  CONSTRAINT `wtms_user_master_dtl_ibfk_3` FOREIGN KEY (`user_group_name`) REFERENCES `wtms_user_group_hdr` (`user_group_id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping events for database 'wtms'
--

--
-- Dumping routines for database 'wtms'
--
/*!50003 DROP FUNCTION IF EXISTS `getmapfieldlist` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` FUNCTION `getmapfieldlist`(feature_id INT) RETURNS longtext CHARSET utf8mb4
    DETERMINISTIC
BEGIN
 	
    DECLARE feature_idx longtext; 
 	
 
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select Distinct group_CONCAT(IFNULL(a.`value`,'')) INTO feature_idx from wtms_feature_field_map_details a 
       where a.fk_feature_id = feature_id;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 
    return feature_idx;
 	
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `getplan_summarynotes` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` FUNCTION `getplan_summarynotes`(
 	plan_id INT
 ) RETURNS longtext CHARSET utf8mb4
    DETERMINISTIC
BEGIN
    
       DECLARE v_feature_idx LONGTEXT;   
       
       set v_feature_idx = '';  
      
       SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
       select group_concat(summary_name) INTO v_feature_idx 
       from(select Distinct b.summary_name from  wtms.wtms_tier_summary_map a join wtms.wtms_tier_summaries_master_dtl b on a.summary_id = b.summary_id
       where a.fk_tier_id = plan_id and b.summary_status = 1) pc;
       SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
    
      
       
       return v_feature_idx;  
       
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `getprodsubprodlist` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` FUNCTION `getprodsubprodlist`(tierid INT,type INT) RETURNS longtext CHARSET utf8mb4
    DETERMINISTIC
Begin
 
 
    DECLARE v_feature_idx VARCHAR(250); 
 
 
    if type = 1 then 
 	
       SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        select Distinct group_CONCAT(IFNULL(b.prod_name,'')) INTO v_feature_idx from wtms_tier_sub_product_master a 
          join product_master b  on a.fk_prod_id = b.prod_id where a.fk_tier_id = tierid and b.prod_status = 1 ;
       SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
    end if;
 	
 
    if type = 2 then  
 	
       SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
       select Distinct group_CONCAT(IFNULL(b.category_name,''))  into v_feature_idx from wtms_tier_sub_product_master a 
          join product_category_master b  on a.fk_prod_id = b.fk_prod_id and a.fk_sub_prod_id = b.catg_id
          where a.fk_tier_id = tierid and b.category_status = 1;
       SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
    end if;
 	
    return v_feature_idx;
 
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `getsummarylist` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` FUNCTION `getsummarylist`(
	tierid INT, type int
) RETURNS text CHARSET utf8mb4
    DETERMINISTIC
Begin

		DECLARE v_feature_idx text; 
        
        SET SESSION group_concat_max_len = 1000000;
        
          if type = 1 then
                SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
  				select Distinct group_CONCAT(IFNULL(c.summary_id,'') ORDER BY b.position asc SEPARATOR '|') INTO v_feature_idx 
  				from wtms_tier_management a 
  				left join wtms_tier_summary_map b on a.tier_id = b.fk_tier_id
  				left join wtms_tier_summaries_master_dtl c on b.summary_id=c.summary_id
 				
  				where (a.tier_id = tierid)
                  order by b.position;
                SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
            end if;
            if type = 2 then
                 SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   				
                   
   				select GROUP_CONCAT(DISTINCT c.summary_name ORDER BY b.position asc SEPARATOR '|')  INTO v_feature_idx 
   				from wtms_tier_summaries_master_dtl c 
   				left join wtms_tier_summary_map b on b.summary_id=c.summary_id 
   				left join wtms_tier_management a on a.tier_id = b.fk_tier_id
   				
   				where (a.tier_id = tierid)
 				order by b.position;
                       
                SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
      		end if;
              if type = 3 then
                 SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
  					select group_CONCAT(IFNULL(c.summary_desc,'') ORDER BY b.position asc SEPARATOR '|') INTO v_feature_idx 
  					from wtms_tier_management a 
  					left join wtms_tier_summary_map b on a.tier_id = b.fk_tier_id
  					left join wtms_tier_summaries_master_dtl c on b.summary_id=c.summary_id
                     
  					where (a.tier_id = tierid) order by b.position;
                SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
      		end if;
             if type = 4 then
                 SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
                 select Distinct group_CONCAT(IFNULL(c.summary_url,'') SEPARATOR '|') INTO v_feature_idx 
                 from wtms_tier_management a 
        		left join wtms_tier_summary_map b on a.tier_id = b.fk_tier_id
        		left join wtms_tier_summaries_master_dtl c on b.summary_id=c.summary_id
                where (a.tier_id = tierid);
                SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
      		end if;
             
        
             return v_feature_idx;
          
          End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetCallLogReport` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `GetCallLogReport`(
     IN param_ext INT,
     IN param_sipId INT
 )
BEGIN
     SELECT s_no, ext, sipId, LogDetails
     FROM call_Logs_Reports
     WHERE ext = param_ext AND sipId = param_sipId;
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `InsertCallLogReport` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `InsertCallLogReport`(
     IN param_ext INT,
     IN param_sipId INT,
     IN param_LogDetails JSON
 )
BEGIN
     INSERT INTO call_Logs_Reports (ext, sipId, LogDetails)
     VALUES (param_ext, param_sipId, param_LogDetails);
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sip_pbx_new_get_extension_info_newsss` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sip_pbx_new_get_extension_info_newsss`(  
 	cli varchar(20),  
 	did varchar(40),   
     domain_name varchar(160)
 )
begin
                      
 			declare v_domain_id int;   
 			declare v_extn_found int;  
 			declare v_errcode int;  
 			declare v_errmsg varchar(250); 
 			declare v_is_callq_extn int;   
 			declare v_is_hunt_group int;   
 			declare v_is_conference int;  
 			declare v_is_directory_enable int;   
 			declare v_call_return int;  
 			declare v_find_follow_me_no varchar(20);  
 			declare v_now datetime(3);   
 
 			
 			declare v_is_swith_board int;  
 			declare v_switch_auto_rouing int;  
 			declare v_switcboardid int;  
 			declare v_swb_domainid int;      
 			declare v_is_customer_support int;   
 			declare v_is_voicemail int;   
 			declare v_is_internal_found int;      
 
 			declare v_Hunt_group_domainid int;   
 			declare v_huntgroupno varchar(50);  
 
 			declare v_mobileno_out varchar(20);   
 			declare v_company_id int;      
 
 			declare v_is_direct_call_status int;  
 			declare v_is_direct_call_preq int;   
 			declare v_is_direct_call_pin varchar(50);  
 			declare v_legA_deskphone_Status int;  
 			declare v_legb_deskphone_status int;     
 
 			declare v_block_type int;   
 			declare v_blocked_no_ivr varchar(250);  
 			declare v_is_blocked_number int;     
 
 			declare v_switch_board varchar(20);     
 			declare v_caller_id varchar(20);     
 			declare v_on_demand_rec int;   
 			declare v_always_active_rec int;      
 			declare v_always_active_rec_cli int;      
 			declare v_ondemand_rec_start_ivr varchar(250);  
 			declare v_ondemand_rec_stop_ivr varchar(250);     
 			declare v_call_rec_out_cli int;   
 			declare v_call_rec_out_ddi int;   
 
 			
 			declare v_user_greeting_file varchar(150);  
 			declare v_user_call_screening_type int;   
 			declare v_ddi_user_hold_music varchar(150);  
 			declare v_cli_user_hold_music varchar(150);  
 
 			
 			declare v_after_user_greeting_file varchar(150);  
 			declare v_call_screening_type int;   
 			declare v_connecting_ivr varchar(250);  
 
 			
 			declare v_company_hour int;  
 			declare v_company_date_format time(0);  
 			declare v_Working_Business_Type int;      
 			declare v_audio_connecting_Type int;   
 			declare v_audio_connecting_file varchar(250);     
 
 			
 			declare v_ddi_user_hold_music_type int;  
 			declare v_cli_user_hold_music_type int;  
 			declare v_eb_id int;  
 			declare v_did_ext varchar(20);     
 
 			declare v_cli_user_VideoGreeting varchar(250);  
 			declare v_did_user_videoGreeting varchar(250);      
 
 			declare v_conference_number varchar(20);  
 			declare v_host_code int;  
 			declare v_partipation_code int;  
 			declare v_is_emergency int;    
 
 			declare v_is_voicemail_cli int;  
 			declare v_is_voicemail_did int;  
 			declare v_voicemail_pin varchar(10);    
 
 			declare v_vm_password_need int;    
 
 			declare v_basket_id int;  
 			declare v_did_number_check longtext;  
 			declare v_user_type int;  
 			declare v_freetrial_exp int;      
 
 			declare v_block_outboundcall int;   
 			declare v_is_ivr_conf int;      
 
 			declare v_cli_display varchar(50);     
 			declare v_did_input varchar(20);     
 			declare v_is_block_incomming int;   
 			declare v_is_block_outgoing int;      
 			declare v_domainid_input int;   
 
 			DECLARE v_is_cli_stt_enabled int;  
 			DECLARE v_is_ddi_stt_enabled int ;  
 			DECLARE v_is_cli_ondemand_stt_enable int ;  
 			DECLARE v_is_ddi_ondemand_stt_enabled int ;  
 			DECLARE v_is_transcript_enabled int;  
 
 			declare v_is_call_park int default 0;   
 			declare v_externalnb_domain_id int;   
 			declare v_externalnb_domainname varchar(250);  
 			declare v_extension_password varchar(250);  
 			declare v_plan_expired int;   
 			declare v_plan_id int;   
 			declare v_duration int;     
 			declare v_is_publish int;   
 			declare v_is_pstn_route int;   
 			declare v_ondemand_call_rec_out_cli int;  
 			declare v_ondemand_call_rec_out_did int;       
 			declare v_translation_enabled int;   
 			declare v_is_audio_ondemand int;   
 			declare v_is_audio_automatic int;  
 			declare v_is_audio_transcript_enabled int;   
 			declare v_Is_chatbot_ddi int;     
 			declare v_is_ccaas int; 
 			declare v_cli_username longtext;
 
 			declare v_cliextn_num int;
 			declare v_didextn_num int;
 			declare v_cli_is_blocked_number int;
 			declare v_ddi_is_blocked_number int;
 
                      sp_exit : BEGIN  
                   
                    if left(did,1)='00' and char_length(rtrim(did))>8 
                    then  
                     set did=insert(did,1,2,'44');
                    end if;  
                      
                    if left(did,1)='0' and char_length(rtrim(did))>8 
                    then  
                     set did=insert(did,1,1,'44');
                    end if; 
                      
                    set v_did_input=did;          
                    set v_extn_found=0;     
                    set v_errcode=-1;  
                    set v_errmsg='';  
                    set v_is_hunt_group=0;  
                    set v_is_conference=0;  
                    set v_is_directory_enable=0;  
                    set v_call_return=0;  
                    set v_now=now(3);  
                    set v_is_swith_board=0;  
                    set v_is_internal_found=1;  
                    set v_always_active_rec=0;  
                    set v_on_demand_rec=0;  
                    set v_call_rec_out_cli=0;  
                    set v_call_rec_out_ddi=0;  
                    set v_is_emergency=0;  
                    set v_freetrial_exp=0;     
                    set v_company_date_format=cast(now(3) as time(0));     
                    set cli = replace(cli,'+','');     
                    set v_cli_display=cli;  
                     
                      
                    
                    select id,id into v_domain_id, v_domainid_input from dir_domains a
                    where a.domain_name=domain_name  limit 1;
                      
                    
                    select 1 into v_is_emergency from sip_emer_num_config
                    where number=did  limit 1; 
                      
                    select company_id into v_company_id from vbcp_pbx_account
                    where domain_id=v_domain_id limit 1;  
                      
                    if v_is_emergency=1 
                    then  
                     leave sp_exit;
                    end if; 
                       
                    
                    IF EXISTS(SELECT 1 FROM pbx_call_park_group a 
                    where domain_id=v_domain_id  
                    and park_id=did LIMIT 1 )  
                   THEN
                    
                     set v_is_call_park = 1;   
                    
                   END IF; 
                      
                     
                    IF domain_name = '' OR IFNULL(v_domain_id,0)=0  
                    THEN  
                       
                     
                     select a.domain_id into v_domain_id  from dir_users a
                     join did c  on a.id=c.svc_id    
                        where c.did_number=did  limit 1;
                               
                        IF v_domain_id is null or v_domain_id = ''  
                        Then     
                      select a.domain_id into v_domain_id  
                      from vbcp_pbx_account  a 
                      join UR_ECom_User_Extension_Dtl b  on a.company_id = b.company_id  
                      where a.conference_number = did limit 1; 
                             
                      if ifnull(v_domain_id,0)=0  
                      then  
                            
                       select b.domain_id into v_domain_id from UR_phone_add_number_order_dtl a   
                       join UR_phone_add_number_order b on  a.order_id=b.order_id   
                       where a.external_number=did limit 1;  
                         
                      end if;  
                        
                     End if;  
                          
                     
                     select a.domain_name into domain_name from dir_domains a
                     where id= v_domain_id  limit 1;  
                       
                    END IF;  
                     
                    If v_domain_id = '' or v_domain_id is null  
                    Then  
                     set v_errcode=-1;  
                     set v_errmsg='Domain Name is Invalid!!';  
                     leave sp_exit;  
                    End if;  
                      
                      
 						if char_length(RTRIM(cli))>3 then
 							select user_id into v_cliextn_num from unifiedring.dir_users where did_number = cli and domain_id = v_domain_id;
 						End if;
 
 						select 1 into v_cli_is_blocked_number from UR_ECom_User_Extension_Dtl where Company_id = v_company_id and (Extension_number = cli or Extension_number = ifnull(v_cliextn_num,0)) and Status = 0;
 
 						if v_cli_is_blocked_number = 1 then
 							set v_block_type = 1;
 							set v_is_blocked_number = 1;
 						end if;
 
 						if char_length(RTRIM(did))>3 then
 							select user_id into v_didextn_num from unifiedring.dir_users where did_number = did and domain_id = v_domain_id;
 						End if;
 
 						select 1 into v_ddi_is_blocked_number from UR_ECom_User_Extension_Dtl where Company_Id = v_company_id  and (Extension_number = did or Extension_number = ifnull(v_didextn_num,0)) and Status = 0;
 
 						if v_ddi_is_blocked_number = 1 then
 							set v_block_type = 2;
 							set v_is_blocked_number = 1;
 						end if;
                  
                  
               
                     
                    
                    select 1 into v_is_directory_enable from ur_dialby_directory_setting
                    where domain_id=v_domain_id and dir_enable=1  limit 1;   
                       
                    select company_id into v_company_id from vbcp_pbx_account
                    where domain_id=v_domain_id    limit 1;  
                      
                    
                    
                     select plan_id,plan_duration into v_plan_id, v_duration from ur_company_plan
                     where company_id=v_company_id  limit 1;	  
                      
                    IF IFNULL(v_is_directory_enable,0)=1 and ifnull(v_plan_id,0)>0  
                    THEN        
                         
					IF NOT EXISTS(SELECT 1 FROM  UR_ECom_Plan_Feature_Dtl a join UR_ECom_Plan_Feature b on a.PFD_Feature=b.PF_Idx  where PFD_Plan=v_plan_id and PFD_Duration=v_duration AND b.PF_Idx in(226) LIMIT 1)THEN  
                    

                     
                      SET v_is_directory_enable=0;  
                     
                    END IF;  
                   END IF;

                    
                    IF IFNULL(v_is_call_park,0)=1  THEN  
                    
                     
                     IF NOT EXISTS(select 1 from wtms_feature_info a join wtms_tier_feature_mapping_xml b on a.feature_id = b.featureid where a.feature_name ='call park' and b.tier_id = v_plan_id limit 1)THEN  
                      
                       SET v_is_call_park=0;  
                      
                    END IF;  
                    END IF;

                    
                      
                    set v_plan_expired=0;  
                       
                    select Status,callerid_number into v_legA_deskphone_Status, v_caller_id    
                    from UR_ECom_User_Extension_Dtl
                    where Company_id=v_company_id and Extension_Number=cli  limit 1;   
                    
                    
                    
                    select  1 into v_freetrial_exp from ur_company_plan
                    where    ifnull(Is_free_trail,0)=1 and company_id=v_company_id  
                    and plan_end_date<=now(3) and plan_end_date is not null  
                    order by cp_id desc  
                    limit 1;
                              
                    IF IFNULL(v_freetrial_exp,0)=1 
                    THEN   
                     SET v_legA_deskphone_Status=0;
                    END IF;  
                     
                    
                   
                    select 1 into v_plan_expired from ur_company_plan where suspend_date is not  null  
                    and company_id=v_company_id and status=0  
                    and  plan_end_date<=now(3)
                    limit 1;  
                     
                    if ifnull(v_plan_expired,0)=1 and ifnull(v_freetrial_exp,0)=0  
                    then  
                     set v_legA_deskphone_Status=0;  
                     set v_freetrial_exp=1;  
                   end if;  
                     
                    if ifnull(v_legA_deskphone_Status,0)<>1 and char_length(rtrim(cli))=3  
                    then  
                     set v_errcode=-1;  
                     set v_errmsg='LEGA Deskphone is not active.';  
                     leave sp_exit;   
                    end if;  
                         
                    if ifnull(v_caller_id,'')='' or v_caller_id = ''
                    then  
                     set v_caller_id=v_switch_board;
                    end if;  
                      
                    
                        
                     select  landline_number into v_switch_board from vbcp_landline_pool
                     where allocation_type=1 and allocation_id=v_company_id  limit 1;   
                     
   				if IFNULL(v_caller_id,'') = '' 
   				then
   
   				SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   					select external_number INTO v_caller_id from UR_phone_add_number_order_dtl a
   					join  UR_phone_add_number_order b  on a.order_id = b.order_id where company_id = v_company_id and assign_type = 7 
   					and a.extension = cli order by assign_date asc LIMIT 1;
   				SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   				end if;  
   
       			if ifnull(v_caller_id,'')='' or v_caller_id = ''
                    then  
                    
                    select switch_board_no into v_switch_board from vbcp_pbx_account where company_id = v_company_id limit 1;
                     set v_caller_id=v_switch_board;
                    end if;  
                      
                    IF char_length(rtrim(cli)) > 4  
                    THEN   
                       
                     select user_id,user_id into v_mobileno_out, v_did_ext from dir_users a
                       join did c  on a.id=c.svc_id    
                         where c.did_number=cli  and a.domain_id=v_domain_id  limit 1;   
                       
                       
                                 
                       
                     if v_is_swith_board=1  
                     then  
                      set v_errcode=0;  
                      set v_errmsg='Switch board Number found!';  
                      leave sp_exit;   
                     end if;  
                       
                     
                     
                     
                     
                       
                     
                     
                     
                     
                     
                     
                       
                        
                      if ifnull(v_mobileno_out,'')=''  
                      then  
                       
                       select Extension_Number into v_mobileno_out from UR_ECom_User_Extension_Dtl
                       where company_id=v_company_id and mobileno=cli and ifnull(is_mapped,0)=1   limit 1;     
                      end if;  
                       
                    END IF;     
                      
                     
                      
                      
                      
                     if char_length(rtrim(cli))>4  
                     Then  
                      select a.conference_number into v_conference_number   
                      from vbcp_pbx_account a
                      join UR_ECom_User_Extension_Dtl b  on a.company_id = b.company_id  
                      where a.domain_id = v_domain_id limit 1;  
                     Else  
                      
                      select a.conference_number,  
                        b.host_code,  
                        b.partipation_code, 
                        concat(replace(Firstname,' ','_'),'_',replace(surname,' ','_'))
                        into v_conference_number, v_host_code, v_partipation_code, v_cli_username   
                      from vbcp_pbx_account  a join UR_ECom_User_Extension_Dtl b  on a.company_id = b.company_id  
                      where b.Extension_Number = cli and a.domain_id = v_domain_id limit 1;  
                     END IF;  
                         
                     If did = v_conference_number  
                     Then  
                      set v_is_conference = 1;  
                     else  
                      set v_is_conference = 0;  
                     End if;   
                       
                     if ifnull(v_is_conference,0)=0  
                     then  
                       
                      Select 1 Into v_is_conference from UR_phone_add_number_order_dtl
                      where external_number=did and assign_type=9 limit 1;  
                       
                     end if;  
                     
                       
                     if v_is_conference=1   
                     then  
                      set v_errcode=0;  
                      set v_errmsg='Conference Number found!';  
                       leave sp_exit;   
                     end if;  
                      
                     
                      
                    if char_length(rtrim(did))>4  
                    then       
                         
                     select user_id,a.domain_id,  
                     password into v_mobileno_out, v_externalnb_domain_id, v_extension_password from dir_users a
                     join did c  on a.id=c.svc_id    
                        where c.did_number=did  and a.domain_id=v_domain_id  limit 1;
                          
                        if ifnull(v_externalnb_domain_id,0)>0  
                        then  
                      
                      select a.domain_name into v_externalnb_domainname from dir_domains a 
                      where id=v_externalnb_domain_id limit 1;   
                        end if;        
                       
                       
                     select  1,ifnull(d.auto_routing,0),  
                     ifnull(a.switchboard_reg_idx,0),ifnull(a.domain_id,'') into v_is_swith_board, v_switch_auto_rouing, v_switcboardid, v_swb_domainid   
                     from vbcp_switchboard_mapping a
                     join vt_account_features b  on a.company_id = b.company_id and a.switchboard_reg_idx=b.switchboard_reg_id   
                     Left Join did d On d.svc_id = a.dir_user_id And d.did_number = a.dialnumber  
                     where (a.dialnumber=did)  
                     and b.feature_code = 'IVRSWICTHBOARD' and b.feature_status <> 'INACTIVE'  
                     limit 1; 
                       
                     if v_is_swith_board=1  
                     then  
                      set v_errcode=0;  
                      set v_errmsg='Switch board Number found!';  
                      leave sp_exit;   
                     end if;      
                        
                      if ifnull(v_mobileno_out,'')=''  
                      then  
                       
                       select Extension_Number into v_mobileno_out from UR_ECom_User_Extension_Dtl
                       where company_id=v_company_id and mobileno=did and ifnull(is_mapped,0)=1   
                       limit 1;     
                      end if;  
                       
                    end if;         
                    
                    
                    
                    select 1 into v_is_customer_support  from services a 
                    join did_cs_number b on a.id=b.service_id  
                    where a.application='customer_support'  
                    and (a.extension=did or b.did=did)  limit 1;
                         
                    if v_is_customer_support=1  
                    then  
                     set v_errcode=0;  
                     set v_errmsg='Customer Support Number found!';  
                     leave sp_exit;   
                    end if;  
                      
                     
                    
                    select 1 into v_is_voicemail from voicemail_routing_number
                    where routing_number=did limit 1;   
                      
                    if v_is_voicemail=1  
                    then  
                     set v_errcode=0;  
                     set v_errmsg='Voicemail Support Number found!';  
                     leave sp_exit;   
                    end if;     
                      
                      select 1 into v_always_active_rec_cli from ur_direct_call_voicemail_config
                      where domain_id=v_domain_id and CAST(extension AS CHAR)=cli and call_type='CALLRECORD'  
                      and is_enable=1  limit 1;               
                   
                      select 1 into v_is_voicemail_cli from ur_direct_call_voicemail_config
                      where domain_id=v_domain_id and CAST(extension AS CHAR)=cli and call_type='voicemail'  
                      and is_enable=1 limit 1;      
                        
                      set v_call_rec_out_cli=case when v_on_demand_rec=0 and v_always_active_rec_cli=0 then 0  
                           when v_on_demand_rec=0 and v_always_active_rec_cli=1 then 1  
                           when v_on_demand_rec=1 and v_always_active_rec_cli=0 then 2  
                           when v_on_demand_rec=1 and v_always_active_rec_cli=1 then 3 else 0 end;   
                       
                    
                     IF v_is_voicemail_cli=1 and ifnull(v_plan_id,0)>0  
                     then  
                       
                     IF NOT EXISTS(SELECT 1 FROM  UR_ECom_Plan_Feature_Dtl a
                   join UR_ECom_Plan_Feature b on a.PFD_Feature=b.PF_Idx  where PFD_Plan=v_plan_id  
                     and PFD_Duration=v_duration AND b.PF_Idx in(213) LIMIT 1)  
                    THEN  
                     
                     BEGIN  
                      SET v_is_directory_enable=0;  
                     END;  
                      END IF;
                   end if;  
                       
                      select 1,  replace(announcement_start,'audio/',''),  
                       replace(announcement_stop,'audio/','') into v_on_demand_rec, v_ondemand_rec_start_ivr, v_ondemand_rec_stop_ivr   
                      from UR_Call_Recording_Config
                      where Company_Id=v_company_id and rec_status=1   
                      and Type=1  
                      limit 1;            
                        
                      IF v_on_demand_rec=1 and ifnull(v_plan_id,0)>0  
                      THEN  
                         
                     
                       
        			IF NOT EXISTS(select 1 from wtms.wtms_feature_info a join wtms.wtms_feature_category b on a.fk_category_id = b.category_id join wtms.wtms_tier_feature_mapping_xml c on c.featureid = a.feature_id
            		where c.tier_id = v_plan_id and a.feature_name='Call Recording' limit 1)  THEN 
                       BEGIN  
                        SET v_on_demand_rec=0;  
                        SET v_ondemand_rec_start_ivr=NULL;  
                        SET v_ondemand_rec_stop_ivr=NULL;  
                       END;  
                     
                       END IF;  
                     END IF;      
                      
                    IF CHAR_LENGTH(RTRIM(did))=3  
                    THEN  
                      
                     set v_is_hunt_group=0;  
                      
                     
                     
                     
                     
                       
                     
                     
                     
                     
                     
                     
                   
                     select Status into v_legb_deskphone_status from UR_ECom_User_Extension_Dtl
                     where Company_id=v_company_id and Extension_Number=did  limit 1;   
                       
                     if ifnull(v_legb_deskphone_status,0)<>1  
                     then  
                      set v_errcode=-1;  
                      set v_errmsg='LEGB Deskphone is not active.';  
                      leave sp_exit;   
                     end if;  
                       
                     select 1,CAST(IFNULL(call_return_sts,0) AS char),0 into v_extn_found, v_call_return, v_is_internal_found  
                     from dir_users where user_id=did and domain_id=v_domain_id  limit 1;          
                       
                     
                     if v_extn_found=0  
                     then  
                         
                       
                       select 1 into v_extn_found from services   
                       where domain_id=v_domain_id and extension=did
                       limit 1;    	
                         
                       if v_extn_found=0  
                       then  
                        
                        select 1 into v_extn_found from services     
                        where  extension=did and  (application like'cus%' OR application IN('Emergency_number'))
                        limit 1;  
                     
                       end if;  
                         
                     end if;  
                         
                     if v_extn_found=1  
                     then  
                      set v_errcode=0;  
                      set v_errmsg='Extension is Valid!!!';  
                     end if;  
                          
                     select mobileno into v_mobileno_out from UR_ECom_User_Extension_Dtl
                     where company_id=v_company_id and Extension_Number=did and ifnull(is_mapped,0)=1 limit 1;  
                         
                     
                     
                     SELECT mobileno INTO v_find_follow_me_no FROM   ur_extn_find_flow_me
                     WHERE  domain_id = v_domain_id   
                     AND extension = did   
                     and v_now between schedule_from and  schedule_to  
                     and status=1  
                     order by id desc  
                     LIMIT 1;   
                         
                     
                       
                       
                     select is_enable,is_pin_req,pin into v_is_direct_call_status, v_is_direct_call_preq, v_is_direct_call_pin   
                     from ur_direct_call_voicemail_config
                     where domain_id=v_domain_id and extension=did and call_type='DIRECTCALL'  limit 1;   
                             
                     select block_type,replace(block_ivr_file,'audio/','') into v_block_type, v_blocked_no_ivr   
                     from ur_user_extn_block a
                     join ur_user_extn_block_number b on a.eb_id=b.eb_id  
                     where  domain_id=v_domain_id and extension=did limit 1;                 
                      
                      select 1 into v_always_active_rec from ur_direct_call_voicemail_config
                      where domain_id=v_domain_id and extension=did and call_type='CALLRECORD'  
                      and is_enable=1   limit 1; 
                     
                      select ifnull(pin,''),  
                      ifnull(is_pin_req,0) into v_voicemail_pin, v_vm_password_need  
                      from ur_direct_call_voicemail_config
                      where domain_id=v_domain_id and extension=did and call_type='Voicemail'  
                      and is_enable=1 limit 1;    
                        
                      set v_call_rec_out_ddi=case when v_on_demand_rec=0 and v_always_active_rec=0 then 0  
                           when v_on_demand_rec=0 and v_always_active_rec=1 then 1  
                           when v_on_demand_rec=1 and v_always_active_rec=0 then 2  
                           when v_on_demand_rec=1 and v_always_active_rec=1 then 3 else 0 end;   
                   
                     
                     call  sip_pbx_extension_check_voicemail( v_domain_id,did,v_company_id,v_is_voicemail_did);   
                   
                     call sip_pbx_extension_check_voicemail( v_domain_id,cli,v_company_id,v_is_voicemail_cli);    
                   
                     
                     
                     select replace(audio_file,'audio/','') into v_user_greeting_file   
                     from UR_IVR_extention_audio_file f
                     where company_id=v_company_id and extension=did and hour_type=1  
                     and ivr_type='USERGREETING' and active=1  limit 1;      
                     
                     select replace(audio_file,'audio/','') into v_after_user_greeting_file  
                     from UR_IVR_extention_audio_file
                     where company_id=v_company_id and extension=did and hour_type=2  
                     and ivr_type='USERGREETING' and active=1 limit 1;           
                     
                     
                     
                     select call_screening_type into v_user_call_screening_type from UR_IVR_extention_audio_file f
                     where company_id=v_company_id and extension=did and hour_type=1  
                     and ivr_type='CALLSCREENING' and active=1 limit 1;      
                       
                     
                     select  case when Greeting_by=2 and active=1 then CONCAT(MT_Name,'.wav')   
                     when Greeting_by=3 and active=1  then replace(audio_file,'audio/','') else Audio_file end,  
                     ifnull(Greeting_by,0) into v_ddi_user_hold_music, v_ddi_user_hold_music_type  
                     from UR_IVR_extention_audio_file f
                     left outer join UR_IVR_music_type m on f.Music_type=m.MT_ID  
                     where company_id=v_company_id and extension=did and hour_type=1  
                     and ivr_type='HOLDMUSIC'  limit 1;  
                       
                     
                     select  case when Greeting_by=2 and active=1 then CONCAT(MT_Name,'.wav')   
                     when Greeting_by=3 and active=1  then replace(audio_file,'audio/','') else Audio_file end,  
                     ifnull(Greeting_by,0) into v_cli_user_hold_music, v_cli_user_hold_music_type  
                     from UR_IVR_extention_audio_file f
                     left outer join UR_IVR_music_type m on f.Music_type=m.MT_ID  
                     where company_id=v_company_id and cast(extension as char)=cli and hour_type=1  
                     and ivr_type='HOLDMUSIC'  limit 1;      
                       
                     
                     select case Working_Business_Type when 'Custom hours' then 1  
                     when '24 hours/7 days a week' then 0 End into v_Working_Business_Type  
                     from UR_Company_Working_Hours c
                     left outer join UR_Working_Week w on c.CW_ID=w.CW_ID  
                     where company_id=v_company_id and Extension_Number=did limit 1;  
                       
                     
                     select case when v_company_date_format between From_time and To_time then 1   
                     when Hour_Format=24 then 0 else 1 end into v_company_hour  
                     from UR_Company_Working_Hours c
                     left outer join UR_Working_Week w on c.CW_ID=w.CW_ID  
                     where company_id=v_company_id and Extension_Number=did and working_day=dayname(now(3)) limit 1;      
                       
                     if  v_Working_Business_Type=0 
                     then   
                      set v_company_hour=1;
                     end if;    
                        
                     
                     
                     select call_screening_type into v_call_screening_type from UR_IVR_extention_audio_file f
                     where company_id=v_company_id and extension=did and hour_type=1  
                     and ivr_type='CALLSCREENING' and Active=1 limit 1;
                         
                     select replace(audio_file,'audio/','') into v_connecting_ivr  
                     from UR_IVR_extention_audio_file f
                     left outer join UR_IVR_music_type m on f.Music_type=m.MT_ID  
                     where company_id=v_company_id and extension=did and hour_type=1  
                     and ivr_type='CONNECTINGMESSAGE' and active=1  
                     limit 1;  
                       
                     
                     
                     select case when Greeting_by=2 then CONCAT(MT_Name,'.wav')   
                     when Greeting_by=3 then replace(audio_file,'audio/','') else Audio_file end,  
                     ifnull(Greeting_by,0) into v_audio_connecting_file, v_audio_connecting_Type  
                     from UR_IVR_extention_audio_file f
                     left outer join UR_IVR_music_type m on f.Music_type=m.MT_ID  
                     where company_id=v_company_id and extension=did and hour_type=1  
                     and ivr_type='AUDIOCONNECTING' and active=1  
                     limit 1;      
                       
                    END IF;  
                      
                    
                    select block_type,replace(block_ivr_file,'audio/',''),eb_id into v_block_type, v_blocked_no_ivr, v_eb_id   
                    from ur_user_extn_block
                    where domain_id=v_domain_id and CAST(extension AS CHAR)=cli limit 1;  
                     
                    if exists (select 1 from ur_user_extn_block_number where eb_id=v_eb_id and number=did limit 1)  
                    then  
                    
                     set v_is_blocked_number=1;  
                    
                    end if;
                    
                    select 1 into v_is_ivr_conf from ivr_site_config
                    where company_id=v_company_id and   
                    ((ifnull(extension_no,'')=did) or (ifnull(external_number,'')=did)) limit 1;        
                      
                    if exists(select 1 from block_did a where a.did=replace(did,'+','') and status=1 limit 1)  
                    then 
                    
                     SET v_block_outboundcall=1;  
                    
                    end if;
                    
                    set v_ondemand_call_rec_out_cli=v_on_demand_rec;     
                    set v_ondemand_call_rec_out_did=v_on_demand_rec;  
                       
                    call  sip_pbx_check_auto_call_recording_type( v_company_id,did,cli,v_always_active_rec_cli,v_always_active_rec); 
                     
                        
                   end sp_exit;  
                     
                   
                     call sip_pbx_check_extension_user_type(cli,v_domain_id,v_user_type,v_block_outboundcall);  
                    
                      
                    if exists(select 1 from pbx_call_park_group_public where park_status = 1  
                     and domain_id = v_domain_id and park_id = did limit 1)  
                    Then    
                     set v_is_call_park = 1;  
                    End if;     
                    
                    set  v_is_pstn_route=0;  
                      
                    
                    if char_length(rtrim(v_did_input))>9  
                    then  
                     call sip_pbx_check_validate_pstn_routing( v_did_input,v_domain_id,v_is_pstn_route);
                    end if;  
                         
                    if CHAR_LENGTH(RTRIM(cli))>8  
                    THEN  
                     
                     select insert(cli,1,char_length(rtrim(prefix)),xlat_prefix) into v_cli_display from xlat_number 
                     where  prefix=LEFT(cli,char_length(rtrim(prefix))) limit 1;  
                    END IF;  
                        
                      IF IFNULL(v_cli_display,'')=''  
                      THEN  
                        SET v_cli_display=cli;  
                      END IF;  
                        
                      IF CHAR_LENGTH(RTRIM(cli))>5 and ifnull(v_always_active_rec_cli,0)=1 
                      THEN   
                         set v_always_active_rec_cli=0;
                      END IF;  
                        
                      IF CHAR_LENGTH(RTRIM(v_did_input))>5 and  ifnull(v_always_active_rec,0)=1 
                      THEN  
                        set v_always_active_rec=0;
                      END IF;  
                             
                      if ifnull(v_ondemand_call_rec_out_cli,0)=1 and CHAR_LENGTH(RTRIM(cli))>5 
                      then  
                        set v_ondemand_call_rec_out_cli=0;
                      end if;  
                       
                    if ifnull(v_ondemand_call_rec_out_did,0)=1 and CHAR_LENGTH(RTRIM(v_did_input))>5 
                    then  
                     set v_ondemand_call_rec_out_did=0;
                    end if;  
                      
                    
                    IF CHAR_LENGTH(RTRIM(did))<8  
                    THEN  
                   
                     select 1 into v_is_hunt_group from ur_hunt_group
                     where domain_id=v_domain_id and  grp_extn=did limit 1;  
                       
                    select 1 into v_is_callq_extn from ur_call_queue
                    where domain_id = v_domain_id and q_extn = did limit 1;  
                   
                      select 1 into v_is_ivr_conf from ur_multi_ivr
                      where extension=did and company_id=v_company_id  limit 1;
                      
                    END IF;  
                   
                    
                    
                    if CHAR_LENGTH(RTRIM(did))>8  
                    then  
                          
                      set v_is_publish=0;  
                      
                     select 1,grp_extn,b.domain_name,  
                     a.domain_id,b.domain_name into v_is_hunt_group, v_mobileno_out, v_externalnb_domainname, v_domain_id, domain_name  
                     from ur_hunt_group a
                     join dir_domains b on a.domain_id=b.id   
                     where a.grp_did=did  and ifnull(a.grp_did,'')<>'' limit 1;    
                     
                     if ifnull(v_domainid_input,0)<>0 and ifnull(v_is_hunt_group,0)=1 and v_domain_id<>ifnull(v_domainid_input,0) 
                     then  
                      set v_is_hunt_group=0;
                     end if;  
                     
                     select 1,q_extn,b.domain_name,  
                     a.domain_id,b.domain_name into v_is_callq_extn, v_mobileno_out, v_externalnb_domainname, v_domain_id,domain_name  
                     from ur_call_queue a
                     join dir_domains b on a.domain_id=b.id   
                     where a.q_did=did and ifnull(a.q_did,'')<>'' limit 1;  
                       
                     if ifnull(v_domainid_input,0)<>0 and ifnull(v_is_callq_extn,0)=1 and v_domain_id<>ifnull(v_domainid_input,0) 
                     then  
                      set v_is_callq_extn=0;
                     end if;  
                           
                     IF ifnull(v_is_swith_board,0)=1  
                     THEN  
                       
                      select 1,a.extension,  
                      CASE WHEN ifnull(b.Is_publsih,0)=1 THEN d.domain_name ELSE v_externalnb_domainname END,   
                      CASE WHEN ifnull(b.Is_publsih,0)=1 THEN c.domain_id  ELSE v_domain_id END,  
                      CASE WHEN ifnull(b.Is_publsih,0)=1 THEN d.domain_name ELSE domain_name END ,  
                      CASE WHEN ifnull(b.Is_publsih,0)=1 THEN c.domain_id ELSE v_externalnb_domain_id END ,'123456', ifnull(b.Is_publsih,0) 
                      into v_is_ivr_conf, v_mobileno_out, v_externalnb_domainname, v_domain_id,domain_name, 
                      v_externalnb_domain_id, v_extension_password, v_is_publish  from ur_multi_ivr a   
                      join ur_multi_ivr_didnoinfo b on a.ivr_id=b.ivr_id  
                      join vbcp_pbx_account c on a.company_id=c.company_id  
                      join dir_domains d on c.domain_id=d.id   
                      where b.did_number=did limit 1;
                        
                       ELSE  
                         
                      select 1,a.extension, d.domain_name,c.domain_id, d.domain_name,c.domain_id,'123456',ifnull(b.Is_publsih,0) 
                      into v_is_ivr_conf, v_mobileno_out, v_externalnb_domainname, v_domain_id,domain_name, v_externalnb_domain_id, 
                      v_extension_password, v_is_publish from ur_multi_ivr a   
                      join ur_multi_ivr_didnoinfo b on a.ivr_id=b.ivr_id  
                      join vbcp_pbx_account c on a.company_id=c.company_id  
                      join dir_domains d on c.domain_id=d.id   
                      where b.did_number=did limit 1;
                         
                   END IF;  
                       
                     if v_is_ivr_conf=1 and v_is_publish=1 and v_is_swith_board=1 
                     then  
                      set v_is_swith_board=0;
                     end if;  
                        
                     
                     
                     if v_is_ivr_conf=1 and ifnull(v_is_publish,0)=0 and v_is_swith_board=1 
                     then  
                      set v_is_ivr_conf=0;
                     end if;  
                     
                    end if;  
                      
                    
                    
                    if  v_is_ivr_conf=1   
                    then  
                     set v_ondemand_call_rec_out_cli=0;  
                     set v_always_active_rec=0;  
                     set v_ondemand_call_rec_out_did=0;  
                    end if;      
                       
                     set v_Is_chatbot_ddi=0;  
                      set v_is_ccaas = 0;
                      
                    select ifnull(Is_block_Incomming,0),ifnull(Is_block_outgoing,0), ifnull(Is_audio_realtime_translation,0),  
                    ifnull(audio_call_transcript_ondemand,0), ifnull(audio_call_transcript_automatic,0) 
                    into v_is_block_incomming, v_is_block_outgoing, v_translation_enabled, v_is_audio_ondemand, v_is_audio_automatic  
                    from ur_company_plan  where company_id=v_company_id limit 1;
                      
                     set v_is_audio_transcript_enabled=case when ifnull(v_is_audio_ondemand,0)=1 then 2   
                     when ifnull(v_is_audio_automatic,0)=1 then 1  else 0 end;  
                       
                     if ifnull(v_is_audio_ondemand,0)=1 and ifnull(v_is_audio_automatic,0)=1 
                     then  
                       set v_is_audio_transcript_enabled=1;
                     end if;  
                        
                        
                  select ivr_type,b.id,b.domain_name,a.domain_id,'123456' into
                   v_Is_chatbot_ddi,v_domain_id,domain_name,v_externalnb_domain_id,v_extension_password
                   from chatbot_ivr_info a
                   join dir_domains b  on a.domain_id=b.ID  
                  where did_number=did limit 1;
                        
                
                
                     
                select 1,b.id,b.domain_name,a.domain_id,'123456' into 
                v_is_ccaas,v_domain_id,domain_name,v_externalnb_domain_id,v_extension_password      
                from ccas_ivr_call_flow a
                join dir_domains b  on a.domain_id=b.ID  
                  where did_number=did limit 1;       
                     
           if v_is_ccaas=1 and char_length(cli)>5 
           then
            set v_cli_display=cli;  
            set v_cli_display=replace(v_cli_display,'+','');  
           end if; 
           
           	if v_is_swith_board = 1 then 
       		if exists(select * from ur_myacc_company_ivr_route_to_info a 
              join ur_myacc_ivr_route_to_type b on a.typeid = b.id
              where a.company_id = v_company_id and b.typename = 'IVR' limit 1) then
        			set v_is_swith_board = 0;
        			set v_is_ivr_conf = 1;
        		end if;                   
     	end if;
                     
                   select v_domain_id as domain_id,ifnull(v_is_swith_board,0) as is_swith_board,  
                   ifnull(v_switcboardid,0) as switcboardid,ifnull(v_swb_domainid,0) as swb_domainid,ifnull(v_is_directory_enable,0) as directory_enable,  
                   ifnull(v_is_hunt_group,0) as is_hunt_group,ifnull(v_find_follow_me_no,'')as find_follow_me_no,ifnull(v_is_conference,0) as is_conference,  
                   ifnull(v_is_voicemail,0) as is_voicemail,  
                   ifnull(v_is_internal_found,0) as is_internal_found,ifnull(v_Hunt_group_domainid,0) as hunt_group_domainid,  
                   ifnull(v_is_direct_call_status,0) as is_direct_call_status,ifnull(v_is_direct_call_preq,0) as is_direct_call_preq,  
                   ifnull(v_is_direct_call_pin,'') as direct_call_pin,ifnull(v_legA_deskphone_Status,0) as lega_deskphone_Status,ifnull(v_legb_deskphone_status,0) as legb_deskphone_status,  
                   ifnull(v_block_type,0) as block_type,ifnull(v_blocked_no_ivr,'') as blocked_no_ivr,ifnull(v_is_blocked_number,0) as is_block_number,  
                   ifnull(v_caller_id,'') as caller_id,ifnull(v_call_rec_out_cli,0) as call_rec_out_cli,ifnull(v_call_rec_out_ddi,0) as call_rec_out_ddi,ifnull(v_ondemand_rec_start_ivr,'') as ondemand_rec_start_ivr,  
                   ifnull(v_ondemand_rec_stop_ivr,'') as ondemand_rec_stop_ivr,ifnull(v_user_greeting_file,'') as user_greeting_file,ifnull(v_user_call_screening_type,0) as user_call_screening_type,  
                   ifnull(v_ddi_user_hold_music,'') as ddi_user_hold_music,ifnull(v_cli_user_hold_music,'') as cli_user_hold_music,ifnull(v_company_hour,0) as company_hour,  
                   ifnull(v_after_user_greeting_file,'') as user_after_greeting_file,ifnull(v_call_screening_type,0) as call_screening_type,ifnull(v_connecting_ivr,'') as connecting_ivr,  
                   ifnull(v_audio_connecting_Type,0) as audio_connecting_Type,ifnull(v_audio_connecting_file,'') as audio_connecting_file,ifnull(v_ddi_user_hold_music_type,0) as ddi_user_hold_music_type,  
                   ifnull(v_cli_user_hold_music_type,0) as cli_user_hold_music_type,ifnull(v_did_ext,'') as did_ext,ifnull(v_cli_user_VideoGreeting,'') as cli_user_VideoGreeting,  
                   ifnull(v_did_user_videoGreeting,'') as did_user_videoGreeting,  
                   ifnull(v_host_code,'') as host_code, ifnull(v_partipation_code,'') as partipation_code,ifnull(v_is_emergency,0) as is_emergency,  
                   ifnull(domain_name,'') as domain_name,ifnull(v_always_active_rec_cli,0) as cli_rec_flag,ifnull(v_always_active_rec,0) as did_rec_flag,v_errmsg as errmsg,  
                   ifnull(v_is_voicemail_did,0) as is_voicemail_did,ifnull(v_is_voicemail_cli,0) as is_voicemail_cli,ifnull(v_voicemail_pin,'') as voicemail_pin,  
                   ifnull(v_vm_password_need,0) as vm_password_need,ifnull(v_externalnb_domainname,'') as externalnb_domain_name,  
                   ifnull(v_mobileno_out,'') as externalnb_extn,ifnull(v_extension_password,'') as externalnb_extn_pwd,ifnull(v_externalnb_domain_id,0) as externalnb_domain_id,  
                   ifnull(v_user_type,'') as user_type,ifnull(v_freetrial_exp,0) as freetrial_expired,ifnull(v_block_outboundcall,0) as block_outboundcall,  
                   ifnull(v_is_ivr_conf,0) as is_ivr_configured,IFNULL(v_is_callq_extn,0) as is_callq_extn,  
                   ifnull(v_ondemand_call_rec_out_cli,0) as ondemand_cli,ifnull(v_ondemand_call_rec_out_did,0) as ondemand_did,IFNULL(v_is_call_park,0) as is_call_park,  
                   ifnull(v_is_pstn_route,0) as is_pstn_route,IFNULL(v_cli_display,'') AS cli_display,  
                   ifnull(v_is_block_incomming,0) as is_block_incomming,ifnull(v_is_block_outgoing,0) as Is_block_outgoing,  
                   ifnull(v_translation_enabled,0) as translation_enabled,
                   
                   2 as is_audio_transcript_enabled, 
                   ifnull(v_Is_chatbot_ddi,0) as Is_chatbot_ddi,
                   case when v_is_pstn_route = 1 then 0 else ifnull(v_is_ccaas,0) end as is_ccaas,
                   ifnull(v_cli_username,'') as cli_username;   
                     
                   END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Split` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `Split`(v_String VARCHAR(8000), v_Delimiter CHAR(1))
SWL_return:
 begin
 
      
    DECLARE v_idx INT;     
    DECLARE v_slice VARCHAR(8000);     
 
    DROP TEMPORARY TABLE IF EXISTS tt_Split_temptable;
    CREATE TEMPORARY TABLE IF NOT EXISTS tt_Split_temptable
    (
       items VARCHAR(8000)
    );
    SET v_idx = 1;     
    if  CHAR_LENGTH(v_String) < 1 or v_String is null then  
       LEAVE SWL_return;
    end if;     
 
    SWL_Label:
    while v_idx != 0 DO
       set v_idx = LOCATE(v_Delimiter,v_String);
       if v_idx != 0 then
          set v_slice = left(v_String,v_idx -1);
       else
          set v_slice = v_String;
       end if;
       if( CHAR_LENGTH(v_slice) > 0) then
          insert into tt_Split_temptable(Items) values(v_slice);
       end if;
       set v_String = right(v_String, CHAR_LENGTH(v_String) -v_idx);
       if  CHAR_LENGTH(v_String) = 0 then 
          LEAVE SWL_Label;
       end if;
    END WHILE; 
    LEAVE SWL_return;     
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ur_create_product_master` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ur_create_product_master`(prod_id INT,
 prod_name VARCHAR(100),
 prod_code VARCHAR(20),
 description VARCHAR(50),
 status INT,
 sub_prod_available INT,
 processtype INT 
 )
BEGIN
 
 	
    DECLARE v_errcode INT;
    DECLARE v_errmsg VARCHAR(160);
 	
    IF prod_id is null then
       set prod_id = 0;
    END IF;
    sp_exit:
    BEGIN
       IF prod_id is null then
          set prod_id = 0;
       END IF;
       set v_errcode = -1;
       set v_errmsg = 'Failure';
       IF processtype = 1 then
 	
          IF EXISTS(SELECT  * FROM product_master a where a.prod_name = prod_name LIMIT 1)
          then
             SET v_errcode = -1;
             set v_errmsg = 'Product name already exist';
             LEAVE sp_exit;
          end if;
          
			INSERT INTO product_master(prod_code,prod_name,description,prod_status,sub_prod_available)
			VALUES(prod_code,prod_name,description,status,sub_prod_available);
 		
          SET prod_id = LAST_INSERT_ID();
          
          if ROW_COUNT() > 0 
          then
             SET v_errcode = 0;
             set v_errmsg = 'Success to create a Product info.';
             
				INSERT INTO unifiedring.product_master(prod_name)  
				VALUES(prod_name);  
             
             
             LEAVE sp_exit;
          end if;
       end if;
       
       if processtype = 2
       then
 	
          if prod_id = 0 
          then
 		
             LEAVE sp_exit;
          end if;
          IF EXISTS(SELECT  * FROM product_master b where b.prod_name = prod_name and b.prod_id <> prod_id LIMIT 1)
          then
             SET v_errcode = -1;
             set v_errmsg = 'Product name already exist';
             LEAVE sp_exit;
          end if;
          
          UPDATE product_master a set
          a.prod_name = IFNULL(prod_name,a.prod_name),
 		
 		a.Description = IFNULL(description,a.Description),
          a.prod_status = IFNULL(status,a.prod_status),
          a.sub_prod_available = IFNULL(sub_prod_available,a.sub_prod_available)
          where a.prod_id = prod_id;
          
          if ROW_COUNT() > 0 
          then
             SET v_errcode = 0;
             set v_errmsg = 'Success to update a Product info.';
             
				update unifiedring.product_master a set a.prod_name=prod_name  
				where a.prod_id = prod_id;  
             
             LEAVE sp_exit;
          end if;
       end if;
       
       if processtype = 3 
       then
          IF not EXISTS(SELECT  * FROM product_master c WHERE c.prod_id = prod_id LIMIT 1) 
          then
             SET v_errcode = -1;
             set v_errmsg = 'Product info not found';
             LEAVE sp_exit;
          end if;
          
          UPDATE product_master a set a.prod_status = 3
          where a.prod_id = prod_id;
          
          if ROW_COUNT() > 0 
          then
             SET v_errcode = 0;
             set v_errmsg = 'Success to delete Product.';
             LEAVE sp_exit;
          end if;
       end if;
    END;
    
    select v_errcode as errcode,v_errmsg as errmsg, prod_id as prod_id;
 	
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ur_create_sub_product_master` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ur_create_sub_product_master`(
 sub_prod_id INT,
 prod_id INT, 
 sub_prod_name VARCHAR(100),
 sub_prod_code VARCHAR(100),
 sub_prod_description VARCHAR(100), 
 sub_prod_status INT,
 processtype INT 
 )
BEGIN
 
    DECLARE v_errcode INT;
    DECLARE v_errmsg VARCHAR(160);
 	
    IF sub_prod_id is null then
       set sub_prod_id = 0;
    END IF;
    sp_exit:
    BEGIN
       IF sub_prod_id is null then
          set sub_prod_id = 0;
       END IF;
       set v_errcode = -1;
       set v_errmsg = 'Failure';
       IF processtype = 1 then
 	
          IF EXISTS(SELECT * FROM product_category_master a where a.category_name = sub_prod_name and a.fk_prod_id = prod_id LIMIT 1)
          then
             SET v_errcode = -1;
             set v_errmsg = 'Sub Product name already exist';
             LEAVE sp_exit;
          end if;
          
          INSERT INTO product_category_master(fk_prod_id,category_name,category_description,sub_product_code,category_status)
 		VALUES(prod_id,sub_prod_name,sub_prod_description,sub_prod_code,sub_prod_status);
 		
          set sub_prod_id = LAST_INSERT_ID();
          
          if ROW_COUNT() > 0
          then
             SET v_errcode = 0;
             set v_errmsg = 'Success to create a sub product info.';
             LEAVE sp_exit;
          end if;
          
       end if;
       
       if processtype = 2 then
 	
          if sub_prod_id = 0 or prod_id = 0 then
             LEAVE sp_exit;
          end if;
          
          
          IF EXISTS(SELECT  * FROM product_category_master b where b.category_name = sub_prod_name and b.fk_prod_id = prod_id
          and b.catg_id <> sub_prod_id LIMIT 1) 
          then
             SET v_errcode = -1;
             set v_errmsg = 'Sub Product Name already exist';
             LEAVE sp_exit;
          end if;
          
          
          UPDATE product_category_master a
          set a.category_name = IFNULL(sub_prod_name,a.category_name),
          a.category_description = IFNULL(sub_prod_description,a.category_description),
          a.category_status = sub_prod_status
          where a.fk_prod_id = prod_id
          and a.catg_id = sub_prod_id;
          
          
          if ROW_COUNT() > 0 
          then
             SET v_errcode = 0;
             set v_errmsg = 'Success to update a Product Category info.';
             LEAVE sp_exit;
          end if;
       end if;
       
       
       if processtype = 3 then
 	
          IF not EXISTS(SELECT  * FROM product_category_master c WHERE c.catg_id = sub_prod_id LIMIT 1) 
          then
             SET v_errcode = -1;
             set v_errmsg = 'Product Category info not found';
             LEAVE sp_exit;
          end if;
          
          
          UPDATE product_category_master a set a.category_status = 3
          where a.catg_id = sub_prod_id;
          
          
          if ROW_COUNT() > 0 
          then
             SET v_errcode = 0;
             set v_errmsg = 'Success to delete Product Category.';
             LEAVE sp_exit;
          end if;
       end if;
    END;
    select v_errcode as errcode,v_errmsg as errmsg, sub_prod_id as sub_prod_id;
 	
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ur_get_bundle_sub_product_master` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ur_get_bundle_sub_product_master`(prod_id LONGTEXT,
sub_prod_id INT)
Begin


   IF sub_prod_id is null then
      set sub_prod_id = 0;
   END IF;
  
drop temporary table if exists tt_tmp_prd_list ;
create temporary table tt_tmp_prd_list
(
prd_id int
);


 call Split(prod_id,',');
      
            insert into tt_tmp_prd_list(prd_id)
      select Items from tt_Split_temptable;

   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   SELECT catg_id as sub_prod_id,fk_prod_id,sub_product_code,category_name as sub_product_name,category_description as sub_product_description,
	category_status as status
   FROM product_category_master
   where ((fk_prod_id  in(select prd_id from tt_tmp_prd_list) or IFNULL(prod_id,'') = '')) and category_status = 1
	
   and (catg_id = sub_prod_id or IFNULL(sub_prod_id,0) = 0);
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
	

End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ur_get_channel_details_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ur_get_channel_details_info`(
        tier_id INT
        )
begin
        
           SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
           select a.fk_category_id as category_id,a.feature_name,c.tier_id
           from wtms_feature_info a 
           join wtms_feature_category b on a.fk_category_id = b.category_id
           join wtms_tier_feature_mapping_xml c on  c.featureid = a.feature_id and c.categoryid = b.category_id 
           join wtms_tier_category_position d on d.catg_id=c.categoryid and c.tier_id = d.fk_tier_id
           where c.tier_id = tier_id and a.status = 1
           and ifnull(c.value2,0) = 0 and a.feature_usability = 1
           and b.category_name = 'Channels'
           order by d.catg_pos,a.position;
           SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
        
        
        end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ur_get_product_master` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ur_get_product_master`(
 	prod_id INT
 )
Begin
 
    IF prod_id is null then
       set prod_id = 0;
    END IF;
 
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
 	   SELECT a.prod_id,a.prod_code as product_code,a.prod_name as product_name,a.Description,a.prod_status as status,a.sub_prod_available
 	   FROM product_master a
 	   where (a.prod_id = prod_id or IFNULL(prod_id,0) = 0) and IFNULL(a.prod_status,0) = 1;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 	
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ur_get_sub_product_master` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ur_get_sub_product_master`(prod_id VARCHAR(55),
sub_prod_id INT)
Begin

   IF sub_prod_id is null then
      set sub_prod_id = 0;
   END IF;

   
   drop temporary TABLE  if exists tt_tmp_prd_list ;
CREATE temporary TABLE  tt_tmp_prd_list 
(
prd_id int
);


 call Split(prod_id,',');
      
            insert into tt_tmp_prd_list(prd_id)
      select Items from tt_Split_temptable;
      
       drop  TABLE  if exists tt_Split_temptable;

   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   SELECT catg_id as sub_prod_id,fk_prod_id,b.prod_name as product_name,sub_product_code,category_name as sub_product_name,category_description as sub_product_description,
	category_status as status
   FROM product_category_master a
   join product_master b 
   on a.fk_prod_id = b.prod_id
   where ((a.fk_prod_id  in(select b.prd_id from tt_tmp_prd_list b ) or IFNULL(prod_id,'') = '')) 
   and (catg_id = sub_prod_id or IFNULL(sub_prod_id,0) = 0) and IFNULL(a.category_status,0) = 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
	

End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ur_myaccount_whatsapp_integration_insert` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ur_myaccount_whatsapp_integration_insert`(
   p_company_name 				VARCHAR(50),	
   p_company_id   				INT,
   p_reg_company_name 			VARCHAR(50),		
   p_business_vertical 		VARCHAR(100),		
   p_company_website 			VARCHAR(100),		
   p_business_unit 			VARCHAR(100),	
   p_contact_name 				VARCHAR(50),	
   p_contact_designation 		VARCHAR(50),			
   p_contact_email_address 	VARCHAR(50),			
   p_launch_regions 			VARCHAR(50),	
   p_whatsapp_phone_num 		VARCHAR(20), 		
   p_whatsapp_conversation_volume 	VARCHAR(250),			
   p_disp_acc_name 			VARCHAR(50),	
   p_fb_business_mngr_id 		VARCHAR(50),			
   p_fb_business_mngr_name 	VARCHAR(50),
   p_container_setup			VARCHAR(50),
   p_is_approved 				INT,
   p_fileURL 					VARCHAR(500),
   p_accountType				TINYINT,
   p_purchasedat				int,
	p_notification_messages varchar(100),
	p_company_logo text,
	p_business_information varchar(100) ,
	p_status_message varchar(200),
	p_address text,
	p_emailid varchar(100),
	p_customer_optin varchar(100),
	p_pricing varchar(100),
	p_whatsapp_business_solution_use_cases varchar(100),
	p_company_profile varchar(100),
	p_location_of_company_headquarters varchar(100)
   
   )
begin
   
   DECLARE v_errcode INT; 
   DECLARE v_errmsg  VARCHAR(50);
   DECLARE v_curdate DATETIME;
   
   SET v_curdate = now(); 
   
	Insert into ur_myaccount_social_media_whatsapp_integration( company_name ,company_id ,reg_company_name ,business_vertical,company_website,business_unit,contact_name,contact_designation,contact_email_address,launch_regions,
		whatsapp_phone_num,whatsapp_conversation_volume,disp_acc_name,fb_business_mngr_id,fb_business_mngr_name,is_approved,fileURL,accountType,container_setup,createdate ,purchasedat,notification_messages,company_logo,
		business_information,status_message,address,emailid,customer_optin,pricing,whatsapp_business_solution_use_cases,company_profile,location_of_company_headquarters)
	values(p_company_name,p_company_id,p_reg_company_name,p_business_vertical,p_company_website,p_business_unit,p_contact_name,p_contact_designation,p_contact_email_address,p_launch_regions,
		p_whatsapp_phone_num,p_whatsapp_conversation_volume,p_disp_acc_name,p_fb_business_mngr_id,p_fb_business_mngr_name,p_is_approved,p_fileURL,p_accountType,p_container_setup,v_curdate,p_purchasedat,p_notification_messages,p_company_logo,
		p_business_information,p_status_message,p_address,p_emailid,p_customer_optin,p_pricing,p_whatsapp_business_solution_use_cases,p_company_profile,p_location_of_company_headquarters);

   		if row_count()>0
           then
           SET v_errcode = 0;
           SET v_errmsg  = 'Inserted Successfully';
           end if;
   SELECT v_errcode as errcode , v_errmsg as errmsg ;
   End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ur_myacc_GetPurchasedAddonListByCompany` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ur_myacc_GetPurchasedAddonListByCompany`(
  p_company_id int
  )
Begin	
 	declare v_plan_id int;
 
 	select plan_id into v_plan_id from ur_company_plan where company_id = p_company_id;
 
 	select Distinct a.tier_id,a.addon_feature_id,a.addon_feature_name,a.addon_feature_description,a.image_name,case when ap.company_id is not null then 1 else 0 end isPurchased, a.lang_code,a.price as addon_price
 	from wtms.wtms_prod_wise_feature_info a
 	join wtms.wtms_feature_prod_wise_category ct on a.fk_category_id = ct.category_id
 	left join unifiedring.ur_addon_purchase_hdr ap on ap.addon_id = a.addon_feature_id and ap.company_id = p_company_id
 	-- where ct.category_status = 1 and a.status=1 and a.tier_id like concat('%',v_plan_id,'%');
 	where ct.category_status = 1 and a.status=1 and FIND_IN_SET(v_plan_id, a.tier_id) > 0;
     
  End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ur_tariff_get_tariff_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ur_tariff_get_tariff_details`(
  id int,  
  planid int)
BEGIN  
    
    if id = ''
    then
    set id = 0;
    end if;
    
    if planid = ''
    then
    set planid = 0;
    end if;
   
   call unifiedring.ur_tariff_get_tariff_details (id,planid);
     
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `utms_create_esp_tariff` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `utms_create_esp_tariff`(
   plan_id INT, 
   tariff VARCHAR(4),
   tariff_type INT,
   processby VARCHAR(150),
   processtype INT,
   id INT,
   addon_type int 
   )
BEGIN
   
      IF id is null then
         set id = 0;
      END IF;
      CALL unifiedring.ur_tariff_create_tariff_details(plan_id,tariff,tariff_type,processby,processtype,id,addon_type);
   	
   	
   END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `utms_get_tariff_rate_download` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `utms_get_tariff_rate_download`(
  trffclass VARCHAR(4),
  accesscharge INT)
BEGIN
  
  
     DECLARE v_errcode INT; 
     DECLARE v_errmsg VARCHAR(50);
  
     sp_exit:
     BEGIN
        set v_errcode = -1;
        set v_errmsg = 'Not Found';
        
        CALL espprm.BMS_portal_get_tariff_download('MCM',trffclass,accesscharge);
        if found_rows() > 0 then
  	
           set v_errcode = 0;
           set v_errmsg = 'Success';
           LEAVE sp_exit;
        end if;
     END;
     select v_errcode as errcode,v_errmsg as errmsg;
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `utms_get_tariff_upload_drp` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `utms_get_tariff_upload_drp`(type INT)
BEGIN
   	
   	
     
     declare default_int_val int;
     set default_int_val = 1;
   	
      IF type = 1 then
   	
         SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
         select distinct default_int_val as id,trffclass  as `value`
         from unifiedring.plan_tariff_config;
         SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
      end if;
       
      IF type = 2 then
    	
         SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
         SELECT access_type as id, access_type_name as `value`
         FROM ur_access_type_Config;
         SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
      end if;
       
   	
   END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `utms_get_uploaded_tariff_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `utms_get_uploaded_tariff_details`()
BEGIN
  
  	
     SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
     SELECT a.trffclass,a.access_type,b.access_type_name,d.Pln_Name as plan_name FROM tariff_upload_info a
     join ur_access_type_Config b on a.access_type = b.access_type
     join unifiedring.plan_tariff_config c on a.trffclass = c.trffclass
     join unifiedring.UR_ECom_Plan d on c.Plan_id = d.Pln_Idx
       union all
      SELECT a.trffclass,a.access_type,b.access_type_name,CONCAT('Addon',c.bundle_name) as plan_name
    FROM tariff_upload_info a
    join ur_access_type_Config b on a.access_type = b.access_type
    join  unifiedring.utms_new_bundle_log c on a.trffclass = c.tariffclass;
     SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
  	
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UTMS_update_Delete_WEB_rate_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `UTMS_update_Delete_WEB_rate_details`(
 id INT,
  fixed_Rate VARCHAR(150),
  mobile_rate VARCHAR(150),
  procsstype INT 
  )
BEGIN
  
  	
  	
     DECLARE v_errcode INT; 
     DECLARE v_errmsg VARCHAR(160);
  	
     set v_errcode = -1;
     set v_errmsg = 'Failure to update the details';
  	
     IF procsstype = 1 then
  	
        UPDATE UTMS_WEB_RATE_CONFIG a SET  a.fixed_rate = fixed_Rate,a.mobile_rate = mobile_rate where a.id = id;
        IF ROW_COUNT() > 0 then
  		
           set v_errcode = 0;
           set v_errmsg = 'Success to update the rate details';
        end if;
     end if;
  	
     IF  procsstype = 2 then
  	
        DELETE FROM UTMS_WEB_RATE_CONFIG a WHERE a.id = id;
        IF ROW_COUNT() > 0 then
  		
           set v_errcode = 0;
           set v_errmsg = 'Success to update the rate details';
        end if;
     end if;
  	
     Select v_errcode as errcode,v_errmsg as errmsg;
  
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `utms_upload_tariff_rate` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `utms_upload_tariff_rate`(
 bundleid INT,  
 in_xml_data LONGTEXT ,  
 in_user_name VARCHAR(50))
BEGIN
 
   
   
    
   
    CALL unifiedring.tm_upload_bundle_rate_info(bundleid,in_xml_data,in_user_name);  
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_copy_tier_to_new_tier_management` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_copy_tier_to_new_tier_management`(
 	tier_id INT,
     tier_name VARCHAR(150)
 )
Begin
                
     			DECLARE v_errcode INT;								DECLARE v_errmsg INT;								DECLARE v_tier_description VARCHAR(250);			DECLARE v_tier_type INT;							
     			DECLARE v_prod_type_id INT DEFAULT 0;				DECLARE v_bund_prd_type INT DEFAULT 0;				DECLARE v_product_id VARCHAR(50);					DECLARE v_sub_product_id VARCHAR(200);		
     			DECLARE v_fk_purpose_id VARCHAR(100);				DECLARE v_status INT;								DECLARE v_apply_new_exist_cust VARCHAR(10);			DECLARE v_free_or_paid INT;					
     			DECLARE v_currency INT;								DECLARE v_no_of_users VARCHAR(50) DEFAULT '';		DECLARE v_min_users INT DEFAULT 0;					DECLARE v_contract_period VARCHAR(50) DEFAULT '';	
     			DECLARE v_per_addn_user FLOAT DEFAULT 0;			DECLARE v_per_addn_user_currency INT;				DECLARE v_User_Range_xml LONGTEXT DEFAULT null;		DECLARE v_tier_summary_map_xml LONGTEXT DEFAULT '';
     			DECLARE v_catg_position_xml LONGTEXT DEFAULT '';	DECLARE v_catg_feature_map_xml LONGTEXT DEFAULT '';	DECLARE v_feature_mapping_xml LONGTEXT DEFAULT '';	DECLARE v_create_by VARCHAR(20);	
     			DECLARE v_is_review INT;							DECLARE v_client_ip VARCHAR(20) DEFAULT '';			DECLARE v_processtype INT;							DECLARE v_country_id INT;
     			DECLARE v_module_id VARCHAR(150);					DECLARE v_sub_module_id VARCHAR(150);				DECLARE v_reseller_id TEXT;							DECLARE v_pro_user_count INT;
     			DECLARE v_standard_user_count INT;					DECLARE v_basic_user_count INT;						DECLARE v_free_trail_status INT;					DECLARE v_free_trail_days INT;
     			DECLARE v_double_up INT;							DECLARE v_Installation_cost FLOAT;					DECLARE v_Installation_cost_free_count FLOAT;		DECLARE v_platform_fee FLOAT;
     			DECLARE v_messages_count INT;						DECLARE v_sessions_count INT;						DECLARE v_Type_of_plan INT;							DECLARE v_Custom_status INT;
 				DECLARE v_platform_fee_year INT;					DECLARE v_booking_user_count INT;					DECLARE v_booking_user_price FLOAT;					DECLARE v_platform_fee_json_info JSON;
                DECLARE v_parent_id INT;
      
     			set v_processtype = 1;
     			set v_is_review = 1;
                
                   select   tier_description, client_ip, tier_type, prod_type_id, bund_prd_type, product_id, sub_product_id, fk_purpose_id, status, apply_new_exist_cust, free_or_paid, currency, no_of_users, min_users, contract_period, per_addn_user, per_addn_user_currency, User_Range_xml, tier_summary_map, catg_position_xml, feature_mapping, create_by, catg_feature_map_xml, 
 					  country_id,module_id,sub_module_id,reseller_id,pro_user_count,standard_user_count,basic_user_count,free_trail_status,free_trail_days,double_up,Installation_cost,Installation_cost_free_count,platform_fee,messages_count,sessions_count,Type_of_plan,Custom_status,platform_fee_year,
 					  booking_user_count,booking_user_price,platform_fee_json_info,parent_id 
                   INTO v_tier_description,v_client_ip,v_tier_type,v_prod_type_id,v_bund_prd_type,v_product_id,v_sub_product_id,v_fk_purpose_id,v_status,v_apply_new_exist_cust,v_free_or_paid,v_currency,v_no_of_users,v_min_users,v_contract_period,v_per_addn_user,v_per_addn_user_currency,v_User_Range_xml,v_tier_summary_map_xml,v_catg_position_xml,v_feature_mapping_xml,v_create_by,v_catg_feature_map_xml,
 					  v_country_id,v_module_id,v_sub_module_id,v_reseller_id,v_pro_user_count,v_standard_user_count,v_basic_user_count,v_free_trail_status,v_free_trail_days,v_double_up,v_Installation_cost,v_Installation_cost_free_count,v_platform_fee,v_messages_count,v_sessions_count,v_Type_of_plan,v_Custom_status,v_platform_fee_year,
 					  v_booking_user_count,v_booking_user_price,v_platform_fee_json_info,v_parent_id 
                   from  wtms_tier_management_log a where a.tier_id = tier_id and a.is_review = 5 order by id desc LIMIT 1;
                
                   CALL worktual_create_tier_management(0,tier_name,v_tier_description,v_tier_type,v_prod_type_id,v_bund_prd_type,v_product_id,v_sub_product_id,v_fk_purpose_id,v_status,v_apply_new_exist_cust,v_free_or_paid,
 					  v_currency,v_no_of_users,v_min_users,v_contract_period,v_per_addn_user,v_per_addn_user_currency,v_User_Range_xml,v_tier_summary_map_xml,v_catg_position_xml,v_catg_feature_map_xml,v_feature_mapping_xml,
 					  v_create_by,v_is_review,v_client_ip,v_processtype,v_country_id,v_module_id,v_sub_module_id,v_reseller_id,v_pro_user_count,v_standard_user_count,v_basic_user_count,v_free_trail_status,v_free_trail_days,
                       v_double_up,v_Installation_cost,v_Installation_cost_free_count,v_platform_fee,v_messages_count,v_sessions_count,v_Type_of_plan,v_Custom_status,v_platform_fee_year,v_booking_user_count,v_booking_user_price,v_platform_fee_json_info,v_parent_id);
             
     	End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_copy_tier_to_new_tier_management_backup` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_copy_tier_to_new_tier_management_backup`(
   tier_id INT,
   tier_name VARCHAR(150)
   )
Begin
   
      DECLARE v_errcode INT;
      DECLARE v_errmsg INT;
      DECLARE v_tier_description VARCHAR(250);
      DECLARE v_tier_type INT;						
      DECLARE v_prod_type_id INT DEFAULT 0;					
      DECLARE v_bund_prd_type INT DEFAULT 0;				
      DECLARE v_product_id VARCHAR(50);				
      DECLARE v_sub_product_id VARCHAR(200);		
      DECLARE v_fk_purpose_id VARCHAR(100);			
      DECLARE v_status INT;
      DECLARE v_apply_new_exist_cust VARCHAR(10);	
      DECLARE v_free_or_paid INT;
      DECLARE v_currency INT;
      DECLARE v_no_of_users VARCHAR(50) DEFAULT '';			
      DECLARE v_min_users INT DEFAULT 0;
      DECLARE v_contract_period VARCHAR(50) DEFAULT '';		
      DECLARE v_per_addn_user FLOAT DEFAULT 0;
      DECLARE v_per_addn_user_currency INT;
      DECLARE v_User_Range_xml LONGTEXT DEFAULT null;			
      DECLARE v_tier_summary_map_xml LONGTEXT DEFAULT '';		
      DECLARE v_catg_position_xml LONGTEXT DEFAULT '';
      DECLARE v_catg_feature_map_xml LONGTEXT DEFAULT '';
      DECLARE v_feature_mapping_xml LONGTEXT DEFAULT '';			
      DECLARE v_create_by VARCHAR(20);
      DECLARE v_is_review INT;
      DECLARE v_client_ip VARCHAR(20) DEFAULT '';
      DECLARE v_processtype INT;
      DECLARE v_country_id int;
      DECLARE v_module_id varchar(150);
  	DECLARE v_sub_module_id varchar(150);
       DECLARE v_reseller_id text;
   
      set v_processtype = 1;
      set v_is_review = 1;
   
      select   tier_description, client_ip, tier_type, prod_type_id, bund_prd_type, product_id, sub_product_id, fk_purpose_id, status, apply_new_exist_cust, free_or_paid, currency, no_of_users, min_users, contract_period, per_addn_user, per_addn_user_currency, User_Range_xml, tier_summary_map, catg_position_xml, feature_mapping, create_by, catg_feature_map_xml, 
      country_id,module_id,sub_module_id,reseller_id
      INTO v_tier_description,v_client_ip,v_tier_type,v_prod_type_id,v_bund_prd_type,
      v_product_id,v_sub_product_id,v_fk_purpose_id,v_status,v_apply_new_exist_cust,
      v_free_or_paid,v_currency,v_no_of_users,v_min_users,v_contract_period,
      v_per_addn_user,v_per_addn_user_currency,v_User_Range_xml,
      v_tier_summary_map_xml,v_catg_position_xml,v_feature_mapping_xml,v_create_by,
      v_catg_feature_map_xml,v_country_id,v_module_id,v_sub_module_id,v_reseller_id
      from wtms_tier_management_log a where a.tier_id = tier_id and a.is_review = 5   order by id desc LIMIT 1;
   
   
   
      CALL worktual_create_tier_management(0,tier_name,v_tier_description,v_tier_type,v_prod_type_id,v_bund_prd_type,
      v_product_id,v_sub_product_id,v_fk_purpose_id,v_status,v_apply_new_exist_cust,
      v_free_or_paid,v_currency,v_no_of_users,v_min_users,v_contract_period,
      v_per_addn_user,v_per_addn_user_currency,v_User_Range_xml,
      v_tier_summary_map_xml,v_catg_position_xml,v_catg_feature_map_xml,v_feature_mapping_xml,
      v_create_by,v_is_review,v_client_ip,v_processtype,v_country_id,v_module_id,v_sub_module_id,v_reseller_id);
   
   
   
   End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_create_bundle_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_create_bundle_dtl`(
  bundle_id INT,
  bundle_name VARCHAR(100),
  bundle_description VARCHAR(200),
  status INT,
  prod_id VARCHAR(100),
  sub_prod_id VARCHAR(100),
  processtype INT 
  )
Begin
  
  
     DECLARE v_errcode INT; 
     DECLARE v_errmsg VARCHAR(100);
     DECLARE v_now DATETIME(3);
     DECLARE v_sub_prod_name LONGTEXT;
     DECLARE v_prod_name LONGTEXT;
  
     IF bundle_id is null then
        set bundle_id = 0;
     END IF;
     sp_exit:
     BEGIN
        IF bundle_id is null then
           set bundle_id = 0;
        END IF;
        set v_errcode = -1;
        set v_errmsg = 'Failure';
        set v_now = CURRENT_TIMESTAMP;
        
		DROP TEMPORARY TABLE IF EXISTS tt_t1_prod_id;
        CREATE TEMPORARY TABLE tt_t1_prod_id 
        (
        prod_id int
        );
        
		call Split(prod_id,',');
        
		insert into tt_t1_prod_id(prod_id)
		select Items from tt_Split_temptable;
	
  
     DROP TEMPORARY TABLE IF EXISTS tt_t1_sub_prod_id;
       CREATE TEMPORARY TABLE tt_t1_sub_prod_id 
        (
        sub_prod_id int
        );
        
        call Split(sub_prod_id,',');

		insert into tt_t1_sub_prod_id(sub_prod_id)
		select Items from tt_Split_temptable;

  	
		DROP TEMPORARY TABLE IF EXISTS tt_temp_sub_prd_mapping;
		CREATE TEMPORARY TABLE tt_temp_sub_prd_mapping AS select a.catg_id,a.fk_prod_id 
		from product_category_master a
		where a.catg_id in(select b.sub_prod_id from tt_t1_sub_prod_id b)
		and a.fk_prod_id in(select c.prod_id from tt_t1_prod_id c join product_master d on c.prod_id = d.prod_id where d.prod_status = 1)
		and a.category_status = 1;
           
		
		
        
        
		
         
		select Distinct group_CONCAT(b.category_name) INTO v_sub_prod_name from product_category_master b
		where b.catg_id in(select cc.sub_prod_id from tt_t1_sub_prod_id cc) and b.category_status = 1;

		select  Distinct group_CONCAT(b.prod_name) INTO v_prod_name from product_master b
		where b.prod_id in(select a.prod_id from tt_t1_prod_id a) and b.prod_status = 1;
        
        
    
        if processtype = 1 then
  	
           if exists(select  *  from worktual_bundle_master b where b.bundle_name = bundle_name LIMIT 1) 
           then
              set v_errcode = -1;
              set v_errmsg = 'Bundle name already found';
              LEAVE sp_exit;
           end if;
           
           if exists(select * from worktual_bundle_prod_subprod_mapping a where a.bundle_name = bundle_name and a.prod_id = prod_id
           and a.sub_prod_id = sub_prod_id LIMIT 1) 
           then
              set v_errcode = -1;
              set v_errmsg = 'Bundle already exists for selected product and sub product combination';
              LEAVE sp_exit;
           end if;

			insert into worktual_bundle_master(bundle_name,bundle_description,status,create_date)
			values(bundle_name,bundle_description,status,v_now);
  		
           set bundle_id = LAST_INSERT_ID();
           
           if ROW_COUNT() > 0 then
           
  			insert into worktual_bundle_prod_subprod_mapping(bundle_id,bundle_name,bundle_description,status,prod_id,sub_prod_id,prod_name,sub_products)
  			values(bundle_id,bundle_name,bundle_description,status,prod_id,sub_prod_id,v_prod_name,v_sub_prod_name);
  			
  			
  			
              insert into worktual_bundle_product_master(fk_bundle_id,fk_prod_id,fk_sub_prod_id,create_date,update_date)
              select bundle_id,a.fk_prod_id,a.catg_id,v_now,v_now from tt_temp_sub_prd_mapping a;
              set v_errcode = 0;
              set v_errmsg = 'Bundle created';
              LEAVE sp_exit;
           end if;
           
        end if;
        
        if processtype = 2 then
  	
           if not exists(select  *  from worktual_bundle_master b where b.bundle_id = bundle_id LIMIT 1) then
  		
              set v_errcode = -1;
              set v_errmsg = 'BundleID not exist';
              LEAVE sp_exit;
           end if;
           
           if exists(select  * from worktual_bundle_master a where a.bundle_name = bundle_name and a.bundle_id <> bundle_id LIMIT 1) 
           then
              set v_errcode = -1;
              set v_errmsg = 'Bundle name already found';
              LEAVE sp_exit;
           end if;
           

           UPDATE worktual_bundle_master a
           set a.bundle_name = IFNULL(bundle_name,a.bundle_name),
           a.bundle_description = IFNULL(bundle_description,a.bundle_description),
           a.status = IFNULL(status,a.status)
           where a.bundle_id = bundle_id;
           
           if found_rows() > 0 then
              if prod_id <> '' or prod_id is not null then
  			
                 if exists(select  * from worktual_bundle_prod_subprod_mapping b where b.bundle_id = bundle_id LIMIT 1) then
  				
                    delete from worktual_bundle_prod_subprod_mapping d where d.bundle_id = bundle_id;
                 end if;
                 if exists(select  * from worktual_bundle_product_master c where c.fk_bundle_id = bundle_id LIMIT 1) then
  				
                    delete from worktual_bundle_product_master where fk_bundle_id = bundle_id;
                 end if;
           
  				
                 insert into worktual_bundle_product_master(fk_bundle_id,fk_prod_id,fk_sub_prod_id,create_date,update_date)
                 select bundle_id,a.fk_prod_id,a.catg_id,v_now,v_now from tt_temp_sub_prd_mapping a;
                 
                 insert into worktual_bundle_prod_subprod_mapping(bundle_id,bundle_name,bundle_description,status,prod_id,sub_prod_id,prod_name,sub_products)
  				values(bundle_id,bundle_name,bundle_description,status,prod_id,sub_prod_id,v_prod_name,v_sub_prod_name);
              end if;
              
              
              set v_errcode = 0;
              set v_errmsg = 'Bundle Updated';
              LEAVE sp_exit;
              
           end if;
        end if;
        if processtype = 3 then
  	
           if not exists(select  * from worktual_bundle_master d where  d.bundle_id = bundle_id LIMIT 1)
           then
              set v_errcode = -1;
              set v_errmsg = 'Bundle id not found';
              LEAVE sp_exit;
              
           end if;
           update worktual_bundle_master c set c.status = 3
           where c.bundle_id = bundle_id;
           
           if ROW_COUNT() > 0 then
              update worktual_bundle_prod_subprod_mapping a set a.status = 3
              where   a.bundle_id = bundle_id;
              SET v_errcode = 0;
              set v_errmsg = 'Success to delete Bundle.';
              LEAVE sp_exit;
           end if;
        end if;
     END;
     select  v_errcode as errcode,v_errmsg as errmsg, bundle_id as bundle_id;
  
  End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_create_Category_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_create_Category_info`(
category_id INT ,
fk_prod_id INT,
fk_sub_prod INT,
category_Name VARCHAR(255),
category_description VARCHAR(255),
category_position INT,
process_type INT,
status INT)
BEGIN

	
   DECLARE v_errcode INT;
   DECLARE v_errmsg VARCHAR(160);
   DECLARE v_now DATETIME(3);

   IF category_id is null then
      set category_id = 0;
   END IF;
   sp_exit:
   BEGIN
      IF category_id is null then
         set category_id = 0;
      END IF;
      set v_now = CURRENT_TIMESTAMP;
      Set v_errcode = -1;
      set v_errmsg = 'Failure to create Category ';
      if category_Name is null or category_Name = '' then
		
         Set v_errcode = -1;
         set v_errmsg = 'Failure to create Category ';
      end if;
		
		
      IF process_type = 1 
      then
         IF EXISTS(SELECT * FROM wtms_feature_category a where a.Category_Name = category_Name and a.fk_prod_id = fk_prod_id 
         and a.fk_sub_prod = fk_sub_prod LIMIT 1) 
         then
            Set v_errcode = -1;
            Set v_errmsg = 'Category already exists!';
            LEAVE sp_exit;
         end if;
         
         INSERT INTO wtms_feature_category(category_Name,fk_prod_id,fk_sub_prod,category_description,category_status,category_position,create_date)
			VALUES(category_Name,fk_prod_id,fk_sub_prod,category_description,status,category_position,v_now);
			
         set category_id = LAST_INSERT_ID();
         IF ROW_COUNT() > 0 
         then
            Set v_errcode = 0;
            Set v_errmsg = 'New category is created!';
            LEAVE sp_exit;
         end if;
      end if;
		
		
      IF process_type = 2 then
         IF NOT EXISTS(SELECT  * FROM wtms_feature_category b where b.Category_id = category_id LIMIT 1) 
         then
            Set v_errcode = -1;
            Set v_errmsg = 'Category not found!';
            LEAVE sp_exit;
         end if;
         IF EXISTS(SELECT  * FROM wtms_feature_category  c where c.Category_Name = category_Name
         and c.fk_prod_id = fk_prod_id and c.fk_sub_prod = fk_sub_prod and c.Category_id <> category_id LIMIT 1)
         then
            Set v_errcode = -1;
            Set v_errmsg = 'Category already exists!';
            LEAVE sp_exit;
         end if;
         
         UPDATE wtms_feature_category a
         Set a.category_name = category_Name,a.fk_prod_id = fk_prod_id,a.fk_sub_prod = fk_sub_prod,
         a.category_description = category_description,a.category_status = status,
         a.category_position = category_position,a.create_date = v_now
         where a.category_id = category_id;
         IF ROW_COUNT() > 0 
         then
            Set v_errcode = 0;
            Set v_errmsg = CONCAT(category_Name,' details are updated!');
            LEAVE sp_exit;
         end if;
      end if;

		
     
     IF process_type = 3
     then
         IF NOT EXISTS(SELECT  * FROM wtms_feature_category c where c.Category_id = category_id LIMIT 1) 
         then
            Set v_errcode = -1;
            Set v_errmsg = 'Category not found!';
            LEAVE sp_exit;
         end if;
         
         update wtms_feature_category b set b.category_status = 3 where b.Category_id = category_id;
         IF ROW_COUNT() > 0 
         then
            Set v_errcode = 0;
            Set v_errmsg = 'Success to Deleted Category Name info!';
            LEAVE sp_exit;
         end if;
      end if;
   END;
   select v_errcode as errcode,v_errmsg as errmsg, IFNULL(category_id,0) as category_id;
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_create_category_master_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_create_category_master_dtl`(
category_id INT ,
category_name VARCHAR(100),
category_status INT,
processtype INT 
)
Begin

   DECLARE errcode INT;
   DECLARE errmsg VARCHAR(160);
   DECLARE now DATETIME(3);
	
   IF category_id is null then
      set category_id = 0;
   END IF;

sp_exit:
   BEGIN

      set errcode = -1;
      set errmsg = 'Failure';
      set now = CURRENT_TIMESTAMP;

      IF processtype = 1 then
	
         IF EXISTS(SELECT * FROM worktual_sum_category_master a where a.category_name = category_name LIMIT 1) then
		
            SET errcode = -1;
            set errmsg = 'category name already exist';
            LEAVE sp_exit;
         end if;

			INSERT INTO worktual_sum_category_master(category_name,category_status,created_date)
			VALUES(category_name,category_status,now);
		
         SET category_id = LAST_INSERT_ID();

         if ROW_COUNT() > 0 then
		
            SET errcode = 0;
            set errmsg = 'Success : Category created';
            LEAVE sp_exit;
         end if;
      end if;

      IF processtype = 2 then
	
         if category_id = 0 then
            LEAVE sp_exit;
         end if;

         IF EXISTS(SELECT * FROM worktual_sum_category_master a where a.category_name = category_name
         and a.category_id <> category_id LIMIT 1) then
		
            SET errcode = -1;
            set errmsg = 'Category name already exist';
            LEAVE sp_exit;
         end if;

         UPDATE worktual_sum_category_master a 
		 set a.category_name = IFNULL(category_name,a.category_name),a.category_status = IFNULL(category_status,a.category_status)
         where a.category_id = category_id;

         if ROW_COUNT() > 0 then
		
            SET errcode = 0;
            set errmsg = 'Success : Category updated';
            LEAVE sp_exit;
         end if;
      end if;
   END;

   select errcode as errcode,errmsg as errmsg, category_id as category_id;

End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_create_contract_period_info_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_create_contract_period_info_dtl`(
contract_id INT,
contract_period INT,
contract_type INT, 
processtype INT, 
status INT 
)
Begin


   DECLARE contract_desc VARCHAR(50);
   DECLARE errcode INT;
   DECLARE errmsg VARCHAR(100);
   DECLARE now DATETIME(3);

   IF contract_id is null then
      set contract_id = 0;
   END IF;

   sp_exit:
   BEGIN
   
	set now = CURRENT_TIMESTAMP;
	set contract_desc = case when contract_type = 1 then 'Day'
							when contract_type = 2 then 'week'
							when contract_type = 3 then 'month' end;

      if contract_period <> 1 then
         set contract_desc = CONCAT(contract_desc,'s');
      end if;

      set contract_desc = CONCAT(cast(contract_period  as CHAR(30)),' ',contract_desc);

      if processtype = 1 then
	
         if exists(select * from wtms_contract_period_master where cop_description = contract_desc LIMIT 1) then
		 
            set errcode = -1;
            set errmsg = 'Contract period already exists';
            LEAVE sp_exit;
         end if;
         insert into wtms_contract_period_master(cop_cont_id,cop_period,cop_description,create_date,status)
		values(contract_period,contract_type,contract_desc,now,status);
		
         set contract_id = LAST_INSERT_ID();
         set errcode = 0;
         set errmsg = 'Contract period created';
         LEAVE sp_exit;
      end if;
      if processtype = 2 then
	
         if not exists(select * from wtms_contract_period_master a where a.cop_id = contract_id LIMIT 1) then
		 
            set errcode = -1;
            set errmsg = 'Contract period not';
            LEAVE sp_exit;
         end if;

         if exists(select * from wtms_contract_period_master a where a.cop_description = contract_desc and a.cop_id <> contract_id LIMIT 1) then
		 
            set errcode = -1;
            set errmsg = 'Contract period already exists';
            LEAVE sp_exit;
         end if;

         UPDATE wtms_contract_period_master a
         set a.cop_cont_id = contract_period,a.cop_period = contract_type,a.cop_description = contract_desc,
         a.create_date = now,a.status = IFNULL(status,a.status)
         where a.cop_id = contract_id;

         set errcode = 0;
         set errmsg = 'Contract period updated';
         LEAVE sp_exit;
      end if;

      if processtype = 3 then
	
         if not exists(select * from wtms_contract_period_master a where a.cop_id = contract_id LIMIT 1) then
		 
            set errcode = -1;
            set errmsg = 'Contract period not exists';
            LEAVE sp_exit;
         end if;

         update  wtms_contract_period_master set status = 3 where cop_id = contract_id;
         set errcode = 0;
         set errmsg = 'Contract period deleted';
         LEAVE sp_exit;
      end if;

   END;
   select errcode as errcode, errmsg as errmsg,IFNULL(contract_id,0) as contract_id;
	
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_create_currency_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_create_currency_dtl`(
 curr_id INT,
 curr_name VARCHAR(3),
 curr_status INT,
 processtype INT 
 )
begin
 
 	
 
 	
    DECLARE errcode INT;
    DECLARE errmsg VARCHAR(160);
    DECLARE now DATETIME(3);
 	
    IF curr_id is null then
       set curr_id = 0;
    END IF;
 
    sp_exit:
    BEGIN
 
       set errcode = -1;
       set errmsg = 'Failure';
       set now = CURRENT_TIMESTAMP;
       IF processtype = 1 then
 			
          IF EXISTS(SELECT * FROM worktual_currency_master_dtl a where a.curr_name = curr_name LIMIT 1) then
 				
             SET errcode = -1;
             set errmsg = 'currency name already exist';
             LEAVE sp_exit;
          end if;
 
 			INSERT INTO worktual_currency_master_dtl(curr_name,curr_status,curr_created_date)
 			VALUES(curr_name,curr_status,now);
 		   					
          if ROW_COUNT() > 0 then
 						
             SET errcode = 0;
             set errmsg = 'Success : currency created';
             LEAVE sp_exit;
          end if;
       end if;
 
       IF processtype = 2 then
 	
          IF EXISTS(SELECT * FROM worktual_currency_master_dtl a where a.curr_name = curr_name and a.curr_id <> curr_id LIMIT 1) then
 		
             SET errcode = -1;
             set errmsg = 'currency name already exist';
             LEAVE sp_exit;
          end if;
 
          UPDATE worktual_currency_master_dtl a set a.curr_name = IFNULL(curr_name,a.curr_name),a.curr_created_date = IFNULL(now,a.curr_created_date),
          a.curr_status = IFNULL(curr_status,a.curr_status)
          where a.curr_id = curr_id;
 
          if ROW_COUNT() > 0 then
 				
             SET errcode = 0;
             set errmsg = 'Success : currency name updated';
             LEAVE sp_exit;
          end if;
       end if;
 
       IF processtype = 3 then
 		
          IF NOT EXISTS(SELECT * FROM worktual_currency_master_dtl a where a.curr_id = curr_id LIMIT 1) then
 				
             SET errcode = -1;
             set errmsg = 'currency ID not exists';
             LEAVE sp_exit;
          end if;
 
          update worktual_currency_master_dtl a set a.curr_status = 3 where a.curr_id = curr_id;
          
 		 if ROW_COUNT() > 0 then
 				
             SET errcode = 0;
             set errmsg = 'Deleted : currency name deleted';
             LEAVE sp_exit;
          end if;
       end if;
    END;
 
    select errcode as errcode,errmsg as errmsg;
 
 
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_create_feature_field_map_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_create_feature_field_map_details`(
  feature_id int,
  fk_config_id int,
  feature_config LONGTEXT
  )
begin
  
  	
  
  
  	declare errcode int; 
  	declare errmsg varchar(160);
      declare xml_label_name varchar(100);
      declare xml_label_value varchar(100);
  
  	DROP TEMPORARY TABLE IF EXISTS tt_feature_range_xml_structure;
  	create TEMPORARY table tt_feature_range_xml_structure
  	(
  		id int AUTO_INCREMENT PRIMARY KEY,
         feature_id int,
 		fk_config_id int,
  		label_name varchar(100),
  		label_value varchar(100)
  	 );
  
  	drop temporary table if exists xml_label_name_tbl; create temporary table xml_label_name_tbl(id int auto_increment primary key, label_name varchar(100));
  	drop temporary table if exists xml_label_value_tbl; create temporary table xml_label_value_tbl(id int auto_increment primary key, label_value varchar(100));
  
  	SELECT	REPLACE(EXTRACTVALUE(feature_config, '//label_name[1]'),' ',','),
  			REPLACE(EXTRACTVALUE(feature_config, '//label_value[1]'),' ',',')
  	INTO xml_label_name, xml_label_value;
  
  	call Split(xml_label_name,','); insert into xml_label_name_tbl(label_name) select Items from tt_Split_temptable;
  	call Split(xml_label_value,','); insert into xml_label_value_tbl(label_value) select Items from tt_Split_temptable;
  
  	INSERT INTO tt_feature_range_xml_structure(feature_id,fk_config_id,label_name,label_value)
  	select feature_id,fk_config_id,a.label_name,b.label_value
  	from xml_label_name_tbl a 
  	left join xml_label_value_tbl b on a.id = b.id;
  
  	if exists(select * from wtms_feature_field_map_details a where a.fk_feature_id=feature_id limit 1) then
  		delete from wtms_feature_field_map_details a where a.fk_feature_id=feature_id;
  	end if;
  	
  	insert into wtms_feature_field_map_details(fk_feature_id,fk_config_id,value,value_Desc)
  	select Distinct feature_id,fk_config_id,a.label_value,''
  	from tt_feature_range_xml_structure a;
  
  	IF ROW_COUNT()>0 then
  		SET errcode=0;
  		SET errmsg='Success';
  	END if;
  
  
  End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_create_feature_master` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_create_feature_master`(
  	feature_id INT,
  	fk_prod_id INT,
  	fk_sub_prod INT,
  	fk_category_id INT,
  	fk_level_id INT,
  	feature_name VARCHAR(255),
  	feature_desc text,
  	feature_usability INT,
  	fk_config_id INT,
  	no_of_fields INT,
  	tariff VARCHAR(10),
  	price FLOAT,
  	status INT,
  	user_type VARCHAR(20),
  	max_user_in_grp INT,
  	feature_map LONGTEXT,
  	create_by VARCHAR(50),
  	process_type INT, 
  	accessibility int,	
  	main_menu_id int,
  	sub_menu_id int,
  	feature_type_status int,
  	summary_notes text,
     p_position int
      )
BEGIN
      
      	
      
      
      
      
         DECLARE v_errcode INT;
         DECLARE v_errmsg VARCHAR(160);
         DECLARE v_Category_name VARCHAR(255);
         DECLARE v_now DATETIME(3);
      	
         IF feature_id is null then
            set feature_id = 0;
         END IF;
         IF tariff is null then
            set tariff = '';
         END IF;
         IF price is null then
            set price = 0;
         END IF;
         IF user_type is null then
            set user_type = '';
         END IF;
         IF max_user_in_grp is null then
            set max_user_in_grp = 0;
         END IF;
         IF feature_map is null then
            set feature_map = '';
         END IF;
         IF create_by is null then
            set create_by = 'admin';
         END IF;
         sp_exit:
         BEGIN
            IF feature_id is null then
               set feature_id = 0;
            END IF;
            IF tariff is null then
               set tariff = '';
            END IF;
            IF price is null then
               set price = 0;
            END IF;
            IF user_type is null then
               set user_type = '';
            END IF;
            IF max_user_in_grp is null then
               set max_user_in_grp = 0;
            END IF;
            IF feature_map is null then
               set feature_map = '';
            END IF;
            IF create_by is null then
               set create_by = 'admin';
            END IF;
            Set v_errcode = -1;
            set v_errmsg = 'Failure to create feature Master';
            set v_now = CURRENT_TIMESTAMP;
            if feature_name is null or feature_name = '' then
      		
               Set v_errcode = -1;
               set v_errmsg = 'Feature name should not be empty';
               LEAVE sp_exit;
            end if;
      	
      	
            select   a.category_Name INTO v_Category_name from wtms_feature_category a where a.Category_id = fk_category_id;
      
      	
            IF process_type = 1
            then
               IF EXISTS(SELECT  * FROM wtms_feature_info b where b.feature_name = feature_name and b.fk_category_id = fk_category_id LIMIT 1) 
               then
                  Set v_errcode = -1;
                  Set v_errmsg = 'Same feature already exists for this category!';
                  LEAVE sp_exit;
               end if;
               
               insert into wtms_feature_info(fk_category_id,fk_level_id,feature_name,feature_description,feature_usability,fk_config_id,no_fields,tariff,price,
      		status,user_type,create_date,category_name,create_by,max_user_in_grp,accessibility,main_menu_id,sub_menu_id,feature_type_status,summary_notes,position)
      		values(fk_category_id,fk_level_id,feature_name,feature_desc,feature_usability,fk_config_id,no_of_fields,tariff,price,
      		status,user_type,v_now,v_Category_name,create_by,max_user_in_grp,accessibility,main_menu_id,sub_menu_id,feature_type_status,summary_notes,p_position);
      		
               set feature_id = LAST_INSERT_ID();
               
               IF ROW_COUNT() > 0 
               then
                  Set v_errcode = 0;
                  Set v_errmsg = 'Success!';
               end if;
            end if;
      	
      	
            IF process_type = 2 
            then
               IF not EXISTS(SELECT * FROM wtms_feature_info c where c.feature_id = feature_id LIMIT 1) 
               then
                  Set v_errcode = -1;
                  Set v_errmsg = 'feature not exists!';
                  LEAVE sp_exit;
               end if;
               UPDATE wtms_feature_info a
               Set a.fk_category_id = IFNULL(fk_category_id,
   				a.fk_category_id),
   				a.fk_level_id = IFNULL(fk_level_id,a.fk_level_id),
   				a.feature_name = IFNULL(feature_name,a.feature_name),
   				a.feature_description = IFNULL(feature_desc,a.feature_description),
   				a.feature_usability = IFNULL(feature_usability,a.feature_usability),
   				a.fk_config_id = IFNULL(fk_config_id,a.fk_config_id),
   				a.no_fields = IFNULL(no_of_fields,a.no_fields),
   				a.tariff = IFNULL(tariff,a.tariff),
   				a.price = IFNULL(price,a.price),
   				a.status = IFNULL(status,a.status),
   				a.user_type = IFNULL(user_type,a.user_type),
   				a.create_date = v_now,
   				a.category_name = IFNULL(v_Category_name,a.category_name),
   				a.create_by = IFNULL(create_by,a.create_by),
   				a.max_user_in_grp = IFNULL(max_user_in_grp,a.max_user_in_grp),
   				a.accessibility = ifnull(accessibility,a.accessibility),
   				a.main_menu_id = ifnull(main_menu_id,a.main_menu_id),
   				a.sub_menu_id = ifnull(sub_menu_id,a.sub_menu_id),
   				a.feature_type_status = ifnull(feature_type_status,a.feature_type_status),
                  a.summary_notes = ifnull(summary_notes,a.summary_notes),
                  a.position = ifnull(p_position,position)
               WHERE a.feature_id = feature_id;
               IF ROW_COUNT() > 0 
               then
                  Set v_errcode = 0;
                  Set v_errmsg = CONCAT(feature_name,' details are updated!');
               end if;
            end if;
            
            if feature_map is not null 
            then
               CALL worktual_create_feature_field_map_details(feature_id,fk_config_id,feature_map);
               IF ROW_COUNT() > 0 
               then
                  Set v_errcode = 0;
                  Set v_errmsg = 'Success!';
               end if;
            end if;
            IF process_type = 3 
            then
               IF not EXISTS(SELECT  * FROM wtms_feature_info c where c.feature_id = feature_id LIMIT 1) 
               then
                  Set v_errcode = -1;
                  Set v_errmsg = 'feature not exists!';
                  LEAVE sp_exit;
               end if;
               
               UPDATE wtms_feature_info a set a.status = 3
               where a.feature_id = feature_id;
               
               if ROW_COUNT() > 0 
               then
                  SET v_errcode = 0;
                  set v_errmsg = 'Success to delete feature.';
                  LEAVE sp_exit;
               end if;
            end if;
         END;
         select v_errcode as errcode,v_errmsg as errmsg,IFNULL(feature_id,0) as feature_id;
      	
      END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_create_groups_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_create_groups_dtl`(
 group_id INT,
 group_name VARCHAR(155),
 group_status INT,
 processtype INT 
 )
begin
 
 
 	
    DECLARE v_errcode INT;
    DECLARE v_errmsg VARCHAR(160);
    DECLARE v_now DATETIME(3);
 	
    IF group_id is null then
       set group_id = 0;
    END IF;
    sp_exit:
    BEGIN
       IF group_id is null then
          set group_id = 0;
       END IF;
       set v_errcode = -1;
       set v_errmsg = 'Failure';
       set v_now = CURRENT_TIMESTAMP;
       IF processtype = 1 then
 			
          IF EXISTS(SELECT  * FROM worktual_groups_master_dtl a where a.group_name = group_name LIMIT 1) 
          then
             SET v_errcode = -1;
             set v_errmsg = 'group name already exist';
             LEAVE sp_exit;
          end if;
          
          INSERT INTO worktual_groups_master_dtl(group_name,group_status,group_created_date)
 				   VALUES(group_name,group_status,v_now);
 				   
          set group_id = LAST_INSERT_ID();
          
          if ROW_COUNT() > 0 
          then
             SET v_errcode = 0;
             set v_errmsg = 'Success : group created';
             LEAVE sp_exit;
          end if;
       end if;
       
       IF processtype = 2 then
 	
          IF EXISTS(SELECT  * FROM worktual_groups_master_dtl b where b.group_name = group_name and b.group_id <> group_id LIMIT 1) 
          then
             SET v_errcode = -1;
             set v_errmsg = 'group name already exist';
             LEAVE sp_exit;
          end if;
          
          UPDATE worktual_groups_master_dtl a 
          set a.group_name = IFNULL(group_name,a.group_name),
          a.group_created_date = IFNULL(v_now,a.group_created_date),
          a.group_status = IFNULL(group_status,a.group_status)
          where a.group_id = group_id;
          
          if ROW_COUNT() > 0 
          then
             SET v_errcode = 0;
             set v_errmsg = 'Success : group name updated';
             LEAVE sp_exit;
          end if;
       end if;
       IF processtype = 3 then
 		
          IF NOT EXISTS(SELECT  * FROM worktual_groups_master_dtl d where d.group_id = group_id LIMIT 1) 
          then
             SET v_errcode = -1;
             set v_errmsg = 'group ID not exist';
             LEAVE sp_exit;
          end if;
          
          update worktual_groups_master_dtl f set f.group_status = 3 where f.group_id = group_id;
          
          if ROW_COUNT() > 0 
          then
             SET v_errcode = 0;
             set v_errmsg = 'Deleted : group name deleted';
             LEAVE sp_exit;
          end if;
       end if;
    END;
    select v_errcode as errcode,v_errmsg as errmsg,IFNULL(group_id,0) as group_id;
 
 
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_create_Menu_Info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_create_Menu_Info`(
Menu_Name VARCHAR(250),
Menu_link VARCHAR(250),
process_type INT,
Menu_Id INT,
status INT,
position INT
)
BEGIN

   DECLARE v_errcode INT; 
   DECLARE v_errmsg VARCHAR(250);
   IF Menu_Id is null then
      set Menu_Id = 0;
   END IF;
   sp_exit:
   BEGIN
      IF Menu_Id is null then
         set Menu_Id = 0;
      END IF;
      BEGIN
         DECLARE EXIT HANDLER FOR SQLEXCEPTION
         begin
            Set v_errcode = -1;
            GET DIAGNOSTICS CONDITION 1 @SWV_ErrorMsg = MESSAGE_TEXT;
            Set v_errmsg = @SWV_ErrorMsg;
         end;
         
         IF process_type = 1 
         then
            IF EXISTS(SELECT  * FROM wtms_tbl_Menu b where b.Menu_Name = Menu_Name LIMIT 1) 
            then
               Set v_errcode = -1;
               Set v_errmsg = 'Menu Name already exists!';
               LEAVE sp_exit;
            end if;
            
            INSERT INTO wtms_tbl_Menu(Menu_Name,Menu_link,`position`)
		VALUES(Menu_Name,Menu_link,position);
		
            set Menu_Id = LAST_INSERT_ID();
            
            IF ROW_COUNT() > 0 
            then
               Set v_errcode = 0;
               Set v_errmsg = 'Success to create menu info.';
               LEAVE sp_exit;
            end if;
         end if;
         IF process_type = 2 then
	
            IF NOT EXISTS(SELECT  * FROM wtms_tbl_Menu c where c.Pk_Menu_Id = Menu_Id LIMIT 1) 
            then
		
               Set v_errcode = -1;
               Set v_errmsg = 'MenuID not exists!';
               LEAVE sp_exit;
            end if;
            IF EXISTS(SELECT  * FROM wtms_tbl_Menu b where b.Pk_Menu_Id <> Menu_Id and b.Menu_Name = Menu_Name LIMIT 1)
            then
               Set v_errcode = -1;
               Set v_errmsg = 'Menu Name already exists!';
               LEAVE sp_exit;
            end if;
            
            Update wtms_tbl_Menu c set c.Menu_Name = Menu_Name,c.Menu_link = Menu_link,c.status = status,c.`position` = position
            Where c.Pk_Menu_Id = Menu_Id;
            IF ROW_COUNT() > 0 then
		
               Set v_errcode = 0;
               Set v_errmsg = 'Success to create menu info.';
               LEAVE sp_exit;
            end if;
         end if;
      END;
   END;
   Select v_errcode as errcode,v_errmsg as errmsg, IFNULL(Menu_Id,0) as Menu_Id;
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_create_no_of_users_info_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_create_no_of_users_info_dtl`(
  nof_id INT ,
  users_type INT, 
  `from` INT,
  `to` INT,
  min_users INT,
  status INT,
  processtype INT)
Begin
  
  
  
     DECLARE v_user_cnt VARCHAR(50);
     DECLARE v_errcode INT;
     DECLARE v_errmsg VARCHAR(120);
     DECLARE v_now DATETIME(3);
  
  
     IF nof_id is null then
        set nof_id = 0;
     END IF;
     IF `to` is null then
        set `to` = 0;
     END IF;
     sp_exit:
     BEGIN
        IF nof_id is null then
           set nof_id = 0;
        END IF;
        IF `to` is null then
           set `to` = 0;
        END IF;
        set v_now = CURRENT_TIMESTAMP;
        if users_type = 1 then 
  	
           set v_user_cnt = `from`;
        else
           set v_user_cnt = CONCAT(cast(`from` as CHAR(30)),' to ',cast(`to` as CHAR(30)));
        end if;
        
        
        if processtype = 1 then
  	
           if exists(select  * from wtms_no_of_users_master a where a.nof_users_description = v_user_cnt LIMIT 1) 
           then
              set v_errcode = -1;
              set v_errmsg = 'These count/range already exists';
              LEAVE sp_exit;
           end if;
           
           insert into wtms_no_of_users_master(nof_from, nof_to, nof_users_description, nof_min_user, status, create_date,user_type)
  		values(`from`, `to`, v_user_cnt, min_users,status,v_now,users_type);
  		
           set nof_id = LAST_INSERT_ID();
           set v_errcode = 0;
           set v_errmsg = 'no of users created';
           LEAVE sp_exit;
        end if;
        
        
        if processtype = 2 
        then
           if not exists(select  * from wtms_no_of_users_master a where a.nof_id = nof_id LIMIT 1) 
           then
              set v_errcode = -1;
              set v_errmsg = 'These range not exists';
              LEAVE sp_exit;
           end if;
           if exists(select  * from wtms_no_of_users_master a where a.nof_users_description = v_user_cnt and a.nof_id <> nof_id LIMIT 1) 
           then
              set v_errcode = -1;
              set v_errmsg = 'These range already exists';
              LEAVE sp_exit;
           end if;
           
           UPDATE wtms_no_of_users_master a
           set	a.nof_from = IFNULL(`from`,a.nof_from),
           a.nof_to = case when users_type = 2 then IFNULL(`to`,a.nof_to) else 0 end,
           a.nof_users_description = IFNULL(v_user_cnt,a.nof_users_description),
           a.nof_min_user = IFNULL(min_users,a.nof_min_user),
           a.status = IFNULL(status,a.status),
           a.create_date = v_now,
           a.user_type = IFNULL(users_type,a.user_type)
           where a.nof_id = nof_id;
           
           set v_errcode = 0;
           set v_errmsg = 'no of users updated';
           LEAVE sp_exit;
        end if;
        
        if processtype = 3 then
  	
           if not exists(select  * from wtms_no_of_users_master a where a.nof_id = nof_id LIMIT 1)
           then
              set v_errcode = -1;
              set v_errmsg = 'user range not exists';
              LEAVE sp_exit;
              
           end if;
           
           update wtms_no_of_users_master b set b.status = 3 where b.nof_id = nof_id;
           set v_errcode = 0;
           set v_errmsg = 'user range deleted';
           LEAVE sp_exit;
        end if;
     END;
     select v_errcode as errcode, v_errmsg as errmsg, IFNULL(nof_id,0) as nof_id;
  	
  End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_create_prod_wise_Category_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_create_prod_wise_Category_info`(
 category_id INT ,
 fk_prod_id INT,
 category_Name VARCHAR(255),
 category_description VARCHAR(255),
 category_position INT,
 process_type INT,
 status INT)
BEGIN
 
 	
    DECLARE v_errcode INT;
    DECLARE v_errmsg VARCHAR(160);
    DECLARE v_now DATETIME(3);
 
    IF category_id is null then
       set category_id = 0;
    END IF;
    sp_exit:
    BEGIN
       IF category_id is null then
          set category_id = 0;
       END IF;
       set v_now = CURRENT_TIMESTAMP;
       Set v_errcode = -1;
       set v_errmsg = 'Failure to create Category ';
       if category_Name is null or category_Name = '' then
 		
          Set v_errcode = -1;
          set v_errmsg = 'Failure to create Category ';
       end if;
 		
 		
       IF process_type = 1 
       then
          IF EXISTS(SELECT * FROM wtms_feature_prod_wise_category a where a.Category_Name = category_Name and a.fk_prod_id = fk_prod_id LIMIT 1) 
          then
             Set v_errcode = -1;
             Set v_errmsg = 'Category already exists!';
             LEAVE sp_exit;
          end if;
          
          INSERT INTO wtms_feature_prod_wise_category(category_Name,fk_prod_id,category_description,category_status,category_position,create_date)
 			VALUES(category_Name,fk_prod_id,category_description,status,category_position,v_now);
 			
          set category_id = LAST_INSERT_ID();
          IF ROW_COUNT() > 0 
          then
             Set v_errcode = 0;
             Set v_errmsg = 'New category is created!';
             LEAVE sp_exit;
          end if;
       end if;
 		
 		
       IF process_type = 2 then
          IF NOT EXISTS(SELECT  * FROM wtms_feature_prod_wise_category b where b.Category_id = category_id LIMIT 1) 
          then
             Set v_errcode = -1;
             Set v_errmsg = 'Category not found!';
             LEAVE sp_exit;
          end if;
          IF EXISTS(SELECT  * FROM wtms_feature_prod_wise_category  c where c.Category_Name = category_Name
          and c.fk_prod_id = fk_prod_id and c.Category_id <> category_id LIMIT 1)
          then
             Set v_errcode = -1;
             Set v_errmsg = 'Category already exists!';
             LEAVE sp_exit;
          end if;
          
          UPDATE wtms_feature_prod_wise_category a
          Set a.category_name = category_Name,a.fk_prod_id = fk_prod_id,
			  a.category_description = category_description,a.category_status = status,
			  a.category_position = category_position,a.create_date = v_now
		   where a.category_id = category_id;
           
          IF ROW_COUNT() > 0 
          then
             Set v_errcode = 0;
             Set v_errmsg = CONCAT(category_Name,' details are updated!');
             LEAVE sp_exit;
          end if;
       end if;
 
 		
      
      IF process_type = 3
      then
          IF NOT EXISTS(SELECT  * FROM wtms_feature_prod_wise_category c where c.Category_id = category_id LIMIT 1) 
          then
             Set v_errcode = -1;
             Set v_errmsg = 'Category not found!';
             LEAVE sp_exit;
          end if;
          
          update wtms_feature_prod_wise_category b set b.category_status = 3 where b.Category_id = category_id;
          IF ROW_COUNT() > 0 
          then
             Set v_errcode = 0;
             Set v_errmsg = 'Success to Deleted Category Name info!';
             LEAVE sp_exit;
          end if;
       end if;
    END;
    select v_errcode as errcode,v_errmsg as errmsg, IFNULL(category_id,0) as category_id;
 	
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_create_prod_wise_feature_master` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_create_prod_wise_feature_master`(
addon_feature_id INT,
fk_prod_id INT,
fk_category_id INT,
tier_id varchar(255), 
fk_level_id INT,
addon_feature_name VARCHAR(255),
addon_feature_desc VARCHAR(255),
addon_feature_usability INT,
price float,
status INT,
user_type VARCHAR(20),
create_by VARCHAR(50),
process_type INT, 
p_bundle_id		int,
p_image_name varchar(200),
p_lang_code varchar(10)
  )
BEGIN
             
                DECLARE v_errcode INT;
                DECLARE v_errmsg VARCHAR(160);
                DECLARE v_Category_name VARCHAR(255);
                DECLARE v_now DATETIME(3);
             	
                IF addon_feature_id is null then set addon_feature_id = 0; END IF;
                IF price is null then set price = 0; END IF;
                IF create_by is null then set create_by = 'admin'; END IF;
                
                sp_exit:
                BEGIN
         
                   Set v_errcode = -1;
                   set v_errmsg = 'Failure to create feature Master';
                   set v_now = CURRENT_TIMESTAMP;
                   if addon_feature_name is null or addon_feature_name = '' then
             		
                      Set v_errcode = -1;
                      set v_errmsg = 'Feature name should not be empty';
                      LEAVE sp_exit;
                   end if;
             	
             	
                   select   a.category_Name INTO v_Category_name from wtms_feature_prod_wise_category a where a.Category_id = fk_category_id;
             
             	
                   IF process_type = 1
                   then
                      
         			insert into wtms_prod_wise_feature_info(fk_category_id,fk_level_id,addon_feature_name,addon_feature_description,addon_feature_usability,price, status,user_type
     							,create_date,category_name,create_by,tier_id,bundle_id,image_name,lang_code)
         			values(fk_category_id,fk_level_id,addon_feature_name,addon_feature_desc,addon_feature_usability,price, status,user_type,v_now,v_Category_name,create_by,tier_id,p_bundle_id,p_image_name,p_lang_code);
             		
                      set addon_feature_id = LAST_INSERT_ID();
                      
                      IF ROW_COUNT() > 0 
                      then
                         Set v_errcode = 0;
                         Set v_errmsg = 'Success!';
                      end if;
                   end if;
             	
             	
                   IF process_type = 2 
                   then
                      IF not EXISTS(SELECT * FROM wtms_prod_wise_feature_info c where c.addon_feature_id = addon_feature_id LIMIT 1) 
                      then
                         Set v_errcode = -1;
                         Set v_errmsg = 'feature not exists!';
                         LEAVE sp_exit;
                      end if;
                      
                      UPDATE wtms_prod_wise_feature_info a
                      Set a.fk_category_id = IFNULL(fk_category_id,
          				a.fk_category_id),
          				a.fk_level_id = IFNULL(fk_level_id,a.fk_level_id),
          				a.addon_feature_name = IFNULL(addon_feature_name,a.addon_feature_name),
          				a.addon_feature_description = IFNULL(addon_feature_desc,a.addon_feature_description),
          				a.addon_feature_usability = IFNULL(addon_feature_usability,a.addon_feature_usability),
          				a.price = IFNULL(price,a.price),
          				a.status = IFNULL(status,a.status),
          				a.user_type = IFNULL(user_type,a.user_type),
          				a.create_date = v_now,
          				a.category_name = IFNULL(v_Category_name,a.category_name),
          				a.create_by = IFNULL(create_by,a.create_by),
                         a.tier_id = ifnull(tier_id,a.tier_id),
                         a.bundle_id = p_bundle_id,
                         a.image_name = ifnull(p_image_name,a.image_name),
                         a.lang_code = ifnull(p_lang_code,a.lang_code)
                      WHERE a.addon_feature_id = addon_feature_id;
                      IF ROW_COUNT() > 0 
                      then
                         Set v_errcode = 0;
                         Set v_errmsg = CONCAT(addon_feature_name,' details are updated!');
                      end if;
                   end if;
                   
         
                   IF process_type = 3 
                   then
                      IF not EXISTS(SELECT  * FROM wtms_prod_wise_feature_info c where c.addon_feature_id = addon_feature_id LIMIT 1) 
                      then
                         Set v_errcode = -1;
                         Set v_errmsg = 'feature not exists!';
                         LEAVE sp_exit;
                      end if;
                      
                      UPDATE wtms_prod_wise_feature_info a set a.status = 3
                      where a.addon_feature_id = addon_feature_id;
                      
                      if ROW_COUNT() > 0 
                      then
                         SET v_errcode = 0;
                         set v_errmsg = 'Success to delete feature.';
                         LEAVE sp_exit;
                      end if;
                   end if;
                END;
                select v_errcode as errcode,v_errmsg as errmsg,IFNULL(addon_feature_id,0) as addon_feature_id;
             	
             END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_create_roles_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_create_roles_dtl`(
role_id INT,
role_name VARCHAR(155),
role_status INT,
processtype INT 
)
begin

	
   DECLARE v_errcode INT;
   DECLARE v_errmsg VARCHAR(160);
   DECLARE v_now DATETIME(3);
	
   IF role_id is null then
      set role_id = 0;
   END IF;
   sp_exit:
   BEGIN
      IF role_id is null then
         set role_id = 0;
      END IF;
      set v_errcode = -1;
      set v_errmsg = 'Failure';
      set v_now = CURRENT_TIMESTAMP;
      
      
      IF processtype = 1
      then
         IF EXISTS(SELECT  * FROM worktual_roles_master_dtl a where a.role_name = role_name LIMIT 1) 
         then
            SET v_errcode = -1;
            set v_errmsg = 'Role name already exist';
            LEAVE sp_exit;
         end if;
         
         INSERT INTO worktual_roles_master_dtl(role_name,role_status,role_created_date)
				   VALUES(role_name,role_status,v_now);
					
         set role_id = LAST_INSERT_ID();
         
         if ROW_COUNT() > 0
         then
            SET v_errcode = 0;
            set v_errmsg = 'Success : Role created';
            LEAVE sp_exit;
         end if;
      end if;
      
      IF processtype = 2 
      then
         IF EXISTS(SELECT  * FROM worktual_roles_master_dtl b where b.role_name = role_name and b.role_id <> role_id LIMIT 1) 
         then
            SET v_errcode = -1;
            set v_errmsg = 'Role name already exist';
            LEAVE sp_exit;
         end if;
         
         UPDATE worktual_roles_master_dtl a 
         set a.role_name = IFNULL(role_name,a.role_name),
         a.role_created_date = IFNULL(v_now,a.role_created_date),
         a.role_status = IFNULL(role_status,a.role_status)
         where a.role_id = role_id;
         
         if ROW_COUNT() > 0
         then
            SET v_errcode = 0;
            set v_errmsg = 'Success : Role name updated';
            LEAVE sp_exit;
         end if;
      end if;
      
      IF processtype = 3
      then
         update worktual_roles_master_dtl e set e.role_status = 3  where e.role_id = role_id;
         
         if ROW_COUNT() > 0 
         then
            SET v_errcode = 0;
            set v_errmsg = 'Deleted : Role name daleted';
            LEAVE sp_exit;
         end if;
      end if;
   END;
   select v_errcode as errcode,v_errmsg as errmsg,IFNULL(role_id,0) as role_id;




end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_create_Role_Menu_Mapping` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_create_Role_Menu_Mapping`(
Role_ID INT,
Role_Name VARCHAR(50),
menu_id LONGTEXT,
process_type INT,
status INT
)
BEGIN

	
	
   DECLARE errcode INT; 
   DECLARE errmsg VARCHAR(250);

   Sp_exit:
   BEGIN
      DROP TEMPORARY TABLE IF EXISTS tt_temp_menu;
      create TEMPORARY table tt_temp_menu
      (
         menu_id VARCHAR(50)
      );
	
	
	
      SET errcode = -1;
      SET errmsg = 'Failure to do role Mapping.';

      if Role_Name = '' or Role_Name is null then
	
         SET errcode = -1;
         SET errmsg = 'Role_Name should not be empty.';
         LEAVE Sp_exit;
      end if;

      If process_type = 1 then
	
         if exists(select * FROM worktual_roles_master_dtl a where a.role_name = Role_Name LIMIT 1) then
		
            SET errcode = -1;
            SET errmsg = 'Role name already exist!.';
            LEAVE Sp_exit;
         end if;

         If not exists(select * FROM worktual_roles_master_dtl a where a.role_name = Role_Name LIMIT 1) then
			
			insert into worktual_roles_master_dtl(role_name,role_created_date,role_status)
			values(Role_Name,CURRENT_TIMESTAMP,status);
				
            set Role_ID = LAST_INSERT_ID();
         end if;

         BEGIN
            DECLARE EXIT HANDLER FOR SQLEXCEPTION
            begin
               SET errcode = -1;
               SET errmsg = 'Please check Input details!';
            end; 
		

			call Split(menu_id,',');
		 
			insert into tt_temp_menu(menu_id)
			select Items from tt_Split_temptable;
		 
		 
		 
            Delete from wtms_Role_Menu_Mapping a where a.Fk_Role_ID = Role_ID
            AND a.Fk_Menu_ID IN(select a.menu_id from tt_temp_menu b);
		 
		 
            INSERT INTO wtms_Role_Menu_Mapping(Fk_Role_ID,Fk_Menu_ID,Last_update)
            Select Role_ID,b.menu_id,CURRENT_TIMESTAMP FROM  tt_temp_menu b;

            IF ROW_COUNT() > 0 then
		
               SET errcode = 0;
               SET errmsg = 'New role is created.';
            end if;
         END;
      end if;

      If process_type = 2 then
	
         If exists(select * FROM worktual_roles_master_dtl a where a.role_name = Role_Name and a.role_id <> Role_ID LIMIT 1) then
		
            SET errcode = -1;
            SET errmsg = 'Role name already exist!.';
            LEAVE Sp_exit;
         end if;

         If not exists(select * FROM worktual_roles_master_dtl a where a.role_id = Role_ID LIMIT 1) then
		
            SET errcode = -1;
            SET errmsg = 'Role ID not exist!.';
            LEAVE Sp_exit;
         end if;

         update worktual_roles_master_dtl a
         set a.role_name = Role_Name,a.role_created_date = CURRENT_TIMESTAMP,a.role_status = status
         where a.role_id = Role_ID;
		
		
         BEGIN
            DECLARE EXIT HANDLER FOR SQLEXCEPTION
            begin
               SET errcode = -1;
               SET errmsg = 'Please check Input details!';
            end;


			call Split(menu_id,',');

			insert into tt_temp_menu(menu_id)
			select Items from tt_Split_temptable;
		 
		 
		 
            Delete from wtms_Role_Menu_Mapping where Fk_Role_ID = Role_ID;
		 
		 
            INSERT INTO wtms_Role_Menu_Mapping(Fk_Role_ID,Fk_Menu_ID,Last_update)
            Select Role_ID,a.menu_id,CURRENT_TIMESTAMP FROM tt_temp_menu a;

            IF ROW_COUNT() > 0 then
		
               SET errcode = 0;
               SET errmsg = CONCAT(Role_Name,' details are updated.');
            end if;

         END;
      end if;
   END;
   select errcode as errcode,errmsg as errmsg;
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_create_tier_category_position` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_create_tier_category_position`(
  tier_id INT,
  tier_category_position LONGTEXT,
  create_by VARCHAR(50)
  )
begin
  
  
  
     DECLARE v_hDoc INT; 
     DECLARE v_errcode INT; 
     DECLARE v_errmsg VARCHAR(160);
     DECLARE v_now DATETIME(3);
     DECLARE v_catg_id text;
     DECLARE v_catg_pos text;
     
     DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
     BEGIN
        SET @SWV_Error = 1;
     END;
     IF create_by is null then
        set create_by = 'admin';
     END IF;
     SET @SWV_Error = 0;
     BEGIN
        DECLARE EXIT HANDLER FOR SQLEXCEPTION
        begin
           SET v_errcode = @SWV_Error;
           GET STACKED DIAGNOSTICS CONDITION 1 v_errmsg = MESSAGE_TEXT;
           select v_errcode as errcode, v_errmsg as errmsg;
        end;
        set v_now = CURRENT_TIMESTAMP;

        DROP TEMPORARY TABLE IF EXISTS tt_tier_category_position_xml;
        create TEMPORARY table tt_tier_category_position_xml
        (
           id INT   AUTO_INCREMENT PRIMARY KEY,
           tier_id INT,
           catg_id INT,
           catg_pos INT
        )  AUTO_INCREMENT = 1;
       
 			drop temporary table if exists xml_catg_id_tbl; create temporary table xml_catg_id_tbl(id int auto_increment primary key,catg_id int);
 			drop temporary table if exists xml_catg_pos_tbl; create temporary table xml_catg_pos_tbl(id int auto_increment primary key,catg_pos int);
 
 			SELECT replace(ExtractValue(tier_category_position, '//catg_id[1]'),' ',','), 
 			replace(ExtractValue(tier_category_position, '//catg_pos[1]'),' ',',') into v_catg_id, v_catg_pos;
                   
 			drop table if exists tt_Split_temptable; call Split(v_catg_id,','); insert into xml_catg_id_tbl(catg_id) select Items from tt_Split_temptable;
 			drop table if exists tt_Split_temptable; call Split(v_catg_pos,','); insert into xml_catg_pos_tbl(catg_pos) select Items from tt_Split_temptable;
                         
 			INSERT INTO tt_tier_category_position_xml(tier_id,catg_id,catg_pos)
 			select tier_id,a.catg_id,b.catg_pos
 			from xml_catg_id_tbl a 
 			left join xml_catg_pos_tbl b on a.id = b.id;
       
 		  if exists(select  * from wtms_tier_category_position a where  a.fk_tier_id = tier_id LIMIT 1)
 		  then
 			  delete from wtms_tier_category_position where fk_tier_id = tier_id;
 		   end if;
        
        insert into wtms_tier_category_position(fk_tier_id,catg_id,catg_pos)
        select Distinct tier_id,catg_id,catg_pos
        from tt_tier_category_position_xml;
        
        IF ROW_COUNT() > 0 
        then
  		
           if not exists(select  1 from wtms_tier_category_position_MT a where a.fk_tier_id = tier_id LIMIT 1) 
           then
  			  insert into wtms_tier_category_position_MT(fk_tier_id,catg_id,catg_pos)
              select Distinct tier_id,catg_id,catg_pos
              from tt_tier_category_position_xml;
           end if;
           SET v_errcode = 0;
           SET v_errmsg = 'Inserted';
        end if;
     END; 
  End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_create_tier_catg_feature_map` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_create_tier_catg_feature_map`(
  tier_id INT,
  catg_feature_map_xml LONGTEXT,
  create_by VARCHAR(50))
begin
  
  
  
     DECLARE v_hDoc INT; 
     DECLARE v_errcode INT; 
     DECLARE v_errmsg VARCHAR(160);
     DECLARE v_now DATETIME(3);
     DECLARE v_tiertype text; 
     DECLARE v_prodid text; 
     DECLARE v_subprodid text; 
     DECLARE v_categoryid text; 
     DECLARE v_featureid text; 
     
     DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
     BEGIN
        SET @SWV_Error = 1;
     END;
     IF create_by is null then
        set create_by = 'admin';
     END IF;
     SET @SWV_Error = 0;
     BEGIN
        DECLARE EXIT HANDLER FOR SQLEXCEPTION
        begin
           SET v_errcode = @SWV_Error;
           GET STACKED DIAGNOSTICS CONDITION 1 v_errmsg = MESSAGE_TEXT;
           select v_errcode as errcode, v_errmsg as errmsg;
        end;
        set v_now = CURRENT_TIMESTAMP;
 
        DROP TEMPORARY TABLE IF EXISTS tt_tier_catgfeature_mapping_xml;
        create TEMPORARY table tt_tier_catgfeature_mapping_xml
        (
           id INT   AUTO_INCREMENT PRIMARY KEY,
           tier_id INT,
           tiertype INT,
           product_id INT,
           sub_product_id INT,
           categoryid INT,
           featureid INT
        )  AUTO_INCREMENT = 1;
        
 
      	    drop temporary table if exists xml_tiertype_tbl; create temporary table xml_tiertype_tbl(id int auto_increment primary key,tiertype int);
    			drop temporary table if exists xml_prodid_tbl; create temporary table xml_prodid_tbl(id int auto_increment primary key,prodid int);
    			drop temporary table if exists xml_subprodid_tbl; create temporary table xml_subprodid_tbl(id int auto_increment primary key,subprodid INT);
    			drop temporary table if exists xml_categoryid_tbl; create temporary table xml_categoryid_tbl(id int auto_increment primary key,categoryid int);
    			drop temporary table if exists xml_featureid_tbl; create temporary table xml_featureid_tbl(id int auto_increment primary key,featureid int);
    
 		SELECT replace(ExtractValue(catg_feature_map_xml, '//tiertype[1]'),' ',','), 
 			replace(ExtractValue(catg_feature_map_xml, '//prodid[1]'),' ',','),
 			replace(ExtractValue(catg_feature_map_xml, '//subprodid[1]'),' ',','),
 			replace(ExtractValue(catg_feature_map_xml, '//categoryid[1]'),' ',','),
 			replace(ExtractValue(catg_feature_map_xml, '//featureid[1]'),' ',',')
 			into v_tiertype,v_prodid,v_subprodid,v_categoryid,v_featureid;
                   
                   
               drop table if exists tt_Split_temptable; call Split(v_tiertype,','); insert into xml_tiertype_tbl(tiertype) select Items from tt_Split_temptable; 
               drop table if exists tt_Split_temptable; call Split(v_prodid,','); insert into xml_prodid_tbl(prodid) select Items from tt_Split_temptable;
               drop table if exists tt_Split_temptable; call Split(v_subprodid,','); insert into xml_subprodid_tbl(subprodid) select Items from tt_Split_temptable;
               drop table if exists tt_Split_temptable; call Split(v_categoryid,','); insert into xml_categoryid_tbl(categoryid) select Items from tt_Split_temptable;
               drop table if exists tt_Split_temptable; call Split(v_featureid,','); insert into xml_featureid_tbl(featureid) select Items from tt_Split_temptable;
               
 
 			INSERT INTO tt_tier_catgfeature_mapping_xml(tier_id,tiertype,product_id,sub_product_id,categoryid,featureid)
 			select tier_id,a.tiertype, b.prodid, c.subprodid, d.categoryid, e.featureid
 			from xml_tiertype_tbl a 
 			left join xml_prodid_tbl b on a.id = b.id
 			left join xml_subprodid_tbl c on a.id=c.id
 			left join xml_categoryid_tbl d on a.id=d.id
 			left join xml_featureid_tbl e on a.id=e.id;
                   
      
 			if exists(select  * from wtms_tier_catg_feature_mapping_info a where  a.tier_id = tier_id LIMIT 1) 
 			then
 				delete from wtms_tier_catg_feature_mapping_info b where b.tier_id = tier_id;
 			end if;
        
        insert into wtms_tier_catg_feature_mapping_info(tier_id,tiertype,product_id,sub_product_id,categoryid,featureid)
        select Distinct a.tier_id,a.tiertype,a.product_id,a.sub_product_id,a.categoryid,a.featureid
        from tt_tier_catgfeature_mapping_xml a;
        
        IF ROW_COUNT() > 0 
        then
  		
           if not exists(select  * from wtms_tier_catg_feature_mapping_info_MT b where b.tier_id = tier_id LIMIT 1) 
           then
  			  insert into wtms_tier_catg_feature_mapping_info_MT(tier_id,tiertype,product_id,sub_product_id,categoryid,featureid)
              select Distinct a.tier_id,a.tiertype,a.product_id,a.sub_product_id,a.categoryid,a.featureid
              from tt_tier_catgfeature_mapping_xml a ;
           end if;
           SET v_errcode = 0;
           SET v_errmsg = 'Inserted';
        end if;
     END; 
 
  End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_create_tier_feature_mapping_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_create_tier_feature_mapping_info`(
         tier_id INT,
         feature_mapping_xml LONGTEXT,
         create_by VARCHAR(50)
         )
begin
        
        
         
            DECLARE v_hDoc INT; 
            DECLARE v_errcode INT; 
            DECLARE v_errmsg VARCHAR(160);
            DECLARE v_now DATETIME(3);
            
       		DECLARE v_tiertype text; 
       		DECLARE v_bundid text; 
       		DECLARE v_prodid text; 
       		DECLARE v_subprodid text; 
       		DECLARE v_categoryid text; 
       		DECLARE v_featureid text; 
       		DECLARE v_value1 text;
       		DECLARE v_value2 text;
       		DECLARE v_value3 text;
       		DECLARE v_value4 text;
       		DECLARE v_value5 text;
       		DECLARE v_value6 text;
       		DECLARE v_value7 text;
       		DECLARE v_value8 text;
       		DECLARE v_value9 text;
       		DECLARE v_value10 text;
            
            
            DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
            BEGIN
               SET @SWV_Error = 1;
            END;
            IF create_by is null then
               set create_by = 'admin';
            END IF;
            SET @SWV_Error = 0;
            BEGIN
               DECLARE EXIT HANDLER FOR SQLEXCEPTION
               begin
                  SET v_errcode = -1;
                  GET STACKED DIAGNOSTICS CONDITION 1 v_errmsg = MESSAGE_TEXT;
                  select v_errcode as errcode, v_errmsg as errmsg;
               end;
               set v_now = CURRENT_TIMESTAMP;
           
               DROP TEMPORARY TABLE IF EXISTS tt_tier_feature_mapping_xml;
               create TEMPORARY table tt_tier_feature_mapping_xml
               (
                  id INT   AUTO_INCREMENT PRIMARY KEY,
                  tier_id INT,
                  tiertype INT,
                  bundle_id INT,
                  product_id INT,
                  sub_product_id INT,
                  categoryid INT,
                  featureid INT,
                  value1 text,
                  value2 text,
                  value3 text,
                  value4 text,
                  value5 text,
                  value6 text,
                  value7 text,
                  value8 text,
                  value9 text,
                  value10 text
               )  AUTO_INCREMENT = 1;
               
                 	drop temporary table if exists xml_tiertype_tbl; create temporary table xml_tiertype_tbl(id int auto_increment primary key,tiertype int);
           			drop temporary table if exists xml_bundid_tbl; create temporary table xml_bundid_tbl(id int auto_increment primary key,bundleid int);
           			drop temporary table if exists xml_prodid_tbl; create temporary table xml_prodid_tbl(id int auto_increment primary key,prodid INT);
           			drop temporary table if exists xml_subprodid_tbl; create temporary table xml_subprodid_tbl(id int auto_increment primary key,subprodid int);
           			drop temporary table if exists xml_categoryid_tbl; create temporary table xml_categoryid_tbl(id int auto_increment primary key,categoryid int);
                 	drop temporary table if exists xml_featureid_tbl; create temporary table xml_featureid_tbl(id int auto_increment primary key,featureid int);
           			drop temporary table if exists xml_value1_tbl; create temporary table xml_value1_tbl(id int auto_increment primary key,value1 text);
           			drop temporary table if exists xml_value2_tbl; create temporary table xml_value2_tbl(id int auto_increment primary key,value2 text);
           			drop temporary table if exists xml_value3_tbl; create temporary table xml_value3_tbl(id int auto_increment primary key,value3 text);
           			drop temporary table if exists xml_value4_tbl; create temporary table xml_value4_tbl(id int auto_increment primary key,value4 text);
         			drop temporary table if exists xml_value5_tbl; create temporary table xml_value5_tbl(id int auto_increment primary key,value5 text);
           			drop temporary table if exists xml_value6_tbl; create temporary table xml_value6_tbl(id int auto_increment primary key,value6 text);
           			drop temporary table if exists xml_value7_tbl; create temporary table xml_value7_tbl(id int auto_increment primary key,value7 text);
           			drop temporary table if exists xml_value8_tbl; create temporary table xml_value8_tbl(id int auto_increment primary key,value8 text);
           			drop temporary table if exists xml_value9_tbl; create temporary table xml_value9_tbl(id int auto_increment primary key,value9 text);
        			drop temporary table if exists xml_value10_tbl; create temporary table xml_value10_tbl(id int auto_increment primary key,value10 text);
              
        
                  SELECT  replace(ExtractValue(feature_mapping_xml, '//tiertype[1]'),' ',','), 
                          replace(ExtractValue(feature_mapping_xml, '//bundleid[1]'),' ',','),
                          replace(ExtractValue(feature_mapping_xml, '//prodid[1]'),' ',','),
                          replace(ExtractValue(feature_mapping_xml, '//subprodid[1]'),' ',','),
                          replace(ExtractValue(feature_mapping_xml, '//categoryid[1]'),' ',','),
                          replace(ExtractValue(feature_mapping_xml, '//featureid[1]'),' ',','), 
                          replace(ExtractValue(feature_mapping_xml, '//value1[1]'),'|',','),
                          replace(ExtractValue(feature_mapping_xml, '//value2[1]'),'|',','),
                          replace(ExtractValue(feature_mapping_xml, '//value3[1]'),'|',','),
                          replace(ExtractValue(feature_mapping_xml, '//value4[1]'),'|',','),
                          replace(ExtractValue(feature_mapping_xml, '//value5[1]'),'|',','), 
                          replace(ExtractValue(feature_mapping_xml, '//value6[1]'),'|',','),
                          replace(ExtractValue(feature_mapping_xml, '//value7[1]'),'|',','),
                          replace(ExtractValue(feature_mapping_xml, '//value8[1]'),'|',','),
                          replace(ExtractValue(feature_mapping_xml, '//value9[1]'),'|',','),
                          replace(ExtractValue(feature_mapping_xml, '//value10[1]'),'|',',')
                          into v_tiertype,v_bundid,v_prodid,v_subprodid,v_categoryid,v_featureid,v_value1,
                          v_value2,v_value3,v_value4,v_value5,v_value6,v_value7,v_value8,v_value9,v_value10;
                          
        				drop table if exists tt_Split_temptable; call Split(v_tiertype,','); insert into xml_tiertype_tbl(tiertype) select Items from tt_Split_temptable;
        				drop table if exists tt_Split_temptable; call Split(v_bundid,','); insert into xml_bundid_tbl(bundleid) select Items from tt_Split_temptable;
        				drop table if exists tt_Split_temptable; call Split(v_prodid,','); insert into xml_prodid_tbl(prodid) select Items from tt_Split_temptable;
        				drop table if exists tt_Split_temptable; call Split(v_subprodid,','); insert into xml_subprodid_tbl(subprodid) select Items from tt_Split_temptable;
        				drop table if exists tt_Split_temptable; call Split(v_categoryid,','); insert into xml_categoryid_tbl(categoryid) select Items from tt_Split_temptable;
        				drop table if exists tt_Split_temptable; call Split(v_featureid,','); insert into xml_featureid_tbl(featureid) select Items from tt_Split_temptable;
        				drop table if exists tt_Split_temptable; call Split(v_value1,','); insert into xml_value1_tbl(value1) select Items from tt_Split_temptable;
        				drop table if exists tt_Split_temptable; call Split(v_value2,','); insert into xml_value2_tbl(value2) select Items from tt_Split_temptable;
        				drop table if exists tt_Split_temptable; call Split(v_value3,','); insert into xml_value3_tbl(value3) select Items from tt_Split_temptable;
        				drop table if exists tt_Split_temptable; call Split(v_value4,','); insert into xml_value4_tbl(value4) select Items from tt_Split_temptable;
        				drop table if exists tt_Split_temptable; call Split(v_value5,','); insert into xml_value5_tbl(value5) select Items from tt_Split_temptable;
        				drop table if exists tt_Split_temptable; call Split(v_value6,','); insert into xml_value6_tbl(value6) select Items from tt_Split_temptable;
        				drop table if exists tt_Split_temptable; call Split(v_value7,','); insert into xml_value7_tbl(value7) select Items from tt_Split_temptable;
        				drop table if exists tt_Split_temptable; call Split(v_value8,','); insert into xml_value8_tbl(value8) select Items from tt_Split_temptable;
        				drop table if exists tt_Split_temptable; call Split(v_value9,','); insert into xml_value9_tbl(value9) select Items from tt_Split_temptable;
        				drop table if exists tt_Split_temptable; call Split(v_value10,','); insert into xml_value10_tbl(value10) select Items from tt_Split_temptable;
                      
        				INSERT INTO tt_tier_feature_mapping_xml(tier_id,tiertype,bundle_id,product_id,sub_product_id,categoryid,featureid,value1,value2,value3,value4,value5, value6,value7,value8,value9,value10)
        				select tier_id,a.tiertype,b.bundleid,c.prodid,d.subprodid,e.categoryid,f.featureid,replace(g.value1,'=',','),replace(h.value2,'=',','),replace(i.value3,'=',','),replace(j.value4,'=',','),replace(k.value5,'=',','), replace(l.value6,'=',','),replace(m.value7,'=',','),replace(n.value8,'=',','),replace(o.value9,'=',','),replace(p.value10,'=',',')
        				from xml_tiertype_tbl a 
        				left join xml_bundid_tbl b on a.id = b.id
        				left join xml_prodid_tbl c on a.id=c.id
        				left join xml_subprodid_tbl d on a.id=d.id
        				left join xml_categoryid_tbl e on a.id=e.id
        				left join xml_featureid_tbl f on a.id = f.id
        				left join xml_value1_tbl g on a.id=g.id
        				left join xml_value2_tbl h on a.id=h.id
        				left join xml_value3_tbl i on a.id=i.id
        				left join xml_value4_tbl j on a.id = j.id
        				left join xml_value5_tbl k on a.id=k.id
        				left join xml_value6_tbl l on a.id=l.id
        				left join xml_value7_tbl m on a.id=m.id
        				left join xml_value8_tbl n on a.id = n.id
        				left join xml_value9_tbl o on a.id=o.id
        				left join xml_value10_tbl p on a.id=p.id;
        
              if exists(select * from wtms_tier_feature_mapping_xml a where  a.tier_id = tier_id LIMIT 1) 
              then
                  delete from wtms_tier_feature_mapping_xml b where b.tier_id = tier_id;
               end if;
               
               insert into wtms_tier_feature_mapping_xml(tier_id,tiertype,bundle_id,product_id,sub_product_id,categoryid,featureid,value1,value2,value3,value4,value5, value6,value7,value8,value9,value10)
               select Distinct a.tier_id,a.tiertype,a.bundle_id,a.product_id,a.sub_product_id,a.categoryid,a.featureid,a.value1,a.value2,a.value3,a.value4,a.value5,a.value6,a.value7,a.value8,a.value9,a.value10
               from tt_tier_feature_mapping_xml a;
               
               IF ROW_COUNT() > 0 
               then
         
         		
                  if not exists(select  * from wtms_tier_feature_mapping_xml_MT b where b.tier_id = tier_id LIMIT 1) 
                  then
         			  insert into wtms_tier_feature_mapping_xml_MT(tier_id,tiertype,bundle_id,product_id,sub_product_id,categoryid,featureid,value1,value2,value3,value4,value5,value6,value7,value8,value9,value10)
                     select Distinct a.tier_id,a.tiertype,a.bundle_id,a.product_id,a.sub_product_id,a.categoryid,a.featureid,a.value1,a.value2,a.value3,a.value4,a.value5,a.value6,a.value7,a.value8,a.value9,a.value10
                     from tt_tier_feature_mapping_xml a;
                  end if;
                  SET v_errcode = 0;
                  SET v_errmsg = 'Inserted';
               end if;
            END; 
         
         
         End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_create_tier_management` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_create_tier_management`(
         	tier_id INT,
         	tier_name VARCHAR(150),
         	tier_description VARCHAR(250),
         	tier_type INT,						
         	prod_type_id INT,					 
         	bund_prd_type INT,					
         	product_id VARCHAR(50),				
         	sub_product_id VARCHAR(200),		
         	fk_purpose_id VARCHAR(100),			
         	status INT,
         	apply_new_exist_cust VARCHAR(10),	
         	free_or_paid INT,
         	currency INT,
         	no_of_users VARCHAR(50),			
         	min_users INT,
         	contract_period VARCHAR(50),		
         	per_addn_user FLOAT,
         	per_addn_user_currency INT,
         	User_Range_xml LONGTEXT,			
         	tier_summary_map_xml LONGTEXT,		
         	catg_position_xml LONGTEXT,
         	catg_feature_map_xml LONGTEXT,
         	feature_mapping_xml LONGTEXT,		
         	create_by VARCHAR(20),
         	is_review INT,						
         	client_ip VARCHAR(20),
         	processtype INT,					
         	country_id int,
         	module_id varchar(150),
         	sub_module_id varchar(150),
         	reseller_id text,
         	pro_user_count int,
         	standard_user_count int,
         	basic_user_count int,
         	free_trail_status int,
         	free_trail_days  int,
         	double_up int,
         	Installation_cost float,
         	Installation_cost_free_count float,
         	platform_fee float,
         	messages_count int, 
         	sessions_count int,
    		Type_of_plan int,
        	Custom_status int,
    		platform_fee_year float,
    		booking_user_count int,
            booking_user_price float,
            p_platform_fee_json_info json,
            parent_id int
            )
Begin
    
   			           
            		  
   			DECLARE v_errcode INT;
   			DECLARE v_errmsg VARCHAR(250);
   			DECLARE v_now DATETIME(3);
   			DECLARE v_id INT;
   			DECLARE v_approver_1_remarks VARCHAR(250);
   			DECLARE v_approver_2_remarks VARCHAR(250);
   			DECLARE v_approver_1_status VARCHAR(250);
   			DECLARE v_approver_2_status VARCHAR(250);
   			  
                                 
   			DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
   			BEGIN
   				SET @SWV_Error = 1;
   			END;
   			 
   			IF tier_id is null then					set tier_id = 0;				END IF;
   			IF prod_type_id is null then			set prod_type_id = 0;			END IF;
   			IF bund_prd_type is null then			set bund_prd_type = 0;			END IF;
   			IF no_of_users is null then				set no_of_users = '';			END IF;
   			IF min_users is null then				set min_users = 0;				END IF;
   			IF contract_period is null then			set contract_period = '';		END IF;
   			IF per_addn_user is null then			set per_addn_user = 0;			END IF;
   			IF tier_summary_map_xml is null then	set tier_summary_map_xml = '';	END IF;
   			IF catg_position_xml is null then		set catg_position_xml = '';		END IF;
   			IF catg_feature_map_xml is null then	set catg_feature_map_xml = '';	END IF;
   			IF feature_mapping_xml is null then		set feature_mapping_xml = '';	END IF;
   			IF is_review is null then				set is_review = 1;				END IF;
   			IF client_ip is null then				set client_ip = '';				END IF;
   			IF country_id is null then 				set country_id = 0 ; 			END IF;
   			IF module_id is null then 				set module_id = '' ; 			END IF;
   			IF sub_module_id is null then 			set sub_module_id = '' ; 		END IF;
                        
            			SET @SWV_Error = 0;
                       
                                 BEGIN
                                    DECLARE EXIT HANDLER FOR SQLEXCEPTION
                                    begin
                                       SET v_errcode = @SWV_Error;
                                       GET STACKED DIAGNOSTICS CONDITION 1 v_errmsg = MESSAGE_TEXT;
                 
                                       select v_errcode as errcode, v_errmsg as errmsg, IFNULL(tier_id,0) as tier_id;
                               
                                       insert into wtms_tier_management_log(tier_id,tier_name,tier_description,tier_type,prod_type_id,bund_prd_type,product_id,sub_product_id,fk_purpose_id,status,apply_new_exist_cust,free_or_paid,currency,no_of_users,min_users,contract_period,per_addn_user,per_addn_user_currency,User_Range_xml,tier_summary_map,
                             			catg_position_xml,feature_mapping,create_date,create_by,is_review,processtype,catg_feature_map_xml,client_ip,reseller_id,pro_user_count,standard_user_count,basic_user_count,free_trail_status ,free_trail_days,double_up,Installation_cost,Installation_cost_free_count,platform_fee,messages_count, sessions_count,Type_of_plan,Custom_status,platform_fee_year,booking_user_count,booking_user_price,platform_fee_json_info,parent_id)
                                       select tier_id,tier_name,tier_description,tier_type,prod_type_id,bund_prd_type,product_id,sub_product_id,fk_purpose_id,status,apply_new_exist_cust,free_or_paid,currency,no_of_users,min_users,contract_period,per_addn_user,per_addn_user_currency,User_Range_xml,
                             			tier_summary_map_xml,	catg_position_xml,	feature_mapping_xml,v_now,create_by,is_review,processtype,catg_feature_map_xml,client_ip,reseller_id,pro_user_count,standard_user_count,basic_user_count,free_trail_status ,free_trail_days,double_up,Installation_cost,Installation_cost_free_count,platform_fee,messages_count, sessions_count,Type_of_plan,Custom_status,platform_fee_year,booking_user_count,booking_user_price,p_platform_fee_json_info,parent_id;
                                    
                                   end;
                                                      
                                    sp_exit:
                                    BEGIN
                          
                                       SET v_now = CURRENT_TIMESTAMP;
                  
                                       IF (tier_name = '' or tier_name IS NULL) THEN	
                                          SET v_errcode = -1;
                                          SET v_errmsg = 'Tier Name should not be empty';
                                          LEAVE sp_exit;
                                       END IF;
                              
            					
            						DROP TEMPORARY TABLE IF EXISTS tt_t1_prod_id;			CREATE TEMPORARY TABLE tt_t1_prod_id(prod_id int);                            
            						DROP TEMPORARY TABLE IF EXISTS tt_t1_sub_prod_id;		CREATE TEMPORARY TABLE tt_t1_sub_prod_id(sub_prod_id int);
            						DROP TEMPORARY TABLE IF EXISTS tt_temp_sub_prd_mapping;	CREATE TEMPORARY TABLE tt_temp_sub_prd_mapping(tier_id INT,sub_prod_id INT,prod_id INT);
                         
            						call Split(product_id,',');insert into tt_t1_prod_id(prod_id)select a.items from tt_Split_temptable a;
            					
            						call Split(sub_product_id,',');insert into tt_t1_sub_prod_id(sub_prod_id)select a.items from tt_Split_temptable a;
                      
                                       if processtype = 1 
                                       then
                              	
                                          IF EXISTS(select * from wtms_tier_management a where a.tier_name = tier_name and a.prod_type_id = prod_type_id and a.tier_type = tier_type and a.country_id = country_id 
                                          and a.fk_purpose_id = fk_purpose_id LIMIT 1)then                  	
                                             SET v_errcode = -1;
                                             SET v_errmsg = 'Tier Name already exists';
                                             LEAVE sp_exit;
                                          END IF;
                            
                             			insert into wtms_tier_management(tier_name,tier_type,tier_description,prod_type_id,bund_prd_type,fk_purpose_id,status,min_users,apply_new_exist_cust,
                             			free_or_paid,currency,create_date,modify_date,product_id,sub_product_id,is_review,per_addn_user,per_addn_user_currency,module_id,sub_module_id,country_id,reseller_id,pro_user_count,standard_user_count,basic_user_count,free_trail_status ,free_trail_days,double_up,Installation_cost,Installation_cost_free_count,platform_fee,messages_count, sessions_count,Type_of_plan,Custom_status,platform_fee_year,booking_user_count,booking_user_price,platform_fee_json_info,parent_id)
                             			values(tier_name,tier_type,tier_description,prod_type_id,bund_prd_type,fk_purpose_id,status,min_users,apply_new_exist_cust,
                             			free_or_paid,currency,v_now,v_now,product_id,sub_product_id,is_review,per_addn_user,per_addn_user_currency,module_id,sub_module_id,country_id,reseller_id,pro_user_count,standard_user_count,basic_user_count,free_trail_status ,free_trail_days,double_up,Installation_cost,Installation_cost_free_count,platform_fee,messages_count, sessions_count,Type_of_plan,Custom_status,platform_fee_year,booking_user_count,booking_user_price,p_platform_fee_json_info,parent_id);
                             
                                          set tier_id = LAST_INSERT_ID();
                                          
                                          IF ROW_COUNT() > 0 then
                      						
                      							call Split(reseller_id,',');
                      
                      							insert into wtms.wtms_tier_reseller_info(tier_id,reseller_id)
                      							select tier_id,a.items from tt_Split_temptable a;
                                  
                      						
                              		
                             			insert into wtms_copy_of_tier_management_temp(fk_tier_id,tier_name,tier_type,tier_description,prod_type_id,bund_prd_type,fk_purpose_id,status,min_users,apply_new_exist_cust,
                             			free_or_paid,currency,create_date,modify_date,product_id,sub_product_id,is_review,per_addn_user,per_addn_user_currency,module_id,sub_module_id,country_id,reseller_id,pro_user_count,standard_user_count,basic_user_count,free_trail_status ,free_trail_days,double_up,Installation_cost,Installation_cost_free_count,platform_fee,messages_count, sessions_count,Type_of_plan,Custom_status,platform_fee_year,booking_user_count,booking_user_price,platform_fee_json_info,parent_id)
                             			values(tier_id,tier_name,tier_type,tier_description,prod_type_id,bund_prd_type,fk_purpose_id,status,min_users,apply_new_exist_cust,
                             			free_or_paid,currency,v_now,v_now,product_id,sub_product_id,4,per_addn_user,per_addn_user_currency,module_id,sub_module_id,country_id,reseller_id,pro_user_count,standard_user_count,basic_user_count,free_trail_status ,free_trail_days,double_up,Installation_cost,Installation_cost_free_count,platform_fee,messages_count, sessions_count,Type_of_plan,Custom_status,platform_fee_year,booking_user_count,booking_user_price,p_platform_fee_json_info,parent_id);
                                         
                                             set v_errcode = 0;
                                             set v_errmsg = 'Success : Tier plan created';
                                          end if;
                                       end if;
                                   
                                       if processtype = 2 then
                           
                                          if exists(select  * from wtms_tier_management b where b.tier_name = tier_name and b.tier_id <> tier_id and b.prod_type_id = prod_type_id and b.tier_type = tier_type and b.country_id = country_id 
                                          and b.fk_purpose_id = fk_purpose_id LIMIT 1) then
                                             SET v_errcode = -1;
                                             SET v_errmsg = 'Tier Name already exists';
                                             LEAVE sp_exit;
                                          end if;
                                          
                                          if not exists(select  * from wtms_tier_management c where c.tier_id = tier_id LIMIT 1)then
                                             SET v_errcode = -1;
                                             SET v_errmsg = 'Tier not exists';
                                             LEAVE sp_exit;
                                          end if;
                                          
 										UPDATE wtms_tier_management a
 										set a.tier_name = IFNULL(tier_name,a.tier_name),
 											a.tier_type = IFNULL(tier_type,a.tier_type),
 											a.tier_description = IFNULL(tier_description,a.tier_description),
 											a.prod_type_id = IFNULL(prod_type_id,a.prod_type_id),
 											a.bund_prd_type = IFNULL(bund_prd_type,a.bund_prd_type),
 											a.fk_purpose_id = IFNULL(fk_purpose_id,a.fk_purpose_id),
 											a.status = IFNULL(status,a.status),
 											a.min_users = IFNULL(min_users,a.min_users),
 											a.apply_new_exist_cust = IFNULL(apply_new_exist_cust,a.apply_new_exist_cust),
 											a.free_or_paid = IFNULL(free_or_paid,a.free_or_paid),
 											a.currency = IFNULL(currency,a.currency),
 											a.modify_date = v_now,
 											a.contract_period = contract_period,
 											a.per_addn_user = per_addn_user,
 											a.per_addn_user_currency  = per_addn_user_currency,
 											a.product_id = IFNULL(product_id,a.product_id),
 											a.sub_product_id = IFNULL(sub_product_id,a.sub_product_id),
 											a.is_review = IFNULL(is_review,a.is_review),
 											a.sub_module_id = ifnull(sub_module_id,a.sub_module_id),
 											a.module_id = ifnull(module_id,a.module_id),
 											a.country_id = ifnull(country_id,a.country_id),
 											a.reseller_id = ifnull(reseller_id, a.reseller_id),
 											a.pro_user_count = ifnull(pro_user_count,a.pro_user_count),
 											a.standard_user_count = ifnull(standard_user_count,a.standard_user_count),
 											a.basic_user_count = ifnull(basic_user_count,a.basic_user_count),
 											a.free_trail_status  = ifnull(free_trail_status ,a.free_trail_status ),
 											a.free_trail_days  = ifnull(free_trail_days ,a.free_trail_days ),
 											a.double_up = ifnull(double_up,a.double_up),
 											a.Installation_cost = ifnull(Installation_cost,a.Installation_cost),
 											a.Installation_cost_free_count = ifnull(Installation_cost_free_count,a.Installation_cost_free_count),
 											a.platform_fee = ifnull(platform_fee,a.platform_fee),
 											a.messages_count = ifnull(messages_count,a.messages_count),
 											a.sessions_count = ifnull(sessions_count,a.sessions_count),
 											a.Type_of_plan = ifnull(Type_of_plan,a.Type_of_plan),
 											a.Custom_status = ifnull(Custom_status,a.Custom_status),
 											a.platform_fee_year = ifnull(platform_fee_year,a.platform_fee_year),
 											a.booking_user_count = ifnull(booking_user_count,a.booking_user_count),
 											a.booking_user_price = ifnull(booking_user_price,a.booking_user_price),
 											a.platform_fee_json_info = ifnull(p_platform_fee_json_info,a.platform_fee_json_info),
                                            a.parent_id = ifnull(parent_id,a.parent_id)
             							where a.tier_id = tier_id;
                                          
                                          if ROW_COUNT() > 0 then
                                          
                      							if exists(select * from  wtms.wtms_tier_reseller_info a where a.tier_id = tier_id) then
                      								delete from wtms.wtms_tier_reseller_info a where a.tier_id = tier_id;
            									End if;
                                                  
            									call Split(reseller_id,',');
                      
                      							insert into wtms.wtms_tier_reseller_info(tier_id,reseller_id)
                      							select tier_id,a.items from tt_Split_temptable a;
                                          
                              		
 										UPDATE wtms_copy_of_tier_management_temp a
 										set a.tier_name = IFNULL(tier_name,a.tier_name),a.tier_type = IFNULL(tier_type,a.tier_type),
 											a.tier_description = IFNULL(tier_description,a.tier_description),					
 											a.prod_type_id = IFNULL(prod_type_id,a.prod_type_id),
 											a.bund_prd_type = IFNULL(bund_prd_type,a.bund_prd_type),a.fk_purpose_id = IFNULL(fk_purpose_id,a.fk_purpose_id),										
 											a.min_users = IFNULL(min_users,a.min_users),a.apply_new_exist_cust = IFNULL(apply_new_exist_cust,a.apply_new_exist_cust),		
 											a.free_or_paid = IFNULL(free_or_paid,a.free_or_paid),a.currency = IFNULL(currency,a.currency),											
 											a.modify_date = v_now,a.contract_period = contract_period,												
 											a.per_addn_user = per_addn_user,a.per_addn_user_currency  = per_addn_user_currency,								
 											a.product_id = IFNULL(product_id,a.product_id),
 											a.sub_product_id = IFNULL(sub_product_id,a.sub_product_id),						
 											a.is_review = 4, 
 											a.sub_module_id = ifnull(sub_module_id,a.sub_module_id),
 											a.module_id = ifnull(module_id,a.module_id),
 											a.country_id = ifnull(country_id,a.country_id),
 											a.reseller_id = ifnull(reseller_id, a.reseller_id),
 											a.pro_user_count = ifnull(pro_user_count,a.pro_user_count),
 											a.standard_user_count = ifnull(standard_user_count,a.standard_user_count),
 											a.basic_user_count = ifnull(basic_user_count,a.basic_user_count) ,
 											a.free_trail_status  = ifnull(free_trail_status ,a.free_trail_status ),
 											a.free_trail_days  = ifnull(free_trail_days ,a.free_trail_days ),
 											a.double_up = ifnull(double_up,a.double_up),
 											a.Installation_cost = ifnull(Installation_cost,a.Installation_cost),
 											a.Installation_cost_free_count = ifnull(Installation_cost_free_count,a.Installation_cost_free_count),
 											a.platform_fee = ifnull(platform_fee,a.platform_fee),
 											a.messages_count = ifnull(messages_count,a.messages_count),
 											a.sessions_count = ifnull(sessions_count,a.sessions_count),
 											a.Type_of_plan = ifnull(Type_of_plan,a.Type_of_plan),
 											a.Custom_status = ifnull(Custom_status,a.Custom_status),
 											a.platform_fee_year = ifnull(platform_fee_year,a.platform_fee_year),
 											a.booking_user_count = ifnull(booking_user_count,a.booking_user_count),
 											a.booking_user_price = ifnull(booking_user_price,a.booking_user_price),
 											a.platform_fee_json_info = ifnull(p_platform_fee_json_info,a.platform_fee_json_info),
                                            a.parent_id = ifnull(parent_id,a.parent_id)
 										where a.fk_tier_id = tier_id;
                                         
             								SET v_errcode = 0;
             								SET v_errmsg = 'Tier updated';
                                             
                        					
                                              if exists(select * from wtms_tier_approval_management a where a.fk_tier_id = tier_id limit 1) then 
                                              
                        						select   max(a.id) INTO v_id from wtms_tier_approval_management a where a.fk_tier_id = tier_id;
                                                
                        							select   a.approver_1_status, a.approver_2_status, a.approver_1_remarks, a.approver_2_remarks 
                        							INTO v_approver_1_status,v_approver_2_status,v_approver_1_remarks,v_approver_2_remarks 
                        							from wtms_tier_approval_management a where a.fk_tier_id = tier_id and a.id = v_id;
                                                    
                                                    if v_approver_1_status = 'Approved' and v_approver_2_status = 'Approved' then
                        								insert into wtms_tier_approval_management(fk_tier_id,approver_1_userid,approver_1_user_group_name,approver_1_status,approver_1_approved_on,
                        								approver_1_remarks,approver_2_userid,approver_2_user_group_name,approver_2_status,approver_2_approved_on,approver_2_remarks,approver_1_username,approver_2_username)
                        								values(tier_id,0,'',null,current_timestamp,'',0,'','',null,'','','');
                                                    End if;
                        
                                              End if;
                                             
                                            
                                          end if;
                                       end if;
                                       
                                       if sub_product_id = '' or sub_product_id = 0
                                       then
                              		
                              		  insert into tt_temp_sub_prd_mapping(tier_id,sub_prod_id,prod_id)
                                          select tier_id as tier_id,0 as sub_prod_id,a.prod_id as prod_id
                                          from product_master a
                                          where a.prod_id in(select c.prod_id from tt_t1_prod_id c) and a.prod_status = 1;
                                       Else
                              		
                              		 insert into tt_temp_sub_prd_mapping(tier_id,sub_prod_id,prod_id)
                                          select tier_id as tier_id,a.catg_id as sub_prod_id,a.fk_prod_id as prod_id
                                          from product_category_master a
                                          where a.catg_id in(select b.sub_prod_id from tt_t1_sub_prod_id b)
                                          and a.fk_prod_id in(select c.prod_id from tt_t1_prod_id c join product_master d on c.prod_id = d.prod_id where d.prod_status = 1)
                                          and a.category_status = 1;
       							end if;
                                       if exists(select  * from wtms_tier_sub_product_master b where b.fk_tier_id = tier_id LIMIT 1) then
                                          if exists(select  * from tt_temp_sub_prd_mapping c where c.tier_id = tier_id LIMIT 1) then     		
                                             delete from wtms_tier_sub_product_master d where d.fk_tier_id = tier_id;
                                          end if;
                                          insert into wtms_tier_sub_product_master(fk_tier_id,fk_tier_type,fk_prod_id,fk_sub_prod_id,create_date)
                                          select tier_id,tier_type,prod_id,sub_prod_id ,v_now
                                          from tt_temp_sub_prd_mapping;
                                          
                                          if ROW_COUNT() > 0
                                          then
                                             set v_errcode = 0;
                                             set v_errmsg = 'prod/sub product mapped to tier';
                                          end if;
                                       Else
       							insert into wtms_tier_sub_product_master(fk_tier_id,fk_tier_type,fk_prod_id,fk_sub_prod_id,create_date)
       								select tier_id,tier_type,prod_id,sub_prod_id ,v_now
       								from tt_temp_sub_prd_mapping;
       							end if;
                              
                              	
                                       if not exists(select  * from wtms_tier_sub_product_master_MT a where a.fk_tier_id = tier_id LIMIT 1) then
                              				  insert into wtms_tier_sub_product_master_MT(fk_tier_id,fk_tier_type,fk_prod_id,fk_sub_prod_id,create_date)
                                          select tier_id,tier_type,prod_id,sub_prod_id ,v_now
                                          from tt_temp_sub_prd_mapping;
                                       end if;
                                          
                            
   						if ifnull(p_platform_fee_json_info,'')<>'' then 
   							call worktual_create_tier_platform_fee_json(tier_id,p_platform_fee_json_info);
   						end if;
                              
                              	
                                       IF User_Range_xml is not null then
                                          CALL worktual_create_tier_price_by_user_Range(tier_id,User_Range_xml,create_by);
                                       end if;
                              
                              	
                                       IF tier_summary_map_xml is not null then
                                          CALL worktual_create_tier_summary_map(tier_id,tier_summary_map_xml,create_by);
                                       end if;
                              
                              	
                                       IF catg_position_xml is not null then
                                          CALL worktual_create_tier_category_position(tier_id,catg_position_xml,create_by);
                                       end if;
                              
                              	
                                       IF catg_feature_map_xml is not null then
                                          CALL worktual_create_tier_catg_feature_map(tier_id,catg_feature_map_xml,create_by);
                                       end if;
                              
                              	
                                       IF feature_mapping_xml is not null then
                                          CALL worktual_create_tier_feature_mapping_info(tier_id,feature_mapping_xml,create_by);
                                       end if;
       
                              	
       						insert into wtms_tier_management_log(tier_id,tier_name,tier_description,tier_type,prod_type_id,bund_prd_type,product_id,sub_product_id,fk_purpose_id,status,
       							apply_new_exist_cust,free_or_paid,currency,no_of_users,min_users,contract_period,per_addn_user,per_addn_user_currency,User_Range_xml,tier_summary_map,
       							catg_position_xml,feature_mapping,create_date,create_by,is_review,processtype,catg_feature_map_xml,client_ip,module_id,sub_module_id,country_id,reseller_id,pro_user_count,standard_user_count,basic_user_count,free_trail_status ,free_trail_days,double_up,Installation_cost,Installation_cost_free_count,platform_fee,messages_count,sessions_count,Type_of_plan,Custom_status,platform_fee_year,booking_user_count,booking_user_price,platform_fee_json_info,parent_id )
       						select tier_id,tier_name,tier_description,tier_type,prod_type_id,bund_prd_type,product_id,sub_product_id,fk_purpose_id,status,
       							apply_new_exist_cust,free_or_paid,currency,no_of_users,min_users,contract_period,per_addn_user,per_addn_user_currency,User_Range_xml,
       							tier_summary_map_xml,	catg_position_xml,	feature_mapping_xml,v_now,create_by,is_review,processtype,catg_feature_map_xml,client_ip,module_id,sub_module_id,country_id,reseller_id,pro_user_count,standard_user_count,basic_user_count,free_trail_status ,free_trail_days,double_up,Installation_cost,Installation_cost_free_count,platform_fee,messages_count,sessions_count,Type_of_plan,Custom_status,platform_fee_year,booking_user_count,booking_user_price,p_platform_fee_json_info,parent_id ;
                                    END;
                                    select v_errcode as errcode, v_errmsg as errmsg, IFNULL(tier_id,0) as tier_id;
                                 END; 
                              
                              End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_create_tier_management_07062023` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_create_tier_management_07062023`(
              tier_id INT,
              tier_name VARCHAR(150),
              tier_description VARCHAR(250),
              tier_type INT,							
              prod_type_id INT,					
              bund_prd_type INT,					
              product_id VARCHAR(50),				
              sub_product_id VARCHAR(200),			
              fk_purpose_id VARCHAR(100),			
              status INT,
              apply_new_exist_cust VARCHAR(10),		
              free_or_paid INT,
              currency INT,
              no_of_users VARCHAR(50),			
              min_users INT,
              contract_period VARCHAR(50),		
              per_addn_user FLOAT,
              per_addn_user_currency INT,
              User_Range_xml LONGTEXT,				
              tier_summary_map_xml LONGTEXT,			
              catg_position_xml LONGTEXT,
              catg_feature_map_xml LONGTEXT,
              feature_mapping_xml LONGTEXT,			
              create_by VARCHAR(20),
              is_review INT,						
              client_ip VARCHAR(20),
              processtype INT,						
              country_id int,
              module_id varchar(150),
              sub_module_id varchar(150),
              reseller_id text,
              pro_user_count int,
              standard_user_count int,
              basic_user_count int
              )
Begin
             
             
             
             
            
              
              
              
        		DECLARE v_errcode INT;
        		DECLARE v_errmsg VARCHAR(250);
        		DECLARE v_now DATETIME(3);
        		DECLARE v_id INT;
        		DECLARE v_approver_1_remarks VARCHAR(250);
        		DECLARE v_approver_2_remarks VARCHAR(250);
        		DECLARE v_approver_1_status VARCHAR(250);
        		DECLARE v_approver_2_status VARCHAR(250);
                 
                 
                 DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
                 BEGIN
                    SET @SWV_Error = 1;
                 END;
                 IF tier_id is null then
                    set tier_id = 0;
                 END IF;
                 IF prod_type_id is null then
                    set prod_type_id = 0;
                 END IF;
                 IF bund_prd_type is null then
                    set bund_prd_type = 0;
                 END IF;
                 IF no_of_users is null then
                    set no_of_users = '';
                 END IF;
                 IF min_users is null then
                    set min_users = 0;
                 END IF;
                 IF contract_period is null then
                    set contract_period = '';
                 END IF;
                 IF per_addn_user is null then
                    set per_addn_user = 0;
                 END IF;
                 IF tier_summary_map_xml is null then
                    set tier_summary_map_xml = '';
                 END IF;
                 IF catg_position_xml is null then
                    set catg_position_xml = '';
                 END IF;
                 IF catg_feature_map_xml is null then
                    set catg_feature_map_xml = '';
                 END IF;
                 IF feature_mapping_xml is null then
                    set feature_mapping_xml = '';
                 END IF;
                 IF is_review is null then
                    set is_review = 1;
                 END IF;
                 IF client_ip is null then
                    set client_ip = '';
                 END IF;
                  SET @SWV_Error = 0;
                 
             		if country_id is null then set country_id = 0 ; end if;
             		if module_id is null then set module_id = '' ; end if;
             		if sub_module_id is null then set sub_module_id = '' ; end if;
                 
                 
                 BEGIN
                    DECLARE EXIT HANDLER FOR SQLEXCEPTION
                    begin
                       SET v_errcode = @SWV_Error;
                       
                       
                       GET STACKED DIAGNOSTICS CONDITION 1 v_errmsg = MESSAGE_TEXT;
 
                       select v_errcode as errcode, v_errmsg as errmsg, IFNULL(tier_id,0) as tier_id;
               
                       insert into wtms_tier_management_log(tier_id,tier_name,tier_description,tier_type,prod_type_id,bund_prd_type,product_id,sub_product_id,fk_purpose_id,status,apply_new_exist_cust,free_or_paid,currency,no_of_users,min_users,contract_period,per_addn_user,per_addn_user_currency,User_Range_xml,tier_summary_map,
             			catg_position_xml,feature_mapping,create_date,create_by,is_review,processtype,catg_feature_map_xml,client_ip,reseller_id,pro_user_count,standard_user_count,basic_user_count)
                       select tier_id,tier_name,tier_description,tier_type,prod_type_id,bund_prd_type,product_id,sub_product_id,fk_purpose_id,status,apply_new_exist_cust,free_or_paid,currency,no_of_users,min_users,contract_period,per_addn_user,per_addn_user_currency,User_Range_xml,
             			tier_summary_map_xml,	catg_position_xml,	feature_mapping_xml,v_now,create_by,is_review,processtype,catg_feature_map_xml,client_ip,reseller_id,pro_user_count,standard_user_count,basic_user_count;
          
                   end;
                    
                    
                    sp_exit:
                    BEGIN
          
                       set v_now = CURRENT_TIMESTAMP;
                       
                       
                       if (tier_name = '' or tier_name IS NULL) then
              		
                          SET v_errcode = -1;
                          SET v_errmsg = 'Tier Name should not be empty';
                          LEAVE sp_exit;
                       end if;
              
              		
                        DROP TEMPORARY TABLE IF EXISTS  tt_t1_prod_id;
                        CREATE TEMPORARY TABLE tt_t1_prod_id
                        (
                        prod_id int
                        );
                        
         				DROP TEMPORARY TABLE IF EXISTS  tt_t1_sub_prod_id;
         				CREATE TEMPORARY TABLE tt_t1_sub_prod_id
         				(
         				sub_prod_id int
         				);
         
         				call Split(product_id,',');
         
         				insert into tt_t1_prod_id(prod_id)
         				select a.items from tt_Split_temptable a;
                         
              		
              
            				call Split(sub_product_id,',');
                    
                         insert into tt_t1_sub_prod_id(sub_prod_id)
         				select a.items from tt_Split_temptable a;
         
                       DROP TEMPORARY TABLE IF EXISTS tt_temp_sub_prd_mapping;
                       create TEMPORARY table tt_temp_sub_prd_mapping
                       (
                          tier_id INT,
                          sub_prod_id INT,
                          prod_id INT
                       );
               
                       if processtype = 1 
                       then
              	
                          if exists(select  * from wtms_tier_management a  where a.tier_name = tier_name and a.prod_type_id = prod_type_id and a.tier_type = tier_type LIMIT 1)
                          then
              	
                             SET v_errcode = -1;
                             SET v_errmsg = 'Tier Name already exists';
                             LEAVE sp_exit;
                          end if;
            
             			insert into wtms_tier_management(tier_name,tier_type,tier_description,prod_type_id,bund_prd_type,fk_purpose_id,status,min_users,apply_new_exist_cust,
             			free_or_paid,currency,create_date,modify_date,product_id,sub_product_id,is_review,per_addn_user,per_addn_user_currency,module_id,sub_module_id,country_id,reseller_id,pro_user_count,standard_user_count,basic_user_count)
             			values(tier_name,tier_type,tier_description,prod_type_id,bund_prd_type,fk_purpose_id,status,min_users,apply_new_exist_cust,
             			free_or_paid,currency,v_now,v_now,product_id,sub_product_id,is_review,per_addn_user,per_addn_user_currency,module_id,sub_module_id,country_id,reseller_id,pro_user_count,standard_user_count,basic_user_count);
             
                          set tier_id = LAST_INSERT_ID();
                          if ROW_COUNT() > 0 
                          then
      						
      							call Split(reseller_id,',');
      
      							insert into wtms.wtms_tier_reseller_info(tier_id,reseller_id)
      							select tier_id,a.items from tt_Split_temptable a;
                  
      						
              		
              		
             			insert into wtms_copy_of_tier_management_temp(fk_tier_id,tier_name,tier_type,tier_description,prod_type_id,bund_prd_type,fk_purpose_id,status,min_users,apply_new_exist_cust,
             			free_or_paid,currency,create_date,modify_date,product_id,sub_product_id,is_review,per_addn_user,per_addn_user_currency,module_id,sub_module_id,country_id,reseller_id,pro_user_count,standard_user_count,basic_user_count)
             			values(tier_id,tier_name,tier_type,tier_description,prod_type_id,bund_prd_type,fk_purpose_id,status,min_users,apply_new_exist_cust,
             			free_or_paid,currency,v_now,v_now,product_id,sub_product_id,4,per_addn_user,per_addn_user_currency,module_id,sub_module_id,country_id,reseller_id,pro_user_count,standard_user_count,basic_user_count);
              			
                             set v_errcode = 0;
                             set v_errmsg = 'Success : Tier plan created';
                          end if;
                       end if;
                   
                       if processtype = 2 
                       then
           
                          if exists(select  * from wtms_tier_management b where b.tier_name = tier_name and b.tier_id <> tier_id and b.prod_type_id = prod_type_id and b.tier_type = tier_type LIMIT 1) 
                          then
                             SET v_errcode = -1;
                             SET v_errmsg = 'Tier Name already exists';
                             LEAVE sp_exit;
                          end if;
                          if not exists(select  * from wtms_tier_management c where c.tier_id = tier_id LIMIT 1)
                          then
                             SET v_errcode = -1;
                             SET v_errmsg = 'Tier not exists';
                             LEAVE sp_exit;
                          end if;
                          
                          UPDATE wtms_tier_management a
                          set a.tier_name = IFNULL(tier_name,a.tier_name),
                          a.tier_type = IFNULL(tier_type,a.tier_type),
                          a.tier_description = IFNULL(tier_description,a.tier_description),					
                          a.prod_type_id = IFNULL(prod_type_id,a.prod_type_id),
                          a.bund_prd_type = IFNULL(bund_prd_type,a.bund_prd_type),
                          a.fk_purpose_id = IFNULL(fk_purpose_id,a.fk_purpose_id),
                          a.status = IFNULL(status,a.status),												
                          a.min_users = IFNULL(min_users,a.min_users),
                          a.apply_new_exist_cust = IFNULL(apply_new_exist_cust,a.apply_new_exist_cust),		
                          a.free_or_paid = IFNULL(free_or_paid,a.free_or_paid),
                          a.currency = IFNULL(currency,a.currency),											
                          a.modify_date = v_now,
                          a.contract_period = contract_period,												
                          a.per_addn_user = per_addn_user,
                          a.per_addn_user_currency  = per_addn_user_currency,								
                          a.product_id = IFNULL(product_id,a.product_id),
                          a.sub_product_id = IFNULL(sub_product_id,a.sub_product_id),						
                          a.is_review = IFNULL(is_review,a.is_review),
                          a.sub_module_id = ifnull(sub_module_id,a.sub_module_id),
                          a.module_id = ifnull(module_id,a.module_id),
                          a.country_id = ifnull(country_id,a.country_id),
                          a.reseller_id = ifnull(reseller_id, a.reseller_id),
                          a.pro_user_count = ifnull(pro_user_count,a.pro_user_count),
                          a.standard_user_count = ifnull(standard_user_count,a.standard_user_count),
                          a.basic_user_count = ifnull(basic_user_count,a.basic_user_count) 
                          where a.tier_id = tier_id;
                          
                          if ROW_COUNT() > 0 
                          then
                          
      							if exists(select * from  wtms.wtms_tier_reseller_info a where a.tier_id = tier_id) then
      								delete from wtms.wtms_tier_reseller_info a where a.tier_id = tier_id;
                                  End if;
                                  
                                  call Split(reseller_id,',');
      
      							insert into wtms.wtms_tier_reseller_info(tier_id,reseller_id)
      							select tier_id,a.items from tt_Split_temptable a;
                          
              		
                             UPDATE wtms_copy_of_tier_management_temp a
                             set a.tier_name = IFNULL(tier_name,a.tier_name),a.tier_type = IFNULL(tier_type,a.tier_type),
                             a.tier_description = IFNULL(tier_description,a.tier_description),					
                             a.prod_type_id = IFNULL(prod_type_id,a.prod_type_id),
                             a.bund_prd_type = IFNULL(bund_prd_type,a.bund_prd_type),a.fk_purpose_id = IFNULL(fk_purpose_id,a.fk_purpose_id),
                             a.status = IFNULL(status,a.status),												
                             a.min_users = IFNULL(min_users,a.min_users),a.apply_new_exist_cust = IFNULL(apply_new_exist_cust,a.apply_new_exist_cust),		
                             a.free_or_paid = IFNULL(free_or_paid,a.free_or_paid),a.currency = IFNULL(currency,a.currency),											
                             a.modify_date = v_now,a.contract_period = contract_period,												
                             a.per_addn_user = per_addn_user,a.per_addn_user_currency  = per_addn_user_currency,								
                             a.product_id = IFNULL(product_id,a.product_id),
                             a.sub_product_id = IFNULL(sub_product_id,a.sub_product_id),						
                             a.is_review = 4, 
                             a.sub_module_id = ifnull(sub_module_id,a.sub_module_id),
                          a.module_id = ifnull(module_id,a.module_id),
                          a.country_id = ifnull(country_id,a.country_id),
                          a.reseller_id = ifnull(reseller_id, a.reseller_id),
                          a.pro_user_count = ifnull(pro_user_count,a.pro_user_count),
                          a.standard_user_count = ifnull(standard_user_count,a.standard_user_count),
                          a.basic_user_count = ifnull(basic_user_count,a.basic_user_count) 
                             where a.fk_tier_id = tier_id;
                             SET v_errcode = 0;
                             SET v_errmsg = 'Tier updated';
                             
        					
                              if exists(select * from wtms_tier_approval_management a where a.fk_tier_id = tier_id limit 1) then 
                              
        						select   max(a.id) INTO v_id from wtms_tier_approval_management a where a.fk_tier_id = tier_id;
                                
        							select   a.approver_1_status, a.approver_2_status, a.approver_1_remarks, a.approver_2_remarks 
        							INTO v_approver_1_status,v_approver_2_status,v_approver_1_remarks,v_approver_2_remarks 
        							from wtms_tier_approval_management a where a.fk_tier_id = tier_id and a.id = v_id;
                                    
                                    if v_approver_1_status = 'Approved' and v_approver_2_status = 'Approved' then
        								insert into wtms_tier_approval_management(fk_tier_id,approver_1_userid,approver_1_user_group_name,approver_1_status,approver_1_approved_on,
        								approver_1_remarks,approver_2_userid,approver_2_user_group_name,approver_2_status,approver_2_approved_on,approver_2_remarks,approver_1_username,approver_2_username)
        								values(tier_id,0,'',null,current_timestamp,'',0,'','',null,'','','');
                                    End if;
        
                              End if;
                             
                            
                             
                          end if;
                       end if;
                       
                       if sub_product_id = '' or sub_product_id = 0
                       then
              		
              		  insert into tt_temp_sub_prd_mapping(tier_id,sub_prod_id,prod_id)
                          select tier_id as tier_id,0 as sub_prod_id,a.prod_id as prod_id
                          from product_master a
                          where a.prod_id in(select c.prod_id from tt_t1_prod_id c) and a.prod_status = 1;
                       Else
              		
              		 insert into tt_temp_sub_prd_mapping(tier_id,sub_prod_id,prod_id)
                          select tier_id as tier_id,a.catg_id as sub_prod_id,a.fk_prod_id as prod_id
                          from product_category_master a
                          where a.catg_id in(select b.sub_prod_id from tt_t1_sub_prod_id b)
                          and a.fk_prod_id in(select c.prod_id from tt_t1_prod_id c join product_master d on c.prod_id = d.prod_id where d.prod_status = 1)
                          and a.category_status = 1;
                       end if;
                       if exists(select  * from wtms_tier_sub_product_master b where b.fk_tier_id = tier_id LIMIT 1) then
              	
                          if exists(select  * from tt_temp_sub_prd_mapping c where c.tier_id = tier_id LIMIT 1) then
              		
                             delete from wtms_tier_sub_product_master d where d.fk_tier_id = tier_id;
                          end if;
                          insert into wtms_tier_sub_product_master(fk_tier_id,fk_tier_type,fk_prod_id,fk_sub_prod_id,create_date)
                          select tier_id,tier_type,prod_id,sub_prod_id ,v_now
                          from tt_temp_sub_prd_mapping;
                          
                          if ROW_COUNT() > 0
                          then
                             set v_errcode = 0;
                             set v_errmsg = 'prod/sub product mapped to tier';
                          end if;
                       Else
              		 insert into wtms_tier_sub_product_master(fk_tier_id,fk_tier_type,fk_prod_id,fk_sub_prod_id,create_date)
                          select tier_id,tier_type,prod_id,sub_prod_id ,v_now
                          from tt_temp_sub_prd_mapping;
                       end if;
              
              	
                       if not exists(select  * from wtms_tier_sub_product_master_MT a where a.fk_tier_id = tier_id LIMIT 1) then
              			
              				  insert into wtms_tier_sub_product_master_MT(fk_tier_id,fk_tier_type,fk_prod_id,fk_sub_prod_id,create_date)
                          select tier_id,tier_type,prod_id,sub_prod_id ,v_now
                          from tt_temp_sub_prd_mapping;
                       end if;
              
              	
                       IF User_Range_xml is not null then
              	
                          CALL worktual_create_tier_price_by_user_Range(tier_id,User_Range_xml,create_by);
                       end if;
              
              	
                       IF tier_summary_map_xml is not null then
              	
                          CALL worktual_create_tier_summary_map(tier_id,tier_summary_map_xml,create_by);
                       end if;
              
              	
                       IF catg_position_xml is not null then
              	
                          CALL worktual_create_tier_category_position(tier_id,catg_position_xml,create_by);
                       end if;
              
              	
                       IF catg_feature_map_xml is not null then
              	
                          CALL worktual_create_tier_catg_feature_map(tier_id,catg_feature_map_xml,create_by);
                       end if;
              
              	
                       IF feature_mapping_xml is not null then
              	
                          CALL worktual_create_tier_feature_mapping_info(tier_id,feature_mapping_xml,create_by);
                       end if;
              
              	
                       insert into wtms_tier_management_log(tier_id,tier_name,tier_description,tier_type,prod_type_id,bund_prd_type,product_id,sub_product_id,fk_purpose_id,status,
              	apply_new_exist_cust,free_or_paid,currency,no_of_users,min_users,contract_period,per_addn_user,per_addn_user_currency,User_Range_xml,tier_summary_map,
              	catg_position_xml,feature_mapping,create_date,create_by,is_review,processtype,catg_feature_map_xml,client_ip,module_id,sub_module_id,country_id,reseller_id,pro_user_count,standard_user_count,basic_user_count)
                       select tier_id,tier_name,tier_description,tier_type,prod_type_id,bund_prd_type,product_id,sub_product_id,fk_purpose_id,status,
              	apply_new_exist_cust,free_or_paid,currency,no_of_users,min_users,contract_period,per_addn_user,per_addn_user_currency,User_Range_xml,
              	tier_summary_map_xml,	catg_position_xml,	feature_mapping_xml,v_now,create_by,is_review,processtype,catg_feature_map_xml,client_ip,module_id,sub_module_id,country_id,reseller_id,pro_user_count,standard_user_count,basic_user_count;
                    END;
                    select v_errcode as errcode, v_errmsg as errmsg, IFNULL(tier_id,0) as tier_id;
                 END; 
              
              
              
              End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_create_tier_management_backup` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_create_tier_management_backup`(
         tier_id INT,
         tier_name VARCHAR(150),
         tier_description VARCHAR(250),
         tier_type INT,							
         prod_type_id INT,					
         bund_prd_type INT,					
         product_id VARCHAR(50),				
         sub_product_id VARCHAR(200),			
         fk_purpose_id VARCHAR(100),			
         status INT,
         apply_new_exist_cust VARCHAR(10),		
         free_or_paid INT,
         currency INT,
         no_of_users VARCHAR(50),			
         min_users INT,
         contract_period VARCHAR(50),		
         per_addn_user FLOAT,
         per_addn_user_currency INT,
         User_Range_xml LONGTEXT,				
         tier_summary_map_xml LONGTEXT,			
         catg_position_xml LONGTEXT,
         catg_feature_map_xml LONGTEXT,
         feature_mapping_xml LONGTEXT,			
         create_by VARCHAR(20),
         is_review INT,						
         client_ip VARCHAR(20),
         processtype INT,						
         country_id int,
         module_id varchar(150),
         sub_module_id varchar(150),
         reseller_id text
         )
Begin
        
        
        
        
       
         
         
         
   		DECLARE v_errcode INT;
   		DECLARE v_errmsg VARCHAR(250);
   		DECLARE v_now DATETIME(3);
   		DECLARE v_id INT;
   		DECLARE v_approver_1_remarks VARCHAR(250);
   		DECLARE v_approver_2_remarks VARCHAR(250);
   		DECLARE v_approver_1_status VARCHAR(250);
   		DECLARE v_approver_2_status VARCHAR(250);
            
            
            DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
            BEGIN
               SET @SWV_Error = 1;
            END;
            IF tier_id is null then
               set tier_id = 0;
            END IF;
            IF prod_type_id is null then
               set prod_type_id = 0;
            END IF;
            IF bund_prd_type is null then
               set bund_prd_type = 0;
            END IF;
            IF no_of_users is null then
               set no_of_users = '';
            END IF;
            IF min_users is null then
               set min_users = 0;
            END IF;
            IF contract_period is null then
               set contract_period = '';
            END IF;
            IF per_addn_user is null then
               set per_addn_user = 0;
            END IF;
            IF tier_summary_map_xml is null then
               set tier_summary_map_xml = '';
            END IF;
            IF catg_position_xml is null then
               set catg_position_xml = '';
            END IF;
            IF catg_feature_map_xml is null then
               set catg_feature_map_xml = '';
            END IF;
            IF feature_mapping_xml is null then
               set feature_mapping_xml = '';
            END IF;
            IF is_review is null then
               set is_review = 1;
            END IF;
            IF client_ip is null then
               set client_ip = '';
            END IF;
             SET @SWV_Error = 0;
            
        		if country_id is null then set country_id = 0 ; end if;
        		if module_id is null then set module_id = '' ; end if;
        		if sub_module_id is null then set sub_module_id = '' ; end if;
            
            
            BEGIN
               DECLARE EXIT HANDLER FOR SQLEXCEPTION
               begin
                  SET v_errcode = @SWV_Error;
                  GET DIAGNOSTICS CONDITION 1 @SWV_ErrorMsg = MESSAGE_TEXT;
                  set v_errmsg = @SWV_ErrorMsg;
             
                  select v_errcode as errcode, v_errmsg as errmsg, IFNULL(tier_id,0) as tier_id;
          
                  insert into wtms_tier_management_log(tier_id,tier_name,tier_description,tier_type,prod_type_id,bund_prd_type,product_id,sub_product_id,fk_purpose_id,status,apply_new_exist_cust,free_or_paid,currency,no_of_users,min_users,contract_period,per_addn_user,per_addn_user_currency,User_Range_xml,tier_summary_map,
        			catg_position_xml,feature_mapping,create_date,create_by,is_review,processtype,catg_feature_map_xml,client_ip,reseller_id)
                  select tier_id,tier_name,tier_description,tier_type,prod_type_id,bund_prd_type,product_id,sub_product_id,fk_purpose_id,status,apply_new_exist_cust,free_or_paid,currency,no_of_users,min_users,contract_period,per_addn_user,per_addn_user_currency,User_Range_xml,
        			tier_summary_map_xml,	catg_position_xml,	feature_mapping_xml,v_now,create_by,is_review,processtype,catg_feature_map_xml,client_ip,reseller_id;
     
              end;
               
               
               sp_exit:
               BEGIN
     
                  set v_now = CURRENT_TIMESTAMP;
                  
                  
                  if (tier_name = '' or tier_name IS NULL) then
         		
                     SET v_errcode = -1;
                     SET v_errmsg = 'Tier Name should not be empty';
                     LEAVE sp_exit;
                  end if;
         
         		
                   DROP TEMPORARY TABLE IF EXISTS  tt_t1_prod_id;
                   CREATE TEMPORARY TABLE tt_t1_prod_id
                   (
                   prod_id int
                   );
                   
    				DROP TEMPORARY TABLE IF EXISTS  tt_t1_sub_prod_id;
    				CREATE TEMPORARY TABLE tt_t1_sub_prod_id
    				(
    				sub_prod_id int
    				);
    
    				call Split(product_id,',');
    
    				insert into tt_t1_prod_id(prod_id)
    				select a.items from tt_Split_temptable a;
                    
         		
         
       				call Split(sub_product_id,',');
               
                    insert into tt_t1_sub_prod_id(sub_prod_id)
    				select a.items from tt_Split_temptable a;
    
                  DROP TEMPORARY TABLE IF EXISTS tt_temp_sub_prd_mapping;
                  create TEMPORARY table tt_temp_sub_prd_mapping
                  (
                     tier_id INT,
                     sub_prod_id INT,
                     prod_id INT
                  );
          
                  if processtype = 1 
                  then
         	
                     if exists(select  * from wtms_tier_management a  where a.tier_name = tier_name LIMIT 1)
                     then
         	
                        SET v_errcode = -1;
                        SET v_errmsg = 'Tier Name already exists';
                        LEAVE sp_exit;
                     end if;
       
        			insert into wtms_tier_management(tier_name,tier_type,tier_description,prod_type_id,bund_prd_type,fk_purpose_id,status,min_users,apply_new_exist_cust,
        			free_or_paid,currency,create_date,modify_date,product_id,sub_product_id,is_review,per_addn_user,per_addn_user_currency,module_id,sub_module_id,country_id,reseller_id)
        			values(tier_name,tier_type,tier_description,prod_type_id,bund_prd_type,fk_purpose_id,status,min_users,apply_new_exist_cust,
        			free_or_paid,currency,v_now,v_now,product_id,sub_product_id,is_review,per_addn_user,per_addn_user_currency,module_id,sub_module_id,country_id,reseller_id);
        
                     set tier_id = LAST_INSERT_ID();
                     if ROW_COUNT() > 0 
                     then
 						
 							call Split(reseller_id,',');
 
 							insert into wtms.wtms_tier_reseller_info(tier_id,reseller_id)
 							select tier_id,a.items from tt_Split_temptable a;
             
 						
         		
         		
        			insert into wtms_copy_of_tier_management_temp(fk_tier_id,tier_name,tier_type,tier_description,prod_type_id,bund_prd_type,fk_purpose_id,status,min_users,apply_new_exist_cust,
        			free_or_paid,currency,create_date,modify_date,product_id,sub_product_id,is_review,per_addn_user,per_addn_user_currency,module_id,sub_module_id,country_id,reseller_id)
        			values(tier_id,tier_name,tier_type,tier_description,prod_type_id,bund_prd_type,fk_purpose_id,status,min_users,apply_new_exist_cust,
        			free_or_paid,currency,v_now,v_now,product_id,sub_product_id,4,per_addn_user,per_addn_user_currency,module_id,sub_module_id,country_id,reseller_id);
         			
                        set v_errcode = 0;
                        set v_errmsg = 'Success : Tier plan created';
                     end if;
                  end if;
              
                  if processtype = 2 
                  then
      
                     if exists(select  * from wtms_tier_management b where b.tier_name = tier_name and b.tier_id <> tier_id LIMIT 1) 
                     then
                        SET v_errcode = -1;
                        SET v_errmsg = 'Tier Name already exists';
                        LEAVE sp_exit;
                     end if;
                     if not exists(select  * from wtms_tier_management c where c.tier_id = tier_id LIMIT 1)
                     then
                        SET v_errcode = -1;
                        SET v_errmsg = 'Tier not exists';
                        LEAVE sp_exit;
                     end if;
                     
                     UPDATE wtms_tier_management a
                     set a.tier_name = IFNULL(tier_name,a.tier_name),
                     a.tier_type = IFNULL(tier_type,a.tier_type),
                     a.tier_description = IFNULL(tier_description,a.tier_description),					
                     a.prod_type_id = IFNULL(prod_type_id,a.prod_type_id),
                     a.bund_prd_type = IFNULL(bund_prd_type,a.bund_prd_type),
                     a.fk_purpose_id = IFNULL(fk_purpose_id,a.fk_purpose_id),
                     a.status = IFNULL(status,a.status),												
                     a.min_users = IFNULL(min_users,a.min_users),
                     a.apply_new_exist_cust = IFNULL(apply_new_exist_cust,a.apply_new_exist_cust),		
                     a.free_or_paid = IFNULL(free_or_paid,a.free_or_paid),
                     a.currency = IFNULL(currency,a.currency),											
                     a.modify_date = v_now,
                     a.contract_period = contract_period,												
                     a.per_addn_user = per_addn_user,
                     a.per_addn_user_currency  = per_addn_user_currency,								
                     a.product_id = IFNULL(product_id,a.product_id),
                     a.sub_product_id = IFNULL(sub_product_id,a.sub_product_id),						
                     a.is_review = IFNULL(is_review,a.is_review),
                     a.sub_module_id = ifnull(sub_module_id,a.sub_module_id),
                     a.module_id = ifnull(module_id,a.module_id),
                     a.country_id = ifnull(country_id,a.country_id),
                     a.reseller_id = ifnull(reseller_id, a.reseller_id)
                     where a.tier_id = tier_id;
                     
                     if ROW_COUNT() > 0 
                     then
                     
 							if exists(select * from  wtms.wtms_tier_reseller_info a where a.tier_id = tier_id) then
 								delete from wtms.wtms_tier_reseller_info a where a.tier_id = tier_id;
                             End if;
                             
                             call Split(reseller_id,',');
 
 							insert into wtms.wtms_tier_reseller_info(tier_id,reseller_id)
 							select tier_id,a.items from tt_Split_temptable a;
                     
         		
                        UPDATE wtms_copy_of_tier_management_temp a
                        set a.tier_name = IFNULL(tier_name,a.tier_name),a.tier_type = IFNULL(tier_type,a.tier_type),
                        a.tier_description = IFNULL(tier_description,a.tier_description),					
                        a.prod_type_id = IFNULL(prod_type_id,a.prod_type_id),
                        a.bund_prd_type = IFNULL(bund_prd_type,a.bund_prd_type),a.fk_purpose_id = IFNULL(fk_purpose_id,a.fk_purpose_id),
                        a.status = IFNULL(status,a.status),												
                        a.min_users = IFNULL(min_users,a.min_users),a.apply_new_exist_cust = IFNULL(apply_new_exist_cust,a.apply_new_exist_cust),		
                        a.free_or_paid = IFNULL(free_or_paid,a.free_or_paid),a.currency = IFNULL(currency,a.currency),											
                        a.modify_date = v_now,a.contract_period = contract_period,												
                        a.per_addn_user = per_addn_user,a.per_addn_user_currency  = per_addn_user_currency,								
                        a.product_id = IFNULL(product_id,a.product_id),
                        a.sub_product_id = IFNULL(sub_product_id,a.sub_product_id),						
                        a.is_review = 4, 
                        a.sub_module_id = ifnull(sub_module_id,a.sub_module_id),
                     a.module_id = ifnull(module_id,a.module_id),
                     a.country_id = ifnull(country_id,a.country_id),
                     a.reseller_id = ifnull(reseller_id, a.reseller_id)
                        where a.fk_tier_id = tier_id;
                        SET v_errcode = 0;
                        SET v_errmsg = 'Tier updated';
                        
   					
                         if exists(select * from wtms_tier_approval_management a where a.fk_tier_id = tier_id limit 1) then 
                         
   						select   max(a.id) INTO v_id from wtms_tier_approval_management a where a.fk_tier_id = tier_id;
                           
   							select   a.approver_1_status, a.approver_2_status, a.approver_1_remarks, a.approver_2_remarks 
   							INTO v_approver_1_status,v_approver_2_status,v_approver_1_remarks,v_approver_2_remarks 
   							from wtms_tier_approval_management a where a.fk_tier_id = tier_id and a.id = v_id;
                               
                               if v_approver_1_status = 'Approved' and v_approver_2_status = 'Approved' then
   								insert into wtms_tier_approval_management(fk_tier_id,approver_1_userid,approver_1_user_group_name,approver_1_status,approver_1_approved_on,
   								approver_1_remarks,approver_2_userid,approver_2_user_group_name,approver_2_status,approver_2_approved_on,approver_2_remarks,approver_1_username,approver_2_username)
   								values(tier_id,0,'',null,current_timestamp,'',0,'','',null,'','','');
                               End if;
   
                         End if;
                        
                       
                        
                     end if;
                  end if;
                  
                  if sub_product_id = '' or sub_product_id = 0
                  then
         		
         		  insert into tt_temp_sub_prd_mapping(tier_id,sub_prod_id,prod_id)
                     select tier_id as tier_id,0 as sub_prod_id,a.prod_id as prod_id
                     from product_master a
                     where a.prod_id in(select c.prod_id from tt_t1_prod_id c) and a.prod_status = 1;
                  Else
         		
         		 insert into tt_temp_sub_prd_mapping(tier_id,sub_prod_id,prod_id)
                     select tier_id as tier_id,a.catg_id as sub_prod_id,a.fk_prod_id as prod_id
                     from product_category_master a
                     where a.catg_id in(select b.sub_prod_id from tt_t1_sub_prod_id b)
                     and a.fk_prod_id in(select c.prod_id from tt_t1_prod_id c join product_master d on c.prod_id = d.prod_id where d.prod_status = 1)
                     and a.category_status = 1;
                  end if;
                  if exists(select  * from wtms_tier_sub_product_master b where b.fk_tier_id = tier_id LIMIT 1) then
         	
                     if exists(select  * from tt_temp_sub_prd_mapping c where c.tier_id = tier_id LIMIT 1) then
         		
                        delete from wtms_tier_sub_product_master d where d.fk_tier_id = tier_id;
                     end if;
                     insert into wtms_tier_sub_product_master(fk_tier_id,fk_tier_type,fk_prod_id,fk_sub_prod_id,create_date)
                     select tier_id,tier_type,prod_id,sub_prod_id ,v_now
                     from tt_temp_sub_prd_mapping;
                     
                     if ROW_COUNT() > 0
                     then
                        set v_errcode = 0;
                        set v_errmsg = 'prod/sub product mapped to tier';
                     end if;
                  Else
         		 insert into wtms_tier_sub_product_master(fk_tier_id,fk_tier_type,fk_prod_id,fk_sub_prod_id,create_date)
                     select tier_id,tier_type,prod_id,sub_prod_id ,v_now
                     from tt_temp_sub_prd_mapping;
                  end if;
         
         	
                  if not exists(select  * from wtms_tier_sub_product_master_MT a where a.fk_tier_id = tier_id LIMIT 1) then
         			
         				  insert into wtms_tier_sub_product_master_MT(fk_tier_id,fk_tier_type,fk_prod_id,fk_sub_prod_id,create_date)
                     select tier_id,tier_type,prod_id,sub_prod_id ,v_now
                     from tt_temp_sub_prd_mapping;
                  end if;
         
         	
                  IF User_Range_xml is not null then
         	
                     CALL worktual_create_tier_price_by_user_Range(tier_id,User_Range_xml,create_by);
                  end if;
         
         	
                  IF tier_summary_map_xml is not null then
         	
                     CALL worktual_create_tier_summary_map(tier_id,tier_summary_map_xml,create_by);
                  end if;
         
         	
                  IF catg_position_xml is not null then
         	
                     CALL worktual_create_tier_category_position(tier_id,catg_position_xml,create_by);
                  end if;
         
         	
                  IF catg_feature_map_xml is not null then
         	
                     CALL worktual_create_tier_catg_feature_map(tier_id,catg_feature_map_xml,create_by);
                  end if;
         
         	
                  IF feature_mapping_xml is not null then
         	
                     CALL worktual_create_tier_feature_mapping_info(tier_id,feature_mapping_xml,create_by);
                  end if;
         
         	
                  insert into wtms_tier_management_log(tier_id,tier_name,tier_description,tier_type,prod_type_id,bund_prd_type,product_id,sub_product_id,fk_purpose_id,status,
         	apply_new_exist_cust,free_or_paid,currency,no_of_users,min_users,contract_period,per_addn_user,per_addn_user_currency,User_Range_xml,tier_summary_map,
         	catg_position_xml,feature_mapping,create_date,create_by,is_review,processtype,catg_feature_map_xml,client_ip,module_id,sub_module_id,country_id,reseller_id)
                  select tier_id,tier_name,tier_description,tier_type,prod_type_id,bund_prd_type,product_id,sub_product_id,fk_purpose_id,status,
         	apply_new_exist_cust,free_or_paid,currency,no_of_users,min_users,contract_period,per_addn_user,per_addn_user_currency,User_Range_xml,
         	tier_summary_map_xml,	catg_position_xml,	feature_mapping_xml,v_now,create_by,is_review,processtype,catg_feature_map_xml,client_ip,module_id,sub_module_id,country_id,reseller_id;
               END;
               select v_errcode as errcode, v_errmsg as errmsg, IFNULL(tier_id,0) as tier_id;
            END; 
         
         
         
         End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_create_tier_management_test` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_create_tier_management_test`(
   tier_id INT,
   tier_name VARCHAR(150),
   tier_description VARCHAR(250),
   tier_type INT,							
   prod_type_id INT,					
   bund_prd_type INT,					
   product_id VARCHAR(50),				
   sub_product_id VARCHAR(200),			
   fk_purpose_id VARCHAR(100),			
   status INT,
   apply_new_exist_cust VARCHAR(10),		
   free_or_paid INT,
   currency INT,
   no_of_users VARCHAR(50),			
   min_users INT,
   contract_period VARCHAR(50),		
   per_addn_user FLOAT,
   per_addn_user_currency INT,
   User_Range_xml LONGTEXT,				
   tier_summary_map_xml LONGTEXT,			
   catg_position_xml LONGTEXT,
   catg_feature_map_xml LONGTEXT,
   feature_mapping_xml LONGTEXT,			
   create_by VARCHAR(20),
   is_review INT,						
   client_ip VARCHAR(20),
   processtype INT,						
   country_id int,
   module_id varchar(150),
   sub_module_id varchar(150)
   )
Begin
  
 
   
   
   
      DECLARE v_errcode INT;
      DECLARE v_errmsg VARCHAR(250);
      DECLARE v_now DATETIME(3);
      
      
      DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
      BEGIN
         SET @SWV_Error = 1;
      END;
      IF tier_id is null then
         set tier_id = 0;
      END IF;
      IF prod_type_id is null then
         set prod_type_id = 0;
      END IF;
      IF bund_prd_type is null then
         set bund_prd_type = 0;
      END IF;
      IF no_of_users is null then
         set no_of_users = '';
      END IF;
      IF min_users is null then
         set min_users = 0;
      END IF;
      IF contract_period is null then
         set contract_period = '';
      END IF;
      IF per_addn_user is null then
         set per_addn_user = 0;
      END IF;
      IF tier_summary_map_xml is null then
         set tier_summary_map_xml = '';
      END IF;
      IF catg_position_xml is null then
         set catg_position_xml = '';
      END IF;
      IF catg_feature_map_xml is null then
         set catg_feature_map_xml = '';
      END IF;
      IF feature_mapping_xml is null then
         set feature_mapping_xml = '';
      END IF;
      IF is_review is null then
         set is_review = 1;
      END IF;
      IF client_ip is null then
         set client_ip = '';
      END IF;
      SET @SWV_Error = 0;
      
  		if country_id is null then set country_id = 0 ; end if;
  		if module_id is null then set module_id = '' ; end if;
  		if sub_module_id is null then set sub_module_id = '' ; end if;
      
      
      BEGIN
      
         sp_exit:
         BEGIN
            set v_now = CURRENT_TIMESTAMP;
            if (tier_name = '' or tier_name IS NULL) then
   		
               SET v_errcode = -1;
               SET v_errmsg = 'Tier Name should not be empty';
               LEAVE sp_exit;
            end if;
   
   		
             CREATE TEMPORARY TABLE tt_t1_prod_id
             (
             prod_id int
             );
               CREATE TEMPORARY TABLE tt_t1_sub_prod_id
             (
             sub_prod_id int
             );
           
     
             call Split(product_id,',');
         
               insert into tt_t1_prod_id(prod_id)
  		select Items from tt_Split_temptable;
               DROP  TABLE IF EXISTS tt_Split_temptable;
               
   		
   
 				call Split(sub_product_id,',');
         
               insert into tt_t1_sub_prod_id(sub_prod_id)
         select Items from tt_Split_temptable;
               DROP  TABLE IF EXISTS tt_Split_temptable;
            
            
            DROP TEMPORARY TABLE IF EXISTS tt_temp_sub_prd_mapping;
            create TEMPORARY table tt_temp_sub_prd_mapping
            (
               tier_id INT,
               sub_prod_id INT,
               prod_id INT
            );
    
    
            if processtype = 1 
            then
   	
               if exists(select  * from wtms_tier_management a  where a.tier_name = tier_name LIMIT 1)
               then
   	
                  SET v_errcode = -1;
                  SET v_errmsg = 'Tier Name already exists';
                  LEAVE sp_exit;
               end if;
 
  			insert into wtms_tier_management(tier_name,tier_type,tier_description,prod_type_id,bund_prd_type,fk_purpose_id,status,min_users,apply_new_exist_cust,
  			free_or_paid,currency,create_date,modify_date,product_id,sub_product_id,is_review,per_addn_user,per_addn_user_currency,module_id,sub_module_id,country_id)
  			values(tier_name,tier_type,tier_description,prod_type_id,bund_prd_type,fk_purpose_id,status,min_users,apply_new_exist_cust,
  			free_or_paid,currency,v_now,v_now,product_id,sub_product_id,is_review,per_addn_user,per_addn_user_currency,module_id,sub_module_id,country_id);
  
               set tier_id = LAST_INSERT_ID();
               if ROW_COUNT() > 0 
               then
   		
   		
  			insert into wtms_copy_of_tier_management_temp(fk_tier_id,tier_name,tier_type,tier_description,prod_type_id,bund_prd_type,fk_purpose_id,status,min_users,apply_new_exist_cust,
  			free_or_paid,currency,create_date,modify_date,product_id,sub_product_id,is_review,per_addn_user,per_addn_user_currency,module_id,sub_module_id,country_id)
  			values(tier_id,tier_name,tier_type,tier_description,prod_type_id,bund_prd_type,fk_purpose_id,status,min_users,apply_new_exist_cust,
  			free_or_paid,currency,v_now,v_now,product_id,sub_product_id,is_review,per_addn_user,per_addn_user_currency,module_id,sub_module_id,country_id);
   			
                  set v_errcode = 0;
                  set v_errmsg = 'Success : Tier plan created';
               end if;
            end if;
        
            if processtype = 2 
            then

               if exists(select  * from wtms_tier_management b where b.tier_name = tier_name and b.tier_id <> tier_id LIMIT 1) 
               then
                  SET v_errcode = -1;
                  SET v_errmsg = 'Tier Name already exists';
                  LEAVE sp_exit;
               end if;
               if not exists(select  * from wtms_tier_management c where c.tier_id = tier_id LIMIT 1)
               then
                  SET v_errcode = -1;
                  SET v_errmsg = 'Tier not exists';
                  LEAVE sp_exit;
               end if;
               
               UPDATE wtms_tier_management a
               set a.tier_name = IFNULL(tier_name,a.tier_name),
               a.tier_type = IFNULL(tier_type,a.tier_type),
               a.tier_description = IFNULL(tier_description,a.tier_description),					
               a.prod_type_id = IFNULL(prod_type_id,a.prod_type_id),
               a.bund_prd_type = IFNULL(bund_prd_type,a.bund_prd_type),
               a.fk_purpose_id = IFNULL(fk_purpose_id,a.fk_purpose_id),
               a.status = IFNULL(status,a.status),												
               a.min_users = IFNULL(min_users,a.min_users),
               a.apply_new_exist_cust = IFNULL(apply_new_exist_cust,a.apply_new_exist_cust),		
               a.free_or_paid = IFNULL(free_or_paid,a.free_or_paid),
               a.currency = IFNULL(currency,a.currency),											
               a.modify_date = v_now,
               a.contract_period = contract_period,												
               a.per_addn_user = per_addn_user,
               a.per_addn_user_currency  = per_addn_user_currency,								
               a.product_id = IFNULL(product_id,a.product_id),
               a.sub_product_id = IFNULL(sub_product_id,a.sub_product_id),						
               a.is_review = IFNULL(is_review,a.is_review),
               a.sub_module_id = ifnull(sub_module_id,a.sub_module_id),
               a.module_id = ifnull(module_id,a.module_id),
               a.country_id = ifnull(country_id,a.country_id)
               where a.tier_id = tier_id;
               
               if ROW_COUNT() > 0 
               then
   		
                  UPDATE wtms_copy_of_tier_management_temp a
                  set a.tier_name = IFNULL(tier_name,a.tier_name),a.tier_type = IFNULL(tier_type,a.tier_type),
                  a.tier_description = IFNULL(tier_description,a.tier_description),					
                  a.prod_type_id = IFNULL(prod_type_id,a.prod_type_id),
                  a.bund_prd_type = IFNULL(bund_prd_type,a.bund_prd_type),a.fk_purpose_id = IFNULL(fk_purpose_id,a.fk_purpose_id),
                  a.status = IFNULL(status,a.status),												
                  a.min_users = IFNULL(min_users,a.min_users),a.apply_new_exist_cust = IFNULL(apply_new_exist_cust,a.apply_new_exist_cust),		
                  a.free_or_paid = IFNULL(free_or_paid,a.free_or_paid),a.currency = IFNULL(currency,a.currency),											
                  a.modify_date = v_now,a.contract_period = contract_period,												
                  a.per_addn_user = per_addn_user,a.per_addn_user_currency  = per_addn_user_currency,								
                  a.product_id = IFNULL(product_id,a.product_id),
                  a.sub_product_id = IFNULL(sub_product_id,a.sub_product_id),						
                  a.is_review = IFNULL(is_review,a.is_review),
                  a.sub_module_id = ifnull(sub_module_id,a.sub_module_id),
               a.module_id = ifnull(module_id,a.module_id),
               a.country_id = ifnull(country_id,a.country_id)
                  where a.fk_tier_id = tier_id;
                  SET v_errcode = 0;
                  SET v_errmsg = 'Tier updated';
               end if;
            end if;
            
            if sub_product_id = '' or sub_product_id = 0
            then
   		
   		  insert into tt_temp_sub_prd_mapping(tier_id,sub_prod_id,prod_id)
               select tier_id as tier_id,0 as sub_prod_id,a.prod_id as prod_id
               from product_master a
               where a.prod_id in(select c.prod_id from tt_t1_prod_id c) and a.prod_status = 1;
            Else
   		
   		 insert into tt_temp_sub_prd_mapping(tier_id,sub_prod_id,prod_id)
               select tier_id as tier_id,a.catg_id as sub_prod_id,a.fk_prod_id as prod_id
               from product_category_master a
               where a.catg_id in(select b.sub_prod_id from tt_t1_sub_prod_id b)
               and a.fk_prod_id in(select c.prod_id from tt_t1_prod_id c join product_master d on c.prod_id = d.prod_id where d.prod_status = 1)
               and a.category_status = 1;
            end if;
            if exists(select  * from wtms_tier_sub_product_master b where b.fk_tier_id = tier_id LIMIT 1) then
   	
               if exists(select  * from tt_temp_sub_prd_mapping c where c.tier_id = tier_id LIMIT 1) then
   		
                  delete from wtms_tier_sub_product_master d where d.fk_tier_id = tier_id;
               end if;
               insert into wtms_tier_sub_product_master(fk_tier_id,fk_tier_type,fk_prod_id,fk_sub_prod_id,create_date)
               select tier_id,tier_type,prod_id,sub_prod_id ,v_now
               from tt_temp_sub_prd_mapping;
               
               if ROW_COUNT() > 0
               then
                  set v_errcode = 0;
                  set v_errmsg = 'prod/sub product mapped to tier';
               end if;
            Else
   		 insert into wtms_tier_sub_product_master(fk_tier_id,fk_tier_type,fk_prod_id,fk_sub_prod_id,create_date)
               select tier_id,tier_type,prod_id,sub_prod_id ,v_now
               from tt_temp_sub_prd_mapping;
            end if;
   
   	
            if not exists(select  * from wtms_tier_sub_product_master_MT a where a.fk_tier_id = tier_id LIMIT 1) then
   			
   				  insert into wtms_tier_sub_product_master_MT(fk_tier_id,fk_tier_type,fk_prod_id,fk_sub_prod_id,create_date)
               select tier_id,tier_type,prod_id,sub_prod_id ,v_now
               from tt_temp_sub_prd_mapping;
            end if;
   
   	
            IF User_Range_xml is not null then
   	
               CALL worktual_create_tier_price_by_user_Range(tier_id,User_Range_xml,create_by);
            end if;
   
   	
            IF tier_summary_map_xml is not null then
   	
               CALL worktual_create_tier_summary_map(tier_id,tier_summary_map_xml,create_by);
            end if;
   
   	
            IF catg_position_xml is not null then
   	
               CALL worktual_create_tier_category_position(tier_id,catg_position_xml,create_by);
            end if;
   
   	
            IF catg_feature_map_xml is not null then
   	
               CALL worktual_create_tier_catg_feature_map(tier_id,catg_feature_map_xml,create_by);
            end if;
   
   	
            IF feature_mapping_xml is not null then
   	
               CALL worktual_create_tier_feature_mapping_info(tier_id,feature_mapping_xml,create_by);
            end if;
   
   	
            insert into wtms_tier_management_log(tier_id,tier_name,tier_description,tier_type,prod_type_id,bund_prd_type,product_id,sub_product_id,fk_purpose_id,status,
   	apply_new_exist_cust,free_or_paid,currency,no_of_users,min_users,contract_period,per_addn_user,per_addn_user_currency,User_Range_xml,tier_summary_map,
   	catg_position_xml,feature_mapping,create_date,create_by,is_review,processtype,catg_feature_map_xml,client_ip,module_id,sub_module_id,country_id)
            select tier_id,tier_name,tier_description,tier_type,prod_type_id,bund_prd_type,product_id,sub_product_id,fk_purpose_id,status,
   	apply_new_exist_cust,free_or_paid,currency,no_of_users,min_users,contract_period,per_addn_user,per_addn_user_currency,User_Range_xml,
   	tier_summary_map_xml,	catg_position_xml,	feature_mapping_xml,v_now,create_by,is_review,processtype,catg_feature_map_xml,client_ip,module_id,sub_module_id,country_id;
         END;
         select v_errcode as errcode, v_errmsg as errmsg, IFNULL(tier_id,0) as tier_id;
      END; 
   
   
   
   End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_create_tier_platform_fee_json` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_create_tier_platform_fee_json`(
    p_tier_id int,
    p_platform_fee_json_info json
    )
Begin
    
    
    
		DECLARE v_JLength INT;
   
   		SET v_JLength = JSON_LENGTH(p_platform_fee_json_info, "$");
        
   		DROP TEMPORARY TABLE IF EXISTS tt_platform_fee_json_info;
   		CREATE TEMPORARY TABLE tt_platform_fee_json_info AS
   		WITH RECURSIVE CTE_JsonCount AS (
   			SELECT 0 SlNo
   			UNION ALL
   			SELECT SlNo + 1 SlNo
   			FROM CTE_JsonCount
   			WHERE SlNo < v_JLength - 1
   		)
		SELECT 
			TRIM(BOTH '"' FROM (json_extract(p_platform_fee_json_info, CONCAT('$[', SlNo, '].tier_id')))) AS tier_id,
			TRIM(BOTH '"' FROM (json_extract(p_platform_fee_json_info, CONCAT('$[', SlNo, '].platform_fee_name')))) AS platform_fee_name,
			TRIM(BOTH '"' FROM (json_extract(p_platform_fee_json_info, CONCAT('$[', SlNo, '].platform_fee_month_price')))) AS platform_fee_month_price,
			TRIM(BOTH '"' FROM (json_extract(p_platform_fee_json_info, CONCAT('$[', SlNo, '].platform_fee_yearly_price')))) AS platform_fee_yearly_price,
			TRIM(BOTH '"' FROM (json_extract(p_platform_fee_json_info, CONCAT('$[', SlNo, '].platform_fee_count')))) AS platform_fee_count
 		FROM CTE_JsonCount;
         
         if exists(select 1 from wtms_tier_platform_fee_info a where a.tier_id = p_tier_id limit 1) then
			delete from wtms_tier_platform_fee_info where tier_id = p_tier_id;
         end if;
         
         insert into wtms_tier_platform_fee_info(tier_id,platform_fee_name,platform_fee_month_price,platform_fee_yearly_price,platform_fee_count)
         select p_tier_id,platform_fee_name,platform_fee_month_price,platform_fee_yearly_price,platform_fee_count from tt_platform_fee_json_info;
 
    End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_create_tier_price_by_user_Range` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_create_tier_price_by_user_Range`(
     tier_id int,
     tier_price_range_xml longtext,
     create_by varchar(50)
     )
begin
     
     
     
     
     	declare errcode int ;
     	declare errmsg varchar(160);
     	declare now datetime;
     
     	DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
     	BEGIN
     		SET @SWV_Error = 1;
     	END;
         
     	IF create_by is null then
     		set create_by = 'admin';
     	END IF;
         
        SET @SWV_Error = 0;
        
     	Begin
         
     	 DECLARE EXIT HANDLER FOR SQLEXCEPTION
          
           begin
              SET errcode = @SWV_Error;
              GET STACKED DIAGNOSTICS CONDITION 1 errmsg = MESSAGE_TEXT;
              select errcode as errcode, errmsg as errmsg;
           end;
           
           set now = current_timestamp;
     
     	drop temporary table if exists temp_plan_price_range_xml_structure;
     	create temporary table temp_plan_price_range_xml_structure
     	(
     		id int auto_increment primary key,
             tier_id int,
     		users_type_id int,
     		contract_period_id int,
     		price1 float,
     		price2 float,
     		price3 float,
     		discount1 float,
     		discount2 float,
     		months1 int,
     		months2 int,
     		min_user_count int,
            max_user_count int
     	 );
     
     		drop temporary table if exists xml_users_type_id_tbl; create temporary table xml_users_type_id_tbl(id int auto_increment primary key, users_type_id varchar(100));
     		drop temporary table if exists xml_contract_period_id_tbl; create temporary table xml_contract_period_id_tbl(id int auto_increment primary key, contract_period_id varchar(100));
     		drop temporary table if exists xml_price1_tbl; create temporary table xml_price1_tbl(id int auto_increment primary key, price1 varchar(100));
     		drop temporary table if exists xml_price2_tbl; create temporary table xml_price2_tbl(id int auto_increment primary key, price2 varchar(100));
     		drop temporary table if exists xml_price3_tbl; create temporary table xml_price3_tbl(id int auto_increment primary key, price3 varchar(100));
     		drop temporary table if exists xml_discount1_tbl; create temporary table xml_discount1_tbl(id int auto_increment primary key, discount1 varchar(100));
     		drop temporary table if exists xml_discount2_tbl; create temporary table xml_discount2_tbl(id int auto_increment primary key, discount2 varchar(100));
     		drop temporary table if exists xml_months1_tbl; create temporary table xml_months1_tbl(id int auto_increment primary key, months1 varchar(100));
     		drop temporary table if exists xml_months2_tbl; create temporary table xml_months2_tbl(id int auto_increment primary key, months2 varchar(100));
     		drop temporary table if exists xml_min_user_count_tbl; create temporary table xml_min_user_count_tbl(id int auto_increment primary key, min_user_count varchar(100));
            drop temporary table if exists xml_max_user_count_tbl; create temporary table xml_max_user_count_tbl(id int auto_increment primary key, max_user_count varchar(100));
     
     		set @contract_period_id:=extractvalue(tier_price_range_xml,"//Tier/Range/contract/@contract_period_id");
     		set @price1:=extractvalue(tier_price_range_xml,"//Tier/Range/contract/@price1");
     		set @price2:=extractvalue(tier_price_range_xml,"//Tier/Range/contract/@price2");
     		set @price3:=extractvalue(tier_price_range_xml,"//Tier/Range/contract/@price3");
     		set @discount1:=extractvalue(tier_price_range_xml,"//Tier/Range/contract/@discount1");
     		set @discount2:=extractvalue(tier_price_range_xml,"//Tier/Range/contract/@discount2");
     		set @months1:=extractvalue(tier_price_range_xml,"//Tier/Range/contract/@months1");
     		set @months2:=extractvalue(tier_price_range_xml,"//Tier/Range/contract/@months2");
     		set @users_type_id:=extractvalue(tier_price_range_xml,"//Tier/Range/contract/@users_type_id");
     		set @min_user_count:=extractvalue(tier_price_range_xml,"//Tier/Range/contract/@min_user_count");
            set @max_user_count:=extractvalue(tier_price_range_xml,"//Tier/Range/contract/@max_user_count");
             
     		call unifiedring.Split(replace(@contract_period_id,' ',','),','); insert into xml_contract_period_id_tbl(contract_period_id) select Items from unifiedring.tt_Split_temptable;
     		call unifiedring.Split(replace(@price1,' ',','),','); insert into xml_price1_tbl(price1) select Items from unifiedring.tt_Split_temptable;
     		call unifiedring.Split(replace(@price2,' ',','),','); insert into xml_price2_tbl(price2) select Items from unifiedring.tt_Split_temptable;
     		call unifiedring.Split(replace(@price3,' ',','),','); insert into xml_price3_tbl(price3) select Items from unifiedring.tt_Split_temptable;
     		call unifiedring.Split(replace(@discount1,' ',','),','); insert into xml_discount1_tbl(discount1) select Items from unifiedring.tt_Split_temptable;
     		call unifiedring.Split(replace(@discount2,' ',','),','); insert into xml_discount2_tbl(discount2) select Items from unifiedring.tt_Split_temptable;
     		call unifiedring.Split(replace(@months1,' ',','),','); insert into xml_months1_tbl(months1) select Items from unifiedring.tt_Split_temptable;
     		call unifiedring.Split(replace(@months2,' ',','),','); insert into xml_months2_tbl(months2) select Items from unifiedring.tt_Split_temptable;
     		call unifiedring.Split(replace(@users_type_id,' ',','),','); insert into xml_users_type_id_tbl(users_type_id) select Items from unifiedring.tt_Split_temptable;
     		call unifiedring.Split(replace(@min_user_count,' ',','),','); insert into xml_min_user_count_tbl(min_user_count) select Items from unifiedring.tt_Split_temptable;
            call unifiedring.Split(replace(@max_user_count,' ',','),','); insert into xml_max_user_count_tbl(max_user_count) select Items from unifiedring.tt_Split_temptable;
            
    
     		INSERT INTO temp_plan_price_range_xml_structure(tier_id,users_type_id,contract_period_id,price1,price2,price3,discount1,discount2,months1,months2,min_user_count,max_user_count)
     		SELECT tier_id,a.users_type_id,b.contract_period_id,c.price1,d.price2,e.price3,f.discount1,g.discount2,h.months1,i.months2,j.min_user_count,k.max_user_count
     		from xml_users_type_id_tbl a 
     		left join xml_contract_period_id_tbl b on a.id = b.id
     		left join xml_price1_tbl c on a.id = c.id
     		left join xml_price2_tbl d on a.id = d.id
     		left join xml_price3_tbl e on a.id = e.id
     		left join xml_discount1_tbl f on a.id = f.id
     		left join xml_discount2_tbl g on a.id = g.id
     		left join xml_months1_tbl h on a.id = h.id
     		left join xml_months2_tbl i on a.id = i.id
     		left join xml_min_user_count_tbl j on a.id = j.id
            left join xml_max_user_count_tbl k on a.id = k.id;
             
         if exists(select * from wtms_contract_pricing_dtl a where a.tier_id=tier_id limit 1) then
     		delete from wtms_contract_pricing_dtl a where a.tier_id=tier_id;
     	end if;
     	
     	insert into wtms_contract_pricing_dtl(tier_id,fk_user_type_id,fk_contract_period_id,price1,discount1,price2,discount2,price3,min_user,create_by,create_date,months1,months2,max_user)
     	select Distinct tier_id,a.users_type_id,a.contract_period_id,a.price1,a.discount1,a.price2,a.discount2,a.price3,a.min_user_count,create_by,now,a.months1,a.months2,a.max_user_count
     	from temp_plan_price_range_xml_structure a;
     
     	IF ROW_COUNT()>0 then
     	
     		
     		if not exists(select * from wtms_contract_pricing_dtl_MT a where a.tier_id = tier_id limit 1) then 
     			insert into wtms_contract_pricing_dtl_MT(tier_id,fk_user_type_id,fk_contract_period_id,price1,discount1,price2,discount2,price3,min_user,create_by,create_date,months1,months2,max_user)
     			select Distinct tier_id,a.users_type_id,a.contract_period_id,a.price1,a.discount1,a.price2,a.discount2,a.price3,a.min_user_count,create_by,now,a.months1,a.months2,a.max_user_count
     			from temp_plan_price_range_xml_structure a;
     		End if;
     
     		SET errcode=0;
     		SET errmsg='Sucess';
     	
     	END if;
     
     End;
     
     End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_create_tier_price_by_user_Range_backup` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_create_tier_price_by_user_Range_backup`(
  tier_id int,
  tier_price_range_xml longtext,
  create_by varchar(50)
  )
begin
  
  
  
  
  	declare errcode int ;
  	declare errmsg varchar(160);
  	declare now datetime;
  
  	DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
  	BEGIN
  		SET @SWV_Error = 1;
  	END;
      
  	IF create_by is null then
  		set create_by = 'admin';
  	END IF;
      
     SET @SWV_Error = 0;
     
  	Begin
      
  	 DECLARE EXIT HANDLER FOR SQLEXCEPTION
       
        begin
           SET errcode = @SWV_Error;
           GET DIAGNOSTICS CONDITION 1 @SWV_ErrorMsg = MESSAGE_TEXT;
           set errmsg = @SWV_ErrorMsg;
           select errcode as errcode, errmsg as errmsg;
        end;
        
        set now = current_timestamp;
  
  	drop temporary table if exists temp_plan_price_range_xml_structure;
  	create temporary table temp_plan_price_range_xml_structure
  	(
  		id int auto_increment primary key,
          tier_id int,
  		users_type_id int,
  		contract_period_id int,
  		price1 float,
  		price2 float,
  		price3 float,
  		discount1 float,
  		discount2 float,
  		months1 int,
  		months2 int,
  		min_user_count int
  	 );
  
  		drop temporary table if exists xml_users_type_id_tbl; create temporary table xml_users_type_id_tbl(id int auto_increment primary key, users_type_id varchar(100));
  		drop temporary table if exists xml_contract_period_id_tbl; create temporary table xml_contract_period_id_tbl(id int auto_increment primary key, contract_period_id varchar(100));
  		drop temporary table if exists xml_price1_tbl; create temporary table xml_price1_tbl(id int auto_increment primary key, price1 float);
  		drop temporary table if exists xml_price2_tbl; create temporary table xml_price2_tbl(id int auto_increment primary key, price2 float);
  		drop temporary table if exists xml_price3_tbl; create temporary table xml_price3_tbl(id int auto_increment primary key, price3 float);
  		drop temporary table if exists xml_discount1_tbl; create temporary table xml_discount1_tbl(id int auto_increment primary key, discount1 float);
  		drop temporary table if exists xml_discount2_tbl; create temporary table xml_discount2_tbl(id int auto_increment primary key, discount2 float);
  		drop temporary table if exists xml_months1_tbl; create temporary table xml_months1_tbl(id int auto_increment primary key, months1 varchar(100));
  		drop temporary table if exists xml_months2_tbl; create temporary table xml_months2_tbl(id int auto_increment primary key, months2 varchar(100));
  		drop temporary table if exists xml_min_user_count_tbl; create temporary table xml_min_user_count_tbl(id int auto_increment primary key, min_user_count varchar(100));
  
  		set @contract_period_id:=extractvalue(tier_price_range_xml,"//Tier/Range/contract/@contract_period_id");
  		set @price1:=extractvalue(tier_price_range_xml,"//Tier/Range/contract/@price1");
  		set @price2:=extractvalue(tier_price_range_xml,"//Tier/Range/contract/@price2");
  		set @price3:=extractvalue(tier_price_range_xml,"//Tier/Range/contract/@price3");
  		set @discount1:=extractvalue(tier_price_range_xml,"//Tier/Range/contract/@discount1");
  		set @discount2:=extractvalue(tier_price_range_xml,"//Tier/Range/contract/@discount2");
  		set @months1:=extractvalue(tier_price_range_xml,"//Tier/Range/contract/@months1");
  		set @months2:=extractvalue(tier_price_range_xml,"//Tier/Range/contract/@months2");
  		set @users_type_id:=extractvalue(tier_price_range_xml,"//Tier/Range/contract/@users_type_id");
  		set @min_user_count:=extractvalue(tier_price_range_xml,"//Tier/Range/contract/@min_user_count");
          
  		call unifiedring.Split(replace(@contract_period_id,' ',','),','); insert into xml_contract_period_id_tbl(contract_period_id) select Items from unifiedring.tt_Split_temptable;
  		call unifiedring.Split(replace(@price1,' ',','),','); insert into xml_price1_tbl(price1) select Items from unifiedring.tt_Split_temptable;
  		call unifiedring.Split(replace(@price2,' ',','),','); insert into xml_price2_tbl(price2) select Items from unifiedring.tt_Split_temptable;
  		call unifiedring.Split(replace(@price3,' ',','),','); insert into xml_price3_tbl(price3) select Items from unifiedring.tt_Split_temptable;
  		call unifiedring.Split(replace(@discount1,' ',','),','); insert into xml_discount1_tbl(discount1) select Items from unifiedring.tt_Split_temptable;
  		call unifiedring.Split(replace(@discount2,' ',','),','); insert into xml_discount2_tbl(discount2) select Items from unifiedring.tt_Split_temptable;
  		call unifiedring.Split(replace(@months1,' ',','),','); insert into xml_months1_tbl(months1) select Items from unifiedring.tt_Split_temptable;
  		call unifiedring.Split(replace(@months2,' ',','),','); insert into xml_months2_tbl(months2) select Items from unifiedring.tt_Split_temptable;
  		call unifiedring.Split(replace(@users_type_id,' ',','),','); insert into xml_users_type_id_tbl(users_type_id) select Items from unifiedring.tt_Split_temptable;
  		call unifiedring.Split(replace(@min_user_count,' ',','),','); insert into xml_min_user_count_tbl(min_user_count) select Items from unifiedring.tt_Split_temptable;
  		
  		INSERT INTO temp_plan_price_range_xml_structure(tier_id,users_type_id,contract_period_id,price1,price2,price3,discount1,discount2,months1,months2,min_user_count)
  		SELECT tier_id,a.users_type_id,b.contract_period_id,c.price1,d.price2,e.price3,f.discount1,g.discount2,h.months1,i.months2,j.min_user_count
  		from xml_users_type_id_tbl a 
  		left join xml_contract_period_id_tbl b on a.id = b.id
  		left join xml_price1_tbl c on a.id = c.id
  		left join xml_price2_tbl d on a.id = d.id
  		left join xml_price3_tbl e on a.id = e.id
  		left join xml_discount1_tbl f on a.id = f.id
  		left join xml_discount2_tbl g on a.id = g.id
  		left join xml_months1_tbl h on a.id = h.id
  		left join xml_months2_tbl i on a.id = i.id
  		left join xml_min_user_count_tbl j on a.id = j.id;
          
      if exists(select * from wtms_contract_pricing_dtl a where a.tier_id=tier_id limit 1) then
  		delete from wtms_contract_pricing_dtl a where a.tier_id=tier_id;
  	end if;
  	
  	insert into wtms_contract_pricing_dtl(tier_id,fk_user_type_id,fk_contract_period_id,price1,discount1,price2,discount2,price3,min_user,create_by,create_date,months1,months2)
  	select Distinct tier_id,a.users_type_id,a.contract_period_id,a.price1,a.discount1,a.price2,a.discount2,a.price3,a.min_user_count,create_by,now,a.months1,a.months2
  	from temp_plan_price_range_xml_structure a;
  
  	IF ROW_COUNT()>0 then
  	
  		
  		if not exists(select * from wtms_contract_pricing_dtl_MT a where a.tier_id = tier_id limit 1) then 
  			insert into wtms_contract_pricing_dtl_MT(tier_id,fk_user_type_id,fk_contract_period_id,price1,discount1,price2,discount2,price3,min_user,create_by,create_date,months1,months2)
  			select Distinct tier_id,a.users_type_id,a.contract_period_id,a.price1,a.discount1,a.price2,a.discount2,a.price3,a.min_user_count,create_by,now,a.months1,a.months2
  			from temp_plan_price_range_xml_structure a;
  		End if;
  
  		SET errcode=0;
  		SET errmsg='Sucess';
  	
  	END if;
  
  End;
  
  End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_create_tier_summaries` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_create_tier_summaries`(
 summary_id INT,
 fk_prod_id INT,
 fk_sub_prod INT ,
 fk_bundle_id INT,
 Tier_type  INT,
 summary_name VARCHAR(155),
 summary_status INT,
 processtype INT, 
 summary_desc text,
 summary_url text
 )
begin
 
 
 	
    DECLARE v_errcode INT;
    DECLARE v_errmsg VARCHAR(160);
    DECLARE v_now DATETIME(3);
 	
    IF summary_id is null then
       set summary_id = 0;
    END IF;
    sp_exit:
    BEGIN
       IF summary_id is null then
          set summary_id = 0;
       END IF;
       set v_errcode = -1;
       set v_errmsg = 'Failure';
       set v_now = CURRENT_TIMESTAMP;
       
       if Tier_type = 1 then
          if fk_prod_id <> 0 then
             if not exists(select  * from product_master d where d.prod_status = 1 and d.prod_id = fk_prod_id LIMIT 1)
             then
                set v_errcode = -1;
                set v_errmsg = 'Invalid product ID';
                LEAVE sp_exit;
             end if;
          end if;
          
          if fk_prod_id <> 0 then
 		
             if not exists(select  * from product_master d where d.prod_status = 1 and d.prod_id = fk_prod_id LIMIT 1) 
             then
                set v_errcode = -1;
                set v_errmsg = 'Invalid product ID';
                LEAVE sp_exit;
             end if;
          end if;
          if fk_sub_prod <> 0 then
 		
             if not exists(select  * from product_category_master d where d.catg_id = fk_sub_prod and d.fk_prod_id = fk_prod_id and d.category_status = 1 LIMIT 1) 
             then
                set v_errcode = -1;
                set v_errmsg = 'Invalid sub product ID matched';
                LEAVE sp_exit;
             end if;
          end if;
       end if;
       
       if Tier_type = 2 then
 	
          if fk_bundle_id <> 0 then
 		
             if not exists(select  * from worktual_bundle_master d where d.bundle_id = fk_bundle_id and d.status = 1 LIMIT 1)
             then
                set v_errcode = -1;
                set v_errmsg = 'Invalid product ID';
                LEAVE sp_exit;
             end if;
          end if;
       end if;
       
       
       IF processtype = 1 
       then
          IF EXISTS(SELECT  * FROM wtms_tier_summaries_master_dtl c where c.summary_name = summary_name and c.fk_prod_id = fk_prod_id LIMIT 1)
          then
             SET v_errcode = -1;
             set v_errmsg = 'summary name already exist for this product';
             LEAVE sp_exit;
          end if;
          
          INSERT INTO wtms_tier_summaries_master_dtl(summary_name,fk_prod_id,fk_sub_prod,fk_bundle_id,fk_tier_id,summary_status,summary_create_date,summary_desc, summary_url)
 		VALUES(summary_name,fk_prod_id,fk_sub_prod,fk_bundle_id,Tier_type ,summary_status,v_now,summary_desc, summary_url);
 		
          set summary_id = LAST_INSERT_ID();
          
          if ROW_COUNT() > 0 then
             SET v_errcode = 0;
             set v_errmsg = 'Success : summary created';
             LEAVE sp_exit;
          end if;
       end if;
       IF processtype = 2 then
 	
          IF EXISTS(SELECT  * FROM wtms_tier_summaries_master_dtl e where e.summary_name = summary_name and e.fk_prod_id = fk_prod_id and e.summary_id <> summary_id LIMIT 1) 
          then
             SET v_errcode = -1;
             set v_errmsg = 'summary name already exist';
             LEAVE sp_exit;
          end if;
          
          UPDATE wtms_tier_summaries_master_dtl a
          set a.summary_name = IFNULL(summary_name,a.summary_name),
          a.fk_prod_id = IFNULL(fk_prod_id,a.fk_prod_id),
          a.fk_sub_prod = IFNULL(fk_sub_prod,a.fk_sub_prod),
          a.fk_bundle_id = IFNULL(fk_bundle_id,a.fk_bundle_id),
          a.summary_create_date = IFNULL(v_now,a.summary_create_date),
          a.summary_status = IFNULL(summary_status,a.summary_status),
          a.fk_tier_id = IFNULL(Tier_type,a.fk_tier_id),
          a.summary_desc = ifnull(summary_desc,a.summary_desc), 
          a.summary_url = ifnull(summary_url,a.summary_url)
          where a.summary_id = summary_id;
 		
 
          if ROW_COUNT() > 0 then
             SET v_errcode = 0;
             set v_errmsg = 'Success : summary name updated';
             LEAVE sp_exit;
          end if;
       end if;
       
       IF processtype = 3 
       then
          update wtms_tier_summaries_master_dtl r set r.summary_status = 3 where r.summary_id = summary_id;
          if ROW_COUNT() > 0 
          then
             SET v_errcode = 0;
             set v_errmsg = 'Deleted : summary name deleted';
             LEAVE sp_exit;
          end if;
       end if;
    END;
        
    select v_errcode as errcode,v_errmsg as errmsg,IFNULL(summary_id,0) as summary_id,IFNULL(Tier_type,0) as Tier_type;
 
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_create_tier_summary_map` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_create_tier_summary_map`(
     tier_id INT,
     tier_summary_map LONGTEXT,
     create_by VARCHAR(50))
begin
     
     
     
     
        DECLARE v_hDoc INT; 
        DECLARE v_errcode INT; 
        DECLARE v_errmsg VARCHAR(160);
        DECLARE v_now DATETIME(3);
        
        DECLARE v_tiertype text;
        DECLARE v_bundid text;
        DECLARE v_prodid text;
        DECLARE v_subprodid text;
        DECLARE v_summid text;
        DECLARE v_position text;
        
        
        DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
        BEGIN
           SET @SWV_Error = 1;
        END;
        IF create_by is null then
           set create_by = 'admin';
        END IF;
        SET @SWV_Error = 0;
        BEGIN
           DECLARE EXIT HANDLER FOR SQLEXCEPTION
           begin
              SET v_errcode = @SWV_Error;
              GET STACKED DIAGNOSTICS CONDITION 1 v_errmsg = MESSAGE_TEXT;
              select v_errcode as errcode, v_errmsg as errmsg;
           end;
           set v_now = CURRENT_TIMESTAMP;
           
           DROP TEMPORARY TABLE IF EXISTS tt_tier_summary_map_xml;
           create TEMPORARY table tt_tier_summary_map_xml
           (
              id INT   AUTO_INCREMENT PRIMARY KEY,
              tier_id INT,
              tiertype INT,
              bundle_id INT,
              product_id INT,
              sub_product_id INT,
              summary_id INT,
              position INT
           )  AUTO_INCREMENT = 1;
           
 			drop temporary table if exists xml_tiertype_tbl; create temporary table xml_tiertype_tbl(id int auto_increment primary key,tiertype int);
 			drop temporary table if exists xml_bundid_tbl; create temporary table xml_bundid_tbl(id int auto_increment primary key,bundid int);
 			drop temporary table if exists xml_prodid_tbl; create temporary table xml_prodid_tbl(id int auto_increment primary key,prodid INT);
 			drop temporary table if exists xml_subprodid_tbl; create temporary table xml_subprodid_tbl(id int auto_increment primary key,subprodid int);
 			drop temporary table if exists xml_summid_tbl; create temporary table xml_summid_tbl(id int auto_increment primary key,summid int);
            drop temporary table if exists xml_positionid_tbl; create temporary table xml_positionid_tbl(id int auto_increment primary key,position int);
 			
       
 			SELECT replace(ExtractValue(tier_summary_map, '//tiertype[1]'),' ',','), 
 				 replace(ExtractValue(tier_summary_map, '//bundid[1]'),' ',','),
 				 replace(ExtractValue(tier_summary_map, '//prodid[1]'),' ',','),
 				 replace(ExtractValue(tier_summary_map, '//subprodid[1]'),' ',','),
 				 replace(ExtractValue(tier_summary_map, '//summid[1]'),' ',','),
                 replace(ExtractValue(tier_summary_map, '//position[1]'),' ',',')
 				 into v_tiertype,v_bundid,v_prodid,v_subprodid,v_summid,v_position;
                      
 			drop table if exists tt_Split_temptable; call Split(v_tiertype,','); insert into xml_tiertype_tbl(tiertype) select Items from tt_Split_temptable;
 			drop table if exists tt_Split_temptable; call Split(v_bundid,','); insert into xml_bundid_tbl(bundid) select Items from tt_Split_temptable;
 			drop table if exists tt_Split_temptable; call Split(v_prodid,','); insert into xml_prodid_tbl(prodid) select Items from tt_Split_temptable;
 			drop table if exists tt_Split_temptable; call Split(v_subprodid,','); insert into xml_subprodid_tbl(subprodid) select Items from tt_Split_temptable;
 			drop table if exists tt_Split_temptable; call Split(v_summid,','); insert into xml_summid_tbl(summid) select Items from tt_Split_temptable;
            drop table if exists tt_Split_temptable; call Split(v_position,','); insert into xml_positionid_tbl(position) select Items from tt_Split_temptable;
                         
 			INSERT INTO tt_tier_summary_map_xml(tier_id,tiertype,bundle_id,product_id,sub_product_id,summary_id,position)
 			select tier_id,a.tiertype, b.bundid, c.prodid, d.subprodid, e.summid,f.position
 			from xml_tiertype_tbl a 
 			left join xml_bundid_tbl b on a.id = b.id
 			left join xml_prodid_tbl c on a.id=c.id
 			left join xml_subprodid_tbl d on a.id=d.id
 			left join xml_summid_tbl e on a.id=e.id
            left join xml_positionid_tbl f on a.id=f.id;
    
          if exists(select  * from wtms_tier_summary_map a where  a.fk_tier_id = tier_id LIMIT 1) 
          then
              delete from wtms_tier_summary_map b where b.fk_tier_id = tier_id;
           end if;
           
           insert into wtms_tier_summary_map(fk_tier_id,tiertype,bundle_id,product_id,sub_product_id,summary_id,position)
           select Distinct tier_id,a.tiertype,a.bundle_id,a.product_id,a.sub_product_id,a.summary_id,a.position
           from tt_tier_summary_map_xml a;
           
           IF ROW_COUNT() > 0
           then
     	
              if not exists(select  * from wtms_tier_summary_map_MT a where a.fk_tier_id = tier_id LIMIT 1) 
              then
     			  insert into wtms_tier_summary_map_MT(fk_tier_id,tiertype,bundle_id,product_id,sub_product_id,summary_id)
                 select Distinct a.tier_id,a.tiertype,a.bundle_id,a.product_id,a.sub_product_id,a.summary_id
                 from tt_tier_summary_map_xml a;
              end if;
              SET v_errcode = 0;
              SET v_errmsg = 'Inserted';
           end if;
        END; 
     
     End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_create_user_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_create_user_dtl`(
 userid INT  ,
 firstname VARCHAR(150),
 lastname VARCHAR(150),
 username VARCHAR(60),
 password VARCHAR(60),
 fk_role INT,
 fk_group_id INT,
 user_grp_id INT,
 status INT,
 created_by VARCHAR(50),
 processtype INT, 
 last_login_ip VARCHAR(50))
begin
 
 
    DECLARE v_errcode INT DEFAULT -1;
    DECLARE v_errmsg VARCHAR(60) DEFAULT 'failure';
    DECLARE v_now DATETIME(3);
 
 
 	
 
    IF userid is null then
       set userid = 0;
    END IF;
    IF created_by is null then
       set created_by = 'admin';
    END IF;
    IF last_login_ip is null then
       set last_login_ip = '';
    END IF;
    sp_end:
    BEGIN
       IF userid is null then
          set userid = 0;
       END IF;
       IF created_by is null then
          set created_by = 'admin';
       END IF;
       IF last_login_ip is null then
          set last_login_ip = '';
       END IF;
       set v_now = CURRENT_TIMESTAMP;
       set user_grp_id = null;
       
       
       select   a.user_group_id INTO user_grp_id from wtms_user_group_hdr a
       join worktual_roles_master_dtl b on a.Fk_role_id = b.role_id
       join worktual_groups_master_dtl c on c.group_id = a.fk_group_id where b.role_id = fk_role and c.group_id = fk_group_id;
       
       
       if username = '' or username is null then
          set v_errcode = -1;
          set v_errmsg = 'Username is mandatory';
          LEAVE sp_end;
       end if;
       
       
       if not exists(select * from worktual_roles_master_dtl  where role_id = fk_role)
       then
          SET v_errcode = -1;
          SET v_errmsg = 'RoleID not exists';
          LEAVE sp_end;
       end if;
       
       
       if not exists(select * from worktual_groups_master_dtl  where group_id = fk_group_id) 
       then
          SET v_errcode = -1;
          SET v_errmsg = 'Group ID not exists';
          LEAVE sp_end;
       end if;
       
       if processtype = 1 then
 	
          if exists(select * from wtms_user_master_dtl  a where a.username = username) 
          then
 		    SET v_errcode = -1;
             SET v_errmsg = 'username already exists';
             LEAVE sp_end;
          end if;
          
          
          insert into wtms_user_master_dtl(firstname,lastname,username,password,user_role,user_group,user_group_name,status,create_date,modify_date,created_by,last_login_ip)
          select firstname,lastname,username,password,fk_role,fk_group_id,user_grp_id,status,v_now,v_now,created_by,last_login_ip;
          
          set userid = LAST_INSERT_ID();
          
          if ROW_COUNT() > 0 
          then
 			SET v_errcode = 0;
             SET v_errmsg = 'username created';
             LEAVE sp_end;
          end if;
          
       end if;
       
       if processtype = 2 then
 	
          if exists(select * from wtms_user_master_dtl  b where b.username = username and b.userid <> userid) 
          then
 		    SET v_errcode = -1;
             SET v_errmsg = 'user already exists';
             LEAVE sp_end;
          end if;
          
          
          UPDATE wtms_user_master_dtl a
          set		
          a.firstname = IFNULL(firstname,a.firstname),
          a.lastname = IFNULL(lastname,a.lastname),
          a.password = IFNULL(password,a.password),
          a.user_role = IFNULL(fk_role,a.user_role),
          a.user_group = IFNULL(fk_group_id,a.user_group),
          a.user_group_name = IFNULL(user_grp_id,a.user_group_name),
          a.status = IFNULL(status,a.status),
          a.modify_date = v_now,
          a.created_by = IFNULL(created_by,a.created_by),
          a.last_login_ip = IFNULL(last_login_ip,''),
          a.last_login_date = v_now,
          a.username = username
          where a.userid = userid;
          
          
          if ROW_COUNT() > 0 
          then
 			
             SET v_errcode = 0;
             SET v_errmsg = 'user details updated';
             LEAVE sp_end;
          end if;
       end if;
       
       if processtype = 3 then
 	
          if not exists(select * from wtms_user_master_dtl c where c.username = username and c.userid = userid) then
 		
             SET v_errcode = -1;
             SET v_errmsg = 'user not exists';
             LEAVE sp_end;
          end if;
          update wtms_user_master_dtl e set e.status = 3 where e.userid = userid and e.username = username; 
 
 		
 
          if ROW_COUNT() > 0 then
 		   SET v_errcode = 0;
             SET v_errmsg = 'user deleted';
             LEAVE sp_end;
          end if;
       end if;
    END;
    select v_errcode errcode,v_errmsg errmsg, IFNULL(userid,0) as userid;
 
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_create_user_group_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_create_user_group_info`(
user_group_id INT,
approve_1 INT,
approve_2 INT,
created_by VARCHAR(10),
status INT)
Begin


   DECLARE v_errcode INT;
   DECLARE v_errmsg VARCHAR(200);
   DECLARE v_now DATETIME(3);

   IF approve_1 is null then
      set approve_1 = 0;
   END IF;
   IF approve_2 is null then
      set approve_2 = 0;
   END IF;
   IF created_by is null then
      set created_by = '';
   END IF;
   sp_exit:
   BEGIN
      IF approve_1 is null then
         set approve_1 = 0;
      END IF;
      IF approve_2 is null then
         set approve_2 = 0;
      END IF;
      IF created_by is null then
         set created_by = '';
      END IF;
      set v_now = CURRENT_TIMESTAMP;
      if not exists(select  * from wtms_user_group_hdr a where a.user_group_id = user_group_id LIMIT 1) 
      then
         set v_errcode = -1;
         set v_errmsg = 'group ID not exists';
         LEAVE sp_exit;
      end if;
      
      update wtms_user_group_hdr b
      set b.modify_date = v_now,b.modify_by = created_by,b.approve_1 = approve_1,b.approve_2 = approve_2
      where b.user_group_id = user_group_id;
      if ROW_COUNT() > 0 
      then
         set v_errcode = 0;
         set v_errmsg = 'updated';
      end if;
   END;
   select v_errcode as errcode,v_errmsg as errmsg, IFNULL(user_group_id,0) as user_group_id;

End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_create_user_group_permission` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_create_user_group_permission`(
 user_group_id INT,
 Fk_role_id INT,
 fk_group_id INT,
 user_group_name VARCHAR(100),
 menu_permission LONGTEXT,
 created_by VARCHAR(10),
 status INT,
 process_type INT 
 )
Begin
 
 
 	
 
    DECLARE v_errcode INT;
    DECLARE v_errmsg VARCHAR(50);
    DECLARE v_now DATETIME(3);
    DECLARE v_group_name VARCHAR(3);
    DECLARE v_role_name VARCHAR(3);
    DECLARE v_UG_name VARCHAR(10);
    
    
    DECLARE v_fk_menu_id VARCHAR(100);
    DECLARE v_is_menu VARCHAR(100);
    DECLARE v_is_create VARCHAR(100);
    DECLARE v_is_edit VARCHAR(100);
    DECLARE v_is_view VARCHAR(100); 
    DECLARE v_is_copy VARCHAR(100);
    DECLARE v_is_approve_reject_rfm VARCHAR(100);
 
    IF user_group_id is null then
       set user_group_id = 0;
    END IF;
    IF created_by is null then
       set created_by = '';
    END IF;
    sp_exit:
    BEGIN
       IF user_group_id is null then
          set user_group_id = 0;
       END IF;
       IF created_by is null then
          set created_by = '';
       END IF;
       set v_now = CURRENT_TIMESTAMP;
       select   left(a.group_name,3) INTO v_group_name from worktual_groups_master_dtl a where a.group_id = fk_group_id;
       select   left(b.role_name,3) INTO v_role_name from worktual_roles_master_dtl b where b.role_id = Fk_role_id;
       set v_UG_name = CONCAT(v_role_name,'_',v_group_name);
       
       if user_group_name <> v_UG_name
       then
          set v_errcode = -1;
          set v_errmsg = CONCAT('Suggested user group name is  ',upper(v_UG_name));
          LEAVE sp_exit;
       end if;
       
       if process_type = 1 then
          if exists(select * from wtms_user_group_hdr a where a.user_group_name = user_group_name and a.Fk_role_id = Fk_role_id and a.fk_group_id = fk_group_id LIMIT 1) 
          then
             set v_errcode = -1;
             set v_errmsg = 'group name already exists';
             LEAVE sp_exit;
          end if;
          
          if exists(select  * from wtms_user_group_hdr b where b.user_group_name = user_group_name LIMIT 1) 
          then
             set v_errcode = -1;
             set v_errmsg = 'group name already exists';
             LEAVE sp_exit;
          end if;
          insert into wtms_user_group_hdr(Fk_role_id,fk_group_id,user_group_name,status,create_date,created_by)
 			values(Fk_role_id,fk_group_id,user_group_name,status,v_now,created_by);
 			
          set user_group_id = LAST_INSERT_ID();
          
          if ROW_COUNT() > 0 then
             set v_errcode = 0;
             set v_errmsg = 'Created Success ';
          end if;
       end if;
       
       
       if process_type = 2 then
 		
          if not exists(select  * from wtms_user_group_hdr c where c.user_group_id = user_group_id LIMIT 1) 
          then
             set v_errcode = -1;
             set v_errmsg = 'group not exists';
             LEAVE sp_exit;
          end if;
          if exists(select  * from wtms_user_group_hdr d where d.Fk_role_id = Fk_role_id and d.fk_group_id = fk_group_id
          and d.user_group_id <> user_group_id LIMIT 1) then
 			
             set v_errcode = -1;
             set v_errmsg = 'same groupID and roleID combination already exists';
             LEAVE sp_exit;
          end if;
          if exists(select  * from wtms_user_group_hdr m where m.user_group_name = user_group_name
          and m.user_group_id <> user_group_id LIMIT 1) 
          then
             set v_errcode = -1;
             set v_errmsg = 'group name already exists';
             LEAVE sp_exit;
          end if;
          
          update wtms_user_group_hdr v
          set v.Fk_role_id = Fk_role_id,v.fk_group_id = fk_group_id,v.user_group_name = user_group_name,
          v.modify_date = v_now,v.modify_by = created_by
          where v.user_group_id = user_group_id;
          
          if ROW_COUNT() > 0 
          then
             set v_errcode = 0;
             set v_errmsg = 'updated';
          end if;
       end if;
       
       IF process_type = 3 
       then
          IF NOT EXISTS(SELECT  * FROM wtms_user_group_hdr h where h.user_group_id = user_group_id LIMIT 1) 
          then
             SET v_errcode = -1;
             set v_errmsg = 'group ID not exist';
             LEAVE sp_exit;
          end if;
          update wtms_user_group_hdr n set n.status = 3 where n.user_group_id = user_group_id;
          
          if ROW_COUNT() > 0 
          then
             SET v_errcode = 0;
             set v_errmsg = 'Deleted : group name deleted';
             LEAVE sp_exit;
          end if;
       end if;
       
       
       DROP TEMPORARY TABLE IF EXISTS tt_temp_user_group_details;
       create TEMPORARY table tt_temp_user_group_details
       (
          id INT   AUTO_INCREMENT PRIMARY KEY,
          Fk_user_group_id INT,
          fk_menu_id INT,
          is_menu INT,
          is_create INT,
          is_edit INT,
          is_view INT,
          is_copy INT,
          is_approve_reject_rfm INT
       )  AUTO_INCREMENT = 1;
       
    
      
          	drop temporary table if exists xml_fk_menu_id_tbl; create temporary table xml_fk_menu_id_tbl(id int auto_increment primary key,fk_menu_id int);
   			drop temporary table if exists xml_is_menu_tbl; create temporary table xml_is_menu_tbl(id int auto_increment primary key,is_menu int);
   			drop temporary table if exists xml_is_create_tbl; create temporary table xml_is_create_tbl(id int auto_increment primary key,is_create INT);
   			drop temporary table if exists xml_is_edit_tbl; create temporary table xml_is_edit_tbl(id int auto_increment primary key,is_edit int);
   			drop temporary table if exists xml_is_view_tbl; create temporary table xml_is_view_tbl(id int auto_increment primary key,is_view int);
             drop temporary table if exists xml_is_copy_tbl; create temporary table xml_is_copy_tbl(id int auto_increment primary key,is_copy int);
   			drop temporary table if exists xml_is_approve_reject_rfm_tbl; create temporary table xml_is_approve_reject_rfm_tbl(id int auto_increment primary key,is_approve_reject_rfm int);
   
             SELECT replace(ExtractValue(menu_permission, '//fk_menu_id[1]'),' ',','), 
                  replace(ExtractValue(menu_permission, '//is_menu[1]'),' ',','),
                  replace(ExtractValue(menu_permission, '//is_create[1]'),' ',','),
                  replace(ExtractValue(menu_permission, '//is_edit[1]'),' ',','),
                  replace(ExtractValue(menu_permission, '//is_view[1]'),' ',','),
                  replace(ExtractValue(menu_permission, '//is_copy[1]'),' ',','),
                  replace(ExtractValue(menu_permission, '//is_approve_reject_rfm[1]'),' ',',')
                  into v_fk_menu_id, v_is_menu, v_is_create, v_is_edit, v_is_view,v_is_copy,v_is_approve_reject_rfm;

             
   			call Split(v_fk_menu_id,','); insert into xml_fk_menu_id_tbl(fk_menu_id) select Items from tt_Split_temptable;
   			call Split(v_is_menu,','); insert into xml_is_menu_tbl(is_menu) select Items from tt_Split_temptable;
   			call Split(v_is_create,','); insert into xml_is_create_tbl(is_create) select Items from tt_Split_temptable;
   			call Split(v_is_edit,','); insert into xml_is_edit_tbl(is_edit) select Items from tt_Split_temptable;
   			call Split(v_is_view,','); insert into xml_is_view_tbl(is_view) select Items from tt_Split_temptable;
            call Split(v_is_copy,','); insert into xml_is_copy_tbl(is_copy) select Items from tt_Split_temptable;
   			call Split(v_is_approve_reject_rfm,','); insert into xml_is_approve_reject_rfm_tbl(is_approve_reject_rfm) select Items from tt_Split_temptable;
            
            INSERT INTO tt_temp_user_group_details(Fk_user_group_id,fk_menu_id,is_menu,is_create,is_edit,is_view,is_copy,is_approve_reject_rfm)
            select user_group_id, a.fk_menu_id,b.is_menu,c.is_create,d.is_edit,e.is_view,f.is_copy,g.is_approve_reject_rfm
            from xml_fk_menu_id_tbl a 
            left join xml_is_menu_tbl b on a.id = b.id
            left join xml_is_create_tbl c on a.id=c.id
            left join xml_is_edit_tbl d on a.id=d.id
            left join xml_is_view_tbl e on a.id=e.id
            left join xml_is_copy_tbl f on a.id=f.id
            left join xml_is_approve_reject_rfm_tbl g on a.id=g.id;
            
     
            
      if exists(select * from wtms_user_group_details q where q.Fk_user_group_id = user_group_id LIMIT 1) 
      then
 		
          delete from wtms_user_group_details f where f.Fk_user_group_id = user_group_id;
       end if;
       
       insert into wtms_user_group_details(Fk_user_group_id,fk_menu_id,is_menu,is_create,is_edit,is_view,is_copy,is_approve_reject_rfm,create_date,status)
       select Distinct a.Fk_user_group_id,a.fk_menu_id,a.is_menu,a.is_create,a.is_edit,a.is_view,a.is_copy,a.is_approve_reject_rfm,v_now,status
       from tt_temp_user_group_details a
       left join wtms_tbl_Menu b on a.fk_menu_id = b.Pk_Menu_Id
       where b.status = 1;
       
       IF ROW_COUNT() > 0 
       then
          SET v_errcode = 0;
          SET v_errmsg = 'Success';
       end if;
    END;
    select v_errcode as errcode,v_errmsg as errmsg, IFNULL(user_group_id,0) as user_group_id;
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_get_bundle_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_get_bundle_dtl`(bundle_id INT)
Begin

   IF bundle_id is null then
      set bundle_id = 0;
   END IF;
   select a.bundle_id,a.bundle_name,a.bundle_description,a.status, a.prod_id,a.sub_prod_id,a.prod_name,a.sub_products
   from worktual_bundle_prod_subprod_mapping a
   where (a.bundle_id = bundle_id or IFNULL(bundle_id,0) = 0) and IFNULL(a.status,0) = 1;



End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_get_category_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_get_category_info`(
  category_id INT ,
  fk_prod_id INT,
  fk_sub_prod VARCHAR(100)
  )
BEGIN
  
  
  	
  		
     IF category_id is null then set category_id = 0; END IF;
     IF fk_prod_id is null then set fk_prod_id = 0; END IF;
     IF fk_sub_prod is null then set fk_sub_prod = ''; END IF;
  
     
     drop temporary table if exists tt_sub_prod_id;
  
     create temporary table tt_sub_prod_id
     (
  	sub_prod_id int
     );
  
  
     call Split(fk_sub_prod,','); 
  
     insert into tt_sub_prod_id(sub_prod_id)
     select Items from tt_Split_temptable;
  
  		
     SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
  	   SELECT a.Category_id,a.Category_Name,a.fk_prod_id,a.fk_sub_prod,a.category_description,a.category_status,a.category_position,a.create_date
  	   FROM wtms_feature_category a
  	   where ((a.Category_id = category_id) or (category_id = 0))
  	   and (a.fk_prod_id = fk_prod_id or IFNULL(fk_prod_id,0) = 0)
  	   and (a.fk_sub_prod in (select Distinct b.sub_prod_id from tt_sub_prod_id b) or IFNULL(fk_sub_prod,'') = '')
  	   
  	   order by a.category_id;
     SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ; 
  	
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_get_category_master` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_get_category_master`(category_id INT)
Begin

   IF category_id is null then
      set category_id = 0;
   END IF;
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   SELECT b.category_id,b.category_name, b.category_status,b.created_date
   FROM worktual_sum_category_master b
   where (b.category_id = category_id or IFNULL(category_id,0) = 0);
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
	

End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_get_config_type` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_get_config_type`()
Begin

   select configid,config_name from wtms_config_type;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_get_contract_period_info_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_get_contract_period_info_dtl`(cop_id INT)
Begin

   IF cop_id is null then
      set cop_id = 0;
   END IF;
   select b.cop_id,cop_cont_id,cop_period,cop_description,create_date,status
   from wtms_contract_period_master b where (b.cop_id = cop_id or IFNULL(cop_id,0) = 0) and status = 1;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_get_currency_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_get_currency_dtl`(curr_id INT)
begin


   IF curr_id is null then
      set curr_id = 0;
   END IF;
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select a.curr_id as currency_id,a.curr_name as currency_name,a.curr_status as currency_status,a.curr_created_date as currency_created_date
   from worktual_currency_master_dtl a 
   where (a.curr_id = curr_id or IFNULL(curr_id,0) = 0) and a.curr_status = 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;


end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_get_feature_by_category` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_get_feature_by_category`(category_id INT)
Begin

   select feature_id,feature_name,feature_description,fk_config_id,no_fields,status,category_name,IFNULL(getmapfieldlist(a.feature_id),'') as map_field
   from wtms_feature_info a
   left join wtms_config_type c on a.fk_config_id = c.configid
   where fk_category_id = category_id
   and status = 1; 

End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_get_feature_details_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_get_feature_details_info`(
        tier_id INT,
        feature_id INT,
        fk_category_id INT
        )
begin
        
           IF feature_id is null then set feature_id = 0; END IF;
           IF fk_category_id is null then set fk_category_id = 0; END IF;
        
           SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
           select a.feature_id,a.fk_category_id as category_id,a.feature_name,a.feature_description,a.status,b.category_Name as category_name,
        	  b.category_description,c.value1,c.value2,c.value3,c.value4,c.value5,a.summary_notes
           from wtms_feature_info a 
           join wtms_feature_category b on a.fk_category_id = b.category_id
           join wtms_tier_feature_mapping_xml c on  c.featureid = a.feature_id and c.categoryid = b.category_id 
           join wtms_tier_category_position d on d.catg_id=c.categoryid and c.tier_id = d.fk_tier_id
           where c.tier_id = tier_id and (a.feature_id = feature_id or feature_id = 0) and (a.fk_category_id = fk_category_id or fk_category_id = 0) and a.status = 1
           and ifnull(c.value2,0)=0 and a.feature_usability=1
           order by d.catg_pos,a.position;
           SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
        
        
        end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_get_feature_master` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_get_feature_master`(
     feature_id INT,
     fk_prod_id INT,
     fk_sub_prod INT,
     category_id INT
     )
Begin
     
     
        IF feature_id is null then set feature_id = 0; END IF;
        IF fk_prod_id is null then set fk_prod_id = 0; END IF;
        IF fk_sub_prod is null then set fk_sub_prod = 0; END IF;
        IF category_id is null then set category_id = 0; END IF;
     
        select	Distinct a.feature_id,a.feature_name,a.feature_description,a.status,a.fk_category_id,ct.category_Name,
     			a.feature_usability,a.fk_config_id,c.config_name,a.no_fields,a.tariff,a.price,a.user_type,a.create_date,
     			a.create_by,ct.fk_prod_id,ct.fk_sub_prod,a.max_user_in_grp,d.level_id,
     			IFNULL(wtms.getmapfieldlist(a.feature_id),'') as map_field,
                a.accessibility,a.main_menu_id,a.sub_menu_id,a.feature_type_status,a.summary_notes,a.position
        from wtms_feature_info a
        join wtms_feature_category ct on a.fk_category_id = ct.category_id
        left join wtms_feature_field_map_details b on a.feature_id = b.fk_feature_id
        left join wtms_config_type c on a.fk_config_id = c.configid
        left join wtms_ref_feature_level d on a.fk_level_id = d.level_id
        where (a.feature_id = feature_id or IFNULL(feature_id,0) = 0)
        and (ct.fk_prod_id = fk_prod_id or IFNULL(fk_prod_id,0) = 0)
        and (ct.fk_sub_prod = fk_sub_prod or IFNULL(fk_sub_prod,0) = 0)
        and (a.fk_category_id = category_id or IFNULL(category_id,0) = 0);
      
     
     End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_get_group_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_get_group_dtl`(
group_id INT
)
begin



   IF group_id is null then
      set group_id = 0;
   END IF;

   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	   select a.group_id as group_id,a.group_name as group_name,a.group_status as group_status,a.group_created_date as group_created_date
	   from worktual_groups_master_dtl a 
	   where (a.group_id = group_id or IFNULL(group_id,0) = 0) and a.group_status = 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;


end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_get_inactive_tier_plan_purpose_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_get_inactive_tier_plan_purpose_info`(
            purpose_id int,
            product_id int,
            prod_type_id int 
            )
Begin
            
            	 if purpose_id = 0 then set purpose_id = 1; end if;
            	 if product_id = 0 then set product_id = 1; end if;
            
    			select 	a.prod_type_id,a.product_id,a.fk_purpose_id,a.fk_tier_id as tier_id,tier_name,tier_description,e.purpose_name,
    					b.price1,b.price2,b.price3,b.discount1,b.discount2,c.cop_description,d.nof_from,d.nof_to,d.nof_users_description,b.min_user,
    					wtms.getsummarylist(a.fk_tier_id,2) as summary_list,a.pro_user_count,b.max_user,a.product_id,a.prod_type_id
    			from wtms.wtms_copy_of_tier_management_temp a 
    			inner join wtms.wtms_contract_pricing_dtl b on a.fk_tier_id = b.tier_id
    			inner join wtms.wtms_contract_period_master c on c.cop_id=b.fk_contract_period_id
    			inner join wtms.wtms_no_of_users_master d on b.fk_user_type_id = d.nof_id
    			inner join wtms.wtms_ref_tier_purpose e on a.fk_purpose_id = e.purpose_id
    			where (a.fk_purpose_id = purpose_id) 
              and (a.product_id = product_id or (ifnull(product_id,1)=1))
    			 and (a.prod_type_id  = prod_type_id  or (ifnull(prod_type_id,0)=0))            
    			and a.status = 0 and a.tier_name not like '%copy%' and a.is_review=3;
            
            End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_get_main_tier_management` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_get_main_tier_management`(
             tier_id INT,
             type INT)
Begin
             
             	
                IF tier_id is null then
                   set tier_id = 0;
                END IF;
                IF type is null then
                   set type = 1;
                END IF;
                if type = 1 or type = 0 then
             	
  				select Distinct a.fk_tier_id,a.tier_name,a.tier_description ,a.tier_type,c.name as tier_type,a.prod_type_id,
  				getprodsubprodlist(a.fk_tier_id,1) as prod_name,
  				getprodsubprodlist(a.fk_tier_id,2) as sub_prod_name,
  				a.bund_prd_type,a.product_id,a.sub_product_id,a.fk_purpose_id,a.status,a.reseller_id,a.pro_user_count,a.standard_user_count,a.basic_user_count,a.apply_new_exist_cust,a.booking_user_count,a.booking_user_price
  				from wtms_copy_of_tier_management_temp a
  				left join product_master b on a.prod_type_id = b.prod_id
  				left join wtms_ref_tier_type c on a.tier_type = c.id
  				where (a.fk_tier_id = tier_id or IFNULL(tier_id,0) = 0)
  				and a.is_review = 2;
                end if;
             
             	
                if type = 2 then
             	
                   select a.fk_tier_id,a.free_or_paid,a.currency,b.fk_user_type_id,b.fk_contract_period_id,b.discount1 as discount,b.price1 as price,b.min_user,a.apply_new_exist_cust,
             		c.nof_id,c.nof_from,c.nof_to,c.nof_users_description,d.cop_id,d.cop_period,d.cop_description,e.curr_name as currency_name,
             		a.per_addn_user,a.per_addn_user_currency,b.max_user
                   from wtms_copy_of_tier_management_temp a
                   left join wtms_contract_pricing_dtl_MT b on a.fk_tier_id = b.tier_id
                   left join wtms_no_of_users_master c on b.fk_user_type_id = c.nof_id
                   left join wtms_contract_period_master d on b.fk_contract_period_id = d.cop_id
                   left join worktual_currency_master_dtl e
                   on e.curr_id = a.currency
                   where (a.fk_tier_id = tier_id or IFNULL(tier_id,0) = 0);
                end if;
             
             	
                if type = 3 then
             	
                   select a.fk_tier_id,b.tiertype,b.bundle_id,b.product_id,b.sub_product_id,b.summary_id,c.summary_name,b.id
                   from wtms_copy_of_tier_management_temp a
                   left join wtms_tier_summary_map_MT b on a.fk_tier_id = b.fk_tier_id
                   left join wtms_tier_summaries_master_dtl c on b.summary_id = c.summary_id
                   where (a.fk_tier_id = tier_id or IFNULL(tier_id,0) = 0);
                end if;
             
             	
                if type = 4 then
             	
                   select a.fk_tier_id,b.catg_id,b.catg_pos,c.category_Name,b.id
                   from wtms_copy_of_tier_management_temp a
                   left join wtms_tier_category_position_MT b on a.fk_tier_id = b.fk_tier_id
                   left join wtms_feature_category c on b.catg_id = c.category_id
                   where (a.fk_tier_id = tier_id or IFNULL(tier_id,0) = 0);
                end if;
             
             	
                if type = 5 then
             	
                   select a.fk_tier_id,b.tiertype,b.product_id,b.sub_product_id,b.categoryid,c.category_Name,b.featureid,b.id
                   from wtms_copy_of_tier_management_temp a
                   left join wtms_tier_catg_feature_mapping_info_MT b on a.fk_tier_id = b.tier_id
                   left join wtms_feature_category c on c.category_id = b.categoryid
                   where (a.fk_tier_id = tier_id or IFNULL(tier_id,0) = 0);
                end if;
             
             	
                if type = 6 then
             	
                   select a.fk_tier_id,b.tiertype,bundle_id,b.product_id,b.sub_product_id,b.categoryid,b.featureid,c.feature_name,b.value1,b.value2,b.value3,b.value4,b.value5,b.id
                   from wtms_copy_of_tier_management_temp a
                   left join wtms_tier_feature_mapping_xml_MT b on a.fk_tier_id = b.tier_id
                   left join wtms_feature_info c on b.featureid = c.feature_id
                   where (a.fk_tier_id = tier_id or IFNULL(tier_id,0) = 0);
                end if;
             
             	
                if type = 7 then
                
       			select Distinct fk_tier_id,tier_name,tier_description,tier_type,tier_type_name,prod_type_id,prod_name,sub_prod_name,
       					bund_prd_type,product_id,sub_product_id,fk_purpose_id,status,
       					approver_1_user_group_name,max(approver_1_approved_on) as approver_1_approved_on, approver_2_user_group_name,max(approver_2_approved_on) as approver_2_approved_on,
       					approver_1_username,approver_2_username,country_id ,is_review,pro_user_count,standard_user_count,basic_user_count,apply_new_exist_cust,
                        booking_user_count,booking_user_price
       			from (select Distinct a.fk_tier_id,a.tier_name,a.tier_description ,a.tier_type,c.name as tier_type_name,a.prod_type_id,
       								getprodsubprodlist(a.fk_tier_id,1) as prod_name,
       								getprodsubprodlist(a.fk_tier_id,2) as sub_prod_name,
       								a.bund_prd_type,a.product_id,a.sub_product_id,a.fk_purpose_id,a.status,
       								d.approver_1_user_group_name,d.approver_1_approved_on, d.approver_2_user_group_name,d.approver_2_approved_on,
       								d.approver_1_username,d.approver_2_username,a.country_id ,a.is_review,a.pro_user_count,a.standard_user_count,a.basic_user_count,a.apply_new_exist_cust,
                                    a.booking_user_count,a.booking_user_price
       								from wtms_copy_of_tier_management_temp a
       								left join product_master b on a.prod_type_id = b.prod_id
       								left join wtms_ref_tier_type c on a.tier_type = c.id
       								inner join wtms_tier_approval_management d on a.fk_tier_id = d.fk_tier_id
       								where  (a.fk_tier_id = tier_id or IFNULL(tier_id,0) = 0) and a.is_review  in (3 ,4)
       								and d.approver_1_status = 'Approved' and d.approver_2_status = 'Approved') z
       			group by fk_tier_id,tier_name,tier_description,tier_type,tier_type_name,prod_type_id,prod_name,sub_prod_name,
       			bund_prd_type,product_id,sub_product_id,fk_purpose_id,status,
       			approver_1_user_group_name, approver_2_user_group_name,
       			approver_1_username,approver_2_username,country_id ,is_review,pro_user_count,standard_user_count,basic_user_count,apply_new_exist_cust,
                booking_user_count,booking_user_price;
             	
                
                end if;
             
             End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_get_main_tier_management_backup` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_get_main_tier_management_backup`(
        tier_id INT,
        type INT)
Begin
        
        	
           IF tier_id is null then
              set tier_id = 0;
           END IF;
           IF type is null then
              set type = 1;
           END IF;
           if type = 1 or type = 0 then
        	
              select Distinct a.fk_tier_id,a.tier_name,a.tier_description ,a.tier_type,c.name as tier_type,a.prod_type_id,
        		getprodsubprodlist(a.fk_tier_id,1) as prod_name,
        		getprodsubprodlist(a.fk_tier_id,2) as sub_prod_name,
        		a.bund_prd_type,a.product_id,a.sub_product_id,a.fk_purpose_id,a.status,a.reseller_id
              from wtms_copy_of_tier_management_temp a
              left join product_master b on a.prod_type_id = b.prod_id
              left join wtms_ref_tier_type c on a.tier_type = c.id
              where (a.fk_tier_id = tier_id or IFNULL(tier_id,0) = 0)
              and a.is_review = 2;
           end if;
        
        	
           if type = 2 then
        	
              select a.fk_tier_id,a.free_or_paid,a.currency,b.fk_user_type_id,b.fk_contract_period_id,b.discount,b.price,b.min_user,a.apply_new_exist_cust,
        		c.nof_id,c.nof_from,c.nof_to,c.nof_users_description,d.cop_id,d.cop_period,d.cop_description,e.curr_name as currency_name,
        		a.per_addn_user,a.per_addn_user_currency
              from wtms_copy_of_tier_management_temp a
              left join wtms_contract_pricing_dtl_MT b on a.fk_tier_id = b.tier_id
              left join wtms_no_of_users_master c on b.fk_user_type_id = c.nof_id
              left join wtms_contract_period_master d on b.fk_contract_period_id = d.cop_id
              left join worktual_currency_master_dtl e
              on e.curr_id = a.currency
              where (a.fk_tier_id = tier_id or IFNULL(tier_id,0) = 0);
           end if;
        
        	
           if type = 3 then
        	
              select a.fk_tier_id,b.tiertype,b.bundle_id,b.product_id,b.sub_product_id,b.summary_id,c.summary_name,b.id
              from wtms_copy_of_tier_management_temp a
              left join wtms_tier_summary_map_MT b on a.fk_tier_id = b.fk_tier_id
              left join wtms_tier_summaries_master_dtl c on b.summary_id = c.summary_id
              where (a.fk_tier_id = tier_id or IFNULL(tier_id,0) = 0);
           end if;
        
        	
           if type = 4 then
        	
              select a.fk_tier_id,b.catg_id,b.catg_pos,c.category_Name,b.id
              from wtms_copy_of_tier_management_temp a
              left join wtms_tier_category_position_MT b on a.fk_tier_id = b.fk_tier_id
              left join wtms_feature_category c on b.catg_id = c.category_id
              where (a.fk_tier_id = tier_id or IFNULL(tier_id,0) = 0);
           end if;
        
        	
           if type = 5 then
        	
              select a.fk_tier_id,b.tiertype,b.product_id,b.sub_product_id,b.categoryid,c.category_Name,b.featureid,b.id
              from wtms_copy_of_tier_management_temp a
              left join wtms_tier_catg_feature_mapping_info_MT b on a.fk_tier_id = b.tier_id
              left join wtms_feature_category c on c.category_id = b.categoryid
              where (a.fk_tier_id = tier_id or IFNULL(tier_id,0) = 0);
           end if;
        
        	
           if type = 6 then
        	
              select a.fk_tier_id,b.tiertype,bundle_id,b.product_id,b.sub_product_id,b.categoryid,b.featureid,c.feature_name,b.value1,b.value2,b.value3,b.value4,b.value5,b.id
              from wtms_copy_of_tier_management_temp a
              left join wtms_tier_feature_mapping_xml_MT b on a.fk_tier_id = b.tier_id
              left join wtms_feature_info c on b.featureid = c.feature_id
              where (a.fk_tier_id = tier_id or IFNULL(tier_id,0) = 0);
           end if;
        
        	
           if type = 7 then
           
  			select Distinct fk_tier_id,tier_name,tier_description,tier_type,tier_type_name,prod_type_id,prod_name,sub_prod_name,
  					bund_prd_type,product_id,sub_product_id,fk_purpose_id,status,
  					approver_1_user_group_name,max(approver_1_approved_on) as approver_1_approved_on, approver_2_user_group_name,max(approver_2_approved_on) as approver_2_approved_on,
  					approver_1_username,approver_2_username,country_id ,is_review     
  			from (select Distinct a.fk_tier_id,a.tier_name,a.tier_description ,a.tier_type,c.name as tier_type_name,a.prod_type_id,
  								getprodsubprodlist(a.fk_tier_id,1) as prod_name,
  								getprodsubprodlist(a.fk_tier_id,2) as sub_prod_name,
  								a.bund_prd_type,a.product_id,a.sub_product_id,a.fk_purpose_id,a.status,
  								d.approver_1_user_group_name,d.approver_1_approved_on, d.approver_2_user_group_name,d.approver_2_approved_on,
  								d.approver_1_username,d.approver_2_username,a.country_id ,a.is_review
  								from wtms_copy_of_tier_management_temp a
  								left join product_master b on a.prod_type_id = b.prod_id
  								left join wtms_ref_tier_type c on a.tier_type = c.id
  								inner join wtms_tier_approval_management d on a.fk_tier_id = d.fk_tier_id
  								where  (a.fk_tier_id = tier_id or IFNULL(tier_id,0) = 0) and a.is_review  in (3 ,4)
  								and d.approver_1_status = 'Approved' and d.approver_2_status = 'Approved') z
  			group by fk_tier_id,tier_name,tier_description,tier_type,tier_type_name,prod_type_id,prod_name,sub_prod_name,
  			bund_prd_type,product_id,sub_product_id,fk_purpose_id,status,
  			approver_1_user_group_name, approver_2_user_group_name,
  			approver_1_username,approver_2_username,country_id ,is_review ;
        	
           
           end if;
        
        End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_get_Menu_Info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_get_Menu_Info`(Menu_Id INT)
BEGIN
	
   IF Menu_Id is null then
      set Menu_Id = 0;
   END IF;

   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	   Select a.Pk_Menu_Id as Menu_Id,a.Menu_Name,a.Menu_link,a.status,a.`position`  
	   from wtms_tbl_Menu a
	   Where ((Menu_Id = 0) or (a.Pk_Menu_Id = Menu_Id))
	   order by a.`position` asc;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_get_no_of_users_info_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_get_no_of_users_info_dtl`(nof_id INT)
Begin

   IF nof_id is null then
      set nof_id = 0;
   END IF;
   select b.nof_id,b.nof_from,b.nof_to,b.nof_users_description,b.nof_min_user,b.user_type,b.create_date,b.status
   from wtms_no_of_users_master b
   where (b.nof_id = nof_id or IFNULL(nof_id,0) = 0)  and b.status = 1;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_Get_plan_summary_notes_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_Get_plan_summary_notes_info`(
plan_id INT,
summaryid INT
)
Begin


   IF plan_id is null then
      set plan_id = 0;
   END IF;

   IF summaryid is null then
      set summaryid = 0;
   END IF;

   select a.summaryid,a.plan_id,a.fk_category_id as category_id,a.summary_notes,a.sum_status,a.create_date
   from worktual_plan_summary_info a
   where (a.plan_id = plan_id or IFNULL(plan_id,0) = 0)
   and (a.summaryid = summaryid or IFNULL(summaryid,0) = 0);
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Worktual_get_product_wise_category_id_name_list` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `Worktual_get_product_wise_category_id_name_list`(
   	product_id int
)
BEGIN
      		
        IF product_id is null then set product_id = 0; END IF;
        
         select a.category_id,a.fk_prod_id as product_id,a.category_Name from   wtms.wtms_feature_prod_wise_category a where 
          a.category_status = 1 and  (a.fk_prod_id = product_id or IFNULL(product_id,0) = 0)
       order by a.category_id;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_Get_Prod_Wise_Addon_List` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_Get_Prod_Wise_Addon_List`(
        	category_id int,
        	tier_id int,
        	product_id int
        )
Begin
        
        	IF tier_id is null then set tier_id = 0; END IF;
        	IF product_id is null then set product_id = 0; END IF;
            
        	SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        		select	Distinct a.addon_feature_id,a.addon_feature_name,a.addon_feature_description,a.status,a.fk_category_id,ct.category_Name,a.tier_Id, ct.fk_prod_id,ct.category_id,ct.category_name,a.price as addon_price,
                a.bundle_id,a.image_name, a.lang_code
        		from wtms.wtms_prod_wise_feature_info a
        		join wtms.wtms_feature_prod_wise_category ct on a.fk_category_id = ct.category_id
        		where ((ct.category_id = category_id) or (category_id = 0))
        		and (ct.fk_prod_id = product_id or IFNULL(product_id,0) = 0)
        		
             and (find_in_set(tier_id,a.tier_id) or ifnull(tier_id,0) =0 )
        		and ct.category_status = 1 and ifnull(a.status,0)=1
        		order by ct.category_id;
        	SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ; 
        	
        
        End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_get_prod_wise_category_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_get_prod_wise_category_info`(
  category_id INT ,
  fk_prod_id INT
  )
BEGIN
  		
     IF category_id is null then set category_id = 0; END IF;
     IF fk_prod_id is null then set fk_prod_id = 0; END IF;

     SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
  	   SELECT a.Category_id,a.Category_Name,a.fk_prod_id,a.category_description,a.category_status,a.category_position,a.create_date
  	   FROM wtms_feature_prod_wise_category a
  	   where ((a.Category_id = category_id) or (category_id = 0))
  	   and (a.fk_prod_id = fk_prod_id or IFNULL(fk_prod_id,0) = 0)
  	   and a.category_status = 1
  	   order by a.category_id;
     SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ; 
  	
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_get_prod_wise_category_list` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_get_prod_wise_category_list`(
   	tier_id int,
   	product_id int
   )
BEGIN
      		
         IF tier_id is null then set tier_id = 0; END IF;
         IF product_id is null then set product_id = 0; END IF;
   
   		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   		select	Distinct a.addon_feature_id,a.addon_feature_name,a.addon_feature_description,a.status,a.fk_category_id,ct.category_Name,a.tier_Id, ct.fk_prod_id,ct.category_id,ct.category_name,a.bundle_id
   		from wtms.wtms_prod_wise_feature_info a
   		join wtms.wtms_feature_prod_wise_category ct on a.fk_category_id = ct.category_id
   		where 
           (ct.fk_prod_id = product_id or IFNULL(product_id,0) = 0)
   		and (a.tier_id like concat('%',tier_id,'%') or ifnull(tier_id,0) =0 )
   		and ct.category_status = 1
   		order by ct.category_id;
   		SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ; 
      	
      END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_get_prod_wise_feature_master` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_get_prod_wise_feature_master`(
        addon_feature_id INT,
        fk_prod_id INT,
        category_id INT
        )
Begin
        
        
           IF addon_feature_id is null then set addon_feature_id = 0; END IF;
           IF fk_prod_id is null then set fk_prod_id = 0; END IF;
           IF category_id is null then set category_id = 0; END IF;
        
           select	Distinct a.addon_feature_id,a.addon_feature_name,a.addon_feature_description,a.status,a.fk_category_id,ct.category_Name,a.tier_Id,
        			a.addon_feature_usability,a.price,a.user_type,a.create_date,
        			a.create_by,ct.fk_prod_id,a.bundle_id,a.image_name, a.lang_code
           from wtms_prod_wise_feature_info a
           join wtms_feature_prod_wise_category ct on a.fk_category_id = ct.category_id
           where (a.addon_feature_id = addon_feature_id or IFNULL(addon_feature_id,0) = 0)
           and (ct.fk_prod_id = fk_prod_id or IFNULL(fk_prod_id,0) = 0)
           and (a.fk_category_id = category_id or IFNULL(category_id,0) = 0);
         
        
        End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_get_ref_feature_level` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_get_ref_feature_level`()
Begin

   select level_id,level_Desc from wtms_ref_feature_level;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_get_roles_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_get_roles_dtl`(role_id INT)
begin

   IF role_id is null then
      set role_id = 0;
   END IF;
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select a.role_id as role_id,a.role_name as role_name,a.role_status as role_status,a.role_created_date as role_created_date
   from worktual_roles_master_dtl a 
   where (a.role_id = role_id or IFNULL(role_id,0) = 0) and a.role_status = 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;


end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_get_Role_Info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_get_Role_Info`(Pk_role_id INT)
BEGIN

IF Pk_role_id is null then
      set Pk_role_id = 0;
   END IF;
   
   SELECT t.role_id,role_name,role_created_date,role_status, insert((SELECT GROUP_CONCAT(CONCAT(',',cast(s.Fk_Menu_ID as CHAR(30))) SEPARATOR '')
      FROM wtms_Role_Menu_Mapping s
      WHERE s.Fk_Role_ID = t.role_id),1,1,'') AS menu_id FROM worktual_roles_master_dtl AS t
   where (Pk_role_id = 0) or t.role_id = Pk_role_id
   GROUP BY role_id,Role_name,Role_created_date,role_status;   
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_get_summaries_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_get_summaries_dtl`(
 summary_id INT,
 fk_prod_id INT,
 fk_bundle_id INT,
 fk_sub_prod INT
 )
begin
 
    IF summary_id is null then set summary_id = 0; END IF;
    IF fk_prod_id is null then set fk_prod_id = 0; END IF;
    IF fk_bundle_id is null then set fk_bundle_id = 0; END IF;
    IF fk_sub_prod is null then set fk_sub_prod = 0; END IF;
 
 
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select	a.summary_id as summary_id,a.summary_name as summary_name,a.fk_prod_id as fk_prod_id,a.fk_sub_prod as fk_sub_prod,
 			a.fk_bundle_id as fk_bundle_id,   a.summary_status as summary_status,a.summary_create_date as summary_create_date,a.fk_tier_id as Tier_type,a.summary_desc, a.summary_url
    from wtms_tier_summaries_master_dtl a 
    where (a.summary_id = summary_id or IFNULL(summary_id,0) = 0)
    and (a.fk_prod_id = fk_prod_id or IFNULL(fk_prod_id,0) = 0)
    and ((a.fk_sub_prod = fk_bundle_id or IFNULL(fk_bundle_id,0) = 0) or (a.fk_sub_prod = fk_sub_prod or IFNULL(fk_sub_prod,0) = 0))
    and ((a.fk_sub_prod = fk_sub_prod or a.fk_sub_prod = fk_sub_prod)  or IFNULL(fk_sub_prod,0) = 0) and IFNULL(a.summary_status,0) = 1;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_get_summary_position_by_tierid` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_get_summary_position_by_tierid`(
p_tier_id int,
p_summary_id int
)
Begin
select position as summary_position from wtms_tier_summary_map where fk_tier_id = p_tier_id and summary_id= p_summary_id;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_get_tier_approval_list` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_get_tier_approval_list`(tier_id INT)
begin
  
     IF tier_id is null then
        set tier_id = 0;
     END IF;
     select	id,a.fk_tier_id,approver_1_userid,approver_1_user_group_name,approver_1_status,approver_1_approved_on,approver_1_remarks,approver_2_userid,
  			approver_2_user_group_name,approver_2_status,approver_2_approved_on,approver_2_remarks
     from wtms_tier_approval_management a join wtms_tier_management b on a.fk_tier_id = b.tier_id    
     where (a.fk_tier_id = tier_id) 
    
    
     order by id desc limit 1;
  end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_get_tier_management` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_get_tier_management`(
	tier_id INT,
    type INT,
    categoryid INT
)
Begin
                     
                     
			IF tier_id is null then set tier_id = 0; END IF;
			IF type is null then set type = 1; END IF;
			IF categoryid is null then set categoryid = 0; END IF;
		 
		
			if type = 1 or type = 0 then
		 
				select Distinct a.tier_id,a.tier_name,a.tier_description ,a.tier_type,c.name as tier_type_name,a.prod_type_id,
				wtms.getprodsubprodlist(a.tier_id,1) as prod_name,
				wtms.getprodsubprodlist(a.tier_id,2) as sub_prod_name,
				a.bund_prd_type,a.product_id,a.sub_product_id,a.fk_purpose_id,a.status,a.country_id,a.reseller_id,a.pro_user_count,a.standard_user_count,a.basic_user_count,a.free_trail_status ,a.free_trail_days,a.double_up,a.Installation_cost,a.Installation_cost_free_count,
			   a.platform_fee,a.messages_count,a.sessions_count,a.Type_of_plan,a.Custom_status,a.platform_fee_year,a.apply_new_exist_cust,a.booking_user_count,a.booking_user_price,a.parent_id 
				from wtms_tier_management a
				left join product_master b on a.prod_type_id = b.prod_id
				left join wtms_ref_tier_type c on a.tier_type = c.id
				where (a.tier_id = tier_id or IFNULL(tier_id,0) = 0)
				and a.is_review in (1,2)
				order by a.tier_id desc;
			end if;
		 
			
			if type = 2 then
			
				select a.tier_id,a.free_or_paid,a.currency,b.fk_user_type_id,b.fk_contract_period_id,b.discount1, b.discount2,
				cast(b.price1 as decimal(10,2)) as price1,cast(b.price2 as decimal(10,2)) as price2,cast(b.price3 as decimal(10,2)) as price3,
				
				b.months1,b.months2,b.min_user,a.apply_new_exist_cust,
				c.nof_id,c.nof_from,c.nof_to,c.nof_users_description,d.cop_id,d.cop_period,d.cop_description,e.curr_name as currency_name,
				a.per_addn_user,a.per_addn_user_currency,b.max_user,a.parent_id
				from wtms_tier_management a
				left join wtms_contract_pricing_dtl b on a.tier_id = b.tier_id
				left join wtms_no_of_users_master c on b.fk_user_type_id = c.nof_id
				left join wtms_contract_period_master d on b.fk_contract_period_id = d.cop_id
				left join worktual_currency_master_dtl e
				on e.curr_id = a.currency
				where (a.tier_id = tier_id or IFNULL(tier_id,0) = 0);
			end if;
		 
			
			if type = 3 then
			
			   select a.tier_id,b.tiertype,b.bundle_id,b.product_id,b.sub_product_id,b.summary_id,c.summary_name,b.id
			   from wtms_tier_management a
			   left join wtms_tier_summary_map b on a.tier_id = b.fk_tier_id
			   left join wtms_tier_summaries_master_dtl c on b.summary_id = c.summary_id
			   where (a.tier_id = tier_id or IFNULL(tier_id,0) = 0);
			end if;
		 
			
			if type = 4 then
			
			   select a.tier_id,b.catg_id,b.catg_pos,c.category_Name,b.id
			   from wtms_tier_management a
			   left join wtms_tier_category_position b on a.tier_id = b.fk_tier_id
			   left join wtms_feature_category c on b.catg_id = c.category_id
			   where (a.tier_id = tier_id or IFNULL(tier_id,0) = 0);
			end if;
		 
			
			if type = 5 then
			
			   select a.tier_id,b.tiertype,b.product_id,b.sub_product_id,b.categoryid,c.category_Name,b.featureid,b.id
			   from wtms_tier_management a
			   left join wtms_tier_catg_feature_mapping_info b on a.tier_id = b.tier_id
			   left join wtms_feature_category c on c.category_id = b.categoryid
			   where (a.tier_id = tier_id or IFNULL(tier_id,0) = 0);
			end if;
		 
			
			if type = 6 then
			
			   select a.tier_id,b.tiertype,bundle_id,b.product_id,b.sub_product_id,b.categoryid,b.featureid,c.feature_name,b.value1,b.value2,b.value3,b.value4,b.value5,b.id
			   from wtms_tier_management a
			   left join wtms_tier_feature_mapping_xml b on a.tier_id = b.tier_id
			   left join wtms_feature_info c on b.featureid = c.feature_id
			   where (a.tier_id = tier_id or IFNULL(tier_id,0) = 0)
			   and (b.categoryid = categoryid or IFNULL(categoryid,0) = 0);
			end if;
		 
			
			if type = 7 then
			
			select 	Distinct a.tier_id,a.tier_name,a.tier_description ,a.tier_type,c.name as tier_type_name,a.prod_type_id,
					wtms.getprodsubprodlist(a.tier_id,1) as prod_name,
					wtms.getprodsubprodlist(a.tier_id,2) as sub_prod_name,
					a.bund_prd_type,a.product_id,a.sub_product_id,a.fk_purpose_id,a.status,
					d.approver_1_user_group_name,d.approver_1_approved_on, d.approver_2_user_group_name,d.approver_2_approved_on,
					d.approver_1_username,d.approver_2_username,a.country_id,a.pro_user_count,a.standard_user_count,a.basic_user_count,a.free_trail_status ,a.free_trail_days,ifnull(a.free_trial_amount,0) as free_trial_amount,
					a.double_up,a.Installation_cost,a.Installation_cost_free_count,a.platform_fee,a.messages_count,a.sessions_count,a.Type_of_plan,a.Custom_status,a.platform_fee_year,a.apply_new_exist_cust,a.booking_user_count,a.booking_user_price,
					a.parent_id
			from wtms_tier_management a
			left join product_master b on a.prod_type_id = b.prod_id
			left join wtms_ref_tier_type c on a.tier_type = c.id
			inner join wtms_tier_approval_management d on a.tier_id = d.fk_tier_id
			where (a.tier_id = tier_id or IFNULL(tier_id,0) = 0)
			and a.is_review = 3
			and d.approver_1_status = 'Approved' and d.approver_2_status = 'Approved'
			order by a.tier_id desc;
			end if;
		 
			
			if type = 8 then
				SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
				select 	tier_id	,tier_name,	a.tier_type,c.name as tier_type_name,tier_description,status,a.create_date,	a.create_by,	a.is_review,
						wtms.getprodsubprodlist(a.tier_id,1) as prod_name,
						wtms.getprodsubprodlist(a.tier_id,2) as sub_prod_name,
						a.parent_id
				from wtms_tier_management_log  a 
				left join product_master b  on a.prod_type_id = b.prod_id
				left join wtms_ref_tier_type c  on a.tier_type = c.id
				
				where (a.tier_id = tier_id or tier_id = 0)
				order by a.tier_id asc;
				SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
			end if;
		 
		 
		 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_get_tier_management_backup` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_get_tier_management_backup`(
     tier_id INT,
     type INT,
     categoryid INT
     )
Begin
     
     
        IF tier_id is null then set tier_id = 0; END IF;
        IF type is null then set type = 1; END IF;
        IF categoryid is null then set categoryid = 0; END IF;
     
     	
     
        if type = 1 or type = 0 then
     
           select Distinct a.tier_id,a.tier_name,a.tier_description ,a.tier_type,c.name as tier_type_name,a.prod_type_id,
     		wtms.getprodsubprodlist(a.tier_id,1) as prod_name,
     		wtms.getprodsubprodlist(a.tier_id,2) as sub_prod_name,
     		a.bund_prd_type,a.product_id,a.sub_product_id,a.fk_purpose_id,a.status,a.country_id,a.reseller_id
           from wtms_tier_management a
           left join product_master b on a.prod_type_id = b.prod_id
           left join wtms_ref_tier_type c on a.tier_type = c.id
           where (a.tier_id = tier_id or IFNULL(tier_id,0) = 0)
           and a.is_review  in(1,2)
           order by a.tier_id desc;
        end if;
     
     	
        if type = 2 then
     	
           select a.tier_id,a.free_or_paid,a.currency,b.fk_user_type_id,b.fk_contract_period_id,b.discount1, b.discount2,
  		cast(b.price1 as decimal(10,2)) as price1,cast(b.price2 as decimal(10,2)) as price2,cast(b.price3 as decimal(10,2)) as price3,b.months1,b.months2,b.min_user,a.apply_new_exist_cust,
     		c.nof_id,c.nof_from,c.nof_to,c.nof_users_description,d.cop_id,d.cop_period,d.cop_description,e.curr_name as currency_name,
     		a.per_addn_user,a.per_addn_user_currency
           from wtms_tier_management a
           left join wtms_contract_pricing_dtl b on a.tier_id = b.tier_id
           left join wtms_no_of_users_master c on b.fk_user_type_id = c.nof_id
           left join wtms_contract_period_master d on b.fk_contract_period_id = d.cop_id
           left join worktual_currency_master_dtl e
           on e.curr_id = a.currency
           where (a.tier_id = tier_id or IFNULL(tier_id,0) = 0);
        end if;
     
     	
        if type = 3 then
     	
           select a.tier_id,b.tiertype,b.bundle_id,b.product_id,b.sub_product_id,b.summary_id,c.summary_name,b.id
           from wtms_tier_management a
           left join wtms_tier_summary_map b on a.tier_id = b.fk_tier_id
           left join wtms_tier_summaries_master_dtl c on b.summary_id = c.summary_id
           where (a.tier_id = tier_id or IFNULL(tier_id,0) = 0);
        end if;
     
     	
        if type = 4 then
     	
           select a.tier_id,b.catg_id,b.catg_pos,c.category_Name,b.id
           from wtms_tier_management a
           left join wtms_tier_category_position b on a.tier_id = b.fk_tier_id
           left join wtms_feature_category c on b.catg_id = c.category_id
           where (a.tier_id = tier_id or IFNULL(tier_id,0) = 0);
        end if;
     
     	
        if type = 5 then
     	
           select a.tier_id,b.tiertype,b.product_id,b.sub_product_id,b.categoryid,c.category_Name,b.featureid,b.id
           from wtms_tier_management a
           left join wtms_tier_catg_feature_mapping_info b on a.tier_id = b.tier_id
           left join wtms_feature_category c on c.category_id = b.categoryid
           where (a.tier_id = tier_id or IFNULL(tier_id,0) = 0);
        end if;
     
     	
        if type = 6 then
     	
           select a.tier_id,b.tiertype,bundle_id,b.product_id,b.sub_product_id,b.categoryid,b.featureid,c.feature_name,b.value1,b.value2,b.value3,b.value4,b.value5,b.id
           from wtms_tier_management a
           left join wtms_tier_feature_mapping_xml b on a.tier_id = b.tier_id
           left join wtms_feature_info c on b.featureid = c.feature_id
           where (a.tier_id = tier_id or IFNULL(tier_id,0) = 0)
           and (b.categoryid = categoryid or IFNULL(categoryid,0) = 0);
        end if;
     
     	
        if type = 7 then
     	
           select Distinct a.tier_id,a.tier_name,a.tier_description ,a.tier_type,c.name as tier_type_name,a.prod_type_id,
     		wtms.getprodsubprodlist(a.tier_id,1) as prod_name,
     		wtms.getprodsubprodlist(a.tier_id,2) as sub_prod_name,
     		a.bund_prd_type,a.product_id,a.sub_product_id,a.fk_purpose_id,a.status,
     		d.approver_1_user_group_name,d.approver_1_approved_on, d.approver_2_user_group_name,d.approver_2_approved_on,
     		d.approver_1_username,d.approver_2_username,a.country_id
           from wtms_tier_management a
           left join product_master b on a.prod_type_id = b.prod_id
           left join wtms_ref_tier_type c on a.tier_type = c.id
           inner join wtms_tier_approval_management d on a.tier_id = d.fk_tier_id
           where (a.tier_id = tier_id or IFNULL(tier_id,0) = 0)
           and a.is_review = 3
           and d.approver_1_status = 'Approved' and d.approver_2_status = 'Approved'
           order by a.tier_id desc;
        end if;
     
     
     	
        if type = 8 then
     	
           SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
           select tier_id	,tier_name,	a.tier_type,c.name as tier_type_name,tier_description,status,a.create_date,	a.create_by,	a.is_review,
     		wtms.getprodsubprodlist(a.tier_id,1) as prod_name,
     		wtms.getprodsubprodlist(a.tier_id,2) as sub_prod_name
           from wtms_tier_management_log  a 
           left join product_master b  on a.prod_type_id = b.prod_id
           left join wtms_ref_tier_type c  on a.tier_type = c.id
           inner join wtms_tier_approval_management d  on a.tier_id = d.fk_tier_id
           where (a.tier_id = tier_id or tier_id = 0)
           order by a.tier_id asc;
           SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
        end if;
     
     
     End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_get_tier_plan_purpose_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_get_tier_plan_purpose_info`(
 		purpose_id int,
 		product_id int,
 		prod_type_id int,
 		p_country_id int
       )
Begin
                         
       		 if purpose_id = 0 then set purpose_id = 1; end if;
       		 if product_id = 0 then set product_id = 1; end if;
       
       		select 	
 					a.prod_type_id,a.product_id,a.fk_purpose_id,a.fk_tier_id as tier_id,tier_name,tier_description,e.purpose_name,
 					
                     cast(b.price1 as decimal(10,2)) as price1,cast(b.price2 as decimal(10,2)) as price2,cast(b.price3 as decimal(10,2)) as price3
                     ,b.discount1,b.discount2,c.cop_description,d.nof_from,d.nof_to,d.nof_users_description,b.min_user,
 					wtms.getsummarylist(a.fk_tier_id,2) as summary_list,
 					a.pro_user_count,b.max_user,a.product_id,a.prod_type_id,a.free_trail_status ,a.free_trail_days,ifnull(a.free_trial_amount,0) as free_trial_amount,
 					Installation_cost_free_count, Installation_cost,a.platform_fee,a.messages_count,a.sessions_count,a.Type_of_plan,a.Custom_status, 
 					wtms.getsummarylist(a.fk_tier_id,3) as summary_desc_list,
 					wtms.getsummarylist(a.fk_tier_id,4) as summary_url_list,
 					a.platform_fee_year,a.apply_new_exist_cust,a.free_or_paid,a.booking_user_count,a.booking_user_price
 					,a.platform_fee_json_info, a.parent_id, a.per_addn_user
       		from wtms.wtms_copy_of_tier_management_temp a 
       		inner join wtms.wtms_contract_pricing_dtl b on a.fk_tier_id = b.tier_id
       		inner join wtms.wtms_contract_period_master c on c.cop_id=b.fk_contract_period_id
       		inner join wtms.wtms_no_of_users_master d on b.fk_user_type_id = d.nof_id
       		inner join wtms.wtms_ref_tier_purpose e on a.fk_purpose_id = e.purpose_id
       		where (a.fk_purpose_id = purpose_id) 
       		and (a.product_id = product_id or (ifnull(product_id,1)=1))
       		and (a.prod_type_id  = prod_type_id  or (ifnull(prod_type_id,0)=0))
  			and a.country_id = p_country_id
       		and a.status = 1 and a.tier_name not like '%copy%' and a.is_review in (3,4);
       
       		End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_get_tier_pricing_range_user_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_get_tier_pricing_range_user_info`(
  contract_period INT , 
  no_of_user INT  
  )
Begin
  
  
     IF contract_period is null then set contract_period = 0; END IF;
     IF no_of_user is null then set no_of_user = 0; END IF;
     if contract_period = 0 then set contract_period = 1; end if;
     if no_of_user = 0 then set no_of_user = 1; end if;
  
     select	a.fk_tier_id as tier_id,tier_name,tier_description,b.price1,b.price2,b.price3,b.discount1,b.discount2,c.cop_description,d.nof_from,d.nof_to,
  			d.nof_users_description,b.min_user,a.Type_of_plan,a.Custom_status
     from wtms_copy_of_tier_management_temp a
     inner join wtms_contract_pricing_dtl b on a.fk_tier_id = b.tier_id
     inner join wtms_contract_period_master c on c.cop_id = b.fk_contract_period_id
     inner join wtms_no_of_users_master d on b.fk_user_type_id = d.nof_id
     where c.cop_id = contract_period and d.nof_id = no_of_user
     and a.status = 1 and a.is_review = 3;
  
  End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_get_tier_purpose_info_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_get_tier_purpose_info_dtl`(
  purpose_id int
  )
Begin
  
  	if purpose_id is null or purpose_id = '' then
  		set purpose_id = 0 ; 
  	end if;
  
  	select a.purpose_id,a.purpose_name,a.create_date from wtms_ref_tier_purpose a where (a.purpose_id = purpose_id or ifnull(purpose_id,0) = 0 )
     and a.status=1;
  End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_get_tier_type_info_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_get_tier_type_info_dtl`(id INT)
begin

   IF id is null then
      set id = 0;
   END IF;
   select b.id,b.name from wtms_ref_tier_type b where (b.id = id or IFNULL(id,0) = 0);
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_get_tier_type_master_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_get_tier_type_master_info`()
Begin

   select id,name from wtms_ref_tier_type;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_get_user_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_get_user_dtl`(userid INT)
Begin

   IF userid is null then
      set userid = 0;
   END IF;
   select a.userid,firstname,lastname,username,password,user_role,user_group,d.user_group_name as user_group_name,a.status,a.create_date,a.modify_date,a.created_by,b.role_name,c.group_name ,a.user_group_name as user_group_id
   from wtms_user_master_dtl a
   left join worktual_roles_master_dtl b on a.user_role = b.role_id
   left join worktual_groups_master_dtl c on a.user_group = c.group_id
   left join wtms_user_group_hdr d on d.user_group_id = a.user_group_name
   where (a.userid = userid or IFNULL(userid,0) = 0);

End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_get_user_groupname` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_get_user_groupname`(
user_group_id int
)
Begin

	if user_group_id is null or user_group_id = '' then
		set user_group_id = 0;
	end if;
    
	SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
		select Distinct a.user_group_id,a.user_group_name,a.status,a.create_date 
		from wtms_user_group_hdr a
		where (a.user_group_id = user_group_id or ifnull(user_group_id,0)=0);
	SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_get_user_group_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_get_user_group_info`(
user_group_id INT,
userid INT
)
Begin


   IF user_group_id is null then set user_group_id = 0; END IF;
   IF userid is null then set userid = 0; END IF;

   select	a.user_group_id,a.Fk_role_id,a.fk_group_id,a.user_group_name,c.role_name as role_name,b.group_name as group_name ,a.status,
			a.create_date,a.created_by,a.modify_date,a.modify_by,a.approve_1,a.approve_2
   from wtms_user_group_hdr a
   join worktual_groups_master_dtl b on a.fk_group_id = b.group_id
   join worktual_roles_master_dtl c on c.role_id = a.Fk_role_id
   join wtms_user_master_dtl d on d.user_group = b.group_id
   where (a.user_group_id = user_group_id or IFNULL(user_group_id,0) = 0) and (a.user_group = userid or IFNULL(userid,0) = 0)
   and (a.approve_1 is not null or a.approve_2 is not null);
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_get_user_group_list_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_get_user_group_list_info`(
userid INT
)
begin


   DECLARE user_role INT DEFAULT 0;


   IF userid is null then set userid = 0; END IF;

   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select b.userid as userid,a.user_group_name,a.user_group_id as user_group_id,a.status,a.approve_1,a.approve_2,c.group_name as group_name,d.role_name as role_name,a.create_date as create_date
   from  wtms_user_group_hdr a 
   join wtms_user_master_dtl b on a.Fk_role_id = b.user_role
   join worktual_groups_master_dtl c on c.group_id = a.fk_group_id
   join worktual_roles_master_dtl d on d.role_id = a.Fk_role_id
   where (a.Fk_role_id = user_role or IFNULL(user_role,0) = 0)
   and (b.userid = userid or IFNULL(userid,0) = 0)  and IFNULL(a.status,b.status) = 1
   order by b.userid;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_get_user_group_permission` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_get_user_group_permission`(
 Fk_user_group_id INT,
 fk_menu_id INT  ,
 type INT)
Begin
 
 
 
    IF Fk_user_group_id is null then
       set Fk_user_group_id = 0;
    END IF;
    IF fk_menu_id is null then
       set fk_menu_id = 0;
    END IF;
    IF type is null then
       set type = 1;
    END IF;
    if type = 0 then
       set type = 1;
    end if;
 	
    if type = 1 then
 	
       select Distinct a.Fk_user_group_id,Fk_role_id,fk_group_id,user_group_name,c.role_name as role_name,d.group_name as group_name,  a.create_date,a.status
       from wtms_user_group_details a
       join wtms_user_group_hdr b on a.Fk_user_group_id = b.user_group_id
       join worktual_roles_master_dtl c on c.role_id = b.Fk_role_id
       join worktual_groups_master_dtl d on d.group_id = b.fk_group_id
       where (a.Fk_user_group_id = Fk_user_group_id or IFNULL(Fk_user_group_id,0) = 0)
       and (a.fk_menu_id = fk_menu_id or IFNULL(fk_menu_id,0) = 0);
    end if;
 
 
    if type = 2 then
 	
       select a.Fk_user_group_id,Fk_role_id,fk_group_id,user_group_name,c.role_name as role_name,d.group_name as group_name,a.fk_menu_id,is_menu,is_create,is_edit,is_view,is_copy,is_approve_reject_rfm,a.create_date,a.status
       from wtms_user_group_details a
       join wtms_user_group_hdr b on a.Fk_user_group_id = b.user_group_id
       join worktual_roles_master_dtl c on c.role_id = b.Fk_role_id
       join worktual_groups_master_dtl d on d.group_id = b.fk_group_id
       where (a.Fk_user_group_id = Fk_user_group_id or IFNULL(Fk_user_group_id,0) = 0)
       and (a.fk_menu_id = fk_menu_id or IFNULL(fk_menu_id,0) = 0);
    end if;
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_get_user_menu_link_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_get_user_menu_link_dtl`(
userid INT,
Menu_link VARCHAR(250)
)
Begin

   IF userid is null then
      set userid = 0;
   END IF;
   IF Menu_link is null then
      set Menu_link = '';
   END IF;
   select d.userid,e.group_name,e.group_id,f.role_id,f.role_name,Fk_user_group_id,fk_menu_id,is_menu,is_create,is_edit,is_view,is_copy,is_approve_reject_rfm,c.Menu_link,c.Menu_Name,Pk_Menu_Id
   from wtms_user_group_details a
   left join wtms_user_group_hdr b on a.Fk_user_group_id = b.user_group_id
   left join wtms_tbl_Menu c on a.fk_menu_id = c.Pk_Menu_Id
   left join wtms_user_master_dtl d on d.user_role = b.Fk_role_id
   left join worktual_groups_master_dtl e on e.group_id = b.fk_group_id
   left join worktual_roles_master_dtl f on f.role_id = d.user_role
   where (d.userid = userid or IFNULL(userid,0) = 0)
   and (c.Menu_link = Menu_link or IFNULL(Menu_link,'') = '');
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_get_user_type` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_get_user_type`()
Begin
	select a.typeid,a.name from wtms_ref_user_type a;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_myaccount_get_addon_list` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_myaccount_get_addon_list`(company_id int)
Begin
   
   		select description,cast(price as decimal(10,2)) as price,0 as addon_id, 0 as is_cancel
          from ur_invoice_breakup a
   		where a.company_id = company_id
   		and category like '%add%on%'
   		union 
   		select ap.addon_name as description,cast(cp.total_charge as decimal(10,2)) as price,ap.addon_id as  addon_id,ap.is_cancel as is_cancel
   		from ur_addon_purchase_hdr ap join comp_prepaid_payment_info cp on ap.Pay_Reference = cp.pay_reference
   		where cp.company_id = company_id and cp.purchase_type like '%add%on%';
           
     End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_plan_category_summary_create_notes_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_plan_category_summary_create_notes_info`(
plan_id INT,
processtype INT, 
catg_id INT, 
catg_summary_notes LONGTEXT, 
catg_summary_notes_status INT,
plan_summary_notes_id INT)
Begin

   DECLARE v_errcode INT; 
   DECLARE v_errmsg VARCHAR(100);
   DECLARE v_category_name VARCHAR(100);
   DECLARE v_now DATETIME(3);

   sp_exit:
   BEGIN
      set v_errcode = -1;
      set v_errmsg = 'Failure';
      set v_now = CURRENT_TIMESTAMP;
      if processtype = 1 then
	
         if exists(select  *  from worktual_plan_summary_info a where a.summary_notes = catg_summary_notes and a.plan_id = plan_id LIMIT 1)
         then
            set v_errcode = -1;
            set v_errmsg = 'Summary notes already found';
            LEAVE sp_exit;
         end if;
         
         select   b.category_name INTO v_category_name from worktual_sum_category_master b where b.category_id = catg_id;
         insert into worktual_plan_summary_info(plan_id,fk_category_id,summary_notes,sum_status,create_date)
		values(plan_id,catg_id,catg_summary_notes,catg_summary_notes_status,v_now);
		
         set plan_summary_notes_id = LAST_INSERT_ID();
         if ROW_COUNT() > 0 then
		
            set v_errcode = 0;
            set v_errmsg = 'Notes Inserted';
            LEAVE sp_exit;
         end if;
      end if;
      
      if processtype = 2 
      then
         if exists(select  *  from worktual_plan_summary_info c
         where c.summary_notes = catg_summary_notes and c.plan_id = plan_id
         and c.summaryid <> plan_summary_notes_id LIMIT 1) 
         then
            set v_errcode = -1;
            set v_errmsg = 'Notes already found';
            LEAVE sp_exit;
         end if;
         
         if not exists(select  *  from worktual_plan_summary_info d where d.summaryid = plan_summary_notes_id LIMIT 1) 
         then
            set v_errcode = -1;
            set v_errmsg = 'Notes ID not exist';
            LEAVE sp_exit;
         end if;
         
         UPDATE worktual_plan_summary_info a
         set a.summary_notes = catg_summary_notes,a.sum_status = catg_summary_notes_status,
         a.create_date = v_now
         where a.plan_id = plan_id and summaryid = plan_summary_notes_id;
         if ROW_COUNT() > 0 
         then
            set v_errcode = 0;
            set v_errmsg = 'Notes Updated';
            LEAVE sp_exit;
         end if;
      end if;
      
      if processtype = 3 
      then
         if not exists(select  *  from worktual_plan_summary_info where summaryid = plan_summary_notes_id LIMIT 1) 
         then
            set v_errcode = -1;
            set v_errmsg = 'Notes ID not exist';
            LEAVE sp_exit;
         end if;
         
         delete from worktual_plan_summary_info where summaryid = plan_summary_notes_id;
         if ROW_COUNT() > 0 
         then
            set v_errcode = 0;
            set v_errmsg = 'Notes Deleted';
            LEAVE sp_exit;
         end if;
      end if;
   END;
   select  v_errcode as errcode,v_errmsg as errmsg,plan_summary_notes_id as plan_summary_notes_id;

End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_product_set_discount_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_product_set_discount_details`(
prod_id INT,
prod_description   VARCHAR(555),
disc_percent FLOAT,
disc_percent_status INT ,
process_type INT 
)
begin


   DECLARE v_errcode INT;
   DECLARE v_errmsg VARCHAR(160);
   DECLARE v_now DATETIME(3);
	
   sp_exit:
   BEGIN
      set v_errcode = -1;
      set v_errmsg = 'Failure';
      set v_now = CURRENT_TIMESTAMP;
      IF process_type = 1 then
			
         IF NOT EXISTS(SELECT  * FROM product_master b   where b.prod_id = prod_id LIMIT 1) 
         then
            SET v_errcode = -1;
            set v_errmsg = 'Product is not available';
            LEAVE sp_exit;
         end if;
         
         INSERT INTO product_discount_details(prod_id,prod_description,disc_percent,disc_percent_status,created_date)
				VALUES(prod_id,prod_description ,disc_percent,disc_percent_status,v_now);
		   		
         if ROW_COUNT() > 0 
         then
            SET v_errcode = 0;
            set v_errmsg = 'Success : Product Discount created';
            LEAVE sp_exit;
         end if;
      end if;
      
      IF process_type = 2
      then
         IF NOT EXISTS(SELECT  * FROM product_master b   where b.prod_id = prod_id LIMIT 1)
         then
            SET v_errcode = -1;
            set v_errmsg = 'Product is not available';
            LEAVE sp_exit;
         end if;
         IF not EXISTS(SELECT  * FROM product_discount_details where  prod_id = prod_id LIMIT 1) 
         then
            SET v_errcode = -1;
            set v_errmsg = 'Product Discount is not exist';
            LEAVE sp_exit;
         end if;
         
         UPDATE product_discount_details a set 
         a.prod_description = IFNULL(prod_description ,a.prod_description),
         a.disc_percent_status = disc_percent_status,
         a.created_date = IFNULL(v_now,a.created_date),
         a.disc_percent = IFNULL(disc_percent,a.disc_percent)
         where a.prod_id = prod_id;
         
         if ROW_COUNT() > 0 
         then
            SET v_errcode = 0;
            set v_errmsg = 'Success : product discount updated';
            LEAVE sp_exit;
         end if;
      end if;
   END;
   select v_errcode as errcode,v_errmsg as errmsg;
   


end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_prod_get_disc_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_prod_get_disc_details`(prod_id INT)
begin

   IF prod_id is null then
      set prod_id = 0;
   END IF;
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select a.prod_id,a.prod_name,a.prod_description,a.disc_percent,a.disc_percent_status,a.created_date from prod_disc_details a 
   where (a.prod_id = prod_id or prod_id = 0) and a.disc_percent_status = 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_prod_set_disc_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_prod_set_disc_details`(
prod_id INT,
prod_description  VARCHAR(555),
prod_name INT,
disc_percent FLOAT,
disc_percent_status INT ,
process_type INT 
)
begin


   DECLARE v_errcode INT;
   DECLARE v_errmsg VARCHAR(160);
   DECLARE v_now DATETIME(3);
	
   sp_exit:
   BEGIN
      set v_errcode = -1;
      set v_errmsg = 'Failure';
      set v_now = CURRENT_TIMESTAMP;
      IF process_type = 1 then
			
         IF  EXISTS(SELECT * FROM prod_disc_details b   where b.prod_id = prod_id LIMIT 1) 
         then
            SET v_errcode = -1;
            set v_errmsg = 'Product discount is already available';
            LEAVE sp_exit;
         end if;
         
         INSERT INTO prod_disc_details(prod_id,prod_name,prod_description,disc_percent,disc_percent_status,created_date)
				VALUES(prod_id,prod_name,prod_description,disc_percent,disc_percent_status,v_now);
		   		
         if ROW_COUNT() > 0 
         then
            SET v_errcode = 0;
            set v_errmsg = 'Success : Product Discount created';
            LEAVE sp_exit;
         end if;
      end if;
      
      IF process_type = 2 
      then
         IF not EXISTS(SELECT  * FROM prod_disc_details a where  a.prod_id = prod_id LIMIT 1) 
         then
            SET v_errcode = -1;
            set v_errmsg = 'Product Discount is not exist';
            LEAVE sp_exit;
         end if;
         
         UPDATE prod_disc_details a set 
         a.prod_description = IFNULL(prod_description,a.prod_description),
         a.prod_name = IFNULL(prod_name,a.prod_name),
         a.disc_percent_status = disc_percent_status,
         a.created_date = IFNULL(v_now,a.created_date),
         a.disc_percent = IFNULL(disc_percent,a.disc_percent)
         where a.prod_id = prod_id;
         
         
         if ROW_COUNT() > 0
         then
            SET v_errcode = 0;
            set v_errmsg = 'Success : product discount updated';
            LEAVE sp_exit;
         end if;
      end if;
      
      IF process_type = 3 
      then
         IF NOT EXISTS(SELECT  * FROM prod_disc_details b where b.prod_id = prod_id LIMIT 1) 
         then
            SET v_errcode = -1;
            set v_errmsg = 'group ID not exist';
            LEAVE sp_exit;
         end if;
         
         update prod_disc_details b set b.disc_percent_status = 3 where b.prod_id = prod_id;
         if ROW_COUNT() > 0
         then
            SET v_errcode = 0;
            set v_errmsg = 'Deleted : disc_percent deleted';
            LEAVE sp_exit;
         end if;
      end if;
   END;
   select v_errcode as errcode,v_errmsg as errmsg;
   


end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_Role_Menu_Mapping_get_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_Role_Menu_Mapping_get_info`(
Role_ID INT,
group_id INT,
menu_id INT
)
BEGIN

	
   DECLARE v_errcode INT; 
   DECLARE v_errmsg VARCHAR(250);

	
   Sp_exit:
   BEGIN
      SET v_errcode = -1;
      SET v_errmsg = 'Failure to do role Mapping.';
      
      if exists(select  1 from wtms_user_group_details a join wtms_user_group_hdr b on a.Fk_user_group_id = b.user_group_id
      where b.fk_group_id = group_id and Fk_role_id = Role_ID and fk_menu_id = menu_id LIMIT 1)
      then
         SET v_errcode = 0;
         SET v_errmsg = 'success role Mapping.';
         LEAVE sp_exit;
      else
         SET v_errcode = -1;
         SET v_errmsg = 'failed role Mapping.';
      end if;
   END;
   select v_errcode as errcode,v_errmsg as errmsg;
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_tier_create_approval_management` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_tier_create_approval_management`(
   tier_id INT,
   user_id INT,
   user_group_id INT,
   approver_status VARCHAR(10),
   approver_remarks VARCHAR(250))
Begin
   
   
      DECLARE v_user_role INT;
      DECLARE v_errcode INT DEFAULT 0;
      DECLARE v_errmsg VARCHAR(100) DEFAULT 'success';
      DECLARE v_approver_1_remarks VARCHAR(250);
      DECLARE v_approver_2_remarks VARCHAR(250);
      DECLARE v_approver_1_status VARCHAR(250);
      DECLARE v_approver_2_status VARCHAR(250);
      DECLARE v_now DATETIME(3); 
      DECLARE v_id INT;
      DECLARE v_ug_id INT DEFAULT 0;
      DECLARE v_username VARCHAR(50);
      DECLARE v_logid INT;
   
      DECLARE v_user_group_name VARCHAR(20) DEFAULT '';
      DECLARE Swv_RowCount INT;
   
      sp_exit:
      BEGIN
         select   IFNULL(a.user_group_name,0), b.user_group_name, username 
         INTO v_ug_id,v_user_group_name,v_username 
         from wtms_user_master_dtl a join wtms_user_group_hdr b on a.user_group_name = b.user_group_id where a.userid = user_id;
         
         if v_ug_id <> user_group_id 
         then
            SET v_errcode = -1;
            SET v_errmsg = CONCAT('Role mapped to ',v_user_group_name,' and user_group_id - ',cast(v_ug_id as CHAR(30)));
            LEAVE sp_exit;
         end if;
         
         set v_now = CURRENT_TIMESTAMP;
         if not exists(select  * from wtms_tier_approval_management a where a.fk_tier_id = tier_id LIMIT 1)
         then
   	
   		  insert into wtms_tier_approval_management(fk_tier_id,approver_1_userid,approver_1_user_group_name,approver_1_status,approver_1_approved_on,
   		approver_1_remarks,approver_2_userid,approver_2_user_group_name,approver_2_status,approver_2_approved_on,approver_2_remarks,approver_1_username,approver_2_username)
   		values(tier_id,user_id,v_user_group_name,approver_status,v_now,approver_remarks,0,'','',null,'',v_username,'');
   		
            SET v_errcode = 0;
            SET v_errmsg = 'Success : Tier status sent';
            LEAVE sp_exit;
         end if;
         
         SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
         select   max(a.id) INTO v_id from wtms_tier_approval_management a where a.fk_tier_id = tier_id;
         SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
         SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
         select   max(b.id) INTO v_logid from wtms_tier_management_log b  where b.tier_id = tier_id;
         SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
         SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
         select   a.approver_1_status, a.approver_2_status, a.approver_1_remarks, a.approver_2_remarks 
         INTO v_approver_1_status,v_approver_2_status,v_approver_1_remarks,v_approver_2_remarks 
         from wtms_tier_approval_management a where a.fk_tier_id = tier_id and a.id = v_id;
         SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   
   		
         if (v_approver_1_status is null or v_approver_1_status = 'Rejected') and (v_approver_1_remarks is not null or v_approver_1_remarks is null or v_approver_1_remarks = '') then
   			
            SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
            insert into wtms_tier_approval_management(fk_tier_id,approver_1_userid,approver_1_user_group_name,approver_1_status,approver_1_approved_on,
   				approver_1_remarks,approver_2_userid,approver_2_user_group_name,approver_2_status,approver_2_approved_on,approver_2_remarks,approver_1_username,approver_2_username)
            select  tier_id as fk_tier_id,
   						user_id as approver_1_userid,
   						v_user_group_name as approver_1_user_group_name,
   						approver_status as approver_1_status,
   						v_now as approver_1_approved_on,
   						approver_remarks as approver_1_remarks,
   						b.approver_2_userid,
   						b.approver_2_user_group_name,
   						b.approver_2_status,
   						b.approver_2_approved_on,
   						b.approver_2_remarks,
   						v_username as approver_1_username,
   						b.approver_2_username
            from wtms_tier_approval_management b where b.fk_tier_id = tier_id and b.id = v_id;
            SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
            
            if ROW_COUNT() > 0 then
               set v_errcode = 0;
               set v_errmsg = 'success - level 1 updated';
               LEAVE sp_exit;
            end if;
         end if;
   
   			
         if v_approver_1_status = 'Approved' and (v_approver_2_status is null or v_approver_2_status = 'Rejected' or v_approver_2_status = 'Approved' or v_approver_2_status = '') then
   			
            SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
            insert into wtms_tier_approval_management(fk_tier_id,approver_1_userid,approver_1_user_group_name,approver_1_status,approver_1_approved_on,
   				approver_1_remarks,approver_2_userid,approver_2_user_group_name,approver_2_status,approver_2_approved_on,approver_2_remarks,approver_1_username,approver_2_username)
            select  fk_tier_id,
   						c.approver_1_userid,
   						c.approver_1_user_group_name,
   						c.approver_1_status,
   						c.approver_1_approved_on,
   						c.approver_1_remarks,
   						user_id as approver_2_userid,
   						v_user_group_name as approver_2_user_group_name,
   						approver_status as approver_2_status,
   						v_now as approver_2_approved_on,
   						approver_remarks as approver_2_remarks,
   						c.approver_1_username,
   						v_username as approver_2_username
            from wtms_tier_approval_management c  where c.fk_tier_id = tier_id and c.id = v_id;
        
            SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
            if ROW_COUNT() > 0 then
               set v_errcode = 0;
               set v_errmsg = 'success - level 2 updated';
            end if;
         end if;
         
         select   approver_1_status, approver_2_status INTO v_approver_1_status,v_approver_2_status from wtms_tier_approval_management where fk_tier_id = tier_id   order by id desc LIMIT 1;
         
         if v_approver_1_status = 'Approved' and v_approver_2_status = 'Approved' then
   			
   				
            update wtms_tier_management m set m.is_review = 3 where m.tier_id = tier_id;
 				
            update wtms_copy_of_tier_management_temp m set m.is_review = 3 where m.fk_tier_id = tier_id;
   
   				
            update wtms_tier_management_log r set r.is_review = 5 where r.tier_id = tier_id and r.id = v_logid;
            
            if ROW_COUNT() > 0 then
               CALL wtms_copy_of_approval_details_info(tier_id);
               set v_errcode = 0;
               set v_errmsg = 'updated';
               LEAVE sp_exit;
            end if;
         end if;
      END;
      select v_errcode as errcode, v_errmsg as errmsg;
   
   
   End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_UpdateTierCustomStatus` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_UpdateTierCustomStatus`(
p_tier_id int,
p_Custom_status int
)
Begin
	declare v_errcode int;
    declare v_errmsg varchar(30);

	update wtms.wtms_tier_management set Custom_status = p_Custom_status where tier_id = p_tier_id;

	update wtms.wtms_copy_of_tier_management_temp set Custom_status = p_Custom_status where fk_tier_id = p_tier_id;

	set v_errcode = 0;
    set v_errmsg = 'Success';
    
    select v_errcode as errcode , v_errmsg as errmsg;

End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_user_signin_signup` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbteam`@`%` PROCEDURE `worktual_user_signin_signup`(
email VARCHAR(250),  
firstname VARCHAR(150),  
lastname VARCHAR(150),  
password VARCHAR(50),  
last_updatedby VARCHAR(250),  
deviceid VARCHAR(100),  
ip_address VARCHAR(20))
Begin
  
  
   DECLARE v_errcode INT;   
   DECLARE v_errmsg VARCHAR(250);  
   DECLARE v_now DATETIME(3);    
  
   sp_exit:BEGIN
   
      set v_now = CURRENT_TIMESTAMP;
      
      if not exists(select  1 from worktual_user_dtl a where a.email = email LIMIT 1) 
      then
 
         set v_errcode = -1;
         set v_errmsg = 'This email address not found';
         LEAVE sp_exit;
      end if;
      
      if exists(select  1 from worktual_user_dtl a where a.email = email LIMIT 1) 
      then
 
         update worktual_user_dtl a set a.firstname = firstname,a.lastname = lastname,a.password = password,a.last_update = v_now,
         a.last_updatedby = IFNULL(last_updatedby,a.last_updatedby),a.deviceid = IFNULL(deviceid,a.deviceid),
         a.ip_address = IFNULL(ip_address,a.ip_address)
         where a.email = email;
         
         if ROW_COUNT() > 0 
         then
  
            set v_errcode = 0;
            set v_errmsg = 'Success';
            LEAVE sp_exit;
         end if;
         
      end if;
      
   END sp_exit;
   
   select v_errcode as errcode,v_errmsg as errmsg;  
  
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_user_signup_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_user_signup_dtl`(
email VARCHAR(250),
created_by VARCHAR(250),
last_updatedby VARCHAR(250),
deviceid VARCHAR(100),
ip_address VARCHAR(20)
)
begin

	
	
		
   DECLARE pin VARCHAR(10);
   DECLARE now DATETIME(3);
   DECLARE errcode INT; 
   DECLARE errmsg VARCHAR(250);
   DECLARE output VARCHAR(50);
   DECLARE domain_id INT;

   DECLARE dp_password VARCHAR(15);  
   declare sip_password varchar(20);
		                   
		 
   sp_exit:
   BEGIN

      select a.domain_id INTO domain_id from ref_worktual_dir_domain a;
      
	  set errcode = -1;
      set errmsg = '';

      if exists(select * from worktual_user_dtl a where a.email = email and a.password is not null LIMIT 1) then
		
         set errcode = -1;
         set errmsg = 'This email address has already been used';
         LEAVE sp_exit;
      end if;

      if exists(select * from UR_ECom_User_Extension_Dtl a where a.Email = email LIMIT 1) then
		
         set errcode = -1;
         set errmsg = 'This email address has already been used';
         LEAVE sp_exit;
      end if;

      if exists(select * from vbcp_company a where a.email = email LIMIT 1) then
		
         set errcode = -1;
         set errmsg = 'This email address has already been used';
         LEAVE sp_exit;
      end if;

      if exists(select * from UR_ECom_User_Dtl a where a.UR_ECom_Email = email LIMIT 1) then
		
         set errcode = -1;
         set errmsg = 'This email address has already been used';
         LEAVE sp_exit;
      end if;

      SET pin = right(FORMAT(RAND(),6),4);
      set now = CURRENT_TIMESTAMP;

      if not exists(select * from worktual_user_dtl a where a.email = email LIMIT 1) then

		select SUBSTRING(MD5(RAND()) FROM 1 FOR 15) into dp_password;

		CALL usp_generate_password(8,sip_password);

		insert into worktual_user_dtl(email,pin,create_date,last_update,expiry_time,created_by,last_updatedby,deviceid,ip_address,sip_password,dp_password,domain_id)
		values(email,pin,now,now,5,created_by,last_updatedby,deviceid,ip_address,sip_password,dp_password,domain_id);
			
		if ROW_COUNT() > 0 then
			
			set errcode = 0;
			set errmsg = 'success to generate pin';
		end if;
      else

         update worktual_user_dtl a set a.pin = pin,a.last_update = now,a.last_updatedby = IFNULL(last_updatedby,a.last_updatedby),
         a.deviceid = IFNULL(deviceid,a.deviceid),a.ip_address = IFNULL(ip_address,a.ip_address)
         where a.email = email;

         if ROW_COUNT() > 0 then
			
            set errcode = 0;
            set errmsg = 'success to generate pin';
         end if;
      end if;
   END;
   select errcode as errcode,errmsg as errmsg, IFNULL(pin,0) as pin;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_user_signup_validation` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_user_signup_validation`(email VARCHAR(250),
pin VARCHAR(10))
begin


	
	

   DECLARE v_errcode INT;
   DECLARE v_errmsg VARCHAR(100);
   DECLARE v_now DATETIME(3);
   DECLARE v_Timediff INT; 
   DECLARE v_expiry_time INT; 
   DECLARE v_create_time DATETIME(3);
   sp_exit:
   BEGIN
      set v_errcode = -1;
      set v_errmsg = 'Failure';
      set v_now = CURRENT_TIMESTAMP;
      If not exists(select  * from worktual_user_dtl a where a.email = email LIMIT 1) 
      then
         set v_errcode = -1;
         set v_errmsg = 'No records found';
         LEAVE sp_exit;
      end if;
      if exists(select  * from worktual_user_dtl b where b.email = email LIMIT 1)
      then
	
         If not exists(select  * from worktual_user_dtl e where e.email = email and e.pin = pin LIMIT 1)
         then
            set v_errcode = -1;
            set v_errmsg = 'Invalid otp';
            LEAVE sp_exit;
         end if;
      end if;
      select   expiry_time, last_update INTO v_expiry_time,v_create_time from worktual_user_dtl r where r.email = email and r.pin = pin    LIMIT 1;
      set v_Timediff = TIMESTAMPDIFF(MINUTE,v_create_time,CURRENT_TIMESTAMP);
      if v_expiry_time > v_Timediff then
	
         set v_errcode = 0;
         set v_errmsg = 'Active otp';
         LEAVE sp_exit;
      Else
         set v_errcode = -1;
         set v_errmsg = 'otp Expired';
         LEAVE sp_exit;
      end if;
   END;
   select v_errcode as errcode,v_errmsg as errmsg;


End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_Validate_login_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_Validate_login_info`(
Username VARCHAR(50),
Password VARCHAR(50),
Last_login_Ip VARCHAR(250)
)
BEGIN


	
	
   DECLARE errcode INT;
   DECLARE errmsg VARCHAR(250);
   DECLARE role_id INT; 
   DECLARE User_ID INT;
   DECLARE group_id INT;
   DECLARE user_group_id INT;

   sp_exit:
   BEGIN
      set errcode = -1;
      set errmsg = 'User details not found';
	
	
      IF NOT EXISTS(SELECT * FROM wtms_user_master_dtl a WHERE a.username = Username LIMIT 1) then
	
         SET errcode = -1;
         SET errmsg = 'User details not found!';
         LEAVE sp_exit;
      end if;
	
	
      IF EXISTS(SELECT * FROM wtms_user_master_dtl a WHERE a.username = Username and a.status <> 1 LIMIT 1) then
	
         SET errcode = -1;
         SET errmsg = 'User is not acive.Please contact Administrator!';
         LEAVE sp_exit;
      end if;

      IF EXISTS(SELECT * FROM  wtms_user_master_dtl a join worktual_roles_master_dtl b on a.user_role = b.role_id 
	  and b.role_status = 1 WHERE a.username = Username and a.password = Password LIMIT 1) then
		
         SET errcode = 0;
         SET errmsg = 'User Authenticated!';

		 SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
			 select a.user_group_name INTO user_group_id 
			 from wtms_user_master_dtl a join worktual_groups_master_dtl b on a.user_group = b.group_id 
			 WHERE a.username = Username  and a.password = Password;
		 SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

         UPDATE wtms_user_master_dtl a 
		 SET a.last_login_date = CURRENT_TIMESTAMP,
		 a.last_login_ip = Last_login_Ip
         WHERE a.username = Username and a.Password = Password;

		 SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
			select a.user_role,a.userid,a.user_group into role_id,User_ID,group_id  
			from wtms_user_master_dtl a WHERE a.username = Username and a.Password = Password;
		 SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

         LEAVE sp_exit;
      ELSE
         SET errcode = -1;
         SET errmsg = 'Password is Invalid/Role is inactive!';
         LEAVE sp_exit;
      end if;
   END;

	Select errcode as errcode,errmsg as errmsg,IFNULL(role_id,0) as role_id,IFNULL(User_ID,0) as UserId,IFNULL(group_id,0) as group_id,
	IFNULL(user_group_id,0) as user_group_id;
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_Validate_user_role_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_Validate_user_role_info`(
Userid INT
)
Begin


   DECLARE v_errcode INT;
   DECLARE v_errmsg VARCHAR(250);
   DECLARE v_role_id INT; 

   sp_exit:
   BEGIN
      set v_errcode = -1;
      set v_errmsg = 'User details not found';
      IF Userid = '' or Userid = 0 then
		
         SET v_errcode = -1;
         SET v_errmsg = 'User ID should not be empty or Zero!';
         LEAVE Sp_exit;
      end if;
      
      IF NOT EXISTS(SELECT  * FROM wtms_user_master_dtl d WHERE d.userid = Userid LIMIT 1) 
      then
         SET v_errcode = -1;
         SET v_errmsg = 'User details not found!';
         LEAVE sp_exit;
      end if;
      
      IF EXISTS(SELECT  * FROM wtms_user_master_dtl e WHERE e.userid = Userid and e.status = 0 LIMIT 1) 
      then
         SET v_errcode = -1;
         SET v_errmsg = 'User status is inactive!';
         LEAVE sp_exit;
      end if;
      
      
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select   f.user_role INTO v_role_id FROM wtms_user_master_dtl f WHERE f.userid = Userid and f.status = 1;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
      
      
      If Exists(select  *  from worktual_roles_master_dtl  g where g.role_id = v_role_id and g.role_status = 0 LIMIT 1)
      then
         SET v_errcode = -1;
         SET v_errmsg = 'User role status is inactive!';
         LEAVE sp_exit;
      end if;
      
      IF Exists(SELECT  * FROM wtms_user_master_dtl a  JOIN worktual_roles_master_dtl b ON a.user_role = b.role_id
      WHERE a.userid = Userid and a.status = 1 and b.role_status = 1 LIMIT 1) 
      then
         SET v_errcode = 0;
         SET v_errmsg = 'Success Active user and role found!';
         LEAVE sp_exit;
      end if;
      
   END;
   select v_errcode as errcode, v_errmsg as errmsg;

End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Worktual_wtms_bulkupload_web_rates_country_prefix_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `Worktual_wtms_bulkupload_web_rates_country_prefix_info`(
 callingtype varchar(200),
 upload_rate_xml longtext ,
 created_by varchar(200)
 )
begin
 
 
 
 declare country varchar(250);
 declare prefix varchar(20) ;
 declare rate   varchar(150) ;
 declare Type varchar(250);
 
 declare errcode int;
 declare errmsg varchar(225);
 
 
  sp_exit:
         BEGIN
         
         
          DROP TEMPORARY TABLE IF EXISTS tt_bulk_upload_rate;
            create TEMPORARY table tt_bulk_upload_rate
            (
               id INT AUTO_INCREMENT PRIMARY KEY ,
               country  varchar(250),
               prefix varchar(20),
               rate varchar(150) ,
               Type varchar(250)
            )  AUTO_INCREMENT=1;
         
         	drop temporary table if exists xml_country_tbl; create temporary table xml_country_tbl(id int auto_increment primary key,country varchar(250));
   			drop temporary table if exists xml_prefix_tbl; create temporary table xml_prefix_tbl(id int auto_increment primary key,prefix varchar(20) );
   			drop temporary table if exists xml_rate_tbl; create temporary table xml_rate_tbl(id int auto_increment primary key,rate varchar(150) );
   			drop temporary table if exists xml_Type_tbl; create temporary table xml_Type_tbl(id int auto_increment primary key,Type varchar(250));
             
             
                SELECT replace(ExtractValue(upload_rate_xml, '//country[1]'),'|',','), 
                  replace(ExtractValue(upload_rate_xml, '//prefix[1]'),' ',','),
                  replace(ExtractValue(upload_rate_xml, '//rate[1]'),' ',','),
                  replace(ExtractValue(upload_rate_xml, '//Type[1]'),' ',',')
                      into  country, prefix, rate, Type;
                      
             call Split(country,','); insert into xml_country_tbl(country) select Items from tt_Split_temptable;
   			call Split(prefix,','); insert into xml_prefix_tbl(prefix) select Items from tt_Split_temptable;
   			call Split(rate,','); insert into xml_rate_tbl(rate) select Items from tt_Split_temptable;
   			call Split(Type,','); insert into xml_Type_tbl(Type) select Items from tt_Split_temptable;

         
         insert into tt_bulk_upload_rate(country,prefix,rate,Type)
        		select a.country,b.prefix,c.rate,d.Type
        		from xml_country_tbl a 
        		left join xml_prefix_tbl b on a.id = b.id
        		left join xml_rate_tbl c on a.id=c.id
   			left join xml_Type_tbl d on a.id=d.id;

             if exists (select a.country,a.prefix,a.Type,count(1) from tt_bulk_upload_rate a 
             group by a.Country,a.Prefix,a.Type 
           having count(1)>1  limit 1)
           then
           set errcode=-1;
           set errmsg='Same county+Prefix+Type was duplicated.Please check uploaded excel sheet';
           end if;
 
        DELETE FROM UTMS_WEB_RATE_CONFIG a WHERE a.calling_type=callingtype;
 
 
      INSERT INTO UTMS_WEB_RATE_CONFIG(calling_type,country,prefix,rate,Type,
    create_date,create_by,filename)
    select callingtype,a.country,a.prefix,a.rate,a.Type,now(3),created_by,null
    from tt_bulk_upload_rate a ;
    
    if row_count()>0
    then
    set errcode=0;
    set errmsg='Success to upload tariff rates';
    
    end if;
    
    END sp_exit ; 
    
     select errcode as errcode,errmsg as errmsg;
    
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Worktual_wtms_get_tariff_rate_download` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `Worktual_wtms_get_tariff_rate_download`(
  trffclass VARCHAR(4),
  accesscharge INT
)
begin

call UTMS.utms_get_tariff_rate_download(trffclass,accesscharge);

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Worktual_wtms_get_uploaded_tariff_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `Worktual_wtms_get_uploaded_tariff_details`()
begin

call UTMS.utms_get_uploaded_tariff_details();

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Worktual_wtms_get_web_rates_country_prefix_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `Worktual_wtms_get_web_rates_country_prefix_info`(callingtype VARCHAR(100),
  type VARCHAR(250),
  country VARCHAR(150))
BEGIN
  
  
  	
  	
     SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
     select id,calling_type,country,CONCAT(prefix,'|',cast(rate as CHAR(30))) as prefix
     from UTMS.UTMS_WEB_RATE_CONFIG a
     where a.calling_type = callingtype
     and a.country = country
     and a.Type = type;
     SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
  	
  
  
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Worktual_wtms_update_web_rates_country_prefix_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `Worktual_wtms_update_web_rates_country_prefix_info`(
 prefix_id int,
 prefix varchar(25),
 rate float
 )
begin
 
 declare errcode int;
 declare errmsg varchar(55);
 set errcode=-1;
 set errmsg='failure to update';
 
 sp_exit:begin
 
 if exists (select * from UTMS.UTMS_WEB_RATE_CONFIG a where a.id=prefix_id )
 then
 update UTMS.UTMS_WEB_RATE_CONFIG a set a.prefix=prefix , a.rate=cast(rate as char)
 where a.id=prefix_id ;
 end if;
 
 if row_count()>0
 then
 set errcode=0;
 set errmsg='updated success fully';
 leave sp_exit;
 end if;
 
 
 
 
 end sp_exit;
 
 select errcode,errmsg;
 
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Worktual_wtms_uplaod_esp_tariff_rates` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `Worktual_wtms_uplaod_esp_tariff_rates`(
login	VARCHAR(32),
   tariffclass	VARCHAR(4),
   access_type INT,
   effectivedate	DATETIME(3),
   filename VARCHAR(250),
   tempfilename VARCHAR(250),
   upload_type INT 
)
begin

call UTMS.utms_uplaod_esp_tariff_rates (login,tariffclass,access_type,effectivedate,filename,tempfilename,upload_type);


end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wtms_copy_of_approval_details_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wtms_copy_of_approval_details_info`(tier_id INT)
Begin
    
    
 		DECLARE v_now DATETIME(3);
 		DECLARE v_create_by VARCHAR(10) DEFAULT 'copyof';
 		declare v_new_plan_price INT;
 		declare v_apply_new_exist_cust INT;
        declare v_status int;
    
       set v_now = CURRENT_TIMESTAMP;
       
       select  c.status into v_status from wtms.wtms_tier_management c where c.tier_id = tier_id;
       
   		update wtms_copy_of_tier_management_temp m set m.is_review = 3,m.status = v_status where m.fk_tier_id = tier_id;
         
         select a.apply_new_exist_cust into v_apply_new_exist_cust from wtms.wtms_copy_of_tier_management_temp a where a.fk_tier_id = tier_id;
    	
    	
       if exists(select  * from wtms_tier_sub_product_master_MT a where a.fk_tier_id = tier_id LIMIT 1) then
    	
          delete from wtms_tier_sub_product_master_MT b where b.fk_tier_id = tier_id;
          insert into wtms_tier_sub_product_master_MT(fk_tier_id,fk_tier_type,fk_prod_id,fk_sub_prod_id,create_date)
          select c.fk_tier_id,c.fk_tier_type,c.fk_prod_id,c.fk_sub_prod_id ,v_now
          from wtms_tier_sub_product_master c where c.fk_tier_id = tier_id;
       end if;
    
       if exists(select  * from wtms_contract_pricing_dtl_MT d where d.tier_id = tier_id LIMIT 1) then
    	
          delete from wtms_contract_pricing_dtl_MT r where r.tier_id = tier_id;
          insert into wtms_contract_pricing_dtl_MT(tier_id,fk_user_type_id,fk_contract_period_id,price1,discount1,price2,discount2,min_user,create_by,create_date,price3,months1,months2)
          select Distinct f.tier_id,f.fk_user_type_id,f.fk_contract_period_id,f.price1,f.discount1,f.price2,f.discount2,f.min_user,
          v_create_by,v_now,f.price3,f.months1,f.months2
          from wtms_contract_pricing_dtl f where f.tier_id = tier_id;
       end if;
    
       if exists(select  * from wtms_tier_summary_map_MT e where e.fk_tier_id = tier_id LIMIT 1) then
    	
          delete from wtms_tier_summary_map_MT r where r.fk_tier_id = tier_id;
          insert into wtms_tier_summary_map_MT(fk_tier_id,tiertype,bundle_id,product_id,sub_product_id,summary_id)
          select Distinct n.fk_tier_id,n.tiertype,n.bundle_id,n.product_id,n.sub_product_id,n.summary_id
          from wtms_tier_summary_map n where n.fk_tier_id = tier_id;
       end if;
    
       if exists(select  * from wtms_tier_category_position_MT e where e.fk_tier_id = tier_id LIMIT 1)
       then
    	
          delete from wtms_tier_category_position_MT where fk_tier_id = tier_id;
          insert into wtms_tier_category_position_MT(fk_tier_id,catg_id,catg_pos)
          select Distinct r.fk_tier_id,r.catg_id,r.catg_pos
          from wtms_tier_category_position r where r.fk_tier_id = tier_id;
       end if;
    
       if exists(select  * from wtms_tier_catg_feature_mapping_info_MT e where e.tier_id = tier_id LIMIT 1) then
    	
          delete from wtms_tier_catg_feature_mapping_info_MT e where e.tier_id = tier_id;
          insert into wtms_tier_catg_feature_mapping_info_MT(tier_id,tiertype,product_id,sub_product_id,categoryid,featureid)
          select Distinct w.tier_id,w.tiertype,w.product_id,w.sub_product_id,w.categoryid,w.featureid
          from wtms_tier_catg_feature_mapping_info w where w.tier_id = tier_id;
       end if;
    
    
       if exists(select * from wtms_tier_feature_mapping_xml_MT e where e.tier_id = tier_id LIMIT 1) then
    		
          delete from wtms_tier_feature_mapping_xml_MT t where t.tier_id = tier_id;
          insert into wtms_tier_feature_mapping_xml_MT(tier_id,tiertype,bundle_id,product_id,sub_product_id,categoryid,featureid,value1,value2,value3,value4,value5,
    			value6,value7,value8,value9,value10)
          select Distinct v.tier_id,v.tiertype,v.bundle_id,v.product_id,v.sub_product_id,v.categoryid,v.featureid,v.value1,v.value2,
          v.value3,v.value4,v.value5,
    			v.value6,v.value7,v.value8,v.value9,v.value10
          from wtms_tier_feature_mapping_xml v where v.tier_id = tier_id;
       end if;
       
 		if v_apply_new_exist_cust <> 1 then
 		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
         
 		select b.price1 INTO v_new_plan_price from wtms.wtms_copy_of_tier_management_temp a WHERE a.fk_tier_id = tier_id;
 
 		insert into unifiedring.ur_company_plan_change_log (cp_id,company_id,product_id,plan_id,plan_duration,account_credit,next_bill_date,status,createdate,total_plan_user,total_plan_user_purchase,plan_price,
 				last_bill_date,plan_ord_user_range,plan_start_date,plan_end_date,bill_cycle,calling_credit,threshold_limit,due_date,Is_free_trail,credit_add_by,
 				auto_topup_flag,auto_topup_amount,Is_FT_to_paid,FT_paid_convert_date,suspend_date,contract_end_date,addon_bundle_id,addon_bun_pur_date,addon_bun_price,
 				addon_cancel_Date,Payment_attempt_cnt,Payment_reattempt_Date,Is_block_Incomming,Is_block_outgoing,partially_suspend_date,contract_start_date,
 				contract_canceled_date,low_balance_flag,is_video_transcript_addon_purid,is_video_transcript,Is_video_realtime_translation,Is_video_recorded_translation,
 				Is_video_recorded_translation_addon_purid,is_audio_transcript_addon_purid,Is_audio_realtime_translation,Is_audio_realtime_trans_addon_purid,
 				Is_audio_recorded_translation,Is_audio_recorded_translation_addon_purid,audio_call_transcript_ondemand,audio_call_transcript_automatic,Is_email_transcript,
 				Is_voicemail_transcript_app,Is_closed_caption)
 		select a.cp_id,a.company_id,a.product_id,a.plan_id,a.plan_duration,a.account_credit,a.next_bill_date,a.status,a.createdate,a.total_plan_user,a.total_plan_user_purchase,a.plan_price,a.
 				last_bill_date,a.plan_ord_user_range,a.plan_start_date,a.plan_end_date,a.bill_cycle,a.calling_credit,a.threshold_limit,a.due_date,a.Is_free_trail,a.credit_add_by,a.
 				auto_topup_flag,a.auto_topup_amount,a.Is_FT_to_paid,a.FT_paid_convert_date,a.suspend_date,a.contract_end_date,a.addon_bundle_id,a.addon_bun_pur_date,a.addon_bun_price,a.
 				addon_cancel_Date,a.Payment_attempt_cnt,a.Payment_reattempt_Date,a.Is_block_Incomming,a.Is_block_outgoing,a.partially_suspend_date,a.contract_start_date,a.
 				contract_canceled_date,a.low_balance_flag,a.is_video_transcript_addon_purid,a.is_video_transcript,a.Is_video_realtime_translation,a.Is_video_recorded_translation,a.
 				Is_video_recorded_translation_addon_purid,a.is_audio_transcript_addon_purid,a.Is_audio_realtime_translation,a.Is_audio_realtime_trans_addon_purid,a.
 				Is_audio_recorded_translation,a.Is_audio_recorded_translation_addon_purid,a.audio_call_transcript_ondemand,a.audio_call_transcript_automatic,a.Is_email_transcript,a.
 				Is_voicemail_transcript_app,a.Is_closed_caption
 		from unifiedring.ur_company_plan where a.plan_id = tier_id; 
 
 		update unifiedring.ur_company_plan a set a.plan_price = ifnull(v_new_plan_price,0) where a.plan_id = tier_id; 
 		 
 		SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 		End if;
    
    
    End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wtms_create_country_list` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wtms_create_country_list`(
country_id INT,
country_name VARCHAR(250),
status INT,
process_type INT 
)
Begin

   DECLARE errcode INT;
   DECLARE errmsg VARCHAR(150);


   IF country_id is null then
      set country_id = 0;
   END IF;
   
   sp_exit:
   BEGIN

      if process_type = 1 then
	
         if exists(select * from wtms_country_list a where a.country_name = country_name limit 1) then
            set errcode = -1;
            set errmsg = 'Country name already exists';
            LEAVE sp_exit;
         end if;
         
         insert into wtms_country_list(country_name,status)
		values(country_name,status);
			
         set country_id = LAST_INSERT_ID();
         
         if ROW_COUNT() > 0 then	
            set errcode = 0;
            set errmsg = 'Country name created';
            LEAVE sp_exit;
         end if;
      end if;
      
      if process_type = 2 then
	
         if exists(select * from wtms_country_list a where a.country_name = country_name and a.id <> country_id  limit 1) then
            set errcode = -1;
            set errmsg = 'Country name already exists';
            LEAVE sp_exit;
         end if;
         
         if not exists(select * from wtms_country_list a where a.id = country_id limit 1) then
            set errcode = -1;
            set errmsg = 'Country id not exists';
            LEAVE sp_exit;
         end if;
         
         UPDATE wtms_country_list a
         set a.country_name = country_name,a.status = status
         where a.id = country_id;
         
         if ROW_COUNT() > 0 then
			
            set errcode = 0;
            set errmsg = 'Country name updated';
            LEAVE sp_exit;
         end if;
      end if;
      if process_type = 3 then
	
         if not exists(select * from wtms_country_list a where a.id = country_id  limit 1) then
		
            set errcode = -1;
            set errmsg = 'Country id not exists';
            LEAVE sp_exit;
         end if;
         
         UPDATE wtms_country_list a set a.status = 3 where a.id = country_id;
         
         if ROW_COUNT() > 0 then		
            set errcode = 0;
            set errmsg = 'Country deleted';
            LEAVE sp_exit;
         end if;
      end if;
   END;
   
	select errcode as errcode, errmsg as errmsg, country_id as country_id;

End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wtms_create_module_list` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wtms_create_module_list`(module_id INT,
module_name VARCHAR(250),
status INT,
process_type INT 
)
Begin


   DECLARE errcode INT;
   DECLARE errmsg VARCHAR(150);


   IF module_id is null then
      set module_id = 0;
   END IF;
   sp_exit:
   BEGIN
      IF module_id is null then
         set module_id = 0;
      END IF;
      if process_type = 1 then
	
         if exists(select * from wtms_module_info a where a.module_name = module_name) then
		
            set errcode = -1;
            set errmsg = 'module name already exists';
            LEAVE sp_exit;
         end if;
         insert into wtms_module_info(module_name,status)
			values(module_name,status);
			
         set module_id = LAST_INSERT_ID();
         if ROW_COUNT() > 0 then
			
            set errcode = 0;
            set errmsg = 'module name created';
            LEAVE sp_exit;
         end if;
      end if;
      if process_type = 2 then
	
         if exists(select * from wtms_module_info a where a.module_name = module_name and a.mod_id <> module_id) then
		
            set errcode = -1;
            set errmsg = 'module name already exists';
            LEAVE sp_exit;
         end if;
         if not exists(select * from wtms_module_info a where a.mod_id = module_id) then
		
            set errcode = -1;
            set errmsg = 'module id not exists';
            LEAVE sp_exit;
         end if;
         UPDATE wtms_module_info a
         set a.module_name = module_name,a.status = status
         where a.mod_id = module_id;
         if ROW_COUNT() > 0 then
			
            set errcode = 0;
            set errmsg = 'module name updated';
            LEAVE sp_exit;
         end if;
      end if;
      if process_type = 3 then
	
         if not exists(select * from wtms_module_info a where a.mod_id = module_id) then
		
            set errcode = -1;
            set errmsg = 'module id not exists';
            LEAVE sp_exit;
         end if;
         UPDATE wtms_module_info a set a.status = 3 where a.mod_id = module_id;
         if ROW_COUNT() > 0 then
		
            set errcode = 0;
            set errmsg = 'module deleted';
            LEAVE sp_exit;
         end if;
      end if;
   END;
   select errcode as errcode, errmsg as errmsg, module_id as module_id;

End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wtms_create_sub_module_list` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wtms_create_sub_module_list`(
 module_id INT,
 sub_module_id INT , 
 sub_module_name VARCHAR(250),
 status INT,
 sub_module_name_url VARCHAR(250), 
 process_type INT 
 )
Begin
 
    DECLARE errcode INT;
    DECLARE errmsg VARCHAR(150);
 
    IF sub_module_id is null 
    then
       set sub_module_id = 0;
    END IF;
    
    sp_exit:BEGIN
 
       if not exists(select * from wtms_module_info a where a.mod_id = module_id) 
       then
 	
          set errcode = -1;
          set errmsg = 'module id not exists';
          LEAVE sp_exit;
       end if;
       
       if process_type = 1 
       then
 	
          if exists(select * from wtms_sub_module_info a where a.sub_module_name = sub_module_name and a.fk_mod_id = module_id) then
 		
             set errcode = -1;
             set errmsg = 'sub module name already exists';
             LEAVE sp_exit;
          end if;
          
          insert into wtms_sub_module_info(fk_mod_id,sub_module_name,status,sub_module_name_url)
		  values(module_id,sub_module_name,status,sub_module_name_url);
 			
          set sub_module_id = LAST_INSERT_ID();
          
          if ROW_COUNT() > 0 
          then
 			
             set errcode = 0;
             set errmsg = 'sub module name created';
             LEAVE sp_exit;
          end if;
          
       end if;
       
       if process_type = 2 
       then
 	
          if exists(select * from wtms_sub_module_info a where a.sub_module_name = sub_module_name and a.sub_mod_id <> sub_module_id and a.fk_mod_id = module_id) 
          then
 		
             set errcode = -1;
             set errmsg = 'sub module name already exists';
             LEAVE sp_exit;
          end if;
          
          if not exists(select * from wtms_sub_module_info a where a.sub_mod_id = sub_module_id) 
          then
 		
             set errcode = -1;
             set errmsg = 'sub module id not exists';
             LEAVE sp_exit;
          end if;
          
          UPDATE wtms_sub_module_info a
          set a.fk_mod_id = module_id,a.sub_module_name = sub_module_name,a.status = status,a.sub_module_name_url = sub_module_name_url
          where a.sub_mod_id = sub_module_id;
          
          if ROW_COUNT() > 0 
          then
 			
             set errcode = 0;
             set errmsg = 'sub module name updated';
             LEAVE sp_exit;
          end if;
          
       end if;
       
       if process_type = 3 
       then
 	
          if not exists(select * from wtms_sub_module_info a where a.sub_mod_id = sub_module_id) 
          then
 		
             set errcode = -1;
             set errmsg = 'sub module id not exists';
             LEAVE sp_exit;
          end if;
          
          UPDATE wtms_sub_module_info a set a.status = 3,a.sub_module_name_url = sub_module_name_url
          where a.sub_mod_id = sub_module_id;
          
          if ROW_COUNT() > 0 
          then
 		
             set errcode = 0;
             set errmsg = 'sub module deleted';
             LEAVE sp_exit;
          end if;
          
       end if;
       
    END sp_exit;
    
    select errcode as errcode, errmsg as errmsg, sub_module_id as sub_module_id;
 
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wtms_get_country_list` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wtms_get_country_list`(country_id INT)
Begin

   IF country_id is null then
      set country_id = 0;
   END IF;
   select id,country_name,status from wtms_country_list a where (a.id = country_id or IFNULL(country_id,0) = 0) and status = 1;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wtms_get_module_list` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wtms_get_module_list`(module_id INT)
Begin


   IF module_id is null then
      set module_id = 0;
   END IF;
   
   select a.mod_id,a.module_name,a.status from wtms_module_info a where (a.mod_id = module_id or IFNULL(module_id,0) = 0) and status = 1;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wtms_get_module_submod_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wtms_get_module_submod_details`(
module_id longtext)
begin         
        		
   	drop temporary table if exists tt_contact_list;
   	create temporary table tt_contact_list
   	(
   		id int auto_increment primary key,
   		module_id longtext 
   	);
     
     call split(module_id,',');
     
     insert into tt_contact_list(module_id)
     select items from tt_Split_temptable;
     
   			select c.mod_id,c.module_name,d.sub_mod_id,d.sub_module_name
   			from wtms_module_info c join wtms_sub_module_info d on c.mod_id = d.fk_mod_id             
   			where c.mod_id in (select Distinct a.module_id from tt_contact_list a)
			and c.mod_id = module_id and c.status = 1 and d.status = 1; 
  
   end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wtms_get_sub_module_list` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wtms_get_sub_module_list`(
sub_module_id INT)
Begin
  
     IF sub_module_id is null 
     then
        set sub_module_id = 0;
     END IF;
     
     select a.sub_mod_id,a.fk_mod_id,a.sub_module_name,a.status,a.sub_module_name_url,b.module_name
     from wtms_sub_module_info a join wtms_module_info b on a.fk_mod_id = b.mod_id
     where (a.sub_mod_id = sub_module_id or IFNULL(sub_module_id,0) = 0) and a.status = 1;
     
  End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wtms_get_tier_summary_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wtms_get_tier_summary_info`(
 tier_id int
 )
Begin
 	select tier_id,getsummarylist(tier_id,1) as tier_summary_list;
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wtms_get_user_approval_list` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wtms_get_user_approval_list`(
userid INT
)
Begin

   DECLARE user_group_name INT;
   DECLARE firstname VARCHAR(100);
   DECLARE lastname VARCHAR(100);
   DECLARE username VARCHAR(100);

   select a.user_group_name, a.firstname, a.lastname, a.username INTO user_group_name,firstname,lastname,username 
   from wtms_user_master_dtl a where a.userid = userid;

	select userid as userid,firstname as firstname,lastname as lastname,username as username,
	a.user_group_name,a.approve_1,a.approve_2,a.create_date,a.status 
	from wtms_user_group_hdr a
	where a.user_group_id = user_group_name;


End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Wtms_get_web_rates_country_summary_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `Wtms_get_web_rates_country_summary_info`(callingtype VARCHAR(100))
BEGIN
   
   	
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select a.calling_type,a.Type,a.country,count(distinct prefix)  as prefix_count
      from WTMS_WEB_RATE_CONFIG a
      WHERE a.calling_type = callingtype
      group  by a.calling_type,a.Type,a.country
      order by country asc;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   
   END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `WTMS_portal_do_run_tariff_upload_file` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `WTMS_portal_do_run_tariff_upload_file`(
sitecode	varchar(3),
idx int
)
begin
	declare link_server varchar(250);
	declare spname varchar(250);
	
	select a.linked_server into link_server from crm3.crm3_linked_server a
	where a.sitecode=sitecode and db_type='ESPDB' limit 1;
	
	set link_server=replace(link_server,'.esp','.espmgt');
	
	
	IF link_server is not null
	then
	
		call espmgt.BMS_portal_do_run_traiff_request(sitecode,idx);
		
	end if;
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `WTMS_portal_do_upload_multiple_tariff_request` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `WTMS_portal_do_upload_multiple_tariff_request`(
login	varchar(32),
sitecode	varchar(3),
cardID	int,
tariffclass	varchar(255),
timeperiod	int,
effectivedate	datetime,
accesscharge int,
filetariff varchar(250),
temptariff varchar(250)
)
BEGIN

	declare link_server varchar(250);
	declare spname varchar(250);
	
	
	
	
    CALL esp.BMS_portal_upload_multiple_tariff_request (login	,
sitecode	,
cardID	,
tariffclass	,
timeperiod	,
effectivedate	,
accesscharge ,
filetariff ,
temptariff );
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `WTMS_portal_get_upload_request_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `WTMS_portal_get_upload_request_details`(
sitecode varchar(3)
)
BEGIN
	
call esp.BMS_portal_get_upload_request_details (sitecode);
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wtms_tariff_get_tariff_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wtms_tariff_get_tariff_details`(
 id int,  
 planid int)
BEGIN  
   
   if id = '' then set id = 0; end if;   
   if planid = '' then set planid = 0; end if;
  
  
	call unifiedring.wtms_tariff_get_tariff_details (id,planid);
    
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wtms_tier_get_module_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wtms_tier_get_module_details`(
 company_id int,
 tier_id int
)
begin         
 
	declare v_sub_module_id text;
      		
 	drop temporary table if exists tt_contact_list;
 	create temporary table tt_contact_list
 	(
 		id int auto_increment primary key,
 		sub_module_id varchar(150)                
 	);
    
   
   select a.sub_module_id into v_sub_module_id from wtms_tier_management a where a.tier_id = tier_id limit 1; 
   
   call split(v_sub_module_id,',');
   
   insert into tt_contact_list(sub_module_id)
   select items from tt_Split_temptable;
   
 			select distinct a.company_id,b.tier_id,b.module_id,c.module_name,d.sub_mod_id,d.sub_module_name,d.sub_module_name_URL 
 			from unifiedring.ur_company_plan a 
 			join wtms_tier_management b on a.plan_id = b.tier_id 
 			join wtms_module_info c on b.module_id = c.mod_id 
            join wtms_sub_module_info d on c.mod_id = d.fk_mod_id             
 			where d.sub_mod_id in (select Distinct a.sub_module_id from tt_contact_list a)
            and a.company_id = company_id and  b.tier_id = tier_id; 

 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wtms_tier_get_module_submodule_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wtms_tier_get_module_submodule_details`(
   tier_id int
)
begin         
 
	select a.tier_id,a.module_id,a.sub_module_id from wtms.wtms_tier_management a where a.tier_id = tier_id;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wtms_tier_get_platform_fee_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wtms_tier_get_platform_fee_info`(
p_tier_id int
)
Begin
	select * from wtms_tier_platform_fee_info where tier_id = p_tier_id;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wtms_tier_get_reseller_list` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wtms_tier_get_reseller_list`(
tier_id int
)
begin
	select a.tier_id,ifnull(a.reseller_id,0) as reseller_id from wtms.wtms_tier_management a where a.tier_id = tier_id;

End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-21  9:54:08
