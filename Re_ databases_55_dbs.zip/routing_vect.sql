-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: routing_vect
-- ------------------------------------------------------
-- Server version	8.0.44-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `routing_vect`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `routing_vect` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `routing_vect`;

--
-- Table structure for table `R20_ROUTE08`
--

DROP TABLE IF EXISTS `R20_ROUTE08`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `R20_ROUTE08` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parentId` int DEFAULT NULL,
  `state` int NOT NULL,
  `reason` int DEFAULT NULL,
  `routeCls` int NOT NULL,
  `oprId` int NOT NULL,
  `pc` varchar(2) NOT NULL,
  `prefixCode` varchar(16) NOT NULL,
  `prefixLen` int NOT NULL,
  `destCode` varchar(32) DEFAULT NULL,
  `clsOrg` varchar(2) NOT NULL,
  `cls` varchar(2) NOT NULL,
  `costOrgCurr` varchar(4) NOT NULL,
  `costOrg` float NOT NULL,
  `cost` float NOT NULL,
  `priority` float NOT NULL,
  `access` int NOT NULL,
  `quality` float DEFAULT NULL,
  `rating` int DEFAULT NULL,
  `flag` int NOT NULL,
  `ext` int DEFAULT NULL,
  `lastUpd` datetime(3) NOT NULL,
  `lastUpdBy` varchar(16) NOT NULL,
  `exception` int DEFAULT NULL,
  `exceptionCls` int DEFAULT NULL,
  `lastLock` datetime(3) DEFAULT NULL,
  `lastLockBy` varchar(50) DEFAULT NULL,
  `uploadDate` datetime(3) DEFAULT NULL,
  `uploadBy` varchar(100) DEFAULT NULL,
  `UpdateFlag` smallint DEFAULT NULL,
  `opr_cost` float DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_list` (`routeCls`,`pc`,`prefixCode`),
  KEY `idx1` (`routeCls`,`oprId`,`pc`,`cls`),
  KEY `idx2` (`oprId`,`prefixCode`,`cls`),
  KEY `idx3` (`routeCls`,`oprId`,`pc`,`prefixCode`,`cls`),
  KEY `idx_R20_ROUTE08_routeCls` (`routeCls`),
  KEY `idx_R20_ROUTE08_state` (`state`),
  KEY `idx_R20_ROUTE08_oprId` (`oprId`),
  KEY `idx_R20_ROUTE08_pc` (`pc`),
  KEY `idx_R20_ROUTE08_cls` (`cls`),
  KEY `idx_R20_ROUTE08_prefixcode` (`prefixCode`)
) ENGINE=InnoDB AUTO_INCREMENT=180908484 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `XlatInterDomain`
--

DROP TABLE IF EXISTS `XlatInterDomain`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `XlatInterDomain` (
  `sitecode_in` varchar(4) NOT NULL,
  `switchcode_in` varchar(4) NOT NULL,
  `sitecode_out` varchar(4) NOT NULL,
  `operator_out` varchar(15) NOT NULL,
  `prefix` varchar(20) NOT NULL,
  `xlatpfx` varchar(20) DEFAULT NULL,
  `prefixlen` int DEFAULT NULL,
  `comment` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`sitecode_in`,`switchcode_in`,`sitecode_out`,`operator_out`,`prefix`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `causecode`
--

DROP TABLE IF EXISTS `causecode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `causecode` (
  `domain` varchar(8) NOT NULL,
  `operator` varchar(32) NOT NULL,
  `code` int NOT NULL,
  `name` varchar(32) DEFAULT NULL,
  `next` int DEFAULT NULL,
  `counter` int DEFAULT NULL,
  `duration` int DEFAULT NULL,
  `reserved` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `india_did_route`
--

DROP TABLE IF EXISTS `india_did_route`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `india_did_route` (
  `did` varchar(30) NOT NULL,
  `group` varchar(20) NOT NULL,
  `cost` float DEFAULT NULL,
  PRIMARY KEY (`did`,`group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `inter_xgate_bridge`
--

DROP TABLE IF EXISTS `inter_xgate_bridge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inter_xgate_bridge` (
  `domain_from` varchar(4) NOT NULL,
  `domain_to` varchar(4) NOT NULL,
  `bridge_idx` int NOT NULL,
  `bridge_group` varchar(8) NOT NULL,
  `bridge_domain` varchar(4) NOT NULL,
  `bridge_hint` varchar(30) NOT NULL,
  `comment` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`domain_from`,`domain_to`,`bridge_idx`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `r20_routeCPrice`
--

DROP TABLE IF EXISTS `r20_routeCPrice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `r20_routeCPrice` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `pc` varchar(2) NOT NULL,
  `Prefixcode` varchar(16) NOT NULL,
  `cls` varchar(2) NOT NULL,
  `OprId` int NOT NULL,
  `Cost` float NOT NULL,
  `Custom1` varchar(500) DEFAULT NULL,
  `Custom2` varchar(500) DEFAULT NULL,
  `Custom3` float DEFAULT NULL,
  `Custom4` float DEFAULT NULL,
  `reserved` varchar(250) DEFAULT NULL,
  `Custom5` float DEFAULT NULL,
  `Custom6` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `Idx2` (`pc`,`Prefixcode`,`cls`,`OprId`),
  KEY `IdxForView` (`Prefixcode`,`OprId`),
  KEY `idx3` (`Prefixcode`,`cls`,`OprId`),
  KEY `idx4` (`Prefixcode`,`cls`,`OprId`)
) ENGINE=InnoDB AUTO_INCREMENT=161462016 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `r20_route_timecls`
--

DROP TABLE IF EXISTS `r20_route_timecls`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `r20_route_timecls` (
  `id` int NOT NULL AUTO_INCREMENT,
  `routecls` int NOT NULL,
  `oprId` int NOT NULL,
  `cls` varchar(1) NOT NULL,
  `pc` varchar(2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_r20_route_timecls_routecls` (`routecls`),
  KEY `idx_r20_route_timecls_oprid` (`oprId`),
  KEY `idx_r20_route_timecls_cls` (`cls`),
  KEY `idx_r20_route_timecls_pc` (`pc`),
  KEY `idx_r20_route_timecls_id` (`id`),
  KEY `idx_tc` (`routecls`,`oprId`,`cls`,`pc`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=57887 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `r_daycode`
--

DROP TABLE IF EXISTS `r_daycode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `r_daycode` (
  `id` int NOT NULL AUTO_INCREMENT,
  `d1` int NOT NULL,
  `d2` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_r_daycode_id` (`id`),
  KEY `idx_r_daycode_d1` (`d1`),
  KEY `idx_r_daycode_d2` (`d2`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `r_domain`
--

DROP TABLE IF EXISTS `r_domain`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `r_domain` (
  `state` char(1) NOT NULL,
  `universe` varchar(8) NOT NULL,
  `name` varchar(8) NOT NULL,
  `longname` varchar(32) NOT NULL,
  `userinfo` varchar(128) DEFAULT NULL,
  `timezone` int NOT NULL,
  `reserved` varchar(64) DEFAULT NULL,
  `update_by` varchar(50) DEFAULT NULL,
  `last_update` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`universe`,`name`),
  KEY `idx_r_domain_name` (`name`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `r_info`
--

DROP TABLE IF EXISTS `r_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `r_info` (
  `timezone` int DEFAULT NULL,
  `universe` varchar(8) DEFAULT NULL,
  `domain` varchar(32) DEFAULT NULL,
  `is_emergency` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `r_interface`
--

DROP TABLE IF EXISTS `r_interface`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `r_interface` (
  `id` int NOT NULL AUTO_INCREMENT,
  `state` char(1) NOT NULL,
  `universe` varchar(8) NOT NULL,
  `domain` varchar(8) NOT NULL,
  `pdomain` varchar(8) DEFAULT NULL,
  `name` varchar(32) NOT NULL,
  `group` varchar(16) NOT NULL,
  `hint` varchar(128) DEFAULT NULL,
  `routecls` int NOT NULL,
  `allowloop` int NOT NULL,
  `intcls` int DEFAULT NULL,
  `userinfo` varchar(64) DEFAULT NULL,
  `reserved` varchar(64) DEFAULT NULL,
  `prefixcls` int DEFAULT NULL,
  `type` int DEFAULT NULL,
  `UpdateFlag` smallint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx1` (`reserved`),
  KEY `idx_r_interface_id` (`id`),
  KEY `idx_r_interface_state` (`state`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=8383 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `r_interfaceGroup`
--

DROP TABLE IF EXISTS `r_interfaceGroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `r_interfaceGroup` (
  `tintid` int NOT NULL,
  `IntGroupID` int NOT NULL,
  `flag` int DEFAULT NULL,
  `msrepl_synctran_ts` binary(16) NOT NULL,
  PRIMARY KEY (`tintid`,`IntGroupID`),
  KEY `idx_r_interfaceGroup_tintid` (`tintid`),
  KEY `idx_r_interfaceGroup_IntGroupID` (`IntGroupID`),
  KEY `idx_r_interfaceGroup_flag` (`flag`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `r_operatorset`
--

DROP TABLE IF EXISTS `r_operatorset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `r_operatorset` (
  `operatorset_id` int NOT NULL,
  `oprid` int NOT NULL,
  `state` tinyint unsigned DEFAULT NULL,
  `flag` tinyint unsigned DEFAULT NULL,
  `cost` float DEFAULT NULL,
  `quality` float DEFAULT NULL,
  `rating` int DEFAULT NULL,
  `priority` int NOT NULL,
  `comment` varchar(128) DEFAULT NULL,
  `domain` varchar(8) DEFAULT NULL,
  `group` varchar(16) DEFAULT NULL,
  `interface` varchar(16) DEFAULT NULL,
  `userinfo` varchar(64) DEFAULT NULL,
  `oprtype` int DEFAULT NULL,
  `universe` varchar(8) DEFAULT NULL,
  PRIMARY KEY (`operatorset_id`,`priority`),
  UNIQUE KEY `r_operatorset_idx` (`operatorset_id`,`oprid`,`domain`,`group`,`interface`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `r_prefix2`
--

DROP TABLE IF EXISTS `r_prefix2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `r_prefix2` (
  `state` varchar(1) NOT NULL,
  `pc` varchar(2) NOT NULL,
  `prefixcode` varchar(17) NOT NULL,
  `prefixlen` int NOT NULL,
  `destcode` varchar(32) NOT NULL,
  `prefixreg` varchar(8) DEFAULT NULL,
  `prefixcls` int DEFAULT NULL,
  `reserved` varchar(64) DEFAULT NULL,
  `routecls` int DEFAULT NULL,
  `interfacecls` int DEFAULT NULL,
  `local_mroute` int DEFAULT NULL,
  `local_mcost` float DEFAULT NULL,
  `tollfree_mroute` int DEFAULT NULL,
  `tollfree_mcost` float DEFAULT NULL,
  `mobile_mroute` int DEFAULT NULL,
  `mobile_mcost` float DEFAULT NULL,
  `payphone_mroute` int DEFAULT NULL,
  `payphone_mcost` float DEFAULT NULL,
  `countrycode` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`prefixcode`),
  KEY `idx1` (`pc`,`prefixlen`),
  KEY `idx_r_prefix2_pc` (`pc`),
  KEY `idx_r_prefix2_prefixcode` (`prefixcode`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `r_prefix233`
--

DROP TABLE IF EXISTS `r_prefix233`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `r_prefix233` (
  `state` varchar(1) NOT NULL,
  `pc` varchar(2) NOT NULL,
  `prefixcode` varchar(17) NOT NULL,
  `prefixlen` int NOT NULL,
  `destcode` varchar(32) NOT NULL,
  `prefixreg` varchar(8) DEFAULT NULL,
  `prefixcls` int DEFAULT NULL,
  `reserved` varchar(64) DEFAULT NULL,
  `routecls` int DEFAULT NULL,
  `interfacecls` int DEFAULT NULL,
  `local_mroute` int DEFAULT NULL,
  `local_mcost` float DEFAULT NULL,
  `tollfree_mroute` int DEFAULT NULL,
  `tollfree_mcost` float DEFAULT NULL,
  `mobile_mroute` int DEFAULT NULL,
  `mobile_mcost` float DEFAULT NULL,
  `payphone_mroute` int DEFAULT NULL,
  `payphone_mcost` float DEFAULT NULL,
  `countrycode` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`prefixcode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `r_prefix2_new`
--

DROP TABLE IF EXISTS `r_prefix2_new`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `r_prefix2_new` (
  `state` varchar(1) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `pc` varchar(2) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `prefixcode` varchar(17) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `prefixlen` int NOT NULL,
  `destcode` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `prefixreg` varchar(8) DEFAULT NULL,
  `prefixcls` int DEFAULT NULL,
  `reserved` varchar(64) DEFAULT NULL,
  `routecls` int DEFAULT NULL,
  `interfacecls` int DEFAULT NULL,
  `local_mroute` int DEFAULT NULL,
  `local_mcost` float DEFAULT NULL,
  `tollfree_mroute` int DEFAULT NULL,
  `tollfree_mcost` float DEFAULT NULL,
  `mobile_mroute` int DEFAULT NULL,
  `mobile_mcost` float DEFAULT NULL,
  `payphone_mroute` int DEFAULT NULL,
  `payphone_mcost` float DEFAULT NULL,
  `countrycode` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`prefixcode`),
  KEY `idx1` (`pc`,`prefixlen`),
  KEY `idx2` (`prefixlen`,`pc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `r_timecls`
--

DROP TABLE IF EXISTS `r_timecls`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `r_timecls` (
  `id` int NOT NULL AUTO_INCREMENT,
  `state` varchar(1) NOT NULL,
  `tintid` int NOT NULL,
  `cls` varchar(1) NOT NULL,
  `dc` int NOT NULL,
  `tc` int NOT NULL,
  `sc` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx1` (`tintid`,`cls`,`dc`,`tc`,`sc`),
  KEY `idx_r_timecls_tintid` (`tintid`),
  KEY `idx_r_timecls_cls` (`cls`),
  KEY `idx_r_timecls_dc` (`dc`),
  KEY `idx_r_timecls_tc` (`tc`),
  KEY `idx_r_timecls_sc` (`sc`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=15512 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `r_timecode`
--

DROP TABLE IF EXISTS `r_timecode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `r_timecode` (
  `id` int NOT NULL AUTO_INCREMENT,
  `h1` int NOT NULL,
  `h2` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_r_timecode_id` (`id`),
  KEY `idx_r_timecode_h1` (`h1`),
  KEY `idx_r_timecode_h2` (`h2`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=2655 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `r_xlat_domain`
--

DROP TABLE IF EXISTS `r_xlat_domain`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `r_xlat_domain` (
  `domain` varchar(8) DEFAULT NULL,
  `xlatdom` varchar(8) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`),
  KEY `idx_r_xlat_domain_xlatdom` (`xlatdom`),
  KEY `idx_r_xlat_domain_domain` (`domain`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `route_limit`
--

DROP TABLE IF EXISTS `route_limit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `route_limit` (
  `sitecode` varchar(3) DEFAULT NULL,
  `prefix` varchar(15) DEFAULT NULL,
  `routenb` varchar(4) DEFAULT NULL,
  `maxdif` float DEFAULT NULL,
  `comment` varchar(200) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `staging_sheet1`
--

DROP TABLE IF EXISTS `staging_sheet1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `staging_sheet1` (
  `id` int NOT NULL AUTO_INCREMENT,
  `record_date` datetime DEFAULT NULL,
  `trunkout` varchar(50) DEFAULT NULL,
  `destcode` varchar(100) DEFAULT NULL,
  `prefixcode` varchar(50) DEFAULT NULL,
  `routecls` varchar(50) DEFAULT NULL,
  `did` varchar(50) DEFAULT NULL,
  `ani` varchar(50) DEFAULT NULL,
  `dialednum` varchar(50) DEFAULT NULL,
  `calls` int DEFAULT NULL,
  `talktime_inmin` float DEFAULT NULL,
  `callcost` float DEFAULT NULL,
  `acd` float DEFAULT NULL,
  `rate` float DEFAULT NULL,
  `cost` float DEFAULT NULL,
  `import_status` tinyint DEFAULT '0',
  `import_error` varchar(500) DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_staging1_prefixcode` (`prefixcode`),
  KEY `idx_staging1_status` (`import_status`)
) ENGINE=InnoDB AUTO_INCREMENT=93013 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `staging_sheet2`
--

DROP TABLE IF EXISTS `staging_sheet2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `staging_sheet2` (
  `id` int NOT NULL AUTO_INCREMENT,
  `trunkout` varchar(50) DEFAULT NULL,
  `destcode` varchar(100) DEFAULT NULL,
  `prefixcode` varchar(50) DEFAULT NULL,
  `routecls` varchar(50) DEFAULT NULL,
  `did` varchar(50) DEFAULT NULL,
  `import_status` tinyint DEFAULT '0',
  `import_error` varchar(500) DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_staging2_prefixcode` (`prefixcode`),
  KEY `idx_staging2_status` (`import_status`)
) ENGINE=InnoDB AUTO_INCREMENT=15624 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `trunkcodec_info`
--

DROP TABLE IF EXISTS `trunkcodec_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `trunkcodec_info` (
  `id` int NOT NULL AUTO_INCREMENT,
  `trunk` varchar(50) NOT NULL,
  `trunk_codec` varchar(50) NOT NULL,
  `status` int DEFAULT NULL,
  `create_date` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`trunk`,`trunk_codec`),
  UNIQUE KEY `id` (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=116 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `xlat`
--

DROP TABLE IF EXISTS `xlat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `xlat` (
  `sitecode` varchar(3) NOT NULL,
  `switchcode` varchar(3) NOT NULL,
  `prefix` varchar(15) NOT NULL,
  `trunkcode` varchar(8) NOT NULL,
  `direction` int NOT NULL,
  `xlatpfx` varchar(20) NOT NULL,
  `prefixlen` int DEFAULT NULL,
  `pc` char(2) DEFAULT NULL,
  PRIMARY KEY (`sitecode`,`switchcode`,`prefix`,`trunkcode`,`direction`,`xlatpfx`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping events for database 'routing_vect'
--

--
-- Dumping routines for database 'routing_vect'
--
/*!50003 DROP PROCEDURE IF EXISTS `croute_get_codec_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `croute_get_codec_details`(trunk VARCHAR(20))
BEGIN
 
 	
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select a.trunk_codec from trunkcodec_info a
    where a.trunk = trunk and a.status = 1;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 	
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `cr_get_operatorset` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `cr_get_operatorset`(id INT)
begin
 
     SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
     select z.* from(select y.universe, y.`domain`, y.pdomain,y.`group`, y.name interface, y.userinfo,
  		y.hint, IFNULL(y.type,1) oprtype,
  		x.cost, x.flag, x.rating, x.quality, x.priority
        from r_operatorset x, r_interface y 
        where
        x.operatorset_id = id and x.state = 1 and
        x.oprId = y.id
        union
        select universe, `domain`, `domain` pdomain, `group`, interface, userinfo,
  		null hint, IFNULL(oprtype,1) oprtype,
  		cost, flag, rating, quality, priority
        from r_operatorset
        where
        operatorset_id = id and oprid = -1) z
     order by z.priority;
     SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;	
  
  end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `emg_get_route` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbteam`@`%` PROCEDURE `emg_get_route`(
   pDDI VARCHAR(32),                          
   pDate DATETIME(3),                          
   pSrcInt VARCHAR(7),                          
   pSrcIntGroup VARCHAR(64),                          
   pSrcIntDom VARCHAR(64),                          
   routeclass INT  ,                      
   pCLI VARCHAR(32),                          
   pOperatorGroup INT)
begin


   DECLARE v_longestPrefixcode VARCHAR(16);                          
   DECLARE v_longestCls INT;  
   DECLARE v_nearestTime VARCHAR(17);                          
  
  
                                       
   IF routeclass is null 
   then
      set routeclass = 0;
   END IF;
   
   IF pCLI is null 
   then
      set pCLI = '';
   END IF;
   
   IF pOperatorGroup is null 
   then
      set pOperatorGroup = 0;
   END IF;
      
   select   prefixcode, prefixCls INTO v_longestPrefixcode,v_longestCls from 
   r_prefix2  where pc = left(pDDI,2) and pDDI like CONCAT(prefixcode,'%')   order by prefixlen desc LIMIT 1;   
  
   if v_longestCls is null 
   then 
      set v_longestCls = 0;
   end if;  
  
   CALL r22_routeGetNearestTime(pDate,v_nearestTime);  
   
   if v_longestCls in(3,4) 
   then
      CALL r24_routeSpecialGetCache(v_longestPrefixcode,pDate,pSrcInt,pSrcIntGroup,pSrcIntDom,routeclass,pCLI,pOperatorGroup);
   else
      CALL emg_routeGetCache(v_longestPrefixcode,v_longestCls,pDate,pSrcInt,pSrcIntGroup,pSrcIntDom,routeclass,pCLI,pOperatorGroup);
   end if;  
   
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `emg_routeGetCache` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `emg_routeGetCache`(
    pLongest VARCHAR(32),                                      
    pLongestCls INT,              
    pDate DATETIME(3),                                      
    pSrcInt VARCHAR(7),                                      
    pSrcIntGroup VARCHAR(64),                                      
    pSrcIntDom VARCHAR(64),                                      
    routeclass INT  ,                                  
    pCLI VARCHAR(32),                                      
    pOperatorGroup INT    ,        
    isgrade INT)
begin
                                   
    DECLARE v_pc VARCHAR(2);                                      
    DECLARE v_dd INT;        
    DECLARE v_hh INT;        
    DECLARE v_mm INT;     
    DECLARE v_dadomain VARCHAR(100);     
    DECLARE v_gmt DATETIME(3);    
    declare v_datefirst  DATETIME(3);                                          
   
    IF routeclass is null 
    then
       set routeclass = 0;
    END IF;
    
    IF pCLI is null 
    then
       set pCLI = '';
    END IF;
    
    IF pOperatorGroup is null 
    then
       set pOperatorGroup = 0;
    END IF;
    
    IF isgrade is null 
    then
       set isgrade = 0;
    END IF;
    
    set v_pc = left(pLongest,2);    
    
   
                                       
    set v_dd = 1+(v_datefirst+DAYOFWEEK(pDate) -2)%7;        
    select   `domain`, (EXTRACT(HOUR FROM pDate) -timezone) INTO v_dadomain,v_hh from r_info;         
    set v_mm = EXTRACT(MINUTE FROM pDate);        
                                       
 
    DROP TEMPORARY TABLE IF EXISTS tt_operator_selected;        
    CREATE TEMPORARY TABLE tt_operator_selected 
    (
       routecls INT NOT NULL,
       oprId INT NOT NULL,
       cls VARCHAR(1) NOT NULL,
       pc VARCHAR(2) NOT NULL
    );        
         
    CREATE  UNIQUE  INDEX idx1 ON `tt_operator_selected`
    (routecls, 
    oprId, 
    cls, 
    pc);        
         
         
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    insert into tt_operator_selected(routecls,oprid,cls,pc)
    select x.routecls,x.oprid,x.cls,x.pc  from r20_route_timecls x, r_timecls y, r_interface tit,
    r_timecode tco, r_daycode dco where x.routecls = 0 and tit.id = x.oprid and tit.state = 'I'
    and y.tintid = x.oprid and y.cls = x.cls and y.dc = dco.id and y.tc = tco.id and y.sc = 0
    and v_dd between dco.d1 and dco.d2 and((24+v_hh+IFNULL(tit.prefixcls,0))%24)*100+v_mm 
    between tco.h1 and tco.h2 -1 and x.pc = v_pc and tit.`domain` = v_dadomain;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;       
                 
    DROP TEMPORARY TABLE IF EXISTS tt_timecls_selected;                       
    CREATE TEMPORARY TABLE tt_timecls_selected 
    (
       routecls INT NOT NULL,
       oprId INT NOT NULL,
       pc VARCHAR(2) NOT NULL,
       prefixcode VARCHAR(50) NOT NULL,
       cnt INT,
       clsA INT,
       clsP INT,
       clsO INT,
       clsW INT,
       cls VARCHAR(1) NOT NULL
    );         
         
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    insert into tt_timecls_selected(routecls,oprid,pc,prefixcode,cnt,clsA,clsP,clsO,clsW,cls)
    select a.routecls, a.oprid, a.pc, max(a.prefixCode) prefixCode,count(*) cnt,
  sum(case when a.cls = 'A' then 1 else 0 end) clsA,
  sum(case when a.cls = 'P' then 1 else 0 end) clsP,
  sum(case when a.cls = 'O' then 1 else 0 end) clsO,
  sum(case when a.cls = 'W' then 1 else 0 end) clsW, 'Z' cls
    from R20_ROUTE08 a, tt_operator_selected b
    where a.routeCls = b.routeCls and a.oprId = b.oprId and a.cls = b.cls and a.pc = b.pc
    and left(pLongest,prefixLen) = a.prefixcode
    group by a.routecls,a.oprid,a.pc;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;          
        
    update tt_timecls_selected
    set cls =(case when (clsW > 0) and (cnt = clsW) then 'W'
    when (clsO > 0) and (cnt = clsO) then 'O'
    when (clsP > 0) and (cnt = clsP) then 'P'
    when (clsA > 0) and (cnt = clsA) then 'A'
    else 'Z' end);        
         
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    update tt_timecls_selected
    set cls =(select max(a.cls) from R20_ROUTE08 a 
    where a.routecls = tt_timecls_selected.routecls
    and a.oprid = tt_timecls_selected.oprId
    and a.pc = tt_timecls_selected.pc
    and a.prefixCode = tt_timecls_selected.prefixCode
    and ((a.cls = 'A' and tt_timecls_selected.clsA <> 0) or
           (a.cls = 'P' and tt_timecls_selected.clsP <> 0) or
           (a.cls = 'O' and tt_timecls_selected.clsO <> 0) or
           (a.cls = 'W' and tt_timecls_selected.clsW <> 0)))
    where cls = 'Z';
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;        
         
    DROP TEMPORARY TABLE IF EXISTS tt_route;                
    CREATE TEMPORARY TABLE tt_route 
    (
       seqno INT   AUTO_INCREMENT PRIMARY KEY,
       priority INT,
       id INT,
       isactive INT,
       reason INT,
       `exception` INT,
       calcexception INT,
       ext INT,
       oprid INT,
       parentid INT,
       routecls INT,
       prefixcode VARCHAR(50),
       universe VARCHAR(5),
       `domain` VARCHAR(5),
       pdomain VARCHAR(5),
       `group` VARCHAR(40),
       interface VARCHAR(40),
       userinfo VARCHAR(40),
       hint VARCHAR(100),
       clsorg CHAR(1),
       cls CHAR(1),
       cost FLOAT,
       flag INT,
       rating INT,
       access VARCHAR(10),
       redlist INT,
       quality FLOAT,
       exceptioncls INT
    )  AUTO_INCREMENT = 10;        
         
         
    if isgrade = 0 
    then
 
       SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
       insert into tt_route(isactive,reason,`exception`,calcexception,id,parentid,routecls,oprid,prefixcode,clsorg,cls,cost,
 						   priority,rating,flag,ext,quality,exceptioncls)
       select x.state isactive, x.reason,IFNULL(x.`exception`,0) `exception`,
 		case when ((IFNULL(x.`exception`,0) = 0)) then 0
       when x.`exception` > 0 then cast((x.`exception`+0.5)*10 as SIGNED INTEGER)
       else cast((x.`exception` -0.5)*10 as SIGNED INTEGER)
       end calcException,x.id, x.parentId, x.routeCls, x.oprId, x.prefixCode, x.clsOrg, x.cls,
 		x.cost, x.priority, rating, x.flag, x.ext,x.quality,x.exceptioncls
       from R20_ROUTE08 x, tt_timecls_selected b
       where x.routecls = b.routecls and x.oprid = b.oprid and x.pc = b.pc and x.prefixcode = b.prefixcode and x.cls = b.cls
       order by x.cost;
       SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
       
    else
    
       SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
       insert into tt_route(isactive,reason,`exception`,calcexception,id,parentid,routecls,oprid,prefixcode,clsorg,cls,cost,
 							priority,rating,flag,ext,quality,exceptioncls)
       select x.state isactive, x.reason,IFNULL(x.`exception`,0) `exception`,
 		case when ((IFNULL(x.`exception`,0) = 0)) then 0
       when x.`exception` > 0 then cast((x.`exception`+0.5)*10 as SIGNED INTEGER)
       else cast((x.`exception` -0.5)*10 as SIGNED INTEGER) end calcException,
 	 x.id, x.parentId, x.routeCls, x.oprId, x.prefixCode, x.clsOrg, x.cls,
 	 x.cost, x.priority, rating, x.flag, x.ext,x.quality,x.exceptioncls
       from R20_ROUTE08 x, tt_timecls_selected b where x.routecls = b.routecls and x.oprid = b.oprid 
       and x.pc = b.pc and x.prefixcode = b.prefixcode and x.cls = b.cls order by x.quality,x.cost;
       SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
       
    end if;        
                               
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select 'r20_route08' routeset,x.seqno priority, x.id, x.isactive, x.reason,
    x.`exception`, IFNULL(x.ext,0) ext,x.routecls, x.prefixcode, y.universe, y.`domain`, y.pdomain,
     y.`group`, y.name interface, y.userinfo, y.hint, x.clsOrg, x.cls timecls, x.cost, x.flag, x.rating,
  '11111' access, 0 redlist,x.quality grade,IFNULL(y.intcls,0) intcls,x.exceptioncls capability, IFNULL(y.type,1) oprtype
    from tt_route x, r_interface y, r_interfaceGroup ig where x.oprId = y.id and ig.tintid = x.oprId 
    and ig.intgroupid = pOperatorGroup and ig.flag = 1 and x.isactive = 1 and pLongest like CONCAT(x.prefixcode,'%')
    order by seqno+calcException;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;                              
     
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es3_get_xlat` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `es3_get_xlat`(
sitecode VARCHAR(3),
prefix VARCHAR(30),  
trunkcode VARCHAR(16),  
direction INT,   
switchcode VARCHAR(3)
)
begin
   
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select * from xlat a
    where a.sitecode = sitecode
    and a.prefix = left(prefix,prefixlen)
    and a.trunkcode = trunkcode
    and a.direction = direction
    and (a.switchcode = switchcode or a.switchcode = 'ALL')
    order by a.switchcode,a.prefix desc;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;    
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es5_get_config` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `es5_get_config`(opr VARCHAR(16),  
 pfx VARCHAR(20))
begin
 
   
    select * from cswitch_config
    where (operator = opr or operator = '*')
    and   (left(pfx,CHAR_LENGTH(RTRIM(prefix))) = prefix  or prefix = '*')
    order by operator desc,prefix desc;   
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `esp_getxlat_interdomain` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `esp_getxlat_interdomain`(
  sitein VARCHAR(4),  
  switchin VARCHAR(4),  
  siteout VARCHAR(4),  
  operatorout VARCHAR(15),  
  phone VARCHAR(30))
begin
   
    select * from routingv2_voip.XlatInterDomain a where (sitecode_in = sitein or sitecode_in = '*') and
   (switchcode_in = switchin or switchcode_in = '*') and (sitecode_out = siteout) and
   (a.operator_out = operatorout or a.operator_out = '*') and (prefix = left(phone,prefixlen) or prefix = '*')
   order by prefixlen desc,sitecode_in desc,switchcode_in desc,sitecode_out,operator_out desc LIMIT 1;   
   
  end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `esp_get_routelimit` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `esp_get_routelimit`(
 site VARCHAR(3),  
 phone VARCHAR(20))
begin
 
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select  a.routenb,a.maxdif from route_limit a
    where (a.sitecode = site or a.sitecode = '*')
    and  (a.prefix = left(phone,CHAR_LENGTH(RTRIM(a.prefix))) or a.prefix = '*')
    order by a.sitecode desc,a.prefix desc LIMIT 1;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r01_get_prefix_ref` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbteam`@`%` PROCEDURE `r01_get_prefix_ref`(dialednumb VARCHAR(100))
begin
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select  a.prefixcode prefix_ref
    from r_prefix2 a
    where a.pc = left(dialednumb,2) and dialednumb like CONCAT(a.prefixcode,'%') order by a.prefixlen desc LIMIT 1;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r22_routeGetNearestTime` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `r22_routeGetNearestTime`(
  	pDate DATETIME(3),  
  OUT sDate VARCHAR(30))
begin
  
     DECLARE v_m INT;   
     
     set v_m = EXTRACT(minute FROM pDate);  
 
     if v_m < 30 
     then
        set sDate = CONCAT(left(DATE_FORMAT(pDate,'%Y-%m-%d %T'),14),'00');
     else
        set sDate = CONCAT(left(DATE_FORMAT(pDate,'%Y-%m-%d %T'),14),'30');
     end if;  
     
  end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r24_routeSpecialGetCache` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbteam`@`%` PROCEDURE `r24_routeSpecialGetCache`(
   pLongest VARCHAR(32),                                          
   pDate DATETIME(3),                                          
   pSrcInt VARCHAR(7),                                          
   pSrcIntGroup VARCHAR(64),                                          
   pSrcIntDom VARCHAR(64),                                          
   routeclass INT  ,                                      
   pCLI VARCHAR(32),                                          
   pOperatorGroup INT)
begin
           
              
   IF routeclass is null 
   then
      set routeclass = 0;
   END IF;
   
   IF pCLI is null 
   then
      set pCLI = '';
   END IF;
   
   IF pOperatorGroup is null 
   then
      set pOperatorGroup = 0;
   END IF;
   
   select 'r20_route08' routeSet, 1 priority, a.id, a.state isactive, reason, 0 `exception`, 0 ext, a.routecls,
 prefixCode, c.universe, b.`domain`, b.pdomain, b.`group`, b.name interface, b.userinfo, b.hint,
 clsOrg, cls timeCls, cost, flag, rating, '11111' access, 0 redList, 0 `except`,quality grade,IFNULL(b.intcls,0) intcls,
 exceptioncls capability,IFNULL(b.type,1) oprtype
   from r20_route08 a, r_interface b, r_domain c 
   where a.routeCls = 0 and a.pc = left(pLongest,2) and a.prefixcode = pLongest
   and a.oprid = b.id and b.`domain` = c.name and a.state = 1;
   
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r25_delete_india_did_route` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `r25_delete_india_did_route`(
  p_did varchar(30),
  p_group varchar(10)
  )
Begin
 	declare v_errcode int default -1;
     declare v_errmsg varchar(100) default 'Failure';
  	delete from india_did_route where did = p_did and `group` = p_group;
     
     if row_count()>0 then 
 		set v_errcode = 0;
         set v_errmsg = 'Did removed';
     End if;
     
     select v_errcode as errcode, v_errmsg as errmsg;
     
  End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r25_get_india_did_route` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `r25_get_india_did_route`(
p_did varchar(30)
)
Begin
	select * from india_did_route where did = p_did;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r25_get_route` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `r25_get_route`(
		pDDI VARCHAR(32),                              
       pDate DATETIME(3),                              
       pSrcInt VARCHAR(7),                              
       pSrcIntGroup VARCHAR(64),                              
       pSrcIntDom VARCHAR(64),                              
       routeclass INT  ,                          
       pCLI VARCHAR(32),                              
       pOperatorGroup INT  ,    
       isgrade INT
)
begin
           
       DECLARE v_longestPrefixcode VARCHAR(16);                              
       DECLARE v_longestCls INT;      
       DECLARE v_nearestTime VARCHAR(50); 

       IF routeclass is null then
          set routeclass = 0;
       END IF;
       IF pCLI is null then
          set pCLI = '';
       END IF;
       IF pOperatorGroup is null then
          set pOperatorGroup = 0;
       END IF;
       IF isgrade is null then
          set isgrade = 0;
       END IF;
       
       set @v_pc = '';
       
       SET @v_pc = left(pDDI,2);
       
       SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
       select   a.prefixcode, ifnull(a.prefixCls,0) INTO v_longestPrefixcode,v_longestCls 
       from r_prefix2  a where a.pc = @v_pc and pDDI like CONCAT(a.prefixcode,'%')   order by a.prefixlen desc LIMIT 1;
       SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;      
          
       if v_longestCls is null then 
          set v_longestCls = 0;
       end if;      
          
      

       
		if v_longestCls in(3,4,7,9) then
		  CALL r25_routeSpecialGetCache(v_longestPrefixcode,pDate,pSrcInt,pSrcIntGroup,pSrcIntDom,routeclass, pCLI,pOperatorGroup);
		else
		  CALL r25_routeGetCache(v_longestPrefixcode,v_longestCls,pDate,pSrcInt,pSrcIntGroup,pSrcIntDom, routeclass,pCLI,pOperatorGroup,isgrade);
		end if;   

    end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r25_routeGetCache` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `r25_routeGetCache`(
       pLongest VARCHAR(32),  
       pLongestCls INT,  
       pDate DATETIME(3),  
       pSrcInt VARCHAR(7),  
       pSrcIntGroup VARCHAR(64),  
       pSrcIntDom VARCHAR(64),  
       routeclass INT,  
       pCLI VARCHAR(32),  
       pOperatorGroup INT ,  
       isgrade INT)
begin
    
       DECLARE v_pc VARCHAR(2);  
       DECLARE v_dd INT;  
       DECLARE v_hh INT;  
       DECLARE v_mm INT;  
       DECLARE v_gmt DATETIME(3);  
       declare v_datefirst DATETIME(3);
     
       
       IF routeclass is null 
       then
          set routeclass = 0;
       END IF;
       
       IF pCLI is null 
       then
          set pCLI = '';
       END IF;
       
       IF pOperatorGroup is null 
       then
          set pOperatorGroup = 0;
       END IF;
       
       IF isgrade is null 
       then
          set isgrade = 0;
       END IF;
       
       set v_pc = left(pLongest,2);  
       
       select(TIMESTAMPADD(HOUR,-timezone,pDate)) INTO v_gmt from r_info;  
       
       set v_dd = 1+(7+DAYOFWEEK(v_gmt) -2)%7;  
       set v_hh = EXTRACT(HOUR FROM v_gmt);  
       set v_mm = EXTRACT(MINUTE FROM v_gmt);  
       
    
    
    
       
    
       
       DROP TEMPORARY TABLE IF EXISTS tt_operator_selected;
       CREATE TEMPORARY TABLE tt_operator_selected 
       (
          routecls INT NOT NULL,
          oprId INT NOT NULL,
          cls VARCHAR(1) NOT NULL,
          pc VARCHAR(2) NOT NULL
       );  
       
       CREATE  UNIQUE  INDEX idx1 ON `tt_operator_selected`(routecls, oprId, cls, pc);  
       
       alter table tt_operator_selected add index idx_os_routecls(routecls);
       alter table tt_operator_selected add index idx_os_oprId(oprId);
       alter table tt_operator_selected add index idx_os_cls(cls);
       alter table tt_operator_selected add index idx_os_pc(pc);

       SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
       insert into tt_operator_selected(routecls,oprid,cls,pc)
       select x.routecls,x.oprid,x.cls,x.pc
       from r20_route_timecls x, r_timecls y, r_interface tit,
       r_timecode tco, r_daycode dco where x.routecls = 0
       and tit.id = x.oprid and tit.state = 'I'
       and y.tintid = x.oprid and y.cls = x.cls
       and y.dc = dco.id and y.tc = tco.id and y.sc = 0
       and v_dd between dco.d1 and dco.d2
       and((24+v_hh+IFNULL(tit.prefixcls,0))%24)*100+v_mm between tco.h1 and tco.h2 -1
       and x.pc = v_pc;
       SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
       
       DROP TEMPORARY TABLE IF EXISTS tt_timecls_selected;     
       CREATE TEMPORARY TABLE tt_timecls_selected 
       (
          routecls INT NOT NULL,
          oprId INT NOT NULL,
          pc VARCHAR(2) NOT NULL,
          prefixcode VARCHAR(50) NOT NULL,
          cnt INT,
          clsA INT,
          clsP INT,
          clsO INT,
          clsW INT,
          cls VARCHAR(1) NOT NULL
       );  
       
       alter table tt_timecls_selected add index idx_ts_routecls(routecls);
       alter table tt_timecls_selected add index idx_ts_oprId(oprId);
       alter table tt_timecls_selected add index idx_ts_prefixcode(prefixcode);
       alter table tt_timecls_selected add index idx_ts_pc(pc);
       
       alter table tt_timecls_selected add index idx_ts_cnt(cnt);
       alter table tt_timecls_selected add index idx_ts_clsA(clsA);
       alter table tt_timecls_selected add index idx_ts_clsP(clsP);
       alter table tt_timecls_selected add index idx_ts_clsO(clsO);
       alter table tt_timecls_selected add index idx_ts_clsW(clsW);
       alter table tt_timecls_selected add index idx_ts_cls(cls);
       
       
       SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
       insert into tt_timecls_selected(routecls,oprid,pc,prefixcode,cnt,clsA,clsP,clsO,clsW,cls)
       select a.routecls, a.oprid, a.pc, max(a.prefixCode) prefixCode,
     count(*) cnt,
     sum(case when a.cls = 'A' then 1 else 0 end) clsA,
     sum(case when a.cls = 'P' then 1 else 0 end) clsP,
     sum(case when a.cls = 'O' then 1 else 0 end) clsO,
     sum(case when a.cls = 'W' then 1 else 0 end) clsW, 'Z' cls
       from R20_ROUTE08 a, tt_operator_selected b
       where a.routeCls = b.routeCls and a.oprId = b.oprId and a.pc = b.pc
       and  left(pLongest,prefixLen) = a.prefixcode  and a.cls = b.cls
       group by a.routecls,a.oprid,a.pc;
       SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
       
       update tt_timecls_selected
       set cls =(case when (clsW > 0) and (cnt = clsW) then 'W'
       when (clsO > 0) and (cnt = clsO) then 'O'
       when (clsP > 0) and (cnt = clsP) then 'P'
       when (clsA > 0) and (cnt = clsA) then 'A'
       else 'Z' end);  
       
       SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
       update tt_timecls_selected
       set cls =(select max(a.cls) from R20_ROUTE08 a 
       where a.routecls = tt_timecls_selected.routecls
       and a.oprid = tt_timecls_selected.oprId
       and a.pc = tt_timecls_selected.pc
       and a.prefixCode = tt_timecls_selected.prefixCode
       and ((a.cls = 'A' and tt_timecls_selected.clsA <> 0) or
              (a.cls = 'P' and tt_timecls_selected.clsP <> 0) or
              (a.cls = 'O' and tt_timecls_selected.clsO <> 0) or
              (a.cls = 'W' and tt_timecls_selected.clsW <> 0)))
       where cls = 'Z';
       SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
       
       DROP TEMPORARY TABLE IF EXISTS tt_route;     
       CREATE TEMPORARY TABLE tt_route 
       (
          seqno INT   AUTO_INCREMENT PRIMARY KEY,
          priority INT,
          id INT,
          isactive INT,
          reason INT,
          `exception` INT,
          calcexception INT,
          ext INT,
          oprid INT,
          parentid INT,
          routecls INT,
          prefixcode VARCHAR(50),
          universe VARCHAR(5),
          `domain` VARCHAR(5),
          pdomain VARCHAR(5),
          `group` VARCHAR(40),
          interface VARCHAR(40),
          userinfo VARCHAR(40),
          hint VARCHAR(100),
          clsorg CHAR(1),
          cls CHAR(1),
          cost FLOAT,
          flag INT,
          rating INT,
          access VARCHAR(10),
          redlist INT,
          quality FLOAT,
          exceptioncls INT
       )  AUTO_INCREMENT = 10;  
       
       if isgrade = 0 
       then
    
          SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
          insert into tt_route(isactive,reason,`exception`,calcexception,id,parentid,routecls,oprid,prefixcode,clsorg,cls,cost,
    		priority,rating,flag,ext,quality,exceptioncls)
          select x.state isactive, x.reason,IFNULL(x.`exception`,0) `exception`,
    	  case when ((IFNULL(x.`exception`,0) = 0)) then 0
          when x.`exception` > 0 then cast((x.`exception`+0.5)*10 as SIGNED INTEGER)
          else cast((x.`exception` -0.5)*10 as SIGNED INTEGER)
          end calcException,x.id, x.parentId, x.routeCls, x.oprId, 
          x.prefixCode, x.clsOrg, x.cls,x.cost,
    	  x.priority, rating, x.flag, x.ext,x.quality,x.exceptioncls
          from R20_ROUTE08 x, tt_timecls_selected b, r_interface y
          where x.routecls = b.routecls and x.oprid = b.oprid and x.pc = b.pc and x.prefixcode = b.prefixcode and x.cls = b.cls and x.oprId = y.id
          order by case when x.oprid < 0 then x.cost*1.05 else x.cost end,case when `domain` = pSrcIntDom then 0 else 1 end;
          SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
          
       else
       
          SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
          insert into tt_route(isactive,reason,`exception`,calcexception,id,parentid,routecls,oprid,prefixcode,clsorg,cls,cost,
    							priority,rating,flag,ext,quality,exceptioncls)
          select x.state isactive, x.reason,IFNULL(x.`exception`,0) `exception`,
				case when ((IFNULL(x.`exception`,0) = 0)) then 0
				when x.`exception` > 0 then cast((x.`exception`+0.5)*10 as SIGNED INTEGER)
				else cast((x.`exception` -0.5)*10 as SIGNED INTEGER)
				end calcException, x.id, x.parentId, x.routeCls, x.oprId, 
				x.prefixCode, x.clsOrg, x.cls,x.cost,
				x.priority, rating, x.flag, x.ext,x.quality,x.exceptioncls
          from R20_ROUTE08 x, tt_timecls_selected b, r_interface y
          where x.routecls = b.routecls and x.oprid = b.oprid and x.pc = b.pc and x.prefixcode = b.prefixcode and x.cls = b.cls and x.oprId = y.id
          order by x.quality,case when x.oprid < 0 then x.cost*1.05 else x.cost end,case when `domain` = pSrcIntDom then 0 else 1 end;
          SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
          
       end if;  
            
       SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
		Select  'R20_ROUTE08'routeset,priority,a.id,isactive,reason,`exception`,ext,
				routecls, a.prefixcode, universe, IFNULL(z.xlatdom,a.`domain`) `domain`, IFNULL(z.xlatdom,a.`domain`) pdomain,
				`group`,interface,userinfo,hint,clsOrg,timecls,a.cost,flag,rating,
				access,redlist,grade,intcls,capability,oprtype,b.Cost CostPrice
		from
        (
			select x.seqno priority, x.id, x.isactive, x.reason, x.`exception`, IFNULL(x.ext,0) ext,
			x.oprid, x.routecls, x.prefixcode, y.universe, y.`domain`, y.pdomain, calcException,
			y.`group`, y.name interface, y.userinfo, y.hint, x.clsOrg, x.cls timecls, x.cost, x.flag, x.rating,  
			'11111' access, 0 redlist,x.quality grade,IFNULL(y.intcls,0) intcls,x.exceptioncls capability, IFNULL(y.type,1) oprtype  
			from tt_route x, r_interface y, r_interfaceGroup ig where x.oprId = y.id and ig.tintid = x.oprId 
			and ig.intgroupid = pOperatorGroup and ig.flag = 1 and x.isactive = 1 
			and pLongest like CONCAT(x.prefixcode,'%')
        ) a
		left join r20_routeCPrice b on a.Timecls = b.cls and a.oprId = b.Oprid and a.prefixCode = b.PrefixCode, r_xlat_domain z 
		where a.`domain` = z.`domain` order by Priority+calcException;
       SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
 
    end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r25_routeSpecialGetCache` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `r25_routeSpecialGetCache`(
  pLongest VARCHAR(32),                                                  
     pDate DATETIME(3),                                                  
     pSrcInt VARCHAR(7),                                                  
     pSrcIntGroup VARCHAR(64),                                                  
     pSrcIntDom VARCHAR(64),                                                  
     routeclass INT  ,                                              
     pCLI VARCHAR(32),                                                  
     pOperatorGroup INT)
begin
                   
               
     IF routeclass is null then
        set routeclass = 0;
     END IF;
     IF pCLI is null then
        set pCLI = '';
     END IF;
     IF pOperatorGroup is null then
        set pOperatorGroup = 0;
     END IF;
     SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
     select routeSet,priority,x.id,isactive,reason,`exception`,ext,routecls,x.prefixCode,universe,IFNULL(z.xlatdom,x.`domain`) `domain`,IFNULL(z.xlatdom,x.`domain`) pdomain,`group`,
  interface,userinfo,hint,clsOrg,timeCls,x.cost,flag,rating,access,redList,`except`,grade,intcls,capability,oprtype, y.Cost CostPrice from(select 'r20_route08' routeSet, 1 priority, a.id, a.oprId, a.state isactive, reason, 0 `exception`, 0 ext, a.routecls,
   prefixCode, c.universe, b.`domain`, b.pdomain, b.`group`, b.name interface, b.userinfo, b.hint,
   clsOrg, cls timeCls, cost, flag, rating, '11111' access, 0 redList, 0 `except`,quality grade,IFNULL(b.intcls,0) intcls,
   exceptioncls capability,IFNULL(b.type,1) oprtype
        from R20_ROUTE08 a, r_interface b, r_domain c 
        where a.routeCls = 0 and a.pc = left(pLongest,2) and a.prefixcode = pLongest
        and a.oprid = b.id and b.`domain` = c.name and a.state = 1) x
     left join
     r20_routeCPrice y 
     On x.timecls = y.cls and x.prefixcode = y.prefixcode and x.OprId = y.OprId, r_xlat_domain z 
     where x.`domain` = z.xlatdom;
     SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
  end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r_interxgate_get_bridges` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `r_interxgate_get_bridges`(
 domainfr VARCHAR(4),    
 domainto VARCHAR(4))
begin
     
    select * from inter_xgate_bridge a where (domain_from = domainfr or domain_from = '*')
    and (a.domain_to = domainto or a.domain_to = '*') and bridge_idx >= 0
    order by domain_from desc,a.domain_to desc,bridge_idx LIMIT 1;      
    
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sip_pbx_new_check_conference` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sip_pbx_new_check_conference`(domain_id INT,
 pin VARCHAR(10))
BEGIN
    DECLARE v_company_id INT; 
    DECLARE v_db_host_pin VARCHAR(10);
    DECLARE v_db_part_pin VARCHAR(10);
    DECLARE v_Extension_Number VARCHAR(15);
 	
    DECLARE v_extn_audio_file VARCHAR(250);
 	
    DECLARE v_conf_usr_type INT; 
 	
    DECLARE v_errcode INT; 
    DECLARE v_errmsg VARCHAR(250);
 	
    sp_exit:
    BEGIN
       set v_errcode = -1;
       set v_errmsg = 'Conference pin mismatch';
       SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
       select   company_id INTO v_company_id from vbcp_pbx_account a where a.domain_id = domain_id;
       SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
       IF EXISTS(SELECT  1 FROM UR_ECom_User_Extension_Dtl where Company_id = v_company_id and
       host_code = pin LIMIT 1) then
 	
          SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
          select   Extension_Number, IFNULL(extn_audio_file,'') INTO v_Extension_Number,v_extn_audio_file FROM UR_ECom_User_Extension_Dtl where Company_id = v_company_id and host_code = pin;
          SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
          set v_conf_usr_type = 1;
          set v_errcode = 0;
          set v_errmsg = 'User Host pin found.';
          LEAVE sp_exit;
       end if;
       IF EXISTS(SELECT  1 FROM UR_ECom_User_Extension_Dtl where Company_id = v_company_id and
       partipation_code = pin LIMIT 1) then
 	
          SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
          select   Extension_Number, IFNULL(extn_audio_file,'') INTO v_Extension_Number,v_extn_audio_file FROM UR_ECom_User_Extension_Dtl where Company_id = v_company_id and partipation_code = pin;
          SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
          set v_conf_usr_type = 2;
          set v_errcode = 0;
          set v_errmsg = 'User Participant pin found.';
          LEAVE sp_exit;
       end if;
    END;
    select IFNULL(v_conf_usr_type,0) as conf_usr_type,v_Extension_Number as Extension_Number,v_errcode as errcode,
 v_errmsg as errmsg,IFNULL(v_extn_audio_file,'') as extn_audio_file;
 	
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sl_checkddiblocked` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbteam`@`%` PROCEDURE `sl_checkddiblocked`(v_ddi VARCHAR(20))
begin
     SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select * from routingv2_voip.blocked_ddi a  where a.ddi = ltrim(rtrim(v_ddi)) LIMIT 1;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `up_insert_india_did_route` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `up_insert_india_did_route`(
 p_didfrom varchar(30),
 p_didto varchar(30),
 p_group varchar(20),
 p_cost float
 )
sp_return:begin
 
     if ifnull(p_didfrom,'')='' then
 		select -1 as errcode , 'DID is mandatory';
         leave sp_return;
     end if;
     
     if ifnull(p_didto,'')='' then
		set p_didto = p_didfrom;
     End if;
 
         while p_didfrom <= p_didto do
 			
             insert into india_did_route(did, `group`, cost) 
             values(p_didfrom,p_group, p_cost);
             
 			set p_didfrom = p_didfrom + 1;
         End while;

     select 0 as errcode , 'DID Inserted';
     
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-21  9:52:43
