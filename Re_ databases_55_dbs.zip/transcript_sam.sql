-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: transcript_sam
-- ------------------------------------------------------
-- Server version	8.0.44-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ts_folder_master_list`
--

DROP TABLE IF EXISTS `ts_folder_master_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ts_folder_master_list` (
  `folderid` int NOT NULL AUTO_INCREMENT,
  `createDate` datetime DEFAULT CURRENT_TIMESTAMP,
  `foldername` varchar(100) DEFAULT NULL,
  `createdBy` int DEFAULT NULL,
  `updateddate` datetime DEFAULT NULL,
  PRIMARY KEY (`folderid`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=86 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ts_login_master_log`
--

DROP TABLE IF EXISTS `ts_login_master_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ts_login_master_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(250) DEFAULT NULL,
  `password` varchar(250) DEFAULT NULL,
  `errcode` int DEFAULT NULL,
  `errmsg` varchar(250) DEFAULT NULL,
  `create_date` datetime(3) DEFAULT NULL,
  `email_sent_flag` int DEFAULT NULL,
  `device_type` varchar(150) DEFAULT NULL,
  `browser` varchar(250) DEFAULT NULL,
  `login_type` varchar(250) DEFAULT NULL,
  `login_source` varchar(30) DEFAULT NULL,
  `login_device_id` varchar(100) DEFAULT NULL,
  `login_ipaddress` varchar(30) DEFAULT NULL,
  `product_id` int DEFAULT (0),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=590 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ts_meeting_folder_list`
--

DROP TABLE IF EXISTS `ts_meeting_folder_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ts_meeting_folder_list` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int DEFAULT NULL,
  `meetingId` int DEFAULT NULL,
  `folderId` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ts_meeting_list`
--

DROP TABLE IF EXISTS `ts_meeting_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ts_meeting_list` (
  `id` int NOT NULL AUTO_INCREMENT,
  `createDate` datetime DEFAULT CURRENT_TIMESTAMP,
  `title` varchar(100) DEFAULT NULL,
  `userid` int DEFAULT NULL,
  `meetingURL` text,
  `summary` text,
  `participantPerformance` json DEFAULT NULL,
  `transcriptKeyword` text,
  `transcriptSpeakers` json DEFAULT NULL,
  `recordedMeeting` json DEFAULT NULL,
  `isDeleted` tinyint DEFAULT '0',
  `highlights` json DEFAULT NULL,
  `deletedate` datetime DEFAULT NULL,
  `updatedDate` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ts_users_dtl`
--

DROP TABLE IF EXISTS `ts_users_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ts_users_dtl` (
  `userid` int NOT NULL AUTO_INCREMENT,
  `createDate` datetime DEFAULT CURRENT_TIMESTAMP,
  `firstname` varchar(100) DEFAULT NULL,
  `lastname` varchar(100) DEFAULT NULL,
  `emailAddress` varchar(250) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `status` int DEFAULT '1',
  `source` varchar(50) DEFAULT NULL,
  `is_verified` tinyint DEFAULT '0',
  `verify_code` varchar(10) DEFAULT NULL,
  `expiry_time` int DEFAULT NULL,
  `companyName` varchar(150) DEFAULT NULL,
  `companySize` varchar(10) DEFAULT NULL,
  `industry` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `profpicUrl` text,
  `updatedAt` datetime DEFAULT NULL,
  `device` varchar(50) DEFAULT NULL,
  `token` text,
  PRIMARY KEY (`userid`),
  KEY `idx_ts_users_dtl_emailAddress` (`emailAddress`)
) ENGINE=InnoDB AUTO_INCREMENT=119 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping routines for database 'transcript_sam'
--
/*!50003 DROP PROCEDURE IF EXISTS `ts_create_signup_user_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ts_create_signup_user_dtl`(
       email VARCHAR(250),
       ip_address VARCHAR(20)
       )
Begin
       
          DECLARE verify_code VARCHAR(10) default 0;
          DECLARE errcode INT default -1; 
          DECLARE errmsg VARCHAR(250) default '';
       
          sp_exit:
          BEGIN
       
             if exists(select * from ts_users_dtl a  where a.emailAddress = email and a.is_verified = 1 LIMIT 1) then
                set errcode = -1;
                set errmsg = 'This email address already verified';
                LEAVE sp_exit;
             end if;
       
             SET verify_code = right(FORMAT(RAND(),7),6);
       
             if exists(select * from ts_users_dtl a  where a.emailAddress = email and a.is_verified = 0 LIMIT 1) then
       		
                UPDATE ts_users_dtl a 
                set a.verify_code = verify_code, a.expiry_time = 15
                where a.emailAddress = email and a.is_verified = 0;
                if ROW_COUNT() > 0 then
       			
                   set errcode = 0;
                   set errmsg = 'success';
                   LEAVE sp_exit;
                end if;
             end if;
             if not exists(select * from ts_users_dtl a where a.emailAddress = email LIMIT 1) then
       		
       			insert into ts_users_dtl(emailAddress,verify_code,is_verified,expiry_time)
       			values(email,verify_code,0,15);
       			
                if ROW_COUNT() > 0 then
       			
                   set errcode = 0;
                   set errmsg = 'success to generate pin';
                end if;
             end if;
          END;
     
          select errcode as errcode,errmsg as errmsg, verify_code as verify_code;
       
       End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ts_delete_folder_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ts_delete_folder_dtl`(
 p_folderid int,
 p_userId int
 )
Begin
 
	declare v_errcode int default -1;
    declare v_errmsg varchar(50) default 'Failure';
 
 	delete from ts_folder_master_list where createdBy = p_userId and folderid = p_folderid;
    
    if row_count()>0 then
		set v_errcode = 0;
        set v_errmsg = 'Deleted';
    End if;
    
    select v_errcode as errcode, v_errmsg as errmsg;
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ts_delete_restore_meetingId_list` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ts_delete_restore_meetingId_list`(
p_id int
,p_userid int
,del_res_flag tinyint 
)
Begin

	declare v_errcode int default -1;
    declare v_errmsg varchar(100) default 'Failure';

	if exists(select 1 from ts_meeting_list where id = p_id)then
		update ts_meeting_list set isDeleted = del_res_flag, deletedate = if(del_res_flag = 1,now(),null)
        where userid = p_userid and (id = p_id or ifnull(p_id,0)=0) ;
    End if;
		
	   if row_count()>0 then
			set v_errcode = 0;
            set v_errmsg = 'Deleted';
        End if;
    
     select v_errcode as errcode, v_errmsg as errmsg;
    
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ts_forget_password_user_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ts_forget_password_user_dtl`(
       email VARCHAR(250)
       )
Begin
       
          DECLARE verify_code VARCHAR(10) default 0;
          DECLARE errcode INT default -1; 
          DECLARE errmsg VARCHAR(250) default '';
       
          sp_exit:
          BEGIN
       
             if not exists(select 1 from ts_users_dtl a  where a.emailAddress = email LIMIT 1) then
                set errcode = -1;
                set errmsg = 'This email address not found';
                LEAVE sp_exit;
             end if;
       
             SET verify_code = right(FORMAT(RAND(),7),6);
       
             if exists(select 1 from ts_users_dtl a  where a.emailAddress = email LIMIT 1) then
       		
                UPDATE ts_users_dtl a 
                set a.verify_code = verify_code, a.expiry_time = 15,a.is_verified = 0
                where a.emailAddress = email;
                
                if ROW_COUNT() > 0 then
                   set errcode = 0;
                   set errmsg = 'success to generate pin';
                   LEAVE sp_exit;
                end if;
             end if;
             
          END;
     
          select errcode as errcode,errmsg as errmsg, verify_code as verify_code;
       
       End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ts_get_deleted_meeting_list` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ts_get_deleted_meeting_list`(
p_id int
,p_userid int
)
Begin
    
	select * from ts_meeting_list where userid = p_userid and (id = p_id or ifnull(p_id,0)=0) and isDeleted = 1 ;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ts_get_folder_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ts_get_folder_dtl`(
p_folderid int,
p_userId int
)
Begin
	select * from ts_folder_master_list where createdBy = p_userId and (folderid = p_folderid or ifnull(p_folderid,0)=0) ;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ts_get_folder_files_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ts_get_folder_files_dtl`(
p_folderid int,
p_userId int
)
Begin
	select * from ts_meeting_folder_list where userId = p_userId and (folderid = p_folderid or ifnull(p_folderid,0)=0) ;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ts_get_meeting_list` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ts_get_meeting_list`(
p_id int
,p_userid int
,p_meetingURL	text

)
Begin

	
	if exists(select 1 from ts_meeting_list where Datediff(now(),createDate) >= 30) then
		delete from ts_meeting_list where Datediff(now(),createDate) > 30;
    End if;
    
	select * from ts_meeting_list where userid = p_userid and (id = p_id or ifnull(p_id,0)=0) and isDeleted = 0 
    and (meetingURL= p_meetingURL or ifnull(p_meetingURL,0)=0);
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ts_insert_login_master_log` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ts_insert_login_master_log`(  
  p_email varchar(250),  
  p_password varchar(250),  
  p_errcode int,   
  p_errmsg varchar(250),
  p_device_type varchar(150),
  p_browser varchar(250),
  p_login_type varchar(250),
  p_login_source    VARCHAR(30),
  p_login_device_id VARCHAR(100) ,
  p_login_ipaddress VARCHAR(30),
  p_product_id int
  )
Begin  
    
   declare v_now datetime(3); 
   declare v_MyAcc_Password varchar(100);  
   set v_now = now(3);  
    
   insert into ts_login_master_log (email,password,errcode,errmsg,create_date,device_type,browser,login_type,login_source,login_device_id,login_ipaddress,product_id)  
   values(p_email,p_password,p_errcode,p_errmsg,v_now,p_device_type,p_browser,p_login_type,p_login_source,p_login_device_id,p_login_ipaddress,p_product_id);  
    
  End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ts_insert_update_folder_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ts_insert_update_folder_dtl`(
   p_folderid int,
   p_foldername varchar(100),
   p_createdBy int
   )
Begin
   	declare v_errcode int default -1;
       declare v_errmsg varchar(100) default 'failure';
       declare v_id int;
       
       select folderid into v_id from ts_folder_master_list where folderid = p_folderid limit 1;
       
       sp_exit:begin
       if v_id is null then
   		insert into ts_folder_master_list( foldername,  createdBy)
           values(p_foldername,  p_createdBy);
           
           set v_id = last_insert_id();
           
           if row_count()>0 then
   			set v_errcode = 0;
               set v_errmsg = 'Inserted';
           End if;
            
       Else
       
   		if exists(select 1 from ts_folder_master_list where foldername = p_foldername and folderid <> p_folderid and createdBy = p_createdBy) then
   			set v_errcode = -1;
   			set v_errmsg = 'Folder name already exists'; 
               leave sp_exit;
           end if;
       
   		update ts_folder_master_list
   			set foldername = ifnull(p_foldername,foldername)
           where folderid = p_folderid and createdBy = p_createdBy;
   		
           set v_errcode = 0;
   		set v_errmsg = 'Updated';
               
       End if;
       
       End;
       select v_errcode as errcode, v_errmsg as errmsg,ifnull(v_id,0) as folderid;
   End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ts_insert_update_meeting_list` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ts_insert_update_meeting_list`(
p_id int
,p_userid int
,p_title varchar(100)
,p_meetingURL text
,p_summary text
,p_participantPerformance json
,p_transcriptKeyword text
,p_transcriptSpeakers json
,p_recordedMeeting json
,p_highlights json
,p_type int 
)
Begin
	declare v_errcode int default -1;
    declare v_errmsg varchar(100) default 'Failure';
    declare v_id int;
    
    if p_type = 1 then
		select id into v_id from ts_meeting_list where meetingURL = p_meetingURL limit 1;
    Else
		set v_id = null;
    End if;
    
    if v_id is null then
		insert into ts_meeting_list (title, userid, meetingURL, summary, participantPerformance, transcriptKeyword, transcriptSpeakers, recordedMeeting, highlights)
        values(p_title, p_userid, p_meetingURL, p_summary, p_participantPerformance, p_transcriptKeyword, p_transcriptSpeakers, p_recordedMeeting, p_highlights);
        
        if row_count()>0 then
			set v_errcode = 0;
            set v_errmsg = 'Inserted';
        End if;
	Else
		update ts_meeting_list
			set userid = ifnull(p_userid,p_userid)
				,summary= ifnull(p_summary,summary)	
				,participantPerformance= ifnull(p_participantPerformance,participantPerformance)
				,transcriptKeyword= ifnull(p_transcriptKeyword,transcriptKeyword)	
				,transcriptSpeakers	= ifnull(p_transcriptSpeakers,transcriptSpeakers)
				,recordedMeeting= ifnull(p_recordedMeeting,recordedMeeting)	
				,isDeleted	= ifnull(p_isDeleted,isDeleted)
				,highlights= ifnull(p_highlights,highlights)
				,updatedAt = now()
        where meetingURL = p_meetingURL;
        
        set v_errcode = 0;
		set v_errmsg = 'Updated'; 
        
    End if;
		
    select v_errcode as errcode, v_errmsg as errmsg;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ts_insert_update_user_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ts_insert_update_user_dtl`(
     p_firstname varchar(100),
     p_lastname varchar(100),
     p_emailAddress varchar(100),
     p_password varchar(50),
     p_source varchar(20),
     p_companyName varchar(150),
     p_companySize varchar(10),
     p_industry varchar(100),
     p_country varchar(100),
     p_profpicUrl text,
     p_token text
     )
Begin
     
  		declare v_errcode int;
  		declare v_errmsg varchar(50);
         declare v_userid int;
         
  		DECLARE EXIT HANDLER FOR SQLEXCEPTION
  		BEGIN
  			SHOW ERRORS;
  			ROLLBACK;   
  		END; 
           START TRANSACTION;
     	if not exists(select 1 from ts_users_dtl where emailAddress = p_emailAddress limit 1) then
     		insert into ts_users_dtl ( firstname, lastname, emailAddress,  password,  source, companyName, companySize, industry, country, profpicUrl, token)
             values(p_firstname, p_lastname, p_emailAddress,  p_password, p_source, p_companyName, p_companySize, p_industry, p_country, p_profpicUrl, p_token);
             
             set  v_userid = LAST_INSERT_ID();
             
             if row_count()>0 then
     			set v_errcode = 0;
                 set v_errmsg = 'Inserted';           
             End if;
             
     	else
     		update ts_users_dtl a
     		set  
     			a.firstname = ifnull(p_firstname, a.firstname)
     			,a.lastname = ifnull(p_lastname, a.lastname)
     			,a.password = ifnull(p_password,a.password)
     			,a.source = ifnull(p_source,a.source)
                 ,a.companyName = ifnull(p_companyName, a.companyName)
     			,a.companySize = ifnull(p_companySize,a.companySize)
     			,a.industry = ifnull(p_industry,a.industry)
     			,a.country = ifnull(p_country,a.country)
     			,a.profpicUrl = ifnull(p_profpicUrl,a.profpicUrl)
              ,a.token = ifnull(p_token,a.token)
     		where emailAddress = p_emailAddress;
     
     		if row_count()>0 then
     			set v_errcode = 0;
     			set v_errmsg = 'Updated';
     		End if;
         End if;
         
         COMMIT;    
     	select v_errcode as errcode, v_errmsg as errmsg,ifnull(v_userid,0) as userid;
     End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ts_move_meeting_to_folder` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ts_move_meeting_to_folder`(
p_id int,
p_folderId int,
p_userId int,
p_meetingId int,
p_type int 
)
Begin
	declare v_errcode int default -1;
    declare v_errmsg varchar(50) default 'Failure';
    
    
    if p_type = 1 then
		insert into ts_meeting_folder_list(userId, meetingId, folderId)
		values(p_userId, p_meetingId, p_folderId);
        
        if row_count()>0 then
			set v_errcode = 1;
			set v_errmsg = 'Inserted';
        end if;
        
    Elseif p_type = 2 then
		update ts_meeting_folder_list
        set folderId = ifnull(p_folderId,folderId)
        where id = p_id;
        
        if row_count()>0 then
			set v_errcode = 2;
			set v_errmsg = 'Meeting moved to another folder';
        end if;
        
	ElseIf p_type = 3 then
		delete from ts_meeting_folder_list where id = p_id;
        
        if row_count()>0 then
			set v_errcode = 3;
			set v_errmsg = 'File removed';
        end if;
        
    End if;
    
    select v_errcode as errcode, v_errmsg as errmsg;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ts_update_user_password_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ts_update_user_password_dtl`(
p_emailAddress varchar(100),
p_password varchar(50)
)
Begin
		declare v_errcode int default -1;
  		declare v_errmsg varchar(50) default 'No record found';

		sp_exit:begin
		if not exists(select 1 from ts_users_dtl where emailAddress = p_emailAddress limit 1) then
			leave sp_exit;
        End if;
        
			update ts_users_dtl a
			set a.password = ifnull(p_password,a.password)
			where emailAddress = p_emailAddress;
            
            set v_errcode = 0;
			set v_errmsg = 'Updated';
			
		End;

			select v_errcode as errcode, v_errmsg as errmsg; 
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ts_user_login_validation` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ts_user_login_validation`(
   	p_email VARCHAR(250)
   	,p_password VARCHAR(50)
   	,source varchar(50)
   	,signintype tinyint 
	,device_id varchar(50)
   )
sp_return: Begin
          
   	   declare v_found int;
   	   declare v_company_id int;

          			if not exists(select 1 from ts_users_dtl a where emailAddress = p_email limit 1)then
          				select -1 as errcode, 'User not found' as errmsg;
          				leave sp_return;
          			end if;
                   
                   if signintype=0 then
         				if exists(select 1 from ts_users_dtl a where emailAddress = p_email and BINARY password <> p_password) then
         					select -1 as errcode, 'Incorrect Password' as errmsg;
         					leave sp_return;
         				end if;
       			
         				select 1 into v_found from ts_users_dtl where emailAddress = p_email and BINARY password = p_password and status = 1 ;
         				
         				if v_found is null then
         					select -1 as errcode, 'Inactive / wrong Password' as errmsg;
         					leave sp_return;
						End if;
					End if;
						
					select 0 as errcode, 'Login successfully' as errmsg,a.*
					from ts_users_dtl a                     
					where a.emailAddress = p_email 
					and ((BINARY a.password = p_password and signintype = 0) or (signintype = 1))
					and status = 1 ; 
					 
					 call ts_insert_login_master_log (p_email,p_password,0,'Login successfully','','','',source,device_id,'',null);
          
          	End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ts_validate_signup_user_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ts_validate_signup_user_dtl`(
       email VARCHAR(250),
       verify_code VARCHAR(10)
       )
Begin
       
          DECLARE errcode INT; 
          DECLARE errmsg VARCHAR(250);
          DECLARE now DATETIME(3);
          Declare Timediff int; 
          Declare v_expiry_time int; 
          Declare v_create_time datetime(3);
          
          sp_exit:
          BEGIN
             set errcode = -1;
             set errmsg = '';
             set now = CURRENT_TIMESTAMP;
             
             if not exists(select * from ts_users_dtl a  where a.emailAddress = email LIMIT 1) then
       		
                set errcode = 0;
                set errmsg = 'Incorrect email address';
                LEAVE sp_exit;
             end if;
             
             if exists(select * from ts_users_dtl a  where a.emailAddress = email and a.verify_code <> verify_code LIMIT 1) then
       		
                set errcode = 0;
                set errmsg = 'Invalid OTP';
                LEAVE sp_exit;
             end if;
             
             if exists(select * from ts_users_dtl a  where a.emailAddress = email and a.verify_code = verify_code and a.is_verified = 0 LIMIT 1) then
             
     			select a.expiry_time, a.createDate into v_expiry_time, v_create_time
     			from ts_users_dtl a where a.emailAddress = email and a.verify_code = verify_code  
     			limit 1;
     
     			set Timediff = timestampdiff(MINUTE,v_create_time,NOW(3));  
     
     			if v_expiry_time <  Timediff Then  
     				set errcode = -1;  
     				set errmsg = 'OTP has expired, please click on Resend code to continue';  
     				leave sp_exit;
     			End if;  
                 
                set errcode = 0;
                set errmsg = 'Success : Email verified';
                
                UPDATE ts_users_dtl a set a.is_verified = 1
                where a.emailAddress = email and a.verify_code = verify_code;
                LEAVE sp_exit;
             end if;
             
          END;
          select errcode as errcode,errmsg as errmsg; 
       
       End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-21  9:57:07
