-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: routingv3
-- ------------------------------------------------------
-- Server version	8.0.44-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `routingv3`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `routingv3` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `routingv3`;

--
-- Table structure for table `ExchangeRateQueue`
--

DROP TABLE IF EXISTS `ExchangeRateQueue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ExchangeRateQueue` (
  `Queueid` int NOT NULL AUTO_INCREMENT,
  `UploadFileName` text,
  `Uploaddate` datetime DEFAULT NULL,
  `UploadedBy` varchar(40) DEFAULT NULL,
  `Operator` varchar(64) DEFAULT NULL,
  `Currency` varchar(3) DEFAULT NULL,
  `Price` float DEFAULT NULL,
  `Percentage` int DEFAULT NULL,
  `Status` int DEFAULT NULL,
  PRIMARY KEY (`Queueid`)
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ExchangeRateQueueLog`
--

DROP TABLE IF EXISTS `ExchangeRateQueueLog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ExchangeRateQueueLog` (
  `Queueid` int NOT NULL AUTO_INCREMENT,
  `UploadFileName` text,
  `Uploaddate` datetime DEFAULT NULL,
  `UploadedBy` varchar(40) DEFAULT NULL,
  `Operator` varchar(64) DEFAULT NULL,
  `Currency` varchar(3) DEFAULT NULL,
  `Price` float DEFAULT NULL,
  PRIMARY KEY (`Queueid`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Objects`
--

DROP TABLE IF EXISTS `Objects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Objects` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ns` varchar(16) DEFAULT NULL,
  `cls` varchar(16) DEFAULT NULL,
  `name` varchar(32) DEFAULT NULL,
  `secType` int DEFAULT NULL,
  `sec` varchar(64) DEFAULT NULL,
  `LastUpdate` datetime DEFAULT NULL,
  `LastUser` varchar(16) DEFAULT NULL,
  `Seq` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=193 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `R20_ROUTE01`
--

DROP TABLE IF EXISTS `R20_ROUTE01`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `R20_ROUTE01` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parentId` int DEFAULT NULL,
  `state` int NOT NULL,
  `reason` int DEFAULT NULL,
  `routeCls` int NOT NULL,
  `oprId` int NOT NULL,
  `pc` varchar(2) NOT NULL,
  `prefixCode` varchar(16) NOT NULL,
  `prefixLen` int NOT NULL,
  `destCode` varchar(32) DEFAULT NULL,
  `clsOrg` varchar(2) NOT NULL,
  `cls` varchar(2) NOT NULL,
  `costOrgCurr` varchar(4) NOT NULL,
  `costOrg` float NOT NULL,
  `cost` float NOT NULL,
  `priority` float NOT NULL,
  `access` int NOT NULL,
  `quality` float DEFAULT NULL,
  `rating` int DEFAULT NULL,
  `flag` int NOT NULL,
  `ext` int DEFAULT NULL,
  `lastUpd` datetime NOT NULL,
  `lastUpdBy` varchar(16) NOT NULL,
  `exception` int DEFAULT '0',
  `exceptionCls` int DEFAULT '0',
  `lastLock` datetime DEFAULT NULL,
  `lastLockBy` varchar(50) DEFAULT NULL,
  `uploadDate` datetime DEFAULT NULL,
  `uploadBy` varchar(100) DEFAULT NULL,
  `UpdateFlag` smallint DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `routeCls` (`routeCls`,`oprId`,`pc`,`cls`),
  KEY `idx_list` (`routeCls`,`pc`,`prefixCode`)
) ENGINE=InnoDB AUTO_INCREMENT=317563 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `R20_ROUTE02`
--

DROP TABLE IF EXISTS `R20_ROUTE02`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `R20_ROUTE02` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parentId` int DEFAULT NULL,
  `state` int NOT NULL,
  `reason` int DEFAULT NULL,
  `routeCls` int NOT NULL,
  `oprId` int NOT NULL,
  `pc` varchar(2) NOT NULL,
  `prefixCode` varchar(16) NOT NULL,
  `prefixLen` int NOT NULL,
  `destCode` varchar(32) DEFAULT NULL,
  `clsOrg` varchar(2) NOT NULL,
  `cls` varchar(2) NOT NULL,
  `costOrgCurr` varchar(4) NOT NULL,
  `costOrg` float NOT NULL,
  `cost` float NOT NULL,
  `priority` float NOT NULL,
  `access` int NOT NULL,
  `quality` float DEFAULT NULL,
  `rating` int DEFAULT NULL,
  `flag` int NOT NULL,
  `ext` int DEFAULT NULL,
  `lastUpd` datetime NOT NULL,
  `lastUpdBy` varchar(16) NOT NULL,
  `exception` int DEFAULT '0',
  `exceptionCls` int DEFAULT '0',
  `lastLock` datetime DEFAULT NULL,
  `lastLockBy` varchar(50) DEFAULT NULL,
  `uploadDate` datetime DEFAULT NULL,
  `uploadBy` varchar(100) DEFAULT NULL,
  `UpdateFlag` smallint DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `routeCls` (`routeCls`,`oprId`,`pc`,`cls`),
  KEY `idx_list` (`routeCls`,`pc`,`prefixCode`)
) ENGINE=InnoDB AUTO_INCREMENT=175229 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `R20_ROUTE03`
--

DROP TABLE IF EXISTS `R20_ROUTE03`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `R20_ROUTE03` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parentId` int DEFAULT NULL,
  `state` int NOT NULL,
  `reason` int DEFAULT NULL,
  `routeCls` int NOT NULL,
  `oprId` int NOT NULL,
  `pc` varchar(2) NOT NULL,
  `prefixCode` varchar(16) NOT NULL,
  `prefixLen` int NOT NULL,
  `destCode` varchar(32) DEFAULT NULL,
  `clsOrg` varchar(2) NOT NULL,
  `cls` varchar(2) NOT NULL,
  `costOrgCurr` varchar(4) NOT NULL,
  `costOrg` float NOT NULL,
  `cost` float NOT NULL,
  `priority` float NOT NULL,
  `access` int NOT NULL,
  `quality` float DEFAULT NULL,
  `rating` int DEFAULT NULL,
  `flag` int NOT NULL,
  `ext` int DEFAULT NULL,
  `lastUpd` datetime NOT NULL,
  `lastUpdBy` varchar(16) NOT NULL,
  `exception` int DEFAULT '0',
  `exceptionCls` int DEFAULT '0',
  `lastLock` datetime DEFAULT NULL,
  `lastLockBy` varchar(50) DEFAULT NULL,
  `uploadDate` datetime DEFAULT NULL,
  `uploadBy` varchar(100) DEFAULT NULL,
  `UpdateFlag` smallint DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `routeCls` (`routeCls`,`oprId`,`pc`,`cls`),
  KEY `idx_list` (`routeCls`,`pc`,`prefixCode`)
) ENGINE=InnoDB AUTO_INCREMENT=55840 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `R20_ROUTE04`
--

DROP TABLE IF EXISTS `R20_ROUTE04`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `R20_ROUTE04` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parentId` int DEFAULT NULL,
  `state` int NOT NULL,
  `reason` int DEFAULT NULL,
  `routeCls` int NOT NULL,
  `oprId` int NOT NULL,
  `pc` varchar(2) NOT NULL,
  `prefixCode` varchar(16) NOT NULL,
  `prefixLen` int NOT NULL,
  `destCode` varchar(32) DEFAULT NULL,
  `clsOrg` varchar(2) NOT NULL,
  `cls` varchar(2) NOT NULL,
  `costOrgCurr` varchar(4) NOT NULL,
  `costOrg` float NOT NULL,
  `cost` float NOT NULL,
  `priority` float NOT NULL,
  `access` int NOT NULL,
  `quality` float DEFAULT NULL,
  `rating` int DEFAULT NULL,
  `flag` int NOT NULL,
  `ext` int DEFAULT NULL,
  `lastUpd` datetime NOT NULL,
  `lastUpdBy` varchar(16) NOT NULL,
  `exception` int DEFAULT '0',
  `exceptionCls` int DEFAULT '0',
  `lastLock` datetime DEFAULT NULL,
  `lastLockBy` varchar(50) DEFAULT NULL,
  `uploadDate` datetime DEFAULT NULL,
  `uploadBy` varchar(100) DEFAULT NULL,
  `UpdateFlag` smallint DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `routeCls` (`routeCls`,`oprId`,`pc`,`cls`),
  KEY `idx_list` (`routeCls`,`pc`,`prefixCode`)
) ENGINE=InnoDB AUTO_INCREMENT=80974 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `R20_ROUTE05`
--

DROP TABLE IF EXISTS `R20_ROUTE05`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `R20_ROUTE05` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parentId` int DEFAULT NULL,
  `state` int NOT NULL,
  `reason` int DEFAULT NULL,
  `routeCls` int NOT NULL,
  `oprId` int NOT NULL,
  `pc` varchar(2) NOT NULL,
  `prefixCode` varchar(16) NOT NULL,
  `prefixLen` int NOT NULL,
  `destCode` varchar(32) DEFAULT NULL,
  `clsOrg` varchar(2) NOT NULL,
  `cls` varchar(2) NOT NULL,
  `costOrgCurr` varchar(4) NOT NULL,
  `costOrg` float NOT NULL,
  `cost` float NOT NULL,
  `priority` float NOT NULL,
  `access` int NOT NULL,
  `quality` float DEFAULT NULL,
  `rating` int DEFAULT NULL,
  `flag` int NOT NULL,
  `ext` int DEFAULT NULL,
  `lastUpd` datetime NOT NULL,
  `lastUpdBy` varchar(16) NOT NULL,
  `exception` int DEFAULT '0',
  `exceptionCls` int DEFAULT '0',
  `lastLock` datetime DEFAULT NULL,
  `lastLockBy` varchar(50) DEFAULT NULL,
  `uploadDate` datetime DEFAULT NULL,
  `uploadBy` varchar(100) DEFAULT NULL,
  `UpdateFlag` smallint DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `routeCls` (`routeCls`,`oprId`,`pc`,`cls`),
  KEY `idx_list` (`routeCls`,`pc`,`prefixCode`),
  KEY `idx2` (`oprId`,`prefixCode`,`cls`),
  KEY `idx3` (`routeCls`,`oprId`,`pc`,`prefixCode`,`cls`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `R20_ROUTE06`
--

DROP TABLE IF EXISTS `R20_ROUTE06`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `R20_ROUTE06` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parentId` int DEFAULT NULL,
  `state` int NOT NULL,
  `reason` int DEFAULT NULL,
  `routeCls` int NOT NULL,
  `oprId` int NOT NULL,
  `pc` varchar(2) NOT NULL,
  `prefixCode` varchar(16) NOT NULL,
  `prefixLen` int NOT NULL,
  `destCode` varchar(32) DEFAULT NULL,
  `clsOrg` varchar(2) NOT NULL,
  `cls` varchar(2) NOT NULL,
  `costOrgCurr` varchar(4) NOT NULL,
  `costOrg` float NOT NULL,
  `cost` float NOT NULL,
  `priority` float NOT NULL,
  `access` int NOT NULL,
  `quality` float DEFAULT NULL,
  `rating` int DEFAULT NULL,
  `flag` int NOT NULL,
  `ext` int DEFAULT NULL,
  `lastUpd` datetime NOT NULL,
  `lastUpdBy` varchar(16) NOT NULL,
  `exception` int DEFAULT '0',
  `exceptionCls` int DEFAULT '0',
  `lastLock` datetime DEFAULT NULL,
  `lastLockBy` varchar(50) DEFAULT NULL,
  `uploadDate` datetime DEFAULT NULL,
  `uploadBy` varchar(100) DEFAULT NULL,
  `UpdateFlag` smallint DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_list` (`routeCls`,`pc`,`prefixCode`),
  KEY `idx1` (`routeCls`,`oprId`,`pc`,`cls`)
) ENGINE=InnoDB AUTO_INCREMENT=599 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `R20_ROUTE07`
--

DROP TABLE IF EXISTS `R20_ROUTE07`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `R20_ROUTE07` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parentId` int DEFAULT NULL,
  `state` int NOT NULL,
  `reason` int DEFAULT NULL,
  `routeCls` int NOT NULL,
  `oprId` int NOT NULL,
  `pc` varchar(2) NOT NULL,
  `prefixCode` varchar(16) NOT NULL,
  `prefixLen` int NOT NULL,
  `destCode` varchar(32) DEFAULT NULL,
  `clsOrg` varchar(2) NOT NULL,
  `cls` varchar(2) NOT NULL,
  `costOrgCurr` varchar(4) NOT NULL,
  `costOrg` float NOT NULL,
  `cost` float NOT NULL,
  `priority` float NOT NULL,
  `access` int NOT NULL,
  `quality` float DEFAULT NULL,
  `rating` int DEFAULT NULL,
  `flag` int NOT NULL,
  `ext` int DEFAULT NULL,
  `lastUpd` datetime NOT NULL,
  `lastUpdBy` varchar(16) NOT NULL,
  `exception` int DEFAULT '0',
  `exceptionCls` int DEFAULT '0',
  `lastLock` datetime DEFAULT NULL,
  `lastLockBy` varchar(50) DEFAULT NULL,
  `uploadDate` datetime DEFAULT NULL,
  `uploadBy` varchar(100) DEFAULT NULL,
  `UpdateFlag` smallint DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_list` (`routeCls`,`pc`,`prefixCode`),
  KEY `idx1` (`routeCls`,`oprId`,`pc`,`cls`)
) ENGINE=InnoDB AUTO_INCREMENT=125 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `R20_ROUTE08`
--

DROP TABLE IF EXISTS `R20_ROUTE08`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `R20_ROUTE08` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parentId` int DEFAULT NULL,
  `state` int NOT NULL,
  `reason` int DEFAULT NULL,
  `routeCls` int NOT NULL,
  `oprId` int NOT NULL,
  `pc` varchar(2) NOT NULL,
  `prefixCode` varchar(16) NOT NULL,
  `prefixLen` int NOT NULL,
  `destCode` varchar(32) DEFAULT NULL,
  `clsOrg` varchar(2) NOT NULL,
  `cls` varchar(2) NOT NULL,
  `costOrgCurr` varchar(4) NOT NULL,
  `costOrg` float NOT NULL,
  `cost` float NOT NULL,
  `priority` float NOT NULL,
  `access` int NOT NULL,
  `quality` float DEFAULT NULL,
  `rating` int DEFAULT NULL,
  `flag` int NOT NULL,
  `ext` int DEFAULT NULL,
  `lastUpd` datetime NOT NULL,
  `lastUpdBy` varchar(16) NOT NULL,
  `exception` int DEFAULT '0',
  `exceptionCls` int DEFAULT '0',
  `lastLock` datetime DEFAULT NULL,
  `lastLockBy` varchar(50) DEFAULT NULL,
  `uploadDate` datetime DEFAULT NULL,
  `uploadBy` varchar(100) DEFAULT NULL,
  `UpdateFlag` smallint DEFAULT '0',
  `opr_cost` float DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `routeCls` (`routeCls`,`oprId`,`pc`,`cls`),
  KEY `idx_list` (`routeCls`,`pc`,`prefixCode`),
  KEY `idx2` (`oprId`,`prefixCode`,`cls`),
  KEY `idx3` (`routeCls`,`oprId`,`pc`,`prefixCode`,`cls`)
) ENGINE=InnoDB AUTO_INCREMENT=185654643 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `R20_ROUTE09`
--

DROP TABLE IF EXISTS `R20_ROUTE09`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `R20_ROUTE09` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parentId` int DEFAULT NULL,
  `state` int NOT NULL,
  `reason` int DEFAULT NULL,
  `routeCls` int NOT NULL,
  `oprId` int NOT NULL,
  `pc` varchar(2) NOT NULL,
  `prefixCode` varchar(16) NOT NULL,
  `prefixLen` int NOT NULL,
  `destCode` varchar(32) DEFAULT NULL,
  `clsOrg` varchar(2) NOT NULL,
  `cls` varchar(2) NOT NULL,
  `costOrgCurr` varchar(4) NOT NULL,
  `costOrg` float NOT NULL,
  `cost` float NOT NULL,
  `priority` float NOT NULL,
  `access` int NOT NULL,
  `quality` float DEFAULT NULL,
  `rating` int DEFAULT NULL,
  `flag` int NOT NULL,
  `ext` int DEFAULT NULL,
  `lastUpd` datetime NOT NULL,
  `lastUpdBy` varchar(16) NOT NULL,
  `exception` int DEFAULT '0',
  `exceptionCls` int DEFAULT '0',
  `lastLock` datetime DEFAULT NULL,
  `lastLockBy` varchar(50) DEFAULT NULL,
  `uploadDate` datetime DEFAULT NULL,
  `uploadBy` varchar(100) DEFAULT NULL,
  `UpdateFlag` smallint DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `routeCls` (`routeCls`,`oprId`,`pc`,`cls`),
  KEY `idx_list` (`routeCls`,`pc`,`prefixCode`)
) ENGINE=InnoDB AUTO_INCREMENT=8512 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `R20_ROUTE10`
--

DROP TABLE IF EXISTS `R20_ROUTE10`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `R20_ROUTE10` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parentId` int DEFAULT NULL,
  `state` int NOT NULL,
  `reason` int DEFAULT NULL,
  `routeCls` int NOT NULL,
  `oprId` int NOT NULL,
  `pc` varchar(2) NOT NULL,
  `prefixCode` varchar(16) NOT NULL,
  `prefixLen` int NOT NULL,
  `destCode` varchar(32) DEFAULT NULL,
  `clsOrg` varchar(2) NOT NULL,
  `cls` varchar(2) NOT NULL,
  `costOrgCurr` varchar(4) NOT NULL,
  `costOrg` float NOT NULL,
  `cost` float NOT NULL,
  `priority` float NOT NULL,
  `access` int NOT NULL,
  `quality` float DEFAULT NULL,
  `rating` int DEFAULT NULL,
  `flag` int NOT NULL,
  `ext` int DEFAULT NULL,
  `lastUpd` datetime NOT NULL,
  `lastUpdBy` varchar(16) NOT NULL,
  `exception` int DEFAULT '0',
  `exceptionCls` int DEFAULT '0',
  `lastLock` datetime DEFAULT NULL,
  `lastLockBy` varchar(50) DEFAULT NULL,
  `uploadDate` datetime DEFAULT NULL,
  `uploadBy` varchar(100) DEFAULT NULL,
  `UpdateFlag` smallint DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `routeCls` (`routeCls`,`oprId`,`pc`,`cls`),
  KEY `idx_list` (`routeCls`,`pc`,`prefixCode`)
) ENGINE=InnoDB AUTO_INCREMENT=153685 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `R20_ROUTE11`
--

DROP TABLE IF EXISTS `R20_ROUTE11`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `R20_ROUTE11` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parentId` int DEFAULT NULL,
  `state` int NOT NULL,
  `reason` int DEFAULT NULL,
  `routeCls` int NOT NULL,
  `oprId` int NOT NULL,
  `pc` varchar(2) NOT NULL,
  `prefixCode` varchar(16) NOT NULL,
  `prefixLen` int NOT NULL,
  `destCode` varchar(32) DEFAULT NULL,
  `clsOrg` varchar(2) NOT NULL,
  `cls` varchar(2) NOT NULL,
  `costOrgCurr` varchar(4) NOT NULL,
  `costOrg` float NOT NULL,
  `cost` float NOT NULL,
  `priority` float NOT NULL,
  `access` int NOT NULL,
  `quality` float DEFAULT NULL,
  `rating` int DEFAULT NULL,
  `flag` int NOT NULL,
  `ext` int DEFAULT NULL,
  `lastUpd` datetime NOT NULL,
  `lastUpdBy` varchar(16) NOT NULL,
  `exception` int DEFAULT '0',
  `exceptionCls` int DEFAULT '0',
  `lastLock` datetime DEFAULT NULL,
  `lastLockBy` varchar(50) DEFAULT NULL,
  `uploadDate` datetime DEFAULT NULL,
  `uploadBy` varchar(100) DEFAULT NULL,
  `UpdateFlag` smallint DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `routeCls` (`routeCls`,`oprId`,`pc`,`cls`),
  KEY `idx_list` (`routeCls`,`pc`,`prefixCode`)
) ENGINE=InnoDB AUTO_INCREMENT=48951 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `R20_ROUTE12`
--

DROP TABLE IF EXISTS `R20_ROUTE12`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `R20_ROUTE12` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parentId` int DEFAULT NULL,
  `state` int NOT NULL,
  `reason` int DEFAULT NULL,
  `routeCls` int NOT NULL,
  `oprId` int NOT NULL,
  `pc` varchar(2) NOT NULL,
  `prefixCode` varchar(16) NOT NULL,
  `prefixLen` int NOT NULL,
  `destCode` varchar(32) DEFAULT NULL,
  `clsOrg` varchar(2) NOT NULL,
  `cls` varchar(2) NOT NULL,
  `costOrgCurr` varchar(4) NOT NULL,
  `costOrg` float NOT NULL,
  `cost` float NOT NULL,
  `priority` float NOT NULL,
  `access` int NOT NULL,
  `quality` float DEFAULT NULL,
  `rating` int DEFAULT NULL,
  `flag` int NOT NULL,
  `ext` int DEFAULT NULL,
  `lastUpd` datetime NOT NULL,
  `lastUpdBy` varchar(16) NOT NULL,
  `exception` int DEFAULT '0',
  `exceptionCls` int DEFAULT '0',
  `lastLock` datetime DEFAULT NULL,
  `lastLockBy` varchar(50) DEFAULT NULL,
  `uploadDate` datetime DEFAULT NULL,
  `uploadBy` varchar(100) DEFAULT NULL,
  `UpdateFlag` smallint DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `routeCls` (`routeCls`,`oprId`,`pc`,`cls`),
  KEY `idx_list` (`routeCls`,`pc`,`prefixCode`)
) ENGINE=InnoDB AUTO_INCREMENT=520565 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `lcr_operator_dtls`
--

DROP TABLE IF EXISTS `lcr_operator_dtls`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lcr_operator_dtls` (
  `id` int NOT NULL AUTO_INCREMENT,
  `opr_name` varchar(100) NOT NULL,
  `opr_code` varchar(20) DEFAULT NULL,
  `created_by` varchar(150) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `modified_by` varchar(150) DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=130 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `lcr_view_get_route_details_log`
--

DROP TABLE IF EXISTS `lcr_view_get_route_details_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lcr_view_get_route_details_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `siteid` int DEFAULT NULL,
  `pDDI` varchar(32) DEFAULT NULL,
  `pDate` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=286 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `log`
--

DROP TABLE IF EXISTS `log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `namespace` varchar(32) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `username` varchar(32) DEFAULT NULL,
  `address` varchar(32) DEFAULT NULL,
  `msg` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=165 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `r20_reason`
--

DROP TABLE IF EXISTS `r20_reason`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `r20_reason` (
  `id` int NOT NULL AUTO_INCREMENT,
  `reasonID` int DEFAULT NULL,
  `reason` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `r20_reset`
--

DROP TABLE IF EXISTS `r20_reset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `r20_reset` (
  `resetTime` datetime NOT NULL,
  `resetBy` varchar(16) NOT NULL,
  `routecls` int NOT NULL,
  `oprid` int NOT NULL,
  `clsOrg` varchar(2) NOT NULL,
  `prefixCode` varchar(16) NOT NULL,
  `quality` float DEFAULT NULL,
  `cls` varchar(2) DEFAULT NULL,
  `exceptioncls` int DEFAULT NULL,
  PRIMARY KEY (`resetTime`,`routecls`,`oprid`,`clsOrg`,`prefixCode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `r20_routeCPrice`
--

DROP TABLE IF EXISTS `r20_routeCPrice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `r20_routeCPrice` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `pc` varchar(2) DEFAULT NULL,
  `Prefixcode` varchar(16) DEFAULT NULL,
  `cls` varchar(2) DEFAULT NULL,
  `OprId` int DEFAULT NULL,
  `Cost` float DEFAULT NULL,
  `Custom1` varchar(500) DEFAULT NULL,
  `Custom2` varchar(500) DEFAULT NULL,
  `Custom3` float DEFAULT NULL,
  `Custom4` float DEFAULT NULL,
  `reserved` varchar(250) DEFAULT NULL,
  `Custom5` float DEFAULT NULL,
  `Custom6` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `pc` (`pc`,`Prefixcode`,`cls`,`OprId`),
  KEY `IdxForView` (`Prefixcode`,`OprId`),
  KEY `Idx2` (`Prefixcode`,`cls`,`OprId`)
) ENGINE=InnoDB AUTO_INCREMENT=165899510 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `r20_route_timecls`
--

DROP TABLE IF EXISTS `r20_route_timecls`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `r20_route_timecls` (
  `id` int NOT NULL AUTO_INCREMENT,
  `routecls` int DEFAULT NULL,
  `oprId` int DEFAULT NULL,
  `cls` varchar(1) DEFAULT NULL,
  `pc` varchar(2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx1` (`routecls`,`oprId`,`cls`,`pc`)
) ENGINE=InnoDB AUTO_INCREMENT=57904 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `r_IntGroup`
--

DROP TABLE IF EXISTS `r_IntGroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `r_IntGroup` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupid` int DEFAULT NULL,
  `groupname` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `r_OperatorPrefix`
--

DROP TABLE IF EXISTS `r_OperatorPrefix`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `r_OperatorPrefix` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `OprId` int DEFAULT NULL,
  `PrefixCode` varchar(32) DEFAULT NULL,
  `Destination` varchar(32) DEFAULT NULL,
  `LastUpdate` datetime DEFAULT NULL,
  `TypeofUpdate` tinyint DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `r_operatorPrefixIdx2` (`OprId`,`PrefixCode`)
) ENGINE=InnoDB AUTO_INCREMENT=14732771 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `r_countrycode_key`
--

DROP TABLE IF EXISTS `r_countrycode_key`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `r_countrycode_key` (
  `id` int NOT NULL AUTO_INCREMENT,
  `countrycode` varchar(32) DEFAULT NULL,
  `prefixkey` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `r_daycode`
--

DROP TABLE IF EXISTS `r_daycode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `r_daycode` (
  `id` int NOT NULL AUTO_INCREMENT,
  `d1` int NOT NULL,
  `d2` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `r_domain`
--

DROP TABLE IF EXISTS `r_domain`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `r_domain` (
  `id` int NOT NULL AUTO_INCREMENT,
  `state` char(1) DEFAULT NULL,
  `universe` varchar(8) NOT NULL,
  `name` varchar(8) NOT NULL,
  `longname` varchar(32) DEFAULT NULL,
  `userinfo` varchar(128) DEFAULT NULL,
  `timezone` int DEFAULT NULL,
  `reserved` varchar(64) DEFAULT NULL,
  `update_by` varchar(50) DEFAULT NULL,
  `last_update` datetime DEFAULT NULL,
  PRIMARY KEY (`universe`,`name`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `r_groupmenu`
--

DROP TABLE IF EXISTS `r_groupmenu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `r_groupmenu` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupid` int DEFAULT NULL,
  `menuid` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=474 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `r_info`
--

DROP TABLE IF EXISTS `r_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `r_info` (
  `id` int NOT NULL AUTO_INCREMENT,
  `timezone` int DEFAULT NULL,
  `universe` varchar(8) DEFAULT NULL,
  `domain` varchar(32) DEFAULT NULL,
  `lastupdate` datetime DEFAULT NULL,
  `flag` int DEFAULT NULL,
  `seq` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `r_interface`
--

DROP TABLE IF EXISTS `r_interface`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `r_interface` (
  `id` int NOT NULL AUTO_INCREMENT,
  `state` char(1) NOT NULL,
  `universe` varchar(8) NOT NULL,
  `domain` varchar(8) NOT NULL,
  `pdomain` varchar(8) DEFAULT NULL,
  `name` varchar(32) NOT NULL,
  `group` varchar(16) NOT NULL,
  `hint` varchar(128) DEFAULT NULL,
  `routecls` int NOT NULL,
  `allowloop` int NOT NULL,
  `intcls` int DEFAULT NULL,
  `userinfo` varchar(64) DEFAULT NULL,
  `reserved` varchar(64) DEFAULT NULL,
  `prefixcls` int DEFAULT NULL,
  `type` int DEFAULT NULL,
  `UpdateFlag` smallint DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8384 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `r_interface_Addinfo`
--

DROP TABLE IF EXISTS `r_interface_Addinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `r_interface_Addinfo` (
  `id` int NOT NULL AUTO_INCREMENT,
  `oprId` int DEFAULT NULL,
  `lastUpdate` datetime DEFAULT NULL,
  `LastUpdateBy` varchar(32) DEFAULT NULL,
  `Comment` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Cons_Unique` (`oprId`),
  CONSTRAINT `Cons_FkKey` FOREIGN KEY (`oprId`) REFERENCES `r_interface` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2010 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `r_interface_V2`
--

DROP TABLE IF EXISTS `r_interface_V2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `r_interface_V2` (
  `id` int NOT NULL AUTO_INCREMENT,
  `state` char(1) DEFAULT NULL,
  `universe` varchar(8) DEFAULT NULL,
  `domain` varchar(8) DEFAULT NULL,
  `pdomain` varchar(8) DEFAULT NULL,
  `name` varchar(32) DEFAULT NULL,
  `group` varchar(16) DEFAULT NULL,
  `hint` varchar(128) DEFAULT NULL,
  `routecls` int DEFAULT NULL,
  `allowloop` int DEFAULT NULL,
  `intcls` int DEFAULT NULL,
  `userinfo` varchar(64) DEFAULT NULL,
  `reserved` varchar(64) DEFAULT NULL,
  `prefixcls` int DEFAULT NULL,
  `type` int DEFAULT NULL,
  `UpdateFlag` smallint DEFAULT NULL,
  `LastUpdate` datetime DEFAULT NULL,
  `LastUpdateBy` varchar(32) DEFAULT NULL,
  `Comment` varchar(3000) DEFAULT NULL,
  PRIMARY KEY (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=8383 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `r_menu`
--

DROP TABLE IF EXISTS `r_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `r_menu` (
  `id` int NOT NULL AUTO_INCREMENT,
  `menuID` int DEFAULT NULL,
  `parentID` int DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `pageLink` varchar(100) DEFAULT NULL,
  `status` int DEFAULT NULL,
  `menulevel` int DEFAULT NULL,
  `position` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `r_prefix1`
--

DROP TABLE IF EXISTS `r_prefix1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `r_prefix1` (
  `id` int NOT NULL AUTO_INCREMENT,
  `state` varchar(1) DEFAULT NULL,
  `pc` varchar(2) DEFAULT NULL,
  `prefixcode` varchar(17) DEFAULT NULL,
  `prefixlen` int DEFAULT NULL,
  `destcode` varchar(32) DEFAULT NULL,
  `prefixreg` varchar(8) DEFAULT NULL,
  `prefixcls` int DEFAULT NULL,
  `reserved` varchar(64) DEFAULT NULL,
  `routecls` int DEFAULT NULL,
  `interfacecls` int DEFAULT NULL,
  `local_mroute` int DEFAULT NULL,
  `local_mcost` float DEFAULT NULL,
  `tollfree_mroute` int DEFAULT NULL,
  `tollfree_mcost` float DEFAULT NULL,
  `mobile_mroute` int DEFAULT NULL,
  `mobile_mcost` float DEFAULT NULL,
  `payphone_mroute` int DEFAULT NULL,
  `payphone_mcost` float DEFAULT NULL,
  `countrycode` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=120112 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `r_prefix2`
--

DROP TABLE IF EXISTS `r_prefix2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `r_prefix2` (
  `state` varchar(1) NOT NULL,
  `pc` varchar(2) NOT NULL,
  `prefixcode` varchar(17) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `prefixlen` int NOT NULL,
  `destcode` varchar(32) NOT NULL,
  `prefixreg` varchar(8) DEFAULT NULL,
  `prefixcls` int DEFAULT NULL,
  `reserved` varchar(64) DEFAULT NULL,
  `routecls` int DEFAULT NULL,
  `interfacecls` int DEFAULT NULL,
  `local_mroute` int DEFAULT NULL,
  `local_mcost` double DEFAULT NULL,
  `tollfree_mroute` int DEFAULT NULL,
  `tollfree_mcost` double DEFAULT NULL,
  `mobile_mroute` int DEFAULT NULL,
  `mobile_mcost` double DEFAULT NULL,
  `payphone_mroute` int DEFAULT NULL,
  `payphone_mcost` double DEFAULT NULL,
  `countrycode` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`prefixcode`),
  KEY `idx1` (`pc`,`prefixlen`),
  KEY `idx2` (`prefixlen`,`pc`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `r_prefix_intest`
--

DROP TABLE IF EXISTS `r_prefix_intest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `r_prefix_intest` (
  `state` varchar(1) NOT NULL,
  `prefixcode` varchar(17) NOT NULL,
  `destcode` varchar(32) NOT NULL,
  `userinfo` varchar(64) DEFAULT NULL,
  `sname` varchar(16) DEFAULT NULL,
  `sunit` varchar(16) DEFAULT NULL,
  `sgroup` varchar(32) DEFAULT NULL,
  `sdomain` varchar(8) DEFAULT NULL,
  `suniverse` varchar(8) DEFAULT NULL,
  `tname` varchar(16) DEFAULT NULL,
  `tunit` varchar(16) DEFAULT NULL,
  `tgroup` varchar(32) DEFAULT NULL,
  `tdomain` varchar(8) DEFAULT NULL,
  `tuniverse` varchar(8) DEFAULT NULL,
  PRIMARY KEY (`prefixcode`),
  KEY `state` (`state`,`prefixcode`,`destcode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `r_rating`
--

DROP TABLE IF EXISTS `r_rating`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `r_rating` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tintid` int DEFAULT NULL,
  `prefixcode` varchar(17) DEFAULT NULL,
  `rating` int DEFAULT NULL,
  `varInt` int DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `r_rating_country`
--

DROP TABLE IF EXISTS `r_rating_country`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `r_rating_country` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tintid` int DEFAULT NULL,
  `countrycode` varchar(32) DEFAULT NULL,
  `type` int DEFAULT NULL,
  `rating` int DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `r_timecls`
--

DROP TABLE IF EXISTS `r_timecls`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `r_timecls` (
  `id` int NOT NULL AUTO_INCREMENT,
  `state` varchar(1) DEFAULT NULL,
  `tintid` int NOT NULL,
  `cls` varchar(1) NOT NULL,
  `dc` int NOT NULL,
  `tc` int NOT NULL,
  `sc` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx1` (`tintid`,`cls`,`dc`,`tc`,`sc`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=15514 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `r_timecode`
--

DROP TABLE IF EXISTS `r_timecode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `r_timecode` (
  `id` int NOT NULL AUTO_INCREMENT,
  `h1` int NOT NULL,
  `h2` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2655 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `r_userlogin`
--

DROP TABLE IF EXISTS `r_userlogin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `r_userlogin` (
  `id` int NOT NULL AUTO_INCREMENT,
  `login` varchar(32) DEFAULT NULL,
  `groupid` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `request_status`
--

DROP TABLE IF EXISTS `request_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `request_status` (
  `id` int NOT NULL AUTO_INCREMENT,
  `status` int DEFAULT NULL,
  `comment` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `route_config`
--

DROP TABLE IF EXISTS `route_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `route_config` (
  `id` int NOT NULL AUTO_INCREMENT,
  `clsid` int DEFAULT NULL,
  `set` varchar(32) DEFAULT NULL,
  `threshold1` float DEFAULT NULL,
  `threshold2` float DEFAULT NULL,
  `prefix` varchar(32) DEFAULT NULL,
  `routename` varchar(50) DEFAULT NULL,
  `webstatus` int DEFAULT NULL,
  `routetype` int DEFAULT NULL,
  `dbname` varchar(100) DEFAULT NULL,
  `curRoute` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sites`
--

DROP TABLE IF EXISTS `sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sites` (
  `siteid` int NOT NULL AUTO_INCREMENT,
  `domain` varchar(10) DEFAULT NULL,
  `sitename` varchar(50) DEFAULT NULL,
  `linkedserver` varchar(100) DEFAULT NULL,
  `status` int DEFAULT NULL,
  `dbname` varchar(50) DEFAULT NULL,
  `sitecode` varchar(10) DEFAULT NULL,
  `LinkEspPrm` varchar(100) DEFAULT NULL,
  `DBEspPrm` varchar(100) DEFAULT NULL,
  `serverAddress` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`siteid`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sms_notif_list`
--

DROP TABLE IF EXISTS `sms_notif_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sms_notif_list` (
  `idx` int NOT NULL AUTO_INCREMENT,
  `smslink` text,
  `mobileno` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`idx`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `staging_sheet1`
--

DROP TABLE IF EXISTS `staging_sheet1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `staging_sheet1` (
  `id` int NOT NULL AUTO_INCREMENT,
  `record_date` datetime DEFAULT NULL,
  `trunkout` varchar(50) DEFAULT NULL,
  `destcode` varchar(100) DEFAULT NULL,
  `prefixcode` varchar(50) DEFAULT NULL,
  `routecls` varchar(50) DEFAULT NULL,
  `did` varchar(50) DEFAULT NULL,
  `ani` varchar(50) DEFAULT NULL,
  `dialednum` varchar(50) DEFAULT NULL,
  `calls` int DEFAULT NULL,
  `talktime_inmin` float DEFAULT NULL,
  `callcost` float DEFAULT NULL,
  `acd` float DEFAULT NULL,
  `rate` float DEFAULT NULL,
  `cost` float DEFAULT NULL,
  `import_status` tinyint DEFAULT '0',
  `import_error` varchar(500) DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_staging1_prefixcode` (`prefixcode`),
  KEY `idx_staging1_status` (`import_status`)
) ENGINE=InnoDB AUTO_INCREMENT=93013 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `staging_sheet2`
--

DROP TABLE IF EXISTS `staging_sheet2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `staging_sheet2` (
  `id` int NOT NULL AUTO_INCREMENT,
  `trunkout` varchar(50) DEFAULT NULL,
  `destcode` varchar(100) DEFAULT NULL,
  `prefixcode` varchar(50) DEFAULT NULL,
  `routecls` varchar(50) DEFAULT NULL,
  `did` varchar(50) DEFAULT NULL,
  `import_status` tinyint DEFAULT '0',
  `import_error` varchar(500) DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_staging2_prefixcode` (`prefixcode`),
  KEY `idx_staging2_status` (`import_status`)
) ENGINE=InnoDB AUTO_INCREMENT=15624 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_upload_lcr_rates_dtl`
--

DROP TABLE IF EXISTS `tb_upload_lcr_rates_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_upload_lcr_rates_dtl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `operatorName` varchar(20) DEFAULT NULL,
  `timeClass` char(1) DEFAULT NULL,
  `effFrom` date DEFAULT NULL,
  `requestType` int DEFAULT NULL,
  `currency` char(3) DEFAULT NULL,
  `isNotToRoute` char(1) DEFAULT NULL,
  `prefix` varchar(16) DEFAULT NULL,
  `LCR_price` float DEFAULT NULL,
  `destination` varchar(150) DEFAULT NULL,
  `createdAt` datetime DEFAULT CURRENT_TIMESTAMP,
  `uploaded` tinyint DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping events for database 'routingv3'
--

--
-- Dumping routines for database 'routingv3'
--
/*!50003 DROP PROCEDURE IF EXISTS `es07_get_prefix` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `es07_get_prefix`(
	pDDI varchar(32)
)
begin
   select * 
   from r_prefix2  
   where (pc=substring(pDDI, 1, 2))
   and state='I'
   and pDDI like concat(prefixcode,'%')
   order by prefixlen desc limit 1;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `lcr_get_reason` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `lcr_get_reason`()
begin
	call r_getreason();
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `lcr_update_routing_status` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `lcr_update_routing_status`(
id int,
status int,
login varchar(32),
rset varchar(100),
interface varchar(100),
domain varchar(100),
cls varchar(20),
prefixcode varchar(200) ,
reason int,
exception int,
lockstatus int,
lockpfx varchar(40),
grade float,
dtmf int
)
BEGIN
	
	

	if lockpfx is null then set lockpfx=''; end if;		
	if reason is null then set reason=0; end if;		
	if grade=0 then set grade=null; end if;		
	if dtmf=0 then set dtmf=null; end if;
	if lockstatus='' then set lockstatus=null; End if;
		

	call r_routing_updatestatus_new_v2 (id,status,login,rset,interface,domain,cls,prefixcode,
	reason,exception,lockstatus,lockstatus,grade,dtmf);
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `lcr_user_login_check` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `lcr_user_login_check`(
user_name varchar(20),
password varchar(20),
namespace varchar(150),
remote_address varchar(61)
)
BEGIN
	
	call routingv3.um1_user_checkPassword_v2 (namespace,user_name,password,remote_address);
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `lcr_view_domain_list` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `lcr_view_domain_list`()
BEGIN
	
	call routingv3.RDOMAIN_list();
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `lcr_view_domain_search` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `lcr_view_domain_search`(
pUniverse varchar(32),
pName varchar(32)
)
BEGIN
	call routingv3.RDOMAIN_get (pUniverse,pName);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `lcr_view_get_route_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `lcr_view_get_route_details`(
 siteid int,            
 pDDI varchar(32),                                        
 pDate datetime,
 search_flag int 
)
BEGIN
	

	if search_flag is null then
		set search_flag = 1;
	End if;
	
	insert into lcr_view_get_route_details_log(siteid,pDDI,pDate) values(siteid,pDDI,pDate);
	
	if search_flag=1 then set pDate=current_timestamp(); end if;		
	if search_flag=2 then set pDate= cast(concat(current_date(),' 02:00:00') as datetime); end if;
	if search_flag=3 then set pDate=cast(concat(current_date(),' 03:00:00') as datetime); end if;
	
	call r21_get_route_v2 (siteid,pDDI,pDate,'','','',0,'',0,'r20_route06',99.0);
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `log_add` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `log_add`(
   pUserName   varchar(32),
   pMsg        varchar(32),
   pRemoteInfo varchar(64)  
)
begin  
	if pUserName is null then  
	   set pUserName=SYSTEM_USER();
	End if;

	IF pRemoteInfo IS NULL then
	   SET pRemoteInfo = @@HOSTNAME;  
	End if;
	 
	insert routingv3.log(namespace, `date`, username, address, msg)  
	values('LONDON', current_timestamp(), pUserName, pRemoteInfo, pMsg) ; 

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `operator_list` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `operator_list`(
domain varchar(8)
)
begin
	select id,name from r_interface a where a.domain=domain order by name;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r20_route_view_v2` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `r20_route_view_v2`(
  datefrom datetime,
  dateto datetime,
  operator varchar(100),
  cls varchar(5),
  prefixcls int
 )
sp_return: begin
  
  	declare strquery varchar(5000);
  	declare oprid int;
  
  	
  
  	if (datefrom is null or dateto is null) and operator is null then
  		set @strquery = concat('select state status,''''  operator, prefixcode,cls timeclass,cost,lastupd,lastupdby  from R20_ROUTE08 limit 0');
  	else
  		set @strquery=concat('select a.state status,b.reserved operator,a.prefixcode,a.cls timeclass,a.cost,a.lastupd,a.lastupdby 
  						from R20_ROUTE08 a  inner join r_interface b on  a.routecls=0  ');
  		
  		if operator is not null then
  
  			select a.id into oprid from r_interface a where a.reserved=operator limit 1;
  
  			if oprid is null then
  				set oprid=-1;
  				set @strquery = concat('select state status,''''  operator, prefixcode,cls timeclass,cost,lastupd,lastupdby from R20_ROUTE08 limit 1 ');
  
  				PREPARE STMT FROM @strquery;
  				EXECUTE STMT;
  				DEALLOCATE PREPARE STMT;
  
  				leave sp_return;
  			end if;
  				set @strquery= concat(@strquery ,' and oprid=' ,cast(oprid as SIGNED INTEGER));	
  		end if;
  
  		if datefrom is not null THEN
  			set @strquery=concat(@strquery,' and lastupd between ''' , cast(datefrom as char(20)) ,''' and ''' ,  cast(dateto as char(20)) +''' ');
  		end if;
  		
  		if cls is not null then
  			set @strquery= concat(@strquery, ' and cls= ''' , cls +''' ');
  			set @strquery= concat(@strquery , ' and a.oprid=b.id');
  		end if;
  	end if;
  
  	if prefixcls is not null then
  		set @strquery= concat('select * from (' ,@strquery  ,') as a inner join r_prefix2 b  on a.prefixcode=b.prefixcode and b.prefixcls=' , cast(prefixcls as char(20)));
  	end if;
  	
  	set @strquery=concat(@strquery , ' order by cls,lastupd desc');
  
  	PREPARE STMT FROM @strquery;
  	EXECUTE STMT;
  	DEALLOCATE PREPARE STMT;
  
  end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r21_get_route` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `r21_get_route`(
   pDDI varchar(32),
   pDate datetime,
   pSrcInt varchar(7),
   pSrcIntGroup varchar(64),
   pSrcIntDom varchar(64),
   routeclass int, 
   pCLI varchar(32),
   pOperatorGroup int,
   pRouteset varchar(50),
   pGrade float,
   oprtype int
 )
begin
 	declare  longestPrefixcode varchar(32);
 	declare  longestCls int ;
 	declare  nearestTime varchar(17);
 	declare  strmonth varchar(2) ;
 	declare  strquery text;
 
 	if  routeclass is null then set  routeclass = 0; End if;
 	if  pCLI is null then set  pCLI = ''; End if;
 	if  pOperatorGroup is null then set  pOperatorGroup = 0; End if;
 	if  pGrade is null then set  pGrade = 100.00; End if;
 	if  oprtype is null then set  oprtype = 0; End if;
 
 	if  pRouteset is null then 
 	 call r_routing_getCurTbl ( pRouteSet,1); 
 	End if;
 
 	set  strmonth=right( pRouteSet,2); 
  
 	select a.prefixcode, a.prefixCls into  longestPrefixcode,  longestCls
 	from r_prefix2 a
 	where pc = left( pDDI,2) and  pDDI like concat(prefixcode,'%')
 	order by prefixlen desc limit 1;
  
 	if  longestcls is null then set  longestcls = 0 ; end if;
 	if  longestPrefixcode is null then set  longestPrefixcode='null'; end if;
  
 	call r22_routeGetNearestTime ( pDate,  nearestTime); 
 
 	if  longestcls in (3,4)  then
 
 		set  @strquery = CONCAT('CALL r24_routeSpecialGetCache_',  strmonth, ' (''',  longestprefixcode, ''', ''', CAST( nearestTime AS DATETIME), ''', ''', 
 			 pSrcInt, ''', ''',  pSrcIntGroup, ''', ''',  pSrcIntDom, ''', ''',  routeclass, ''', ''',  pcli, ''', ''', 
 			 pOperatorGroup, ''', ''', FORMAT( pGrade, 10, 2), ''');');
             
			PREPARE stmt FROM  @strquery;
			EXECUTE stmt;
			DEALLOCATE PREPARE stmt;
	
 	else 
                
		call r24_routeGetCache_08(longestprefixcode,longestCls,DATE_FORMAT( nearestTime, '%Y-%m-%d %H:%i:%s'),pSrcInt,pSrcIntGroup,pSrcIntDom,routeclass,pcli,pOperatorGroup,CAST(pGrade AS DECIMAL(10,2)),oprtype);
 
 	end if;
    
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r21_get_route_v2` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `r21_get_route_v2`(
     siteid int,
     pDDI varchar(32),
     pDate datetime,
     pSrcInt varchar(7),
     pSrcIntGroup varchar(64),
     pSrcIntDom varchar(64),
     routeclass int,
     pCLI varchar(32),
     pOperatorGroup int,   
     routeset varchar(50),
     grade float
  )
begin
  
  	
  	
  	
   
  	  
  
  	  declare linkedserver varchar(100);
  	  declare dbname varchar(100);
  	  declare strquery text;
  
  	  if routeclass is null then set routeclass=0; end if;
  	  if pCLI is null then set pCLI=''; end if;
  	  if pOperatorGroup is null then set pOperatorGroup=0; end if;
  	  if routeset is null then set routeset='R20_ROUTE06'; end if;
  	  if grade is null then set grade=99.0; end if;
  
  	if siteid=17 then
  		drop temporary table if exists tt_temp; 
  		create temporary table tt_temp 
  		(
  			routeset varchar(30),
  			calcException varchar(30),
  			priority int,
  			`id` varchar(30),
  			IsActive varchar(30),
  			Reason varchar(50),
  			exception varchar(30),
  			ext varchar(30),
  			routecls varchar(30),
  			prefixcode varchar(30),
  			universe varchar(30),
  			domain varchar(30),
  			pdomain varchar(30),
  			`group` varchar(30),
  			interface varchar(30),
  			userinfo varchar(30),
  			hint varchar(150),
  			clsOrg varchar(30),
  			timecls varchar(30),
  			cost varchar(30),
  			flag varchar(30),
  			rating varchar(30),
  			access varchar(30),
  			redlist varchar(30),
  			lastUser varchar(30),
  			UpdateFlag varchar(30),
  			OprID varchar(30),
  			lastUpd varchar(40),
  			`except` varchar(30),
  			lastlockby varchar(30),
  			lastlock varchar(30),
  			strtimecls varchar(30),
  			grade varchar(30),
  			uploaddate varchar(50),
  			uploadby varchar(50),
  			capability varchar(30),
  			dtmf varchar(30)
  		);
    
  		
  		call r21_get_route (pDDI , pDate, pSrcInt, pSrcIntGroup, pSrcIntDom, routeclass, pCLI, pOperatorGroup, routeset, grade,null);
  
  
  	select '0' LState, tc.* 
  	From tt_temp tc 
  	order by tc.priority;
  
    else  
  		select a.dbname,a.linkedserver into dbname,linkedserver from sites a where a.siteid=siteid limit 1;
  
  		      
                  
  		SET @pddi := pddi;
  		SET @psrcint := psrcint;
  		SET @pdate := pdate; 
  		SET @pSrcIntGroup := pSrcIntGroup;
  		SET @pSrcIntDom := pSrcIntDom;
  		SET @routeclass := routeclass;
  		SET @pCLI := pCLI;
  		SET @pOperatorGroup := pOperatorGroup;
  
  		SELECT @strquery=CONCAT(
  			'CALL routingV2.r21_get_Routes(',
  			QUOTE(@pddi), ', ',
  			QUOTE(CAST(@pdate AS DATE)), ', ',
  			QUOTE(@psrcint), ', ',
  			QUOTE(@pSrcIntGroup), ', ',
  			QUOTE(@pSrcIntDom), ', ',
  			QUOTE(@routeclass), ', ',
  			QUOTE(@pCLI), ', ',
  			QUOTE(@pOperatorGroup),
  			');'
  		);
  
  		PREPARE STMT FROM @strquery;
  		EXECUTE STMT;
  		DEALLOCATE PREPARE STMT;
  
   
    end if; 
  end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r21_get_route_web` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `r21_get_route_web`(
     pDDI varchar(32),  
     pDate datetime,  
     pSrcInt varchar(7),  
     pSrcIntGroup varchar(64),  
     pSrcIntDom varchar(64),  
     routeclass int,
     pCLI varchar(32),
     pOperatorGroup int,
     pRouteset varchar(50),
     pGrade float,
     oprtype int
  )
begin
  
  	declare longestPrefixcode varchar(16);  
  	declare longestCls int;  
  	declare nearestTime varchar(17);  
  	declare strmonth varchar(2);
  	declare strquery varchar(5000);
    
  	set strmonth=right(pRouteSet,2);
  
  	if routeclass is null then set routeclass=0; end if;  
  	if pCLI is null then set pCLI =''  ; end if;
  	if pOperatorGroup is null then set pOperatorGroup = 0; end if;
  	if pRouteset is null then set pRouteset='R20_ROUTE08'; end if; 
  	if pGrade is null then set pGrade=100.0; end if;
  	if oprtype is null then set oprtype =0; end if;
  
  	select a.prefixcode, a.prefixCls into longestPrefixcode, longestCls
  	from r_prefix2 a
  	where pc=left(pDDI,2) and pDDI like concat(prefixcode,'%')
  	order by prefixlen desc  limit 1;
    
  	if longestcls is null then set longestcls = 0; end if;
  	if longestPrefixcode is null then set longestPrefixcode='null'; end if; 
   
  	call r22_routeGetNearestTime (pDate, nearestTime);
  
  	if longestcls in (3,4) then
  	 
  		call r24_routeSpecialGetCache_08 (longestprefixcode,cast(nearestTime as date),pSrcInt,pSrcIntGroup,pSrcIntDom,cast(routeclass as char(50)),
  		pcli,cast(pOperatorGroup as char(30)),cast((pGrade,10,2) as char(30)));
  	else
  
  	call r24_routeGetCache_web(longestprefixcode,ltrim(longestCls),cast(nearestTime as date),pSrcInt,pSrcIntGroup,pSrcIntDom
  			,ltrim(routeclass),pcli,ltrim(pOperatorGroup),ltrim(CAST(pGrade as DECIMAL(10,2))),ltrim(oprtype));
  	end if;
  end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r22_data_getFromReset` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `r22_data_getFromReset`( 
  pOperator int,        
  pTimecls varchar(2),        
  pPrefix varchar(16),      
  INOUT grade float,
  INOUT exceptioncls int
)
begin    
	set grade=99.0;
	set exceptioncls=0;

	select ifnull(quality,99.0),ifnull(exceptioncls,0) 
	into grade,exceptioncls
	from r20_reset  
	where routecls=0 and oprid = pOperator       
    and prefixCode=pPrefix and cls=pTimecls;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r22_GotOperatorPrefix` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `r22_GotOperatorPrefix`(
  pPrefix varchar(16),  
  pDestCode varchar(32),  
  req tinyInt,
  oprId int
 )
Begin
  
  Update r_OperatorPrefix set LastUpdate = current_timestamp(),  TypeofUpdate = req where PrefixCode = pPrefix and OprId = OprID;
 
 	if (row_count() = 0) then
 		Insert into r_OperatorPrefix (PrefixCode, Destination, TypeofUpdate, OprId, LastUpdate)
 		Values (pPrefix, pDestCode, req, oprid, current_timestamp());
 	End if;
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r22_routeBlock` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `r22_routeBlock`(
	 pRouteSet varchar(16), 
	 pOperator varchar(16), 
	 pTimecls varchar(2), 
	 pPrefix varchar(16), 
	 pReason int, 
	 pUser varchar(16) 
)
sp_return:begin 
        
        	declare oprid int; 
        	declare v_where varchar(2000); 
        	declare pParentID float; 
        	declare pDest varchar(32);
        
  		set @pAdd= null;
         
        	
        	select a.id into oprid from r_interface a where a.reserved=pOperator limit 1; 
        
        	if oprid is null then
        		select -1 ErrorCode, concat('*** Operator{',pOperator,'} Not Found') as  ErrorString;
        		leave sp_return; 
        	end if;
         
        	
        	if not exists(select * from r_timecls a where a.tintid=oprid and a.cls=pTimecls LIMIT 1) then
        		select -1 ErrorCode, concat('*** Timeclass{',pTimecls,'} for Operator{',pOperator,'} Not Found') as ErrorString ;
        		leave sp_return; 
        	end if;
         
        	set pPrefix=ltrim(rtrim(pPrefix));
         
        	if pUser is null then set pUser = user(); end if; 
         
        	set v_where = concat('routecls=0 and a.oprId = ',cast(oprid as SIGNED INTEGER),' and cls=''',pTimecls,''' and pc=''' ,left(pPrefix,2),''' and prefixcode=''',pPrefix,''''); 
         
        	
        	
        	set @sql = concat('update ',pRouteSet ,' a set state=0,ext=20,reason=' , cast(pReason as SIGNED INTEGER));
        	set @sql = concat(@sql , ',lastUpd=current_timestamp(),lastUpdBy=''',pUser,'''');
        	set @sql = concat(@sql , ',UpdateFlag=0 where ' , v_where , ' and state=1 and ifnull(ext,0)=0');
      
        	PREPARE STMT FROM @sql;
        	execUTE STMT;
        	DEALLOCATE PREPARE STMT;
        
        	if row_count() > 0 then
        		call routinghistory.rh_insert (poperator,pPrefix,  pTimeCls ,10000  ,31,puser,0,pRouteSet,'') ;
        		select 0 ErrorCode, 'OK.' ErrorString, 'Previous-State is ACTIVE, Latest-State is BLOCKED' Note ;
        		leave sp_return; 
        	end if;
         
        	
        
        	set @sql = concat('update ', pRouteSet ,' a set state=0,ext=120,reason=' , cast(pReason as SIGNED INTEGER),
        	 ',lastUpd=current_timestamp(),lastUpdBy=''',pUser,''',UpdateFlag=0 where ' , v_where , ' and state=1 and ext=100');  
        	
        	PREPARE STMT FROM @sql;
        	execUTE STMT;
        	DEALLOCATE PREPARE STMT;
        
        	if row_count() > 0 then
        		call routinghistory.rh_insert (poperator,pPrefix,  pTimeCls ,10000  ,31,puser,0,pRouteSet,''); 
        		select 0 ErrorCode, 'OK.' ErrorString, 'Previous-State is ACTIVE-VIRTUAL, Latest-State is BLOCKED-VIRTUAL' Note; 
        		leave sp_return; 
        	 end if;
         
        	set @sql = concat('update ', pRouteSet ,' a set state=0,reason=' , cast(pReason as SIGNED INTEGER) ,  
        	 ',lastUpd=current_timestamp(),lastUpdBy=''',pUser,''',UpdateFlag=0 where ' , v_where , ' and state=0 and ext in (1,20)');
        
        	PREPARE STMT FROM @sql;
        	execUTE STMT;
        	DEALLOCATE PREPARE STMT;
        
        	if row_count() > 0 then
        		call routinghistory.rh_insert (poperator,pPrefix,  pTimeCls ,10000  ,31,puser,0,pRouteSet,''); 
        		select 0 ErrorCode, 'OK.' ErrorString, 'Latest-State is BLOCKED' Note ;
        		leave sp_return;
        	 end if;
         
        	set @sql = concat('update ',pRouteSet,' a set state=0,ext=120,reason=' , cast(pReason as SIGNED INTEGER) ,  
        	 ',lastUpd=current_timestamp(),lastUpdBy=''',pUser,''',UpdateFlag=0 where ' , v_where , ' and state=0 and ext in (101,120)');  
        	
        	PREPARE STMT FROM @sql;
        	execUTE STMT;
        	DEALLOCATE PREPARE STMT; 
        
        	if row_count() > 0 then
        		call routinghistory.rh_insert(poperator,pPrefix,  pTimeCls ,10000  ,31,puser,0,pRouteSet,''); 
        		select 0 ErrorCode, 'OK.' ErrorString, 'Latest-State is BLOCKED-VIRTUAL' Note ;
        		leave sp_return; 
        	 end if;
         
         drop temporary table if exists tt_temp1 ; 
        	
        	set @sql = concat('create temporary table tt_temp1 as select * from ', pRouteSet ,' a where ' , v_where , ' and state=0 and ext in (30,130)');  
        	
        	PREPARE STMT FROM @sql;
        	execUTE STMT;
        	DEALLOCATE PREPARE STMT; 
        
        	if row_count() > 0 then
        	 select -1 ErrorCode, 'OK.' ErrorString, 'Entry is currently FORBIDDEN' Note ;
        	 leave sp_return ;
        	 end if;
         
         drop temporary table if exists tt_temp1 ;
        	
        	set @sql = concat(' create temporary table tt_temp1 as select * from ', pRouteSet ,' a where ' , v_where , ' and state=0'  );
        	
        	PREPARE STMT FROM @sql;
        	execUTE STMT;
        	DEALLOCATE PREPARE STMT; 
        
        	if row_Count() > 0 then
        	 select -1 ErrorCode, 'OK.' ErrorString, 'Entry is currently BLOCKED' Note ;
        	 leave sp_return; 
        	 end if;
         
        	
         
        	
        	call r22_routeGetParent2 (pRouteSet, oprid, pTimecls, pPrefix, pParentID);
        	
        	if pParentID is null then
        	 select -1 ErrorCode, 'OK.' ErrorString, 'Nearest Entry not found' Note;
        	 leave sp_return;
        	 end if;
         
        	set @sql = concat('insert ' , pRouteSet , '(parentID,state,reason,ext,routecls,oprId,pc,prefixcode,prefixLen,clsOrg,cls' ,  
        			',costOrgCurr,costOrg,cost,priority,access,flag,lastUpd,lastUpdBy,quality,exceptioncls,UpdateFlag) ' , 
        			'select id,0,',cast(pReason as SIGNED INTEGER),',1,routecls,oprId,''', left(pPrefix,2),''',''',pPrefix,''',',char_length(pPrefix),',cls,''',pTimecls,'''', 
        			',costOrgCurr,costOrg,cost,priority,access,flag,current_timestamp(),''',pUser,''',quality,exceptioncls,0 from ' , pRouteSet , ' a where id=' , cast(pParentID as DECIMAL(10,2)) ,  
        			' and parentID is null'); 
        
        	PREPARE STMT FROM @sql;
        	execUTE STMT;
        	DEALLOCATE PREPARE STMT; 
        
        	if row_Count() = 0 then
        	 
        	 set @sql = concat('insert ' , pRouteSet , '(parentID,state,reason,ext,routecls,oprId,pc,prefixcode,prefixLen,clsOrg,cls' ,  
        				',costOrgCurr,costOrg,cost,priority,access,flag,lastUpd,lastUpdBy,uploaddate,uploadby,quality,exceptioncls,UpdateFlag) ' , 
        				'select parentId,0,',cast(pReason as SIGNED INTEGER),',1,routecls,oprId,''', left(pPrefix,2),''',''',pPrefix,''',',char_length(pPrefix),',cls,''',pTimecls,'''', 
        				',costOrgCurr,costOrg,cost,priority,access,flag,current_timestamp(),''',pUser,''',current_timestamp(),''',pUser,''',quality,exceptioncls,0 from ' , pRouteSet , ' a where id=' 
        				, cast(pParentID as DECIMAL(10,2)));  
        
        	PREPARE STMT FROM @sql;
        	execUTE STMT;
        	DEALLOCATE PREPARE STMT; 
        
 		end if;
         
        	call routinghistory.rh_insert(poperator,pPrefix,  pTimeCls ,10000  ,31,puser,0,pRouteSet,''); 
        	
        	call r22_routeGetDest (pPrefix, pDest); 
        	call r22_routePrefixNew (pPrefix, pDest,@pAdd); 
        	call r22_routeTimeclsAdd (pRouteSet,0,oprid,pTimecls,left(pPrefix,2) );
         
        	
        	select 0 ErrorCode, 'OK.' ErrorString, 'New BLOCKED-ARTIFICIAL inserted' Note ;
        end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r22_routeCheckChildOpen` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `r22_routeCheckChildOpen`(
  pRouteSet varchar(16),
  pOperator int,  
  pTimecls varchar(2),  
  pPrefix varchar(16),
  INOUT pChild varchar(16)
)
begin

	if pRouteSet = 'R20_ROUTE10' then
	  select  prefixcode into pChild 
		from R20_ROUTE10 
	   where routecls=0 and oprid=pOperator and cls=pTimecls 
		 and pc=left(pPrefix,2) and prefixcode > pPrefix
		 and pPrefix like concat(prefixcode,'%') 
		 and state=1 
	   order by prefixlen desc limit 1;
	End if;
	if pRouteSet = 'R20_ROUTE11' then
	  select  prefixcode into pChild 
		from R20_ROUTE11 
	   where routecls=0 and oprid=pOperator and cls=pTimecls 
		 and pc=left(pPrefix,2) and prefixcode > pPrefix
		 and pPrefix like concat(prefixcode,'%') 
		 and state=1 
	   order by prefixlen desc limit 1;
	End if;
	if pRouteSet = 'R20_ROUTE12' then
	  select  prefixcode into pChild 
		from R20_ROUTE12 
	   where routecls=0 and oprid=pOperator and cls=pTimecls 
		 and pc=left(pPrefix,2) and prefixcode > pPrefix
		 and pPrefix like concat(prefixcode,'%') 
		 and state=1 
	   order by prefixlen desc limit 1;
	End if;
	if pRouteSet = 'R20_ROUTE09' then
	  select  prefixcode into pChild 
		from R20_ROUTE09 
	   where routecls=0 and oprid=pOperator and cls=pTimecls 
		 and pc=left(pPrefix,2) and prefixcode > pPrefix
		 and pPrefix like concat(prefixcode,'%') 
		 and state=1 
	   order by prefixlen desc limit 1;
	End if;
	if pRouteSet = 'R20_ROUTE01' then
	  select  prefixcode into pChild 
		from R20_ROUTE01 
	   where routecls=0 and oprid=pOperator and cls=pTimecls 
		 and pc=left(pPrefix,2) and prefixcode > pPrefix
		 and pPrefix like concat(prefixcode,'%') 
		 and state=1 
	   order by prefixlen desc limit 1;
	End if;
	if pRouteSet = 'R20_ROUTE02' then
	  select  prefixcode into pChild 
		from R20_ROUTE02 
	   where routecls=0 and oprid=pOperator and cls=pTimecls 
		 and pc=left(pPrefix,2) and prefixcode > pPrefix
		 and pPrefix like concat(prefixcode,'%') 
		 and state=1 
	   order by prefixlen desc limit 1;
	End if;
	if pRouteSet = 'R20_ROUTE03' then
	  select  prefixcode into pChild 
		from R20_ROUTE03 
	   where routecls=0 and oprid=pOperator and cls=pTimecls 
		 and pc=left(pPrefix,2) and prefixcode > pPrefix
		 and pPrefix like concat(prefixcode,'%') 
		 and state=1 
	   order by prefixlen desc limit 1;
	End if;
	if pRouteSet = 'R20_ROUTE04' then
	  select  prefixcode into pChild 
		from R20_ROUTE04 
	   where routecls=0 and oprid=pOperator and cls=pTimecls 
		 and pc=left(pPrefix,2) and prefixcode > pPrefix
		 and pPrefix like concat(prefixcode,'%') 
		 and state=1 
	   order by prefixlen desc limit 1;
	End if;
	if pRouteSet = 'R20_ROUTE05' then
	  select  prefixcode into pChild 
		from R20_ROUTE05 
	   where routecls=0 and oprid=pOperator and cls=pTimecls 
		 and pc=left(pPrefix,2) and prefixcode > pPrefix
		 and pPrefix like concat(prefixcode,'%') 
		 and state=1 
	   order by prefixlen desc limit 1;
	End if;
	if pRouteSet = 'R20_ROUTE06' then
	  select  prefixcode into pChild 
		from R20_ROUTE06 
	   where routecls=0 and oprid=pOperator and cls=pTimecls 
		 and pc=left(pPrefix,2) and prefixcode > pPrefix
		 and pPrefix like concat(prefixcode,'%') 
		 and state=1 
	   order by prefixlen desc limit 1;
	End if;
	if pRouteSet = 'R20_ROUTE07' then
	  select  prefixcode into pChild 
		from R20_ROUTE07 
	   where routecls=0 and oprid=pOperator and cls=pTimecls 
		 and pc=left(pPrefix,2) and prefixcode > pPrefix
		 and pPrefix like concat(prefixcode,'%') 
		 and state=1 
	   order by prefixlen desc limit 1;
	End if;
	if pRouteSet = 'R20_ROUTE08' then
	  select  prefixcode into pChild 
		from R20_ROUTE08 
	   where routecls=0 and oprid=pOperator and cls=pTimecls 
		 and pc=left(pPrefix,2) and prefixcode > pPrefix
		 and pPrefix like concat(prefixcode,'%') 
		 and state=1 
	   order by prefixlen desc limit 1;
	End if;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r22_routeCheckNew` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `r22_routeCheckNew`(
 	pOperator int,  
 	pTimecls varchar(2),  
 	pPrefix varchar(16),
	INOUT pNew int 
)
begin

	if exists(select count(*) from r20_reset a where a.routecls=0 and a.oprid = pOperator and a.prefixCode=pPrefix limit 1) then
		set pNew = 0;
	else
		set pNew = 1;
	end if;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r22_routeExcept` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `r22_routeExcept`(
     pRouteSet varchar(16),
     pOperator varchar(16),
     pTimecls varchar(2),
     pPrefix varchar(16),
     pValue int,
     pUser varchar(16)  
    )
sp_return:begin
    
    	declare oprid int;
    	declare v_where varchar(2000);
    	declare comment varchar(150);
    	declare pParentID float;
    	declare pDest varchar(32) ;
    
    	set comment=concat('exception : ',cast(pValue as SIGNED INTEGER));
    set @pAdd = null;
    
    
    	select a.id into oprid from r_interface a where a.reserved=pOperator limit 1;
    
    	if oprid is null then
    		select -1 ErrorCode, concat('*** Operator{',pOperator,'} Not Found') as ErrorString;
    		leave sp_return;
    	end if;
    
    	set pPrefix=cast(pPrefix as char(16));
    
    	if pUser is null then set pUser = USER(); end if;
    
    	set v_where = concat('routecls=0 and a.oprId=',cast(oprid as SIGNED INTEGER),' and cls=''',pTimecls,''' and pc=''' ,left(pPrefix,2),''' and prefixcode=''',pPrefix,'''');
    
    	
    	
    	set @sql = concat('update ' , pRouteSet , ' a set exception=' ,cast(pValue as SIGNED INTEGER),',lastUpd=current_timestamp(),lastUpdBy=''',pUser,''',UpdateFlag=0 where ' , v_where , ' and ext=0'); 
    	
    		PREPARE STMT FROM @sql;
    		EXECUTE STMT;
    		DEALLOCATE PREPARE STMT;
    
    	if row_count() > 0 then
    		 call routinghistory.rh_insert(poperator,pPrefix,  pTimeCls ,10000  ,31,puser,10,pRouteSet,comment);
    		 select 0 ErrorCode, 'OK.' ErrorString, 'EXCEPTION assigned [normal route]' Note;
    		 leave sp_return;
    	 end if;
        
    	
    
    	set @sql = concat('update ' , pRouteSet , ' a set ext=ext+100,exception=' , cast(pValue as SIGNED INTEGER), ',lastUpd=current_timestamp(),lastUpdBy=''',pUser,''',UpdateFlag=0 where ' , v_where , ' and ext<100'); 
    	
    	PREPARE STMT FROM @sql;
    	EXECUTE STMT;
    	DEALLOCATE PREPARE STMT;
    
    	if row_count() > 0 then
    		call routinghistory.rh_insert(poperator,pPrefix,  pTimeCls ,10000  ,31,puser,10,pRouteSet,comment);
    		select 0 ErrorCode, 'OK.' ErrorString, 'EXCEPTION assigned' Note;
    		leave sp_return;
    	end if;
    
    	
    	set @sql = concat('update ',pRouteSet, ' a set exception=' , cast(pValue as SIGNED INTEGER) ,',lastUpd=current_timestamp(),lastUpdBy=''',pUser,''',UpdateFlag=0 where ' , v_where , ' and ext>=100'); 
    	
    	PREPARE STMT FROM @sql;
    	EXECUTE STMT;
    	DEALLOCATE PREPARE STMT;
    
    	if row_count() > 0 then
    		 call routinghistory.rh_insert(poperator,pPrefix,  pTimeCls ,10000  ,31,puser,10,pRouteSet,comment);
    		 select 0 ErrorCode, 'OK.' ErrorString, 'EXCEPTION re-assigned' Note;
    		leave sp_return;
    	 end if;
    
    	
    	call r22_routeGetParent2 (pRouteSet, oprid, pTimecls, pPrefix, pParentID);
    	
    	if pParentID is null then
    		select -1 ErrorCode, 'OK.' ErrorString, '*** Nearest Entry not found' Note;
    		leave sp_return;
    	end if;
    
    	set @sql = concat('insert ',pRouteSet, '(parentID,state,reason,ext,routecls,oprId,pc,prefixCode,prefixLen,clsOrg,clscostOrgCurr,costOrg,cost,priority,access,flag,lastUpd,lastUpdBy,uploaddate,uploadby,exception,quality,exceptioncls,UpdateFlag) 
    		select id,state,reason,ext , case when isnull(ext,0)<100 then 100 else 0 end | 1 ,routecls,oprId,''', left(pPrefix,2),''',''',pPrefix,''',',CHAR_LENGTH(CAST(pPrefix as SIGNED INTEGER)),',cls,''',pTimecls,'''',
    	 ',costOrgCurr,costOrg,cost,priority,access,flag,current_timestamp(),''',pUser,''',current_timestamp(),''',pUser,''',',CAST(pValue as SIGNED INTEGER),
    	 ',quality,exceptioncls,0 from ' , pRouteSet , ' a where id=',CAST(pParentID as FLOAT),' and parentID is null and state = 1');
    
    	PREPARE STMT FROM @sql;
    	EXECUTE STMT;
    	DEALLOCATE PREPARE STMT;
    
    	call r22_routeGetDest (pPrefix, pDest);
    	call r22_routePrefixNew (pPrefix, pDest,@pAdd);
    	call r22_routeTimeclsAdd (pRouteSet,0,oprid,pTimecls,pPrefix);
    
    	
    	call routinghistory.rh_insert(poperator,pPrefix,  pTimeCls ,10000  ,31,puser,10,pRouteSet,comment);
    	select 0 ErrorCode, 'OK.' ErrorString, 'New EXCEPTION-VIRTUAL inserted' Note;
    end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r22_routeForbid` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `r22_routeForbid`(
    pRouteSet varchar(16),
    pOperator varchar(16),
    pTimecls varchar(2),
    pPrefix varchar(16),
    pDestCode varchar(32),
    pReason int,
    pUser varchar(16)
  )
sp_return:begin
  
  	declare oprid int;
  	declare vadd int;
  	declare damsg text;
  	declare child varchar(2000);
  	declare newgrade float;
  	declare tempexceptioncls int;
  
  	if pReason is null then
  		set pReason = 1;
  	end if;
  
  	if pUser is null then
  		set pUser = 'Admin'; 
  	End if;
  
  	
  	select id into oprid from r_interface a where a.reserved=pOperator limit 1;
  
  	if oprid is null then
  		select -1 ErrorCode, concat('*** Operator{',pOperator,'} Not Found') ErrorString;
  		leave sp_return;
  	end if;
  
  	call r22_GotOperatorPrefix (pPrefix, pDestCode, 0, oprid);
  
  	Update r20_routeCPrice set cost = 99.0, Custom3 = 0.0, Custom4 = 0.0, Custom5 = 0.0
  	where  oprid= oprid and cls= pTimecls and pc=left(pPrefix,2) and prefixcode= pPrefix;
  
  	if row_count() = 0 then
  		Insert into r20_routeCPrice (pc, Prefixcode, cls, Oprid, Cost, Custom3, Custom4, Custom5) 
  		values(left(pPrefix, 2), pPrefix, pTimecls, oprId, 99.0, 0.0, 0.0, 0.0);
  	end if;
  
  	set damsg='';
  
  	call r23_routeHigherGetDel ('R20_ROUTE08', oprid, pTimecls, pPrefix, damsg);
  
  	call r22_routeCheckChildOpen ('R20_ROUTE08', oprid, pTimecls, pPrefix, child);
  	
  	if child is not null then
  	  set damsg=concat(damsg,' Child (',child,') is opened. ');
  	End if;
  
  	
  	
  
  	set @where = concat('routecls=0 and oprid=',ltrim(oprid),' and cls=''',pTimecls,''' and pc=''' ,left(pPrefix,2),''' and prefixcode=''',pPrefix,'''');
  	
  	set @sql = concat('update R20_ROUTE08 set quality=99.0,state=0,ext=30,reason=' ,ltrim(pReason),',cost=99,UploadDate=current_timestamp(),UploadBy=''',pUser,''' where ' , @where , ' and state=0 and reason=1');
  
  	 PREPARE STMT FROM @sql;
  	 EXECUTE STMT;
  	 DEALLOCATE PREPARE STMT;
  
  	if row_count() > 0 then
  		call routinghistory.rh_insert (poperator,pPrefix,  pTimeCls ,10000  ,31,puser,-1,'R20_ROUTE08','');
  		call r22_routePrefixNew (pPrefix, pDestCode, vadd);
  		select 0 ErrorCode, 'OK.' ErrorString, damsg Note;
  		leave sp_return;
  	end if;
  
  	
  	set @sql = concat('update R20_ROUTE08 set quality=99.0,state=0,ext=30,reason=',ltrim(pReason),',cost=99,UploadDate=current_timestamp(),UploadBy=''',pUser,''' where ' , @where , ' and state=0 and ext in (1,11,20,21)');
  	
  	PREPARE STMT FROM @sql;
  	EXECUTE STMT;
  	DEALLOCATE PREPARE STMT;
  
  	if row_count() > 0 then
  		call routinghistory.rh_insert(poperator,pPrefix,  pTimeCls ,10000  ,31,puser,-1,'R20_ROUTE08','');
  		call r22_routePrefixNew (pPrefix, pDestCode, vadd);
  		select 0 ErrorCode, 'OK.' ErrorString, concat(damsg,' Status changed from BLOCKED to FORBIDDEN.' , case when vadd=1 then 'New Prefix added' else '' end) Note;
  		leave sp_return;
  	end if;
  
  	set @sql = concat('update R20_ROUTE08 set quality=99.0,state=0,ext=30,reason=' , ltrim(pReason) ,
  	 ',cost=99,UploadDate=current_timestamp(),UploadBy=''',pUser,''' where ' , @where);
  	
  	PREPARE STMT FROM @sql;
  	EXECUTE STMT;
  	DEALLOCATE PREPARE STMT;
  
  	if row_count() > 0 then
  		call routinghistory.rh_insert(poperator,pPrefix,  pTimeCls ,10000  ,31,puser,-1,'R20_ROUTE08','');
  		call r22_routePrefixNew (pPrefix, pDestCode, vadd);
  		select 0 ErrorCode, 'OK.' ErrorString, concat(damsg,' Becomes FORBIDDEN prefix.') Note;
  		leave sp_return;
  	end if;
  
  	
  	call r22_data_getFromReset (oprid,pTimecls,pPrefix,newgrade,tempexceptioncls);
  
  	set newgrade=99.0;
  
  	set @sql = concat('insert into R20_ROUTE08(state,reason,ext,routecls,oprid,pc,prefixcode,prefixLen,clsOrg,cls,costOrgCurr,costOrg,cost,priority,access,flag,lastUpd,lastUpdBy,uploaddate,uploadby,quality,exceptioncls)' ,
  	 ' values (0,',ltrim(pReason),',30,0,',ltrim(oprid),',''',left(pPrefix,2),''', ''',pPrefix,''',',ltrim(CHAR_LENGTH(pPrefix)),',''',pTimecls,''',''',pTimecls,''',''N/A'',1,99,0,31,0,current_timestamp(),''',pUser,''',','current_timestamp(),''',pUser,''',',newgrade,',',tempexceptioncls,')');
  	
  	PREPARE STMT FROM @sql;
  	EXECUTE STMT;
  	DEALLOCATE PREPARE STMT;
  
  	call r22_routePrefixNew (pPrefix, pDestCode, vadd);
  	call r22_routeTimeclsAdd ('R20_ROUTE08',0,oprid,pTimecls,left(pPrefix,2));
  	call r22_routeCheckNew (oprid, pTimecls, pPrefix, vadd);
  
  	call routinghistory.rh_insert (poperator,pPrefix,  pTimeCls ,10000  ,31,puser,-1,'R20_ROUTE08','');
  	select 0 ErrorCode, 'OK.' ErrorString, concat(damsg,' New FORBIDDEN prefix. ',case when vadd = 1 then 'New Prefix added.' else '' end) Note;
  	end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r22_routeGetDest` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `r22_routeGetDest`(
  pPrefix varchar(16), 
  inout pDest varchar(32) 
  )
begin
  	select destcode into pDest from r_prefix2 
  	where pPrefix like concat(prefixcode,'%') 
      order by char_length(prefixcode) desc limit 1;
  end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r22_routeGetNearestTime` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `r22_routeGetNearestTime`(
 	pDate datetime,
 	OUT sDate varchar(17)
 )
begin
 	declare m int;
 		set m = minute(pDate);
         
 	if m < 30 then
 		set sDate = DATE_FORMAT(pDate, '%Y-%m-%d %h:00');
 	else
 		set sDate = DATE_FORMAT(pDate, '%Y-%m-%d %h:30');
 	end if;
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r22_routeGetParent2` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `r22_routeGetParent2`(
 	pRouteSet varchar(16),
 	oprid int,
 	pTimecls varchar(2),
 	pPrefix varchar(16),
 	inout pID int 
 )
begin
 
 	if pRouteSet = 'R20_ROUTE12' then
 
 		if pTimecls = 'P' then
 			select  id into pID from R20_ROUTE12  where routecls=0 and oprId=oprid and (cls<=pTimecls) and (cls <> 'O') and pPrefix like concat(prefixcode,'%')
 			order by char_length(prefixcode) desc, clsOrg desc limit 1;
 		
 		elseif pTimecls = 'W' then
 			select  id into pID from R20_ROUTE12 where routecls=0 and oprId=oprid and (cls<=pTimecls) and (cls <> 'P') and pPrefix like concat(prefixcode,'%') 
 			order by char_length(prefixcode) desc, clsOrg desc limit 1;
 		else
 			select  id into pID from R20_ROUTE12 where routecls=0 and oprId=oprid and (cls<=pTimecls) and pPrefix like concat(prefixcode,'%')
 			order by char_length(prefixcode) desc, clsOrg desc limit 1;
 		End if;
 
 	elseif pRouteSet= 'R20_ROUTE09' then
 
 		if pTimecls = 'P' then
 			select  id into pID from R20_ROUTE09 where routecls=0 and oprId=oprid and (cls<=pTimecls) and (cls <> 'O') and pPrefix like concat(prefixcode,'%')
 			order by char_length(prefixcode) desc, clsOrg desc limit 1;
 		
 		elseif pTimecls = 'W' then
 			select  id into pID from R20_ROUTE09 where routecls=0 and oprId=oprid and (cls<=pTimecls) and (cls <> 'P') and pPrefix like concat(prefixcode,'%')
 			order by char_length(prefixcode) desc, clsOrg desc limit 1;
 		else
 			select  id into pID from R20_ROUTE09 where routecls=0 and oprId=oprid and (cls<=pTimecls) and pPrefix like concat(prefixcode,'%')
 			order by char_length(prefixcode) desc, clsOrg desc limit 1;
 
 		end if;
 	
 	elseif pRouteSet= 'R20_ROUTE10' then
 
 		if pTimecls = 'P' then
 			select  id into pID from R20_ROUTE10 where routecls=0 and oprId=oprid and (cls<=pTimecls) and (cls <> 'O') and pPrefix like concat(prefixcode,'%')
 			order by char_length(prefixcode) desc, clsOrg desc limit 1;
 
 		elseif pTimecls = 'W' then
 			select  id into pID from R20_ROUTE10 where routecls=0 and oprId=oprid and (cls<=pTimecls) and (cls <> 'P') and pPrefix like concat(prefixcode,'%')
 			order by char_length(prefixcode) desc, clsOrg desc limit 1;
 		else
 			select  id into pID from R20_ROUTE10  where routecls=0 and oprId=oprid and (cls<=pTimecls)  and pPrefix like concat(prefixcode,'%')
 			order by char_length(prefixcode) desc, clsOrg desc limit 1;
 
 		end if;
 	
 	elseif pRouteSet= 'R20_ROUTE11' then
 
 		if pTimecls = 'P' then
 			select  id into pID from R20_ROUTE11 where routecls=0 and oprId=oprid and (cls<=pTimecls) and (cls <> 'O') and pPrefix like concat(prefixcode,'%')
 			order by char_length(prefixcode) desc, clsOrg desc limit 1;
 
 		elseif pTimecls = 'W' then
 			select  id into pID from R20_ROUTE11 where routecls=0 and oprId=oprid and (cls<=pTimecls) and (cls <> 'P') and pPrefix like concat(prefixcode,'%')
 			order by char_length(prefixcode) desc, clsOrg desc limit 1;
 		else
 			select  id into pID from R20_ROUTE11  where routecls=0 and oprId=oprid and (cls<=pTimecls) and pPrefix like concat(prefixcode,'%')
 			order by char_length(prefixcode) desc, clsOrg desc limit 1;
 		end if;
 
 	elseif pRouteSet= 'R20_ROUTE01' then
 
 		if pTimecls = 'P' then
 			select  id into pID from R20_ROUTE01 where routecls=0 and oprId=oprid and (cls<=pTimecls) and (cls <> 'O')and pPrefix like concat(prefixcode,'%')
 			order by char_length(prefixcode) desc, clsOrg desc limit 1;
 
 		elseif pTimecls = 'W' then
 			select  id into pID from R20_ROUTE01 where routecls=0 and oprId=oprid and (cls<=pTimecls) and (cls <> 'P') and pPrefix like concat(prefixcode,'%')
 			order by char_length(prefixcode) desc, clsOrg desc limit 1;
 		else
 			select  id into pID from R20_ROUTE01 where routecls=0 and oprId=oprid and (cls<=pTimecls) and pPrefix like concat(prefixcode,'%')
 			order by char_length(prefixcode) desc, clsOrg desc limit 1;
 
 		end if; 
 	
 	elseif pRouteSet= 'R20_ROUTE02' then
 
 		if pTimecls = 'P' then
 			select  id into pID from R20_ROUTE02 where routecls=0 and oprId=oprid and (cls<=pTimecls) and (cls <> 'O') and pPrefix like concat(prefixcode,'%')
 			order by char_length(prefixcode) desc, clsOrg desc limit 1;
 		
 		elseif pTimecls = 'W' then
 			select  id into pID from R20_ROUTE02 where routecls=0 and oprId=oprid and (cls<=pTimecls) and (cls <> 'P') and pPrefix like concat(prefixcode,'%')
 			order by char_length(prefixcode) desc, clsOrg desc limit 1;
 		else
 			select  id into pID from R20_ROUTE02 where routecls=0 and oprId=oprid and (cls<=pTimecls) and pPrefix like concat(prefixcode,'%')
 			order by char_length(prefixcode) desc, clsOrg desc limit 1;
 
 		end if;
 
 	elseif pRouteSet= 'R20_ROUTE03' then
 
 		if pTimecls = 'P' then
 			select  id into pID from R20_ROUTE03 where routecls=0 and oprId=oprid and (cls<=pTimecls) and (cls <> 'O') and pPrefix like concat(prefixcode,'%')
 			order by char_length(prefixcode) desc, clsOrg desc limit 1;
 
 		elseif pTimecls = 'W' then
 			select  id into pID from R20_ROUTE03 where routecls=0 and oprId=oprid and (cls<=pTimecls) and (cls <> 'P') and pPrefix like concat(prefixcode,'%')
 			order by char_length(prefixcode) desc, clsOrg desc limit 1;
 		else
 			select  id into pID from R20_ROUTE03 where routecls=0 and oprId=oprid and (cls<=pTimecls) and pPrefix like concat(prefixcode,'%')
 			order by char_length(prefixcode) desc, clsOrg desc limit 1;
 
 		end if;
 
 	elseif pRouteSet= 'R20_ROUTE04' then
 
 		if pTimecls = 'P' then
 			select  id into pID from R20_ROUTE04 where routecls=0 and oprId=oprid and (cls<=pTimecls) and (cls <> 'O') and pPrefix like concat(prefixcode,'%')
 			order by char_length(prefixcode) desc, clsOrg desc limit 1;
 
 		elseif pTimecls = 'W' then
 			select  id into pID from R20_ROUTE04 where routecls=0 and oprId=oprid and (cls<=pTimecls) and (cls <> 'P') and pPrefix like concat(prefixcode,'%')
 			order by char_length(prefixcode) desc, clsOrg desc limit 1;
 		else
 			select  id into pID from R20_ROUTE04 where routecls=0 and oprId=oprid and (cls<=pTimecls) and pPrefix like concat(prefixcode,'%')
 			order by char_length(prefixcode) desc, clsOrg desc limit 1;
 
 		end if;
 	
 	elseif pRouteSet= 'R20_ROUTE05' then
 
 		if pTimecls = 'P' then
 			select  id into pID from R20_ROUTE05  where routecls=0 and oprId=oprid and (cls<=pTimecls) and (cls <> 'O') and pPrefix like concat(prefixcode,'%')
 			order by char_length(prefixcode) desc, clsOrg desc limit 1;
 
 		elseif pTimecls = 'W' then
 			select  id into pID from R20_ROUTE05 where routecls=0 and oprId=oprid and (cls<=pTimecls) and (cls <> 'P') and pPrefix like concat(prefixcode,'%')
 			order by char_length(prefixcode) desc, clsOrg desc limit 1;
 		else
 			select  id into pID from R20_ROUTE05 where routecls=0 and oprId=oprid and (cls<=pTimecls) and pPrefix like concat(prefixcode,'%')
 			order by char_length(prefixcode) desc, clsOrg desc limit 1;
 
 		end if;
 
 	elseif pRouteSet= 'R20_ROUTE06' then
 
 		if pTimecls = 'P' then
 			select  id into pID from R20_ROUTE06  where routecls=0 and oprId=oprid and (cls<=pTimecls) and (cls <> 'O') and pPrefix like concat(prefixcode,'%')
 			order by char_length(prefixcode) desc, clsOrg desc limit 1;
 		
 		elseif pTimecls = 'W' then
 			select  id into pID from R20_ROUTE06 where routecls=0 and oprId=oprid and (cls<=pTimecls) and (cls <> 'P') and pPrefix like concat(prefixcode,'%')
 			order by char_length(prefixcode) desc, clsOrg desc limit 1;
 		else
 			select  id into pID from R20_ROUTE06 where routecls=0 and oprId=oprid and (cls<=pTimecls) and pPrefix like concat(prefixcode,'%')
 			order by char_length(prefixcode) desc, clsOrg desc limit 1;
 
 		end if;
 	
 	elseif pRouteSet= 'R20_ROUTE07' then
 	
 		if pTimecls = 'P' then
 			select  id into pID from R20_ROUTE07 where routecls=0 and oprId=oprid and (cls<=pTimecls) and (cls <> 'O') and pPrefix like concat(prefixcode,'%')
 			order by char_length(prefixcode) desc, clsOrg desc limit 1;
 		
 		elseif pTimecls = 'W' then
 			select  id into pID from R20_ROUTE07 where routecls=0 and oprId=oprid and (cls<=pTimecls) and (cls <> 'P') and pPrefix like concat(prefixcode,'%')
 			order by char_length(prefixcode) desc, clsOrg desc limit 1;
 		else
 			select  id into pID from R20_ROUTE07 where routecls=0 and oprId=oprid and (cls<=pTimecls) and pPrefix like concat(prefixcode,'%')
 			order by char_length(prefixcode) desc, clsOrg desc limit 1;
 
 		end if;
 	
 	elseif pRouteSet= 'R20_ROUTE08' then
 
 		if pTimecls = 'P' then
 			select  id into pID from R20_ROUTE08 where routecls=0 and oprId=oprid and (cls<=pTimecls) and (cls <> 'O')and pPrefix like concat(prefixcode,'%')
 			order by char_length(prefixcode) desc, clsOrg desc limit 1;
 
 		elseif pTimecls = 'W' then
 			select  id into pID from R20_ROUTE08 where routecls=0 and oprId=oprid and (cls<=pTimecls) and (cls <> 'P')and pPrefix like concat(prefixcode,'%')
 			order by char_length(prefixcode) desc, clsOrg desc limit 1;
 		else
 			select  id into pID from R20_ROUTE08 where routecls=0 and oprId=oprid and (cls<=pTimecls) and pPrefix like concat(prefixcode,'%')
 			order by char_length(prefixcode) desc, clsOrg desc limit 1;
 
 		end if;
 	end if;
 
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r22_routePrefixNew` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `r22_routePrefixNew`(
 	pPrefix varchar(16), 
 	pDestCode varchar(32),
 	INOUT pAdd int
 )
sp_return:begin
 	
 		if pAdd is not null then 
 			set pAdd = 0; 
 		end if;
         
 		if pDestCode is null then 
 			leave sp_return;
 		end if;
 
  	if not exists(select prefixcode from r_prefix2 where prefixcode=pPrefix limit 1) then
 
     	insert into r_prefix2(pc,prefixcode,prefixlen,state,destcode)  
   		values(left(pPrefix,2),pPrefix,CHAR_LENGTH(pPrefix),'I',replace(pDestCode,',',''))  ;
 
 		if pAdd is not null then
 			set pAdd = 1; 
         end if;
 	end if;
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r22_routeTimeclsAdd` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `r22_routeTimeclsAdd`(
	pRouteSet varchar(16),
	pRouteCls int,
	pOprId int,
	pCls varchar(2),
	pPC varchar(2)
)
sp_return:begin

	if exists(select * from r20_route_timecls a where a.routecls=pRouteCls and a.oprId=pOprId and a.cls=pCls and a.pc=pPC limit 1) then
		leave sp_return;
	End if;

	insert r20_route_timecls(routecls, oprId, cls, pc) 
	values(pRouteCls, pOprId, pCls, pPC);

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r22_routeTimeclsDel` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `r22_routeTimeclsDel`(
 	pRouteSet varchar(16),
 	pRouteCls int,
 	pOprId int,
 	pCls varchar(2),
 	pPrefix varchar(2)
 )
sp_return:begin
 
 	declare v_founda int;
 	declare v_foundb int;
 
 	select 1 into v_founda
 	from R20_ROUTE08 where routecls=ltrim(pRouteCls) and pc=left(pPrefix,2) and prefixCode=pPrefix limit 1;
 
 	if ifnull(v_founda,0)=0 then
 	
 		delete from r_prefix2 where pc=left(pPrefix,2) and prefixCode=pPrefix;
 	End if;
 
 	select 1 into v_foundb
 	from R20_ROUTE08 where routecls=ltrim(pRouteCls) and oprId=ltrim(pOprId) and cls=pCls and pc=left(pPrefix,2) limit 1;
 
 	if ifnull(v_foundb,0)=1 then
 	
 		leave sp_return;
 	End if;
 
 	delete from r20_route_timecls where routecls=pRouteCls and oprId=pOprId and cls=pCls and pc=left(pPrefix,2);
 
 
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r22_routeUnBlock` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `r22_routeUnBlock`(
    pRouteSet varchar(16),
    pOperator varchar(16),
    pTimecls varchar(2),
    pPrefix varchar(16),
    pReason int,
    pUser varchar(16)
   )
sp_return:begin
   	declare oprid int;
   	declare v_where varchar(2000);
      
   	
   	select a.id into oprid from r_interface a where a.reserved=pOperator limit 1;
   
   	if oprid is null then
   		select -1 ErrorCode, concat('*** Operator{',pOperator,'} Not Found') as ErrorString;
   		leave sp_return;
   	end if;
   
   	set pPrefix=ltrim(rtrim(pPrefix));
   
   	if pUser is null then set pUser = user(); end if;
   
   	set v_where = concat('routecls=0 and oprId = ',cast(oprid as SIGNED INTEGER),' and cls=''',pTimecls,''' and pc=''' , 
   					left(pPrefix,2),''' and prefixcode=''',pPrefix,'''');
   
   	set @sql = concat('update ' , pRouteSet ,' set state=1,ext=0,reason=',cast(pReason as SIGNED INTEGER), 
   	 ',lastUpd=current_timestamp(),lastUpdBy=''',pUser,''' where ' , v_where , ' and state=0 and ext=20');
   	 
   	PREPARE STMT FROM @sql;
   	EXECUTE STMT;
   	DEALLOCATE PREPARE STMT;
   
   	if row_count() > 0 then
   		call routinghistory.rh_insert(poperator,pPrefix,  pTimeCls ,10000  ,31,puser,1,pRouteSet,'');
   		select 0 ErrorCode, 'OK.' ErrorString, 'Latest-State is ACTIVE' Note;
   		leave sp_return;
   	end if;
         
   	
   	set @sql = concat('update ' , pRouteSet , ' set state=1,ext=100,reason=',cast(pReason as SIGNED INTEGER), 
   	 ',lastUpd=current_timestamp(),lastUpdBy=''',pUser,''' where ' , v_where , ' and state=0 and ext=120'); 
   	
   	PREPARE STMT FROM @sql;
   	EXECUTE STMT;
   	DEALLOCATE PREPARE STMT;
   
   	if row_count() > 0 then
   		call routinghistory.rh_insert(poperator,pPrefix,  pTimeCls ,10000  ,31,puser,1,pRouteSet,'');
   		select 0 ErrorCode, 'OK.' ErrorString, 'Latest-State is ACTIVE' Note;
   		leave sp_return;
   	end if;
         
   	set @sql = concat('delete ' , pRouteSet , ' where ' , v_where , ' and state=0 and ext in (1,101)'); 
   	
   	PREPARE STMT FROM @sql;
   	EXECUTE STMT;
   	DEALLOCATE PREPARE STMT;
   
   	if row_count() > 0 then
   		call r22_routeTimeclsDel (pRouteSet,0,oprid,pTimecls,pPrefix);
   		call routinghistory.rh_insert(poperator,pPrefix,  pTimeCls ,10000  ,31,puser,1,pRouteSet,'');
   		select 0 ErrorCode, 'OK.' ErrorString, 'Deleted' Note;
   		leave sp_return;
   	end if;
   
   	select -1 ErrorCode, '*** Entry not found.' ErrorString;
   end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r22_routeUnExcept` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `r22_routeUnExcept`(
  pRouteSet varchar(16),
  pOperator varchar(16),
  pTimecls varchar(2),
  pPrefix varchar(16),
  pUser varchar(16)
 )
sp_return:begin
 
 	declare oprid int;
 	declare v_where varchar(2000); 
 	declare comment varchar(150);  
 	set comment='exception : 0 (unexcept)';
 
 
 
 	select a.id into oprid from r_interface a where a.reserved=pOperator limit 1;
 
 	if oprid is null then
 		select -1 ErrorCode, CONCAT('*** Operator{',pOperator,'} Not Found') AS ErrorString;
 		leave sp_return;
 	end if;
 
 	set pPrefix=ltrim(rtrim(pPrefix));
 
 	if pUser is null THEN set pUser = user(); END IF;
 
 		set v_where = concat('routecls=0 and a.oprId=',cast(oprid as SIGNED INTEGER),' and cls=''',pTimecls,''' and pc=''' , 
 					left(pPrefix,2),''' and prefixcode=''',pPrefix,''' ');
 
 		set @sql = concat('delete a from R20_ROUTE08 a where ', v_where , 'and ext = 101');
 
 		PREPARE STMT FROM @sql;
 		EXECUTE STMT;
 		DEALLOCATE PREPARE STMT;
 
 	if row_count() > 0 then
 		
 		call r22_routeTimeclsDel (pRouteSet,0,oprid,pTimecls,pPrefix ); 
 		
 		call routinghistory.rh_insert(poperator,pPrefix,  pTimeCls ,10000  ,31,puser,10,pRouteSet,comment);
 		
 		select 0 ErrorCode, 'OK.' ErrorString, 'Deleted' Note;
 		
 		leave sp_return;
 
 	end if;
   
 		set @sql = concat('update R20_ROUTE08 a set exception=null',',lastUpd=current_timestamp(),lastUpdBy=''',pUser,''',UpdateFlag=0 where ' , v_where , ' and ext=0'); 
 
 		PREPARE STMT FROM @sql;
 		EXECUTE STMT;
 		DEALLOCATE PREPARE STMT;
 
 	if rowcount > 0 then
 		call routinghistory.rh_insert (poperator,pPrefix,  pTimeCls ,10000 ,31,puser,10,pRouteSet,comment);
 
 		select 0 ErrorCode, 'OK.' ErrorString,'' Note;
 		leave sp_return;
 	end if;
 
 	set @sql = concat('update R20_ROUTE08 a set ext=ext-100, exception=null, lastUpd=current_timestamp(), lastUpdBy=''',pUser,''',UpdateFlag = 0 where ' , v_where  ,' and ext>=100 '); 
 
 	PREPARE STMT FROM @sql;
 		EXECUTE STMT;
 		DEALLOCATE PREPARE STMT;
 
 	if row_count() > 0 then
 		call routinghistory.rh_insert (poperator,pPrefix,  pTimeCls ,10000  ,31,puser,10,pRouteSet,comment);
 		select 0 ErrorCode, 'OK.' ErrorString, '' Note;
 		leave sp_return;
 	end if;
 
 select -1 ErrorCode, '*** Entry not found.' ErrorString ;
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r22_routingopr_prefixtimecls` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `r22_routingopr_prefixtimecls`(
  	operator varchar(100),  
  	prefixcode varchar(100) 
  )
sp_return:begin
  
  	declare tintid int;
  	declare pfxcode varchar(100);
  	declare datimecls varchar(100);
  
  	if prefixcode is null then
  		set prefixcode = '%';
  	End if;
  
  	
  
  	select a.id into tintid from r_interface a where a.reserved = operator limit 1;  
  
  	if tintid is null then
  		select  '' operator,'' prefixcode ,'' timecls;
  		leave sp_return;
  	end if;
  
  	drop temporary table if exists tt_temp; 
  	create temporary table tt_temp 
  	as  
  	select distinct prefixcode,space(20) timecls 
  	from R20_ROUTE08 
  	where routecls=0 and oprid=tintid and prefixcode like CONCAT('%',prefixcode,'%');
  
  	set pfxcode =null;
  
  	select a.prefixcode into pfxcode from tt_temp a where ltrim(timecls)='' limit 1;
  	
  	while pfxcode is not null do
  	
  		set datimecls='';
  
  		select concat(datimecls ,b.cls) into datimecls
  		from R20_ROUTE08 b 
  		where  b.routecls=0 and b.oprid=tintid and b.prefixcode=pfxcode;
  
  		update tt_temp a set a.timecls=datimecls where a.prefixcode=pfxcode;
  		
  		set pfxcode=null;
  
  		select a.prefixcode into pfxcode from tt_temp a where a.timecls='' limit 1;
  
  	end while;
  
  	select  operator as  operator,a.* from tt_temp a order by a.prefixcode;
  
  end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r23_routeHigherGetDel` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `r23_routeHigherGetDel`(
  	pRouteSet varchar(16),
  	pOperator int,
  	pTimecls varchar(2),
  	pPrefix varchar(16),
  	INOUT msg TEXT
  )
sp_return:begin
  
  	declare pc varchar(2);
  	set pc=lefT(pPrefix,2);
  
  	set @msg = '';
  
  	if pTimecls = 'W' then
  		leave sp_return;
  	end if;
  
  	if pRouteSet = 'R20_ROUTE11' then  
  	
  		if pTimecls in('P','O') then
  
  			set @damsg='';
  
  			set @damsg= (select concat(@damsg,'Overlapped timeclass ',a.cls,' deleted, status=' , ltrim(a.state), ' reason=' ,ltrim(ltrim(ifnull(a.reason,0))) , '\n ')
  			from R20_ROUTE11 a where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in ('A'));
  
  			if @damsg <> '' then
  
  				insert into r20_reset(resetTime,resetBy,routecls,oprid,clsOrg,prefixCode,quality,cls,exceptioncls)
  				select current_timestamp(),'SYSTEMOVLP',a.routecls,a.oprid,a.clsorg,a.prefixcode,a.quality,a.cls,a.exceptioncls
  				from R20_ROUTE11 a where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in ('A');
  
  				
  				delete a from R20_ROUTE11 a where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in ('A');
  			end if;
  
  		elseif pTimecls in('A') then
  
  			set @damsg='';
  				set @damsg= (select concat(@damsg,'Overlapped timeclass ',a.cls,' deleted, status=' , ltrim(a.state), ' reason=' ,ltrim(ltrim(ifnull(a.reason,0))) , '\n ')
  				from R20_ROUTE11 a where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('O','P'));
  
  			
  			if @damsg <>'' then
  				insert into r20_reset(resetTime,resetBy,routecls,oprid,clsOrg,prefixCode,quality,cls,exceptioncls)
  				select current_timestamp(),'SYSTEMOVLP',a.routecls,a.oprid,a.clsorg,a.prefixcode,a.quality,a.cls ,a.exceptioncls
  				from R20_ROUTE11 a where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('O','P');
  
  				delete a from R20_ROUTE11 a where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('O','P');
  			end if;
  		end if;
  
  	elseif pRouteSet = 'R20_ROUTE12' then   
  		if pTimecls in('P','O') then
  
  			set @damsg='';
  
  			set @damsg= (select concat(@damsg,'Overlapped timeclass ',a.cls,' deleted, status=' , ltrim(a.state), ' reason=' ,ltrim(ltrim(ifnull(a.reason,0))) , '\n ')
  			from R20_ROUTE12 a where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('A'));
  
  			if @damsg <> '' then
  			
  				insert into r20_reset(resetTime,resetBy,routecls,oprid,clsOrg,prefixCode,quality,cls,exceptioncls)
  				select current_timestamp(),'SYSTEMOVLP',a.routecls,a.oprid,a.clsorg,a.prefixcode,a.quality,a.cls,a.exceptioncls
  				from R20_ROUTE12 a where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('A');
  
  				
  				delete a from R20_ROUTE12 a where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('A');
  			end if;
  
  		elseif pTimecls in('A') then
  
  			set @damsg='';
  			set @damsg= (select concat(@damsg,'Overlapped timeclass ',a.cls,' deleted, status=' , ltrim(a.state), ' reason=' ,ltrim(ltrim(ifnull(a.reason,0))) , '\n ')
  			from R20_ROUTE12 a where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('O','P'));
  
  			
  			if @damsg <>'' then
  				insert into r20_reset(resetTime,resetBy,routecls,oprid,clsOrg,prefixCode,quality,cls,exceptioncls)
  				select current_timestamp(),'SYSTEMOVLP',a.routecls,a.oprid,a.clsorg,a.prefixcode,a.quality,a.cls ,a.exceptioncls 
  				from R20_ROUTE12 a where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('O','P');
  
  				delete a from R20_ROUTE12 a where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('O','P');
  			end if;
  		end if;
  
  	elseif pRouteSet = 'R20_ROUTE09' then   
  		if pTimecls in('P','O') then
  			set @damsg='';
  
  			set @damsg= (select concat(@damsg,'Overlapped timeclass ',a.cls,' deleted, status=' , ltrim(a.state), ' reason=' ,ltrim(ltrim(ifnull(a.reason,0))) , '\n ')
  			from R20_ROUTE09 a where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('A'));
  
  			if @damsg <> '' then
  				insert into r20_reset(resetTime,resetBy,routecls,oprid,clsOrg,prefixCode,quality,cls)
  				select current_timestamp(),'SYSTEMOVLP',a.routecls,a.oprid,a.clsorg,a.prefixcode,a.quality,a.cls
  				from R20_ROUTE09 a where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('A');
  
  				
  				delete a from R20_ROUTE09 a where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('A');
  			end if;
  
  		elseif pTimecls in('A') then
  
  			set @damsg='';
  			set @damsg= (select concat(@damsg,'Overlapped timeclass ',a.cls,' deleted, status=' , ltrim(a.state), ' reason=' ,ltrim(ltrim(ifnull(a.reason,0))) , '\n ')
  			from R20_ROUTE09 a where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('O','P'));
  
  			
  			if @damsg <>'' then
  				insert into r20_reset(resetTime,resetBy,routecls,oprid,clsOrg,prefixCode,quality,cls)
  				select current_timestamp(),'SYSTEMOVLP',a.routecls,a.oprid,a.clsorg,a.prefixcode,a.quality,a.cls 
  				from R20_ROUTE09 a where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('O','P');
  
  				delete a from R20_ROUTE09 a where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('O','P');
  			end if;
  		end if;
  
  	elseif pRouteSet = 'R20_ROUTE10' then
  		if pTimecls in('P','O') then
  			set @damsg='';
  
  			set @damsg= (select concat(@damsg,'Overlapped timeclass ',a.cls,' deleted, status=' , ltrim(a.state), ' reason=' ,ltrim(ltrim(ifnull(a.reason,0))) , '\n ')
  			from R20_ROUTE10 a where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('A'));
  
  			if @damsg <> '' then
  				insert into r20_reset(resetTime,resetBy,routecls,oprid,clsOrg,prefixCode,quality,cls,exceptioncls)
  				select current_timestamp(),'SYSTEMOVLP',a.routecls,a.oprid,a.clsorg,a.prefixcode,a.quality,a.cls,a.exceptioncls 
  				from R20_ROUTE10 a where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('A');
  
  				
  				delete a from R20_ROUTE10 a where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('A');
  			end if;
  
  		elseif pTimecls in('A') then
  
  				set @damsg='';
  				select @damsg= @damsg,'Overlapped timeclass ',a.cls,' deleted, status=' , ltrim(a.state), ' reason=' ,ltrim(ltrim(ifnull(a.reason,0))) , '\n '
  				from R20_ROUTE10 a where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('O','P');
  
  				
  				if @damsg <>'' then
  					insert into r20_reset(resetTime,resetBy,routecls,oprid,clsOrg,prefixCode,quality,cls,exceptioncls)
  					select current_timestamp(),'SYSTEMOVLP',a.routecls,a.oprid,a.clsorg,a.prefixcode,a.quality,a.cls ,a.exceptioncls
  					from R20_ROUTE10 a where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('O','P');
  
  					delete a from R20_ROUTE10 a where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('O','P');
  				end if;
  			end if;
  
  	elseif pRouteSet = 'R20_ROUTE01' then   
  		if pTimecls in('P','O') then
  			set @damsg='';
  
  			set @damsg= (select concat(@damsg,'Overlapped timeclass ',a.cls,' deleted, status=' , ltrim(a.state),  ' reason=' ,ltrim(ltrim(ifnull(a.reason,0))) , '\n ')
  			from R20_ROUTE01 a where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('A'));
  
  			if @damsg <> '' then
  				insert into r20_reset(resetTime,resetBy,routecls,oprid,clsOrg,prefixCode,quality,cls)
  				select current_timestamp(),'SYSTEMOVLP',a.routecls,a.oprid,a.clsorg,a.prefixcode,a.quality,a.cls
  				from R20_ROUTE01 a where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('A');
  
  				
  				delete a from R20_ROUTE01 a where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('A');
  			end if;
  
  		elseif pTimecls in('A') then
  
  			set @damsg='';
  			set @damsg= (select concat(@damsg,'Overlapped timeclass ',a.cls,' deleted, status=' , ltrim(a.state), ' reason=' ,ltrim(ltrim(ifnull(a.reason,0))) , '\n ')
  			from R20_ROUTE01 a
  			where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('O','P'));
  
  			
  			if @damsg <>'' then
  				insert into r20_reset(resetTime,resetBy,routecls,oprid,clsOrg,prefixCode,quality,cls)
  				select current_timestamp(),'SYSTEMOVLP',a.routecls,a.oprid,a.clsorg,a.prefixcode,a.quality,a.cls 
  				from R20_ROUTE01 a where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('O','P');
  
  				delete a from R20_ROUTE01 a where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('O','P');
  			end if;
  		end if;
  
  	elseif pRouteSet = 'R20_ROUTE02' then
  		
  		if pTimecls in('P','O') then
  			set @damsg='';
  
  			set @damsg= (select concat(@damsg,'Overlapped timeclass ',a.cls,' deleted, status=' , ltrim(a.state), ' reason=' ,ltrim(ltrim(ifnull(a.reason,0))) , '\n ')
  			 from R20_ROUTE02 a
  			 where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('A'));
  
  			if @damsg <> '' then
  				insert into r20_reset(resetTime,resetBy,routecls,oprid,clsOrg,prefixCode,quality,cls)
  				select current_timestamp(),'SYSTEMOVLP',a.routecls,a.oprid,a.clsorg,a.prefixcode,a.quality,a.cls
  				from R20_ROUTE02 a
  				where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('A');
  
  				
  				delete a from R20_ROUTE02 a where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('A');
  			end if;
  
  		elseif pTimecls in('A') then
  
  			set @damsg='' ;
  			set @damsg= (select concat(@damsg,'Overlapped timeclass ',a.cls,' deleted, status=' , ltrim(a.state), ' reason=' ,ltrim(ltrim(ifnull(a.reason,0))) , '\n ')
  			from R20_ROUTE02 a
  			where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('O','P'));
  
  			
  			if @damsg <>'' then 
  				insert into r20_reset(resetTime,resetBy,routecls,oprid,clsOrg,prefixCode,quality,cls)
  				select current_timestamp(),'SYSTEMOVLP',a.routecls,a.oprid,a.clsorg,a.prefixcode,a.quality,a.cls 
  				from R20_ROUTE02 a
  				where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('O','P');
  
  				delete a from R20_ROUTE02 a where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('O','P');
  			end if;
  		end if;
  
  	elseif pRouteSet = 'R20_ROUTE03' then  
  		
  		if pTimecls in('P','O') then
  			set @damsg='';
  
  			set @damsg= (select concat(@damsg,'Overlapped timeclass ',a.cls,' deleted, status=' , ltrim(a.state), ' reason=' ,ltrim(ltrim(ifnull(a.reason,0))) , '\n ')
  			from R20_ROUTE03 a
  			where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('A'));
  
  			if @damsg <> '' then
  				insert into r20_reset(resetTime,resetBy,routecls,oprid,clsOrg,prefixCode,quality,cls)
  				select current_timestamp(),'SYSTEMOVLP',a.routecls,a.oprid,a.clsorg,a.prefixcode,a.quality,a.cls
  				from R20_ROUTE03 a
  				where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('A');
  
  				
  				delete a from R20_ROUTE03 a where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('A');
  			end if;
  
  		elseif pTimecls in('A') then
  
  			set @damsg='';
  			set @damsg= (select concat(@damsg,'Overlapped timeclass ',a.cls,' deleted, status=' , ltrim(a.state), ' reason=' ,ltrim(ltrim(ifnull(a.reason,0))) , '\n ')
  			from R20_ROUTE03 a
  			where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('O','P'));
  
  			
  			if @damsg <>'' then
  				
  				insert into r20_reset(resetTime,resetBy,routecls,oprid,clsOrg,prefixCode,quality,cls)
  				select current_timestamp(),'SYSTEMOVLP',a.routecls,a.oprid,a.clsorg,a.prefixcode,a.quality,a.cls 
  				from R20_ROUTE03 a
  				where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('O','P');
  
  				delete a from R20_ROUTE03 a where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('O','P');
  			end if;
  		end if;
  
  	elseif pRouteSet = 'R20_ROUTE04' then
  		if pTimecls in('P','O') then
  			set @damsg='';
  
  			set @damsg= (select concat(@damsg,'Overlapped timeclass ',a.cls,' deleted, status=' , ltrim(a.state), ' reason=' ,ltrim(ltrim(ifnull(a.reason,0))) , '\n ')
  			from R20_ROUTE04 a
  			where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('A'));
  
  			if @damsg <> '' then
  				insert into r20_reset(resetTime,resetBy,routecls,oprid,clsOrg,prefixCode,quality,cls)
  				select current_timestamp(),'SYSTEMOVLP',a.routecls,a.oprid,a.clsorg,a.prefixcode,a.quality,a.cls
  				from R20_ROUTE04 a
  				where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('A');
  
  				
  				delete a from R20_ROUTE04 a where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('A');
  			end if;
  
  		elseif pTimecls in('A') then
  
  			set @damsg='';
  			set @damsg= (select concat(@damsg,'Overlapped timeclass ',a.cls,' deleted, status=' , ltrim(a.state), ' reason=' ,ltrim(ltrim(ifnull(a.reason,0))) , '\n ')
  			from R20_ROUTE04 a
  			where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('O','P'));
  
  			
  			if @damsg <>'' then
  				insert into r20_reset(resetTime,resetBy,routecls,oprid,clsOrg,prefixCode,quality,cls)
  				select current_timestamp(),'SYSTEMOVLP',a.routecls,a.oprid,a.clsorg,a.prefixcode,a.quality,a.cls 
  				  from R20_ROUTE04 a
  				 where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('O','P');
  
  				delete a from R20_ROUTE04 a where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('O','P');
  			end if;
  		end if;
  
  	elseif pRouteSet = 'R20_ROUTE05' then
  		if pTimecls in('P','O') then
  			set @damsg='';
  
  			set @damsg= (select concat(@damsg,'Overlapped timeclass ',a.cls,' deleted, status=' , ltrim(a.state), ' reason=' ,ltrim(ltrim(ifnull(a.reason,0))) , '\n ')
  			  from R20_ROUTE05 a
  			 where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('A'));
  
  			if @damsg <> '' then
  				insert into r20_reset(resetTime,resetBy,routecls,oprid,clsOrg,prefixCode,quality,cls)
  				select current_timestamp(),'SYSTEMOVLP',a.routecls,a.oprid,a.clsorg,a.prefixcode,a.quality,a.cls
  				  from R20_ROUTE05 a
  				 where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('A');
  
  				
  				delete a from R20_ROUTE05 a where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('A');
  			end if;
  
  		elseif pTimecls in('A') then
  
  			set @damsg='';
  			set @damsg= (select concat(@damsg,'Overlapped timeclass ',a.cls,' deleted, status=' , ltrim(a.state), ' reason=' ,ltrim(ltrim(ifnull(a.reason,0))) , '\n ')
  			  from R20_ROUTE05 a
  			 where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('O','P'));
  
  			
  			if @damsg <>'' then
  		
  				insert into r20_reset(resetTime,resetBy,routecls,oprid,clsOrg,prefixCode,quality,cls)
  				select current_timestamp(),'SYSTEMOVLP',a.routecls,a.oprid,a.clsorg,a.prefixcode,a.quality,a.cls 
  				  from R20_ROUTE05 a
  				 where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('O','P');
  
  				delete a from R20_ROUTE05 a where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('O','P');
  			end if;
  		end if;
  
  	elseif pRouteSet = 'R20_ROUTE06' then
  		if pTimecls in('P','O') then
  			set @damsg='';
  
  			set @damsg= (select concat(@damsg,'Overlapped timeclass ',a.cls,' deleted, status=' , ltrim(a.state), ' reason=' ,ltrim(ltrim(ifnull(a.reason,0))) , '\n ')
  			  from R20_ROUTE06 a
  			 where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('A'));
  
  			if @damsg <> '' then
  				insert into r20_reset(resetTime,resetBy,routecls,oprid,clsOrg,prefixCode,quality,cls)
  				select current_timestamp(),'SYSTEMOVLP',a.routecls,a.oprid,a.clsorg,a.prefixcode,a.quality,a.cls
  				from R20_ROUTE06 a
  				where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('A');
  
  				
  				delete a from R20_ROUTE06 a where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('A');
  			end if;
  
  		elseif pTimecls in('A') then
  
  			set @damsg='';
  			set @damsg= (select concat(@damsg,'Overlapped timeclass ',a.cls,' deleted, status=' , ltrim(a.state),' reason=' ,ltrim(ltrim(ifnull(a.reason,0))) , '\n ')
  			from R20_ROUTE06 a
  			where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('O','P'));
  
  			
  			if @damsg <>'' then
  				insert into r20_reset(resetTime,resetBy,routecls,oprid,clsOrg,prefixCode,quality,cls)
  				select current_timestamp(),'SYSTEMOVLP',a.routecls,a.oprid,a.clsorg,a.prefixcode,a.quality,a.cls 
  				from R20_ROUTE06 a
  				where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('O','P');
  
  				delete a from R20_ROUTE06 a where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('O','P');
  			end if;
  		end if;
  
  	elseif pRouteSet = 'R20_ROUTE07' then
  		if pTimecls in('P','O') then
  			set @damsg='';
  
  			set @damsg= (select concat(@damsg,'Overlapped timeclass ',a.cls,' deleted, status=' , ltrim(a.state), ' reason=' ,ltrim(ltrim(ifnull(a.reason,0))) , '\n ')
  			  from R20_ROUTE07 a
  			 where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('A'));
  
  			if @damsg <> '' then
  				insert into r20_reset(resetTime,resetBy,routecls,oprid,clsOrg,prefixCode,quality,cls)
  				select current_timestamp(),'SYSTEMOVLP',a.routecls,a.oprid,a.clsorg,a.prefixcode,a.quality,a.cls
  				from R20_ROUTE07 a
  				where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('A');
  
  				
  				delete a from R20_ROUTE07 a where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('A');
  			end if;
  
  		elseif pTimecls in('A') then
  
  			set @damsg='';
  			set @damsg= (select concat(@damsg,'Overlapped timeclass ',a.cls,' deleted, status=' , ltrim(a.state), ' reason=' ,ltrim(ltrim(ifnull(a.reason,0))) , '\n ')
  			  from R20_ROUTE07 a
  			 where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('O','P'));
  
  			
  			if @damsg <>'' then
  				insert into r20_reset(resetTime,resetBy,routecls,oprid,clsOrg,prefixCode,quality,cls)
  				select current_timestamp(),'SYSTEMOVLP',a.routecls,a.oprid,a.clsorg,a.prefixcode,a.quality,a.cls 
  				from R20_ROUTE07 a
  				where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('O','P');
  
  				delete a from R20_ROUTE07 a where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('O','P');
  			end if;
  		end if;
  
  	elseif pRouteSet = 'R20_ROUTE08' then
  		if pTimecls in('P','O') then
  			set @damsg='';
  
  			set @damsg= (select concat(@damsg,'Overlapped timeclass ',a.cls,' deleted, status= ' , ltrim(a.state), ', reason= ' ,ltrim(ltrim(ifnull(a.reason,0))) , ', prefix= ', pPrefix , '\n ')
  			from R20_ROUTE08 a
  			where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('A'));
  
  			if @damsg <> '' then
  				insert into r20_reset(resetTime,resetBy,routecls,oprid,clsOrg,prefixCode,quality,cls)
  				select current_timestamp(),'SYSTEMOVLP',a.routecls,a.oprid,a.clsorg,a.prefixcode,a.quality,a.cls
  				from R20_ROUTE08 a
  				where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('A');
  
  				
  				delete a from R20_ROUTE08 a where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('A');
  			end if;
  
  		elseif pTimecls in('A') then
  
  			set @damsg='';
  			set @damsg= (select concat(@damsg,'Overlapped timeclass ',a.cls,' deleted, status= ' , ltrim(a.state), ', reason= ' ,ltrim(ltrim(ifnull(a.reason,0))) , ', prefix= ' , pPrefix , '\n ')
  			from R20_ROUTE08 a
  			where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('O','P'));
  
  			
  			if @damsg <>'' then	
  				insert into r20_reset(resetTime,resetBy,routecls,oprid,clsOrg,prefixCode,quality,cls)
  				select current_timestamp(),'SYSTEMOVLP',a.routecls,a.oprid,a.clsorg,a.prefixcode,a.quality,a.cls 
  				from R20_ROUTE08 a
  				where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('O','P');
  
  				delete a from R20_ROUTE08 a where a.routecls=0 and a.oprid=pOperator and a.pc=pc and a.prefixcode=pPrefix and a.clsorg in('O','P');
  			end if;
  		end if;
  	end if;
  
  	set msg=@damsg;
  
  end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r24_routeGetCache_08` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `r24_routeGetCache_08`(
    	pLongest varchar(32),
    	pLongestCls int,
    	pDate datetime,
    	pSrcInt varchar(7),
    	pSrcIntGroup varchar(64),
    	pSrcIntDom varchar(64),
    	routeclass int, 
    	pCLI varchar(32),
    	pOperatorGroup int,
    	pGrade float,
    	oprtype int 
    )
sp_return: begin 
    
    	
    	
    	declare pc varchar(2); 
    	declare dd int;
    	declare hh int;
    	declare mm int;
    	declare counter int;
    	declare strtimecls varchar(100);
    	declare idx int;
    	declare daoprid int ;
    	declare dacls varchar(10);
    	
    	if routeclass is null then set routeclass = 0; end if;
    	if pCLI is null then set pCLI = ''; end if;
    	if pOperatorGroup is null then set pOperatorGroup = 0; end if;
    	if pGrade is null then set pGrade = 99.0; end if;
    	if oprtype is null then set oprtype = 0; end if;
     
    	set pc=left(pLongest,2);
     
    	set pc = left(pLongest,2);
    	set dd = 1 + (7 + (DAYOFWEEK(NOW()) - 1) - 1) % 7;
     
    	select ((HOUR(pDate) - timezone)-timezone) into hh from r_info limit 1;
    
    	
    		set mm= MINUTE(pDate) ;
    
    	drop temporary table if exists tt_operator_selected;
    	create temporary table tt_operator_selected
    	(
    		 id int,
    		 routecls int,
    		 oprId int,
    		 cls varchar(1),
    		 pc varchar(2),
    		 UNIQUE KEY (routecls, oprId, cls, pc),
    		 KEY idx1_tt_operator_selected (routeCls,oprId,pc)
    
    	);
    
    	
    	
    
    	insert into tt_operator_selected(id, routecls, oprId, cls, pc)
    	select x.id ,x.routecls ,x.oprId ,x.cls ,x.pc 
    	from	r20_route_timecls x, 
    			r_timecls y, 
    			r_interface tit, 
    			r_timecode tco, 
             r_daycode dco  
    	where x.routecls=0
    	and tit.id = x.oprid and tit.state = 'I' 
    	and y.tintid =x.oprid and y.cls=x.cls 
    	and y.dc=dco.id and y.tc=tco.id and y.sc=0
    	and dd between dco.d1 and dco.d2
    	and ((24 + hh + ifnull(tit.prefixcls,0)) % 24) * 100 + mm between tco.h1 and tco.h2-1
    	and x.pc=pc;
    
    	drop temporary table if exists tt_timecls_selected;
    	create temporary table tt_timecls_selected as 
    	select a.routecls, a.oprid, a.pc, max(a.prefixCode) prefixCode,
    			count(*) cnt,
    			sum(case when a.cls='A' then 1 else 0 end) clsA,
    			sum(case when a.cls='P' then 1 else 0 end) clsP,
    			sum(case when a.cls='O' then 1 else 0 end) clsO,
    			sum(case when a.cls='W' then 1 else 0 end) clsW, 'Z' as cls
    	
    	from R20_ROUTE08 a, tt_operator_selected b
    	where (pLongestCls not in (3,4) or a.priority=1)
    	and a.routeCls=b.routeCls and a.oprId=b.oprId and a.pc=b.pc 
    	and left(pLongest,prefixLen)=a.prefixcode
    	and a.cls=b.cls
    	group by a.routecls, a.oprid, a.pc; 
    
    	update tt_timecls_selected 
    	set cls = (case when (clsW>0) and (cnt = clsW) then 'W' 
    			when (clsO>0) and (cnt = clsO) then 'O'
    			when (clsP>0) and (cnt = clsP) then 'P'
    			when (clsA>0) and (cnt = clsA) then 'A' 
    		else 'Z' end);
    
    	update tt_timecls_selected 
    	set cls = (select max(a.cls) from R20_ROUTE08 a 
    		 where a.routecls=tt_timecls_selected.routecls 
    		 and a.oprid = tt_timecls_selected.oprId 
    		 and a.pc=tt_timecls_selected.pc 
    		 and a.prefixCode=tt_timecls_selected.prefixCode
    		 and ((a.cls='A' and tt_timecls_selected.clsA<>0) or 
    			(a.cls='P' and tt_timecls_selected.clsP<>0) or
    			(a.cls='O' and tt_timecls_selected.clsO<>0) or
    			(a.cls='W' and tt_timecls_selected.clsW<>0))
    	)
    	where cls = 'Z';
    
    	drop temporary table if exists tt_routes;
    	create temporary table tt_routes as
    	select * 
    	from (
    	 select case when x.state=1 then 1 else 0 end isactive, x.reason,ifnull(x.exception,0) exception,
    			case when ((ifnull(x.exception,0) = 0) ) then 0 
    				when x.exception > 0 then cast((x.exception+0.5)*10 as SIGNED integer) 
    				else cast((x.exception-0.5)*10 as SIGNED integer) end calcException,
    			x.id, x.parentId, x.routeCls, x.oprId, x.prefixCode, x.clsOrg, x.cls, 
    			x.costOrgCurr, x.costOrg, x.cost, x.priority, rating, x.flag, x.ext, 
    			x.lastUpd, x.lastUpdBy, x.lastLock, x.lastLockBy,ifnull(x.quality,1.0) quality,x.uploaddate,x.uploadby,x.exceptioncls, x.UpdateFlag
    	 from R20_ROUTE08 x, tt_timecls_selected b
    	 where x.routecls=b.routecls and x.oprid=b.oprid and x.pc=b.pc and x.prefixcode=b.prefixcode and x.cls=b.cls
    	) c order by cost;
    
    	drop temporary table if exists tt_temp_one;
    	create temporary table tt_temp_one as 
    	select *
    	
    	from tt_routes;
    
    	set counter=row_count() ;
    
    	alter table tt_temp_one add seqno int auto_increment primary key;
     alter table tt_temp_one add strtimecls varchar(100);
    	SET @@auto_increment_increment=10;
     
     update tt_temp_one set strtimecls = space(100);
     
     	ALTER TABLE tt_temp_one AUTO_INCREMENT = 10;
    
    	
    	set idx=1;
    	
    	while idx<=counter*10 do
    		select a.cls,a.oprid  into dacls,daoprid
    		from tt_temp_one a where a.seqno=idx limit 1;
    
    		if dacls in('O','P','W') then
    			set strtimecls=dacls; 
    		else 
    			set strtimecls='';
    			
    			select group_concat(cls) into strtimecls from r_timecls where tintid=daoprid group by cls;
    
    			if strtimecls<>'' then
    				set Strtimecls=left(strtimecls,CHAR_LENGTH(strtimecls)-1);
    			End if;
    		end if;
    		update tt_temp_one set strtimecls=strtimecls where seqno=idx;
    		set idx=idx+1;
    	end while;
     
    	if oprtype=0 then
 		insert into tt_temp(routeset, calcException, priority, id, isactive, reason, exception, ext, routecls, prefixcode, universe, domain, pdomain,
         `group`, interface, userinfo, hint, clsOrg, timecls, cost, flag, rating, access, redlist, lastUser, UpdateFlag, OprID, lastUpd, `except`, lastlockby, lastlock, strtimecls,grade ,
         uploaddate, uploadby, capability, dtmf)
    		select 'R20_ROUTE08' routeset,calcException, x.seqno priority, x.id, x.isactive, x.reason, x.exception, ifnull(x.ext,0) ext,x.routecls, x.prefixcode, y.universe, y.domain, y.pdomain,
    			y.group, y.name interface, y.userinfo, y.hint, x.clsOrg, x.cls timecls, x.cost, x.flag, x.rating,
    			'11111' access, 0 redlist,
    			x.lastUpdBy lastUser,x.UpdateFlag, x.OprID, 
    			cast(x.lastupd as date) lastUpd, 
    			ifnull(x.calcException,0) `except`, 
    			ifnull(lastlockby,'') lastlockby,
    			ifnull(cast(lastlock as date),'') lastlock ,
    			x.strtimecls,x.quality grade ,
    			ifnull(cast(x.uploaddate as date),'-') uploaddate,
    			ifnull(x.uploadby,'-') uploadby ,
    			exceptioncls capability,(exceptioncls&0x1) dtmf 
    		from tt_temp_one x, r_interface y  
    		where x.oprId=y.id 
    		and x.quality<=pGrade 
    		order by seqno+calcException;
    
    	else 
 		insert into tt_temp(routeset, calcException, priority, id, isactive, reason, exception, ext, routecls, prefixcode, universe, domain, pdomain,
         `group`, interface, userinfo, hint, clsOrg, timecls, cost, flag, rating, access, redlist, lastUser, UpdateFlag, OprID, lastUpd, `except`, lastlockby, lastlock, strtimecls,grade ,
         uploaddate, uploadby, capability, dtmf)
    		select 'R20_ROUTE08' routeset,calcException, x.seqno priority, x.id, x.isactive, x.reason, x.exception, ifnull(x.ext,0) ext,x.routecls, x.prefixcode, y.universe, y.domain, y.pdomain,
    			y.group, y.name interface, y.userinfo, y.hint, x.clsOrg, x.cls timecls, x.cost, x.flag, x.rating,
    			'11111' access, 0 redlist,
    			x.lastUpdBy lastUser,x.UpdateFlag,x.OprId ,
    			cast(x.lastupd as date) lastUpd, 
    			ifnull(x.calcException,0) `except`, 
    			ifnull(lastlockby,'') lastlockby, 
    			ifnull(cast(lastlock as date),'') lastlock , x.strtimecls,x.quality grade , 
    			ifnull(cast(x.uploaddate as date),'-') uploaddate,ifnull(x.uploadby,'-') uploadby,
    			exceptioncls capability,(exceptioncls&0x1) dtmf
    		from tt_temp_one x, r_interface y  
    		where x.oprId=y.id 
    		and x.quality<=pGrade and y.type=oprtype
    		order by seqno+calcException;
 		end if;
        
        SET @@auto_increment_increment=1;
    end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r24_routeGetCache_web` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `r24_routeGetCache_web`(
     pLongest varchar(32),    
      pLongestCls int,    
      pDate datetime,    
      pSrcInt varchar(7),    
      pSrcIntGroup varchar(64),    
      pSrcIntDom varchar(64),    
      routeclass int,
      pCLI varchar(32),
      pOperatorGroup int,
      pGrade float,
      oprtype int
   )
begin
   
   
   
   
   	declare pc varchar(2);
   	declare dd int; 
   	declare hh int; 
   	declare mm int;  
   	declare counter int; 
   	declare strtimecls varchar(100);  
   	declare idx int;  
   	declare daoprid int; 
   	declare dacls varchar(10);
   
   	if routeclass is null		then set routeclass = 0;		end if;
   	if pCLI is null				then set pCLI = '';				end if;
   	if pOperatorGroup is null	then set pOperatorGroup = 0;	end if;
   	if pGrade is null			then set pGrade = 99.0;			end if;
   	if oprtype is null			then set oprtype = 0;			end if;
   
   	set pc=left(pLongest,2);
   	
   	
   	set dd = (SELECT 1 + (WEEKDAY(NOW()) + 1) % 7);
   	
   	
   
   	select (HOUR(pDate) - 0) into hh from r_info limit 1;
   
   	set mm = DATE_FORMAT(pDate, "%i") ;
       
   	DROP TEMPORARY TABLE if exists tt_operator_selected;
   	CREATE TEMPORARY TABLE tt_operator_selected 
   	(    
   		 routecls int NOT NULL,    
   		 oprId int NOT NULL,    
   		 cls varchar (1) NOT NULL,    
   		 pc varchar (2) NOT NULL,    
   		 constraint idx1 primary key(routecls, oprId, cls, pc),
   		 key idx1_tt_operator_selected  (routeCls,oprId,pc)
   	);
   
   	insert into tt_operator_selected(routecls,oprid,cls,pc)    
   	select x.routecls,x.oprid,x.cls,x.pc 
   	from r20_route_timecls x , r_timecls y  , r_interface tit  ,
   	r_timecode tco  , r_daycode dco    
   	where x.routecls=0  
   	and tit.id = x.oprid and tit.state = 'I'   
   	and y.tintid =x.oprid and y.cls=x.cls   
   	and y.dc=dco.id and y.tc=tco.id and y.sc=0
   	and dd between dco.d1 and dco.d2 
   	and ((24+hh+ifnull(tit.prefixcls,0))%24) * 100 + mm between tco.h1 and tco.h2-1  
   	and x.pc=pc  ;  
       
   	drop temporary table if exists tt_timecls_selected;
   	create temporary table tt_timecls_selected
   	(id int auto_increment primary key,routeCls	int,oprId	int,pc	varchar(2),prefixCode	varchar(16),prefixLen	int,
   	cnt int,clsA tinyint,clsP tinyint,clsO tinyint,clsW tinyint,cls char(1));
   
   	insert into tt_timecls_selected(routeCls,oprId,pc,prefixCode,cnt,clsA,clsP,clsO,clsW,cls)
   	select a.routecls, a.oprid, a.pc, max(a.prefixCode) prefixCode,
   	 count(*) cnt,
   	 sum(case when a.cls='A' then 1 else 0 end) clsA,
   	 sum(case when a.cls='P' then 1 else 0 end) clsP,
   	 sum(case when a.cls='O' then 1 else 0 end) clsO,
   	 sum(case when a.cls='W' then 1 else 0 end) clsW, 'Z' cls  
   	from R20_ROUTE08 a, tt_operator_selected b
   	where (pLongestCls not in (3,4) or a.priority=1)  
   	and a.routeCls=b.routeCls and a.oprId=b.oprId and a.pc=b.pc
   	and left(pLongest,prefixLen)=a.prefixcode and  a.cls=b.cls
   	group by a.routecls, a.oprid, a.pc;   
   
   	update tt_timecls_selected 
   	set cls = (case when (clsW>0) and (cnt = clsW) then 'W' 
   			  when (clsO>0) and (cnt = clsO) then 'O'  
   			  when (clsP>0) and (cnt = clsP) then 'P'  
   			  when (clsA>0) and (cnt = clsA) then 'A' 
   		else 'Z' end);
   
   	update tt_timecls_selected 
   	set cls = (select max(a.cls) from R20_ROUTE08 a 
   		 where a.routecls=tt_timecls_selected.routecls 
   		 and a.oprid = tt_timecls_selected.oprId 
   		 and a.pc=tt_timecls_selected.pc 
   		 and a.prefixCode=tt_timecls_selected.prefixCode
   		 and ((a.cls='A' and tt_timecls_selected.clsA<>0) or 
   			  (a.cls='P' and tt_timecls_selected.clsP<>0) or
   			  (a.cls='O' and tt_timecls_selected.clsO<>0) or
   			  (a.cls='W' and tt_timecls_selected.clsW<>0))
   	  )
   	where cls = 'Z';
   
   	drop temporary table if exists tt_routes;
   	create temporary table tt_routes
   	(
   		id int auto_increment,isactive int,parentId int NULL,state int NULL,reason int NULL,routeCls int NOT NULL,oprId int NOT NULL,pc varchar(2) NULL,
   		prefixCode varchar(16) NOT NULL,prefixLen int NULL,destCode varchar(32) NULL,clsOrg varchar(2) NOT NULL,cls varchar(2) NOT NULL,costOrgCurr varchar(4) NOT NULL,
   		costOrg float NOT NULL,cost float NOT NULL,priority float NOT NULL,access int NULL,quality float NULL,rating int NULL,flag int NOT NULL,ext int NULL,
   		lastUpd datetime NOT NULL,lastUpdBy varchar(16) NOT NULL,exception int NULL default 0,exceptionCls int NULL default 0,lastLock datetime NULL,
   		lastLockBy varchar(50) NULL,uploadDate datetime NULL,uploadBy varchar(100) NULL,UpdateFlag smallint NULL default 0,opr_cost float NULL,
        calcException int,
   		CONSTRAINT pk_R20_ROUTE08 UNIQUE KEY (id) 
   	);
   
   	insert into tt_routes(isactive  , reason  , exception  , calcException  ,id  ,parentId  ,routeCls  ,oprId  ,prefixCode  ,clsOrg  ,cls  	,
   			costOrgCurr  ,costOrg  ,cost  ,priority  ,rating  ,flag  ,ext  ,lastUpd ,lastUpdBy  ,lastLock ,lastLockBy ,quality  ,
   			uploadDate  ,uploadBy ,exceptionCls ,UpdateFlag )
   	select isactive  , reason  , exception  , calcException  ,id  ,parentId  ,routeCls  ,oprId  ,prefixCode  ,clsOrg  ,cls  	,
   			costOrgCurr  ,costOrg  ,cost  ,priority  ,rating  ,flag  ,ext  ,lastUpd ,lastUpdBy  ,lastLock ,lastLockBy ,quality  ,
   			uploadDate  ,uploadBy ,exceptionCls ,UpdateFlag 
   	from (  
   	 select case when x.state=1 then 1 else 0 end isactive, x.reason,ifnull(x.exception,0) exception,  
   			case when ((ifnull(x.exception,0) = 0)) then 0 
   				when x.exception > 0 then cast((x.exception+0.5)*10 as SIGNED int) 
   				else cast((x.exception-0.5)*10 as SIGNED int) end calcException,  
   		  x.id, x.parentId, x.routeCls, x.oprId, x.prefixCode, x.clsOrg, x.cls,   
   		  x.costOrgCurr, x.costOrg, x.cost, x.priority, rating, x.flag, x.ext,   
   		  x.lastUpd, x.lastUpdBy, x.lastLock, x.lastLockBy,ifnull(x.quality,1.0) quality,x.uploaddate,x.uploadby,x.exceptioncls, x.UpdateFlag    
   	 from R20_ROUTE08 x, tt_timecls_selected b    
   	where x.routecls=b.routecls and x.oprid=b.oprid and x.pc=b.pc and x.prefixcode=b.prefixcode and x.cls=b.cls  
   	) c order by cost;  
    
   
   	drop temporary table if exists tt_one;
   	create temporary table tt_one
   	(
   		seqno int auto_increment primary key,isactive int,
   		parentId int NULL,state int NULL,reason int NULL,routeCls int NOT NULL,oprId int NOT NULL,pc varchar(2) NULL,
   		prefixCode varchar(16) NOT NULL,prefixLen int NULL,destCode varchar(32) NULL,clsOrg varchar(2) NOT NULL,cls varchar(2) NOT NULL,costOrgCurr varchar(4) NOT NULL,
   		costOrg float NOT NULL,cost float NOT NULL,priority float NOT NULL,access int NULL,quality float NULL,rating int NULL,flag int NOT NULL,ext int NULL,
   		lastUpd datetime NOT NULL,lastUpdBy varchar(16) NOT NULL,exception int NULL default 0,exceptionCls int NULL default 0,lastLock datetime NULL,
   		lastLockBy varchar(50) NULL,uploadDate datetime NULL,uploadBy varchar(100) NULL,UpdateFlag smallint NULL default 0,opr_cost float NULL,
   		strtimecls varchar(200),calcException int,id int,
   		CONSTRAINT pk_R20_ROUTE08 UNIQUE KEY (seqno)
   	);
    
 	
 	
     
   	SET @@auto_increment_increment=10;
     
     update tt_one set strtimecls = space(100);
   
   	ALTER TABLE tt_one AUTO_INCREMENT = 10;
   
   	insert into tt_one(isactive  , reason  , exception  , calcException  ,id  ,parentId  ,routeCls  ,oprId  ,prefixCode  ,clsOrg  ,cls  	,
   			costOrgCurr  ,costOrg  ,cost  ,priority  ,rating  ,flag  ,ext  ,lastUpd ,lastUpdBy  ,lastLock ,lastLockBy ,quality  ,
   			uploadDate  ,uploadBy ,exceptionCls ,UpdateFlag)
   	
   	select  isactive  , reason  , exception  , calcException  ,id  ,parentId  ,routeCls  ,oprId  ,prefixCode  ,clsOrg  ,cls  	,
   			costOrgCurr  ,costOrg  ,cost  ,priority  ,rating  ,flag  ,ext  ,lastUpd ,lastUpdBy  ,lastLock ,lastLockBy ,quality  ,
   			uploadDate  ,uploadBy ,exceptionCls ,UpdateFlag     
   	from tt_routes;
   
   	set counter=row_count() ;
    
   	
     
   	set idx=1;
   	while idx<=counter*10 do
   		select a.cls,a.oprid into dacls,daoprid 
   		from tt_one a where a.seqno=idx  limit 1;
   		
   		if dacls in('O','P','W') then
   			set strtimecls=dacls; 
   		else 
   			set strtimecls='' ; 
   
   			set strtimecls = (select  group_concat(cls) from r_timecls where tintid=daoprid group by cls ); 
   
   			if strtimecls<>'' then 
   				set Strtimecls=left(strtimecls,CHAR_LENGTH(strtimecls)-1);  
   			end if;
   		end if;
   		update tt_one set strtimecls=strtimecls where  seqno=idx  ;
   		set idx=idx+1;
   	end while;
   
    if oprtype=0  then
   		drop temporary table if exists tt_two ;
   		create temporary table tt_two  
   		as
   		select  'r20_route08' routeset, calcException, 
   				x.seqno priority, x.id, x.isactive, x.reason, x.exception, ifnull(x.ext,0) ext,  
   				x.routecls, x.prefixcode, y.universe, y.domain, y.pdomain, 
   				y.group, y.name interface, y.userinfo, y.hint, x.clsOrg, x.cls, x.cost, x.flag, x.rating,  
   				'11111' access, 0 redlist,  
   				x.lastUpdBy lastUser,  x.UpdateFlag, x.OprID, 
   				cast(x.lastupd as date) as lastUpd,
   				ifnull(x.calcException,0) `except`,
   				ifnull(lastlockby,'') lastlockby, 
   				ifnull(cast(lastlock as date),'') lastlock   
   				, x.strtimecls,x.quality grade 
   				,ifnull(cast(x.uploaddate as date),'-') uploaddate
   				,ifnull(x.uploadby,'-') uploadby   
   				,exceptioncls capability,(exceptioncls&  0x1) dtmf
   		
   		from tt_one x, r_interface y   
   		where x.oprId=y.id 
   		and x.quality<=pGrade;
     
   		select a.routeset, a.calcException, a.priority, a.id, a.isactive, a.reason, a.exception, a.ext, a.routecls, a.prefixcode, a.universe, a.domain, a.pdomain, a.`group`, 
   				a.interface, a.userinfo, a.hint, a.clsOrg, a.cls timecls, a.cost, a.flag, a.rating, a.access, a.redlist, a.lastUser,
   				case when b.state = 1 then 0 else a.UpdateFlag end UpdateFlag,
   				a.OprID, a.lastUpd, a.`except`, 
   				a.lastlockby, a.lastlock, a.strtimecls, a.grade, a.uploaddate, a.uploadby, a.capability, a.dtmf, 
   				1 LycaState, b.cost LycaCost, b.ext LycaExt, b.exception LycaException, b.Quality LycaGrade 
   		from tt_two a 
           left join routing_lyca.r20_route12 b   
   		on b.pc = pc and a.oprId = -b.oprId and a.prefixcode = b.prefixcode and a.cls = b.cls  
   		order by a.priority+calcException ;
   	end if;
 		  SET @@auto_increment_increment=1;
   end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r24_routeSpecialGetCache_08` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `r24_routeSpecialGetCache_08`(
 pLongest varchar(32),
 pDate datetime,
 pSrcInt varchar(7),
 pSrcIntGroup varchar(64),
 pSrcIntDom varchar(64),
 routeclass int,
 pCLI varchar(32),
 pOperatorGroup int,
 pGrade float
)
begin

		if routeclass is null then set routeclass=0; end if;
		if pCLI is null then set pCLI=''; end if;
		if pOperatorGroup is null then set pOperatorGroup=0; end if;
		if pGrade is null then set pGrade =99.00; end if;


	select 'r20_route08' routeSet
			, 0 calcexception
			, 1 priority
			, a.id
			, a.state isactive
			, reason
			, 0 exception
			, 0 ext
			, a.routecls
			, prefixCode
			, c.universe
			, b.domain
			, b.pdomain
			, b.`group`
			, b.name interface
			, b.userinfo
			, b.hint
			, clsOrg
			, cls timeCls
			, cost
			, flag
			, rating
			, '11111' access
			, 0 redList
			, lastUpdBy lastUser
			, a.UpdateFlag
			, OprId
			, lastUpd
			, 0 `except`
			, lastLockBy
			, lastLock
			, 'A' strtimecls
			, ifnull(quality,1.0) grade
			, ifnull(cast(a.uploaddate as date),'-') uploaddate
			, ifnull(a.uploadby,'-') uploadby 
			, a.exceptioncls capability
			, (a.exceptioncls&0x1) dtmf
			, 0 LycaState
			, 0.0 LycaCost
			, 0 LycaExt
			, 0 LycaException
			, 0 LycaGrade 
	from R20_ROUTE08 a
	join r_interface b on a.oprid = b.id
	join r_domain c on b.domain=c.name 
	where a.routeCls=0 
	and a.pc=left(pLongest,2) 
	and a.prefixcode=pLongest
	
	and ifnull(quality,1.0)<=pgrade; 

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r25_routeExcept` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `r25_routeExcept`(
  pRouteSet varchar(16),
  pOperator varchar(16),
  pTimecls varchar(2),
  pPrefix varchar(16),
  pValue int,
  pUser varchar(16)  
 )
sp_return:begin
 
 	declare oprid int;
 	declare v_where varchar(2000);
 	declare comment varchar(150);
 	declare pParentID float;
 	declare pDest varchar(32) ;
 
 	set comment=concat('exception : ',cast(pValue as SIGNED INTEGER));
 
 
 	select a.id into oprid from r_interface a where a.reserved=pOperator limit 1;
 
 	if oprid is null then
 		select -1 ErrorCode, concat('*** Operator{',pOperator,'} Not Found') as ErrorString;
 		leave sp_return;
 	end if;
 
 	set pPrefix=cast(pPrefix as char(16));
 
 	if pUser is null then set pUser = USER(); end if;
 
 	set v_where = concat('routecls=0 and oprid=',cast(oprid as SIGNED INTEGER),' and cls=''',pTimecls,''' and pc=''' ,left(pPrefix,2),''' and prefixcode=''',pPrefix,'''');
 
 	
 	
 	set @sql = concat('update ' , pRouteSet , ' set exception=' , cast(pValue as SIGNED INTEGER) , 
 			',lastUpd=current_timestamp(),lastUpdBy=''',pUser,''',UpdateFlag=0 where ' , v_where , ' and ext=0'); 
 	
 		PREPARE STMT FROM @sql;
 		EXECUTE STMT;
 		DEALLOCATE PREPARE STMT;
 
 	if row_count() > 0 then
 		 call routinghistory.rh_insert(poperator,pPrefix,  pTimeCls ,10000  ,31,puser,10,pRouteSet,comment);
 		 select 0 ErrorCode, 'OK.' ErrorString, 'EXCEPTION assigned [normal route]' Note;
 		 leave sp_return;
 	 end if;
     
 	
 
 	set @sql = concat('update ' , pRouteSet , ' set ext=ext+100,exception=' , cast(pValue as SIGNED INTEGER), ',lastUpd=current_timestamp(),lastUpdBy=''',pUser,''',UpdateFlag=0 where ' , v_where , ' and ext<100'); 
 	
 	PREPARE STMT FROM @sql;
 	EXECUTE STMT;
 	DEALLOCATE PREPARE STMT;
 
 	if row_count() > 0 then
 		call routinghistory.rh_insert(poperator,pPrefix,  pTimeCls ,10000  ,31,puser,10,pRouteSet,comment);
 		select 0 ErrorCode, 'OK.' ErrorString, 'EXCEPTION assigned' Note;
 		leave sp_return;
 	end if;
 
 	
 	set @sql = concat('update ' , pRouteSet , ' set exception=' , cast(pValue as SIGNED INTEGER) , 
 	 ',lastUpd=current_timestamp(),lastUpdBy=''',pUser,''',UpdateFlag=0 where ' , v_where , ' and ext>=100'); 
 	
 	PREPARE STMT FROM @sql;
 	EXECUTE STMT;
 	DEALLOCATE PREPARE STMT;
 
 	if row_count() > 0 then
 		 call routinghistory.rh_insert(poperator,pPrefix,  pTimeCls ,10000  ,31,puser,10,pRouteSet,comment);
 		 select 0 ErrorCode, 'OK.' ErrorString, 'EXCEPTION re-assigned' Note;
 		leave sp_return;
 	 end if;
 
 	
 	call r22_routeGetParent2 (pRouteSet, oprid, pTimecls, pPrefix, pParentID);
 	
 	if pParentID is null then
 		select -1 ErrorCode, 'OK.' ErrorString, '*** Nearest Entry not found' Note;
 		leave sp_return;
 	end if;
    
	Insert into R20_routeCPrice (pc, prefixcode, cls, Oprid, Cost)  
	select a.pc, a.prefixcode, a.cls, a.OprId, Cost 
    from   
		(
			select rr.pc, rr.prefixcode, rr.cls, rr.oprid from r20_route08 rr where rr.id = pParentID and rr.oprId = oprId and rr.cls = pTimeCls
		) a   
		inner join   
		(
			select cp.pc, cp.prefixcode, cp.cls, cp.oprId, cp.Cost from R20_routeCPrice cp where cp.pc = left(pPrefix, 2) and cp.oprId = oprId 
		) b on a.pc = b.pc and a.prefixcode = b.prefixcode and a.cls = b.cls and a.OprId = b.OprId;
 
 	set @sql = concat('insert ',pRouteSet, '(parentID,state,reason,ext,routecls,oprid,pc,prefixCode,prefixLen,clsOrg,clscostOrgCurr,costOrg,cost,priority,access,flag,lastUpd,lastUpdBy,uploaddate,uploadby,exception,quality,exceptioncls,UpdateFlag) 
 		select id,state,reason,ext , case when isnull(ext,0)<100 then 100 else 0 end | 1 ,routecls,oprid,''', left(pPrefix,2),''',''',pPrefix,''',',CHAR_LENGTH(CAST(pPrefix as SIGNED INTEGER)),',cls,''',pTimecls,'''',
 	 ',costOrgCurr,costOrg,cost,priority,access,flag,current_timestamp(),''',pUser,''',current_timestamp(),''',pUser,''',',CAST(pValue as SIGNED INTEGER),
 	 ',quality,exceptioncls,0 from ' , pRouteSet , ' where id=',CAST(pParentID as FLOAT),' and parentID is null');
 
 	PREPARE STMT FROM @sql;
 	EXECUTE STMT;
 	DEALLOCATE PREPARE STMT;
 
 	call r22_routeGetDest (pPrefix, pDest);
 	call r22_routePrefixNew (pPrefix, pDest);
 	call r22_routeTimeclsAdd (pRouteSet,0,oprid,pTimecls,pPrefix);
 
 	
 	call routinghistory.rh_insert(poperator,pPrefix,  pTimeCls ,10000  ,31,puser,10,pRouteSet,comment);
 	select 0 ErrorCode, 'OK.' ErrorString, 'New EXCEPTION-VIRTUAL inserted' Note;
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r25_routeUnExcept` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `r25_routeUnExcept`(
  pRouteSet varchar(16),
  pOperator varchar(16),
  pTimecls varchar(2),
  pPrefix varchar(16),
  pUser varchar(16)
 )
sp_return:begin
 
 	declare oprid int;
 	declare v_where varchar(2000); 
 	declare comment varchar(150);  
 	set comment='exception : 0 (unexcept)';
 
 
 
 	select a.id into oprid from r_interface a where a.reserved=pOperator limit 1;
 
 	if oprid is null then
 		select -1 ErrorCode, CONCAT('*** Operator{',pOperator,'} Not Found') AS ErrorString;
 		leave sp_return;
 	end if;
 
 	set pPrefix=ltrim(rtrim(pPrefix));
 
 	if pUser is null THEN set pUser = user(); END IF;
 
 		set v_where = concat('routecls=0 and oprid=',cast(oprid as SIGNED INTEGER),' and cls=''',pTimecls,''' and pc=''' , 
 					left(pPrefix,2),''' and prefixcode=''',pPrefix,''' ');
 
 		set @sql = concat('delete ', pRouteSet,' where ', v_where , 'and ext = 101');
 
 		PREPARE STMT FROM @sql;
 		EXECUTE STMT;
 		DEALLOCATE PREPARE STMT;
 
 	if row_count() > 0 then
    
		delete from r20_routeCPrice where oprid = cast(oprid as SIGNED INTEGER) and cls = pTimecls and pc = left(pPrefix, 2) and prefixcode = pPrefix;
 		
 		call r22_routeTimeclsDel (pRouteSet,0,oprid,pTimecls,pPrefix ); 
 		
 		call routinghistory.rh_insert(poperator,pPrefix,  pTimeCls ,10000  ,31,puser,10,pRouteSet,comment);
 		
 		select 0 ErrorCode, 'OK.' ErrorString, 'Deleted' Note;
 		
 		leave sp_return;
 
 	end if;
   
 		set @sql = concat('update ' , pRouteSet , ' set exception=null',',lastUpd=current_timestamp(),lastUpdBy=''',pUser,''',UpdateFlag=0 where ' , v_where , ' and ext=0'); 
 
 		PREPARE STMT FROM @sql;
 		EXECUTE STMT;
 		DEALLOCATE PREPARE STMT;
 
 	if rowcount > 0 then
 		call routinghistory.rh_insert (poperator,pPrefix,  pTimeCls ,10000  ,31,puser,10,pRouteSet,comment);
 
 		select 0 ErrorCode, 'OK.' ErrorString, '' Note;
 		leave sp_return;
 	end if;
 
 	set @sql = concat('update ' , pRouteSet , ' set ext=ext-100,exception=null,lastUpd=current_timestamp(),lastUpdBy=''',pUser,''',UpdateFlag=0 where ' , v_where  ,' and ext>=100 '); 
 
 	PREPARE STMT FROM @sql;
 		EXECUTE STMT;
 		DEALLOCATE PREPARE STMT;
 
 	if row_count() > 0 then
 		call routinghistory.rh_insert (poperator,pPrefix,  pTimeCls ,10000  ,31,puser,10,pRouteSet,comment);
 		select 0 ErrorCode, 'OK.' ErrorString, '' Note;
 		leave sp_return;
 	end if;
 
 select -1 ErrorCode, '*** Entry not found.' ErrorString ;
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `RDOMAIN_get` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `RDOMAIN_get`(
   pUniverse varchar(32),
   pName varchar(32)
)
begin
	select a.state,a.universe,a.name,a.longname,a.timezone 
	from routingv3.r_domain a
	where a.universe=pUniverse and a.name=pName;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `RDOMAIN_list` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `RDOMAIN_list`()
begin
	select state,universe,name,longname,timezone 
	from routingv3.r_domain
	order by universe,name;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `RDOMAIN_upd` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `RDOMAIN_upd`(
 	pUniverse varchar(32),
 	pName varchar(32),
 	pLongName varchar(32),
 	pTimeZone int,
 	pState varchar(1),
 	login varchar(32)
 )
begin
 	declare tempstat int;
 	declare comment varchar(150);
 
 	if exists(select 1 from r_domain where universe=pUniverse and name=pName limit 1) then
 		update r_domain a
 		set a.longname=pLongName, 
 			a.timezone=pTimeZone, 
 			a.state=pState
 		where a.universe=pUniverse and a.name=pName;
 
 		set comment=concat('[',plongname,'][' , pUniverse ,'][' , ptimezone ,']');
 
 		if pstate='I' then
 			set tempstat=1;
 		else
 			set tempstat=0;
 			call routinghistory.rh_insert(pname, 'Modify domain' ,'-',0,0,login,tempstat,null, comment);
 			select 0 ErrCode, 'OK' ErrStr;
 		end if;
 	else
 		select -1 ErrCode, 'DomainProfile not found.' ErrStr;
 	end if;
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `rh_insert` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `rh_insert`(
  operator varchar(50),  
  prefixcode varchar(50),  
  timeclass varchar(4),  
  cost float,  
  access int,  
  login varchar(50),  
  isactive int,
  Rset varchar(100),
  comment varchar(150) 
 )
begin  
 
 	if isactive is null then
 		set isactive = 1;
 	End if;
 
 	insert into routinghistory.routingtransaction ( operator, prefixcode , timeclass , cost ,access, thedate, login ,isactive,comment,rset)  
 	values ( operator, prefixcode , timeclass , cost , access, current_timestamp(), login ,isactive,comment,Rset)  ;
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `RINTERFACE1_upd_v3` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `RINTERFACE1_upd_v3`(   
   pID int,
   pState varchar(1),
   name varchar(32),
   `group` varchar(16),
   domain varchar(8),
   pdomain varchar(8),
   Comment varchar(3000),
   login varchar(32),     
   type int
)
begin

	declare pErrCode   int;
	declare pErrStr    varchar(128);

	if login is null then
		set login = '-';
	End if;

	if type is null then
		set type = 1;
	End if;


	call _RINTERFACE1_upd_v3 (pID, pState, `name`,`group` ,domain ,pdomain, `Comment`, login,pErrCode, pErrStr,type );       
	
	select pErrCode ErrCode, pErrStr ErrStr;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `RINTERFACE2_upd` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `RINTERFACE2_upd`(
   pID     int,
   pUnit   varchar(32),
   pHint   varchar(128)
)
begin
	declare pErrCode   int;
	declare pErrStr    varchar(128);

	call _RINTERFACE2_upd (pID, pUnit, pHint, pErrCode , pErrStr );
	select pErrCode ErrCode, pErrStr ErrStr;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `RINTERFACE_get` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `RINTERFACE_get`(
 pID   int    
)
begin    
	select id,state,universe,domain,pdomain,name,`group`,ifnull(hint,'') hint, userinfo,ifnull(type,1) intcls     
	from r_interface    
	where id=pID;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `RINTERFACE_get_v2` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `RINTERFACE_get_v2`(
 pID int      
 )
begin      
 		select id,state,universe,domain,pdomain,name,`group`,ifnull(hint,'') as hint, userinfo,ifnull(type,1) intcls, 
 			LastUpdate, LastUpdateBy, Comment
 		from r_interface_V2
 		where id=pID;
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `RINTERFACE_list_v4` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `RINTERFACE_list_v4`(
 pName varchar(40) 
 )
begin   
 
 	
 	
 	
 	  
 	
         select	a.id, ifnull(a.state, 'M') State, ifnull(a.state, 'M') Lstate, a.name,a.group,a.domain,a.universe,ifnull(a.hint,'') hint,        
 				ifnull(a.Updateflag, 0) UpdateFlag,               
 				case ifnull(a.type,0) when 2 then 'IP' else 'Carrier' end intcls,LastUpdate, a.LastUpdateBy, a.Comment      
         from r_interface_V2 a  
         where a.routecls<>1 and a.name not like 'dac%' and a.name not like 'rtp%'                  
         and a.name like pName ;
   
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `RMOBILENOTIF_list` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `RMOBILENOTIF_list`()
begin   
	
	select s.* from sms_notif_list as s;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `route_getList` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `route_getList`(  
	webstatus int
)
begin  

	if webstatus is null then
		set webstatus =1;
    End if;
    
	select a.clsid, a.routename ,a.set as routeset 
    from route_config a
	where a.webstatus=webstatus  
	order by a.routetype, a.clsid  ;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `RPREFIX_del` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `RPREFIX_del`(
   pPrefixCode   varchar(32),
   login varchar(32) 
)
begin
   declare pErrCode int;
   declare pErrStr  varchar(128);

   if login is null then
	set login='';
   End if;

   call _RPREFIX_del (pPrefixCode, pErrCode , pErrStr );

   call routinghistory.rh_insert ('Delete prefix', pprefixcode ,'-',0,0,login,0, '');

   select pErrCode ErrCode, pErrStr ErrStr;
   
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `RPREFIX_list_New` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `RPREFIX_list_New`(
    pRouteSet   varchar(32),
    pStart      varchar(32),
    pMaxRec     int,
    pLike       varchar(32),
    dLike     varchar(50)
 )
begin  
    
    declare cost text;
 
 	if pRouteSet is null then set pRouteSet = 'CURRENT'; end if;
 	if pMaxRec is null then set pMaxRec = 50; end if;
 	if pLike is null then set pLike = '%%'; end if;
 	if dLike is null then set dLike = '%%'; end if;
 
 
    set @sql = concat('  
    select  state,prefixcode,destcode,  
       ''N/A'' offpeak_ccost,   
       ''N/A'' offpeak_eccost,   
       ''N/A'' peak_ccost,   
       ''N/A'' peak_eccost   
    from (  
    select x.state,x.prefixcode,x.destcode  
    from r_prefix2 x  
    where x.prefixcode like ''' , pLike , '''  
    and x.destcode like ''', dlike ,'''  
    and x.prefixlen>0  
    ) a  ');
    
 
 	if pStart is not null then 
 		set @sql = concat(@sql , ' where prefixcode>''' , pStart , '''');  
 	end if;
 
    set @sql = concat(@sql , ' group by state, prefixcode, destcode');  
 
    set @sql = concat(@sql , ' order by prefixcode limit ', CAST(pMaxRec as SIGNED INTEGER));
    
    PREPARE STMT FROM @sql;
    EXECUTE STMT;
    DEALLOCATE PREPARE STMT;
 
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `RPREFIX_upd` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `RPREFIX_upd`(
  pPrefixCode varchar(32),
  pDestCode varchar(32),
  pState varchar(1),
  login varchar(32)
 )
begin
 
 	declare pErrCode int;
 	declare pErrStr varchar(128);
 	declare tempstat int;
 	declare comment varchar(150);
 
 	if login is null then
 		set login = '';
 	End if;
 
 	set pDestCode= replace(pDestCode,',','');
 	set comment= concat('[',pdestcode,']');
 
 	call _RPREFIX_upd (pPrefixCode, pDestCode, pState, pErrCode , pErrStr );
 
 	if pstate='I' then
 		set tempstat=1;
 	else
 		set tempstat=0;
 	End if;
 
 	call routinghistory.rh_insert ('Modify prefix', pprefixcode ,'-',0,0,login,null,tempstat, comment); 
 
 	select pErrCode ErrCode, pErrStr ErrStr;
 
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `RSET_addInterface_v2` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `RSET_addInterface_v2`(
   pRouteSet  varchar(32),
   pName varchar(32),
   pDomain    varchar(32),
   defRuleID int, 
   pUser varchar(32),
   pGroup varchar(32),
   pUniverse varchar(32)
)
begin
   declare pErrCode int;
   declare pErrStr varchar(128);

   if pUser is null then
	set pUser ='';
   end if;

   if pGroup is null then
	set pGroup ='';
   end if;

   if pUniverse is null then
	set pUniverse ='EU';
   end if;

   call _RSET_addInterface_v2 (pRouteSet, pName, pDomain, pGroup, pUniverse,defRuleID,pErrCode, pErrStr,pUser);

   select pErrCode ErrCode, pErrStr ErrStr;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `rset_add_ctest_V2` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `rset_add_ctest_V2`(
 	 pRoute varchar(32), 
 	 pPrefixCode varchar(16), 
 	 pDestCode varchar(32), 
 	 pSrcInt varchar(16), 
 	 pSrcUnit varchar(16),	
 	 pSrcOpr varchar(16),	
 	 pSrcDom varchar(16),	
 	 pTrgInt varchar(16), 
 	 pTrgUnit varchar(16),	
 	 pTrgOpr varchar(16),	
 	 pTrgDom varchar(16),	
 	 pSrcUniverse varchar(16),
 	 pTrgUniverse varchar(16)
 )
sp_return:begin 
 
 	declare timezone int; 
 	declare id int; 
 	declare pc varchar(2); 
 	declare temp int; 
 	declare userinfo varchar(32); 
 	declare flag varchar(1); 
 
 	if pSrcUniverse is null then set pSrcUniverse = 'EU'; END IF;
 	if pTrgUniverse is null then set pTrgUniverse = 'EU'; END IF;
  
 	set pPrefixCode = ltrim(rtrim(pPrefixCode));
  
 	 if exists (select * from r_prefix2 where prefixcode=pPrefixCode limit 1) then
 		select -1 errorCode, 'PrefixCode in-use either by Normal Routing or CarrierTest.' errorString; 
 		leave sp_return ;
 	 end  if;
  
 	 START transaction;
 	 
 	 insert r_prefix_intest(state, prefixcode, destcode, sname, sunit, sgroup, sdomain, suniverse, tname, tunit, tgroup, tdomain, tuniverse) 
 	 values ('I',pPrefixCode, pDestCode, pSrcInt, pSrcUnit, pSrcOpr, pSrcDom, pSrcUniverse, pTrgInt, pTrgUnit, pTrgOpr, pTrgDom, pTrgUniverse); 
  
 	 if pTrgInt='ALL' then
 			select a.id into id from r_interface a where a.name=pTrgOpr and a.domain=pTrgDom and a.universe=pTrgUniverse limit 1; 
 			if id is null then
 				rollback; 				
 				select -1 errorCode, 'Can`t find Target-Operator.' errorString ;
 				leave sp_return ;
 			end if; 
 	 else 
 			if pTrgUnit = 'ALL' then
 				set userinfo = null; 
 			else 
 				set userinfo = pTrgUnit; 
 				select a.timezone into timezone from r_domain a where a.name=pTrgDom limit 1; 
 
 				select a.id into id 
 				from r_interface a
 				where a.name=pTrgInt and a.`group`=pTrgOpr and a.domain=pTrgDom and a.universe=pTrgUniverse limit 1;
  
 				 if id is null then 
 					 insert r_interface(state,universe,domain,pdomain,name,`group`,routecls,userinfo,allowloop,prefixcls,reserved) 
 					 values ('I',pTrgUniverse,pTrgDom,pTrgDom,pTrgInt,pTrgOpr,0,userinfo,0,timezone,concat(pTrgInt,'',pTrgDom)); 
  
 					 select a.id into id from r_interface a
 					 where a.universe=pTrgUniverse and a.domain=pTrgDom and a.name=pTrgInt and a.`group`=pTrgOpr limit 1;
 				 end if;
  
 				 if id is null then
 					rollback;
 					select -1 errorCode, 'Can`t add interface.' errorString ;
 					leave sp_return ;
 				 end if; 
  
 				select  a.tintid into temp from r_timecls a 
 				where a.state='I' and a.tintid=id and a.cls='A' and a.dc=0 and a.tc=0 and a.sc=0 limit 1;
 				
 				if (temp is null) then
 					insert into r_timecls(state,tintid,cls,dc,tc,sc) 
 					values ('I',id,'A',0,0,0); 
 					
 					if row_count() <=0 then 
 						rollback;
 						select -1 errorCode, 'Can`t add timeclass.' errorString; 
 						leave sp_return ;
 					end if;
 				end if;
 			end if;
 		end if;
  
 		if pTrgInt like 'dac%' or pTrgInt like 'rtp%' then
 			set flag = '1';
 		else 
 			set flag = '0';
 		End if;
  
 		set @sql1 = concat(' select * from R20_ROUTE08 where routecls=0 and oprid=',ltrim(id),' and pc=''', left(pPrefixCode,2) ,''' and prefixcode=''', pPrefixCode,'''and cls=''A'''); 
        if @sql1 is not null then
			PREPARE stmt from @sql1;
			execute stmt;
			deallocate PREPARE stmt;
 
			if row_count()<=0 then
				set @sql2 = 
					concat('insert into R20_ROUTE08(state,flag,routecls,pc,prefixcode,prefixlen,oprid,cls,clsOrg,cost,costOrgCurr,costOrg,lastUpd,lastUpdBy,access,priority,quality, UploadBy) 
					values (1,',flag,',0,''',left(pPrefixCode,2),''',''', pPrefixCode,''',',ltrim(CHAR_LENGTH(pPrefixCode)),',', 
					ltrim(id), ',''A'',''A'',0.5,''EUR'',0.5,current_timestamp(),system_user,31,1,1.0, ''Carrier Test'')'); 
				
                if @sql2 is not null then
					PREPARE stmt1 from @sql2;
					execute stmt1;
					deallocate PREPARE stmt1;
                End if;
	 
			end if;
        End if;
  
 	 set pc = left(pPrefixCode,2) ;
 
 	 call r22_routeTimeclsAdd (pRoute, 0, id, 'A', pc);
  
 	 insert r_prefix2(state,pc,prefixcode,prefixlen,destcode,prefixcls) 
 	 values ('I', substring(pPrefixCode,1,2),pPrefixCode,CHAR_LENGTH(pPrefixCode),pDestCode,3); 
 	 
 	 commit; 
  
 	 select 0 as errorCode, 'OK.' as errorString; 
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `rset_del_ctest` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `rset_del_ctest`(
   pRoute        varchar(32),
   pPrefixCode   varchar(16),
   pSrcInt       varchar(16),
   pSrcUnit      varchar(16),  
   pSrcOpr       varchar(16),  
   pSrcDom       varchar(16),  
   pTrgInt       varchar(16),
   pTrgUnit      varchar(16),  
   pTrgOpr       varchar(16),  
   pTrgDom       varchar(16)   
)
begin
   
   START TRANSACTION;
   
   delete from r_prefix2 where prefixcode=pPrefixCode;

   set @dysql = concat('delete ' , pRoute , ' where pc=''' , left(pPrefixCode,2) , ''' and prefixcode=''' , pPrefixCode + '''');

   prepare stmt from @dysql;
   execute stmt;
   deallocate PREPARE stmt;

  
	if pTrgUnit<>'ALL'then
		delete from r_interface 
		where name=pTrgInt and `group`=pTrgOpr and domain=pTrgDom and universe='EU' and (name like 'dac%' or name like 'rtp%');
	end if;

	delete from r_prefix_intest where prefixcode=pPrefixCode;

   commit;

   select 0 errorCode, 'OK.' errorString;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `RTimerule_gettemplate` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `RTimerule_gettemplate`()
begin  
	
	select 0 OPrId;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `rweb_add_ctest_v2` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `rweb_add_ctest_v2`(
   pPrefixCode   varchar(16),
   pDestCode     varchar(32),
   pSrcInt       varchar(16),
   pSrcUnit      varchar(16),  
   pSrcOpr       varchar(16),  
   pSrcDom       varchar(16),  
   pTrgInt       varchar(16),
   pTrgUnit      varchar(16),  
   pTrgOpr       varchar(16),  
   pTrgDom       varchar(16),  
   pSrcUniverse  varchar(16),
   pTrgUniverse  varchar(16)
)
begin
   declare v_route varchar(32);

	if pSrcUniverse is null then
		set pSrcUniverse = 'EU';
	End if;

	if pTrgUniverse is null then
		set pTrgUniverse = 'EU';
	End if;

   call r_routing_getCurTbl (v_route,1);

   call rset_add_ctest_V2 (v_route, pPrefixCode, pDestCode, pSrcInt, pSrcUnit, pSrcOpr, pSrcDom, pTrgInt , pTrgUnit, pTrgOpr, pTrgDom, pSrcUniverse, pTrgUniverse);
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `rweb_ctest_list` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `rweb_ctest_list`()
begin
	
	select x.*, y.id intid,z.opr_name 
	from r_prefix_intest x 
	left outer join r_interface y on (x.tuniverse=y.universe and x.tdomain = y.domain and x.tname=y.name and x.tgroup=y.group)
	left join lcr_operator_dtls z on (z.opr_code =  x.tname)

	union 

	select x.* , -999 intid,z.opr_name  
	from
	r_prefix_intest x 
	left join lcr_operator_dtls z on (z.opr_code =  x.tname)
	where x.tname='ALL';

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `rweb_del_ctest1` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `rweb_del_ctest1`(
   pPrefixCode   varchar(16)
)
begin
	declare v_pSrcInt varchar(16);
	declare v_pSrcUnit varchar(16);
	declare v_pSrcOpr varchar(16);
	declare v_pSrcDom varchar(16);
	declare v_pTrgInt varchar(16);
	declare v_pTrgUnit varchar(16);
	declare v_pTrgOpr varchar(16);
	declare v_pTrgDom varchar(16);
	declare v_strtable varchar(40);

	call r_routing_getCurTbl (v_strtable,1);

	select	a.sname, a.sunit, a.sgroup, a.sdomain, a.tname, a.tunit, a.tgroup, a.tdomain
	into	v_pSrcInt,v_pSrcUnit,v_pSrcOpr,v_pSrcDom,v_pTrgInt,v_pTrgUnit,v_pTrgOpr,v_pTrgDom
	from r_prefix_intest a
	where a.prefixcode=pPrefixCode limit 1;

   call rset_del_ctest (v_strtable, pPrefixCode, v_pSrcInt, v_pSrcUnit, v_pSrcOpr, v_pSrcDom, v_pTrgInt, v_pTrgUnit, v_pTrgOpr, v_pTrgDom);
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r_AllCarrierTest` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `r_AllCarrierTest`()
Begin
	select * from
	(
		select State, prefixcode, destCode, userInfo, tGroup Operator, tDomain Domain, tUniverse 
        from routing_lyca.r_prefix_intest   
        
		Union all
        
		select State, prefixcode, destCode,userInfo, tGroup Operator, tDomain Domain, tUniverse 
        from r_prefix_intest
	) a
	Order by CHAR_LENGTH(prefixcode), Prefixcode;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r_Capability_update` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `r_Capability_update`(
   domain varchar(20),
   operator varchar(50),
   prefixcode varchar(100),
   flagN int,
   timecls varchar(5),
   login varchar(50),
   type int
   )
begin
   	
   	declare tintid int;
   	declare rowcounts int;
   	declare comment varchar(200);
   	declare reserved varchar(100);  
   
   	
   
   	set reserved=concat(operator ,'@',domain);
   
   	if login is null then
   	  set login=user();
   	End if;
   
   	select a.id into tintid from r_interface a where a.reserved=reserved limit 1;
   
   	if type=1 then
   		set @strsql=concat('update R20_ROUTE08 set exceptioncls= exceptioncls |' ,cast(flagN as SIGNED INTEGER), ',lastUpd=current_timestamp(),lastUpdBy=''',login,''',UpdateFlag=0 where routecls=0 and oprid=' , cast(tintid as SIGNED INTEGER) , ' and prefixcode like ''' , prefixcode ,'''');   
   
   		set comment=concat('Modify capability [value set to 1]');
   	else
   		set @strsql=concat('update R20_ROUTE08 set exceptioncls= exceptioncls &' ,cast(~flagN as SIGNED INTEGER), ',lastUpd=current_timestamp(),lastUpdBy=''',login,''',UpdateFlag=0 where routecls=0 and oprid=' , cast(tintid  as SIGNED INTEGER) , ' and prefixcode like ''' , prefixcode ,'''');  
   
   		set comment= concat('Modify capability value [value set to 0]');
   	end if;
    
   	if timecls is not null then
   	  set @strsql=concat(@strsql, ' and cls =''' ,timecls ,'''');
   	End if;
   
   	PREPARE STMT FROM @strsql;
   	EXECUTE STMT ;
   	DEALLOCATE PREPARE STMT;
   
   	set rowcounts=row_count();
   
   	call routinghistory.rh_insert (reserved,prefixcode,  timecls ,flagN  ,10000,login,100,'R20_ROUTE08',comment);
   
   	select rowcounts roweffected,0 ErrorCode, 'OK.' ErrorString, concat('row effected : ',cast(rowcounts as SIGNED INTEGER)) as Note;  
   end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r_ExchangeRate_Upload` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `r_ExchangeRate_Upload`(
UploadFileName varchar(1000),
UploadedBy varchar(40),
Operator varchar(64),
Currency varchar(3),
Price float
)
BEGIN

     DECLARE duplicate int;
     SET duplicate = 0;
     IF EXISTS(SELECT * FROM ExchangeRateQueue a WHERE a.Operator = Operator AND a.Currency = Currency AND a.Price = Price 
				AND DATE_DIFF(a.UploadDate,current_timestamp()) <= 1 limit 1) then

		INSERT INTO ExchangeRateQueueLog ( UploadFileName,Uploaddate,UploadedBy,Operator,Currency,Price)
		VALUES ( UploadFileName,current_timestamp(),UploadedBy,Operator,Currency,Price) ;
         
		SET duplicate = 1;
     ELSE
		INSERT INTO ExchangeRateQueue ( UploadFileName,Uploaddate,UploadedBy,Operator,Currency,Price,Percentage,Status)
		VALUES ( UploadFileName,current_timestamp(),UploadedBy,Operator,Currency,Price,0,1);
     END if;

     IF row_count() <> 0 then
          IF duplicate <> 1 then
	       SELECT 0 as status, 'ExchangeRate Queue created successfully.' as errmsg;
          ELSE
	       SELECT 1 as status,'ExchangeRate Queue created successfully. 
		   Some operators are not loaded as they are recently loaded in less than a day ago.' as errmsg;
          END IF;
     ELSE
	  SELECT -1 as status, 'Failed to create ExchangeRate Queue. ' as errmsg;
     END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r_forbidden_add_new` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `r_forbidden_add_new`(
 login varchar(32),  
 operator varchar(40),  
 prefixcode varchar(40),  
 timecls varchar(100),  
 reason int,  
 status int
 )
sp_return:begin  
 
 	declare intid int;
 	declare opr varchar(100);
 	declare domain varchar(100);
 	declare rset varchar(100);
    
    set rset = 'R20_ROUTE08';
 
 	if reason<=0 or reason>=20 then
 		select -4 `status`,'' diffpermit;
 		leave sp_return;
 	 end if;
 
 	 if status is null then 
 		set status = 0;
 	 End if;
 	
 	select a.id,a.name,a.domain into intid,opr,domain from r_interface a where a.reserved=operator;
 
 	if intid is null then
 		select -1 `status`,'' diffpermit; 
 		leave sp_return;
 	end if;
 
 	if status=1 then
		
 	   call r_routing_updatestatus_new_v2 (-1,status , login ,rset , opr ,domain, timecls, prefixcode ,reason, null, null, '',null, null);    
 	else 
 	   call r22_routeForbid(rset,	operator ,	Timecls ,	Prefixcode, null,Reason,null); 
 	End if;
 
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r_forbidden_view_NEW` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `r_forbidden_view_NEW`(
 operator varchar(40),
 prefixcode varchar(40),
 reason varchar(100)
)
sp_return: begin
 
 	set @strwhere='';
     
 	set @strquery=concat('select a.id,concat(b.name, ''@'', b.domain) operator,a.prefixcode,c.reason reason ,a.lastupdby ''created by'',a.lastupd ''created date'',a.state status,a.cls timecls 
 	from R20_ROUTE08 a  
 	inner join r_interface b on ');
 
 	if (prefixcode is not null) then
 		set @strwhere=concat(@strwhere,' a.pc like ''',left(prefixcode,2),''' and a.prefixcode like ''',prefixcode,''' and ');
 	End if;
 
		set @strquery=concat(@strquery, '  a.state=0 and (a.reason between 1 and 19 ) and  ');
 
 	if (operator is not null) then
		set @strwhere=concat(@strwhere,' b.name like ''' , operator ,''' and ');
 	End if;
 
 	set @strwhere=concat(@strwhere,' b.id=a.oprid  inner join r20_reason c on a.reason=c.reasonid');
 
 	if (char_length(@strwhere)>0 ) then
 		set @strquery=concat(@strquery , ' ' ,@strwhere);
 	end if;
 
 	set @strquery=concat(@strquery,' order by b.name,a.prefixcode limit 1000');
    
 	PREPARE STMT FROM @strquery;
 	EXECUTE STMT;
 	DEALLOCATE PREPARE STMT;

 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r_forbidden_view_NEW2` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `r_forbidden_view_NEW2`(
operator varchar(40),
prefixcode varchar(40),
reason varchar(100)
)
begin

		set @strwhere='';

		set @strquery=concat('select concat(b.name, '''', b.domain) operator,a.prefixcode,c.reason reason ,
		a.cls timecls,a.state status,replace(ifnull(d.destcode,''-''),'','',''.'') destcode,
		DATE_FORMAT(a.lastupd,''%Y-%m-%d %h:%i%s'') lastupd,a.lastupdby  from R20_ROUTE08 a 
		inner join r_interface b on ');


		if (prefixcode is not null) then
			set @strwhere=concat(@strwhere,' a.pc like ''',left(prefixcode,2),'%'' and a.prefixcode like ''',prefixcode,'%'' and ');
		End if;

			set @strquery=concat(@strquery, '  a.state=0 and (a.reason between 1 and 19 ) and  ');

		if (operator is not null) then
			set @strwhere=concat(@strwhere,' b.name like ''%' , operator ,'%'' and ');
		End if;

		set @strwhere=concat(@strwhere,' b.id=a.oprid  inner join r20_reason c  on a.reason=c.reasonid left outer join r_prefix2 d on a.prefixcode=d.prefixcode ' ); 


		if (char_length(@strwhere)>0 ) then
			set @strquery=concat(@strquery , ' ' ,@strwhere);
		end if;

		set @strquery=concat(@strquery,' order by b.name,a.prefixcode');

		PREPARE STMT from @strquery;
		EXECUTE STMT;
		DEALLOCATE PREPARE STMT;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r_GetExchangeRate_UploadDetails` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `r_GetExchangeRate_UploadDetails`()
BEGIN

		SELECT DATE_FORMAT(Uploaddate ,"%d/%m/%y %h:%i:%s") date1,
				UploadedBy,Operator,Price,Currency,rs.comment Status,Percentage
		FROM ExchangeRateQueue ERQ
		INNER JOIN request_status rs ON ERQ.status = rs.status
		Order by Uploaddate desc;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r_getreason` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `r_getreason`()
begin  
select * from r20_reason   order by reasonid;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r_grade_update` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `r_grade_update`(
  domain varchar(20),
  operator varchar(50),
  prefixcode varchar(100),
  grade float ,
  timecls varchar(5),
  login varchar(50)
  )
sp_return:begin
  
  
  	declare tintid int;
  	declare rowcount int;
  	declare reserved varchar(100);  
  
  	set reserved=concat(operator ,'@',domain);
  
  	if login is null then
  	  set login=user();
  	End if;
  
  	select a.id into tintid from r_interface a where a.reserved=reserved limit 1; 
  	
  	
  
  	set @strsql=concat('update R20_ROUTE08 set quality=' ,cast(grade as decimal(10,3))
  				, ',lastUpd=current_timestamp(),lastUpdBy=''',login
  				,''',UpdateFlag=0 where routecls=0 and oprid=' , cast(tintid as SIGNED INTEGER) 
  				, ' and prefixcode like ''%' 
  				, prefixcode ,'%''');   
  
  	if timecls is not null then
  	  set @strsql=CONCAT(@strsql, ' and cls =''' ,timecls ,''''); 
  	End if;

  	prepare stmt from @strsql;
  	execute stmt;
  	deallocate prepare stmt;
  
  	set rowcount=row_count();
  
  	call routinghistory.rh_insert(reserved,prefixcode,  timecls ,grade  ,10000,login,100,'R20_ROUTE08','Modify grade value');
  
  	select rowcount roweffected,0 ErrorCode, 'OK.' ErrorString, CONCAT('row effected : ', cast(rowcount as SIGNED INTEGER))  Note  ;
  
  	end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r_grade_update_v3` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `r_grade_update_v3`(
 	reserved varchar(100),
 	prefixcode varchar(100),
 	isActive int,  
 	reason int,  
 	grade float ,
 	timecls varchar(5),
 	login varchar(50)
 )
begin
 	declare strsql text;
 	declare tbl varchar(100);
 	declare tintid int;
 	declare rowcount int;
 	declare errmsg varchar(100) ;
 	set errmsg='OK.'; 
 	 
 	if login is null then
 	  set login=system_user;
 	end if;
 
 	if timecls is null then
 	  set timecls=null;
 	end if;
 
 	
 	select a.id into tintid from r_interface a where a.reserved=reserved  limit 1; 
 	    
 	if (timecls is not null) then
 	  update R20_ROUTE08 a
 	  set a.quality= CAST(grade as char(20)), 
 		a.lastUpd = current_timestamp(), 
 		a.lastUpdBy= login, 
 		a.state = isActive, 
 		a.reason = reason,
 		a.ext = case when isActive = 0 then 20 else 0 end 
 	  where routecls=0 and oprid= tintid and prefixcode = prefixcode and cls = timecls and ext & 1 = 0 and cost<>99;
 
 	set rowcount = row_count();
 
 		if row_count()<=0  then
 		  set errmsg='FAILED TO MODIFY.';
 		End if;
     End if;
 
 	call routinghistory.rh_insert(reserved,prefixcode,  timecls ,grade  ,10000,login,100,'R20_ROUTE08','Modify grade value');  
 	
 	select rowcount as roweffected,0 as ErrorCode, errmsg as ErrorString, concat('row effected : ',CAST(rowcount as char(10))) as  Note;  
 
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r_grade_view` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `r_grade_view`(
  domain varchar(20),
  operator varchar(50),
  prefixcode varchar(100),
  timecls varchar(5)
  )
spreturn:begin
  
  	declare tbl varchar(100);
  	declare tintid int;
  	declare rowcount int;
  	declare reserved varchar(100);
  
  	set reserved=concat(operator ,'@',domain);
  
  	select a.id into tintid from r_interface a where a.reserved=reserved limit 1;
  
  	if tintid is null then
  		select  reserved operator,prefixcode,cls,quality grade 
  		from R20_ROUTE07 limit 0;
  		leave spreturn;
  	end if;
  
  	set @strsql=concat('select ''',reserved ,''' operator,prefixcode,cls,quality grade from  R20_ROUTE08 where routecls=0 and oprid=' , cast(tintid as SIGNED INTEGER) 
				, ' and prefixcode like ''%', prefixcode , '%'' '); 
			
  	if timecls is not null then
  	  set @strsql=concat(@strsql, ' and cls =''' ,timecls ,''''); 
  	End if;

  	prepare stmt from @strsql;
  	execute stmt;
  	deallocate prepare stmt;
  
  end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r_grade_view_v2` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `r_grade_view_v2`(
  domain varchar(20),  
  operator varchar(50),  
  prefixcode varchar(100),  
  timecls varchar(5),
  grade float  
  )
sp_return:begin  
  
   declare tintid int;  
   declare rowcount int;  
   declare reserved varchar(100); 
    
   if operator <> '-1' then  
    set reserved=concat(operator ,'@',domain);
        
    select a.id into tintid from r_interface a where a.reserved=reserved limit 1;
  
  	if tintid is null then  
  		select reserved operator,prefixcode,cls,quality grade 
  		from R20_ROUTE07 limit 0;  
  		leave sp_return ;
  	end if;
    
    set @strsql= concat('select ''',reserved,''' operator,prefixcode,cls,quality grade from R20_ROUTE08 where routecls=0 and oprid=' , cast(tintid as SIGNED INTEGER) , ' and prefixcode like '''   
       , prefixcode , ''''); 
  	 
  	if grade <> '-1' then
		set @strsql=concat(@strsql,'  and quality =', CAST(grade as char(10)));   
  	end if;  
  
  	if timecls is not null then 
  		set @strsql=concat(@strsql, ' and cls =''' ,timecls ,'''');
	End if;
    
  	else  
  
  		set @sql = concat('(SELECT id oprid,reserved from r_interface  WHERE domain = ''' , domain , ''')');  
    
  		set @strsql = concat('select b.reserved operator ,prefixcode,cls,quality grade from  R20_ROUTE08 a '  
  		, ' INNER JOIN ' , @sql , ' b ON a.oprid = b.oprid '   
  		,' where routecls=0 and prefixcode like ''' , prefixcode , '''');  
    
  	if grade <> '-1' then 
  		set @strsql=concat(@strsql,'  and quality =', cast(grade as char(10)));
  	end if;
  
  	if timecls is not null then 
  		set @strsql=concat(@strsql, ' and cls =''' ,timecls ,'''');  
  	end if;
    
   END IF; 
  
   PREPARE STMT FROM @strsql;
   EXECUTE STMT;
   DEALLOCATE PREPARE STMT;
  
  end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r_intGroup_list` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `r_intGroup_list`()
begin
	select * from r_intgroup order by groupid;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r_rating_add` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `r_rating_add`(
tintid int,
countrycode varchar(32),
type int,
rating int
)
begin

	call r_rating_delete (tintid,countrycode,type);

	insert into r_rating_country(tintid,countrycode,type,rating,date)
	values (tintid,countrycode,type,rating,current_timestamp());

	insert into r_rating(tintid,prefixcode,rating)
	select tintid ,prefixcode,rating 
	from r_prefix1 a  
	inner join r_countrycode_key b  on a.prefixcode like concat(b.prefixkey,'%')
	where b.countrycode=countrycode and prefixcls=type;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r_rating_delete` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `r_rating_delete`(
tintid int,
countrycode varchar(32),
type int
)
begin

	delete a from r_rating_country a where a.tintid=tintid and a.countrycode=countrycode and a.type=type;

	delete a 
	from r_rating a 
	inner join r_countrycode_key b on a.prefixcode like concat(b.prefixkey ,'%')
	inner join r_prefix1 c  on a.prefixcode=c.prefixcode
	where b.countrycode=countrycode and c.prefixcls=type and a.tintid=tintid;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r_rating_list_v2` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `r_rating_list_v2`(
 domain varchar(10),
 operator int,
 prefixcode varchar(32)
 )
begin
 
 	set @strquery=concat('select b.domain,b.name operator, a.prefixcode, a.tintid tintid
 					from r_rating a 
 					inner join r_interface b  on a.tintid=b.id ');
 
 	set @strwhere='';
 
 	if(domain is not null) then
 		set @strwhere=concat(@strwhere , ' b.domain=''', domain,'''  and ');
 	end if;
 	if (operator is not null) then
 		set @strwhere=concat(@strwhere , ' b.id=''', ltrim(rtrim(operator)),'''  and ');
 	end if;
 	if (prefixcode is not null) then
 		set @strwhere=concat(@strwhere , ' a.prefixcode like ''', prefixcode,''' and ');
 	end if;
 
 
 	if (char_length(@strwhere)>0)then
 		set @strwhere=left(@strwhere,char_length(@strwhere)-4);
 
 		set @strquery=concat(@strquery,' where ',@strwhere);
 	  end if;
 
 	  PREPARE STMT FROM @strquery;
 	  EXECUTE STMT;
 	  DEALLOCATE PREPARE STMT;
 
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r_routing_blockview_new` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `r_routing_blockview_new`(
prefixcode varchar(40) 
)
begin


	declare tablename varchar(100);

        
	

	set @strwhere='';

	set @strquery= concat('select b.`name`, '''', b.domain operator,a.prefixcode,c.reason reason ,a.cls timecls, 
					case when ext & 1 = 1 and a.state = 0 then ''Art. Block'' when a.state = 0 then ''Blocked'' else cast(a.state as char(1)) end status,
					replace(ifnull(d.destcode,''-''),'','',''.'') destcode,convert(varchar(20),a.lastupd,120) lastupd,a.lastupdby, 
					a.UploadBy, Convert(varchar(20),a.UploadDate,10) UploadDate, a.ext from r20_route08 a  inner join r_interface b on ');
	
	if (prefixcode is not null) then
		set @strwhere=concat(@strwhere,' a.pc like ''',left(prefixcode,2),''' and a.prefixcode like ''',prefixcode,''' and ');
	End if;
	
	set @strquery=concat(@strquery, '  a.state=0 and (a.reason <1 or a.reason>19 ) and  ');
	
	set @strwhere=concat(@strwhere,' b.name like ''%'' and ');

	set @strwhere=concat(@strwhere,' b.id=a.oprid and b.state=''I'' inner join r20_reason c on a.reason=c.reasonid 
	left outer join r_prefix2 d on d.prefixcode=a.prefixcode');

	if (CHAR_LENGTH(@strwhere)>0 ) then
		set @strquery=concat(@strquery , ' ' ,@strwhere);
	end if;

	set @strquery=concat(@strquery,' order by b.name,a.prefixcode'); 

	PREPARE STMT FROM @strquery;
	EXECUTE STMT;
	DEALLOCATE PREPARE STMT;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r_routing_getCurTbl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `r_routing_getCurTbl`(
  out tblname varchar(32) 
  	,type int
  )
begin 
  	if type=0 then
  	 select a.`set` into tblname from route_config where clsid=0 and  curroute=1;  
  	else 
  	 set tblname='R20_ROUTE08' ;
       end if;
  end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r_routing_updatestatus3_new` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `r_routing_updatestatus3_new`(
 login varchar(32),
 operator varchar(40),
 prefixcode varchar(40),
 timecls varchar(100),
 reason int,
 status int
 )
sp_return:begin
 
 	declare intid int;  
 	declare opr varchar(100);
 	declare rset varchar(100);  
 	declare domain varchar(100);  
 
 	if status is null then
 		set status = 0;
 	End if;
 
 	select a.id,a.name,a.domain into intid,opr,domain from r_interface a where a.reserved=operator limit 1;
 
 	call r_routing_getCurTbl(rset,1);  
 
 	if status=1 then
 		set reason=0;
 	end if;
 	
 	if intid is null then
 		select -1 status,'' diffpermit ,-1 errorCode, 'Operator not found' errorString, 'Operator not found' note;   
 		leave sp_return;  
 	end if; 
 	
 	call r_routing_updatestatus_new_v2 (-1,status , login ,rset , opr ,domain, timecls, prefixcode ,reason,null,null,'',null,null);
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r_routing_updatestatus_new_v2` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `r_routing_updatestatus_new_v2`(
 id int,
 status int,
 login varchar(32),  
 rset varchar(100),  
 interface varchar(100),  
 domain varchar(100),  
 cls varchar(20),  
 prefixcode varchar(200) ,  
 reason int,
 exception int,
 lockstatus int,
 lockpfx varchar(40),
 grade float,
 dtmf int
 )
sp_return:begin
 
 	declare cost float;
 	declare costorgcurr varchar(10)  ;
 	declare costorg float ; 
 	declare datbl varchar(100);
 	declare tintid int;
 	declare reserved varchar(100);
 	declare thedate datetime; 
 	declare destcode varchar(100);  
 	declare access int;  
 	declare flagN int;
 	declare type int;
 
 	if reason is null then set reason = 0; end if; 
 	if lockpfx is null then set lockpfx=''; end if;  
 
 	set prefixcode=replace(prefixcode,'%','');
 
 	if dtmf is not null then
 		
 		set flagN=1;
 
 		if dtmf=1 then
 			set type=1;
 		else
 			set type=0;
 		end if;
 
 		call r_Capability_update(domain, interface, prefixcode, flagN, cls, login, type);
 
 		leave sp_return;  
 
 	end if;
   
 	if grade is not null then
 	   call r_grade_update (domain, interface, prefixcode, grade, cls, login);
 	   leave sp_return;  
 	end if;
   
 	set access=31;   
 	set thedate=current_timestamp();
 
 	set reserved=concat(interface , '@' ,domain); 
 	
 	select a.id into tintid from r_interface a where a.reserved=reserved limit 1;
 
 	if exception is not null then
 	  if exception=0 then
 		call r22_routeUnExcept ('R20_ROUTE08', reserved,cls,prefixcode,login);
 	  else  
 		call r22_routeExcept ('R20_ROUTE08', reserved,cls,prefixcode,exception,login);
 		leave sp_return;  
 	  end if;
 	end if;
 
 	select a.destcode into destcode from r_prefix2 a where a.prefixcode=prefixcode limit 1;
 
 	if status=0 then 
 		set reason=ifnull(reason,0);
 
 		if (reason>=0 and reason<=19) then
 			select -1 errorCode, 'Invalid Reason.' errorString,'Grade value updated.' note;
 			leave sp_return;
 		end if;
 
 		call r22_routeBlock ('R20_ROUTE08',reserved,cls,prefixcode,reason,login); 
 	
 	else  
 		call r22_routeUnBlock ('R20_ROUTE08',reserved,cls,prefixcode,reason,login);  
 	end if; 
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r_routing_updatestatus_new_v3` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `r_routing_updatestatus_new_v3`(
 id int,
 status int,
 login varchar(32),  
 rset varchar(100),  
 interface varchar(100),  
 domain varchar(100),  
 cls varchar(20),  
 prefixcode varchar(200) ,  
 reason int,
 exception int,
 lockstatus int,
 lockpfx varchar(40),
 grade float,
 dtmf int
 )
sp_return:begin
 
 	declare cost float;
 	declare costorgcurr varchar(10)  ;
 	declare costorg float ; 
 	declare datbl varchar(100);
 	declare tintid int;
 	declare reserved varchar(100);
 	declare thedate datetime; 
 	declare destcode varchar(100);  
 	declare access int;  
 	declare flagN int;
 	declare type int;
 
 	if reason is null then set reason = 0; end if; 
 	if lockpfx is null then set lockpfx=''; end if;  
 
 	set prefixcode=replace(prefixcode,'%','');
 
 	if dtmf is not null then
 		
 		set flagN=1;
 
 		if dtmf=1 then
 			set type=1;
 		else
 			set type=0;
 		end if;
 
 		call r_Capability_update(domain, interface, prefixcode, flagN, cls, login, type);
 
 		leave sp_return;  
 
 	end if;
   
 	if grade is not null then
 	   call r_grade_update (domain, interface, prefixcode, grade, cls, login);
 	   leave sp_return;  
 	end if;
   
 	set access=31;   
 	set thedate=current_timestamp();
 
 	set reserved=concat(interface , '' ,domain); 
 	
 	select a.id into tintid from r_interface a where a.reserved=reserved limit 1;
 
 	if exception is not null then
 	  if exception=0 then
 		call r25_routeUnExcept ('r20_route08', reserved,cls,prefixcode,login);
 	  else  
 		call r25_routeUnExcept ('r20_route08', reserved,cls,prefixcode,exception,login);
 		leave sp_return;  
 	  end if;
 	end if;
 
 	select a.destcode into destcode from r_prefix2 a where a.prefixcode=prefixcode limit 1;
 
 	if status=0 then 
 		set reason=ifnull(reason,0);
 
 		if (reason>=0 and reason<=19) then
 			select -1 errorCode, 'Invalid Reason.' errorString,'Grade value updated.' note;
 			leave sp_return;
 		end if;
 
 		call r22_routeBlock ('r20_route08',reserved,cls,prefixcode,reason,login); 
 	
 	else  
 		call r22_routeUnBlock ('r20_route08',reserved,cls,prefixcode,reason,login);  
 	end if; 
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r_sites_view` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `r_sites_view`()
begin
select * from sites where status=1 order by domain;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r_usergroup_checkaccess` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `r_usergroup_checkaccess`(
groupid int,
menuid int
)
begin
	if exists(select * from r_groupmenu where  a.groupid=groupid and a.menuid=menuid limit 1) then
	  select 0 status; 
	else
	  select -1 status;
	end if;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r_XLATNbChg_add` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `r_XLATNbChg_add`(
 	login varchar(32),
 	sitecode varchar(40),
 	prefixcode varchar(14),
 	xlatprefix varchar(15),
 	comment varchar(150)
 )
begin
 
 	declare tempxlatprefix varchar(15);
 
 	select xlatpfx into tempxlatprefix
 	from espprm.xlatnbchanges a
 	where a.sitecode=sitecode and a.prefix=prefixcode limit 1;
 
 	if tempxlatprefix is not null then
 		call r_xlatnbchg_remove (login,sitecode,prefixcode);
 	end if;
 
 	insert into espprm.xlatnbchanges (sitecode,prefix,xlatpfx,comment)
 	values (sitecode,prefixcode,xlatprefix,comment);
 
 	if row_count()>0 then
 		call routinghistory.r_XLATNbChglog (sitecode,prefixcode,xlatprefix,login,1,1);
 		select 0 status;
 	else
 		select -1 status;
 	end if;
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r_XLATNbChg_remove` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `r_XLATNbChg_remove`(
 login varchar(32),
 sitecode varchar(10),
 prefixcode varchar(16)
 )
begin
 	declare xlatpfx varchar(40);
 	declare comment varchar(100);
 
 	select a.xlatpfx,a.comment
 	into xlatpfx,comment
 	from espprm.xlatnbchanges a
 	where a.sitecode=sitecode and a.prefix=prefixcode limit 1;
 
 	delete a from espprm.xlatnbchanges a where a.sitecode=sitecode and a.prefix=prefixcode;
 
 	if row_count()>0 then
 	   call routinghistory.r_XLATNbChglog (sitecode,prefixcode,xlatpfx,login,0,1);
       select 0 as errcode, 'Removed' as errmsg;
 	end if;
    
    
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r_XLATNbChg_view` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `r_XLATNbChg_view`(
 sitecode varchar(40),
 prefixcode varchar(40),
 xlatpfx varchar(40),
 comment varchar(100)
 )
begin  
 
 	set @strwhere='' ;
 
 	set @strquery = concat('select a.sitecode ''SiteCode'',a.prefix ''PrefixCode'',a.xlatpfx ,a.comment ''Comment'' from espprm.xlatnbchanges a ');  
 
 	if sitecode is not null then   
 	  set @strwhere = concat(@strwhere,' a.sitecode like ''' , sitecode , ''' and ');  
 	End if;
 
 	if prefixcode is not null then
 	  set @strwhere = concat(@strwhere,' a.prefix like ''' , prefixcode ,''' and ');  
 	End if;
 
 	if xlatpfx is not null then  
 	  set @strwhere = concat(@strwhere,' a.xlatpfx like ''' , xlatpfx ,''' and ');  
 	End if;
 
 	if comment is not null then  
 	  set @strwhere = concat(@strwhere,' a.comment like ''' , comment ,''' and '); 
 	End if;
 
 	if char_length(@strwhere)>0  then  
 		set @strwhere=left(@strwhere,char_length(@strwhere)-4);  
 		set @strquery=concat(@strquery , ' where ' ,@strwhere);
 	end if;
 
 	set @strquery=concat(@strquery,' order by a.sitecode,a.prefix;');  
    
		PREPARE STMT from @strquery;
		EXECUTE STMT ;
		DEALLOCATE PREPARE STMT;
 
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sl_Blocked_OperatorLog` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sl_Blocked_OperatorLog`()
Begin
    
		Declare theDate datetime;
		Declare login varchar(25);
		Declare OprName VArchar(50);
		Declare OprId int;

		drop table if exists tttempcursor;
		create  table tttempcursor
		(
			id int auto_increment primary key,
			name varchar(32), 
			domain varchar(8), 
			state char(1), 
			thedate datetime, 
			Agent varchar(50)
		);


		insert into tttempcursor(id, name, domain, state, thedate, Agent)
		select id, name, domain, state, getdate(), Space(25) 
		from RoutingV3.r_interface where state <> 'I';
        
        call sl_Blocked_OperatorLog_cursorcallSP();
        
        drop table if exists tttempcursor;
        
	 
	End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sl_Blocked_OperatorLog_cursorcallSP` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sl_Blocked_OperatorLog_cursorcallSP`()
Begin

		DECLARE done INT DEFAULT FALSE;
        Declare theDate datetime;
		Declare login varchar(25);
		Declare OprName VArchar(50);
		Declare OprId int;

		DECLARE opr CURSOR
		FOR 
		SELECT id, concat(name , '' , domain) OprName FROM tttempcursor;
        
         
		DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
	
		OPEN opr;
		    
           
		read_loop: LOOP
			FETCH NEXT FROM opr into OprId, OprName;
			IF done THEN
				LEAVE read_loop;
			END IF;
        
				select a.thedate, a.login into thedate, login  
				from routinghistory.routingtransaction a
				where prefixcode = 'Modify Operator' and isactive = 0 and Operator = OprName
				Order by thedate desc limit 1;
		
				Update tttempcursor a set a.theDate = thedate, a.Agent = login where a.id = oprId; 
			
				FETCH NEXT FROM opr into OprId, OprName;

        END LOOP;
	
		Close opr;
		select id,name,domain,state,cast(thedate as date) UpdateDate,Agent
		from tttempcursor Order by theDate;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `um1_user_checkPassword_v2` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `um1_user_checkPassword_v2`(
  pNamespace varchar(16), 
  pName varchar(32), 
  pPassword varchar(64), 
  pRemoteAddress varchar(64)
)
sp_return:begin 
  
 	declare v_groupid int; 
 	declare v_menucount int ;
 	declare v_accessString varchar(500);
 	declare v_ns varchar(16); 
 	declare v_secType int;
 	declare v_sec varchar(255); 
 	declare v_errcode int; 
 	declare v_errstring varchar(255); 
 	declare v_ePassword varchar(255);
 	
 	select groupid into v_groupid from r_userlogin where login=pName limit 1; 
 
 
 
 
 	if v_groupid is null then
 	  set v_groupid=4; 
 	end if;
 
 	set v_menucount = (select count(*) from r_menu); 
 	set v_accessString = space(v_menucount); 
 	set v_accessString = replace(v_accessString,' ','0'); 
 	
 	select INSERT(v_accessString,menuid,1,'1') into v_accessString 
 	from r_groupmenu 
 	where groupid=v_groupid limit 1;
  
 	select a.ns, a.secType,a.sec into v_ns, v_secType,v_sec
 	from Objects a
 	where (pNamespace is null or ns=pNamespace) 
 	and cls='user' 
 	and name=pName limit 1;
 
 
 	if v_secType is null then
 	 call log_add (pName, 'Object not found.', pRemoteAddress) ;
 	 select v_ns as namespace, 1 errorCode, 'Object not found.' as errorString; 
 	 leave sp_return; 
 	 end if;
  
 	if v_secType=0 then
 		 if v_sec=pPassword then
 			 call log_add (pName, 'Success.', pRemoteAddress); 
 			 select v_ns namespace, 0 errorCode, 'Success.' errorString, v_accessString AccessString, v_groupid GroupId; 
 		 else 
 			 call log_add (pName, 'Password not match.', pRemoteAddress); 
 			 select v_ns namespace, 1 errorCode, 'Password not match.' errorString, '' AccessString, 0 GroupId;		
 		end if;
 	elseif v_secType=1 then
 		 set v_errcode = 0; 
 
 		 call sp_encrypt (pPassword, v_ePassword, v_errcode, v_errstring); 
 
 		 if v_errcode<>0 then
 			 call log_add (pName, 'Error encryption component.', pRemoteAddress); 
 			 select v_ns namespace, 1 errorCode, 'Error encryption component.' errorString  , ' ' AccessString, 0 GroupId; 
 		 elseif v_ePassword=v_sec then
 			 call log_add (pName, 'Success.', pRemoteAddress); 
 			 select v_ns namespace, 0 errorCode, 'Success.' errorString, v_accessString AccessString, v_groupid GroupId; 
 		 else 
 			 call log_add (pName, 'Password not match.', pRemoteAddress); 
 			 select v_ns namespace, 1 errorCode, 'Password not match.' errorString , '' AccessString, 0 GroupId; 
 		 end if;
 	else 
 		 call log_add (pName, 'Unknown Security Type.', pRemoteAddress); 
 		 select v_ns namespace, 1 errorCode, 'Unknown Security Type.' errorString, '' AccessString, 0 GroupId; 
 	end if;
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `upload_lcr_rates_test` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `upload_lcr_rates_test`()
Begin

		declare operatorName varchar(20);
		declare timeClass char(1);
		declare effFrom date;
		declare requestType int;
		declare currency char(3);
		declare isNotToRoute char(1);
		declare prefix varchar(16);
		declare LCR_price float;
		declare destination varchar(150);
        
        /********** LCR RATES - MASTER TABLE - tb_upload_lcr_rates_dtl **********/
        
        select * from tb_upload_lcr_rates_dtl;
	

	-- TABLE 1 :
	select * from r_interface where id = 4094 limit 100;

	-- TABLE 2 : 
	select * from routingv3.r_OperatorPrefix where PrefixCode = '2368776' limit 100;

	-- TABLE 3 :
	select * from r20_routeCPrice where oprid = 4094 and cls = 'A' and pc = left('2368776',2) and prefixcode = '2368776';

	-- TABLE 4 :
	select * from routingv3.R20_ROUTE08 x where cls = 'A' and prefixcode = '2368776' and OprId = 4094;

End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `web_get_rate_history_per_oper` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `web_get_rate_history_per_oper`(
dfrom varchar(10),
dto varchar(10),
opr varchar(64)
)
begin


	drop temporary table if exists temp_interface;
	create temporary table temp_interface
	(
	id int auto_increment primary key,
	reserved varchar(64)
	);

	insert into temp_interface(id,reserved)
	select `id`, reserved 
	from r_interface 
	where reserved like opr;
	
	select	a.`id`
			, a.OprId
			, a.newcostorgcurr `New Curr`
			, round(a.newcostorg, 4) `New Rate`
			, b.reserved `Opr Name`
			, totalupdated `Number Updated`
			, username `Updated By`
			, DATE_FORMAT(logdate, "%Y-%m-%d %h:%i:%s") as `Date`
	from routinghistory.update_currency_exchange_log_per_oper a 
	join temp_interface b
	on a.oprid = b.`id`
	where logdate between dfrom and  DATE_ADD(dto, INTERVAL 1 DAY)
	order by logdate desc;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `_RINTERFACE1_upd_v3` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `_RINTERFACE1_upd_v3`(
     pID int,  
     pState varchar(1),  
     name varchar(32),  
     `group` varchar(16),  
     domain varchar(8),    
     pdomain varchar(8),    
     Comment varchar(3000),  
     login varchar(32),    
     OUT pErrCode int ,  
     OUT pErrStr varchar(64),
     type int 
  )
sp_return:begin 
  
     declare oprstat int;
     declare strcomment varchar(150);
     declare stroperator varchar(42);
     declare curdate datetime;
  
     if type is null then
  	set type = 1;
     End if;
  
  	if not exists(select 1 from r_interface where id=pID limit 1)then
  		set pErrCode = -1  ;
  		set pErrStr = 'Interface not found.' ; 
  		leave sp_return;  
  	end if;
  
  	set pErrCode = 0;
  
	 update r_interface a 
	 set 	a.state=pState,
			a.domain=domain,
			a.pdomain=pdomain,
			a.name=name,
			reserved=concat(name,'@',domain),
			a.group=`group`,
			a.type=type, 
			a.UpdateFlag = 0
	 where id=pID;
       
     Update r_interface_Addinfo a set a.LastUpdate = CURRENT_TIMESTAMP(), a.LastUpdateBy = login, a.Comment = Comment 
     where a.oprId = pID;  
    
  	if pstate='I' then 
  		set oprstat=1 ; 
  	else  
  		set oprstat=0;  
  		set stroperator=concat(name,'@',domain); 
  		set strcomment= concat('[',domain,'-',pdomain,'][',`group`,']');  
  		set curdate=CURRENT_TIMESTAMP();  
  	end if;
  
     call routinghistory.r_operator_insert (stroperator,'Modify Operator','-',0,0,curdate,login,oprstat,strcomment);
  
     set pErrCode=0, pErrStr='OK.';  
  end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `_RINTERFACE2_upd` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `_RINTERFACE2_upd`(
    pID int,
    pUnit varchar(32),
    pHint varchar(128),
    OUT pErrCode int,
    OUT pErrStr varchar(64)
 )
sp_return:begin
 
    if not exists(select x.* 
 		from r_interface x, r_prefix_intest y
 		where x.id=pID and x.universe=y.tuniverse and x.domain=y.tdomain and x.name=y.tname limit 1 
    ) then
 		  set pErrCode = -1;
 		  set pErrStr = 'Interface not found or not set as CarrierTest.';
 		  leave sp_return;
       end if;
 
    set pErrCode = 0;
 
    START TRANSACTION;
    
 	   update r_interface a
 	   set a.userinfo=pUnit, a.hint=pHint
 	   where id=pID;
 
 	   update r_prefix_intest a
 	   join r_interface b on b.id=pID
        set a.tunit=pUnit
 	   where b.universe=a.tuniverse and b.domain=a.tdomain and b.name=a.tname ;
 
    COMMIT;
 
    set pErrCode=0, pErrStr='OK.';
 
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `_RPREFIX_del` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `_RPREFIX_del`(
      pPrefixCode varchar(32),
     OUT  pErrCode int ,
     OUT  pErrStr varchar(128) 
  )
sp_return:begin
  
  	declare  route varchar(64);
  
     if not exists (select 1 from r_prefix2 where prefixcode= pPrefixCode limit 1) then 
        select  pErrCode=-1,  pErrStr='PrefixCode not found.';
        leave sp_return;
     end if;
  
     START transaction;
     
     SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
     delete from r_prefix2 where prefixcode= pPrefixCode limit 1;
	SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
  
     
 	
     
     SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
     set  @sql = concat('delete from R20_ROUTE08 where routeCls=0 and pc=',left( pPrefixCode,2),' and prefixcode=''' ,  pPrefixCode , '''  ;');
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
      
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
     PREPARE STMT FROM  @sql;
     EXECUTE STMT;
     DEALLOCATE PREPARE STMT; 
     SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
  
     commit;
  
     set  pErrCode=0,  pErrStr='OK.';
  end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `_RPREFIX_upd` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `_RPREFIX_upd`(
    pPrefixCode   varchar(32),
    pDestCode     varchar(32),
    pState        varchar(1),
    OUT pErrCode      int,
    OUT pErrStr       varchar(128)
 )
sp_return:begin
 
    if not exists (select 1 from r_prefix2 where prefixcode=pPrefixCode limit 1)then
       select pErrCode=-1, pErrStr='PrefixCode not found.';
       leave sp_return;
     end if;
 
    update r_prefix2
    set destcode=pDestCode, state=pState
    where prefixcode = pPrefixCode;
    
    set pErrCode=0, pErrStr='OK.';
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `_RSET_addInterface_v2` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `_RSET_addInterface_v2`(
   pRouteSet varchar(32),  
   pName varchar(32),  
   pDomain varchar(32),  
   pGroup varchar(32) ,  
   pUniverse varchar(32),  
   defRuleID int,
   OUT pErrCode int, 
   OUT pErrStr varchar(128),
   pUser varchar(32)
)
sp_return:begin  
	declare v_id int;  
	declare v_timezone int;  
	declare v_type int;
	declare v_sql text; 

	DECLARE EXIT HANDLER FOR SQLEXCEPTION
	BEGIN
		select -1 as ErrorCode, 'Fail add record to Interface.' as ErrorString;   
		ROLLBACK;   
	END;

	if pUniverse is null then
		set pUniverse= 'EU';
	End if;

		
		if LEFT(pname,1) REGEXP '0-9+$' = 1 or pdomain in('LIP','NIP') then  
			set v_type=2;
		else
			set v_type=1;
		end if;   
  
   if pGroup is null then
	set pGroup = pName;
	set v_id = null;
   end if;

   select id into v_id from r_interface where domain=pDomain and name=pName  limit 1 ;

   if v_id is not null then 
      select -1 as pErrCode, 'Interface is already exists.' as pErrStr; 
      leave sp_return;  
      end if;

   
   
   set v_timezone=0; 
   if v_timezone is null then 
      select -1 as pErrCode, 'Unknown domain.' as pErrStr; 
      leave sp_return;
	end if;

   
  
   START transaction;
   
   insert into r_interface (state,universe,domain,name,`group`,hint,routecls,allowloop,pdomain,reserved,prefixcls,type)
   values ('I',pUniverse,pDomain,pName,pGroup,'',0,1,pDomain,concat(pName,'',pDomain),v_timezone,v_type) ;
   
   select id into v_id from r_interface where domain=pDomain and name=pName  limit 1;
   
   if v_id is null then
      
      select -1 as ErrorCode, 'Fail add record to Interface.' as ErrorString;
      rollback ; 
      leave sp_return;
	end if;

   insert into r_interface_Addinfo (oprId,lastUpdate,LastUpdateBy,Comment)
   select v_id,getdate(),pUser,'';

   insert into  r_interfaceGroup (tintid,intgroupid,flag)  
   select v_id,groupid,1 from r_intgroup ; 
  
   insert into r_timecls(state,tintid,cls,dc,tc,sc)   
   select 'I',v_id,cls,dc,tc,sc  from  r_timecls where tintid=defruleID ; 
    
   
   insert into r_timerule_pattern(oprid,templateid) values (v_id,defRuleID);  
  
   commit;
  

select pErrCode=0, pErrStr='OK.' ; 
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-21  9:53:03
