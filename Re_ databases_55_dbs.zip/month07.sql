-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: month07
-- ------------------------------------------------------
-- Server version	8.0.44-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `month07`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `month07` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `month07`;

--
-- Table structure for table `sme_cdr`
--

DROP TABLE IF EXISTS `sme_cdr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sme_cdr` (
  `calldate` datetime(3) DEFAULT NULL,
  `cnxdate` datetime(3) DEFAULT NULL,
  `telcocode` char(4) DEFAULT NULL,
  `custcode` char(8) DEFAULT NULL,
  `sitecode` varchar(3) NOT NULL,
  `switchcode` varchar(3) NOT NULL,
  `did` varchar(32) DEFAULT NULL,
  `ani` char(30) DEFAULT NULL,
  `dialednum` char(30) DEFAULT NULL,
  `destcode` varchar(64) DEFAULT NULL,
  `langcode` varchar(8) DEFAULT NULL,
  `pincode` char(12) DEFAULT NULL,
  `trffclass` char(4) DEFAULT NULL,
  `trunkin` varchar(32) DEFAULT NULL,
  `trunkout` varchar(32) DEFAULT NULL,
  `provider` varchar(128) DEFAULT NULL,
  `balance` float DEFAULT NULL,
  `talktime` int DEFAULT NULL,
  `batchcode` int DEFAULT NULL,
  `serialcode` int DEFAULT NULL,
  `billmode` int NOT NULL,
  `charge` int DEFAULT NULL,
  `timeperiod` int DEFAULT NULL,
  `talkcharge` float DEFAULT NULL,
  `provcost` float DEFAULT NULL,
  `cnxdelay` int DEFAULT NULL,
  `cnxunit` float DEFAULT NULL,
  `sampdelay` int DEFAULT NULL,
  `sampunit` float DEFAULT NULL,
  `totalcons` double DEFAULT NULL,
  `balance1` double DEFAULT NULL,
  `acctype` int DEFAULT NULL,
  `maxaccess` int DEFAULT NULL,
  `firstusg` datetime(3) DEFAULT NULL,
  `daysvalid` int DEFAULT NULL,
  `expdate` datetime(3) DEFAULT NULL,
  `freesec` int DEFAULT NULL,
  `premiumdest` int DEFAULT NULL,
  `freecnxdelay` int DEFAULT NULL,
  `cnxcharge` int DEFAULT NULL,
  `firstcnx` int DEFAULT NULL,
  `newdelay` int DEFAULT NULL,
  `legAdev` varchar(20) DEFAULT NULL,
  `legBdev` varchar(20) DEFAULT NULL,
  `rtt` int DEFAULT NULL,
  `taskid` int DEFAULT NULL,
  `sessionid_a` varchar(45) DEFAULT NULL,
  `sessionid_b` varchar(45) DEFAULT NULL,
  `act_id` varchar(12) DEFAULT NULL,
  `netration` float DEFAULT NULL,
  `freebalance` float DEFAULT NULL,
  `wdaychange` float DEFAULT NULL,
  `freecnxfact` float DEFAULT NULL,
  `cnxunitfact` float DEFAULT NULL,
  `accesstype` char(1) DEFAULT NULL,
  `yyyy` int DEFAULT NULL,
  `mm` int DEFAULT NULL,
  `dd` int DEFAULT NULL,
  `hh` int DEFAULT NULL,
  `mn` int DEFAULT NULL,
  `currcode` varchar(3) DEFAULT NULL,
  `fffflag` int DEFAULT NULL,
  `clicategory` int DEFAULT NULL,
  `dummy1` int DEFAULT NULL,
  `enterprieid` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`),
  KEY `idx1_sme_cdr` (`calldate`,`charge`),
  KEY `idx2_sme_cdr` (`calldate`,`charge`,`enterprieid`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping events for database 'month07'
--

--
-- Dumping routines for database 'month07'
--
/*!50003 DROP PROCEDURE IF EXISTS `ur_myaccount_call_History_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbteam`@`%` PROCEDURE `ur_myaccount_call_History_info`(
enterpriseid VARCHAR(50),  
date_from DATETIME(3),  
data_to DATETIME(3))
BEGIN
insert into om.tt_temp_cdr_info(calldate,ani,dialednum,destcode,duration ,callcost ,trffclass ,Usage_From ,id )
   select calldate,ani,replace(Replace(dialednum,'UKMCOM',''),'UK01-O-MCOM','') AS dialednum,destcode,talktime,talkcharge,trffclass,
		  case when custcode like 'R%' THEN 'Master' else 'Bundle' end as Usage_From,sessionid_a as session_id 
    from  sme_cdr a 
   where  SUBSTR(did,3,4) = enterpriseid 
     AND  charge = 78 
     and  calldate between  date_from and data_to
ORDER BY  calldate asc;
  
  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ur_myaccount_call_month_bcp_History_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbteam`@`%` PROCEDURE `ur_myaccount_call_month_bcp_History_info`(
enterpriseid VARCHAR(50),  
date_from DATETIME(3),  
data_to DATETIME(3))
BEGIN
     insert into om.tt_temp_cdr_info(calldate,ani,dialednum,destcode,duration ,callcost ,trffclass ,Usage_From ,id )
		select calldate,ani,Replace(dialednum,'UKMCOM','') AS dialednum,destcode,talktime,talkcharge,trffclass,
			   case when custcode like 'R%' THEN 'Master' else 'Bundle' end as Usage_From,sessionid_a as session_id 
		from   sme_cdr a 
		where  SUBSTR(did,3,4) = enterpriseid 
          AND  charge = 78 
          and  calldate between date_from and data_to
	ORDER BY   calldate asc;  
  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-21  9:51:29
