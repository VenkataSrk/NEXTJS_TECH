-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: mysql_mongo
-- ------------------------------------------------------
-- Server version	8.0.44-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `mysql_mongo`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `mysql_mongo` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `mysql_mongo`;

--
-- Table structure for table `Aorecord_master_details`
--

DROP TABLE IF EXISTS `Aorecord_master_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Aorecord_master_details` (
  `id` int NOT NULL AUTO_INCREMENT,
  `key` text,
  `Call_id` text,
  `Contact_address` text,
  `Ipaddress` text,
  `proxy_username` varchar(30) DEFAULT NULL,
  `transport_type` varchar(30) DEFAULT NULL,
  `device_type` varchar(50) DEFAULT NULL,
  `Registered_time` text,
  `session_state` varchar(30) DEFAULT NULL,
  `createdate` datetime DEFAULT NULL,
  `modifydate` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=107 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Aorecord_master_details_log`
--

DROP TABLE IF EXISTS `Aorecord_master_details_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Aorecord_master_details_log` (
  `log_id` int NOT NULL AUTO_INCREMENT,
  `key` text,
  `Call_id` text,
  `Contact_address` text,
  `Ipaddress` text,
  `proxy_username` varchar(30) DEFAULT NULL,
  `transport_type` varchar(30) DEFAULT NULL,
  `device_type` varchar(50) DEFAULT NULL,
  `Registered_time` text,
  `session_state` varchar(30) DEFAULT NULL,
  `createdate` datetime DEFAULT NULL,
  PRIMARY KEY (`log_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2191 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `TPI_client_details`
--

DROP TABLE IF EXISTS `TPI_client_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TPI_client_details` (
  `TPC_id` int NOT NULL AUTO_INCREMENT,
  `clientId` varchar(255) DEFAULT NULL,
  `appName` varchar(255) DEFAULT NULL,
  `createdOn` datetime DEFAULT NULL,
  PRIMARY KEY (`TPC_id`),
  UNIQUE KEY `clientId` (`clientId`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `TPI_slack_install_user_details`
--

DROP TABLE IF EXISTS `TPI_slack_install_user_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TPI_slack_install_user_details` (
  `TPS_id` int NOT NULL AUTO_INCREMENT,
  `slackID` varchar(255) DEFAULT NULL,
  `bot` longtext,
  `enterprise` longtext,
  `isEnterpriseInstall` longtext,
  `team` longtext,
  `user` longtext,
  `worktualLoggedToken` longtext,
  `createdAt` datetime DEFAULT NULL,
  PRIMARY KEY (`TPS_id`),
  UNIQUE KEY `slackID` (`slackID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Worktual_Meeting_Template`
--

DROP TABLE IF EXISTS `Worktual_Meeting_Template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Worktual_Meeting_Template` (
  `template_id` varchar(500) NOT NULL,
  `title` varchar(500) DEFAULT NULL,
  `sip_id` varchar(500) DEFAULT NULL,
  `meeting_id` varchar(500) DEFAULT NULL,
  `description` varchar(500) DEFAULT NULL,
  `start_timestamp` bigint DEFAULT NULL,
  `end_timestamp` bigint DEFAULT NULL,
  `duration_minutes` bigint DEFAULT NULL,
  `timezone` varchar(500) DEFAULT NULL,
  `joining_option_type` varchar(500) DEFAULT NULL,
  `calender_type` varchar(500) DEFAULT NULL,
  `rrule` varchar(500) DEFAULT NULL,
  `is_host_myvideo` tinyint(1) DEFAULT NULL,
  `is_record_meeting` tinyint(1) DEFAULT NULL,
  `is_alternate_host` tinyint(1) DEFAULT NULL,
  `is_participant_video` tinyint(1) DEFAULT NULL,
  `is_participant_join_bef_host` tinyint(1) DEFAULT NULL,
  `is_participant_invite_guest` tinyint(1) DEFAULT NULL,
  `is_participant_waiting_room` tinyint(1) DEFAULT NULL,
  `is_participant_mute_entry` tinyint(1) DEFAULT NULL,
  `is_use_personal_meeting_id` tinyint(1) DEFAULT NULL,
  `is_without_host_continue` tinyint(1) DEFAULT NULL,
  `isRecurr` tinyint(1) DEFAULT NULL,
  `personal_meeting_id` varchar(500) DEFAULT NULL,
  `is_custom_password` tinyint(1) DEFAULT NULL,
  `is_host_myaudio` tinyint(1) DEFAULT NULL,
  `password` varchar(500) DEFAULT NULL,
  `dial_in_countries` json DEFAULT NULL,
  `participants` json DEFAULT NULL,
  `is_cancelled` bigint DEFAULT NULL,
  `is_attended` bigint DEFAULT NULL,
  `save_template` tinyint(1) DEFAULT NULL,
  `hostName` varchar(500) DEFAULT NULL,
  `uuid` varchar(500) DEFAULT NULL,
  `status` varchar(500) DEFAULT NULL,
  `invite_url` varchar(500) DEFAULT NULL,
  `speakingLanguage` varchar(500) DEFAULT NULL,
  `files` json DEFAULT NULL,
  `createdat` varchar(500) DEFAULT NULL,
  `updatedat` varchar(500) DEFAULT NULL,
  `alternate_host` json DEFAULT NULL,
  `HostAddress` varchar(125) DEFAULT NULL,
  PRIMARY KEY (`template_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Worktual_Meeting_files`
--

DROP TABLE IF EXISTS `Worktual_Meeting_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Worktual_Meeting_files` (
  `user_id` varchar(100) DEFAULT NULL,
  `files` json DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Worktual_Transcript_files`
--

DROP TABLE IF EXISTS `Worktual_Transcript_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Worktual_Transcript_files` (
  `MeetingId` varchar(100) DEFAULT NULL,
  `files` json DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Worktual_call_recording_details`
--

DROP TABLE IF EXISTS `Worktual_call_recording_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Worktual_call_recording_details` (
  `id` int NOT NULL AUTO_INCREMENT,
  `call_uid` varchar(250) DEFAULT NULL,
  `call_callid` varchar(250) DEFAULT NULL,
  `extension` varchar(25) DEFAULT NULL,
  `from_number` varchar(25) DEFAULT NULL,
  `to_number` varchar(25) DEFAULT NULL,
  `call_direction` varchar(25) DEFAULT NULL,
  `call_type` varchar(25) DEFAULT NULL,
  `recording_duration` int DEFAULT NULL,
  `recording_file_path` varchar(125) DEFAULT NULL,
  `file_size` int DEFAULT NULL,
  `q_extn` varchar(25) DEFAULT NULL,
  `domain_name` varchar(155) DEFAULT NULL,
  `domain_id` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_info_master_details`
--

DROP TABLE IF EXISTS `app_info_master_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_info_master_details` (
  `id` int NOT NULL AUTO_INCREMENT,
  `appId` varchar(50) NOT NULL,
  `appSecret` varchar(50) DEFAULT NULL,
  `appName` varchar(150) DEFAULT NULL,
  `domain` varchar(250) DEFAULT NULL,
  `createdBy` varchar(50) DEFAULT NULL,
  `createOn` varchar(250) DEFAULT NULL,
  `accessType` varchar(250) DEFAULT NULL,
  `createdate` datetime DEFAULT NULL,
  PRIMARY KEY (`id`,`appId`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `multi_ivr_reg_details`
--

DROP TABLE IF EXISTS `multi_ivr_reg_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `multi_ivr_reg_details` (
  `reg_id` int NOT NULL AUTO_INCREMENT,
  `server_ip` varchar(255) DEFAULT NULL,
  `Max_call_load` varchar(255) DEFAULT NULL,
  `vms_srv_local_weburl` varchar(255) DEFAULT NULL,
  `Vms_srv_sip_login_number` varchar(255) DEFAULT NULL,
  `vms_srv_sip_login_password` varchar(255) DEFAULT NULL,
  `Vms_registrar_sip_url` varchar(255) DEFAULT NULL,
  `Vms_registration_enabled` varchar(255) DEFAULT NULL,
  `Vms_server_enabled` varchar(255) DEFAULT NULL,
  `Vms_server_preference_order` varchar(255) DEFAULT NULL,
  `Direct_ext_dial_num` varchar(255) DEFAULT NULL,
  `Foreign_ext_dial_num` varchar(255) DEFAULT NULL,
  `Disa_number` varchar(255) DEFAULT NULL,
  `Disa_enabled` varchar(255) DEFAULT NULL,
  `Vms_call_max_duration` varchar(255) DEFAULT NULL,
  `Vms_max_store_duration` varchar(255) DEFAULT NULL,
  `Vms_max_del_store_duration` varchar(255) DEFAULT NULL,
  `server_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`reg_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sip_dir_users_info`
--

DROP TABLE IF EXISTS `sip_dir_users_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sip_dir_users_info` (
  `Operation` varchar(100) DEFAULT NULL,
  `message` json DEFAULT NULL,
  `code` json DEFAULT NULL,
  `dir_users_HistoryID` int DEFAULT NULL,
  `user_id` varchar(250) DEFAULT NULL,
  `domain_id` varchar(250) DEFAULT NULL,
  `password` varchar(150) DEFAULT NULL,
  `msisdn` varchar(250) DEFAULT NULL,
  `leg_delay_start` varchar(250) DEFAULT NULL,
  `call_timeout` varchar(250) DEFAULT NULL,
  `vm_mailto` varchar(250) DEFAULT NULL,
  `callgroup_id` varchar(250) DEFAULT NULL,
  `lastupdate` varchar(250) DEFAULT NULL,
  `updatedby` varchar(250) DEFAULT NULL,
  `CallPickup` varchar(250) DEFAULT NULL,
  `cli` varchar(250) DEFAULT NULL,
  `original_password` varchar(250) DEFAULT NULL,
  `desk_phone` varchar(250) DEFAULT NULL,
  `mobile_phone` varchar(250) DEFAULT NULL,
  `vmd_disable` varchar(250) DEFAULT NULL,
  `vmd_callreject_cc` varchar(250) DEFAULT NULL,
  `position` varchar(250) DEFAULT NULL,
  `Title` varchar(250) DEFAULT NULL,
  `vm_forward` varchar(250) DEFAULT NULL,
  `call_rec` varchar(250) DEFAULT NULL,
  `call_queue` varchar(250) DEFAULT NULL,
  `call_queue_play` varchar(250) DEFAULT NULL,
  `hide` varchar(250) DEFAULT NULL,
  `assign` varchar(250) DEFAULT NULL,
  `assign_by_mobileno` varchar(250) DEFAULT NULL,
  `assign_by_extension` varchar(250) DEFAULT NULL,
  `call_queue_message` varchar(250) DEFAULT NULL,
  `User_Disabled` tinyint(1) DEFAULT NULL,
  `Deskphone_Disabled` tinyint(1) DEFAULT NULL,
  `Directory_Published` tinyint(1) DEFAULT NULL,
  `User_Image_Name` varchar(250) DEFAULT NULL,
  `Directory_Published_Date` varchar(250) DEFAULT NULL,
  `Department` varchar(250) DEFAULT NULL,
  `dnd` varchar(250) DEFAULT NULL,
  `ondemand_recording` tinyint(1) DEFAULT NULL,
  `call_queue_file_path` varchar(250) DEFAULT NULL,
  `is_call_scrn_enabled` tinyint(1) DEFAULT NULL,
  `is_enable` tinyint(1) DEFAULT NULL,
  `call_return_sts` tinyint(1) DEFAULT NULL,
  `ff_status` tinyint(1) DEFAULT NULL,
  `is_sof_enabled` tinyint(1) DEFAULT NULL,
  `user_hours` tinyint(1) DEFAULT NULL,
  `alexa_token` varchar(250) DEFAULT NULL,
  `alexa_status` varchar(250) DEFAULT NULL,
  `did_number` varchar(250) DEFAULT NULL,
  `ga_token` json DEFAULT NULL,
  `sip_login_id` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ur_client_domain_url`
--

DROP TABLE IF EXISTS `ur_client_domain_url`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ur_client_domain_url` (
  `id` int NOT NULL AUTO_INCREMENT,
  `client_domain_url` json DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ur_ecom_del_user_info`
--

DROP TABLE IF EXISTS `ur_ecom_del_user_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ur_ecom_del_user_info` (
  `company_id` int NOT NULL,
  `domain_id` int NOT NULL,
  `extension` varchar(10) DEFAULT NULL,
  `firstname` varchar(50) DEFAULT NULL,
  `lastname` varchar(50) DEFAULT NULL,
  `sip_login_id` int NOT NULL,
  `delete_date` datetime(3) DEFAULT NULL,
  `email` varchar(250) DEFAULT NULL,
  `sip_loginid` varchar(55) DEFAULT NULL,
  PRIMARY KEY (`company_id`,`domain_id`,`sip_login_id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ur_internal_ivr_number`
--

DROP TABLE IF EXISTS `ur_internal_ivr_number`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ur_internal_ivr_number` (
  `inter_id` int NOT NULL AUTO_INCREMENT,
  `hostAddress` varchar(255) DEFAULT NULL,
  `menu_name` varchar(255) DEFAULT NULL,
  `ivrExt` int DEFAULT NULL,
  `uuid` varchar(255) DEFAULT NULL,
  `companyId` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`inter_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ur_ivr_audio`
--

DROP TABLE IF EXISTS `ur_ivr_audio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ur_ivr_audio` (
  `aud_id` int NOT NULL AUTO_INCREMENT,
  `fieldname` varchar(255) DEFAULT NULL,
  `encoding` varchar(255) DEFAULT NULL,
  `mimetype` varchar(255) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `path` varchar(255) DEFAULT NULL,
  `size` int DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `domain` varchar(255) DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`aud_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ur_ivr_info`
--

DROP TABLE IF EXISTS `ur_ivr_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ur_ivr_info` (
  `ivr_id` int NOT NULL AUTO_INCREMENT,
  `ivrJson` longtext,
  `ivrXml` text,
  `ivrExt` text,
  `didNo` json DEFAULT NULL,
  `uuid` varchar(255) DEFAULT NULL,
  `companyId` int DEFAULT NULL,
  `domainName` varchar(255) DEFAULT NULL,
  `createdBy` varchar(255) DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `isDefaultIvr` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `ivrName` varchar(255) DEFAULT NULL,
  `didNumberCountryId` int DEFAULT NULL,
  `didNumberCityId` int DEFAULT NULL,
  `didNumberType` varchar(255) DEFAULT NULL,
  `memberXml` text,
  `assignedNumbers` json DEFAULT NULL,
  PRIMARY KEY (`ivr_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ur_voice_mail_details`
--

DROP TABLE IF EXISTS `ur_voice_mail_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ur_voice_mail_details` (
  `voice_id` int NOT NULL AUTO_INCREMENT,
  `vm_user_id` int DEFAULT NULL,
  `Vm_uuid` varchar(255) DEFAULT NULL,
  `vms_server_id` varchar(255) DEFAULT NULL,
  `domain_id` int DEFAULT NULL,
  `vbox_number` varchar(255) DEFAULT NULL,
  `cid_name` varchar(255) DEFAULT NULL,
  `cid_number` varchar(255) DEFAULT NULL,
  `vmail_server_url` varchar(255) DEFAULT NULL,
  `file_path` varchar(255) DEFAULT NULL,
  `NFSPath` varchar(255) DEFAULT NULL,
  `message_len` varchar(255) DEFAULT NULL,
  `wav_duration` varchar(255) DEFAULT NULL,
  `ReadFlag` varchar(255) DEFAULT NULL,
  `Archived_flag` varchar(255) DEFAULT NULL,
  `deleted_flag` varchar(255) DEFAULT NULL,
  `Forwarded_by` varchar(255) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `mp3_filepath` varchar(255) DEFAULT NULL,
  `deleted_date` datetime DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  PRIMARY KEY (`voice_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `worktual_video_bell_notification`
--

DROP TABLE IF EXISTS `worktual_video_bell_notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `worktual_video_bell_notification` (
  `id` int NOT NULL AUTO_INCREMENT,
  `from` varchar(255) DEFAULT NULL,
  `to` json DEFAULT NULL,
  `message` json DEFAULT NULL,
  `timestamp` bigint DEFAULT NULL,
  `ReadFlag` varchar(255) DEFAULT NULL,
  `type` int DEFAULT NULL,
  `createdat` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `from` (`from`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `worktual_video_meeting_Settings`
--

DROP TABLE IF EXISTS `worktual_video_meeting_Settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `worktual_video_meeting_Settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sip_id` varchar(20) DEFAULT NULL,
  `security` varchar(250) DEFAULT NULL,
  `schedule` varchar(250) DEFAULT NULL,
  `in_meeting_basics` varchar(250) DEFAULT NULL,
  `in_meeting_advance` varchar(250) DEFAULT NULL,
  `createdat` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sip_id` (`sip_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `worktual_video_meeting_master_dtl`
--

DROP TABLE IF EXISTS `worktual_video_meeting_master_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `worktual_video_meeting_master_dtl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uuid` text,
  `participants` json NOT NULL,
  `title` varchar(250) NOT NULL,
  `meeting_id` varchar(250) NOT NULL,
  `password` varchar(100) DEFAULT NULL,
  `personal_meeting_id` varchar(100) NOT NULL,
  `msgid` varchar(100) DEFAULT NULL,
  `server_host` varchar(100) DEFAULT NULL,
  `hostName` varchar(100) DEFAULT NULL,
  `sip_id` varchar(20) DEFAULT NULL,
  `invite_url` varchar(100) DEFAULT NULL,
  `onlyContacts` tinyint(1) DEFAULT NULL,
  `restrictScreenShare` tinyint(1) DEFAULT NULL,
  `requireAuthentication` tinyint(1) DEFAULT NULL,
  `authenticationJoin` enum('Anyone','Only contacts','All signed in user') NOT NULL,
  `chatSetting` json DEFAULT NULL,
  `meetings_type` varchar(20) DEFAULT NULL,
  `description` varchar(250) DEFAULT NULL,
  `start_timestamp` bigint NOT NULL,
  `end_timestamp` bigint NOT NULL,
  `lastModifiedDate` bigint DEFAULT NULL,
  `duration_minutes` int NOT NULL,
  `timezone` varchar(250) NOT NULL,
  `joining_option_type` varchar(30) NOT NULL,
  `calender_type` varchar(20) NOT NULL,
  `recurrence` enum('None','Daily','Weekly','Monthly') NOT NULL,
  `rrule` varchar(30) NOT NULL,
  `is_host_myaudio` tinyint(1) DEFAULT NULL,
  `is_host_myvideo` tinyint(1) DEFAULT NULL,
  `is_participant_video` tinyint(1) DEFAULT NULL,
  `is_use_personal_meeting_id` tinyint(1) DEFAULT NULL,
  `is_participant_waiting_room` tinyint(1) DEFAULT NULL,
  `is_cancelled` tinyint(1) DEFAULT NULL,
  `is_attended` tinyint(1) DEFAULT NULL,
  `is_record_meeting` tinyint(1) DEFAULT NULL,
  `is_alternate_host` tinyint(1) DEFAULT NULL,
  `is_participant_join_bef_host` tinyint(1) DEFAULT NULL,
  `is_participant_invite_guest` tinyint(1) DEFAULT NULL,
  `is_participant_mute_entry` tinyint(1) DEFAULT NULL,
  `is_without_host_continue` tinyint(1) DEFAULT NULL,
  `is_custom_password` tinyint(1) DEFAULT NULL,
  `speakingLanguage` varchar(30) DEFAULT NULL,
  `dial_in_countries` json NOT NULL,
  `save_template` tinyint(1) DEFAULT NULL,
  `status` varchar(30) DEFAULT NULL,
  `ReadFlag` json DEFAULT NULL,
  `files` json DEFAULT NULL,
  `createdate` datetime DEFAULT NULL,
  `modifieddate` datetime DEFAULT NULL,
  `alternate_host` json DEFAULT NULL,
  `isRecurr` int DEFAULT NULL,
  `template_id` varchar(255) DEFAULT NULL,
  `is_deleted` int DEFAULT NULL,
  `is_host` enum('false','true') NOT NULL,
  `white_board` json DEFAULT NULL,
  `HostAddress` varchar(125) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=78 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `worktual_video_meeting_transcript_details`
--

DROP TABLE IF EXISTS `worktual_video_meeting_transcript_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `worktual_video_meeting_transcript_details` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uuid` text,
  `transcripts` json DEFAULT NULL,
  `MOM` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping events for database 'mysql_mongo'
--

--
-- Dumping routines for database 'mysql_mongo'
--
/*!50003 DROP PROCEDURE IF EXISTS `Aorecord_get_master_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `Aorecord_get_master_info`(`key` text)
Begin
 	select a.`key`,a.Call_id,a.Contact_address,a.Ipaddress,a.proxy_username,a.transport_type,a.device_type,a.Registered_time,a.session_state
     from Aorecord_master_details a where a.`key`=`key`;
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Aorecord_insert_master_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `Aorecord_insert_master_info`(
 `key` text,
 Call_id	text,
 Contact_address	text,	
 Ipaddress text,
 proxy_username text,	
 transport_type text,
 device_type	text,
 Registered_time text,
 session_state text
 )
begin
 
 	declare errcode int default -1;
     declare errmsg varchar(100) default 'Failure';
     
     insert into Aorecord_master_details_log(`key`,Call_id,Contact_address,Ipaddress,proxy_username,transport_type,device_type,Registered_time,session_state,createdate)
     values (`key`,Call_id,Contact_address,Ipaddress,proxy_username,transport_type,device_type,Registered_time,session_state,current_timestamp);
      
 	if not exists(select 1 from Aorecord_master_details a where a.`key` =  `key`) then
 		insert into Aorecord_master_details (`key`,Call_id,Contact_address,Ipaddress,proxy_username,transport_type,device_type,Registered_time,session_state,createdate,modifydate)
         values(`key`,Call_id,Contact_address,Ipaddress,proxy_username,transport_type,device_type,Registered_time,session_state,current_timestamp,current_timestamp);
         
         if row_count() > 0 then
 			set errcode =0;
 			set errmsg ='Success: Inserted';
         End if;
     Else
 
 		update Aorecord_master_details a
         set 
         a.`key` = ifnull(`key`,a.`key`),
         a.Call_id = ifnull(Call_id,a.Call_id),
         a.Contact_address = ifnull(Contact_address,a.Contact_address),
         a.Ipaddress = ifnull(Ipaddress,a.Ipaddress),
         a.proxy_username = ifnull(proxy_username,a.proxy_username),
         a.transport_type = ifnull(transport_type,a.transport_type),
         a.device_type = ifnull(device_type,a.device_type),
         a.Registered_time = ifnull(Registered_time,a.Registered_time),
         a.session_state = ifnull(session_state,a.session_state),
         a.modifydate = current_timestamp
         where a.`key` = `key`;
         
         if row_count() > 0 then
 			set errcode =0;
 			set errmsg ='Success: Updated';
         End if;
 
     End if;
 select errcode as errcode, errmsg as errmsg;
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `app_info_get_master_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `app_info_get_master_details`(
appId varchar(50)
)
Begin
select a.appId,a.appSecret,a.appName,a.domain,a.createdBy,a.createOn,a.accessType
from app_info_master_details a where a.appId =  appId;

End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `app_info_insert_master_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `app_info_insert_master_details`(
appId varchar(50),
appSecret varchar(50),
appName varchar(150),
domain varchar(250),
createdBy varchar(50),
createOn varchar(250),
accessType varchar(250)
)
Begin

	declare errcode int default -1;
    declare errmsg varchar(100) default 'Failure';
    
    if not exists(select 1 from app_info_master_details a where a.appId =  appId) then
		insert into app_info_master_details (appId,appSecret,appName,domain,createdBy,createOn,accessType,createdate)
        values(appId,appSecret,appName,domain,createdBy,createOn,accessType,current_timestamp);
        
        if row_count() > 0 then
			set errcode =0;
			set errmsg ='Success: Inserted';
        End if;
    End if;
    select errcode as errcode, errmsg as errmsg;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `dynamic_search` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `dynamic_search`(
   searchby VARCHAR(30),   
   searchvalue VARCHAR(100) ,  
   sortby VARCHAR(50),   
   sortorder  VARCHAR(50),  
   RowsOfPage INT ,  
   PageNumber INT)
BEGIN
    
    DECLARE v_qry LONGTEXT;  
    
    IF searchby is null 
    then
       set searchby = 'fullname';
    END IF;
    
    IF searchvalue is null 
    then
       set searchvalue = 'MiriamIgunnubole';
    END IF;
    
    IF sortby is null 
    then
       set sortby = 'fullname';
    END IF;
    
    IF sortorder is null 
    then
       set sortorder = 'asc';
    END IF;
    
    IF RowsOfPage is null 
    then
       set RowsOfPage = 10;
    END IF;
    
    IF PageNumber is null 
    then
       set PageNumber = 1;
    END IF;
    
    SET v_qry = 'SELECT  fullname, mobile_number,customer_id,sim_order_id,subscriber_id,email,iccid,serial_number,  
  lead_status,social_media_accounts,connection_type,connection_status,postpaid_bundleid,bonus_balance,balance,sim_type,address1,address2  
   FROM tablename WHERE ' or searchby or ' LIKE ''%' or searchvalue or '%''   
      ORDER BY ' or sortby or ' ' or sortorder or  ' OFFSET ' or CAST((PageNumber -1)*RowsOfPage AS CHAR(30)) or
    ' ROWS FETCH NEXT ' or CAST(RowsOfPage AS CHAR(30)) or ' ROWS ONLY ';  
    
    SET @SWV_Stmt = v_qry;
    PREPARE SWT_Stmt FROM @SWV_Stmt;
    EXECUTE SWT_Stmt;
    DEALLOCATE PREPARE SWT_Stmt;  
      
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `multi_ivr_get_xml_byextension` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `multi_ivr_get_xml_byextension`(
ivrext_num varchar(255),
domain varchar(255))
begin 

	select a.domainName as domain_name,a.ivrXml as ivr_xml_action_script 
    from ur_ivr_info a
    where a.ivrExt = ivrext_num and a.domainName = domain;
    
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `multi_ivr_reg_get_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `multi_ivr_reg_get_details`(server_ip varchar(255))
begin
	
    select a.server_id,a.Max_call_load,a.vms_srv_local_weburl,a.Vms_srv_sip_login_number,a.vms_srv_sip_login_password,a.Vms_registrar_sip_url,a.Vms_registration_enabled,
		   a.Vms_server_enabled,a.Vms_server_preference_order,a.Direct_ext_dial_num,a.Foreign_ext_dial_num,a.Disa_number,a.Disa_enabled,
		   a.Vms_call_max_duration,a.Vms_max_store_duration,a.Vms_max_del_store_duration
     from  multi_ivr_reg_details a      
     where a.server_ip = server_ip;
     
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sip_pwd_migration` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sip_pwd_migration`(
  Domain_name varchar(100)
)
begin
  
  	select b.domain_id Domain_id,concat(d.firstname,' ',d.surname) caller_id,du.password as Sip_password, d.Extension_Number as ext
  	from dir_domains a join vbcp_pbx_account b on a.id = b.domain_id
  	join ur_app_login_details c on b.company_id = c.company_id 
  	join UR_ECom_User_Extension_Dtl d on c.login_user_name = d.email 
  	join ur_sip_credential e on c.app_log_id = e.app_log_id 
    join dir_users du on du.domain_id = b.domain_id and du.user_id = d.Extension_Number
  	where a.domain_name = domain_name;	
  
  end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `urmeet_create_guest_user` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `urmeet_create_guest_user`(IN  Operation VARCHAR(250),in message json,in code json,
IN dir_users_HistoryID int,IN user_id VARCHAR(250),IN domain_id VARCHAR(250), IN password VARCHAR(250),
IN msisdn VARCHAR(250),IN leg_delay_start VARCHAR(250),IN call_timeout VARCHAR(50),IN vm_mailto VARCHAR(50),
IN callgroup_id VARCHAR(250),IN lastupdate VARCHAR(50),IN updatedby VARCHAR(250),IN CallPickup VARCHAR(250),
IN cli VARCHAR(250) ,IN original_password varchar(250),IN desk_phone VARCHAR(250) ,IN mobile_phone VARCHAR(250) ,
IN vmd_disable VARCHAR(250) ,IN vmd_callreject_cc VARCHAR(250) ,IN position VARCHAR(250) ,IN Title VARCHAR(250) ,
IN vm_forward VARCHAR(250) ,IN call_rec VARCHAR(250) ,IN call_queue VARCHAR(250) ,IN call_queue_play VARCHAR(250) ,
IN hide VARCHAR(250) , IN assign VARCHAR(250) ,IN assign_by_mobileno VARCHAR(250) ,IN assign_by_extension VARCHAR(250) ,
IN call_queue_message VARCHAR(250) ,IN User_Disabled BOOLEAN ,IN Deskphone_Disabled BOOLEAN ,IN Directory_Published VARCHAR(250) ,
IN User_Image_Name VARCHAR(250) ,IN Directory_Published_Date VARCHAR(250) ,IN Department VARCHAR(250) ,IN dnd VARCHAR(250),
IN ondemand_recording BOOLEAN ,IN call_queue_file_path VARCHAR(250) ,IN is_call_scrn_enabled BOOLEAN,IN is_enable BOOLEAN,
IN call_return_sts BOOLEAN,IN ff_status BOOLEAN,IN is_sof_enabled BOOLEAN,IN user_hours VARCHAR(250),
IN alexa_token VARCHAR(250) ,IN alexa_status VARCHAR(250) ,IN did_number VARCHAR(250),IN ga_token  json,IN sip_login_id INT)
BEGIN

  DECLARE errcode int;
  DECLARE errmsg VARCHAR(100);
  
  set errcode=-1;
  set errmsg='Failure to insert guest User';


INSERT INTO `unifiedring`.`sip_dir_users_info`
(`Operation`,
`message`,
`code`,
`dir_users_HistoryID`,
`user_id`,
`domain_id`,
`password`,
`msisdn`,
`leg_delay_start`,
`call_timeout`,
`vm_mailto`,
`callgroup_id`,
`lastupdate`,
`updatedby`,
`CallPickup`,
`cli`,
`original_password`,
`desk_phone`,
`mobile_phone`,
`vmd_disable`,
`vmd_callreject_cc`,
`position`,
`Title`,
`vm_forward`,
`call_rec`,
`call_queue`,
`call_queue_play`,
`hide`,
`assign`,
`assign_by_mobileno`,
`assign_by_extension`,
`call_queue_message`,
`User_Disabled`,
`Deskphone_Disabled`,
`Directory_Published`,
`User_Image_Name`,
`Directory_Published_Date`,
`Department`,
`dnd`,
`ondemand_recording`,
`call_queue_file_path`,
`is_call_scrn_enabled`,
`is_enable`,
`call_return_sts`,
`ff_status`,
`is_sof_enabled`,
`user_hours`,
`alexa_token`,
`alexa_status`,
`did_number`,
`ga_token`,
`sip_login_id`)
VALUES
(
Operation,
message,
code,
dir_users_HistoryID,
user_id,
domain_id,
password,
msisdn,
leg_delay_start,
call_timeout,
vm_mailto,
callgroup_id,
lastupdate,
updatedby,
CallPickup,
cli,
original_password,
desk_phone,
mobile_phone,
vmd_disable,
vmd_callreject_cc,
position,
Title,
vm_forward,
call_rec,
call_queue,
call_queue_play,
hide,
assign,
assign_by_mobileno,
assign_by_extension,
call_queue_message,
User_Disabled,
Deskphone_Disabled,
Directory_Published,
User_Image_Name,
Directory_Published_Date,
Department,
dnd,
ondemand_recording,
call_queue_file_path,
is_call_scrn_enabled,
is_enable,
call_return_sts,
ff_status,
is_sof_enabled,
user_hours,
alexa_token,
alexa_status,
did_number,
ga_token,
sip_login_id
);

   if (row_count()>0) then
		 set errcode=0;
		set errmsg='Success to delete guest User';
    end if;
   
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `urmeet_delete_guest_user` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `urmeet_delete_guest_user`(in user_id varchar(150))
begin

  DECLARE errcode int;
  DECLARE errmsg VARCHAR(100);

  set errcode=-1;
  set errmsg='Failure to delete guest User';

	delete from  `sip_dir_users_info` where  'user_id'=user_id;
    
    
     if (row_count()>0) then
		 set errcode=0;
		set errmsg='Success to delete guest User';
    end if;
   

select errcode as errcode,errmsg as errmsg;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `urmeet_delete_virtual_file` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `urmeet_delete_virtual_file`(IN user_id varchar(100),IN uu_id varchar(100))
BEGIN
	
    DECLARE errcode INT;
    DECLARE errmsg  VARCHAR(150);
	
    SET errcode=-1;
    SET errmsg='Failure to delete file';
    
	delete from Worktual_Meeting_files a where a.`user_id`=user_id AND json_extract(a.files,'$[4].id')=uu_id;
    
    if (row_count()>0) then
		 SET errcode=0;
		  SET errmsg='Success to delete file';
    end if;

select errcode as errcode,errmsg as errmsg;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `urmeet_get_Transcript_file` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `urmeet_get_Transcript_file`(IN MeetingId varchar(100))
BEGIN
	
	select  MeetingId,files from Worktual_Transcript_files a where a.`MeetingId`=MeetingId;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `urmeet_get_virtual_file` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `urmeet_get_virtual_file`(IN user_id varchar(100))
BEGIN
	
	select  user_id,files from Worktual_Meeting_files a where a.`user_id`=user_id;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `urmeet_meetingTemplates_deleteTemplate` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `urmeet_meetingTemplates_deleteTemplate`(
In template_id VARCHAR(500) )
BEGIN

declare errcode int default -1;
declare errmsg varchar(55) default 'template_id not exists';

if exists (select 1 from Worktual_Meeting_Template a where a.template_id = template_id limit 1)
then
 	DELETE a FROM Worktual_Meeting_Template a where a.template_id=template_id;  

	IF ROW_COUNT()>0
	THEN
		SET errcode = 0;
		SET errmsg = 'DELETED SUCCESSFULLY';
	END IF;
	
end if;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `urmeet_meetingTemplates_filter_template` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `urmeet_meetingTemplates_filter_template`(sip_id int ,In offsets INT,in limits INT,IN sort INT,IN type VARCHAR(100))
BEGIN
  
  	DECLARE V_sort varchar(100);
      
  	SET V_sort=CASE WHEN sort=-1 THEN 'ASC' ELSE 'DESC' END;
    
    if type <>'title' then
		set type = 'updatedat';
    end if;
  
  	SET @limit_sp = CONCAT(' LIMIT ', offsets , ',', limits,' ;');
      SET @sort_sp = CONCAT(' Order by ', type ,' ' , V_sort);
      SET @query = CONCAT( "SELECT * FROM Worktual_Meeting_Template a where a.sip_id=sip_id");
        SET @query = CONCAT(@query, @sort_sp);
      SET @query = CONCAT(@query, @limit_sp);
      
     
      PREPARE stmt FROM @query;
      EXECUTE stmt ;
      DEALLOCATE PREPARE stmt ;
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `urmeet_meetingTemplates_getTemplate` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `urmeet_meetingTemplates_getTemplate`(In template_id VARCHAR(500) )
BEGIN
	SELECT * FROM Worktual_Meeting_Template a where a.template_id=template_id;  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `urmeet_meetingTemplates_getTemplate_by_sipid` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `urmeet_meetingTemplates_getTemplate_by_sipid`(In sip_id VARCHAR(500) )
BEGIN
 	SELECT * FROM Worktual_Meeting_Template a where a.sip_id=sip_id;  
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `urmeet_meetingTemplates_templateTitle` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `urmeet_meetingTemplates_templateTitle`(In template_id VARCHAR(500))
BEGIN
 	SELECT title FROM Worktual_Meeting_Template a where a.template_id=template_id;
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `urmeet_upload_Transcript_file` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `urmeet_upload_Transcript_file`( IN MeetingId varchar(100),in files json)
BEGIN
	declare errcode int;
    declare errmsg varchar(160);
    
    set errcode=-1;
    set errmsg='Failure to insert Transcript Files';
    
    INSERT INTO Worktual_Transcript_files(`MeetingId`,`files`)
    VALUES(MeetingId,files);
    
    if (row_count()>1) then
		set errcode=0;
        set errmsg='Success to insert Transcript Files';
    end if;
    
select errcode as errcode,errmsg as errmsg;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `urmeet_upload_virtual_file` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `urmeet_upload_virtual_file`( IN user_id varchar(100),in files json)
BEGIN
	declare errcode int;
    declare errmsg varchar(160);
    
    set errcode=-1;
    set errmsg='Failure to insert Meeting Files';
    
    INSERT INTO Worktual_Meeting_files(`user_id`,`files`)
    VALUES(user_id,files);
    
    if (row_count()>0) then
		set errcode=0;
        set errmsg='Success to insert Meeting Files';
    end if;
    

select errcode as errcode,errmsg as errmsg;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ur_app_get_deleted_user_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ur_app_get_deleted_user_info`(
 company_id INT,  
 timestamp BIGINT)
BEGIN
 
    IF timestamp is null 
    then
       set timestamp = 0;
    END IF;
    
    select extension,sip_login_id as sip_id,TIMESTAMPDIFF(SECOND,'1970-01-01 00:00:00',delete_date) as `timestamp`,a.firstname first_name,a.lastname last_name,a.sip_login_id,concat(a.firstname,' ',a.lastname)caller_id
    from ur_ecom_del_user_info a where not exists(select b.Email from UR_ECom_User_Extension_Dtl b where a.email = b.email 
    and a.company_id = b.Company_id) and a.company_id = company_id
    and (TIMESTAMPDIFF(SECOND,'1970-01-01 00:00:00',delete_date) > timestamp or IFNULL(timestamp,0) = 0)
    order by delete_date desc;   
 
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ur_get_deleted_user_list` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ur_get_deleted_user_list`(
 company_id int
 )
Begin
 	select a.company_id,a.domain_id,a.extension,a.firstname,a.lastname,a.sip_login_id,a.email 
 	from ur_ecom_del_user_info a where a.company_id = company_id;
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ur_get_sip_domain_ext_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ur_get_sip_domain_ext_details`(
  Domain_name varchar(100),
  Ext varchar(10))
begin
  
  	select b.domain_id Domain_id,concat(d.firstname,' ',d.surname) caller_id,du.password as Sip_password 
  	from dir_domains a join vbcp_pbx_account b on a.id = b.domain_id
  	join ur_app_login_details c on b.company_id = c.company_id 
  	join UR_ECom_User_Extension_Dtl d on c.login_user_name = d.email 
  	
    join dir_users du on du.domain_id = b.domain_id and du.user_id = d.Extension_Number
  	where d.Extension_Number = ext and a.domain_name = domain_name;	
  
  end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ur_ma_login_validation` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ur_ma_login_validation`(
     					  login_user_name VARCHAR(50),   
                           login_password  VARCHAR(50),   
                           login_source    VARCHAR(30),   
                           login_device_id VARCHAR(100),   
                           login_ipaddress VARCHAR(30))
BEGIN
                          
             			DECLARE v_error_code INT;   
             			DECLARE v_error_msg VARCHAR(250);   
             			DECLARE v_domain_id INT;   
             			DECLARE v_ext INT;   
             			DECLARE v_cli VARCHAR(20);   
             			DECLARE v_dir_user_id INT;   
             			DECLARE v_app_log_id INT;   
             			DECLARE v_now DATETIME(3) DEFAULT CURRENT_TIMESTAMP;  
             			DECLARE v_sip_login_id BIGINT;  
             			DECLARE v_sip_password VARCHAR(15);  
             			DECLARE v_caller_id VARCHAR(255);   
             			DECLARE v_company_id INT;  
             			DECLARE v_enetepriseid INT;  
             			DECLARE v_customer_id INT;  
             			DECLARE v_desk_password VARCHAR(100);  
             			DECLARE v_email_flag INT;   
             			DECLARE v_platform INT;  
             			DECLARE v_Email VARCHAR(250);  
             			DECLARE v_user_status VARCHAR(150);  
             			DECLARE v_site_id INT;  
             			DECLARE v_host_address VARCHAR(100);    	
             			DECLARE v_output VARCHAR(50);
             			DECLARE v_Role_Id INT;
             			DECLARE v_country_code VARCHAR(10);  
             			DECLARE v_local_number VARCHAR(30);
             			DECLARE v_user_type INT;     
             			DECLARE v_svc_id INT;     
             			DECLARE v_meeting_id VARCHAR(20);     
             			DECLARE v_profile_url VARCHAR(250);
             			DECLARE v_order_id INT;
             			DECLARE v_email_login_username VARCHAR(150);  
             			DECLARE v_meet_domain_name VARCHAR(500);    
             			DECLARE v_is_cas_user INT;   
             			DECLARE v_is_ucas_user INT;  
             			DECLARE v_is_crm_user INT;   
             			DECLARE v_ucas_role_info LONGTEXT DEFAULT '';  
             			DECLARE v_ccas_role_info LONGTEXT DEFAULT '';  
             			DECLARE v_crm_role_info LONGTEXT DEFAULT '';  
             			DECLARE v_crm_domain VARCHAR(100);  
             			DECLARE v_cas_domain VARCHAR(100);  
             			DECLARE v_domain_prefix VARCHAR(100);              
             			DECLARE default_int_val_0 int; 
             			DECLARE v_domain_name VARCHAR(250);
 						Declare v_usr_id  int;
 						Declare v_firstname VARCHAR(100);
 						Declare v_lastname  VARCHAR(100);
 						declare v_client_domain json;                          
                             GG:BEGIN
                                MSG:BEGIN
																												
                                set default_int_val_0 = 0;
                                
                                   if login_user_name REGEXP('^[+-.$.]?[[0-9,]+...]?$') 
                                   then
                                      if not exists(select 1 from did d where d.did_number = login_user_name LIMIT 1) 
                                      then   
                                         SET v_error_code = -1;
                                         SET v_error_msg = 'Please enter valid credentials';
                                         LEAVE GG;
                                      Else
                          				if not exists(select  1 from did d
                          						inner join dir_users u on d.svc_id = u.id
                          						inner join vbcp_pbx_account a on a.domain_id = u.domain_id
                          						inner join UR_ECom_User_Extension_Dtl e on e.company_id = a.company_id and e.Extension_Number = user_id
                          						where d.did_number = login_user_name LIMIT 1) then
                          		
                          					SET v_error_code = -1;
                          					SET v_error_msg = 'invalid password';
                          					LEAVE GG;
                          				end if;
                                      end if;
                                   end if;
                                   
                                   if login_user_name NOT REGEXP('^[+-.$.]?[[0-9,]+...]?$') 
                                   then
                                      if not exists(select 1 from UR_ECom_User_Extension_Dtl e where e.email = login_user_name LIMIT 1) 
                                      then  
                                         SET v_error_code = -1;
                                         SET v_error_msg = 'There is no account for the email you entered';
                                         LEAVE GG;
                                      Else
                                         if exists(select 1 from UR_ECom_User_Extension_Dtl e where e.email = login_user_name and e.status in(0,3) LIMIT 1) 
                                         then  
                                            SET v_error_code = -1;
                                            SET v_error_msg = 'You do not have access to UnifiedRing. Please contact your admin';
                                            LEAVE GG;
                                         end if;
                                         
                                         if not exists(select 1 from UR_ECom_User_Extension_Dtl e where e.email = login_user_name 
                                         and BINARY e.MyAcc_Password = login_password and status not in(0,3) LIMIT 1) 
                                         then  
                                            SET v_error_code = -1;
                                            SET v_error_msg = 'Please enter a valid Email and Password ';
                                            LEAVE GG;
                                         end if;
                                      end if;
                                   end if;  
                            
                           
                                   if exists(select 1 from did  d where d.did_number = login_user_name LIMIT 1) 
                                   then 
                                      select  e.Email INTO login_user_name from did d
                                      inner join dir_users u on d.svc_id = u.id
                                      inner join vbcp_pbx_account a on a.domain_id = u.domain_id
                                      inner join UR_ECom_User_Extension_Dtl e on e.company_id = a.company_id and e.Extension_Number = user_id where d.did_number = login_user_name limit 1;
                                      
                                      if exists(select  1 from UR_ECom_User_Extension_Dtl e where e.email = login_user_name  and e.status in(0,3) LIMIT 1) 
                                      then
                                         SET v_error_code = -1;
                                         SET v_error_msg = 'You do not have access to UnifiedRing. Please contact your admin';
                                         LEAVE GG;
                                      end if;
                                   end if;
            
                                   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
                                   select e.company_id,e.Firstname,e.Surname INTO v_company_id,v_firstname,v_lastname from UR_ECom_User_Extension_Dtl e where e.email = login_user_name and BINARY e.myacc_password = login_password limit 1;
                                   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
                                
                                   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
                                   select   A.site_id INTO v_site_id from  UR_Company_Site A Where A.company_id = v_company_id and A.site_name like '%main%site%' LIMIT 1;
                                   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
                                   
                                   if exists(select * from UR_ECom_User_Extension_Dtl e
                                   where e.email = login_user_name and BINARY e.myacc_password = login_password) 
                                   then  
                                
                                      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
             							select   id, pb.domain_id, user_id, b.app_log_id, c.sip_login_id, c.sip_password, a.effective_caller_id_name,
             									pb.company_id, IFNULL(b.profile_image_url,''), b.user_type, IFNULL(a.password,''), 
             									e.Role_Id, case e.home_country_code when 'UK' then '44' else '0' end, e.Mobileno, IFNULL(Email,''), case when b.user_status is null then ''
             									when b.user_status = 0 then 'Available'
             									when b.user_status = 1 then 'Busy'
             									when b.user_status = 2 then 'Do not disturb'
             									when b.user_status = 3 then 'Invisible' else '' end, IFNULL(e.Meeting_Id,'') 
             							INTO v_dir_user_id,v_domain_id,v_ext,v_app_log_id,v_sip_login_id,v_sip_password,
             									v_caller_id,v_company_id,v_profile_url,v_user_type,v_desk_password,
             									v_Role_Id,v_country_code,v_local_number,v_Email,v_user_status,v_meeting_id 
                                         FROM  ur_app_login_details b 
             							Left outer join  dir_users a  ON a.id = b.dir_user_id
             							Left outer join vbcp_pbx_account pb  on a.domain_id = pb.domain_id
             							left join  ur_sip_credential c  on b.app_log_id = c.app_log_id
             							inner join UR_ECom_User_Extension_Dtl e  on e.company_id = pb.company_id and  e.Extension_Number = user_id 
             							WHERE  e.email = login_user_name and BINARY e.myacc_password = login_password and e.status = 1 and b.is_enable = 1
             							and c.sip_login_id is not null limit 1;
                                      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
                                      
                                      if (v_domain_id = 0 or v_domain_id is null) or (v_sip_login_id = '0' or v_sip_login_id is null) 
                                      then   
                                         SET v_error_code = -1;
                                         SET v_error_msg = 'Inactive status';
                                      Else
                                         SET v_error_code = 0;
                                         SET v_error_msg = 'Login Successfull';
                                      end if;
                                      
                                      
                                      
                                      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
                                      select   B.customer_id INTO v_customer_id from vbcp_company B where B.company_id = v_company_id limit 1;
                                      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
                                      
                                      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
             							select IFNULL(a.external_number,'') INTO v_cli from  UR_phone_add_number_order_dtl  a
             							join UR_phone_add_number_order b  on a.order_id = b.order_id where b.company_id = v_company_id
             							and IFNULL(a.extension,'') = v_ext and IFNULL(a.extension,'') <> ''
             							and a.status = 1 and a.assign_type = 7 and a.external_number <> '' 
             							order by a.assign_date desc LIMIT 1;
                                      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
                                      set v_cli = IFNULL(v_cli,'');
                                      
                                      LEAVE msg;  
                              
                           
                                   ELSE 
                                      IF exists(select * from ur_app_login_details b  where b.login_user_name = login_user_name and BINARY b.login_password = login_password) 
                                      then  
                                         If v_company_id is null then
                            
                                            SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
                                            select   b.company_id INTO v_company_id from ur_app_login_details b where b.login_user_name = login_user_name and BINARY b.login_password = login_password limit 1;
                                            SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
                                         end if;  
                              
                                         SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
                                         select a.domain_id INTO v_domain_id from ur_app_login_details b 
                                         Left outer join dir_users a  ON a.id = b.dir_user_id
                                         left join ur_sip_credential c  on b.app_log_id = c.app_log_id where  b.login_user_name = login_user_name
                                         AND BINARY b.login_password = login_password  limit 1;
                                         SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;   
                                 
                                         If v_domain_id is null then
                                          SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
                                            select C.domain_id INTO v_domain_id from vbcp_pbx_account C where C.company_id = v_company_id  limit 1;
                                            SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
                                         end if;  
                                   
                                         SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
                                         select D.prefix INTO v_enetepriseid from dir_domains D where D.id = v_domain_id  limit 1;
                                         SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
                                         
                  						set v_host_address = CONCAT(cast(v_enetepriseid as CHAR(30)),'.urchat.unifiedring.co.uk');
                  						set v_meet_domain_name = CONCAT(cast(v_enetepriseid as CHAR(30)),'.urmeet.unifiedring.co.uk');
                               
             							
                                         
                                         SET v_error_code = 0;
                                         SET v_error_msg = 'Login Successfull';
                                         LEAVE msg;
                                      ELSE
                                         SET v_error_code = -1;
                                         SET v_error_msg = 'Email is not registered';
                            
                                         LEAVE msg;
                                      end if;
                                   end if;  
                  
                                END;
                                
                                INSERT INTO ur_app_login_details_log(app_log_id,dir_user_id,login_user_name,login_password,login_source,device_id,ip_address,error_code,error_msg,log_datetime)
                                VALUES(v_app_log_id,v_dir_user_id,login_user_name,login_password,login_source,login_device_id,login_ipaddress,v_error_code,v_error_msg,v_now);           
                            
                                IF NOT EXISTS(SELECT  1 FROM ur_sip_credential c WHERE c.app_log_id = v_app_log_id LIMIT 1)  AND v_error_code = 0 
                                then  
                                   
                                   CALL usp_generate_password(8,v_sip_password); 
                                   SET v_sip_password = v_output;
                                   
                                   Insert into ur_sip_credential(app_log_id,sip_password,created_by,created_date)
           						values(v_app_log_id,v_sip_password,'LOGIN-API',CURRENT_TIMESTAMP);
                             
                                   set v_sip_login_id = LAST_INSERT_ID();
                                end if;  
                              
                            
                                SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
                                select D.prefix INTO v_enetepriseid from dir_domains D where D.id = v_domain_id  limit 1;
                                SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
                                
                                set v_platform = v_enetepriseid;
                            
                                set v_host_address = CONCAT(cast(v_platform as CHAR(30)),'.urchat.unifiedring.co.uk');
                                set v_meet_domain_name = CONCAT(cast(v_enetepriseid as CHAR(30)),'.urmeet.unifiedring.co.uk');
                              
                                SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
             						select b.basket_id INTO v_order_id from vbcp_company f 
             						inner join crm_order b  on f.customer_id = b.customer_id 
             						and b.update_by = 'vtos_place_order_existing_customer' where f.company_id = v_company_id  limit 1;
                                SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
                                    
                                if v_user_type = 2 then
                                   set v_Role_Id = 4;
                  					SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;	
                  					select CONCAT(E.firstname,' ',IFNULL(E.lastname,'')) INTO v_caller_id from ur_app_invite_contact E where E.app_log_id = v_app_log_id  limit 1;
                  					SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
                                end if;
                                
                                if v_Role_Id is null then 
                                   set v_Role_Id = 3;
                                end if;
                 	             
             				select  1, CONCAT(COALESCE(v_ucas_role_info,''),',',CAST(role_id AS CHAR(30))) 
                             INTO v_is_ucas_user,v_ucas_role_info 
                             from ccas_prod_user_info a
             				join product_master b on a.prod_id = b.prod_id and b.prod_name = 'ucaas' where company_id = v_company_id and extension = v_ext  limit 1;
                             
             				IF LEFT(v_ucas_role_info,1) = ',' then
             					SET v_ucas_role_info = INSERT(v_ucas_role_info,1,1,'');
             				end if;
                 
             			select   1, CONCAT(COALESCE(v_ccas_role_info,''),',',CAST(role_id AS CHAR(30))) INTO v_is_cas_user,v_ccas_role_info from ccas_prod_user_info a
             			join product_master b on a.prod_id = b.prod_id and b.prod_name = 'ccaas' where company_id = v_company_id and extension = v_ext  limit 1;
             
             			IF LEFT(v_ccas_role_info,1) = ',' then
             				SET v_ccas_role_info = INSERT(v_ccas_role_info,1,1,'');
             			end if;
                         
             			select   1, CONCAT(COALESCE(v_crm_role_info,''),',',CAST(role_id AS CHAR(30))) INTO v_is_crm_user,v_crm_role_info from ccas_prod_user_info a
             			join product_master b on a.prod_id = b.prod_id and b.prod_name = 'crm' where company_id = v_company_id and extension = v_ext  limit 1;
             
             			IF LEFT(v_crm_role_info,1) = ',' then
             				SET v_crm_role_info = insert(v_crm_role_info,1,1,'');
             			end if;
        						SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;	
                                select D.domain_name,D.prefix INTO v_domain_name,v_domain_prefix from dir_domains D where D.id = v_domain_id  limit 1;
       	
          
                                SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
                                 set v_cas_domain = case when IFNULL(v_is_cas_user,0) = 1 then CONCAT(v_domain_prefix,'.ccaas.unifiedring.co.uk') else '' end;
             					set v_crm_domain = case when IFNULL(v_is_crm_user,0) = 1 then CONCAT(v_domain_prefix,'.crm.unifiedring.co.uk') else '' end;
                             END;
                             
            			if exists(select 1 from ur_app_login_details b where b.login_user_name = login_user_name AND BINARY b.login_password = login_password limit 1) then
            				UPDATE ur_app_login_details b
            				SET  b.login_source = login_source, b.device_id = login_device_id, b.ip_address = login_ipaddress
            				WHERE  b.login_user_name = login_user_name
            				AND BINARY b.login_password = login_password limit 1;
            			end if;
                     
     				select e.Usr_Id into v_usr_id 
     				from crm_order a 
     				join vtos_customer b on a.customer_id = b.customer_id
     				join vbcp_company c on c.customer_id = a.customer_id
     				join UR_ECom_User_Extension_Dtl d on d.company_id = c.company_id and a.basket_id = d.basket_id
     				join UR_ECom_Order_Plan e on e.Ord_Id = b.ecom_order_id
     				where d.email = login_user_name;
                    
					select client_domain_url into v_client_domain from ur_client_domain_url limit 1;

                             SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
                             SELECT v_error_code AS error_code,
                   				v_error_msg AS error_msg,
                   				ifnull(v_dir_user_id,default_int_val_0) AS dir_user_id,
                   				ifnull(v_domain_id,default_int_val_0) AS domain_id,
                   				ifnull(v_ext,default_int_val_0) AS ext,
                   				ifnull(v_cli,'') AS cli,
                   				v_sip_login_id as sip_login_id,
                   				ifnull(v_sip_password,'') as sip_password,
                   				ifnull(v_caller_id,'') as caller_id,
                   				ifnull(v_company_id,default_int_val_0) as company_id,
                   				ifnull(v_enetepriseid,default_int_val_0) as enetepriseid,
                   				ifnull(v_customer_id,default_int_val_0) as customer_id,
                   				ifnull(v_Role_Id,default_int_val_0) as role_id,
                   				ifnull(v_country_code,'') country_code,
                   				ifnull(v_local_number,'') as local_number,
                   				ifnull(v_app_log_id,default_int_val_0) as app_log_id,
                   				ifnull(v_profile_url,'') AS profile_url,
                   				ifnull(v_order_id,default_int_val_0) AS order_id,
                   				ifnull(v_desk_password,'') as dp_password,
                   				ifnull(v_platform,default_int_val_0) as platform,
                   				ifnull(v_Email,'') as Email,
                   				ifnull(v_user_status,'') as user_status,
                   				v_site_id as site_id,
                   				v_host_address as host_address,
                   				ifnull(v_domain_name,'') as domain_name,
                   				ifnull(v_meeting_id,'') as meeting_id,
                   				IFNULL(v_meet_domain_name,'') as video_meet_domain,
                 				ifnull(v_enetepriseid,default_int_val_0) as enterpriseid,
                                 IFNULL(v_is_cas_user,0) as is_cas_user,IFNULL(v_ccas_role_info,'') as ccas_role_info,
                 				IFNULL(v_cas_domain,'') as cas_domain,
                 				IFNULL(v_is_ucas_user,0) as is_ucas_user,IFNULL(v_ucas_role_info,'') as ucas_role_info,
                 				IFNULL(v_is_crm_user,0) as is_crm_user,IFNULL(v_crm_role_info,'') as crm_role_info,
                 				IFNULL(v_crm_domain,'') as crm_domain,ifnull(v_usr_id,0) as usr_id,
                                IFNULL(v_firstname,'') as firstname,
                                IFNULL(v_lastname,'') as lastname,
                                IFNULL(v_client_domain,'') as client_domain;                                
                                SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
                  			            
                          END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ur_myacc_delete_groupcall_list_mongodb_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ur_myacc_delete_groupcall_list_mongodb_details`(
 groupId text,
 callingno VARCHAR(20),
 domain_id INT
 
 )
Begin
 
 		DECLARE v_errcode INT DEFAULT -1;
 		DECLARE v_errmsg VARCHAR(50) DEFAULT 'Failure';
 
 sp_exit : Begin
         
 		drop temporary table  if exists tt_t1;
 		create temporary table tt_t1
 		(
 			group_call_Id varchar(50)
 		);
 
 		call split(groupId,',');
        
 		insert into  tt_t1(group_call_Id)
 		select Items from tt_Split_temptable;
         
 		drop temporary table  if exists tt_t3;
 		create temporary table tt_t3
      	(
      		group_call_Id varchar(50)
      	);
          
      	call split(groupId,',');
        
      	insert into tt_t3(group_call_Id)
      	select Items from tt_Split_temptable;
 
 		select * from ur_myacc_cdr_data_mongodb_details a
 		where a.serviceType = 'GroupCall' and a.groupId  in (select Distinct b.group_call_Id from tt_t1 b);
         
 		update ur_myacc_cdr_data_mongodb_details a
 		set a.deletedby_ext = callingno
 		where a.domainId = domain_id and ext = callingno 
         and a.serviceType = 'GroupCall'
 		and (a.callingno = callingno or a.calledno = callingno)
 		and (a.callingNo in (select cast(bb.group_call_Id as CHAR) as called_num from tt_t1 bb) or a.calledNo in (select cast(cc.group_call_Id as CHAR) as called_num from tt_t3 cc));
         
          if found_rows() > 0 
          then
               set v_errcode = 0;
               set v_errmsg = 'Deleted successfully';
               LEAVE sp_exit;
		  end if;
            
 	END sp_exit;
    
         select v_errcode as errcode, v_errmsg as errmsg;
 
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ur_myacc_update_group_call_cdr_mongodb_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ur_myacc_update_group_call_cdr_mongodb_details`(
  groupId text,
  groupCallDuration int,
  groupCallstartedTime datetime(3),
  groupCallEndedTime datetime(3)
  )
Begin
  
 
 		declare errcode int default -1;  
     	declare errmsg varchar(50) default 'Group id not exists';
         declare v_domainid int;
         declare eff_ext text;
         
         select domainId into v_domainid from ur_myacc_cdr_data_mongodb_details a where a.groupId = groupId limit 1 ;
         
		drop temporary table if exists t1_ext;
		create temporary table t1_ext as 
		
		select Distinct teamId from ur_myacc_cdr_data_mongodb_details a where a.groupId = groupId;
         
         select group_concat(effective_caller_id_name) into eff_ext 
         
         from dir_users a where a.domain_id = v_domainid and user_id in (select Distinct teamId from t1_ext);
        
 
  	     if exists(select 1 from ur_myacc_cdr_data_mongodb_details a where a.groupId = groupId limit 1)  Then 
  			update ur_myacc_cdr_data_mongodb_details a 
              set a.groupCallDuration= ifnull(groupCallDuration,a.groupCallDuration),
  				a.groupCallstartedTime= ifnull(groupCallstartedTime,a.groupCallstartedTime),
  				a.groupCallEndedTime= ifnull(groupCallEndedTime,a.groupCallEndedTime),
                 a.teamId = eff_ext
              where a.groupId = groupId;
              
              if row_count()>0 then
  				set errcode  = -1;
                  set errmsg = 'Group call details updated';
              End if;      
           End if;
  
  select errcode as errcode,errmsg as errmsg;
  
  End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ur_server_voicemail_reg_get_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ur_server_voicemail_reg_get_details`(
server_ip varchar(255)
)
begin
  	
      select a.server_id, a.Max_call_load, a.vms_srv_local_weburl, a.Vms_srv_sip_login_number, a.vms_srv_sip_login_password, 
			 a.Vms_registrar_sip_url, a.Vms_registration_enabled, a.Vms_server_enabled, a.Vms_server_preference_order, 
			 a.Direct_ext_dial_num, a.Foreign_ext_dial_num, a.Disa_number, a.Disa_enabled, a.Vms_call_max_duration, 
			 a.Vms_max_store_duration, a.Vms_max_del_store_duration
       from  multi_ivr_reg_details a     
       where a.server_ip = server_ip;
       
  end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ur_valid_extension_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ur_valid_extension_details`(
extension varchar(55),
domain_name varchar(55))
begin 
    
    declare Is_extension_valid int default 0;     

	select 1 into Is_extension_valid from vm_data_transfer_request a  join dir_domains b on a.domain_id = b.id join vbcp_pbx_account c on a.domain_id = c.domain_id 
				LEFT join UR_ECom_User_Extension_Dtl e on e.Company_id = c.company_id and a.extension = e.Extension_Number 
				where a.extension = extension and b.domain_name = domain_name and a.status = 0;
		
		select Is_extension_valid;			

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ur_valid_user_pin_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ur_valid_user_pin_details`(
Vm_username varchar(55),
Vm_User_pin varchar(55))
begin 
    
    declare Is_pin_valid int default 0;     

	select 1 into Is_pin_valid from vm_data_transfer_request a  join dir_domains b on a.domain_id = b.id join vbcp_pbx_account c on a.domain_id = c.domain_id 
				LEFT join UR_ECom_User_Extension_Dtl e on e.Company_id = c.company_id and a.extension = e.Extension_Number 
				where CONCAT(CAST(a.extension as CHAR(30)),'@',domain_name) = Vm_username and IFNULL(pin,'') = Vm_User_pin and a.status = 0;
		
		select Is_pin_valid;			

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ur_voice_mail_archive_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ur_voice_mail_archive_details`(
Vm_uuid varchar(255))
begin

	declare errcode int default -1;
    declare errmsg varchar(55) default 'update error';
    declare updated int default 0;
	
		if exists (select 1 from ur_voice_mail_details a where a.Vm_uuid = Vm_uuid limit 1)
        then
			update ur_voice_mail_details a set a.Archived_flag = 1,updated_date = now()
            where a.Vm_uuid = Vm_uuid;
            
            if found_rows()>0
            then
				set errcode = 0;
                set errmsg = 'updated';
				set updated = 1;	
             end if;
             
        end if;
        
        select errcode as errcode,errmsg as errmsg,updated as updated;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ur_voice_mail_create_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ur_voice_mail_create_details`(
vm_user_id  int,
Vm_uuid    varchar(255),      
vms_server_id  varchar(255),  
domain_id      int,           
vbox_number varchar(255),     
cid_name     varchar(255),    
cid_number   varchar(255),    
vmail_server_url varchar(255),
file_path      varchar(255),  
NFSPath      varchar(255),    
message_len  varchar(255),    
wav_duration   varchar(255),  
ReadFlag      varchar(255),   
Archived_flag   varchar(255), 
deleted_flag    varchar(255), 
Forwarded_by    varchar(255), 
mp3_filepath varchar(255))
begin 

	declare errcode int default -1;
	declare errmsg varchar(255) default 'failure';
    declare is_voicemail_created int default 0;
    
	if not exists (select 1 from ur_voice_mail_details a where a.Vm_uuid = Vm_uuid limit 1)
	then
		insert into ur_voice_mail_details(vm_user_id,Vm_uuid,vms_server_id,domain_id,vbox_number,cid_name,cid_number,vmail_server_url,file_path,NFSPath,message_len,wav_duration,ReadFlag,Archived_flag,deleted_flag,Forwarded_by,created_date,mp3_filepath)
					values (vm_user_id,Vm_uuid,vms_server_id,domain_id,vbox_number,cid_name,cid_number,vmail_server_url,file_path,NFSPath,message_len,wav_duration,ReadFlag,Archived_flag,deleted_flag,Forwarded_by,created_date,mp3_filepath);
                 
     if row_count() >0
     then 
		set errcode = 0;
        set errmsg = 'success : inserted';
        set is_voicemail_created = 1;
     end if;   
	
    end if;      
    
    select errcode as errcode,errmsg as errmsg,is_voicemail_created as is_voicemail_created;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ur_voice_mail_delete_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ur_voice_mail_delete_details`(
Vm_uuid varchar(255))
begin

	declare errcode int default -1;
    declare errmsg varchar(55) default 'update error';
    declare updated int default 0;
	
		if exists (select 1 from ur_voice_mail_details a where a.Vm_uuid = Vm_uuid limit 1)
        then
			update ur_voice_mail_details a set a.deleted_flag = 1,deleted_date = now(),updated_date = now()
            where a.Vm_uuid = Vm_uuid;
            
            if found_rows()>0
            then
				set errcode = 0;
                set errmsg = 'updated';
				set updated = 1;	
             end if;
             
        end if;
        
        select errcode as errcode,errmsg as errmsg,updated as updated;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ur_voice_mail_get_del_arch_flag_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ur_voice_mail_get_del_arch_flag_details`(
Vm_username varchar(255))
begin 

	select * from ur_voice_mail_details a join dir_domains b on a.domain_id = b.id
    where CONCAT(CAST(a.vbox_number as CHAR(30)),'@',b.domain_name) = Vm_username and a.Archived_flag = 1 and a.deleted_flag = 0;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ur_voice_mail_get_readflag_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ur_voice_mail_get_readflag_details`(
Vm_username varchar(255))
begin 

	select * from  ur_voice_mail_details a join dir_domains b on a.domain_id = b.id
    where CONCAT(CAST(a.vbox_number as CHAR(30)),'@',b.domain_name) = Vm_username and ifnull(a.ReadFlag,0) = 0;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ur_voice_mail_get_saved_xml_list` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ur_voice_mail_get_saved_xml_list`(
 Vm_username varchar(50)
 )
Begin
 
 	declare v_cnt int;
     declare v_tcnt int;
     declare v_dayname text; 
     declare v_month text;
     declare v_day text;
     declare v_minute text;
     declare v_hour text;
     declare v_Vm_uuid text;
     declare v_NFSPath text;
     declare v_cid_number text;
     declare v_vbox_number text;
     
     drop temporary table if exists tt_get_vm_details_list_new;
     create temporary table tt_get_vm_details_list_new
     (
 		id int auto_increment primary key,
 		v_dayname text, 
 		v_month text,
 		v_day text,
 		v_minute text,
 		v_hour text,
 		v_Vm_uuid text,
 		v_NFSPath text,
 		v_cid_number text,
 		v_vbox_number text
     );
     
 	drop temporary table if exists tt_get_vm_multixml_new;
     create temporary table tt_get_vm_multixml_new
     (
 		id int auto_increment primary key,
 		multixml text
     );
     
     
     
 		insert into tt_get_vm_details_list_new(v_dayname, v_month,v_day,v_minute,v_hour,v_Vm_uuid,v_NFSPath,v_cid_number,v_vbox_number)
 		select dayname(a.created_Date),monthname(a.created_Date),day(a.created_Date),minute(a.created_Date),hour(a.created_Date),a.Vm_uuid,a.NFSPath,a.cid_number,a.vbox_number
 		from ur_voice_mail_details a join dir_domains b on a.domain_id = b.id  where CONCAT(CAST(a.vbox_number as CHAR(30)),'@',b.domain_name) = Vm_username and Archived_flag = 1 and deleted_flag=0 order by created_date desc;
     
 		set v_cnt = 0;
         set v_tcnt = 0;
 
 		select count(*) into v_tcnt from  ur_voice_mail_details a join dir_domains b on a.domain_id = b.id where CONCAT(CAST(a.vbox_number as CHAR(30)),'@',b.domain_name) = Vm_username and Archived_flag = 1 and deleted_flag=0 order by created_date desc;
         
 		if v_tcnt = 0 then         
 			select CONCAT(
 			'<?xml version=''1.0''?>
 			<ivrxml roottask=''saved_messages''>
 			<action name=''saved_messages'' method=''playandnextaction'' nextaction=''no_more_messages''>
 			<play src=''/root/wav_files/sounds/vectone/vms/you_have.wav''/>
 			<play src=''/root/wav_files/sounds/vectone/vms/0.wav''/>
 			<play src=''/root/wav_files/sounds/vectone/vms/save_messages.wav''/>
 			</action>') as saved_vmail_list;
 		End if;
         
         if v_tcnt = 1 then        
 
 			select	a.v_dayname,a.v_month,a.v_day,a.v_minute,a.v_hour,a.v_Vm_uuid,a.v_NFSPath,a.v_cid_number,a.v_vbox_number
 			into v_dayname,v_month,v_day,v_minute,v_hour,v_Vm_uuid,v_NFSPath,v_cid_number,v_vbox_number
             from tt_get_vm_details_list_new a ;
             
             set @cidnum1:= SUBSTRING(v_cid_number,1,1);
 			set @cidnum2:= SUBSTRING(v_cid_number,2,1);
 			set @cidnum3:= SUBSTRING(v_cid_number,3,1);
         
 
 		select CONCAT('<?xml version=''1.0''?>
 				<ivrxml roottask=''saved_messages''>
 				<action name=''saved_messages'' method=''playandnextaction'' nextaction=''saved_vms_header_0''>		
 					<play src=''/root/wav_files/sounds/vectone/vms/you_have.wav''/>
 					<play src=''/root/wav_files/sounds/vectone/vms/1.wav''/>
 					<play src=''/root/wav_files/sounds/vectone/vms/save_messages.wav''/>
 				</action>
 				<action name=''saved_vms_header_0'' method=''playandnextaction'' nextaction=''saved_vms_voice_0''>
 					<play src=''/root/wav_files/sounds/vectone/vms/message_from.wav''/> 
 					<play src=''/root/wav_files/sounds/vectone/vms/',@cidnum1,'.wav''/> 
 					<play src=''/root/wav_files/sounds/vectone/vms/',@cidnum2,'.wav''/> 
 					<play src=''/root/wav_files/sounds/vectone/vms/',@cidnum3,'.wav''/> 
 					<play src=''/root/wav_files/sounds/vectone/vms/received_on.wav''/> 
 					<play src=''/root/wav_files/sounds/vectone/vms/',v_dayname,'.wav''/> 
 					<play src=''/root/wav_files/sounds/vectone/vms/',v_day,'.wav''/> 
 					<play src=''/root/wav_files/sounds/vectone/vms/',v_month,'.wav''/> 
 					<play src=''/root/wav_files/sounds/vectone/vms/',v_hour,'.wav''/> 
 					<play src=''/root/wav_files/sounds/vectone/vms/',v_minute,'.wav''/> 
 					<play src=''/root/wav_files/sounds/vectone/vms/hours.wav''/> 
 				</action>
 				<action name=''saved_vms_voice_0'' method=''playandnextaction''  params=''',v_Vm_uuid,''' nextaction=''saved_vms_voice_read_http_0''> 
 					<play src=''',v_NFSPath,'''/> 
 				</action>
 				<action name=''saved_vms_voice_read_http_0'' method=''posthttp'' params=''',v_Vm_uuid,'''> 
 					<input type=''httppost'' url=''http://qaursip-api.worktual.co.uk/urvms/v1/voicemail/read'' nextaction=''saved_vms_voice_option_0''/>
 				</action>
 				<action name=''saved_vms_voice_option_0'' nextaction=''no_more_messages'' method=''playandwaitinput''> 
 					<input dtmf=''yes'' dtmfdigits=''1'' interdigittimeout=''5'' validation=''self'' retrycount=''1'' errorexitaction=''no_more_messages''/>
 					<play  src=''/root/wav_files/sounds/vectone/vms/vmail_option.wav'' dtmf=''yes''/>
 				<switch>
 					<case id=''1'' nextaction=''saved_vms_voice_0''/> 
 					<case id=''2'' nextaction=''savemessage''/>
 					<case id=''3'' nextaction=''deletemessage''/>
 					<case id=''4'' nextaction=''newmessage_reachcaller_0''/> 
 					<case id=''5'' nextaction=''no_more_messages''/>
 					<case id=''0'' nextaction=''vmail_menu''/>
 				</switch>
 				<error_invalid_input> 
 					<play src=''/root/wav_files/sounds/vectone/vms/invalidoption.wav''/> 
 				</error_invalid_input>
 				<error_no_input> 
 					<play src=''/root/wav_files/sounds/vectone/vms/no_input.wav''/> </error_no_input>
 				</action>
 				<action name=''newmessage_reachcaller_0'' method=''playandnextaction'' nextaction=''dial_to_extension_0''>
 					<play src=''/root/wav_files/sounds/vectone/vms/your_call_has_been_transferred.wav''/>
 				</action>
 				<action name=''dial_to_extension_0'' method=''calltransfer''>
 					<call fromnumber=''',v_vbox_number,'''
 					tonumber='''' referby=''ivrserrver.UR.mundio.com'' 
 					referto=''',v_cid_number,'''/> 
 				</action>
 				</ivrxml>') as saved_vmail_list;
 		End if;
 
 	if v_tcnt > 1 then
         
 				set @A:= CONCAT('<?xml version=''1.0''?>
 				<ivrxml roottask=''saved_messages''>
 				<action name=''saved_messages'' method=''playandnextaction'' nextaction=''saved_vms_header_0''>		
 					<play src=''/root/wav_files/sounds/vectone/vms/you_have.wav''/>
 					<play src=''/root/wav_files/sounds/vectone/vms/',v_cnt,'.wav''/>
 					<play src=''/root/wav_files/sounds/vectone/vms/save_messages.wav''/>
 				</action>');
                 
                 insert into tt_get_vm_multixml_new(multixml) values(@A);   
 
 				while v_cnt< v_tcnt do
                     
 					select	a.v_dayname,a.v_month,a.v_day,a.v_minute,a.v_hour,a.v_Vm_uuid,a.v_NFSPath,a.v_cid_number,a.v_vbox_number
 					into v_dayname,v_month,v_day,v_minute,v_hour,v_Vm_uuid,v_NFSPath,v_cid_number,v_vbox_number
 					from tt_get_vm_details_list_new a where a.id = v_cnt+1;
             
 					set @cidnum1:= SUBSTRING(v_cid_number,1,1);
 					set @cidnum2:= SUBSTRING(v_cid_number,2,1);
 					set @cidnum3:= SUBSTRING(v_cid_number,3,1);
                     
                     
 					set @B:= CONCAT('<action name=''saved_vms_header_',v_cnt,''' method=''playandnextaction'' nextaction=''saved_vms_voice_',v_cnt,'''>
 								<play src=''/root/wav_files/sounds/vectone/vms/message_from.wav''/> 
 								<play src=''/root/wav_files/sounds/vectone/vms/',@cidnum1,'.wav''/> 
 								<play src=''/root/wav_files/sounds/vectone/vms/',@cidnum2,'.wav''/> 
 								<play src=''/root/wav_files/sounds/vectone/vms/',@cidnum3,'.wav''/> 
 								<play src=''/root/wav_files/sounds/vectone/vms/received_on.wav''/> 
 								<play src=''/root/wav_files/sounds/vectone/vms/',v_dayname,'.wav''/> 
 								<play src=''/root/wav_files/sounds/vectone/vms/',v_day,'.wav''/> 
 								<play src=''/root/wav_files/sounds/vectone/vms/',v_month,'.wav''/> 
 								<play src=''/root/wav_files/sounds/vectone/vms/',v_hour,'.wav''/> 
 								<play src=''/root/wav_files/sounds/vectone/vms/',v_minute,'.wav''/> 
 								<play src=''/root/wav_files/sounds/vectone/vms/hours.wav''/> 
 							</action>
 							<action name=''saved_vms_voice_',v_cnt,''' method=''playandnextaction''  params=''',v_Vm_uuid,''' nextaction=''saved_vms_voice_read_http_',v_cnt,'''> 
 								<play src=''',v_NFSPath,'''/> 
 							</action>
 							<action name=''saved_vms_voice_read_http_',v_cnt,''' method=''posthttp'' params=''',v_Vm_uuid,'''> 
 								<input type=''httppost'' url=''http://qaursip-api.worktual.co.uk/urvms/v1/voicemail/read'' nextaction=''saved_vms_voice_option_',v_cnt,'''/>
 							</action>
 							<action name=''saved_vms_voice_option_',v_cnt,''' nextaction=''no_more_messages'' method=''playandwaitinput''> 
 								<input dtmf=''yes'' dtmfdigits=''1'' interdigittimeout=''5'' validation=''self'' retrycount=''1'' errorexitaction=''no_more_messages''/>
 								<play  src=''/root/wav_files/sounds/vectone/vms/vmail_option.wav'' dtmf=''yes''/>
 							<switch>
 								<case id=''1'' nextaction=''saved_vms_voice_',v_cnt,'''/> 
 								<case id=''2'' nextaction=''savemessage''/>
 								<case id=''3'' nextaction=''deletemessage''/>
 								<case id=''4'' nextaction=''newmessage_reachcaller_',v_cnt,'''/> 
 								<case id=''5'' nextaction=''no_more_messages''/>
 								<case id=''0'' nextaction=''vmail_menu''/>
 							</switch>
 							<error_invalid_input> 
 								<play src=''/root/wav_files/sounds/vectone/vms/invalidoption.wav''/> 
 							</error_invalid_input>
 							<error_no_input> 
 								<play src=''/root/wav_files/sounds/vectone/vms/no_input.wav''/> </error_no_input>
 							</action>
 							<action name=''newmessage_reachcaller_',v_cnt,''' method=''playandnextaction'' nextaction=''dial_to_extension_',v_cnt,'''>
 								<play src=''/root/wav_files/sounds/vectone/vms/your_call_has_been_transferred.wav''/>
 							</action>
 							<action name=''dial_to_extension_',v_cnt,''' method=''calltransfer''>
 								<call fromnumber=''',v_vbox_number,''' tonumber='''' referby=''ivrserrver.UR.mundio.com'' referto=''',v_cid_number,'''/> 
 							</action>');
             
 					set v_cnt = v_cnt + 1;
                     
                    
                    update tt_get_vm_multixml_new set multixml = concat(multixml,@B);
                     
                 End while;
 					update tt_get_vm_multixml_new set multixml = concat(multixml,'</ivrxml>');
                     
                    select multixml as saved_vmail_list from tt_get_vm_multixml_new;
         End if;
 
 
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ur_voice_mail_get_xml_list` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ur_voice_mail_get_xml_list`(
 Vm_username varchar(50)
 )
Begin
 
 	declare v_cnt int;
     declare v_tcnt int;
     declare v_dayname text; 
     declare v_month text;
     declare v_day text;
     declare v_minute text;
     declare v_hour text;
     declare v_Vm_uuid text;
     declare v_NFSPath text;
     declare v_cid_number text;
     declare v_vbox_number text;
     
     drop temporary table if exists tt_get_vm_details_list;
     create temporary table tt_get_vm_details_list
     (
 		id int auto_increment primary key,
 		v_dayname text, 
 		v_month text,
 		v_day text,
 		v_minute text,
 		v_hour text,
 		v_Vm_uuid text,
 		v_NFSPath text,
 		v_cid_number text,
 		v_vbox_number text
     );
     
 	drop temporary table if exists tt_get_vm_multixml;
     create temporary table tt_get_vm_multixml
     (
 		id int auto_increment primary key,
 		multixml text
     );
     
     
     
 		insert into tt_get_vm_details_list(v_dayname, v_month,v_day,v_minute,v_hour,v_Vm_uuid,v_NFSPath,v_cid_number,v_vbox_number)
 		select dayname(a.created_Date),monthname(a.created_Date),day(a.created_Date),minute(a.created_Date),hour(a.created_Date),a.Vm_uuid,a.NFSPath,a.cid_number,a.vbox_number
 		from ur_voice_mail_details a join dir_domains b on a.domain_id = b.id  where CONCAT(CAST(a.vbox_number as CHAR(30)),'@',b.domain_name) = Vm_username and ReadFlag = 0 order by created_date desc;
     
 		set v_cnt = 0;
         set v_tcnt = 0;
 
 		select count(*) into v_tcnt from  ur_voice_mail_details a join dir_domains b on a.domain_id = b.id where CONCAT(CAST(a.vbox_number as CHAR(30)),'@',b.domain_name) = Vm_username and ReadFlag = 0 order by created_date desc;
         
 		if v_tcnt = 0 then         
 			select CONCAT(
 			'<?xml version=''1.0''?>
 			<ivrxml roottask=''new_messages''>
 			<action name=''new_messages'' method=''playandnextaction'' nextaction=''no_more_messages''>
 			<play src=''/root/wav_files/sounds/vectone/vms/you_have.wav''/>
 			<play src=''/root/wav_files/sounds/vectone/vms/0.wav''/>
 			<play src=''/root/wav_files/sounds/vectone/vms/save_messages.wav''/>
 			</action>') as new_vmail_list;
 		End if;
         
         if v_tcnt = 1 then        
 
 			select	a.v_dayname,a.v_month,a.v_day,a.v_minute,a.v_hour,a.v_Vm_uuid,a.v_NFSPath,a.v_cid_number,a.v_vbox_number
 			into v_dayname,v_month,v_day,v_minute,v_hour,v_Vm_uuid,v_NFSPath,v_cid_number,v_vbox_number
             from tt_get_vm_details_list a ;
             
             set @cidnum1:= SUBSTRING(v_cid_number,1,1);
 			set @cidnum2:= SUBSTRING(v_cid_number,2,1);
 			set @cidnum3:= SUBSTRING(v_cid_number,3,1);
         
 
 		select CONCAT('<?xml version=''1.0''?>
 				<ivrxml roottask=''new_messages''>
 				<action name=''new_messages'' method=''playandnextaction'' nextaction=''new_vms_header_0''>		
 					<play src=''/root/wav_files/sounds/vectone/vms/you_have.wav''/>
 					<play src=''/root/wav_files/sounds/vectone/vms/1.wav''/>
 					<play src=''/root/wav_files/sounds/vectone/vms/save_messages.wav''/>
 				</action>
 				<action name=''new_vms_header_0'' method=''playandnextaction'' nextaction=''new_vms_voice_0''>
 					<play src=''/root/wav_files/sounds/vectone/vms/message_from.wav''/> 
 					<play src=''/root/wav_files/sounds/vectone/vms/',@cidnum1,'.wav''/> 
 					<play src=''/root/wav_files/sounds/vectone/vms/',@cidnum2,'.wav''/> 
 					<play src=''/root/wav_files/sounds/vectone/vms/',@cidnum3,'.wav''/> 
 					<play src=''/root/wav_files/sounds/vectone/vms/received_on.wav''/> 
 					<play src=''/root/wav_files/sounds/vectone/vms/',v_dayname,'.wav''/> 
 					<play src=''/root/wav_files/sounds/vectone/vms/',v_day,'.wav''/> 
 					<play src=''/root/wav_files/sounds/vectone/vms/',v_month,'.wav''/> 
 					<play src=''/root/wav_files/sounds/vectone/vms/',v_hour,'.wav''/> 
 					<play src=''/root/wav_files/sounds/vectone/vms/',v_minute,'.wav''/> 
 					<play src=''/root/wav_files/sounds/vectone/vms/hours.wav''/> 
 				</action>
 				<action name=''new_vms_voice_0'' method=''playandnextaction''  params=''',v_Vm_uuid,''' nextaction=''new_vms_voice_read_http_0''> 
 					<play src=''',v_NFSPath,'''/> 
 				</action>
 				<action name=''new_vms_voice_read_http_0'' method=''posthttp'' params=''',v_Vm_uuid,'''> 
 					<input type=''httppost'' url=''http://qaursip-api.worktual.co.uk/urvms/v1/voicemail/read'' nextaction=''new_vms_voice_option_0''/>
 				</action>
 				<action name=''new_vms_voice_option_0'' nextaction=''no_more_messages'' method=''playandwaitinput''> 
 					<input dtmf=''yes'' dtmfdigits=''1'' interdigittimeout=''5'' validation=''self'' retrycount=''1'' errorexitaction=''no_more_messages''/>
 					<play  src=''/root/wav_files/sounds/vectone/vms/vmail_option.wav'' dtmf=''yes''/>
 				<switch>
 					<case id=''1'' nextaction=''new_vms_voice_0''/> 
 					<case id=''2'' nextaction=''savemessage''/>
 					<case id=''3'' nextaction=''deletemessage''/>
 					<case id=''4'' nextaction=''newmessage_reachcaller_0''/> 
 					<case id=''5'' nextaction=''no_more_messages''/>
 					<case id=''0'' nextaction=''vmail_menu''/>
 				</switch>
 				<error_invalid_input> 
 					<play src=''/root/wav_files/sounds/vectone/vms/invalidoption.wav''/> 
 				</error_invalid_input>
 				<error_no_input> 
 					<play src=''/root/wav_files/sounds/vectone/vms/no_input.wav''/> </error_no_input>
 				</action>
 				<action name=''newmessage_reachcaller_0'' method=''playandnextaction'' nextaction=''dial_to_extension_0''>
 					<play src=''/root/wav_files/sounds/vectone/vms/your_call_has_been_transferred.wav''/>
 				</action>
 				<action name=''dial_to_extension_0'' method=''calltransfer''>
 					<call fromnumber=''',v_vbox_number,'''
 					tonumber='''' referby=''ivrserrver.UR.mundio.com'' 
 					referto=''',v_cid_number,'''/> 
 				</action>
 				</ivrxml>') as new_vmail_list;
 		End if;
 
 	if v_tcnt > 1 then
         
 				set @A:= CONCAT('<?xml version=''1.0''?>
 				<ivrxml roottask=''new_messages''>
 				<action name=''new_messages'' method=''playandnextaction'' nextaction=''new_vms_header_0''>		
 					<play src=''/root/wav_files/sounds/vectone/vms/you_have.wav''/>
 					<play src=''/root/wav_files/sounds/vectone/vms/',v_cnt,'.wav''/>
 					<play src=''/root/wav_files/sounds/vectone/vms/save_messages.wav''/>
 				</action>');
                 
                 insert into tt_get_vm_multixml(multixml) values(@A);   
 
 				while v_cnt< v_tcnt do
                     
 					select	a.v_dayname,a.v_month,a.v_day,a.v_minute,a.v_hour,a.v_Vm_uuid,a.v_NFSPath,a.v_cid_number,a.v_vbox_number
 					into v_dayname,v_month,v_day,v_minute,v_hour,v_Vm_uuid,v_NFSPath,v_cid_number,v_vbox_number
 					from tt_get_vm_details_list a where a.id = v_cnt+1;
             
 					set @cidnum1:= SUBSTRING(v_cid_number,1,1);
 					set @cidnum2:= SUBSTRING(v_cid_number,2,1);
 					set @cidnum3:= SUBSTRING(v_cid_number,3,1);
                     
                     
 					set @B:= CONCAT('<action name=''new_vms_header_',v_cnt,''' method=''playandnextaction'' nextaction=''new_vms_voice_',v_cnt,'''>
 								<play src=''/root/wav_files/sounds/vectone/vms/message_from.wav''/> 
 								<play src=''/root/wav_files/sounds/vectone/vms/',@cidnum1,'.wav''/> 
 								<play src=''/root/wav_files/sounds/vectone/vms/',@cidnum2,'.wav''/> 
 								<play src=''/root/wav_files/sounds/vectone/vms/',@cidnum3,'.wav''/> 
 								<play src=''/root/wav_files/sounds/vectone/vms/received_on.wav''/> 
 								<play src=''/root/wav_files/sounds/vectone/vms/',v_dayname,'.wav''/> 
 								<play src=''/root/wav_files/sounds/vectone/vms/',v_day,'.wav''/> 
 								<play src=''/root/wav_files/sounds/vectone/vms/',v_month,'.wav''/> 
 								<play src=''/root/wav_files/sounds/vectone/vms/',v_hour,'.wav''/> 
 								<play src=''/root/wav_files/sounds/vectone/vms/',v_minute,'.wav''/> 
 								<play src=''/root/wav_files/sounds/vectone/vms/hours.wav''/> 
 							</action>
 							<action name=''new_vms_voice_',v_cnt,''' method=''playandnextaction''  params=''',v_Vm_uuid,''' nextaction=''new_vms_voice_read_http_',v_cnt,'''> 
 								<play src=''',v_NFSPath,'''/> 
 							</action>
 							<action name=''new_vms_voice_read_http_',v_cnt,''' method=''posthttp'' params=''',v_Vm_uuid,'''> 
 								<input type=''httppost'' url=''http://qaursip-api.worktual.co.uk/urvms/v1/voicemail/read'' nextaction=''new_vms_voice_option_',v_cnt,'''/>
 							</action>
 							<action name=''new_vms_voice_option_',v_cnt,''' nextaction=''no_more_messages'' method=''playandwaitinput''> 
 								<input dtmf=''yes'' dtmfdigits=''1'' interdigittimeout=''5'' validation=''self'' retrycount=''1'' errorexitaction=''no_more_messages''/>
 								<play  src=''/root/wav_files/sounds/vectone/vms/vmail_option.wav'' dtmf=''yes''/>
 							<switch>
 								<case id=''1'' nextaction=''new_vms_voice_',v_cnt,'''/> 
 								<case id=''2'' nextaction=''savemessage''/>
 								<case id=''3'' nextaction=''deletemessage''/>
 								<case id=''4'' nextaction=''newmessage_reachcaller_',v_cnt,'''/> 
 								<case id=''5'' nextaction=''no_more_messages''/>
 								<case id=''0'' nextaction=''vmail_menu''/>
 							</switch>
 							<error_invalid_input> 
 								<play src=''/root/wav_files/sounds/vectone/vms/invalidoption.wav''/> 
 							</error_invalid_input>
 							<error_no_input> 
 								<play src=''/root/wav_files/sounds/vectone/vms/no_input.wav''/> </error_no_input>
 							</action>
 							<action name=''newmessage_reachcaller_',v_cnt,''' method=''playandnextaction'' nextaction=''dial_to_extension_',v_cnt,'''>
 								<play src=''/root/wav_files/sounds/vectone/vms/your_call_has_been_transferred.wav''/>
 							</action>
 							<action name=''dial_to_extension_',v_cnt,''' method=''calltransfer''>
 								<call fromnumber=''',v_vbox_number,''' tonumber='''' referby=''ivrserrver.UR.mundio.com'' referto=''',v_cid_number,'''/> 
 							</action>');
             
 					set v_cnt = v_cnt + 1;
                     
                    
                    update tt_get_vm_multixml set multixml = concat(multixml,@B);
                     
                 End while;
                    update tt_get_vm_multixml set multixml = concat(multixml,'</ivrxml>');
 
                    select multixml as new_vmail_list from tt_get_vm_multixml;
         End if;
 
 
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ur_voice_mail_update_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ur_voice_mail_update_details`(
Vm_uuid varchar(255))
begin

	declare errcode int default -1;
    declare errmsg varchar(55) default 'update error';
    declare updated int default 0;
	
		if exists (select 1 from ur_voice_mail_details a where a.Vm_uuid = Vm_uuid limit 1)
        then
			update ur_voice_mail_details a set a.ReadFlag = 1,updated_date = now()
            where a.Vm_uuid = Vm_uuid;
            
            if found_rows()>0
            then
				set errcode = 0;
                set errmsg = 'updated';
				set updated = 1;	
             end if;
             
        end if;
        
        select errcode as errcode,errmsg as errmsg,updated as updated;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ur_web_Multi_ivr_feature_get_ivrcount` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ur_web_Multi_ivr_feature_get_ivrcount`(company_id INT)
BEGIN
     
        DECLARE v_errcode INT; 
        DECLARE v_errmsg VARCHAR(160);
   
        DECLARE v_total_count INT; 
        DECLARE v_username VARCHAR(250);
        DECLARE v_domain_name VARCHAR(250);
        DECLARE v_plan_id INT;
     	
        DECLARE v_is_multi_ivr INT;
         declare default_int_val_0 int; 
         set default_int_val_0 = 0;
     	
        set v_errcode = -1;
        set v_errmsg = '';
     	
        set v_is_multi_ivr = 0;
     	
        SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        select   plan_id, b.email, d.domain_name INTO v_plan_id,v_username,v_domain_name from  ur_company_plan a
        join  vbcp_company b on a.company_id = b.company_id
        join  vbcp_pbx_account c on b.company_id = c.company_id
        join  dir_domains d on c.domain_id = d.id where b.company_id = company_id limit 1;
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   
        SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        
      
        
 		select b.value2, 1 into v_total_count,v_is_multi_ivr 
         from wtms.wtms_copy_of_tier_management_temp a 
 		join wtms.wtms_tier_feature_mapping_xml b on a.fk_tier_id = b.tier_id
 		join wtms.wtms_feature_info c on c.feature_id = b.featureid
 		where a.fk_tier_id = v_plan_id and b.value2 REGEXP('^[0-9,]+$')=1 and c.feature_name = 'Multi level IVR' and b.value1 = 'Yes';
        
        
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
     	
        if IFNULL(v_total_count,0) > 0 then
     	
           set v_errcode = 0;
           set v_errmsg = 'Multi ivr with plan feature found.';
        end if;
     	
        select v_errcode as errcode,v_errmsg as errmsg,IFNULL(v_total_count,default_int_val_0) as plan_multi_ivr_count,
     IFNULL(v_username,'') as username,IFNULL(v_domain_name,'') as domain_name,
     IFNULL(v_is_multi_ivr,default_int_val_0) as is_multi_ivr;
     	
     END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `vm_user_domain_greeting_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `vm_user_domain_greeting_details`(
Vm_username varchar(255))
begin

declare Enabled_vms_transcript varchar(55) default '';
declare Language_pref_id varchar(55) default '';

		select a.id vm_user_id,
       		   CONCAT(CAST(a.extension as CHAR(30)),'@',domain_name) as Vm_username,
       		   IFNULL(pin,'') as Vm_User_pin,
               b.id as domain_id,
               IFNULL(a.greeting_path,'') as User_vmail_greeings_voice_url,
               e.Email enabled_vms_email,               
               IFNULL(Enabled_vms_transcript,'') as Enabled_vms_transcript,       		  
               IFNULL(Language_pref_id,'') as Language_pref_id       		  
       	from vm_data_transfer_request a 
       	join dir_domains b on a.domain_id = b.id
       	join vbcp_pbx_account c on a.domain_id = c.domain_id
       	LEFT join UR_ECom_User_Extension_Dtl e on e.Company_id = c.company_id
       	and a.extension = e.Extension_Number and CONCAT(CAST(a.extension as CHAR(30)),'@',domain_name) = Vm_username
       	where a.status = 0;
    
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Worktual_get_call_recording_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `Worktual_get_call_recording_details`(
call_uid varchar(250)
)
begin

select 
a.call_uid ,
a.call_callid ,
a.extension ,
a.from_number  ,
a.to_number  ,
a.call_direction ,
a.call_type ,
a.recording_duration ,
a.recording_file_path ,
a.file_size ,
a.q_extn ,
a.domain_name,
a.domain_id 
from Worktual_call_recording_details a where a.call_uid=call_uid;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Worktual_insert_call_recording_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `Worktual_insert_call_recording_details`(
call_uid varchar(250),
call_callid varchar(250),
extension varchar(25),
from_number  varchar(25),
to_number  varchar(25),
domain_name varchar(155),
domain_id int,
q_extn varchar(25),
call_direction varchar(25),
call_type varchar(25),
recording_duration int,
file_size int,
recording_file_path varchar(125)
)
begin

declare errcode int;
declare errmsg varchar(55);

set  errcode=-1;
set errmsg='failure';

insert into Worktual_call_recording_details
 (
call_uid ,
call_callid ,
extension ,
from_number  ,
to_number  ,
call_direction ,
call_type ,
recording_duration ,
recording_file_path ,
file_size ,
q_extn ,
domain_name,
domain_id
)
values (call_uid ,
call_callid ,
extension ,
from_number  ,
to_number  ,
call_direction ,
call_type ,
recording_duration ,
recording_file_path ,
file_size ,
q_extn ,
domain_name,
domain_id);

if row_count()>0
then 
 set errcode=0;
 set errmsg='inserted successfully';
end if;

select errcode,errmsg;


end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Worktual_mangodb_call_history_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `Worktual_mangodb_call_history_details`(
    company_id int,
    domain_id int,
    call_type varchar(35),
    call_from datetime,
    call_to datetime,
     ext varchar(15)
    )
begin
    
    
    
    if exists (select * from vbcp_pbx_account a where a.domain_id=domain_id and a.company_id=company_id limit 1)
    then
      
      select a.callDateTime,a.callDuration,a.ext,a.calledNo,a.callingNo,a.attendedBy,a.domainId,a.domainName,a.callType,a.created_date from ur_myacc_cdr_data_mongodb_details a where a.domainid=domain_id and 
      (a.calltype=call_type or calltype='') and cast(a.calldatetime as date) between cast(call_from as date) and cast(call_to as date) and (a.ext=ext or ext='');
    
    end if;
    
    
    end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_video_cancel_meeting` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_video_cancel_meeting`(
   `uuid` text
 )
begin
 
 declare errcode int;
 declare errmsg varchar(155);
 
 set errcode=-1;
 set errmsg='failure to cancel the meeting';
 
   update worktual_video_meeting_master_dtl a set a.is_cancelled='true'
   where a.uuid=uuid;
   
   if row_count()>0 then
   set errcode=0;
   set errmsg='Succes to cancel the meeting';
   end if;
 
 select errcode ,errmsg;
 
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_video_create_meeting` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_video_create_meeting`(
    uuid text,
    title varchar(250),
    meeting_id varchar(250),
    password varchar(100),
    personal_meeting_id varchar(100),
    msgid varchar(100),
    server_host varchar(100),
    hostName varchar(100),
    sip_id varchar(20),
    invite_url varchar(100),
    onlyContacts varchar(10),
    restrictScreenShare varchar(10),
    requireAuthentication varchar(10),
    authenticationJoin varchar(30),
    meetings_type varchar(20),
    description varchar(250),
    start_timestamp bigint,
    end_timestamp bigint,
    lastModifiedDate bigint,
    duration_minutes int,
    timezone varchar(250),
    joining_option_type varchar(30),
    calender_type varchar(20),
    recurrence varchar(20),
    rrule varchar(30),
    is_host_myaudio varchar(10),
    is_host_myvideo varchar(10),
    is_participant_video varchar(10),
    is_use_personal_meeting_id varchar(10),
    is_participant_waiting_room varchar(10),
    is_cancelled varchar(10),
    is_attended varchar(10),
    is_record_meeting varchar(10),
    is_alternate_host varchar(10),
    is_participant_join_bef_host varchar(10),
    is_participant_invite_guest varchar(10),
    is_participant_mute_entry varchar(10),
    is_without_host_continue varchar(10),
    is_custom_password varchar(10),
    speakingLanguage varchar(30),
    save_template varchar(10),
    status varchar(30),
    participants json,
    chatSetting json ,
    dial_in_countries json,
    ReadFlag json,
    files json,
    alternate_host json,
    is_deleted int,
    template_id varchar(255),
    HostAddress varchar(125)
    )
Begin
    
    	declare id int;
        declare errcode int default -1;
        declare errmsg varchar(50) default 'Failure';
        
    sp_exit:BEGIN
    
    			if not exists(select 1 from worktual_video_meeting_master_dtl a where a.uuid = uuid) then
    
    			insert into worktual_video_meeting_master_dtl(uuid,participants,title,meeting_id,password,personal_meeting_id,msgid,server_host,hostName,sip_id,invite_url,onlyContacts,restrictScreenShare,
    				requireAuthentication,authenticationJoin,chatSetting,meetings_type,description,start_timestamp,end_timestamp,lastModifiedDate,duration_minutes,timezone,joining_option_type,calender_type,recurrence,
    				rrule,is_host_myaudio,is_host_myvideo,is_participant_video,is_use_personal_meeting_id,is_participant_waiting_room,is_cancelled,is_attended,is_record_meeting,is_alternate_host,is_participant_join_bef_host,
    				is_participant_invite_guest,is_participant_mute_entry,is_without_host_continue,is_custom_password,speakingLanguage,dial_in_countries,save_template,status,ReadFlag,files,createdate,modifieddate,alternate_host,is_deleted,template_id,HostAddress)
    			select uuid,participants,title,meeting_id,password,personal_meeting_id,msgid,server_host,hostName,sip_id,invite_url,onlyContacts,restrictScreenShare,
    				requireAuthentication,authenticationJoin,chatSetting,meetings_type,description,start_timestamp,end_timestamp,lastModifiedDate,duration_minutes,timezone,joining_option_type,calender_type,recurrence,
    				rrule,is_host_myaudio,is_host_myvideo,is_participant_video,is_use_personal_meeting_id,is_participant_waiting_room,is_cancelled,is_attended,is_record_meeting,is_alternate_host,is_participant_join_bef_host,
    				is_participant_invite_guest,is_participant_mute_entry,is_without_host_continue,is_custom_password,speakingLanguage,dial_in_countries,save_template,status,ReadFlag,files,current_timestamp,current_timestamp,alternate_host,is_deleted,template_id,HostAddress;
    
    				set id = LAST_INSERT_ID();
    
    				if row_count() > 0 then
    					set errcode = 0;
    					set errmsg = 'Success : Inserted';
                        
                   
    					LEAVE sp_exit;
    				End if;
    			End if;  
    
    
    	END;
    	select errcode as errcode, errmsg as errmsg, meeting_id as meeting_id,uuid as uuid,invite_url as invite_url;
    End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_video_create_template_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_video_create_template_dtl`(
     template_id varchar(500) ,
     title varchar(500) ,
     sip_id varchar(500) ,
     meeting_id varchar(500) ,
     description varchar(500) ,
     start_timestamp bigint ,
     end_timestamp bigint ,
     duration_minutes bigint ,
     timezone varchar(500) ,
     joining_option_type varchar(500) ,
     calender_type varchar(500) ,
     rrule varchar(500) ,
     is_host_myvideo tinyint(1) ,
     is_record_meeting tinyint(1) ,
     is_alternate_host tinyint(1) ,
     is_participant_video tinyint(1) ,
     is_participant_join_bef_host tinyint(1) ,
     is_participant_invite_guest tinyint(1) ,
     is_participant_waiting_room tinyint(1) ,
     is_participant_mute_entry tinyint(1) ,
     is_use_personal_meeting_id tinyint(1) ,
     is_without_host_continue tinyint(1) ,
     isRecurr tinyint(1) ,
     personal_meeting_id varchar(500) ,
     is_custom_password tinyint(1) ,
     is_host_myaudio tinyint(1) ,
     password varchar(500) ,
     dial_in_countries json ,
     participants json ,
     is_cancelled bigint ,
     is_attended bigint ,
     save_template tinyint(1) ,
     hostName varchar(500) ,
     uuid varchar(500) ,
     status varchar(500) ,
     invite_url varchar(500) ,
     speakingLanguage varchar(500) ,
     files json ,
     createdat varchar(500) ,
     updatedat varchar(500) ,
     alternate_host json ,
     HostAddress varchar(125)
  )
begin
       declare errcode int default -1;
        declare errmsg varchar(50) default 'Failure';
  
    sp_exit:BEGIN
    
    if not exists(select * from Worktual_Meeting_Template a where a.template_id = template_id limit 1) 
    then
    insert into Worktual_Meeting_Template
    (
  	template_id  ,
     title  ,
     sip_id  ,
     meeting_id  ,
     description  ,
     start_timestamp  ,
     end_timestamp  ,
     duration_minutes  ,
     timezone  ,
     joining_option_type  ,
     calender_type  ,
     rrule  ,
     is_host_myvideo  ,
     is_record_meeting  ,
     is_alternate_host  ,
     is_participant_video  ,
     is_participant_join_bef_host  ,
     is_participant_invite_guest  ,
     is_participant_waiting_room  ,
     is_participant_mute_entry  ,
     is_use_personal_meeting_id  ,
     is_without_host_continue  ,
     isRecurr  ,
     personal_meeting_id  ,
     is_custom_password  ,
     is_host_myaudio  ,
     password  ,
     dial_in_countries  ,
     participants  ,
     is_cancelled  ,
     is_attended  ,
     save_template  ,
     hostName  ,
     uuid  ,
     status  ,
     invite_url  ,
     speakingLanguage  ,
     files  ,
     createdat  ,
     updatedat  ,
     alternate_host  ,
     HostAddress
    )
    values
    (
       template_id  ,
     title  ,
     sip_id  ,
     meeting_id  ,
     description  ,
     start_timestamp  ,
     end_timestamp  ,
     duration_minutes  ,
     timezone  ,
     joining_option_type  ,
     calender_type  ,
     rrule  ,
     is_host_myvideo  ,
     is_record_meeting  ,
     is_alternate_host  ,
     is_participant_video  ,
     is_participant_join_bef_host  ,
     is_participant_invite_guest  ,
     is_participant_waiting_room  ,
     is_participant_mute_entry  ,
     is_use_personal_meeting_id  ,
     is_without_host_continue  ,
     isRecurr  ,
     personal_meeting_id  ,
     is_custom_password  ,
     is_host_myaudio  ,
     password  ,
     dial_in_countries  ,
     participants  ,
     is_cancelled  ,
     is_attended  ,
     save_template  ,
     hostName  ,
     uuid  ,
     status  ,
     invite_url  ,
     speakingLanguage  ,
     files  ,
     createdat  ,
     updatedat  ,
     alternate_host  ,
     HostAddress
    );
    
    	     if row_count() > 0 then
    					set errcode = 0;
    					set errmsg = 'Success : Inserted';
             end if;
    End if;
    end;
  select errcode as errcode, errmsg as errmsg;
  end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_video_delete_meetings` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_video_delete_meetings`(
 uuid text
)
begin
  declare errcode int;
  declare errmsg varchar(155);
  
  update worktual_video_meeting_master_dtl a set a.is_deleted=1 where a.uuid=uuid;
 

   if row_count()>0 then
   set errcode=0;
   set errmsg='Succes to delete the meeting';
   end if;
 
 select errcode ,errmsg ;
 
 
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_video_delete_meetings_by_uuid` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_video_delete_meetings_by_uuid`(
 uuid text
)
begin
  declare errcode int;
  declare errmsg varchar(155);
  
  update worktual_video_meeting_master_dtl a set a.is_deleted=1 where a.uuid=uuid;
 

   if row_count()>0 then
   set errcode=0;
   set errmsg='Succes to delete the meeting';
   end if;
 
 select errcode ,errmsg ;
 
 
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_video_end_meeting` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_video_end_meeting`(
  uuid text,
  ishost varchar(250),
  alternate_host json
  )
begin
  
  declare errcode int;
  declare errmsg varchar(155); 
  
   set errcode=-1;
   set errmsg='failure to end_meeting';
  
    update worktual_video_meeting_master_dtl a set a.ishost=ishost,a.alternate_host=alternate_host
    where a.uuid=uuid;
    
    
   if row_count()>0 then
   set errcode=0;
   set errmsg='Succes to to end_meeting';
   end if;
 
 select errcode ,errmsg,uuid as uuid ;
 
  
  end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_video_get_Alive_Meetings` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_video_get_Alive_Meetings`(offset INT, limits INT ,searchText VARCHAR(100))
BEGIN


	SET @limit_sp = CONCAT(' LIMIT ', offset , ',', limits,' ;');
    SET @sort_sp = CONCAT(' Order by ', searchText ,' ');
    SET @query = CONCAT( "SELECT * FROM worktual_video_meeting_master_dtl");
      SET @query = CONCAT(@query, @sort_sp);
    SET @query = CONCAT(@query, @limit_sp);
    

    PREPARE stmt FROM @query;
    EXECUTE stmt ;
    DEALLOCATE PREPARE stmt ;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_video_get_bell_notification` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_video_get_bell_notification`(
`from` varchar(255)
 )
begin
 
 select a.`from` ,a.`to` ,a.`message` ,a.`timestamp` ,a.`ReadFlag`  ,a.`type` ,a.`createdat` from worktual_video_bell_notification a
 where a.`from` =`from` ;
 
 
 
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_video_get_bell_notification_filter_by_sip_id` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_video_get_bell_notification_filter_by_sip_id`(
  `sip_id` json,
  `type` int
  )
begin
  
  
  
  select a.`from` ,a.`to` ,a.`message` ,a.`timestamp` ,a.`ReadFlag`  ,a.`type` ,a.`createdat`,a.`bell_id` as _id 
  from worktual_video_bell_notification a 
  where a.`ReadFlag` like  concat('%',`sip_id`,'%')   and (`type`=0 or a.`type`=`type`); 
  
  end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_video_get_by_meetingid_uuid` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_video_get_by_meetingid_uuid`(muID VARCHAR(500))
BEGIN
  	select *
      FROM worktual_video_meeting_master_dtl a where (a.uuid=muID or meeting_id = muID) ;  
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_video_get_chat_setting_by_meeting` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_video_get_chat_setting_by_meeting`(
uuid text 
)
begin
 declare errcode int;
 declare errmsg varchar(250);
 
 select a.chatSetting from worktual_video_meeting_master_dtl a where a.uuid=uuid;
 

   if row_count()>0 then
   set errcode=0;
   set errmsg='Succes to get chat_setting';
   end if;
 
 select errcode,errmsg ;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_video_get_meetings` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_video_get_meetings`(
  `offset` int,
  `limit` int,
  filter text,
  searchText text
  )
Begin
  
  	declare p_Offset bigint;
  	declare p_Limit bigint;
  
  	set p_Offset= ((`offset`-1)*`limit`);
  	set p_Limit= `limit`;
  
  	select *
  	from worktual_video_meeting_master_dtl a
  	where a.title like concat('%',searchText,'%') 
      and a.status like concat('%',filter,'%')  
      or (CASE when FILTER in ('UNATTENED','Upcoming') then a.is_cancelled = 0 or a.is_attended = 0 end) 
      order by a.uuid LIMIT `limit` offset p_Offset;
  
  End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_video_get_meetings_list_timestamp` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_video_get_meetings_list_timestamp`(timestamp bigint)
BEGIN
 	select *
     FROM worktual_video_meeting_master_dtl a where timestamp between start_timestamp and end_timestamp;  
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_video_get_meeting_by_meetingid` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_video_get_meeting_by_meetingid`(meeting_id VARCHAR(100))
BEGIN
 
 	select *
     FROM worktual_video_meeting_master_dtl a where a.meeting_id=meeting_id;  
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_video_get_meeting_list_by_date` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_video_get_meeting_list_by_date`(currentDate VARCHAR(20),sip_id varchar(20) )
BEGIN
  
  	declare v_curr_timestamp bigint;
  	Set v_curr_timestamp:=UNIX_TIMESTAMP(currentDate);
      set v_curr_timestamp=concat(v_curr_timestamp,'000');
  
  	select *
      FROM worktual_video_meeting_master_dtl a where v_curr_timestamp between start_timestamp and end_timestamp and a.sip_id=sip_id;  
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_video_get_meeting_Settings` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_video_get_meeting_Settings`(
sip_id varchar(20)
)
begin

select a.`sip_id` ,
a.`security` ,
a.`schedule` ,
a.`in_meeting_basics`, 
a.`in_meeting_advance`,
a. `createdat`  from worktual_video_meeting_Settings a
where a.sip_id=sip_id;



end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_video_get_meeting_status` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_video_get_meeting_status`(uuid VARCHAR(500))
BEGIN
 	select *
     FROM worktual_video_meeting_master_dtl a where a.uuid = uuid;  
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_video_get_meeting_status_by_time` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_video_get_meeting_status_by_time`(timestamp bigint)
BEGIN
 
 
 	select *
     FROM worktual_video_meeting_master_dtl a where timestamp between start_timestamp and end_timestamp;  
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_video_get_meeting_uuid` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_video_get_meeting_uuid`(uuid VARCHAR(500))
BEGIN
 	select *
     FROM worktual_video_meeting_master_dtl a where a.uuid=uuid;  
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_video_get_ReadFlag_count_bell_notification` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_video_get_ReadFlag_count_bell_notification`(
    `to` json,
    `type` int,
    `timestamp` bigint
    )
begin
    
    select count(1) as ReadFlag_count  
    from worktual_video_bell_notification a 
    where a.`to` like  concat('%',`to`,'%') 
    and a.ReadFlag like concat('%',`to`,'%')  
    and (`type`=0 or a.`type`=`type`)  
    and JSON_EXTRACT (a.ReadFlag,concat('$."',`to`,'"') ) =1 
    and a.timestamp>`timestamp`; 
    
    
    end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_video_get_timezones` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_video_get_timezones`(

)
begin

select a.timezone from worktual_video_meeting_master_dtl a;


end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_video_get_transcript_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_video_get_transcript_details`(
sip_id varchar(20)
)
begin

select a.`uuid`  ,
a.`transcripts` ,
a.`MOM` from worktual_video_meeting_transcript_details a
where a.sip_id=sip_id;



end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_video_get_whiteboard_by_uuid` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_video_get_whiteboard_by_uuid`(
uuid text 
)
begin 
declare errcode int;
declare errmsg varchar(155);

select a.white_board from worktual_video_meeting_master_dtl a where a.uuid=uuid;

 if row_count()>0 then
      set errcode=0;
      set errmsg='Succes to get whiteboard_by_uuid';
      end if;
    
    select errcode ,errmsg ;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_video_host_start_meeting` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_video_host_start_meeting`(
  `uuid` text
 )
begin
 
 select title,sip_id,hostName,a.meeting_id,description,start_timestamp,end_timestamp,lastModifiedDate,duration_minutes,timezone,joining_option_type,calender_type,rrule,is_host_myvideo,is_record_meeting,
      is_alternate_host,is_participant_video,is_participant_join_bef_host,is_participant_invite_guest,is_participant_waiting_room,is_participant_mute_entry,is_use_personal_meeting_id,personal_meeting_id,
      is_custom_password,is_without_host_continue,isRecurr,password,ReadFlag,dial_in_countries,participants,is_cancelled,is_attended,save_template,a.uuid,template_id,invite_url,status,speakingLanguage,files  from worktual_video_meeting_master_dtl a where a.uuid=uuid;
 
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_video_insert_bell_notification` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_video_insert_bell_notification`(
     `from` varchar(255),
     `to` json ,
     `message`  json ,
     `timestamp` bigint,
     `ReadFlag`  varchar(255),
     `type` int,
     `bell_id` varchar(55)
     )
begin
     
     declare errcode int;
     declare errmsg varchar(155);
     declare v_now datetime ;
     set v_now=current_timestamp();
     set errcode=-1;
     set errmsg='failure';
     
      sp_exit : begin
     
   
         insert into worktual_video_bell_notification (`from`,`to`,`message`,`timestamp` ,`ReadFlag`,`type`,`createdat`,`bell_id`)
         values (`from`,`to`,`message`,`timestamp` ,`ReadFlag`,`type`,v_now ,`bell_id`);
         
         
      	  if row_count() > 0
            then
      			set errcode = 0;
                  set errmsg = 'inserted successfully';
                  leave sp_exit;
            end if;
     
    
     
      end sp_exit;       
      
      select errcode as errcode,errmsg as errmsg;
     
     
     
     end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_video_insert_meeting_Settings` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_video_insert_meeting_Settings`(
 `sip_id` varchar(20) ,
 `security` varchar(250),
 `schedule` varchar(250),
 `in_meeting_basics`  varchar(250),
 `in_meeting_advance`   varchar(250)
 )
begin
 
 declare errcode int;
 declare errmsg varchar(155);
 declare v_now date;
 set v_now=current_date();
 
  sp_exit : begin
 
 if exists (select * from worktual_video_meeting_Settings a where a.sip_id=sip_id limit 1 ) then
 
 update worktual_video_meeting_Settings a set 
 a.`security`=`security` ,
 a.`schedule`=`schedule` ,
 a.`in_meeting_basics`=`in_meeting_basics`, 
 a.`in_meeting_advance`=`in_meeting_advance`,
 a. `createdat` =v_now
 where a.sip_id=sip_id;
 
   if row_count() > 0
        then
  			set errcode = 0;
              set errmsg = 'updated successfully';
              leave sp_exit; 
        end if;
        
        else
        
     insert into worktual_video_meeting_Settings (`id` ,
 `sip_id` ,`security`,`schedule` ,`in_meeting_basics` ,`in_meeting_advance`   ,`createdat` )
     values (`sip_id` ,`security`,`schedule` ,`in_meeting_basics` ,`in_meeting_advance`   ,v_now);
     
     
  	  if row_count() > 0
        then
  			set errcode = 0;
              set errmsg = 'inserted successfully';
              leave sp_exit;
        end if;
 
 end if;
 
  end sp_exit;       
  
  select errcode as errcode,errmsg as errmsg;
 
 
 
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_video_insert_transcript_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_video_insert_transcript_details`(
`uuid` text ,
`transcripts` json,
`MOM` varchar(250)
)
begin

declare errcode int;
declare errmsg varchar(155);


 sp_exit : begin

if exists (select * from worktual_video_meeting_transcript_details a where a.uuid=uuid limit 1 ) then

update worktual_video_meeting_transcript_details a set 
a.`transcripts`=`transcripts` ,
a.`MOM`=`MOM` 
where a.uuid=uuid;

  if row_count() > 0
       then
 			set errcode = 0;
             set errmsg = 'updated successfully';
             leave sp_exit; 
       end if;
       
       else
       
    insert into worktual_video_meeting_transcript_details (uuid,transcripts,MOM )
    values (`uuid`  ,`transcripts` ,`MOM` );
    
 	  if row_count() > 0
       then
 			set errcode = 0;
             set errmsg = 'inserted successfully';
             leave sp_exit;
       end if;

end if;

 end sp_exit;       
 
 select errcode as errcode,errmsg as errmsg;



end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_video_meeting_add_participants_v2` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_video_meeting_add_participants_v2`(uuid VARCHAR(250),participants json ,sip_id varchar(20)  )
BEGIN
 
 	declare errcode int default -1;
 	declare errmsg varchar(50) default 'Failure';
 
 	sp_exit:Begin
 		if not exists(select 1 from worktual_video_meeting_master_dtl a where a.uuid = uuid and a.sip_id=sip_id) then
 			set errcode = -1;
 			set errmsg = 'Meeting uuid is not exists';
 			leave sp_exit;
 		end if;
 
 		if row_count() > 0 then
 		
 			update worktual_video_meeting_master_dtl a 
 			set a.participants = participants
 			where a.uuid = uuid and a.sip_id=sip_id;
 		
 			set errcode = 0;
 			set errmsg = 'Success : Participant added';
 		end if;
 	    
 	END sp_exit;
     select errcode as errcode, errmsg as errmsg;
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_video_meeting_edit_meeting_socket_by_uuid` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_video_meeting_edit_meeting_socket_by_uuid`(uuid VARCHAR(250),participants json )
BEGIN
 
 	declare errcode int default -1;
 	declare errmsg varchar(50) default 'Failure';
 
 	sp_exit:Begin
 		if not exists(select 1 from worktual_video_meeting_master_dtl a where a.uuid = uuid) then
 			set errcode = -1;
 			set errmsg = 'Meeting uuid is not exists';
 			leave sp_exit;
 		end if;
 

 			update worktual_video_meeting_master_dtl a 
 			set a.participants = participants
 			where a.uuid = uuid;
 		
 			set errcode = 0;
 			set errmsg = 'Success : Participant added';
 	    
 	END sp_exit;
     select errcode as errcode, errmsg as errmsg, uuid as uuid;
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_video_meeting_edit_meeting_uuid` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_video_meeting_edit_meeting_uuid`(uuid VARCHAR(250),participants json )
BEGIN
 
 	declare errcode int default -1;
 	declare errmsg varchar(50) default 'Failure';
 
 	sp_exit:Begin
 		if not exists(select 1 from worktual_video_meeting_master_dtl a where a.uuid = uuid) then
 			set errcode = -1;
 			set errmsg = 'Meeting uuid is not exists';
 			leave sp_exit;
 		end if;
 

 			update worktual_video_meeting_master_dtl a 
 			set a.participants = participants
 			where a.uuid = uuid;
 		
 			set errcode = 0;
 			set errmsg = 'Success : Participant added';

 	END sp_exit;
     select errcode as errcode, errmsg as errmsg, uuid as uuid;
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_video_meet_now` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_video_meet_now`(
 title varchar(250),
 meeting_id varchar(250),
 `password` varchar(100),
 is_use_personal_meeting_id varchar(100),
 personal_meeting_id  varchar(100),
 is_participant_video varchar(100),
 participants   varchar(250)
 )
begin
 
  declare errcode int;
 declare errmsg varchar(155);
 declare v_invite_url varchar(500) ;
 
 set errcode=-1;
 set errmsg='failure to connect meet_now';
 
 select a.invite_url into v_invite_url 
 from worktual_video_meeting_master_dtl a
 where a.title=title and a.meeting_id=meeting_id and a.password=`password` and a.is_use_personal_meeting_id=is_use_personal_meeting_id
 and a.personal_meeting_id=personal_meeting_id and a.is_participant_video=is_participant_video and a.participants=participants;
 
   if row_count()>0 then
   set errcode=0;
   set errmsg='Succes to get the meeting invite_url';
   end if;
 
 select errcode ,errmsg , v_invite_url as invite_url;
 
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_video_participant_status` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_video_participant_status`(
 `uuid` text
)
begin

select title,sip_id,hostName,a.meeting_id,description,start_timestamp,end_timestamp,lastModifiedDate,duration_minutes,timezone,joining_option_type,calender_type,rrule,is_host_myvideo,is_record_meeting,
     is_alternate_host,is_participant_video,is_participant_join_bef_host,is_participant_invite_guest,is_participant_waiting_room,is_participant_mute_entry,is_use_personal_meeting_id,personal_meeting_id,
     is_custom_password,is_without_host_continue,isRecurr,password,ReadFlag,dial_in_countries,participants,is_cancelled,is_attended,save_template,a.uuid,template_id,invite_url,status,speakingLanguage,files  from worktual_video_meeting_master_dtl a where a.uuid=uuid;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_video_read_flag_count` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_video_read_flag_count`(
sip_id varchar(20),
server_host varchar(100)
 )
begin
   declare errcode int;
   declare errmsg varchar(155);
   declare v_ReadFlag int;
   
 select count(a.ReadFlag) into  v_ReadFlag from worktual_video_meeting_master_dtl a where a.sip_id=sip_id and a.server_host=server_host;
  
 
    if row_count()>0 then
    set errcode=0;
    set errmsg='Succes to get the read_flag_count meeting';
    end if;
  
  select errcode ,errmsg,v_ReadFlag as ReadFlag_count ;
  
   
   end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_video_read_unread_by_uuid` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_video_read_unread_by_uuid`(
   uuid text
  )
begin
    declare errcode int;
    declare errmsg varchar(155);
    
      update worktual_video_meeting_master_dtl a set a.ReadFlag=1 where a.uuid=uuid ;
   
  
     if row_count()>0 then
     set errcode=0;
     set errmsg='Succes to read the meeting';
     end if;
   
   select errcode ,errmsg ;
   
    
    end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_video_update_chat_setting` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_video_update_chat_setting`(
 chatSetting json,
 uuid text
 )
begin
 
  declare errcode int;
  declare errmsg varchar(250);

	update worktual_video_meeting_master_dtl a set a.chatSetting = chatSetting where a.uuid = uuid;

    if row_count()>0 then
    set errcode=0;
    set errmsg='Succes to update chat_setting';
    end if;
  
  select errcode,errmsg ;
 
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_video_update_meeting_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_video_update_meeting_details`(
    `uuid` text,
    `participants` json ,
    `title` varchar(250) ,
    `meeting_id` varchar(250) ,
    `password` varchar(100) ,
    `personal_meeting_id` varchar(100) ,
    `msgid` varchar(100) ,
    `server_host` varchar(100) ,
    `hostName` varchar(100) ,
    `sip_id` varchar(20) ,
    `invite_url` varchar(100) ,
    `onlyContacts` tinyint(1) ,
    `restrictScreenShare` tinyint(1) ,
    `requireAuthentication` tinyint(1) ,
    `authenticationJoin` enum('Anyone','Only contacts','All signed in user') ,
    `chatSetting` json ,
    `meetings_type` varchar(20) ,
    `description` varchar(250) ,
    `start_timestamp` bigint ,
    `end_timestamp` bigint ,
    `lastModifiedDate` bigint ,
    `duration_minutes` int ,
    `timezone` varchar(250) ,
    `joining_option_type` varchar(30) ,
    `calender_type` varchar(20) ,
    `recurrence` enum('None','Daily','Weekly','Monthly') ,
    `rrule` varchar(30) ,
    `is_host_myaudio` tinyint(1) ,
    `is_host_myvideo` tinyint(1) ,
    `is_participant_video` tinyint(1) ,
    `is_use_personal_meeting_id` tinyint(1) ,
    `is_participant_waiting_room` tinyint(1) ,
    `is_cancelled` tinyint(1) ,
    `is_attended` tinyint(1) ,
    `is_record_meeting` tinyint(1) ,
    `is_alternate_host` tinyint(1) ,
    `is_participant_join_bef_host` tinyint(1) ,
    `is_participant_invite_guest` tinyint(1) ,
    `is_participant_mute_entry` tinyint(1) ,
    `is_without_host_continue` tinyint(1) ,
    `is_custom_password` tinyint(1) ,
    `speakingLanguage` varchar(30) ,
    `dial_in_countries` json ,
    `save_template` tinyint(1) ,
    `status` varchar(30) ,
    `ReadFlag` json ,
    `files` json ,
    `createdate` datetime ,
    `modifieddate` datetime ,
    `alternate_host` json ,
    `isRecurr` int ,
    `template_id` varchar(255) ,
    `is_deleted` int ,
    `is_host` enum('false','true') ,
    `white_board` json ,
    `HostAddress`  varchar(125) 
 )
begin
 
 declare errcode int;
 declare errmsg varchar(250);
 
   set errcode=-1;
   set errmsg='faiure to update';
   
   
 
   if exists(select * from worktual_video_meeting_master_dtl a where a.uuid=uuid limit 1 ) then 
   update worktual_video_meeting_master_dtl a
   set 
    a.participants  =participants  ,
    a.title  =title  ,
    a.meeting_id  =meeting_id  ,
    a.password  =password  ,
    a.personal_meeting_id  =personal_meeting_id  ,
    a.msgid  =msgid  ,
    a.server_host  =server_host  ,
    a.hostName  =hostName  ,
    a.sip_id  =sip_id  ,
    a.invite_url  =invite_url  ,
    a.onlyContacts  =onlyContacts  ,
    a.restrictScreenShare  =restrictScreenShare  ,
    a.requireAuthentication  =requireAuthentication  ,
    a.authenticationJoin  =authenticationJoin  ,
    a.chatSetting  =chatSetting  ,
    a.meetings_type  =meetings_type  ,
    a.description  =description  ,
    a.start_timestamp  =start_timestamp  ,
    a.end_timestamp  =end_timestamp  ,
    a.lastModifiedDate  =lastModifiedDate  ,
    a.duration_minutes  =duration_minutes  ,
    a.timezone  =timezone  ,
    a.joining_option_type  =joining_option_type  ,
    a.calender_type  =calender_type  ,
    a.recurrence  =recurrence  ,
    a.rrule  =rrule  ,
    a.is_host_myaudio  =is_host_myaudio  ,
    a.is_host_myvideo  =is_host_myvideo  ,
    a.is_participant_video  =is_participant_video  ,
    a.is_use_personal_meeting_id  =is_use_personal_meeting_id  ,
    a.is_participant_waiting_room  =is_participant_waiting_room  ,
    a.is_cancelled  =is_cancelled  ,
    a.is_attended  =is_attended  ,
    a.is_record_meeting  =is_record_meeting  ,
    a.is_alternate_host  =is_alternate_host  ,
    a.is_participant_join_bef_host  =is_participant_join_bef_host  ,
    a.is_participant_invite_guest  =is_participant_invite_guest  ,
    a.is_participant_mute_entry  =is_participant_mute_entry  ,
    a.is_without_host_continue  =is_without_host_continue  ,
    a.is_custom_password  =is_custom_password  ,
    a.speakingLanguage  =speakingLanguage  ,
    a.dial_in_countries  =dial_in_countries  ,
    a.save_template  =save_template  ,
    a.status  =status  ,
    a.ReadFlag  =ReadFlag  ,
    a.files  =files  ,
    a.createdate  =createdate  ,
    a.modifieddate  =modifieddate  ,
    a.alternate_host  =alternate_host  ,
    a.isRecurr  =isRecurr  ,
    a.template_id  =template_id  ,
    a.is_deleted  =is_deleted  ,
    a.is_host =is_host ,
    a.white_board=white_board       ,
    a.HostAddress=HostAddress
   where a.uuid=uuid ;
   
 			if row_count()>0 then
 					set errcode=0;
 					set errmsg='Succes to update meeting';
 			end if;
 		  
   end if;
   
   select errcode,errmsg;
 
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_video_update_ReadFlag_bell_notification` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_video_update_ReadFlag_bell_notification`(
     readFlagval json,
     bell_id varchar(125)
     )
begin
     
  	declare errcode int;
  	declare errmsg varchar(125);
  
  	set errcode=-1;
  	set errmsg='failed';
  
  	
  	
  
     update worktual_video_bell_notification a set a.ReadFlag= JSON_SET(a.ReadFlag, concat('$."',readFlagval,'"'), 0) where a.ReadFlag like  concat('%',`readFlagval`,'%')  and  a.bell_id=bell_id  ;
     
     if row_count()>0 then
     set errcode=0;
     set errmsg='updated Success';
     end if;
     
     select  errcode,errmsg;
     
     end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_video_update_template_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_video_update_template_dtl`(
     template_id varchar(500) ,
     title varchar(500) ,
     sip_id varchar(500) ,
     meeting_id varchar(500) ,
     description varchar(500) ,
     start_timestamp bigint ,
     end_timestamp bigint ,
     duration_minutes bigint ,
     timezone varchar(500) ,
     joining_option_type varchar(500) ,
     calender_type varchar(500) ,
     rrule varchar(500) ,
     is_host_myvideo tinyint(1) ,
     is_record_meeting tinyint(1) ,
     is_alternate_host tinyint(1) ,
     is_participant_video tinyint(1) ,
     is_participant_join_bef_host tinyint(1) ,
     is_participant_invite_guest tinyint(1) ,
     is_participant_waiting_room tinyint(1) ,
     is_participant_mute_entry tinyint(1) ,
     is_use_personal_meeting_id tinyint(1) ,
     is_without_host_continue tinyint(1) ,
     isRecurr tinyint(1) ,
     personal_meeting_id varchar(500) ,
     is_custom_password tinyint(1) ,
     is_host_myaudio tinyint(1) ,
     password varchar(500) ,
     dial_in_countries json ,
     participants json ,
     is_cancelled bigint ,
     is_attended bigint ,
     save_template tinyint(1) ,
     hostName varchar(500) ,
     uuid varchar(500) ,
     status varchar(500) ,
     invite_url varchar(500) ,
     speakingLanguage varchar(500) ,
     files json ,
     createdat varchar(500) ,
     updatedat varchar(500) ,
     alternate_host json ,
     HostAddress varchar(125)
  )
begin
       declare errcode int default -1;
        declare errmsg varchar(50) default 'Failure';
  
    sp_exit:BEGIN
    
    if  exists(select * from Worktual_Meeting_Template a where a.template_id = template_id limit 1) 
    then
   
   update Worktual_Meeting_Template a set 
     a.title  =title  ,
     a.sip_id  =sip_id  ,
     a.meeting_id  =meeting_id  ,
     a.description  =description  ,
     a.start_timestamp  =start_timestamp  ,
     a.end_timestamp  =end_timestamp  ,
     a.duration_minutes  =duration_minutes  ,
     a.timezone  =timezone  ,
     a.joining_option_type  =joining_option_type  ,
     a.calender_type  =calender_type  ,
     a.rrule  =rrule  ,
     a.is_host_myvideo  =is_host_myvideo  ,
     a.is_record_meeting  =is_record_meeting  ,
     a.is_alternate_host  =is_alternate_host  ,
     a.is_participant_video  =is_participant_video  ,
     a.is_participant_join_bef_host  =is_participant_join_bef_host  ,
     a.is_participant_invite_guest  =is_participant_invite_guest  ,
     a.is_participant_waiting_room  =is_participant_waiting_room  ,
     a.is_participant_mute_entry  =is_participant_mute_entry  ,
     a.is_use_personal_meeting_id  =is_use_personal_meeting_id  ,
     a.is_without_host_continue  =is_without_host_continue  ,
     a.isRecurr  =isRecurr  ,
     a.personal_meeting_id  =personal_meeting_id  ,
     a.is_custom_password  =is_custom_password  ,
     a.is_host_myaudio  =is_host_myaudio  ,
     a.password  =password  ,
     a.dial_in_countries  =dial_in_countries  ,
     a.participants  =participants  ,
     a.is_cancelled  =is_cancelled  ,
     a.is_attended  =is_attended  ,
     a.save_template  =save_template  ,
     a.hostName  =hostName  ,
     a.uuid  =uuid  ,
     a.status  =status  ,
     a.invite_url  =invite_url  ,
     a.speakingLanguage  =speakingLanguage  ,
     a.files  =files  ,
     a.createdat  =createdat  ,
     a.updatedat  =updatedat  ,
     a.alternate_host  =alternate_host  ,
     a.HostAddress=HostAddress
     where a.template_id=template_id;
     
    	     if row_count() > 0 then
    					set errcode = 0;
    					set errmsg = 'Success : updated';
             end if;
    End if;
    end;
  select errcode as errcode, errmsg as errmsg;
  end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `worktual_video_update_whiteboard` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `worktual_video_update_whiteboard`(
uuid text ,
whiteboard json
)
begin
   declare errcode int;
   declare errmsg varchar(155);

  update worktual_video_meeting_master_dtl a set a.white_board=whiteboard where a.uuid=uuid ;
  
      if row_count()>0 then
      set errcode=0;
      set errmsg='Succes to read the meeting';
      end if;
    
    select errcode ,errmsg ;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-21  9:51:43
