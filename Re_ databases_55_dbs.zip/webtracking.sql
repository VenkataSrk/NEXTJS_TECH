-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: webtracking
-- ------------------------------------------------------
-- Server version	8.0.44-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tb_trackingMasterDtl`
--

DROP TABLE IF EXISTS `tb_trackingMasterDtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_trackingMasterDtl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `domainId` int DEFAULT NULL,
  `visitorId` varchar(40) DEFAULT NULL,
  `trackingData` json DEFAULT NULL,
  `status` int DEFAULT '1',
  `createDate` datetime DEFAULT CURRENT_TIMESTAMP,
  `domainName` varchar(50) DEFAULT NULL,
  `updatedDate` datetime DEFAULT NULL,
  `lastNode` json DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_tb_trackingMasterDtl` (`domainId`),
  KEY `idx_visitorId` (`visitorId`),
  KEY `idx_domainIdvisitorId` (`domainId`,`visitorId`),
  KEY `idx_trackingData` ((cast(json_extract(`trackingData`,_utf8mb4'$.data') as char(100) charset utf8mb4)))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_trackingMasterDtl_v2`
--

DROP TABLE IF EXISTS `tb_trackingMasterDtl_v2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_trackingMasterDtl_v2` (
  `id` int NOT NULL AUTO_INCREMENT,
  `createDate` datetime DEFAULT CURRENT_TIMESTAMP,
  `domainId` int DEFAULT NULL,
  `domainName` varchar(50) DEFAULT NULL,
  `visitorId` varchar(40) DEFAULT NULL,
  `trackingData` text,
  `recordingdata` text,
  `updatedDate` datetime DEFAULT NULL,
  `lastNode` json DEFAULT NULL,
  `utm_source_latnode` json DEFAULT NULL,
  `utm_source_nfspth` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_domainIdvisitorId` (`domainId`,`visitorId`),
  KEY `idx_createDate` (`createDate` DESC),
  KEY `idx_domain_visitor_date` (`domainId`,`visitorId`,`createDate` DESC),
  KEY `idx_domainId_visitorId` (`domainId`,`visitorId`),
  KEY `idx_updatedDate` (`updatedDate` DESC),
  KEY `idx_domain_visitordate` (`domainId`,`visitorId`,`updatedDate` DESC)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=551858 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Temporary view structure for view `vw_unique_visitors_by_domain`
--

DROP TABLE IF EXISTS `vw_unique_visitors_by_domain`;
/*!50001 DROP VIEW IF EXISTS `vw_unique_visitors_by_domain`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vw_unique_visitors_by_domain` AS SELECT 
 1 AS `domainId`,
 1 AS `domainName`,
 1 AS `uniqueVisitorCount`*/;
SET character_set_client = @saved_cs_client;

--
-- Dumping routines for database 'webtracking'
--
/*!50003 DROP PROCEDURE IF EXISTS `copydata` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `copydata`(
p_fromi		smallint,
p_endi 		smallint
)
begin
	declare v_fromi	smallint;
	declare v_limit smallint;
    
    set v_fromi = p_fromi;    
    
	while v_fromi <=  p_endi
	do
		insert into tb_trackingMasterDtl_20250911_bkp(id,domainId,visitorId,trackingData,`status`,createDate,domainName)
		SELECT 	m.id,domainId,m.visitorId,m.trackingData,m.`status`,m.createDate,m.domainName 
		FROM 	tb_trackingMasterDtl m
		WHERE 	domainId = 11165
		AND 	createDate >= '2025-09-11' 
		AND 	createDate < '2025-09-12'
		order by id limit v_fromi,20;
        

		set v_fromi = v_fromi+ 20;       
	end while;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_get_unique_visitors_by_domain` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`crmdev`@`%` PROCEDURE `sp_get_unique_visitors_by_domain`(
    IN in_domainId INT
)
BEGIN
    SELECT *
    FROM vw_unique_visitors_by_domain
    WHERE domainId = in_domainId;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wt_GetTrackingdataByVisitorId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wt_GetTrackingdataByVisitorId`(p_domainId int, p_visitorId varchar(30) )
Begin
		select visitorId,trackingData as trackingData 
        from tb_trackingMasterDtl a
 		where a.domainId = p_domainId 
 		and a.visitorId  = p_visitorId;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wt_GetTrackingMasterDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wt_GetTrackingMasterDtl`(
   p_domainId int,
   p_offset int,
   p_limit int
   )
Begin
   
  	declare v_temp int;
   
  	set  v_temp = p_offset * p_limit;
  	
   	
      
      select id, domainId, visitorId, trackingData, status, createDate, domainName
 	from tb_trackingMasterDtl 
 	where domainId = p_domainId
    order by id desc
     limit v_temp, p_limit;
      
      select count(1) as totalcount
      from tb_trackingMasterDtl 
      where domainId = p_domainId;
      
      SELECT count(distinct visitorId) uniqueVisitorIdCount
  	FROM tb_trackingMasterDtl 
  	WHERE domainId = p_domainId ;
      
      
   End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wt_GetTrackingMasterDtlByUniqueVisitorId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wt_GetTrackingMasterDtlByUniqueVisitorId`(
     p_domainId int,
      p_offset int,
      p_limit int,
      p_visitorId varchar(30) 
     )
sp_return:Begin
 

    		declare v_temp int;
            declare v_fullcount int;
            
            leave sp_return;
             
    		select count(1) into v_fullcount
    		from tb_trackingMasterDtl 
    		where (domainId = p_domainId or p_domainId is null or p_domainId=0);
            
            if p_limit is null then
    			set p_limit = v_fullcount;
            End if;
            
            set v_temp = p_offset * p_limit;
            
    		if p_visitorId is null then
            
    			drop temporary table if exists tt_chk;
    			create temporary table tt_chk as
    			select Distinct visitorId,
    			count(1) over(partition by visitorId) as visitortotalcount
    			from tb_trackingMasterDtl 
    			where (domainId = p_domainId or p_domainId is null or p_domainId=0)
    			limit v_temp, p_limit;
    
    			with cte as 
    			(
    				select Distinct  a.visitorId,ifnull(lastNode,max(id) over(partition by a.visitorId order by id desc )) as rn,visitortotalcount
    				from tb_trackingMasterDtl a join tt_chk b on a.visitorId = b.visitorId
    				where (domainId = p_domainId  or p_domainId is null or p_domainId=0)
    			)
    			select a.visitorId,a.visitortotalcount,b.trackingData from cte a join tb_trackingMasterDtl b on a.rn = b.id;
    		Else
    			select visitorId,JSON_ARRAYAGG(trackingData) as trackingData 
    			from tb_trackingMasterDtl a
    			where (a.domainId = p_domainId  or p_domainId is null or p_domainId=0) 
    			and a.visitorId  = p_visitorId
    			group by a.visitorId
    			limit v_temp, p_limit;
            
    		End if;
            
    		SELECT count(distinct visitorId) uniqueVisitorIdCount
    		FROM tb_trackingMasterDtl 
    		WHERE (domainId = p_domainId  or p_domainId is null or p_domainId=0);
    	
     End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wt_GetTrackingMasterDtlByVisitorId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wt_GetTrackingMasterDtlByVisitorId`(
p_domainId int,
 p_offset int,
 p_limit int,
 p_visitorId varchar(30) 
)
Begin
		
	declare v_temp int;
    
 
	set  v_temp = p_offset * p_limit;
    
    
	 select visitorId,count(1) as visitortotalcount
	from tb_trackingMasterDtl 
	where domainId = p_domainId
	group by visitorId
    limit v_temp, p_limit; 
    
   
    
	select count(1) as totalcount
    from tb_trackingMasterDtl 
    where domainId = p_domainId;
    
    
    if p_visitorId is not null then
		select visitorId,JSON_ARRAYAGG(trackingData) as trackingData 
        from tb_trackingMasterDtl a
		where a.domainId = p_domainId 
		and a.visitorId  = p_visitorId
		group by a.visitorId;
    End if;

    
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wt_GetTrackingMasterDtl_v2` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wt_GetTrackingMasterDtl_v2`(
  p_domainId int
  ,p_visitorId varchar(40)
  ,p_offset int
  ,p_limit int
  ,p_domainName varchar(50)
  )
Begin
      declare v_temp int;
      set v_temp = IF(p_offset IS NULL OR p_offset <= 1, 0, (p_offset - 1) * p_limit);
      -- (p_offset-1) * p_limit;
      
      if p_offset is not null then
		  select id, createDate, domainId, domainName, visitorId, trackingData, recordingdata, updatedDate , lastNode, utm_source_latnode, utm_source_nfspth
		  from tb_trackingMasterDtl_v2 
		  where (domainId = p_domainId or p_domainId is null or p_domainId=0) 
		  and (visitorId collate utf8mb4_0900_ai_ci = p_visitorId or p_visitorId is null or p_visitorId='') 
          and (domainName = p_domainName or p_domainName is null or p_domainName='')
          order by updatedDate desc
		  limit v_temp, p_limit;
      Else
		select id, createDate, domainId, domainName, visitorId, trackingData, recordingdata, updatedDate , lastNode, utm_source_latnode, utm_source_nfspth
		from tb_trackingMasterDtl_v2 
		where (domainId = p_domainId or p_domainId is null or p_domainId=0) 
		and (visitorId  collate utf8mb4_0900_ai_ci = p_visitorId or p_visitorId is null or p_visitorId='') 
        and (domainName = p_domainName or p_domainName is null or p_domainName='')
        order by updatedDate desc;
      End if;
      
  	SELECT count(distinct visitorId) uniqueVisitorIdCount
  	FROM tb_trackingMasterDtl_v2 
  	WHERE (domainId = p_domainId  or p_domainId is null or p_domainId=0)
	and (domainName = p_domainName or p_domainName is null or p_domainName='');
      
  End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wt_GetTrackingMasterDtl_v2_test` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wt_GetTrackingMasterDtl_v2_test`(
  p_domainId int
  ,p_visitorId varchar(40)
  ,p_offset int
  ,p_limit int
  ,p_domainName varchar(50)
  ,p_fromDate date
  ,p_toDate date
  )
Begin
      declare v_temp int;
      declare v_visitorId int;
      declare v_rowcount int;
      set v_temp = IF(p_offset IS NULL OR p_offset <= 1, 0, (p_offset - 1) * p_limit);
      -- (p_offset-1) * p_limit;
      
      drop temporary table if exists tt_webtrackDtl;
      create temporary table tt_webtrackDtl
      (
			id int auto_increment primary key 
			,createDate datetime 
			,domainId int 
			,domainName varchar(50) 
			,visitorId varchar(40) 
			,trackingData text 
			,recordingdata text 
			,updatedDate datetime 
			,lastNode json 
			,utm_source_latnode json 
			,utm_source_nfspth varchar(250)
      );
 
      
      if p_offset is not null then
      
		  if ifnull(p_visitorId,'') <>'' then
			insert into tt_webtrackDtl(id, createDate, domainId, domainName, visitorId, trackingData, recordingdata, updatedDate , lastNode, utm_source_latnode, utm_source_nfspth)
			 select id, createDate, domainId, domainName, visitorId, trackingData, recordingdata, updatedDate , lastNode, utm_source_latnode, utm_source_nfspth
			  from tb_trackingMasterDtl_v2 
			  where (domainId = p_domainId or p_domainId is null or p_domainId=0) 
			  and (visitorId collate utf8mb4_0900_ai_ci = p_visitorId or p_visitorId is null or p_visitorId='') 
			  and (domainName = p_domainName or p_domainName is null or p_domainName='')
			  and (cast(createDate as date) between p_fromDate and p_toDate or (ifnull(p_fromDate,'')='' or ifnull(p_toDate,'')='' ))
			  order by updatedDate desc
			  limit v_temp, p_limit;
              
              
		  Else
			insert into tt_webtrackDtl(id, createDate, domainId, domainName, visitorId, trackingData, recordingdata, updatedDate , utm_source_latnode, utm_source_nfspth)
			 select id, createDate, domainId, domainName, visitorId, trackingData, recordingdata, updatedDate, utm_source_latnode, utm_source_nfspth
			  from tb_trackingMasterDtl_v2 
			  where (domainId = p_domainId or p_domainId is null or p_domainId=0) 
			  and (visitorId collate utf8mb4_0900_ai_ci = p_visitorId or p_visitorId is null or p_visitorId='') 
			  and (domainName = p_domainName or p_domainName is null or p_domainName='')
			  and (cast(createDate as date) between p_fromDate and p_toDate or (ifnull(p_fromDate,'')='' or ifnull(p_toDate,'')='' ))
			  order by updatedDate desc
			  limit v_temp, p_limit;
              
		  End if;
		 
      Else
      
		if ifnull(p_visitorId,'') <>'' then 
			insert into tt_webtrackDtl(id, createDate, domainId, domainName, visitorId, trackingData, recordingdata, updatedDate , lastNode, utm_source_latnode, utm_source_nfspth)
			select id, createDate, domainId, domainName, visitorId, trackingData, recordingdata, updatedDate , lastNode, utm_source_latnode, utm_source_nfspth
			from tb_trackingMasterDtl_v2 
			where (domainId = p_domainId or p_domainId is null or p_domainId=0) 
			and (visitorId  collate utf8mb4_0900_ai_ci = p_visitorId or p_visitorId is null or p_visitorId='') 
			and (domainName = p_domainName or p_domainName is null or p_domainName='')
			and (cast(createDate as date) between p_fromDate and p_toDate or (ifnull(p_fromDate,'')='' or ifnull(p_toDate,'')='' ))
			order by updatedDate desc;
            
        else
			insert into tt_webtrackDtl(id, createDate, domainId, domainName, visitorId, trackingData, recordingdata, updatedDate ,  utm_source_latnode, utm_source_nfspth)
			select id, createDate, domainId, domainName, visitorId, trackingData, recordingdata, updatedDate , utm_source_latnode, utm_source_nfspth
			from tb_trackingMasterDtl_v2 
			where (domainId = p_domainId or p_domainId is null or p_domainId=0) 
			and (visitorId  collate utf8mb4_0900_ai_ci = p_visitorId or p_visitorId is null or p_visitorId='') 
			and (domainName = p_domainName or p_domainName is null or p_domainName='')
			and (cast(createDate as date) between p_fromDate and p_toDate or (ifnull(p_fromDate,'')='' or ifnull(p_toDate,'')='' ))
			order by updatedDate desc;
            
        End if;
      End if;
      
		select count(*) into v_rowcount from tt_webtrackDtl;
        
        select count(*) into v_rowcount from tt_webtrackDtl;

		if v_rowcount>0 then
			set v_visitorId = 1;
		End if;
      

	select * from tt_webtrackDtl;
      
  	SELECT case when v_visitorId = 1 and p_visitorId is not null then 1
                else count(distinct visitorId) end as uniqueVisitorIdCount,
			case when v_visitorId = 1 and p_visitorId is not null then 1
                else count(distinct domainName) end as uniquedomainNameCount
    -- if(v_visitorId =1 ,1, count(distinct visitorId)) uniqueVisitorIdCount ,if(v_visitorId =1 ,1, count(Distinct domainName)) uniquedomainNameCount
  	FROM tt_webtrackDtl
    -- tb_trackingMasterDtl_v2 
  	WHERE (domainId = p_domainId  or p_domainId is null or p_domainId=0)
	and (domainName = p_domainName or p_domainName is null or p_domainName='')
    and (cast(createDate as date) between p_fromDate and p_toDate or (ifnull(p_fromDate,'')='' or ifnull(p_toDate,'')='' ));
    
	SELECT Distinct domainName as  uniquedomainName
  	FROM tt_webtrackDtl
    -- tb_trackingMasterDtl_v2 
  	WHERE (domainId = p_domainId  or p_domainId is null or p_domainId=0)
    and (visitorId  collate utf8mb4_0900_ai_ci = p_visitorId or p_visitorId is null or p_visitorId='')  
    and (cast(createDate as date) between p_fromDate and p_toDate or (ifnull(p_fromDate,'')='' or ifnull(p_toDate,'')='' ));
    
      
  End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wt_GetTrackingMasterDtl_v3` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wt_GetTrackingMasterDtl_v3`(
  p_domainId int
  ,p_visitorId varchar(40)
  ,p_offset int
  ,p_limit int
  ,p_domainName varchar(50)
  )
Begin
      declare v_temp int;
      set v_temp = (p_offset-1) * p_limit;
      
      if p_offset is not null then
		  select id, createDate, domainId, domainName, visitorId, trackingData, recordingdata, updatedDate , lastNode, utm_source_latnode, utm_source_nfspth
		  from tb_trackingMasterDtl_v2 
		  where (domainId = p_domainId or p_domainId is null or p_domainId=0) 
		  and (visitorId collate utf8mb4_0900_ai_ci = p_visitorId or p_visitorId is null or p_visitorId='') 
          and (domainName = p_domainName or p_domainName is null or p_domainName='')
          and updatedDate > date_sub(NOW(), interval 30 MINUTE)
          order by updatedDate desc
		  limit v_temp, p_limit;
      Else
		select id, createDate, domainId, domainName, visitorId, trackingData, recordingdata, updatedDate , lastNode, utm_source_latnode, utm_source_nfspth
		from tb_trackingMasterDtl_v2 
		where (domainId = p_domainId or p_domainId is null or p_domainId=0) 
		and (visitorId  collate utf8mb4_0900_ai_ci = p_visitorId or p_visitorId is null or p_visitorId='') 
        and (domainName = p_domainName or p_domainName is null or p_domainName='')
        and updatedDate > date_sub(NOW(), interval 30 MINUTE)
        order by updatedDate desc;
      End if;
      
  	SELECT count(distinct visitorId) uniqueVisitorIdCount
  	FROM tb_trackingMasterDtl_v2 
  	WHERE (domainId = p_domainId  or p_domainId is null or p_domainId=0)
	and (domainName = p_domainName or p_domainName is null or p_domainName='')
    and updatedDate > date_sub(NOW(), interval 30 MINUTE);
      
  End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wt_InsertUpdateTrackingMasterDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wt_InsertUpdateTrackingMasterDtl`(
  p_domainId int
  ,p_visitorId varchar(40)
  ,p_trackingData json
  ,p_domainName varchar(50)
  
  )
sp_return:Begin
  	declare v_errcode int default -1;
      declare v_errmsg varchar(20) default 'Failure';
      declare v_id int;
      declare p_lastNode json ;
      
      if p_domainId is null or p_visitorId is null or p_trackingData is null then
  		select -1 as v_errcode, 'Mandatory fields cannot be null' as errcode;
          leave sp_return;
      End if;
      
      START TRANSACTION;
  		if not exists(select 1 from tb_trackingMasterDtl where domainId = p_domainId and visitorId = p_visitorId limit 1)then
  		insert into tb_trackingMasterDtl(domainId, visitorId, trackingData, domainName, lastNode) 
  		values(p_domainId, p_visitorId, p_trackingData, p_domainName, p_lastNode);
  		
  		if row_count()>0 then
  			set v_errcode = 0;
  			set v_errmsg = 'Inserted';
  		End if;
      Else
		
        select id into v_id from tb_trackingMasterDtl where domainId = p_domainId and visitorId = p_visitorId order by id desc limit 1;
        
        update tb_trackingMasterDtl
        set trackingData = ifnull(p_trackingData,trackingData)
			, updatedDate  = current_timestamp()
            , lastNode = ifnull(p_lastNode, lastNode)
        where domainId = p_domainId and visitorId = p_visitorId and id = v_id ;
        
        if row_count()>0 then
  			set v_errcode = 0;
  			set v_errmsg = 'Updated';
  		End if;
        
      End if;
      COMMIT;
      
      select v_errcode as errcode, v_errmsg as errmsg;
  End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wt_InsertUpdateTrackingMasterDtl_v2` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wt_InsertUpdateTrackingMasterDtl_v2`(
		p_domainId int
		,p_domainName varchar(50)
		,p_visitorId varchar(40)
		,p_trackingData text
		,p_recordingdata text
		,p_lastNode json
		,p_utm_source_latnode JSON
		,p_utm_source_nfspth varchar(250)
   )
sp_return:Begin
 
 		declare v_errcode int default -1;
 		declare v_errmsg varchar(20) default 'Failure';
      
		
       
       if p_domainId is null or p_visitorId is null then
   		select -1 as v_errcode, 'Mandatory fields cannot be null' as errcode;
           leave sp_return;
       End if;
       
       START TRANSACTION;
   		if not exists(select 1 from tb_trackingMasterDtl_v2 where domainId = p_domainId and visitorId = p_visitorId limit 1)then
 			insert into tb_trackingMasterDtl_v2(domainId, domainName, visitorId, trackingData, recordingdata, lastNode, updatedDate, utm_source_latnode, utm_source_nfspth) 
 			values(p_domainId, p_domainName, p_visitorId, p_trackingData, p_recordingdata, p_lastNode, current_timestamp(), p_utm_source_latnode, p_utm_source_nfspth);
 			
 			if row_count()>0 then
 				set v_errcode = 0;
 				set v_errmsg = 'Inserted';
 			End if;
 		Else
 		
 			update tb_trackingMasterDtl_v2
 			set trackingData = ifnull(p_trackingData, trackingData)
 				, recordingdata = ifnull(p_recordingdata, recordingdata)
 				, updatedDate  = current_timestamp()
                , lastNode = ifnull(p_lastNode, lastNode)
                , utm_source_latnode = ifnull(p_utm_source_latnode, utm_source_latnode)
                , utm_source_nfspth = ifnull(p_utm_source_nfspth, utm_source_nfspth)
 			where domainId = p_domainId and visitorId = p_visitorId ;
 
 			if row_count()>0 then
 				set v_errcode = 0;
 				set v_errmsg = 'Updated';
 			End if;
         
 		End if;
       COMMIT;
       
       select v_errcode as errcode, v_errmsg as errmsg;
   End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Final view structure for view `vw_unique_visitors_by_domain`
--

/*!50001 DROP VIEW IF EXISTS `vw_unique_visitors_by_domain`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`crmdev`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_unique_visitors_by_domain` AS select `tb_trackingMasterDtl_v2`.`domainId` AS `domainId`,`tb_trackingMasterDtl_v2`.`domainName` AS `domainName`,count(distinct `tb_trackingMasterDtl_v2`.`visitorId`) AS `uniqueVisitorCount` from `tb_trackingMasterDtl_v2` group by `tb_trackingMasterDtl_v2`.`domainId`,`tb_trackingMasterDtl_v2`.`domainName` order by `tb_trackingMasterDtl_v2`.`domainId` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-21  9:57:11
