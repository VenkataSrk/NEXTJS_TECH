-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: DEVICEMGT
-- ------------------------------------------------------
-- Server version	8.0.44-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `DEVICEMGT`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `DEVICEMGT` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `DEVICEMGT`;

--
-- Table structure for table `Product`
--

DROP TABLE IF EXISTS `Product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Product` (
  `Product_Id` int NOT NULL AUTO_INCREMENT,
  `Product_name` varchar(160) DEFAULT NULL,
  `product_desc` varchar(1000) DEFAULT NULL,
  `sku_code` varchar(20) NOT NULL,
  `Fk_product_type_id` int DEFAULT NULL,
  `Fk_brand_Id` int DEFAULT NULL,
  `buying_currency` varchar(5) DEFAULT NULL,
  `buying_price` float DEFAULT NULL,
  `selling_currency` varchar(5) DEFAULT NULL,
  `selling_price` float DEFAULT NULL,
  `weight` float DEFAULT NULL,
  `stock` int DEFAULT NULL,
  `status` int DEFAULT NULL,
  `Fk_Vendor_ID` int DEFAULT NULL,
  `img_path1` varchar(500) DEFAULT NULL,
  `img_path2` varchar(500) DEFAULT NULL,
  `img_path3` varchar(500) DEFAULT NULL,
  `img_path4` varchar(500) DEFAULT NULL,
  `img_path5` varchar(500) DEFAULT NULL,
  `create_date` datetime(3) DEFAULT NULL,
  `create_by` varchar(150) DEFAULT NULL,
  `last_update` datetime(3) DEFAULT NULL,
  `last_update_by` varchar(150) DEFAULT NULL,
  `qty` int DEFAULT NULL,
  PRIMARY KEY (`Product_Id`),
  KEY `FK_brand_RefIdx` (`Fk_brand_Id`),
  KEY `FK__Product__Fk_prod__164452B1Idx` (`Fk_product_type_id`),
  KEY `Fk_Vendor_infoIdx` (`Fk_Vendor_ID`),
  CONSTRAINT `FK__Product__Fk_prod__164452B1` FOREIGN KEY (`Fk_product_type_id`) REFERENCES `Ref_product_Type` (`product_Type`),
  CONSTRAINT `FK_brand_Ref` FOREIGN KEY (`Fk_brand_Id`) REFERENCES `brand` (`brand_id`),
  CONSTRAINT `Fk_Vendor_info` FOREIGN KEY (`Fk_Vendor_ID`) REFERENCES `Vendor` (`Vendor_ID`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Promotion_product`
--

DROP TABLE IF EXISTS `Promotion_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Promotion_product` (
  `Promoid` int NOT NULL AUTO_INCREMENT,
  `Fk_Product_Id` int DEFAULT NULL,
  `Min_pur_discount` float DEFAULT NULL,
  `Fk_Product_Type` int DEFAULT NULL,
  `Start_date` datetime(3) DEFAULT NULL,
  `End_date` datetime(3) DEFAULT NULL,
  `Promo_code` varchar(30) DEFAULT NULL,
  `auto_apply` int DEFAULT NULL,
  `status` int DEFAULT NULL,
  `create_date` datetime(3) DEFAULT NULL,
  `create_by` varchar(50) DEFAULT NULL,
  `last_update` datetime(3) DEFAULT NULL,
  `last_update_by` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`Promoid`),
  UNIQUE KEY `Uk_Promotion_product` (`Promo_code`),
  KEY `FK__Promotion__Fk_Pr__403A8C7DIdx` (`Fk_Product_Id`),
  KEY `FK__Promotion__Fk_Pr__412EB0B6Idx` (`Fk_Product_Type`),
  CONSTRAINT `FK__Promotion__Fk_Pr__412EB0B6` FOREIGN KEY (`Fk_Product_Type`) REFERENCES `Ref_product_Type` (`product_Type`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Ref_product_Type`
--

DROP TABLE IF EXISTS `Ref_product_Type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Ref_product_Type` (
  `product_Type` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`product_Type`),
  KEY `FK__Promotion__Fk_Pr__412EB0B6Idx2` (`product_Type`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Role`
--

DROP TABLE IF EXISTS `Role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Role` (
  `Role_Id` int NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`Role_Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `User`
--

DROP TABLE IF EXISTS `User`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `User` (
  `UserId` int NOT NULL AUTO_INCREMENT,
  `Username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `status` int DEFAULT NULL,
  `Fk_Role_id` int DEFAULT NULL,
  `create_date` datetime(3) DEFAULT NULL,
  `last_login_ip` varchar(100) DEFAULT NULL,
  `last_login_date` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`Username`),
  UNIQUE KEY `UserId` (`UserId`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Vendor`
--

DROP TABLE IF EXISTS `Vendor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Vendor` (
  `Vendor_ID` int NOT NULL AUTO_INCREMENT,
  `Vendor_name` varchar(150) DEFAULT NULL,
  `email_id` varchar(150) DEFAULT NULL,
  `phoneno` varchar(20) DEFAULT NULL,
  `location` varchar(500) DEFAULT NULL,
  `create_date` datetime(3) DEFAULT NULL,
  `create_by` varchar(100) DEFAULT NULL,
  `status` int DEFAULT NULL,
  `last_update` datetime(3) DEFAULT NULL,
  `last_update_by` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`Vendor_ID`),
  KEY `Fk_Vendor_infoIdx2` (`Vendor_ID`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `brand`
--

DROP TABLE IF EXISTS `brand`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `brand` (
  `brand_id` int NOT NULL AUTO_INCREMENT,
  `brand_name` varchar(150) DEFAULT NULL,
  `status` int DEFAULT NULL,
  `create_by` varchar(100) DEFAULT NULL,
  `create_date` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`brand_id`),
  KEY `FK_brand_RefIdx2` (`brand_id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `devicemgt_update_return_device_info_log`
--

DROP TABLE IF EXISTS `devicemgt_update_return_device_info_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `devicemgt_update_return_device_info_log` (
  `return_id` int DEFAULT NULL,
  `sku_code` varchar(150) DEFAULT NULL,
  `comments` varchar(150) DEFAULT NULL,
  `return_status` int DEFAULT NULL,
  `return_reason` varchar(250) DEFAULT NULL,
  `Type` int DEFAULT NULL,
  `return_reason_Type` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ref_product_status`
--

DROP TABLE IF EXISTS `ref_product_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ref_product_status` (
  `status_id` int NOT NULL,
  `status_desc` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `urordermgmtlogs_1`
--

DROP TABLE IF EXISTS `urordermgmtlogs_1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `urordermgmtlogs_1` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Application` longtext NOT NULL,
  `Logged` datetime(3) NOT NULL,
  `Level` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `Message` longtext NOT NULL,
  `Logger` longtext NOT NULL,
  `CallSite` longtext NOT NULL,
  `Exception` longtext NOT NULL,
  PRIMARY KEY (`Id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=4364 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping events for database 'DEVICEMGT'
--

--
-- Dumping routines for database 'DEVICEMGT'
--
/*!50003 DROP PROCEDURE IF EXISTS `devicemegt_get_product_selling_performance` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `devicemegt_get_product_selling_performance`(
  search_type INT, 
  search_operator VARCHAR(50),
  search_value FLOAT)
BEGIN
  
  
  	
  	
     DECLARE v_sql LONGTEXT;
     IF search_type is null then
        set search_type = 0;
     END IF;
     IF search_operator is null then
        set search_operator = '';
     END IF;
     IF search_value is null then
        set search_value = 0;
     END IF;
     DROP TEMPORARY TABLE IF EXISTS tt_product_performance;
     create TEMPORARY table tt_product_performance
     (
        Product_id INT,
        product_name VARCHAR(150),
        Porduct_Type VARCHAR(150),
        Sales_qty INT   default 0,
        Sales_order_value FLOAT   default 0,
        Sales_Net_Order_value FLOAT   default 0,
        buying_currency VARCHAR(3),
        Selling_currency VARCHAR(3)   default 'GBP',
        exchange_rate FLOAT   default 1
     );
  	
     SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
     INSERT INTO tt_product_performance(Product_id,product_name,Porduct_Type,buying_currency)
     SELECT Product_Id,Product_name,b.name,a.buying_currency FROM  Product a 
     join Ref_product_Type b on a.Fk_product_type_id = b.product_Type;
     SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
  	
     SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
     UPDATE tt_product_performance tmp set tmp.Sales_qty =(select IFNULL(Sum(quantity),0) from unifiedring.ur_device_order_item a 
     join unifiedring.ur_device_order b on a.order_id = b.order_id
     where IFNULL(device_approval,0) <> 2 AND tmp.Product_id = a.Vec_Device_Product_Id),tmp.Sales_order_value =(select IFNULL(Sum(tot_charge),0) from unifiedring.ur_device_order_item a 
     join unifiedring.ur_device_order b on a.order_id = b.order_id
     where IFNULL(device_approval,0) <> 2 AND tmp.Product_id = a.Vec_Device_Product_Id),tmp.Sales_Net_Order_value =(select IFNULL(Sum(tot_charge),0) -IFNULL(sum(tot_discount),0)
     -IFNULL(sum(tot_tax_fee),0) from unifiedring.ur_device_order_item a 
     join unifiedring.ur_device_order b on a.order_id = b.order_id
     where IFNULL(device_approval,0) <> 2 AND tmp.Product_id = a.Vec_Device_Product_Id);
     SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ; 
  	
  	
     SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
     UPDATE tt_product_performance tmp set tmp.Sales_qty = Sales_qty -(select IFNULL(Sum(quantity),0) from unifiedring.ur_device_order_item a 
     join unifiedring.ur_device_order b on a.order_id = b.order_id
     join unifiedring.ur_device_order_return c on a.itemid = c.itemid
     where IFNULL(rtn_status,0) = 2  and IFNULL(device_approval,0) <> 2 AND tmp.Product_id = a.Vec_Device_Product_Id),tmp.Sales_order_value = IFNULL(tmp.Sales_order_value,0) -(select IFNULL(Sum(rtn_charge),0) from unifiedring.ur_device_order_item a 
     join unifiedring.ur_device_order b on a.order_id = b.order_id
     join unifiedring.ur_device_order_return c on a.itemid = c.itemid
     where IFNULL(rtn_status,0) = 2  and IFNULL(device_approval,0) <> 2 AND tmp.Product_id = a.Vec_Device_Product_Id);
     SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ; 
  	
  	
     SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
     UPDATE tt_product_performance tmp set tmp.Sales_Net_Order_value = Sales_Net_Order_value -(select IFNULL(Sum(d.shipping_charge),0)+IFNULL(sum(shipping_tax_fee),0) from unifiedring.ur_device_order_item a 
     join unifiedring.ur_device_order b on a.order_id = b.order_id
     join Product c on c.Product_id = a.Vec_Device_Product_Id
     join unifiedring.ur_order_delivery_address d on a.order_id = d.order_id
     where  tmp.Product_id = a.Vec_Device_Product_Id);
     SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
  	

  
  	 
     IF search_type = 1 then
  	 
        set v_sql = 'select * from tt_product_performance
  			where Sales_Net_Order_value =' or search_operator or CAST(search_value AS CHAR(30)) or '';
        SET @SWV_Stmt = v_sql;
        PREPARE SWT_Stmt FROM @SWV_Stmt;
        EXECUTE SWT_Stmt;
        DEALLOCATE PREPARE SWT_Stmt;
     end if;
  	 
  	 
     IF search_type = 2 then
  	 
        set v_sql = 'select * from tt_product_performance
  			where Sales_Net_Order_value =' or search_operator or CAST(search_value AS CHAR(30)) or '';
        SET @SWV_Stmt = v_sql;
        PREPARE SWT_Stmt FROM @SWV_Stmt;
        EXECUTE SWT_Stmt;
        DEALLOCATE PREPARE SWT_Stmt;
     end if;
  	 
     IF IFNULL(search_type,0) = 0 then
  	 
        SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        select * from  tt_product_performance
        order by Sales_qty  desc;
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
     end if;
  	
  	
  	
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `devicemegt_get_sales_customer_break_down` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `devicemegt_get_sales_customer_break_down`(search_type INT, 
 search_operator VARCHAR(50),
 search_value FLOAT)
BEGIN
 
    DECLARE v_sql LONGTEXT;
    IF search_type is null then
       set search_type = 0;
    END IF;
    IF search_operator is null then
       set search_operator = '';
    END IF;
    IF search_value is null then
       set search_value = 0;
    END IF;
    DROP TEMPORARY TABLE IF EXISTS tt_temp_sales_breakdown;
    create TEMPORARY table tt_temp_sales_breakdown
    (
       customer_id INT,
       cust_address VARCHAR(250),
       Vendor_name VARCHAR(250),
       Order_placed INT   DEFAULT 0,
       Success_order INT   DEFAULT 0,
       Net_sale FLOAT   DEFAULT 0,
       Gross_Profit FLOAT   DEFAULT 0,
       Shipment_cost FLOAT   DEFAULT 0,
       tax FLOAT   default 0,
       discount FLOAT   default 0,
       Vendor_id INT,
       Goods_cost FLOAT,
       buying_currency VARCHAR(3),
       Selling_currency VARCHAR(3)   default 'GBP',
       exchange_rate FLOAT   default 1
    );
 	
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    insert into tt_temp_sales_breakdown(customer_id,cust_address,Vendor_name,Vendor_id,buying_currency)
    select d.company_id as customer_id,CONCAT(IFNULL(d.address1,''),',',IFNULL(postcode,''),',',IFNULL(address2,''))
    as cust_address,e.Vendor_name,e.Vendor_ID,c.buying_currency from unifiedring.ur_device_order_item a
    join unifiedring.ur_device_order b on a.order_id = b.order_id
    join Product c on a.Vec_Device_Product_Id = c.Product_Id
    join unifiedring.vbcp_company d on b.company_id = d.company_id
    join Vendor e on c.fk_vendor_id = e.Vendor_ID
    group by d.company_id,CONCAT(IFNULL(d.address1,''),',',IFNULL(postcode,''),',',IFNULL(address2,'')),e.Vendor_name,e.Vendor_ID,c.buying_currency;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 	
 	
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    UPDATE tt_temp_sales_breakdown tmp set tmp.Order_placed =(select IFNULL(Sum(quantity),0) from unifiedring.ur_device_order_item a 
    join unifiedring.ur_device_order b on a.order_id = b.order_id
    join Product c on c.Product_id = a.Vec_Device_Product_Id
    where  tmp.vendor_id = c.Fk_Vendor_ID
    and tmp.customer_id = b.company_id);
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ; 
 		
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    UPDATE tt_temp_sales_breakdown tmp set tmp.Goods_cost =(select IFNULL(Sum(buying_price),0) from unifiedring.ur_device_order_item a 
    join unifiedring.ur_device_order b on a.order_id = b.order_id
    join Product c on c.Product_id = a.Vec_Device_Product_Id
    where  tmp.vendor_id = c.Fk_Vendor_ID
    and tmp.customer_id = b.company_id);
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ; 
 	
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    UPDATE tt_temp_sales_breakdown tmp set tmp.Success_order = tmp.Order_placed -(select IFNULL(Sum(quantity),0) from unifiedring.ur_device_order_item a 
    join unifiedring.ur_device_order b on a.order_id = b.order_id
    join unifiedring.ur_device_order_return c on a.itemid = c.itemid
    join Product d on d.Product_id = a.Vec_Device_Product_Id
    where IFNULL(rtn_status,0) = 2  and IFNULL(device_approval,0) <> 2 AND tmp.vendor_id = d.Fk_Vendor_ID
    and tmp.customer_id = b.company_id);
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ; 
 	
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    UPDATE tt_temp_sales_breakdown tmp set tmp.Net_sale =(select IFNULL(Sum(b.tot_charge),0) from unifiedring.ur_device_order_item a 
    join unifiedring.ur_device_order b on a.order_id = b.order_id
    join Product c on c.Product_id = a.Vec_Device_Product_Id
    where  tmp.vendor_id = c.Fk_Vendor_ID
    and tmp.customer_id = b.company_id);
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ; 
 	
 
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    UPDATE tt_temp_sales_breakdown tmp set tmp.tax =(select IFNULL(Sum(b.tot_tax_fee),0) from unifiedring.ur_device_order_item a 
 		   join unifiedring.ur_device_order b on a.order_id = b.order_id
 		   join Product c on c.Product_id = a.Vec_Device_Product_Id
 		   join unifiedring.ur_order_delivery_address d on a.order_id = d.order_id
 		   where  tmp.vendor_id = c.Fk_Vendor_ID
 		   and tmp.customer_id = b.company_id),
    tmp.discount =(select IFNULL(Sum(b.tot_discount),0) from unifiedring.ur_device_order_item a 
 		   join unifiedring.ur_device_order b on a.order_id = b.order_id
 		   join Product c on c.Product_id = a.Vec_Device_Product_Id
 		   join unifiedring.ur_order_delivery_address d on a.order_id = d.order_id
 		   where  tmp.vendor_id = c.Fk_Vendor_ID
 		   and tmp.customer_id = b.company_id),
    tmp.Shipment_cost =(select IFNULL(Sum(d.shipping_charge),0) from unifiedring.ur_device_order_item a 
 		   join unifiedring.ur_device_order b on a.order_id = b.order_id
 		   join Product c on c.Product_id = a.Vec_Device_Product_Id
 		   join unifiedring.ur_order_delivery_address d on a.order_id = d.order_id
    where  tmp.vendor_id = c.Fk_Vendor_ID
    and tmp.customer_id = b.company_id);
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 	
    update tt_temp_sales_breakdown set Net_sale = IFNULL(Net_sale,0) -IFNULL(tax,0) -IFNULL(discount,0) -IFNULL(Shipment_cost,0);
 
 	 
    IF search_type = 1 then
 	 
       set v_sql = 'select * from #temp_sales_breakdown(nolock)
 			where Net_sale' OR search_operator OR CAST(search_value AS CHAR(30)) OR '';
       SET @SWV_Stmt = v_sql;
       PREPARE SWT_Stmt FROM @SWV_Stmt;
       EXECUTE SWT_Stmt;
       DEALLOCATE PREPARE SWT_Stmt;
    end if;
 	 
 	 
    IF search_type = 2 then
 	 
       set v_sql = 'select * from #temp_sales_breakdown(nolock)
 			where Gross_Profit' OR search_operator OR CAST(search_value AS CHAR(30)) OR '';
       SET @SWV_Stmt = v_sql;
       PREPARE SWT_Stmt FROM @SWV_Stmt;
       EXECUTE SWT_Stmt;
       DEALLOCATE PREPARE SWT_Stmt;
    end if;
 	 
    IF search_type = 3 then
 	 
       set v_sql = 'select * from #temp_sales_breakdown(nolock)
 			where Gross_Profit' OR search_operator OR CAST(search_value AS CHAR(30)) OR ' and 
 			Net_sale' OR search_operator OR CAST(search_value AS CHAR(30)) OR '';
       SET @SWV_Stmt = v_sql;
       PREPARE SWT_Stmt FROM @SWV_Stmt;
       EXECUTE SWT_Stmt;
       DEALLOCATE PREPARE SWT_Stmt;
    end if;
 	 
    IF IFNULL(search_type,0) = 0 then
 	 
       select * from tt_temp_sales_breakdown;
    end if;
 	
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `devicemegt_get_vendor_buying_performance` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `devicemegt_get_vendor_buying_performance`(search_type INT,  
  search_operator VARCHAR(50),  
  search_value FLOAT)
BEGIN
  
     DECLARE v_SQL LONGTEXT;  
     
     IF search_type is null then
        set search_type = 0;
     END IF;
     IF search_operator is null then
        set search_operator = '';
     END IF;
     IF search_value is null then
        set search_value = 0;
     END IF;
     IF search_type = 0 then
   
        SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        SELECT a.Product_Id,d.Vendor_name,a.Product_name,c.brand_name,b.name,sum(a.buying_price) as buying_price,a.buying_currency
     , sum(a.qty) as qty	 
        FROM  Product a 
        join Ref_product_Type b on a.Fk_product_type_id = b.product_Type
        join brand c on a.Fk_brand_Id = c.brand_id
        join Vendor d on a.Fk_Vendor_ID = d.Vendor_ID
        group by d.Vendor_name,a.Product_name,c.brand_name,b.name,a.buying_currency,a.Product_Id;
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
     ELSE
        SET v_SQL = 'SELECT a.Product_Id,d.Vendor_name,a.Product_name,c.brand_name,b.name,sum(a.buying_price) as buying_price,a.buying_currency  
    , sum(a.qty) as qty	 
    FROM  Product a  
    join  Ref_product_Type b on a.Fk_product_type_id=b.product_Type  
    join brand c on a.Fk_brand_Id=c.brand_id  
    join  Vendor d on a.Fk_Vendor_ID=d.Vendor_ID   
    WHERE a.buying_price' or search_operator or CAST(search_value AS CHAR(30)) or '  
    group by d.Vendor_name,a.Product_name,c.brand_name,b.name,a.buying_currency,  
    a.Product_Id';
        SET @SWV_Stmt = v_SQL;
        PREPARE SWT_Stmt FROM @SWV_Stmt;
        EXECUTE SWT_Stmt;
        DEALLOCATE PREPARE SWT_Stmt;
     end if;  
    
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `devicemgt_get_product_status` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `devicemgt_get_product_status`()
BEGIN

   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select status_id,status_desc
   from ref_product_status;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `devicemgt_get_purchaed_device_by_orderid` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `devicemgt_get_purchaed_device_by_orderid`(order_id INT)
BEGIN

  
   
   
   CALL unifiedring.devicmgt_get_pur_order_info(order_id);  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `devicemgt_get_purchased_order_list` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `devicemgt_get_purchased_order_list`(
Search_type INT 
)
BEGIN




   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select CAST(a.order_id AS CHAR(30)) as order_no,b.company_name,b.contact_phone,b.email,c.address1 as shipping_address ,
	d.phone_id as product_name,e.sku_code,phone_model,a.tot_phone_charge,d.quantity,a.createdate,a.shipment_date,
	a.dispatch_date,
	case when IFNULL(device_approval,1) = 1 then 'Processing'
   when device_approval = 2 then 'canceled'
   when device_approval = 3 then 'ready to ship'
   when device_approval = 4 then 'Dispatched'
   when device_approval = 5 then 'Delivered'
   when device_approval = 6 then 'Damaged'  end as dev_Status,
	A.delivery_date as delivery_date,
	a.company_id as customer_id,
	IFNULL(b.Hubspot_company_id,0) as Hubspot_company_id
   from ur_device_order a
   join vbcp_company b on a.company_id = b.company_id
   join ur_order_delivery_address c on a.order_id = c.order_id
   join  ur_device_order_item d on a.order_id = d.order_id
   JOIN product e on d.Vec_Device_Product_Id = e.product_id
   WHERE IFNULL(device_approval,1) = CASE WHEN Search_type = 0 THEN IFNULL(device_approval,1)
   ELSE Search_type END;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `devicemgt_get_replacement_order_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `devicemgt_get_replacement_order_info`(status INT,  
replace_id INT)
BEGIN

   IF replace_id is null then
      set replace_id = 0;
   END IF;
   CALL  unifiedring.devicemget_get_replacement_order(status,replace_id);  
   
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `devicemgt_get_replacement_status` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `devicemgt_get_replacement_status`()
BEGIN
   

    
    declare status_id_chk int ;
		set status_id_chk = 0;
    
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;    
    select status_id_chk as status_id,'All' as status_desc
    union
    select status_id,status_desc
    FROM unifiedring.ref_device_replacement_status
    order by  1 asc;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;    
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `devicemgt_get_replace_initiated_orders` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `devicemgt_get_replace_initiated_orders`(
status int,
replace_id int
)
BEGIN
	
    IF replace_id is null then
      set replace_id = 0;
   END IF;
    
	call unifiedring.devicemget_ur_get_replace_initated_order (status,replace_id);
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `devicemgt_get_return_status` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `devicemgt_get_return_status`()
BEGIN
 	
    declare status_id_intchk int;
		set status_id_intchk = 0;
    
 	Select status_id_intchk AS status_id,
 		   'All' AS status_desc
 	UNION 
 	select status_id,status_desc 
 	FROM unifiedring.ref_device_return_status
 	order by status_id asc; 
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `devicemgt_replace_device_check_mac_serial_number` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `devicemgt_replace_device_check_mac_serial_number`(
replacementid INT,
sku_code VARCHAR(150),
mac_address VARCHAR(150),
serial_no VARCHAR(150))
BEGIN


	
	
   CALL unifiedring.devicemgt_ur_check_replacement_mac_serial_number(replacementid,sku_code,mac_address,serial_no);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `devicemgt_return_device_check_mac_serial_number` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `devicemgt_return_device_check_mac_serial_number`(return_id int,
sku_code varchar(150),
mac_address varchar(150),
serial_no varchar(150)
)
BEGIN

	call unifiedring.devicemgt_ur_check_mac_serial_number (return_id,sku_code,mac_address,serial_no);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `devicemgt_update_device_return_status` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `devicemgt_update_device_return_status`(returnid INT,  
status INT)
BEGIN

   DECLARE v_errcode INT;  
   DECLARE v_errmsg VARCHAR(160);  
   
   set v_errcode = -1;  
   set v_errmsg = 'Failure to update the device retrun status';  
   
   UPDATE unifiedring.ur_device_order_return a
   SET a.rtn_status = status
   where a.dr_id = returnid;  
   
   if found_rows()> 0 
   then
      set v_errcode = 0;
      set v_errmsg = 'Success to update thedev';
   end if;  
   

   select  v_errcode as errcode,v_errmsg as  errmsg;  
   
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `devicemgt_update_dispatch_replace_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `devicemgt_update_dispatch_replace_info`(
 replace_id INT,  
 mac_address VARCHAR(50),  
 serial_number VARCHAR(50),  
 status INT,  
 Type INT, 
 shipping_date DATETIME(3),  
 track_number VARCHAR(50),   
 tracking_url VARCHAR(250))
BEGIN
 
   
    
    
    IF track_number is null then
       set track_number = '';
    END IF;
    IF tracking_url is null then
       set tracking_url = '';
    END IF;
    CALL unifiedring.devicemget_update_replacement_dispatch_info(replace_id,mac_address,serial_number,status,Type,shipping_date,
    track_number,tracking_url);  
    
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `devicemgt_update_mac_address_by_orderid` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `devicemgt_update_mac_address_by_orderid`(
order_id INT,
mac_address VARCHAR(150),
serial_number VARCHAR(150))
BEGIN


	
	
   CALL unifiedring.devicemgt_save_mac_address(order_id,mac_address,serial_number);
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `devicemgt_update_replacement_device_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `devicemgt_update_replacement_device_info`(replacementid INT,
sku_code VARCHAR(150),
comments VARCHAR(150),
return_status INT,
return_reason VARCHAR(250), 
Type INT, 
reason_type INT)
BEGIN
	
   IF reason_type is null then
      set reason_type = 0;
   END IF;
   
   CALL unifiedring.devicemgt_ur_update_replacement_device_info(replacementid,sku_code,comments,return_status,return_reason,
   Type,reason_type);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `devicemgt_update_return_device_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `devicemgt_update_return_device_info`(return_id INT,  
 sku_code VARCHAR(150),  
 comments VARCHAR(150),  
 return_status INT,  
 return_reason VARCHAR(250),  
 Type INT,
 return_reason_Type INT 
 )
BEGIN
 
    IF return_reason_Type is null then
       set return_reason_Type = 0;
    END IF;
    
    insert into devicemgt_update_return_device_info_log(return_id,sku_code,comments,return_status,return_reason,Type,return_reason_Type)  
	values(return_id,sku_code,comments,return_status,return_reason,Type,return_reason_Type);  
    
     CALL unifiedring.devicemgt_ur_update_return_device_info(return_id,sku_code,comments,return_status,return_reason,Type,
     return_reason_Type);  
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `devicemgt_update_status_by_orderid` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `devicemgt_update_status_by_orderid`(order_id INT,  
status INT,  
tracking_url VARCHAR(1000),  
tracking_no VARCHAR(50),  
shipment_date DATETIME(3))
BEGIN

  
   
   
   IF tracking_url is null then
      set tracking_url = '';
   END IF;
   IF tracking_no is null then
      set tracking_no = '';
   END IF;
   CALL unifiedring.devicemgt_update_order_status(order_id,status,tracking_url,tracking_no,shipment_date);  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `devicemgt_validate_mac_serial_no` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `devicemgt_validate_mac_serial_no`(mac_address VARCHAR(150),  
serial_no VARCHAR(150))
BEGIN
  
   CALL unifiedring.devicemgt_ur_validate_mac_serial_no(mac_address,serial_no);  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `device_mgt_create_brand` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `device_mgt_create_brand`(
brand_name VARCHAR(150),  
status INT,  
brandid INT,  
create_by VARCHAR(100),  
processtype INT
)
BEGIN

  
   
   
   DECLARE v_errcode INT;   
   DECLARE v_errmsg VARCHAR(160);  
   
   sp_exit:
   BEGIN
      if processtype = 1 then
 
         IF EXISTS(SELECT  1 FROM brand a WHERE a.brand_name = brand_name LIMIT 1) then
  
            SET v_errcode = -1;
            SET v_errmsg = 'Brand Name already Exists!';
            LEAVE SP_EXIT;
         end if;
         INSERT INTO brand(brand_name,status,create_by,create_date)
  VALUES(brand_name,status,create_by,CURRENT_TIMESTAMP);
  
         set brandid = LAST_INSERT_ID();
         if ROW_COUNT() > 0 then
  
            set v_errcode = 0;
            set v_errmsg = 'Success to create brands';
            LEAVE sp_exit;
         end if;
      end if;
      if processtype = 2 then
 
         IF EXISTS(SELECT  1 FROM brand a WHERE a.brand_name = brand_name
         and brand_id <> brandid LIMIT 1) then
  
            SET v_errcode = -1;
            SET v_errmsg = 'Brand Name already Exists!';
            LEAVE SP_EXIT;
         end if;
         IF NOT EXISTS(SELECT  1 FROM brand WHERE  brand_id = brandid LIMIT 1) then
  
            SET v_errcode = -1;
            SET v_errmsg = 'Brand Not Exists';
            LEAVE SP_EXIT;
         end if;
         UPDATE brand a
         SET a.brand_name = brand_name,a.status = status
         WHERE brand_id = brandid;
         if ROW_COUNT() > 0 then
  
            set v_errcode = 0;
            set v_errmsg = 'Success to updte brand';
            LEAVE sp_exit;
         end if;
      end if;
      if processtype = 3 then
 
         IF EXISTS(SELECT  1 FROM Product WHERE  Fk_brand_Id = brandid LIMIT 1) then
  
            SET v_errcode = -1;
            SET v_errmsg = 'Brand already mapped with Product.So delete restricted';
            LEAVE SP_EXIT;
         end if;
         delete from brand where brand_id = brandid;
         if ROW_COUNT() > 0 then
  
            set v_errcode = 0;
            set v_errmsg = 'Success to delete brand';
            LEAVE sp_exit;
         end if;
      end if;
   END;
   select v_errcode as errcode,v_errmsg as errmsg;  
   
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `device_mgt_create_product_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbteam`@`%` PROCEDURE `device_mgt_create_product_info`(
 Product_name	    VARCHAR(160),
 product_desc	    VARCHAR(1000),
 sku_code			VARCHAR(20),
 Fk_product_type_id INT,
 Fk_brand_Id		INT,
 buying_currency    VARCHAR(5),
 buying_price		FLOAT,
 selling_currency   VARCHAR(5),
 selling_price		FLOAT,
 weight			    FLOAT,
 stock              INT,
 status			    INT,
 Fk_Vendor_ID       INT,
 img_path1		    VARCHAR(500),
 img_path2		    VARCHAR(500),
 img_path3		    VARCHAR(500),
 img_path4		    VARCHAR(500),
 img_path5          VARCHAR(500),
 create_by		    VARCHAR(50),
 product_id INT,
 process_Type INT)
BEGIN
 
 
 
 
 
 
    DECLARE v_errcode INT;
    DECLARE v_errmsg VARCHAR(160);
 	
    IF product_id is null then
       set product_id = 0;
    END IF;
    IF process_Type is null then
       set process_Type = 1;
    END IF;
    SP_EXIT:
    BEGIN
       IF product_id is null then
          set product_id = 0;
       END IF;
       IF process_Type is null then
          set process_Type = 1;
       END IF;
       IF process_Type = 1 then
 	
          IF EXISTS(SELECT  1 FROM Product a WHERE a.Product_name = Product_name LIMIT 1) then
 		
             SET v_errcode = -1;
             SET v_errmsg = 'Product Name already Exists!';
             LEAVE SP_EXIT;
          end if;
          IF EXISTS(SELECT  1 FROM Product a WHERE a.sku_code = sku_code LIMIT 1) then
 		
             SET v_errcode = -1;
             SET v_errmsg = 'Product code already Exists!';
             LEAVE SP_EXIT;
          end if;
          INSERT INTO Product(Product_name,product_desc,sku_code,Fk_product_type_id,Fk_brand_Id,
 		buying_currency,buying_price,selling_currency,selling_price,weight,stock,status,
 		Fk_Vendor_ID,img_path1,img_path2,img_path3,img_path4,img_path5,create_date,
 		create_by,qty)
 		VALUES(Product_name,product_desc,sku_code,Fk_product_type_id,Fk_brand_Id,
 		buying_currency,buying_price,selling_currency,selling_price,weight,stock,status,
 		Fk_Vendor_ID,img_path1,img_path2,img_path3,img_path4,img_path5,CURRENT_TIMESTAMP,create_by,
 		stock);
 		
          SET product_id = LAST_INSERT_ID();
          IF ROW_COUNT() > 0 then
 		
             SET v_errcode = 0;
             SET v_errmsg = 'Success to create product';
             LEAVE SP_EXIT;
          end if;
       end if;
       IF process_Type = 2 then
 	
          IF EXISTS(SELECT  1 FROM Product a WHERE a.Product_name = Product_name
          AND Product_Id <> product_id LIMIT 1) then
 		
             SET v_errcode = -1;
             SET v_errmsg = 'Product Name already exist with different Product.';
             LEAVE SP_EXIT;
          end if;
          IF  NOT EXISTS(SELECT  1 FROM Product WHERE  Product_Id = product_id LIMIT 1) then
 		
             SET v_errcode = -1;
             SET v_errmsg = 'Product not exists';
             LEAVE SP_EXIT;
          end if;
          IF EXISTS(SELECT  1 FROM Product a WHERE a.sku_code = sku_code and
          Product_Id <> product_id LIMIT 1) then
 		
             SET v_errcode = -1;
             SET v_errmsg = 'Product code already Exists!';
             LEAVE SP_EXIT;
          end if;
          UPDATE Product a
          SET a.Product_name = Product_name,a.product_desc = product_desc,a.sku_code = sku_code,
          a.Fk_product_type_id = Fk_product_type_id,a.Fk_brand_Id = Fk_brand_Id,
          a.buying_currency = buying_currency,a.buying_price = buying_price,a.selling_currency = selling_currency,
          a.selling_price = selling_price,a.weight = weight,
          a.stock = stock,a.status = status,a.Fk_Vendor_ID = Fk_Vendor_ID,a.img_path1 = img_path1,
          a.img_path2 = img_path2,a.img_path3 = img_path3,a.img_path4 = img_path4,
          a.img_path5 = img_path5,a.last_update = CURRENT_TIMESTAMP,a.last_update_by = create_by,
          a.qty = stock
          WHERE a.Product_Id = product_id;
          IF ROW_COUNT() > 0 then
 		
             SET v_errcode = 0;
             SET v_errmsg = 'Success to update product';
             LEAVE SP_EXIT;
          end if;
       end if;
       IF process_Type = 3 then
 	
          IF  NOT EXISTS(SELECT  1 FROM Product a WHERE  a.Product_Id = product_id LIMIT 1) then
 		
             SET v_errcode = -1;
             SET v_errmsg = 'Product not exists';
             LEAVE SP_EXIT;
          end if;
          
          IF EXISTS(SELECT  1 FROM unifiedring.ur_device_order_item b
          where b.Vec_Device_Product_Id = product_id and b.Vec_Device_Product_Id is not null LIMIT 1) then
 		
             SET v_errcode = -1;
             SET v_errmsg = 'This product already purchased by customer.Not allowed to delete.';
             LEAVE SP_EXIT;
          end if;
          DELETE FROM Product  a WHERE a.Product_Id = product_id;
          IF found_rows() > 0 then
 		
             SET v_errcode = 0;
             SET v_errmsg = 'Success to delete product';
             LEAVE SP_EXIT;
          end if;
       end if;
    END;
    select v_errcode as errcode,v_errmsg as errmsg;
 	
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `device_mgt_create_promotion` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `device_mgt_create_promotion`(product_id INT,
Min_pur_discount FLOAT,
product_Type INT,
Start_date DATETIME(3),
end_date DATETIME(3),
Promo_code VARCHAR(30),
auto_apply INT,
status INT,
calledby VARCHAR(50),
promoid INT ,
process_Type INT)
BEGIN


   DECLARE v_errcode INT;
   DECLARE v_errmsg VARCHAR(160);
	
   IF process_Type is null then
      set process_Type = 1;
   END IF;
   
   SP_EXIT:
   BEGIN
      IF process_Type = 1 then
         IF EXISTS(SELECT  1 FROM Product a WHERE a.Product_Id = product_id LIMIT 1) then
            SET v_errcode = -1;
            SET v_errmsg = 'Please Enter a valid Product';
            LEAVE SP_EXIT;
         end if;
         IF EXISTS(SELECT 1 FROM Promotion_product a WHERE a.Promo_code = Promo_code LIMIT 1) then		
            SET v_errcode = -1;
            SET v_errmsg = 'Promo code already exists.';
            LEAVE SP_EXIT;
         end if;
         
         INSERT INTO Promotion_product(Fk_Product_Id,Min_pur_discount,Fk_Product_Type,
		Start_date,End_date,Promo_code,auto_apply,create_date,create_by,status)
		VALUES(product_id,Min_pur_discount,product_Type,Start_date,end_date,
		Promo_code,auto_apply,CURRENT_TIMESTAMP,calledby,status);
		
          SET Promoid = LAST_INSERT_ID();
         
         IF ROW_COUNT() > 0 then
            SET v_errcode = 0;
            SET v_errmsg = 'Success to create Promotion';
            LEAVE SP_EXIT;
         end if;
      end if;
      
      IF process_Type = 2 then
	
         IF EXISTS(SELECT 1 FROM Promotion_product a WHERE a.Promo_code = Promo_code
         AND a.Promoid <> promoid LIMIT 1) then		
            SET v_errcode = -1;
            SET v_errmsg = 'Promo already exist with different Product.';
            LEAVE SP_EXIT;
         end if;
         IF  NOT EXISTS(SELECT 1 FROM Promotion_product a WHERE  a.Promoid = promoid LIMIT 1) then		
            SET v_errcode = -1;
            SET v_errmsg = 'Promo Not Exists!';
            LEAVE SP_EXIT;
         end if;
         UPDATE Promotion_product a
         SET a.Fk_Product_Id = product_id, a.Min_pur_discount = Min_pur_discount, a.Fk_Product_Type = product_Type,
         a.Start_date = Start_date, a.End_date = end_date, a.Promo_code = Promo_code,
         a.auto_apply = auto_apply, a.status = status, a.last_update = CURRENT_TIMESTAMP,
         a.last_update_by = calledby
         WHERE a.Promoid = promoid;
         IF ROW_COUNT() > 0 then
		
            SET v_errcode = 0;
            SET v_errmsg = 'Success to update Promotion';
            LEAVE SP_EXIT;
         end if;
      end if;
      IF process_Type = 3 then
	
	IF NOT EXISTS(SELECT 1 FROM Promotion_product a WHERE  a.Promoid = promoid LIMIT 1) then
		
            SET v_errcode = -1;
            SET v_errmsg = 'Promo Not Exists!';
            LEAVE SP_EXIT;
         end if;
         DELETE FROM Promotion_product a WHERE a.Promoid = promoid;
         IF ROW_COUNT() > 0 then
		
            SET v_errcode = 0;
            SET v_errmsg = 'Success to delete Promotion';
            LEAVE SP_EXIT;
         end if;
      end if;
   END;
   select v_errcode as errcode,v_errmsg as errmsg;
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `device_mgt_create_vendor` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `device_mgt_create_vendor`(Vendor_name VARCHAR(150),  
status INT,  
email_id VARCHAR(150),  
phoneno VARCHAR(20),  
location VARCHAR(500),  
create_by VARCHAR(50),  
vendor_id INT,  
processtype INT
)
BEGIN

   DECLARE v_errcode INT;   
   DECLARE v_errmsg VARCHAR(160);  
   
   sp_exit:BEGIN
   
      if processtype = 1 
      then
         IF EXISTS(SELECT  1 FROM  Vendor a WHERE a.Vendor_name = Vendor_name LIMIT 1) 
         then
            SET v_errcode = -1;
            SET v_errmsg = 'Vendor name already Exists!';
            LEAVE SP_EXIT;
         end if;
         
         INSERT INTO Vendor(Vendor_name,email_id,phoneno,location,status,create_date,create_by)
  VALUES(Vendor_name,email_id,phoneno,location,status,CURRENT_TIMESTAMP,create_by);
  
         set vendor_id = LAST_INSERT_ID();
         
         if ROW_COUNT() > 0 
         then
            set v_errcode = 0;
            set v_errmsg = 'Success to create Vendors';
            LEAVE sp_exit;
         end if;
      end if;
      
      if processtype = 2 
      then
         IF EXISTS(SELECT  1 FROM Vendor a WHERE a.Vendor_name = Vendor_name
         and a.Vendor_ID <> vendor_id LIMIT 1) 
         then
            SET v_errcode = -1;
            SET v_errmsg = 'Vendor Name already Exists';
            LEAVE SP_EXIT;
         end if;
         
         IF NOT EXISTS(SELECT  1 FROM Vendor a WHERE  a.Vendor_ID = vendor_id LIMIT 1) 
         then
            SET v_errcode = -1;
            SET v_errmsg = 'Vendor Name Not Exists';
            LEAVE SP_EXIT;
         end if;
         
         UPDATE Vendor a SET a.Vendor_name = Vendor_name,a.email_id = email_id,a.phoneno = phoneno,a.location = location,
         a.status = status,a.last_update = CURRENT_TIMESTAMP,a.last_update_by = create_by
         WHERE a.Vendor_ID = vendor_id;
         
         if ROW_COUNT() > 0 
         then
            set v_errcode = 0;
            set v_errmsg = 'Success to update Vendor';
            LEAVE sp_exit;
         end if;
      end if;
      
      if processtype = 3 
      then
         IF EXISTS(SELECT  1 FROM Product b WHERE  b.Fk_Vendor_ID = vendor_id LIMIT 1) 
         then
            SET v_errcode = -1;
            SET v_errmsg = 'Vendor already mapped with Product.So delete restricted';
            LEAVE SP_EXIT;
         end if;
         
         delete from Vendor a where a.Vendor_ID = vendor_id;
         
         if ROW_COUNT() > 0 
         then
            set v_errcode = 0;
            set v_errmsg = 'Success to delete Vendor';
            LEAVE sp_exit;
         end if;
      end if;
   END;
   select v_errcode as errcode,v_errmsg as errmsg;  
   
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `device_mgt_get_brand` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `device_mgt_get_brand`(brand_id INT)
begin
   
    
    
    IF (brand_id is null or brand_id = '') then
       set brand_id = 0;
    END IF;
    
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select a.brand_id,brand_name,status
    from brand a
    where ((brand_id = 0) OR (a.brand_id = brand_id));
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
    
    
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `device_mgt_get_product_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `device_mgt_get_product_info`(
 product_id INT,
 vendor_id INT,
 brand_id INT,
 stock_qty_filter INT,
 status VARCHAR(250))
BEGIN
	
 		
    IF (stock_qty_filter is null or stock_qty_filter = '') then set stock_qty_filter = 0; END IF;
    IF status is null then set status = ''; END IF;
    
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    SELECT a.Product_Id,Product_name,product_desc,sku_code,Fk_product_type_id,
 		Fk_brand_Id,buying_currency,buying_price,selling_currency,
 		selling_price,weight,stock,a.status,Fk_Vendor_ID,img_path1,
 		img_path2,img_path3,img_path4,img_path5,
 		b.name as product_type_desc,c.brand_name as brand_desc,
 		d.Vendor_name,
 		case when a.status = 1 and  IFNULL(stock,0) > 0 then 'Active'
    when a.status = 0 then 'InActive'
    when a.status = 2 then 'Discontinued'
    when a.status = 1 and IFNULL(stock,0) = 0 then 'Stockout' end as status_description,
 			 a.create_date,
 			a.last_update
    FROM Product a
    LEFT JOIN  Ref_product_Type b on a.Fk_product_type_id = b.product_Type
    LEFT JOIN brand c on a.Fk_brand_Id = c.brand_id
    LEFT JOIN Vendor d on a.Fk_Vendor_ID = d.Vendor_ID
    WHERE ((product_id = 0) or (a.Product_Id = product_id)) and
 	 ((IFNULL(vendor_id,0) = 0) or (a.Fk_Vendor_ID = vendor_id)) and
 	 ((IFNULL(brand_id,0) = 0) or (a.Fk_brand_Id = brand_id)) and
 	 ((IFNULL(stock_qty_filter,0) = 0) OR (a.stock <= stock_qty_filter)) AND
 	 ( (IFNULL(status,'') = '') OR  (status = case when a.status = 1 and  IFNULL(stock,0) > 0 then 'Active'
    when a.status = 0 then 'InActive'
    when a.status = 2 then 'Discontinued'
    when a.status = 1 and IFNULL(stock,0) = 0 then 'Stockout' end));
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 	 
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `device_mgt_get_product_Type` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `device_mgt_get_product_Type`()
BEGIN

   SELECT a.product_Type,a.name FROM Ref_product_Type a
   ORDER BY a.name ASC;   
   
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `device_mgt_get_purchased_orde_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `device_mgt_get_purchased_orde_info`(
Search_type INT 
)
BEGIN


	
	
   CALL unifiedring.devicemgt_get_purchased_order_list(Search_type);
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `device_mgt_get_returned_product_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `device_mgt_get_returned_product_info`(
Search_type INT ,
retrun_id INT)
BEGIN


	
	
   IF retrun_id is null then
      set retrun_id = 0;
   END IF;
   CALL unifiedring.devicemgt_get_returned_product_list(Search_type,retrun_id);
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `device_mgt_get_vendor` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `device_mgt_get_vendor`(vendor_id INT,  
status INT)
begin

   IF vendor_id is null then
      set vendor_id = 0;
   END IF;
   IF status is null then
      set status = 0;
   END IF;
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select a.Vendor_ID,a.Vendor_name,a.status,a.email_id,
  a.phoneno,a.location,a.last_update as last_update,
  case when a.status = 1 then 'Active'
   when a.status = 2 then 'Discontinued' end as status_desc
   from Vendor a
   where ((vendor_id = 0) OR (a.Vendor_ID = vendor_id)) and
    ((status = 0) or (a.status = status));
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
   
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `device_mgt_product_promotion` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `device_mgt_product_promotion`(promoid INT,  
status INT 
)
BEGIN

  
   
   
   IF promoid is null then
      set promoid = 0;
   END IF;
   IF status is null then
      set status = -1;
   END IF;
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select Promoid,a.Fk_Product_Id as product_id,b.Product_name,b.sku_code,
 c.name as product_Type_name,c.product_Type as product_Type_id,
 a.Start_date,a.End_date,a.Promo_code,a.auto_apply,a.status,a.create_date,
 a.create_by,a.last_update,a.last_update_by,
 case when a.status = 1 and End_date >= CURRENT_TIMESTAMP  then 'Active'
   when  End_date <= CURRENT_TIMESTAMP then 'Expired' end as status_Desc  from Promotion_product a 
   JOIN Product b on a.Fk_Product_Id = b.product_id
   JOIN  Ref_product_Type c on a.Fk_Product_Type = c.product_Type
   Where ( (promoid = 0) OR (a.Promoid = promoid));
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `device_mgt_update_stock_product` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `device_mgt_update_stock_product`(product_id INT,  
 qty INT,  
 Type INT)
BEGIN
 
    IF Type is null then
       set Type = 1;
    END IF;
    
    IF Type = 1 
    then
       Update Product a set a.stock = a.stock - qty
       where a.Product_Id = product_id;
    end if;  
    
    IF Type = 2 
    then
       Update Product a set a.stock = a.stock + qty
       where a.Product_Id = product_id;
    end if;  
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `device_mgt_upload_bulk_vendor` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `device_mgt_upload_bulk_vendor`(
  vendor_xml LONGTEXT,
  create_by VARCHAR(50))
BEGIN
 
 	 
 
 
  
     DECLARE v_errcode INT;
     DECLARE v_errmsg VARCHAR(160);
 	
     declare v_Vendor_name longtext;
 	declare v_email_id longtext;
 	declare v_phoneno longtext;
 	declare v_location longtext;
 
        SET v_errcode = -1;
        SET v_errmsg = '';
  	
     SP_EXIT:
     BEGIN
        DROP TEMPORARY TABLE IF EXISTS tt_temp_vendor;
        create TEMPORARY table tt_temp_vendor
        (
           Vendor_name VARCHAR(150),
           email_id VARCHAR(150),
           phoneno VARCHAR(20),
           location VARCHAR(500)
        );
        
 
 drop temporary table if exists xml_Vendor_name_tbl; create temporary table xml_Vendor_name_tbl( id int auto_increment primary key,Vendor_name longtext);
 drop temporary table if exists xml_email_id_tbl; create temporary table xml_email_id_tbl( id int auto_increment primary key,email_id longtext);
 drop temporary table if exists xml_phoneno_tbl; create temporary table xml_phoneno_tbl( id int auto_increment primary key,phoneno longtext);
 drop temporary table if exists xml_location_tbl; create temporary table xml_location_tbl( id int auto_increment primary key,location longtext);
 
 
  SELECT replace(ExtractValue(vendor_xml, '//Vendor_name[1]'),' ',','), 
        replace(ExtractValue(vendor_xml, '//email_id[1]'),' ',','), 
 	   replace(ExtractValue(vendor_xml, '//phoneno[1]'),' ',','),
 	   replace(ExtractValue(vendor_xml, '//location[1]'),' ',',')
 	   into v_Vendor_name,v_email_id,v_phoneno,v_location;
 
   call unifiedring.Split(v_Vendor_name,','); insert into xml_Vendor_name_tbl(Vendor_name) select Items from unifiedring.tt_Split_temptable;
   call unifiedring.Split(v_email_id,','); insert into xml_email_id_tbl(email_id) select Items from unifiedring.tt_Split_temptable;
   call unifiedring.Split(v_phoneno,','); insert into xml_phoneno_tbl(phoneno) select Items from unifiedring.tt_Split_temptable;
   call unifiedring.Split(v_location,','); insert into xml_location_tbl(location) select Items from unifiedring.tt_Split_temptable;
 
   insert into tt_temp_vendor(Vendor_name,email_id,phoneno,location)
   select Vendor_name,email_id,phoneno,location 
   from xml_Vendor_name_tbl a 
   left join xml_email_id_tbl b on a.id = b.id
   left join xml_phoneno_tbl c on a.id = c.id
   left join xml_location_tbl d on a.id = d.id;
        
  
        
        IF EXISTS(SELECT 1 FROM tt_temp_vendor a
        join Vendor b on a.Vendor_name = b.Vendor_name LIMIT 1) then
  	
           SET v_errcode = -1;
           SET v_errmsg = 'Vendor Name already exists';
           LEAVE SP_EXIT;
        end if;
 
        INSERT INTO Vendor(Vendor_name,email_id,phoneno,location,create_date,create_by,status)
        select Vendor_name,email_id,phoneno,location,CURRENT_TIMESTAMP,create_by,1  
        from tt_temp_vendor a;
        
        IF found_rows() > 0 then
  		
           SET v_errcode = 0;
           SET v_errmsg = 'Success to create Vendor';
           LEAVE SP_EXIT;
        end if;
     END;
     select v_errcode as errcode,v_errmsg as errmsg;
  	
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `device_mgt_vaidate_promo_code` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `device_mgt_vaidate_promo_code`(promocode VARCHAR(30))
BEGIN

   DECLARE v_errcode INT; 
   DECLARE v_errmsg VARCHAR(160);
	
   set v_errcode = 0;
   set v_errmsg = 'Promo code valid';
	
   IF EXISTS(SELECT  1 FROM Promotion_product a where a.Promo_code = promocode LIMIT 1) then
	
      set v_errcode = -1;
      set v_errmsg = 'Promo code already Exists!';
   end if;
	
   select v_errcode as errcode, v_errmsg as errmsg;
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `device_mgt_validate_user_login` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `device_mgt_validate_user_login`(username VARCHAR(50),  
   password VARCHAR(50),  
   loginip VARCHAR(50))
BEGIN
  
      
      DECLARE v_errcode INT;   
      DECLARE v_errmsg VARCHAR(160);  
      DECLARE v_roleid INT;	 DECLARE v_roleid_intchk INT;      
      DECLARE v_userid INT;   DECLARE v_userid_intchk INT;   
      
      set v_roleid_intchk = 0;
      set v_userid_intchk = 0;
      
      sp_exit:
      BEGIN
         SET v_errcode = -1;
         SET v_errmsg = '';
         
         IF NOT EXISTS(SELECT  1 FROM User A WHERE A.Username = username LIMIT 1) then
    
            SET v_errcode = -1;
            SET v_errmsg = 'User Name is invalid!';
            LEAVE sp_exit;
         end if;
         IF  EXISTS(SELECT  1 FROM User a WHERE a.Username = username and a.status = 0 LIMIT 1) then
    
            SET v_errcode = -1;
            SET v_errmsg = 'User was blocked!Please contact administrator';
            LEAVE sp_exit;
         end if;
         
         IF  EXISTS(SELECT  1 FROM User a WHERE a.Username = username AND a.password <> password LIMIT 1) then
    
            SET v_errcode = -1;
            SET v_errmsg = 'Invalid Password';
            LEAVE sp_exit;
         end if;
         
         IF  EXISTS(SELECT  1 FROM User a WHERE a.Username = username AND password = password LIMIT 1) then
    
            UPDATE User a SET a.last_login_ip = loginip,a.last_login_date = CURRENT_TIMESTAMP,
            a.userid = UserId WHERE a.Username = username AND a.password = password;
            
            select a.Fk_Role_id,a.UserId into v_roleid,v_userid
            from User a
            where a.Username = username AND a.password = password;
            
            SET v_errcode = 0;
            SET v_errmsg = 'Success';
            LEAVE sp_exit;
         end if;
         
      END;
      select v_errcode as errcode, v_errmsg as errmsg,IFNULL(v_roleid,v_roleid_intchk) as roleid,IFNULL(v_userid,v_userid_intchk) as userid;  
      
   END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `devicmgt_get_assigned_deivce_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `devicmgt_get_assigned_deivce_details`(
order_id INT,
type INT,
Search_status INT)
begin


	
	
   IF order_id is null then
      set order_id = 0;
   END IF;
   IF type is null then
      set type = 1;
   END IF;
   IF Search_status is null then
      set Search_status = 0;
   END IF;
   CALL unifiedring.devicmgt_get_assigned_deivce_info(order_id,type,Search_status);
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ur_app_update_profile_image_ulr` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ur_app_update_profile_image_ulr`(company_id INT,  
extension INT,  
profile_image_url VARCHAR(250),  
type INT)
begin 
  
   DECLARE v_errcode INT DEFAULT -1;
   DECLARE v_errmsg VARCHAR(30) DEFAULT 'failure';  
   DECLARE v_dir_user_id INT;
   DECLARE v_domain_id INT;  
  
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   a.domain_id INTO v_domain_id from  vbcp_pbx_account a where a.company_id = company_id;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
  
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   b.id INTO v_dir_user_id from dir_users b where b.domain_id = v_domain_id and b.user_id = extension;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
  
   if type = 1 
   then
      UPDATE ur_app_login_details l set l.profile_image_url = profile_image_url 
      where l.company_id = company_id and l.dir_user_id = v_dir_user_id;
   else 
      if type = 2 
      then
         UPDATE ur_app_login_details l set l.profile_image_url = null 
         where l.company_id = company_id and l.dir_user_id = v_dir_user_id;
      end if;
   end if;  
  
   if ROW_COUNT() > 0 
   then 
      SET v_errcode = 0;
      SET v_errmsg = 'success';
   end if;  
  
   select v_errcode errcode,v_errmsg errmsg;   
  
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ur_crm_portal_get_new_plan_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ur_crm_portal_get_new_plan_info`(company_id INT,  
plan_duration_input INT,  
no_of_user INT)
Begin
  
   DECLARE v_plan_id INT;
   DECLARE v_plan_duration INT;
   DECLARE v_PC_Price FLOAT;  
   DECLARE v_is_free_trial INT;   
   DECLARE v_plan_price FLOAT;   
   DECLARE v_product_id INT;
   DECLARE v_range_id INT;   
  
   IF plan_duration_input is null 
   then
      set plan_duration_input = 0;
   END IF;
   
   IF no_of_user is null 
   then
      set no_of_user = 0;
   END IF;
   
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   b.plan_duration, b.plan_price, b.plan_id, IFNULL(b.Is_free_trail,0), IFNULL(b.product_id,0) 
   INTO v_plan_duration,v_PC_Price,v_plan_id,v_is_free_trial,v_product_id 
   from  ur_company_plan b  where b.company_id = company_id;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;   
  
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   a.PC_Price INTO v_plan_price from   UR_ECom_Plan_Cost a
   where a.PC_Plan = v_plan_id and a.PC_Product = v_product_id;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;   
  
   IF IFNULL(plan_duration_input,0) > 0 
   then
      SET v_plan_duration = plan_duration_input;
   end if;  
  
   DROP TEMPORARY TABLE IF EXISTS tt_temp_ur_plan_info;  
  
   create TEMPORARY table tt_temp_ur_plan_info
   (
      Pln_Idx INT,
      New_plan VARCHAR(250),
      Pln_Name VARCHAR(250),
      pc_price VARCHAR(4000),
      pc_duration INT,
      yearly_monthly_Duration VARCHAR(10),
      Range_typeid INT,
      is_reseller INT,
      view_order INT,
      discount FLOAT
   );  
   
   
   IF IFNULL(v_is_free_trial,0) = 1 
   then
   insert into tt_temp_ur_plan_info(Pln_Idx,New_plan,Pln_Name,pc_price,pc_duration,yearly_monthly_Duration,
 Range_typeid,is_reseller,view_order,discount)
      select  b.Pln_Idx,CONCAT(b.Pln_Name,' ',cast(a.pc_price as CHAR(30)),' ',case when a.pc_duration = 1 then 'Monthly'
      when a.pc_duration in(6,12) then 'Yearly'   	
      end) as New_plan,b.Pln_Name,new_price_combined pc_price,a.pc_duration,
       case when a.yearly_monthly_Duration = 0 and a.pc_duration = 1 then 'M'
      when a.yearly_monthly_Duration = 0 and a.pc_duration in(12) then 'Y'
      when a.yearly_monthly_Duration = 1 and a.pc_duration = 12 then 'YM' end as yearly_monthly_Duration,
       a.Range_typeid,
       IFNULL(a.is_reseller,0) as is_reseller,
       b.view_order,
       case when a.yearly_monthly_Duration = 1 and a.PC_Duration = 12 THEN a.monthly_yearly_discount
      when a.yearly_monthly_Duration = 0 and a.PC_Duration = 12 THEN yearly_discount
      When a.PC_Duration = 24 THEN two_year_monthly_discount
      When a.PC_Duration = 36 THEN three_year_monthly_discount end
      from  UR_ECom_Plan_Cost a join  UR_ECom_Plan b on a.PC_Plan = b.Pln_Idx
      where b.Pln_Name is not null and b.pln_status = 1 and a.PC_Duration = v_plan_duration
      and IFNULL(a.is_reseller,0) = 0
      order by IFNULL(b.view_order,0) asc;
   ELSE
 insert into tt_temp_ur_plan_info(Pln_Idx,New_plan,Pln_Name,pc_price,pc_duration,yearly_monthly_Duration,
 Range_typeid,is_reseller,view_order,discount)
      select  b.Pln_Idx,CONCAT(b.Pln_Name,' ',cast(a.pc_price as CHAR(30)),' ',case when a.pc_duration = 1 then 'Monthly'
      when a.pc_duration in(6,12) then 'Yearly'          
      end) as New_plan,b.Pln_Name,a.new_price_combined pc_price,a.pc_duration,
       case when a.yearly_monthly_Duration = 0 and a.pc_duration = 1 then 'M'
      when a.yearly_monthly_Duration = 0 and a.pc_duration in(12) then 'Y'
      when a.yearly_monthly_Duration = 1 and a.pc_duration = 12 then 'YM' end as yearly_monthly_Duration,
       a.Range_typeid,
        IFNULL(a.is_reseller,0) as is_reseller,
         b.view_order,
       case when a.yearly_monthly_Duration = 1 and a.PC_Duration = 12 THEN a.monthly_yearly_discount
      when a.yearly_monthly_Duration = 0 and a.PC_Duration = 12 THEN yearly_discount
      When a.PC_Duration = 24 THEN two_year_monthly_discount
      When a.PC_Duration = 36 THEN three_year_monthly_discount end
      from UR_ECom_Plan_Cost a join UR_ECom_Plan b on a.PC_Plan = b.Pln_Idx
      where b.Pln_Name is not null and b.pln_status = 1 and a.PC_Duration = v_plan_duration  
 
      and IFNULL(is_reseller,0) = 0
      order by IFNULL(b.view_order,0) asc,b.Pln_Name,a.pc_duration;
   end if;  
   
   IF IFNULL(no_of_user,0) > 0 
   then    
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select   A.Range_typeid INTO v_range_id from UR_ECom_User_Range_Master_Detail A
      where no_of_user  between  A.From_user_Range and IFNULL(A.To_user_Range,no_of_user);
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      Select b.Pln_Idx,b.New_plan,b.Pln_Name,cast(a.price as CHAR(30)) as pc_price,b.pc_duration,b.yearly_monthly_Duration,
   b.is_reseller,IFNULL(b.discount,0) as discount
      from  UR_ECom_Plan_User_Range_Price a
      join tt_temp_ur_plan_info b on a.PC_Plan = b.Pln_Idx and a.typeid = v_range_id
      where a.Duration = plan_duration_input
      order by IFNULL(b.view_order,'') asc;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   ELSE
      Select Pln_Idx,New_plan,Pln_Name,pc_price,pc_duration,yearly_monthly_Duration ,
  is_reseller,view_order,IFNULL(discount,0) as discount
      from tt_temp_ur_plan_info
      order by IFNULL(view_order,'') asc;
   end if;  
   
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UR_ecom_Get_tier_pricing_range_user_info_7` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `UR_ecom_Get_tier_pricing_range_user_info_7`(
          Duration INT, 
          reseller_id INT,
          is_free_trial int,
          purpose_id varchar(250)
          )
SWL_return:
             Begin
                DECLARE v_is_reseller_plan INT; 
                DECLARE v_role_id INT; 
                DECLARE Default_int_val int;
                
                set Default_int_val = 0 ;
                
                drop temporary table if exists ref_purpose_id;
                create temporary table ref_purpose_id
                (
                purpose_id int primary key
                );
                
                call Split(purpose_id,',');
                
                insert into ref_purpose_id(purpose_id)
                select items from tt_Split_temptable;
                
                IF reseller_id is null then set reseller_id = 0; END IF;
                IF is_free_trial is null then set is_free_trial = 0; END IF;
                
                IF IFNULL(reseller_id,0) > 0 then 
                   select fk_role_id INTO v_role_id FROM smereseller.Reseller a where a.Reseller_id = reseller_id;
                   SET v_is_reseller_plan = 1;
                end if;
                
                set v_is_reseller_plan = IFNULL(v_is_reseller_plan,0);
                
        			DROP temporary TABLE IF EXISTS tt_temp_plan_info;
    				CREATE temporary TABLE tt_temp_plan_info as   
    				select distinct a.fk_tier_id as plan_id,a.tier_name as plan_name,b.fk_contract_period_id as Duration,b.price1 as PC_Price,
    						case when c.cop_id = 5 THEN 'Yearly Plan'When c.cop_id = 1 THEN 'Monthly Plan'When c.cop_id = 6 THEN 'Two Year Plan'When c.cop_id = 7 THEN 'Three Year Plan' end as plan_Type,
                            b.discount1 as Discount,
    						case when a.free_or_paid = 1 then 1 else  0 end as is_free_trial,0 as most_popular,wtms.getplan_summarynotes(a.fk_tier_id) as plan_notes,
                            d.nof_from as From_user_Range,d.nof_to as To_user_Range,0 as is_reseller,0 as view_order,
    						IFNULL(b.min_user,Default_int_val) as min_user
    				from wtms.wtms_copy_of_tier_management_temp a 
    				inner join wtms.wtms_contract_pricing_dtl b on a.fk_tier_id = b.tier_id
    				inner join wtms.wtms_contract_period_master c on c.cop_id=b.fk_contract_period_id
    				inner join wtms.wtms_no_of_users_master d on b.fk_user_type_id = d.nof_id
                  left join wtms.wtms_tier_reseller_info m on a.fk_tier_id = m.tier_id
    				where c.cop_id= Duration and a.is_review = 3
    			
                    and (a.fk_purpose_id in (select z.purpose_id from ref_purpose_id z) or ifnull(purpose_id,'')= '');
    				
                
    				if IFNULL(v_is_reseller_plan,0) = 1 then
						select 	s.plan_id,s.plan_name,s.Duration,s.From_user_Range,s.To_user_Range,s.PC_Price as PC_Price,s.plan_Type,
    							Default_int_val as Discount,s.is_free_trial,s.most_popular,s.plan_notes,s.free_trial_days,s.is_reseller,s.view_order,
    							yearly_monthly_Duration,ifnull(min_user,Default_int_val) as min_user 
    					from tt_temp_plan_info s
    					join sme_plan_Show_info b on s.Plan_Id = b.Plan_Id
    					where b.duration = Duration and s.plan_id in (select e.Plan_Id from sme_plan_member_Type e join ref_Member_type b on e.Member_type = b.id where s.Plan_Id = e.Plan_Id  and b.role_id = v_role_id)
    					and IFNULL(is_reseller,0) = 1
    					and plan_Type=case when Duration=12 then 'Yearly Plan' else plan_Type end 
                        
    					union
                        
    					select 	a.plan_id,a.plan_name,a.Duration,a.From_user_Range,a.To_user_Range,a.PC_Price as PC_Price,a.plan_Type,
    							a.Discount,a.is_free_trial,a.most_popular,a.plan_notes,a.free_trial_days,a.is_reseller,a.view_order,
    							0 as yearly_monthly_Duration,ifnull(min_user,Default_int_val) as min_user
    					from tt_temp_plan_info a 
                        where IFNULL(is_reseller,0) = 0
    					and plan_Type=case when Duration=12 then 'Yearly Plan' else plan_Type end 
    					order by  is_reseller asc,view_order asc;
                        
    					LEAVE SWL_return;
                        
    				end if;
    					select * from tt_temp_plan_info
    					WHERE plan_Type=case when Duration=12 then 'Yearly Plan' else plan_Type end 
    					order by  is_reseller asc,view_order asc;
    
             END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ur_myaccount_get_product_list` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ur_myaccount_get_product_list`(product_name VARCHAR(150),  
 product_id INT)
BEGIN
 
 if product_name = ''
 then
 set product_name = null;
 end if;
 if product_id = ''
 then
 set product_id = null;
 end if;
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select a.product_id,a.sku_code,a.product_name,b.product_Type as product_Type_id,
  null as inventory_id,NULL AS prod_model,c.brand_name,
  a.weight,stock as qty,a.selling_price,null,a.product_desc,
  IFNULL(a.img_path1,'') as img_path1,IFNULL(a.img_path2,'') as img_path2,
  IFNULL(a.img_path3,'') as img_path3,IFNULL(a.img_path4,'') as img_path4,
  'Vectone'
    from  Product a
    join Ref_product_Type b on a.Fk_product_type_id = b.product_Type
    join brand c on a.Fk_brand_Id = c.brand_id;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
    
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-21  9:50:28
