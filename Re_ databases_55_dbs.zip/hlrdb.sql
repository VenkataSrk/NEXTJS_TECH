-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: hlrdb
-- ------------------------------------------------------
-- Server version	8.0.44-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `CALLFORWARD_BLACKLIST`
--

DROP TABLE IF EXISTS `CALLFORWARD_BLACKLIST`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CALLFORWARD_BLACKLIST` (
  `SITECODE` varchar(5) NOT NULL,
  `IMSITYPE` int NOT NULL,
  `PREFIX` varchar(15) NOT NULL,
  `PREFIX_END` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`SITECODE`,`IMSITYPE`,`PREFIX`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `CallForward`
--

DROP TABLE IF EXISTS `CallForward`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CallForward` (
  `IMSI` char(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `CFWType` int NOT NULL,
  `ProvisionState` int NOT NULL,
  `NotifToCalling` int DEFAULT NULL,
  `Presentation` int DEFAULT NULL,
  `NotifToFwding` int DEFAULT NULL,
  PRIMARY KEY (`IMSI`,`CFWType`),
  KEY `CFWType_CallForward_FK1Idx` (`CFWType`),
  KEY `IMSI_CallForward_FK1Idx` (`IMSI`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `CallForwarddelete` AFTER DELETE ON `CallForward` FOR EACH ROW SWL_return:
BEGIN

   DECLARE v_errorNumber INT;
   DECLARE v_errorMsg VARCHAR(255);
  
   DELETE FROM CallForward_BSG
   WHERE CallForward_BSG.IMSI = OLD.IMSI and
   CallForward_BSG.CFWType = OLD.CFWType;
   LEAVE SWL_return;
   SET @SWV_Error = v_errorNumber;
   
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `CallForward_BSG`
--

DROP TABLE IF EXISTS `CallForward_BSG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CallForward_BSG` (
  `IMSI` char(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `CFWType` int NOT NULL,
  `ActivationState` int DEFAULT NULL,
  `RegistrationState` int DEFAULT NULL,
  `HLRInductionState` int DEFAULT NULL,
  `ForwardToNb` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `Subaddress` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `NoReplyTimer` int DEFAULT NULL,
  `ServiceCode` int NOT NULL,
  `ServiceType` int NOT NULL,
  PRIMARY KEY (`IMSI`,`CFWType`,`ServiceCode`,`ServiceType`),
  CONSTRAINT `CallForward_CallForward_BSG_new_FK` FOREIGN KEY (`IMSI`, `CFWType`) REFERENCES `CallForward` (`IMSI`, `CFWType`) ON UPDATE CASCADE
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `IMSI`
--

DROP TABLE IF EXISTS `IMSI`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `IMSI` (
  `ICCID` char(20) NOT NULL,
  `IMSI` char(15) NOT NULL,
  `PLMNID` int NOT NULL,
  `MCC` char(3) DEFAULT NULL,
  `MNC` char(2) DEFAULT NULL,
  `MSIN` char(10) DEFAULT NULL,
  `AccessMode` int NOT NULL,
  `LMSI` char(8) DEFAULT NULL,
  `LMUID` char(15) DEFAULT NULL,
  `MultiISDNFlag` int NOT NULL,
  `BasicMSISDN` varchar(25) DEFAULT NULL,
  `AlertMSISDN` varchar(25) DEFAULT NULL,
  `TransferSMMode` int DEFAULT NULL,
  `MobilityMgtState` int DEFAULT NULL,
  `MSPurgedG` int DEFAULT NULL,
  `MSPurgedNonG` int DEFAULT NULL,
  `CheckSS` int DEFAULT NULL,
  `Ki` varchar(32) DEFAULT NULL,
  `IncomingBarredFlag` int DEFAULT NULL,
  `FirstAuthentication` datetime(3) DEFAULT NULL,
  `IMSItype` int DEFAULT NULL,
  `BasicMSISDN_value` varchar(15) DEFAULT NULL,
  `date_updated` datetime(3) DEFAULT NULL,
  `updated_by` varchar(30) DEFAULT NULL,
  `CamelCapabilityHandling` int DEFAULT NULL,
  `FallbackOption` int DEFAULT NULL,
  `ExistOCSI` int DEFAULT '0',
  `FirstGPRSUpdate` datetime(3) DEFAULT NULL,
  `cb_password` varbinary(255) DEFAULT NULL,
  `cb_wrong_counter` int NOT NULL DEFAULT '0',
  `CSI_Subscription_Id` int DEFAULT NULL,
  `gprs_subscription_id` int DEFAULT NULL,
  `auth_version` int DEFAULT '3',
  `seqNB` bigint DEFAULT NULL,
  `op_ID` int DEFAULT NULL,
  `lastGPRSUpdate` datetime(3) DEFAULT NULL,
  `default_gprs_subscription_id` int DEFAULT NULL,
  `seqNB_input` bigint DEFAULT NULL,
  PRIMARY KEY (`IMSI`),
  KEY `idx_basicmsisdn_value` (`BasicMSISDN_value`,`PLMNID`,`ICCID`),
  KEY `idx_imsitype` (`IMSItype`),
  KEY `idx_msisdn` (`BasicMSISDN`),
  KEY `idx_msisdn2` (`AlertMSISDN`),
  KEY `imsi_idx_BasicMSISDN_value` (`BasicMSISDN_value`),
  KEY `imsi_idx_BasicMSISDN_value_imsitype` (`BasicMSISDN_value`,`IMSItype`),
  KEY `imsi_idx_iccid` (`ICCID`),
  KEY `imsi_idx_iccid_imsitype` (`ICCID`,`IMSItype`),
  KEY `imsi_msin_imsitype_idx` (`MSIN`,`IMSItype`),
  KEY `PLMN_IMSI_new_FK1` (`PLMNID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `MSISDN`
--

DROP TABLE IF EXISTS `MSISDN`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MSISDN` (
  `MSISDN` varchar(15) NOT NULL,
  `ICCID` char(20) DEFAULT NULL,
  `BCASetID` int DEFAULT NULL,
  `ispool` int DEFAULT NULL,
  PRIMARY KEY (`MSISDN`),
  KEY `msisdn_iccid` (`ICCID`),
  KEY `msisdn_idx_iccid_ispool` (`ICCID`,`ispool`),
  KEY `BCASet_Ref_MSISDN_FK1` (`BCASetID`),
  CONSTRAINT `BCASet_Ref_MSISDN_FK1` FOREIGN KEY (`BCASetID`) REFERENCES `BCASet_Ref` (`BCASetID`),
  CONSTRAINT `SIM_MSISDN_FK1` FOREIGN KEY (`ICCID`) REFERENCES `SIM` (`ICCID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `MSISDN_POOL`
--

DROP TABLE IF EXISTS `MSISDN_POOL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MSISDN_POOL` (
  `MSISDN` varchar(15) NOT NULL,
  `IMSI` char(20) DEFAULT NULL,
  `ICCID` char(20) DEFAULT NULL,
  `status` int DEFAULT NULL,
  `sitecode` varchar(5) DEFAULT NULL,
  `lastAssigned` datetime(3) DEFAULT NULL,
  `lastUpdated` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`MSISDN`),
  KEY `msisdn_pool_idx1` (`IMSI`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ODBGPRS`
--

DROP TABLE IF EXISTS `ODBGPRS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ODBGPRS` (
  `IMSI` char(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `OutgoingG` int DEFAULT NULL,
  `Roaming` int DEFAULT NULL,
  `PLMB1` int DEFAULT NULL,
  `PLMB2` int DEFAULT NULL,
  `PLMB3` int DEFAULT NULL,
  `PLMB4` int DEFAULT NULL,
  `ODBGen_16` int DEFAULT NULL,
  `ODBGen_17` int DEFAULT NULL,
  `ODBGen_18` int DEFAULT NULL,
  `created_date` datetime(3) DEFAULT NULL,
  `last_update` datetime(3) DEFAULT NULL,
  `imsitype` int DEFAULT NULL,
  PRIMARY KEY (`IMSI`),
  KEY `IMSI_ODBGPRS_FK1Idx` (`IMSI`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ODBGPRS_log`
--

DROP TABLE IF EXISTS `ODBGPRS_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ODBGPRS_log` (
  `logid` int NOT NULL AUTO_INCREMENT,
  `logdate` datetime(3) DEFAULT NULL,
  `iccid` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `imsi` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `imsitype` int DEFAULT NULL,
  `OutgoingG` int DEFAULT NULL,
  `PLMB1` int DEFAULT NULL,
  `PLMB2` int DEFAULT NULL,
  `PLMB3` int DEFAULT NULL,
  `PLMB4` int DEFAULT NULL,
  `ODBGen_16` int DEFAULT NULL,
  `ODBGen_17` int DEFAULT NULL,
  `ODBGen_18` int DEFAULT NULL,
  `SubscriberStatus` int DEFAULT NULL,
  `GPRSSubscriberStatus` int DEFAULT NULL,
  `prev_OutgoingG` int DEFAULT NULL,
  `prev_PLMB1` int DEFAULT NULL,
  `prev_PLMB2` int DEFAULT NULL,
  `prev_PLMB3` int DEFAULT NULL,
  `prev_PLMB4` int DEFAULT NULL,
  `prev_ODBGen_16` int DEFAULT NULL,
  `prev_ODBGen_17` int DEFAULT NULL,
  `prev_ODBGen_18` int DEFAULT NULL,
  `prev_SubscriberStatus` int DEFAULT NULL,
  `prev_GPRSSubscriberStatus` int DEFAULT NULL,
  `update_by` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  UNIQUE KEY `logid` (`logid`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=2635847 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ODBNonGPRS`
--

DROP TABLE IF EXISTS `ODBNonGPRS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ODBNonGPRS` (
  `IMSI` char(15) NOT NULL,
  `Outgoing` int DEFAULT NULL,
  `Incoming` int DEFAULT NULL,
  `Roaming` int DEFAULT NULL,
  `PremiumInfo` int DEFAULT NULL,
  `PremiumEnt` int DEFAULT NULL,
  `PLMNType1` int DEFAULT NULL,
  `PLMNType2` int DEFAULT NULL,
  `PLMNType3` int DEFAULT NULL,
  `PLMNType4` int DEFAULT NULL,
  `PLMNType5` int DEFAULT NULL,
  `SupplementarySvcMgm` int DEFAULT NULL,
  `CallForward` int DEFAULT NULL,
  `CallTransferInvocation` int DEFAULT NULL,
  `DoubleChargedCallTransfer` int DEFAULT NULL,
  `SecondCallTransferInvocation` int DEFAULT NULL,
  PRIMARY KEY (`IMSI`),
  CONSTRAINT `IMSI_ODBNonGPRS_FK1` FOREIGN KEY (`IMSI`) REFERENCES `IMSI` (`IMSI`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `PDPContext_subscription`
--

DROP TABLE IF EXISTS `PDPContext_subscription`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PDPContext_subscription` (
  `gprs_subscription_id` int NOT NULL,
  `PDPContextID` int NOT NULL,
  `PDPTypeOrg` int DEFAULT NULL,
  `PDPTypeValue` int DEFAULT NULL,
  `PDPAddress` varchar(32) DEFAULT NULL,
  `APNNetworkID` varchar(64) DEFAULT NULL,
  `APNOperatorID` varchar(32) DEFAULT NULL,
  `VPLMNAddrsAllowed` int DEFAULT NULL,
  `QosProfileID` int DEFAULT NULL,
  `slow_profile` int DEFAULT NULL,
  PRIMARY KEY (`gprs_subscription_id`,`PDPContextID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `PDPContext_template`
--

DROP TABLE IF EXISTS `PDPContext_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PDPContext_template` (
  `PLMNID` int NOT NULL,
  `IMSIType` int NOT NULL,
  `TemplateType` int NOT NULL,
  `PDPContextID` int NOT NULL,
  `PDPTypeOrg` int DEFAULT NULL,
  `PDPTypeValue` int DEFAULT NULL,
  `PDPAddress` varchar(32) DEFAULT NULL,
  `APNNetworkID` varchar(64) DEFAULT NULL,
  `APNOperatorID` varchar(32) DEFAULT NULL,
  `VPLMNAddrsAllowed` int DEFAULT NULL,
  `QosProfileID` int DEFAULT NULL,
  PRIMARY KEY (`PLMNID`,`IMSIType`,`PDPContextID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `PLMN`
--

DROP TABLE IF EXISTS `PLMN`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PLMN` (
  `PLMNID` int NOT NULL,
  `sitecode` char(3) NOT NULL,
  `Name` varchar(32) NOT NULL,
  `cc` varchar(5) NOT NULL,
  `Description` varchar(128) DEFAULT NULL,
  `hlraddress` varchar(15) DEFAULT NULL,
  `smscaddress` varchar(15) DEFAULT NULL,
  `imsiprefix` varchar(10) DEFAULT NULL,
  `VMDepositAddress` varchar(15) DEFAULT NULL,
  `VMRetrieveAddress` varchar(15) DEFAULT NULL,
  `mcc` char(3) DEFAULT NULL,
  `mnc` char(2) DEFAULT NULL,
  `hlraddressroaming` varchar(15) DEFAULT NULL,
  `smscaddressroaming` varchar(15) DEFAULT NULL,
  `TopUpAddress` varchar(20) DEFAULT NULL,
  `auth_version` int DEFAULT '1',
  `smscaddress_fsm` varchar(15) DEFAULT NULL,
  `smscaddressroaming_fsm` varchar(15) DEFAULT NULL,
  `smscaddress_mo_forward` varchar(24) DEFAULT NULL,
  `smscInternationalAddress` varchar(15) DEFAULT NULL,
  `hlrInternationalAddress` varchar(15) DEFAULT NULL,
  `hostprefix` varchar(15) DEFAULT NULL,
  `homeprefix` varchar(15) DEFAULT NULL,
  `mnp_type` int NOT NULL DEFAULT '2',
  PRIMARY KEY (`PLMNID`),
  KEY `plmn_idx_cc_homeprefix` (`cc`,`homeprefix`),
  KEY `plmn_idx_mcc_cc` (`mcc`,`cc`),
  KEY `Sites_PLMN_FK1` (`sitecode`),
  KEY `Sites_PLMN_FK1Idx` (`sitecode`),
  CONSTRAINT `Sites_PLMN_FK1` FOREIGN KEY (`sitecode`) REFERENCES `Sites` (`siteCode`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `RoamingConfig`
--

DROP TABLE IF EXISTS `RoamingConfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RoamingConfig` (
  `Sitecode` varchar(5) NOT NULL,
  `IMSI_prefix` varchar(15) NOT NULL,
  `VLR_prefix` varchar(20) NOT NULL,
  `Roaming` int DEFAULT NULL,
  `Camel` int DEFAULT NULL,
  `CallBarring` int DEFAULT NULL,
  `Comment` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`Sitecode`,`VLR_prefix`,`IMSI_prefix`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `SIM`
--

DROP TABLE IF EXISTS `SIM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SIM` (
  `ICCID` char(20) NOT NULL,
  `MSCategory` int DEFAULT NULL,
  `IMSIActive` varchar(20) DEFAULT NULL,
  `VLRNumber` varchar(20) DEFAULT NULL,
  `MSCNumber` varchar(20) DEFAULT NULL,
  `SGSNNumber` varchar(20) DEFAULT NULL,
  `GGSNNumber` varchar(20) DEFAULT NULL,
  `SGSNAddress` varchar(40) DEFAULT NULL,
  `MNRG` int DEFAULT NULL,
  `MNRR` int DEFAULT NULL,
  `MNRF` int DEFAULT NULL,
  `MCEF` int DEFAULT NULL,
  `MobilityMgtState` int DEFAULT NULL,
  `RSZIListID` int DEFAULT NULL,
  `SubscriberStatus` int DEFAULT NULL,
  `FirstUpdate` datetime(3) DEFAULT NULL,
  `LastUpdate` datetime(3) DEFAULT NULL,
  `rq_callback` datetime(3) DEFAULT NULL,
  `releaseflag` int DEFAULT NULL,
  `prev_substatus` int DEFAULT NULL,
  `LastLocUpdIMSI` varchar(15) DEFAULT NULL,
  `IDType` int DEFAULT NULL,
  `sub_sitecode` varchar(5) DEFAULT NULL,
  `IMEI` varchar(15) DEFAULT NULL,
  `real_imsi` varchar(15) DEFAULT NULL,
  `lastAttemptIMSI` varchar(20) DEFAULT NULL,
  `lastAttemptDate` datetime(3) DEFAULT NULL,
  `GPRSSubscriberStatus` int NOT NULL DEFAULT '0',
  `attempt_ctr` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`ICCID`),
  KEY `RSZIList_Ref_SIM_new_FK1Idx` (`RSZIListID`),
  KEY `idx_imei1` (`IMEI`),
  KEY `idx_imsi` (`IMSIActive`),
  KEY `idx_real_imsi` (`real_imsi`),
  KEY `idx2` (`IMEI`,`real_imsi`),
  KEY `idx22` (`real_imsi`,`IMEI`),
  KEY `idx3` (`real_imsi`,`ICCID`,`IMSIActive`),
  KEY `idx4` (`IMEI`,`real_imsi`,`ICCID`,`IMSIActive`),
  KEY `idx5_sim` (`LastUpdate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ServiceType_Ref`
--

DROP TABLE IF EXISTS `ServiceType_Ref`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ServiceType_Ref` (
  `serviceType` int NOT NULL,
  `name` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`serviceType`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `enterprise_ref`
--

DROP TABLE IF EXISTS `enterprise_ref`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `enterprise_ref` (
  `enterprise_id` int NOT NULL,
  `enterprise_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `description` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`enterprise_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `hlr_cancel_loc_request`
--

DROP TABLE IF EXISTS `hlr_cancel_loc_request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hlr_cancel_loc_request` (
  `reqid` int NOT NULL AUTO_INCREMENT,
  `sitecode` varchar(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `reqby` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `reqdate` datetime(3) DEFAULT NULL,
  `iccid` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `imsi` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `cancel_loc_type` int DEFAULT NULL,
  `status` int DEFAULT NULL,
  `status_desc` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `lastupdate` datetime(3) DEFAULT NULL,
  `updated_by` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `roaming` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`reqid`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=5687088 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `msisdn_porting`
--

DROP TABLE IF EXISTS `msisdn_porting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `msisdn_porting` (
  `msisdn` varchar(24) NOT NULL,
  `porting_status` int DEFAULT NULL,
  `last_update` datetime(3) DEFAULT NULL,
  `last_portin` varchar(20) DEFAULT NULL,
  `last_portout` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`msisdn`),
  KEY `idx1` (`msisdn`,`porting_status`),
  KEY `msisdn_porting_idx1` (`msisdn`,`porting_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `non_subscriber_NB`
--

DROP TABLE IF EXISTS `non_subscriber_NB`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `non_subscriber_NB` (
  `canonicNB` varchar(32) NOT NULL,
  `comment` varchar(64) DEFAULT NULL,
  `expire_date` datetime(3) DEFAULT NULL,
  `vectone_app` int NOT NULL,
  PRIMARY KEY (`canonicNB`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pdpcontext_log`
--

DROP TABLE IF EXISTS `pdpcontext_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pdpcontext_log` (
  `dt` datetime(3) NOT NULL,
  `host` varchar(128) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `IMSI` char(15) NOT NULL,
  `PDPContextID` int NOT NULL,
  `PDPTypeOrg` int DEFAULT NULL,
  `PDPTypeValue` int DEFAULT NULL,
  `PDPAddress` varchar(32) DEFAULT NULL,
  `APNNetworkID` varchar(64) DEFAULT NULL,
  `APNOperatorID` varchar(32) DEFAULT NULL,
  `VPLMNAddrsAllowed` int DEFAULT NULL,
  `QosProfileID` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=47936276 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ported_out`
--

DROP TABLE IF EXISTS `ported_out`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ported_out` (
  `pout_id` int NOT NULL AUTO_INCREMENT,
  `pout_date` datetime(3) DEFAULT NULL,
  `msisdn` varchar(15) DEFAULT NULL,
  `iccid` char(20) DEFAULT NULL,
  `comment` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`pout_id`),
  KEY `idx4` (`msisdn`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=8016 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sim_basedrouting`
--

DROP TABLE IF EXISTS `sim_basedrouting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sim_basedrouting` (
  `trunkgroup` varchar(10) NOT NULL,
  `prefix` varchar(20) NOT NULL,
  `simbased_flag` int DEFAULT NULL,
  PRIMARY KEY (`trunkgroup`,`prefix`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `simbasedpfx_transaction`
--

DROP TABLE IF EXISTS `simbasedpfx_transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `simbasedpfx_transaction` (
  `insert_date` datetime(3) DEFAULT NULL,
  `sitecode` varchar(3) DEFAULT NULL,
  `cli` varchar(16) NOT NULL,
  `msisdn` varchar(16) NOT NULL,
  `sessionid` varchar(32) DEFAULT NULL,
  `switchcode` varchar(3) DEFAULT NULL,
  `trunkcode` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`cli`,`msisdn`),
  KEY `idx1_simbasedpfx_transaction` (`msisdn`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sms_xtrapp_imsi_mapping`
--

DROP TABLE IF EXISTS `sms_xtrapp_imsi_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sms_xtrapp_imsi_mapping` (
  `id` int NOT NULL AUTO_INCREMENT,
  `msisdn` varchar(20) NOT NULL,
  `imsi` varchar(20) DEFAULT NULL,
  `sms_relay` varchar(25) DEFAULT NULL,
  `status` int DEFAULT NULL,
  `create_date` datetime(3) DEFAULT NULL,
  `main_msisdn` varchar(20) DEFAULT NULL,
  `exp_date` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`msisdn`),
  UNIQUE KEY `id` (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=5009 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ur_charge_did_prefix`
--

DROP TABLE IF EXISTS `ur_charge_did_prefix`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ur_charge_did_prefix` (
  `country` varchar(50) DEFAULT NULL,
  `Number_Type` varchar(100) DEFAULT NULL,
  `prefix` varchar(25) NOT NULL,
  `route_prefix` varchar(10) DEFAULT NULL,
  `status` int DEFAULT NULL,
  PRIMARY KEY (`prefix`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `xlat_in`
--

DROP TABLE IF EXISTS `xlat_in`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `xlat_in` (
  `sitecode` varchar(5) NOT NULL,
  `switchcode` varchar(5) NOT NULL,
  `trunkin` varchar(16) NOT NULL,
  `pfx` varchar(20) NOT NULL,
  `xlatin` varchar(25) DEFAULT NULL,
  `noa` int NOT NULL,
  `xlatnoa` int NOT NULL,
  PRIMARY KEY (`sitecode`,`switchcode`,`trunkin`,`pfx`,`noa`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `xlat_out`
--

DROP TABLE IF EXISTS `xlat_out`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `xlat_out` (
  `sitecode` varchar(5) NOT NULL,
  `switchcode` varchar(5) NOT NULL,
  `trunkout` varchar(16) NOT NULL,
  `pfx` varchar(32) NOT NULL,
  `xlatout` varchar(24) DEFAULT NULL,
  PRIMARY KEY (`sitecode`,`switchcode`,`trunkout`,`pfx`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `xtrapp_imsi_pool`
--

DROP TABLE IF EXISTS `xtrapp_imsi_pool`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `xtrapp_imsi_pool` (
  `id` int NOT NULL AUTO_INCREMENT,
  `imsi` varchar(20) NOT NULL,
  `status` int DEFAULT NULL,
  `reg_msisdn` varchar(20) DEFAULT NULL,
  `reg_by` varchar(25) DEFAULT NULL,
  `last_update` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`imsi`),
  UNIQUE KEY `id` (`id`),
  KEY `idx1_xtrapp_imsi_pool` (`reg_msisdn`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=5001 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping events for database 'hlrdb'
--

--
-- Dumping routines for database 'hlrdb'
--
/*!50003 DROP FUNCTION IF EXISTS `get_value_from_map_address` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` FUNCTION `get_value_from_map_address`(map varchar(32)) RETURNS varchar(32) CHARSET utf8mb4
    DETERMINISTIC
begin

  declare i int;
  declare j int;
  declare k int; 
  declare value varchar(32);
  
  set i = LOCATE(';', map);
  set j = LOCATE(';', map, i+1);
  
  if i =0 then 
   set value = map;
  else
    if j > 0 then
     set value = right(map,char_length(map)-j) ;
    else
     set value = right(map,char_length(map)-i) ;
	end if;
	end if;
  return value;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `cancel_loc_insert_request` */;
ALTER DATABASE `hlrdb` CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `cancel_loc_insert_request`(v_sitecode VARCHAR(3),
v_reqby VARCHAR(32) ,
v_now DATETIME(3),
v_iccid VARCHAR(20),
v_imsi  VARCHAR(20),
v_cancel_loc_type INT, 
v_comment VARCHAR(100),
INOUT v_errcode INT ,
INOUT v_errmsg VARCHAR(250))
SWL_return:
begin
   DECLARE v_imsi_type INT; 
   DECLARE v_roaming INT; 
		
   IF v_reqby is null then
      set v_reqby = '';
   END IF;
   set v_errcode = -1;
   set v_errmsg = '';
   set v_roaming = 0;
	
	
	
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   IMSItype INTO v_imsi_type from imsi where iccid = v_iccid and
   imsi = v_imsi;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
	
	
   if v_imsi_type <> 1 then
      set v_roaming = 1;
   end if;

   insert into hlr_cancel_loc_request(sitecode,reqby,reqdate,iccid,imsi,cancel_loc_type,status,status_desc,lastupdate,updated_by,roaming)
	values(v_sitecode,v_reqby,v_now,v_iccid,v_imsi,v_cancel_loc_type,0,v_comment,v_now,v_reqby,v_roaming);
	

	
   if ROW_COUNT() <= 0 then
	
      set v_errmsg = 'Failed to insert hlr_cancel_loc_request table';
      LEAVE SWL_return;
   end if;
	
   set v_errcode = 0;
   set v_errmsg = 'Sucess to insert the Cancel request';
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `hlrdb` CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `did_portal_get_imsi_pool` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `did_portal_get_imsi_pool`(`msisdn` VARCHAR(20))
BEGIN
	
   IF `msisdn` is null then
      set `msisdn` = '';
   END IF;
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select imsi,IFNULL(reg_msisdn,'NA') AS msisdn,IFNULL(reg_by,'') as reg_by,
	last_update
   from xtrapp_imsi_pool
   where (`msisdn` = '') or (reg_msisdn = `msisdn`);
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `did_portal_map_did_number` */;
ALTER DATABASE `hlrdb` CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `did_portal_map_did_number`(v_did_number VARCHAR(20),  
v_mobileno VARCHAR(20),  
v_first_name VARCHAR(50),  
v_last_name VARCHAR(50),  
v_email VARCHAR(150),  
v_product_id INT,  
v_assign_date DATETIME(3),  
v_purchase_date DATETIME(3),  
v_purchase_price FLOAT,  
v_exp_date DATETIME(3),  
v_company_id INT,  
v_company_name VARCHAR(150))
BEGIN

   IF v_company_id is null 
   then
      set v_company_id = 0;
   END IF;
   
   IF v_company_name is null 
   then
      set v_company_name = '';
   END IF;
   
   UPDATE  did_number_pool SET status = 1,fk_product_id = v_product_id,assigned_date = CURRENT_TIMESTAMP
   WHERE did_number = v_did_number;  
   
   if ROW_COUNT() > 0 then
 
    INSERT INTO did_number_user_info(did_number,assigned_user,first_name,last_name,email,fk_product_id,
  assigned_date,assigned_by,purchase_price,exp_date,company_id,company_name)
  VALUES(v_did_number,v_mobileno,v_first_name,v_last_name,v_email,v_product_id,v_assign_date,v_purchase_date,
  v_purchase_price,v_exp_date,v_company_id,v_company_name);
   end if;  
   
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `hlrdb` CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `gmsc_check_nonsubscriber_number` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `gmsc_check_nonsubscriber_number`(nb VARCHAR(20))
begin
  
  	
  
     DECLARE v_now DATETIME(3); 
     set v_now = CURRENT_TIMESTAMP;
     
     SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
     select * from non_subscriber_NB  where canonicNB = nb
     and  (expire_date is null or  (expire_date >= v_now and expire_date is not null)) LIMIT 1;
     SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ; 
  end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `gmsc_getaccount_mvno` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbteam`@`%` PROCEDURE `gmsc_getaccount_mvno`(msisdn VARCHAR(16))
begin

   CALL esp.esp_getaccount_mvno(msisdn);  
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `gmsc_get_addprefix` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `gmsc_get_addprefix`(number VARCHAR(20),
 routing_id INT)
begin
 
 	
     
    CALL esp.esp_get_addprefix(number,routing_id);
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `gmsc_get_forwarding` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `gmsc_get_forwarding`(imsi VARCHAR(15))
BEGIN
 
    DECLARE v_sitecode VARCHAR(5); 
    DECLARE v_imsitype INT;
    DECLARE Default_int_val_0 int;
    DECLARE Default_int_val_1 int;
    
    set Default_int_val_0 = 0 ;
    set Default_int_val_1 = 1 ;
    
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select   sitecode, IMSItype INTO v_sitecode,v_imsitype 
    from IMSI t1 join PLMN t2 on (t1.PLMNID = t2.PLMNID) where t1.IMSI = imsi;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
    
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    SELECT a.IMSI, a.CFWType ss_code,
 		case b.ActivationState when 2 then Default_int_val_1 else Default_int_val_0 end q,
 		a.ProvisionState p,
 		case b.RegistrationState when 2 then Default_int_val_0 else Default_int_val_1 end r,
 		case b.ActivationState when 0 then Default_int_val_0 else Default_int_val_1 end a,
 		NoReplyTimer max_nry,
 		cast(get_noa_from_map_address(ForwardToNb) as SIGNED INTEGER) ftn_noa,
 		cast(get_value_from_map_address(ForwardToNb) as CHAR(15)) ftn_address
    from CallForward a join
 	(select distinct t1_in.IMSI, t1_in.CFWType,
 			case when PREFIX is null then ActivationState else Default_int_val_0 end ActivationState,
 			case when PREFIX is null then RegistrationState else Default_int_val_0 end RegistrationState,
 			case when PREFIX is null then ForwardToNb else null end ForwardToNB,
 			case when PREFIX is null then Subaddress else null end subaddress,
 			case when PREFIX is null then NoReplyTimer else null end noreplytimer,
 			ServiceCode, ServiceType
       from CallForward_BSG t1_in left join CALLFORWARD_BLACKLIST t2_in
       on (sitecode = v_sitecode and IMSItype in (0,v_imsitype) and left(common_get_map_address_value(ForwardToNb), CHAR_LENGTH(prefix)) = prefix)
       where t1_in.IMSI = imsi) b
    ON a.IMSI = b.IMSI and a.CFWType = b.CFWType
    WHERE a.IMSI = imsi
    and ServiceType = 3;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `gmsc_get_mapped_msisdn` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `gmsc_get_mapped_msisdn`(
site_code VARCHAR(3),    
msisdn  VARCHAR(20)
)
begin

    
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select a.msisdn_local as msisdn from mvno.multi_number_subscription a
   where a.msisdn_remote = msisdn and a.status in(1,2)
   and DATE_FORMAT(CURRENT_TIMESTAMP,'%Y-%m-%d') <= a.expiry_date;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `gmsc_get_mapped_msisdn_v2` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `gmsc_get_mapped_msisdn_v2`(
site_code varchar(3), 
phonenb  varchar(20),
datenow datetime
)
sp_return : begin    



	declare msisdn varchar(24);
	declare prefix_dest varchar(20)	;
	declare errcode int;
	declare errmsg varchar(255);
	declare prompt_file varchar(30);
	declare ussd_msg varchar(255);
	declare svc_id int;
	declare enddate datetime;
	declare sendussd int;
	declare ban_ported_out int;
	declare isported int;

	set errcode = -1;
	set errmsg = 'multinumber mapping not found';
	set prompt_file = '';
	set ussd_msg = '';
	set sendussd = 0;
	set msisdn = phonenb ;
	set prefix_dest = '';

	sp_exit:begin
	if site_code = 'BES' then

		select msisdn_local into msisdn from mvno.multi_number_subscription a 
		where a.msisdn_remote = phoneNB and a.status in (1,2) and  cast(datenow as date) <= expiry_date limit 1;	
	
		if row_count()>0 then
			set errcode = 0;
			set errmsg = 'OLD Multinumber OK';
			leave sp_exit;
		end if;
	end if;

	select account_info, svc_id, enddate into msisdn,svc_id,enddate
	from mvno.multi_number_register a
	where a.reg_number = phoneNB and a.status in (1,2)
	order by a.status, a.enddate desc limit 1;

	if row_count()<=0 then
		select errcode errcode, errmsg errmsg, msisdn msisdn, prompt_file prompt_file, ussd_msg ussd_msg limit 0;
		leave sp_return;
	end if;

	

	if enddate < datenow then
		set msisdn=phonenb;

		select message, prompt_file, incomingcall_ussd_notif 
		into errmsg, prompt_file, sendussd
		from mvno.multi_number_message a where a.svc_id = svc_id and a.messageid = 601 limit 1;

		if row_count() > 0 then
			set errmsg = 'Multinumber is expired.';
			leave sp_exit	;
		End if;
	end if;

	
	
	set ban_ported_out =0;
	select ban_ported_out,ifnull(prefix_dest,'') into ban_ported_out,prefix_dest from mvno.multi_number_service a where a.svc_id=svc_id limit 1;
	if ban_ported_out = 1 then
		
		set isported=0;
		select a.porting_status into isported from msisdn_porting a where a.msisdn = msisdn limit 1;

		if isported= 2 then 

			select message, prompt_file, incomingcall_ussd_notif
			into errmsg, prompt_file, sendussd 
			from mvno.multi_number_message a where a.svc_id = svc_id and a.messageid = 602 limit 1;

			if rowcount <= 0 then
				set errmsg = 'Multinumber is not allowed for ported out user.';
				leave sp_exit;
			end if;
		end if;
	End if;
	

	set errcode = 0;
	set errmsg = 'Multinumber OK';
    
    End sp_exit;
    
	if sendussd = 1 then
		set ussd_msg = errmsg;
	End if;
	select errcode errcode, errmsg errmsg, msisdn msisdn, prompt_file prompt_file, ussd_msg ussd_msg, prefix_dest prefix_dest;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `gmsc_get_simbased_routing` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `gmsc_get_simbased_routing`(trunkgroup VARCHAR(10),  
 ddi VARCHAR(20))
begin
 	
 	
    DECLARE v_simbased_flag INT;
 		set v_simbased_flag = 0;
 	
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
 	   select IFNULL(simbased_flag,0) INTO v_simbased_flag 
        from sim_basedrouting a where (a.trunkgroup = trunkgroup or a.trunkgroup = '*')
 	   and prefix = left(ddi, CHAR_LENGTH(prefix)) order by a.trunkgroup desc, a.prefix desc LIMIT 1;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 	
    select v_simbased_flag as simbased_flag;
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `gmsc_get_subscriber` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `gmsc_get_subscriber`(
  	msisdn VARCHAR(25),
     callback_timeout INT)
BEGIN
    
    DECLARE vlrtype INT;
       DECLARE iccid CHAR(20);
       DECLARE imsi CHAR(15);
       DECLARE msisdn_val VARCHAR(15);
       DECLARE sstat INT;
       DECLARE act INT;
       DECLARE mnrf INT;
       DECLARE plmnid INT;
       DECLARE vlr VARCHAR(20);
       DECLARE msc VARCHAR(20);
       DECLARE ispool INT;
       DECLARE isroaming INT;
       DECLARE imsitype INT;
       DECLARE iscbblock INT;
       DECLARE isported INT;
       DECLARE incomming_block INT;
       declare mnrf_default int;
       
       set mnrf_default=0;
       IF callback_timeout is null or callback_timeout = '' or callback_timeout=0 then
          set callback_timeout = 180;
       END IF;
       
       BEGIN
          set incomming_block = 0;
          
          SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
          select a.ICCID, a.ispool INTO iccid,ispool from MSISDN a where a.MSISDN = msisdn;
          SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
          
          if ispool = 1 then 
             SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
             select a.ICCID INTO iccid from MSISDN_POOL a where a.MSISDN = msisdn;
             SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
          end if;
    
     
          SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
          select b.IMSI, b.AlertMSISDN, a.SubscriberStatus, a.mnrf, b.PLMNID, b.IMSItype, 
          convert(get_value_from_map_address(a.VLRNumber),CHAR(20)), 
          convert(get_value_from_map_address(a.MSCNumber),CHAR(20)), 
          case when TIMESTAMPDIFF(SECOND,IFNULL(rq_callback,'1970-1-1'),TIMESTAMPADD(SECOND,callback_timeout,CURRENT_TIMESTAMP)) <= 0 then 1 else 0 end 
          INTO imsi,msisdn_val,sstat,mnrf,plmnid,imsitype,vlr,msc,iscbblock FROM SIM a  join IMSI b 
          ON a.ICCID = b.ICCID and a.IMSIActive = b.IMSI where a.ICCID = iccid;
          SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
          
    
          
          SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
          select   case when left(vlr, CHAR_LENGTH(cc)) = cc then 0 else 1 end INTO isroaming from PLMN a  where a.PLMNID = plmnid;
          SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
          set act = 0;  
          if sstat = 0 then 
             set act = 1;
          end if;
          if sstat = 1 then
     
             if isroaming = 1 then
                SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
                select   case Incoming when 1 then 0 else 1 end INTO act from ODBNonGPRS a where a.IMSI = imsi;
                SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
             end if;
          end if;
     
        
          if isroaming = 1 and imsitype = 3 and IFNULL(vlr,'') <> '' AND IFNULL(imsi,'') <> '' and act = 1 then
    	
             SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
             select   1 INTO incomming_block from RoamingConfig where IMSI_prefix = left(imsi, CHAR_LENGTH(IMSI_prefix)) 
             and VLR_prefix = left(vlr, CHAR_LENGTH(VLR_prefix))
             and IFNULL(IMSI_prefix,'') <> '' and CallBarring in(54,53,51,46)   order by IMSI_prefix desc LIMIT 1;
             SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
             if incomming_block = 1 then
                set act = 0;
             end if;
          end if;       
    
     
          set isported = 0;
          SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
          select   porting_status INTO isported from msisdn_porting a  where a.msisdn = msisdn;
          SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
        
          
          select iccid iccid, imsi imsi, msisdn_val msisdn, act act,mnrf_default  mnrf, vlr vlr, msc msc, isroaming isroaming, imsitype ,
     iscbblock is_cb_block, isported isPorted;
       END;
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `gmsc_simbasedpfx_transaction` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `gmsc_simbasedpfx_transaction`(sitecode VARCHAR(3),
  cli VARCHAR(16),
  msisdn VARCHAR(16),
  sessionid VARCHAR(32),
  switchcode VARCHAR(3),
  trunkcode VARCHAR(32))
begin
  
     DECLARE now DATETIME(3);
     DECLARE errcode INT;
     DECLARE errmsg VARCHAR(256);
  	
     set now = CURRENT_TIMESTAMP;
     
     set errcode = -1;
     set errmsg = '';
  	
     if exists(select * from simbasedpfx_transaction a where a.cli = cli and a.msisdn = msisdn) then
        set errmsg = CONCAT_WS('','Entry found for CLI=',cli,' and MSISD',msisdn);
     else
  		 insert into simbasedpfx_transaction(insert_date,sitecode,cli,msisdn,sessionid,switchcode,trunkcode)
  		values(now,sitecode,cli,msisdn,sessionid,switchcode,trunkcode);
  		
        set errcode = 0;
     end if;
  	
     select errcode errcode, errmsg errmsg;
  end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `gmsc_xlat_in` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `gmsc_xlat_in`(site VARCHAR(5),    
 switch VARCHAR(5),    
 trunk VARCHAR(16),    
 nb VARCHAR(20),  
 noa INT)
BEGIN
 
    IF noa is null then
       set noa = 0;
    END IF;
    
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    SELECT  a.pfx, a.xlatin, a.noa, a.xlatnoa FROM xlat_in a
    WHERE a.sitecode = site
    AND (a.switchcode = switch OR a.switchcode = '*')
    AND (a.trunkin = trunk OR a.trunkin = '*')
    AND LEFT(nb, CHAR_LENGTH(a.pfx)) = pfx
    AND (a.noa = noa or a.noa = 0)
    ORDER BY switchcode,trunkin, CHAR_LENGTH(pfx),a.noa desc LIMIT 1;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;    
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `gmsc_xlat_out` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `gmsc_xlat_out`(site VARCHAR(5),        
 switch VARCHAR(5),        
 trunk VARCHAR(16),        
 nb VARCHAR(50))
BEGIN
       
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    SELECT a.pfx, a.xlatout FROM xlat_out a
    WHERE a.sitecode = site
    AND (a.switchcode = switch OR a.switchcode = '*')
    AND (a.trunkout = trunk OR a.trunkout = '*')
    AND LEFT(nb, CHAR_LENGTH(a.pfx)) = a.pfx
    ORDER BY switchcode ,trunkout , CHAR_LENGTH(pfx) desc LIMIT 1;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;        
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `gprs_odb_cancel_barring` */;
ALTER DATABASE `hlrdb` CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `gprs_odb_cancel_barring`(v_sitecode VARCHAR(3),
v_reqby VARCHAR(32),
v_now DATETIME(3),
v_iccid VARCHAR(20),
INOUT v_errcode INT ,
INOUT v_errmsg VARCHAR(250))
SWL_return:
begin



	
   DECLARE v_status INT;
   DECLARE v_imsi VARCHAR(20);
	
   set v_errcode = -1;
   set v_errmsg = '';


   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   GPRSSubscriberStatus, IMSIActive INTO v_status,v_imsi from sim  where iccid = v_iccid;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ; 
	
	
   if v_status <> 1 then
      LEAVE SWL_return;
   end if;
	
	
   CALL gprs_odb_update_status(v_sitecode,v_imsi,v_iccid,0,v_reqby,v_errcode,v_errmsg);   
		
   if v_errcode = 0 then
	
      CALL cancel_loc_insert_request(v_sitecode,v_reqby,v_now,v_iccid,v_imsi,2,'gprs cancel request',v_errcode,
      v_errmsg);
   end if; 
		
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `hlrdb` CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `gprs_odb_update_status` */;
ALTER DATABASE `hlrdb` CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `gprs_odb_update_status`(v_sitecode VARCHAR(5),
v_imsi VARCHAR(20),
v_iccid VARCHAR(20),
v_status INT,
v_updby VARCHAR(20),
INOUT v_errcode INT ,
INOUT v_errmsg VARCHAR(120))
SWL_return:
begin
   DECLARE v_OutgoingG INT; 
   DECLARE v_roaming INT; 
   DECLARE v_PLMB1 INT;
   DECLARE v_PLMB2 INT;
   DECLARE v_PLMB3 INT; 
   DECLARE v_PLMB4 INT; 
   DECLARE v_now DATETIME(3);
   DECLARE v_prev_substatus INT;  
   DECLARE v_after_substatus INT;  
   DECLARE v_prev_gprssubstatus INT;  
   DECLARE v_gprssubstatus INT;  
   DECLARE v_subsstatus INT;  
   DECLARE v_counter INT;  
   DECLARE v_totalcounter INT;  
   DECLARE v_p_imsi VARCHAR(20);  
   DECLARE v_imsitype INT;  
   DECLARE v_prev_OutgoingG INT;  
   DECLARE v_prev_PLMB1 INT;   
   DECLARE v_prev_PLMB2 INT;   
   DECLARE v_prev_PLMB3 INT;   
   DECLARE v_prev_PLMB4 INT; 
   DECLARE v_prev_ODBGen_16 INT;   
   DECLARE v_prev_ODBGen_17 INT;   
   DECLARE v_prev_ODBGen_18 INT; 
   DECLARE v_ODB_GEN_16 INT;
   DECLARE v_ODB_GEN_17 INT; 
   DECLARE v_ODB_GEN_18 INT;
   DECLARE Swv_RowCount INT; 


   sp_exit:
   BEGIN
      set v_now = CURRENT_TIMESTAMP;
      set v_errcode = -1;
      set v_errmsg = 'update not ok';
      drop TEMPORARY table IF EXISTS tt_imsi_temp;	
      create TEMPORARY table tt_imsi_temp
      (
         id INT   AUTO_INCREMENT PRIMARY KEY,
         imsi VARCHAR(20),
         imsitype INT
      )  AUTO_INCREMENT = 1;  

	
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      insert into tt_imsi_temp(imsi,imsitype)
      select imsi, imsitype from imsi  where iccid = v_iccid;
      SET Swv_RowCount = ROW_COUNT();
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
      if Swv_RowCount <= 0 then
         LEAVE SWL_return;
      end if;
      START TRANSACTION;   

	
      UPDATE SIM a
      set v_prev_gprssubstatus = GPRSSubscriberStatus,v_gprssubstatus = v_status,v_subsstatus = SubscriberStatus
      where iccid = v_iccid and GPRSSubscriberStatus <> v_status;
      if ROW_COUNT() <= 0 then
	
         ROLLBACK;
         LEAVE sp_exit;
      end if;
      select   count(1) INTO v_totalcounter from tt_imsi_temp;
      set v_counter = 1;
      while v_counter <= v_totalcounter DO
         select   imsi, imsitype INTO v_p_imsi,v_imsitype from tt_imsi_temp where id = v_counter;
         if v_status = 0 then 
		
            select   OutgoingG, PLMB1, PLMB2, PLMB3, PLMB4, ODBGen_16, ODBGen_17, ODBGen_18 INTO v_prev_OutgoingG,v_prev_PLMB1,v_prev_PLMB2,v_prev_PLMB3,v_prev_PLMB4,v_prev_ODBGen_16,
            v_prev_ODBGen_17,v_prev_ODBGen_18 from ODBGPRS where imsi = v_p_imsi;
			
			
            delete FROM  ODBGPRS where imsi = v_p_imsi;
			
 			
            insert into ODBGPRS_log(logdate,iccid,imsi,imsitype,OutgoingG,PLMB1,PLMB2,PLMB3,PLMB4,ODBGen_16,ODBGen_17,ODBGen_18,SubscriberStatus,GPRSSubscriberStatus,
				prev_OutgoingG,prev_PLMB1,prev_PLMB2,prev_PLMB3,prev_PLMB4,prev_ODBGen_16,prev_ODBGen_17,prev_ODBGen_18,prev_SubscriberStatus,prev_GPRSSubscriberStatus, update_by)
			values(v_now,v_iccid,v_p_imsi,v_imsitype,null,null,null,null,null,null,null,null,null,null,
				v_prev_OutgoingG,v_prev_PLMB1,v_prev_PLMB2,v_prev_PLMB3,v_prev_PLMB4,v_prev_ODBGen_16,v_prev_ODBGen_17,v_prev_ODBGen_18,v_prev_substatus,v_prev_gprssubstatus, v_updby);
         else
            SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
            select   OutgoingG, PLMB1, PLMB2, PLMB3, PLMB4, ODBGen_16, ODBGen_17, ODBGen_18 INTO v_OutgoingG,v_PLMB1,v_PLMB2,v_PLMB3,v_PLMB4,v_ODB_GEN_16,v_ODB_GEN_17,
            v_ODB_GEN_18 from ODBGPRS_config  where sitecode = v_sitecode and status = v_status;
            SET Swv_RowCount = ROW_COUNT();
            SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
            if Swv_RowCount <= 0 then
			
               ROLLBACK;
               LEAVE sp_exit;
            end if;
            if exists(select  1 from ODBGPRS where imsi = v_p_imsi LIMIT 1) then
			
               UPDATE ODBGPRS a set
               v_prev_OutgoingG = OutgoingG,v_prev_PLMB1 = PLMB1,v_prev_PLMB2 = PLMB2,v_prev_PLMB3 = PLMB3,
               v_prev_PLMB4 = PLMB4,v_OutgoingG = OutgoingG,v_prev_ODBGen_16 = ODBGen_16,
               v_prev_ODBGen_17 = ODBGen_17,v_prev_ODBGen_18 = ODBGen_18,a.PLMB1 = v_PLMB1,
               a.PLMB2 = v_PLMB2,a.PLMB3 = v_PLMB3,a.PLMB4 = v_PLMB4,a.ODBGen_16 = v_ODB_GEN_16,
               v_ODB_GEN_17 = ODBGen_17,v_ODB_GEN_18 = ODBGen_18
               where imsi = v_p_imsi;
            else
               set v_prev_OutgoingG = null;
               set  v_prev_PLMB1 = null;
               set v_prev_PLMB2 = null;
               set v_prev_PLMB3 = null;
               set v_prev_PLMB4 = null;
               SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
               insert into ODBGPRS(IMSI,imsitype,OutgoingG,Roaming,PLMB1,PLMB2,PLMB3,PLMB4,ODBGen_16,ODBGen_17,ODBGen_18,created_date,last_update)
               select imsi,imsitype,v_OutgoingG,case when imsitype = 1 then 0 else 1 end as roaming, v_PLMB1,v_PLMB2,v_PLMB3,v_PLMB4,v_ODB_GEN_16,v_ODB_GEN_17,v_ODB_GEN_18,v_now,v_now
               from imsi where imsi = v_p_imsi;
               SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
            end if;
			
 			
            insert into ODBGPRS_log(logdate,iccid,imsi,imsitype,OutgoingG,PLMB1,PLMB2,PLMB3,PLMB4,ODBGen_16,ODBGen_17,ODBGen_18,SubscriberStatus,GPRSSubscriberStatus,
				prev_OutgoingG,prev_PLMB1,prev_PLMB2,prev_PLMB3,prev_PLMB4,prev_ODBGen_16,prev_ODBGen_17,prev_ODBGen_18,prev_SubscriberStatus,prev_GPRSSubscriberStatus,update_by)
			values(v_now,v_iccid,v_p_imsi,v_imsitype,v_OutgoingG,v_PLMB1,v_PLMB2,v_PLMB3,v_PLMB4,v_ODB_GEN_16,v_ODB_GEN_17,v_ODB_GEN_18,v_subsstatus,v_gprssubstatus,
				v_prev_OutgoingG,v_prev_PLMB1,v_prev_PLMB2,v_prev_PLMB3,v_prev_PLMB4,v_prev_ODBGen_16,v_prev_ODBGen_17,v_prev_ODBGen_18,v_prev_substatus,v_prev_gprssubstatus,v_updby);
         end if;
         set v_counter = v_counter+1;
      END WHILE;
      set v_errcode = 0;
      set v_errmsg = 'update ok';
      COMMIT;
   END;
   

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `hlrdb` CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `SIM_get_firstupdate` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `SIM_get_firstupdate`(v_iccid VARCHAR(20),
INOUT v_sim_firstupdate DATETIME(3) ,
INOUT v_errorcode INT ,
INOUT v_errormsg CHAR(50) ,
INOUT v_sim_lastupdate DATETIME(3))
begin

   DECLARE Swv_RowCount INT;

   set v_errorcode = -1;
   set v_errormsg = '';

   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   FirstUpdate, LastUpdate INTO v_sim_firstupdate,v_sim_lastupdate from SIM where iccid = v_iccid;
   SET Swv_RowCount = ROW_COUNT();
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

   if Swv_RowCount > 0 then
	
      set v_errorcode = 0;
      set v_errormsg = 'Success to get the sim firstupdate';
   end if; 
	

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `urapp_did_do_routing_process` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `urapp_did_do_routing_process`(did VARCHAR(20),  
 trunk_in VARCHAR(20),  
 trunk_out VARCHAR(20),  
 port_out VARCHAR(20),  
 fwd_prefix VARCHAR(10),  
 route_prefix VARCHAR(10),  
 sitecode VARCHAR(3))
BEGIN
 
    DECLARE v_xlat_out VARCHAR(50);  
    DECLARE v_errcode INT;  
    DECLARE v_errmsg VARCHAR(20);     
    DECLARE v_charge_prefix VARCHAR(50);  
     
    
    if route_prefix = '89010' 
    then  
       set route_prefix = '89600';
    end if;  
            
    select   route_prefix INTO v_charge_prefix from ur_charge_did_prefix where prefix = left(did, CHAR_LENGTH(prefix))
    and status = 1    LIMIT 1;
       
    if IFNULL(v_charge_prefix,'') <> '' 
    then
       set route_prefix = v_charge_prefix;
    end if;  
   
     
  
    IF NOT EXISTS(select  1 from selector.call_selector where prefix_did = did LIMIT 1) 
    then 
     INSERT INTO selector.call_selector(sitecode,switchcode,trunk_in,port_in,prefix_did,pfxdid_len,trunk_out,port_out,prefix_cli)
     VALUES('GBR','*',trunk_in,'*',did, CHAR_LENGTH(did),trunk_out,port_out,'*');
    end if;  
   
  
    IF NOT EXISTS(SELECT  1 FROM non_subscriber_NB where canonicNB = did LIMIT 1) 
    then 
      INSERT INTO non_subscriber_NB (canonicNB,comment,expire_date)
      VALUES(did,'URAPP',NULL);
    end if;  
     
     
  
    IF NOT EXISTS(SELECT  1 FROM xlat_out where pfx = CONCAT_WS('',fwd_prefix,cast(did as CHAR(30))) LIMIT 1) 
    then 
      INSERT INTO xlat_out(sitecode,switchcode,trunkout,pfx,xlatout)
 	 VALUES(sitecode,'*','piper',CONCAT_WS('',fwd_prefix,did),CONCAT_WS('',route_prefix,did));
    ELSE
       UPDATE xlat_out SET xlatout = CONCAT_WS('',route_prefix,did)  where pfx = CONCAT_WS('',fwd_prefix,cast(did as CHAR(30)));
    end if;  
   
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `urapp_did_remove_routing` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `urapp_did_remove_routing`(did VARCHAR(20),  
route_prefix VARCHAR(10))
BEGIN
 
   
   DECLARE v_xlat_out VARCHAR(50);  
   DECLARE v_errcode INT;  
   DECLARE v_errmsg VARCHAR(20);  
  
    
 
   IF  EXISTS(select  1 from selector.call_selector a where a.prefix_did = did LIMIT 1) then
 
      delete from  selector.call_selector a where a.prefix_did = did;
   end if;  
  
 
   IF  EXISTS(SELECT  1 FROM non_subscriber_NB b where b.canonicNB = did LIMIT 1) then
 
      delete from non_subscriber_NB  b where b.canonicNB = did;
   end if;  
    
    
 
   IF  EXISTS(SELECT  1 FROM xlat_out c where c.xlatout = CONCAT_WS('',route_prefix,cast(did as CHAR(30))) LIMIT 1) then
 
      delete from xlat_out  c where c.xlatout = CONCAT_WS('',route_prefix,cast(did as CHAR(30)));
   end if;  
  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UR_ma_insert_phone_add_number_dtl` */;
ALTER DATABASE `hlrdb` CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `UR_ma_insert_phone_add_number_dtl`(v_company_id INT,    
v_domain_id INT,                
v_extension CHAR(255),    
v_external_number VARCHAR(15),    
v_assign_type INT,    
v_charge_price FLOAT,    
v_prorata FLOAT,    
v_tax_per VARCHAR(30),    
v_tax_fee FLOAT,    
v_total_charge FLOAT,    
v_reference_no VARCHAR(50),    
v_country VARCHAR(20),    
v_number_type VARCHAR(20),    
INOUT v_errcode INT ,    
INOUT v_errmsg VARCHAR(100) ,  
v_called_by VARCHAR(50),  
v_site_id INT,  
v_upload_path text(500),  
v_ivr_id INT ,  
v_pay_reference text(50),  
v_pay_maount FLOAT,  
v_pay_status VARCHAR(150),  
v_call_queue_id INT)
SWL_return:Begin    
    
   DECLARE v_ext_id INT;    
   DECLARE v_enterprise_id INT;                      
   DECLARE v_serviceinfo VARCHAR(32);    
   DECLARE v_did_id INT;
   DECLARE v_effective_caller_id_name VARCHAR(100);    
   DECLARE v_first_name VARCHAR(100);
   DECLARE v_last_name VARCHAR(100);    
   DECLARE v_order_id INT;
   DECLARE v_assign_date DATETIME(3);    
   DECLARE v_GetDate DATETIME(3);         
   DECLARE v_email CHAR(250);  
   DECLARE v_expdate DATETIME(3);  
   DECLARE v_comp_mobileno VARCHAR(20);  
   DECLARE v_company_name CHAR(250);
   
   IF v_upload_path is null 
   then
      set v_upload_path = '';
   END IF;
   
   if v_extension = 'null' 
   then
      set v_extension = null;
   end if;  
    
   set v_errcode = 0;    
   set v_errmsg = 'success';      
   set v_expdate = TIMESTAMPADD(YEAR,10,CURRENT_TIMESTAMP);  
   set v_GetDate = CURRENT_TIMESTAMP;   
    
 
   IF IFNULL(v_pay_reference,'') <> '' 
   then 
   INSERT INTO DID_PURCHASE_PAYMENT_LOG(company_id,did_number,extension,payment_reference,pay_amount,Pay_status,assign_type,create_date)
   VALUES(v_company_id,v_external_number,v_extension,v_pay_reference,v_pay_maount,v_pay_status,v_assign_type,CURRENT_TIMESTAMP);
   end if;  
   
   select   IFNULL(b.first_name,''), IFNULL(b.last_name,''), IFNULL(b.email,''), IFNULL(contact_number,'') INTO v_first_name,v_last_name,v_email,v_comp_mobileno from vbcp_company a
   join vtos_customer b on a.customer_id = b.customer_id where a.company_id = v_company_id    LIMIT 10;  
  
 
   CALL UR_user_insert_history_log(v_company_id,'PHONE NUMBER-MODULE','NUMBER-PURCHASE',v_external_number,'ADMIN');  
       

    
   if v_assign_type = 3 
   then
  insert into UR_phone_add_number_order(company_id,domain_id,reference_no,tax_per,tax_fee,total_charge,createdate)
      select v_company_id,v_domain_id,v_reference_no,v_tax_per,v_tax_fee,v_total_charge,CURRENT_TIMESTAMP;
      set v_order_id = LAST_INSERT_ID();
      insert into UR_phone_add_number_order_dtl(order_id,extension,external_number,
assign_type,charge_price,prorata,status,assigned_to,country,number_type,assign_date,site_id,upload_path,ivr_id)
      select v_order_id,v_extension,v_external_number,
       v_assign_type,v_charge_price,v_prorata,case when v_assign_type in(1,3) 
       then 
       0 else 1 end status,v_first_name,v_country,v_number_type,v_assign_date,v_site_id,
       v_upload_path,v_ivr_id;    
        

      
      UPDATE vbcp_landline_pool t set t.pool_status = 'taken',t.allocation_id = v_company_id
      where landline_number = v_external_number;
      
  
  
      CALL DIDPORTAL.did_portal_map_did_number(v_external_number,v_comp_mobileno,v_first_name,v_last_name,v_email,7,v_GetDate,v_GetDate,0,v_expdate);
      LEAVE SWL_return;
   end if;    
  
  
  

   if v_assign_type = 14 
   then
   INSERT INTO call_queue_external_number(company_id,Queue_id,did_number,pur_reference_no,create_date,charge_price)
   VALUES(v_company_id,v_call_queue_id,v_external_number,v_reference_no,CURRENT_TIMESTAMP,v_charge_price);    
       
   
   
      CALL DIDPORTAL.did_portal_map_did_number(v_external_number,v_comp_mobileno,v_first_name,v_last_name,v_email,7,v_GetDate,v_GetDate,0,v_expdate);
      
      IF IFNULL(v_external_number,'') <> '' 
      then  
         CALL hlrdb.urapp_did_do_routing_process(v_external_number,'btipxin','uk_Mobil','pipeukmobile','fwbmcm','89600','MCM');
      end if;
      
      insert into UR_phone_add_number_order(company_id,domain_id,reference_no,tax_per,tax_fee,total_charge,createdate)
      select v_company_id,v_domain_id,v_reference_no,v_tax_per,v_tax_fee,v_total_charge,CURRENT_TIMESTAMP;
      set v_order_id = LAST_INSERT_ID();
      insert into UR_phone_add_number_order_dtl(order_id,
extension,external_number,
assign_type,charge_price,prorata,status,assigned_to,country,number_type,assign_date,site_id,upload_path,ivr_id ,
call_queue_id)
      select v_order_id,v_extension,v_external_number,
       v_assign_type,v_charge_price,v_prorata,case when v_assign_type in(1,4,5,6) then 0 else 1 end status,v_first_name,
    v_country,v_number_type,v_assign_date,v_site_id,v_upload_path,v_ivr_id ,v_call_queue_id;
      LEAVE SWL_return;
   end if;    
  
  
  

   if v_assign_type in(2,7) 
   then
   
      select id,effective_caller_id_name INTO v_ext_id,v_effective_caller_id_name from dir_users  where domain_id = v_domain_id and user_id = v_extension;
    


    
      select   CONCAT(Firstname,' ',Surname) INTO v_first_name from UR_ECom_User_Extension_Dtl  where  Company_id = v_company_id and Extension_Number = v_extension    LIMIT 1;
    

      
      if exists(select id from did  where did_number = v_external_number) 
      then  
         UPDATE did d set d.svc_id = v_ext_id,d.svc_type = 'extn' where did_number = v_external_number;
      else
         insert into did(did_number, svc_type, svc_id) values(v_external_number, 'extn', v_ext_id);
      end if;
      
      set v_assign_date = CURRENT_TIMESTAMP;    
 
      
      select   sme_enterprise_id INTO v_enterprise_id From vbcp_pbx_account a
      left join vbcp_sme_sims_account b  ON b.company_id = a.company_id where domain_id = v_domain_id;
      
      set v_serviceinfo = CONCAT(cast(v_enterprise_id as CHAR(10)),':');
      
      if(v_extension <> '') 
      then 
         set v_serviceinfo = CONCAT_WS('',v_serviceinfo,v_extension);
      end if;        
   
  
      if not exists(select  1
      from vt_myaccount_def_ext_number a 
      join dir_users c  on a.dir_users_id = C.id
      where c.id = v_ext_id LIMIT 1) 
      then   
         select   ID INTO v_did_id from did where did_number = v_external_number and svc_id = v_ext_id;
         
         IF IFNULL(v_did_id,0) > 0 
         then    
    insert into vt_myaccount_def_ext_number(dir_users_id ,did_id)
            select v_ext_id ,v_did_id;
         end if;
      end if;
   end if;    
  
   insert into UR_phone_add_number_order(company_id,domain_id,reference_no,tax_per,tax_fee,total_charge,createdate)
   select v_company_id,v_domain_id,v_reference_no,v_tax_per,v_tax_fee,v_total_charge,CURRENT_TIMESTAMP;    
    
   set v_order_id = LAST_INSERT_ID();    
    
   if  v_ivr_id is not null 
   then
      select menu_name,extension_no INTO v_first_name,v_extension from ivr_site_config where company_id = v_company_id and ivr_id = v_ivr_id;
   end if;  
    
   insert into UR_phone_add_number_order_dtl(order_id,
extension,external_number,
assign_type,charge_price,prorata,status,assigned_to,country,number_type,assign_date,site_id,upload_path,ivr_id)
   select v_order_id,v_extension,v_external_number,
       v_assign_type,v_charge_price,v_prorata,case when v_assign_type in(1,4,5,6) then 0 else 1 end status,v_first_name,
    v_country,v_number_type,v_assign_date,v_site_id,v_upload_path,v_ivr_id;    
  
        
        

   
   UPDATE vbcp_landline_pool t
   set t.pool_status = 'taken',t.allocation_id = v_company_id  where landline_number = v_external_number;
   	
   select   company_name INTO v_company_name from vbcp_company where company_id = v_company_id    LIMIT 1;
  
  
 
   CALL DIDPORTAL.did_portal_map_did_number(v_external_number,v_comp_mobileno,v_first_name,v_last_name,v_email,7,v_GetDate,v_GetDate,0,v_expdate,v_company_id,v_company_name);  
  

   if not exists(select  1 from ur_local_number_log where company_id = v_company_id and did_number = v_external_number LIMIT 1) 
   then   
      insert into ur_local_number_log(company_id,extn,did_number,called_by,errcode,createdate,user_type)
      select v_company_id,v_extension,v_external_number,IFNULL(v_called_by,'MYACC-PHONENUMBER'),0,CURRENT_TIMESTAMP,1;
   end if;  
  
   IF IFNULL(v_external_number,'') <> '' 
   then 
      CALL hlrdb.urapp_did_do_routing_process(v_external_number,'btipxin','uk_Mobil','pipeukmobile','fwbmcm','89600','MCM');
   end if;  
  
  
   if v_assign_type = 1 
   then 
      CALL UR_ma_auto_receptionist_switchboard_insert(v_company_id,v_domain_id,v_external_number);
   end if;  
    
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `hlrdb` CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `ur_myaccount_delete_number` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ur_myaccount_delete_number`(did VARCHAR(20))
BEGIN


   DELETE from  non_subscriber_NB where canonicnb = did;
	
   DELETE from xlat_out where pfx = CONCAT_WS('','fwbmcm',did);
	
   DELETE FROM   selector.call_selector
   where prefix_did = did;


END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `vbcp_log_error` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `vbcp_log_error`(v_caller_code VARCHAR(1024),
	INOUT v_error_idx INT ,
	v_descript VARCHAR(1024))
begin

   DECLARE v_dummy INT;
	


insert into vbcp_log_unknown_errors(log_date, caller_code, descript)
   select CURRENT_TIMESTAMP, v_caller_code, v_descript;

   set v_error_idx = LAST_INSERT_ID();
   SET v_dummy = 0;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wsvc_set_enterprise` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wsvc_set_enterprise`(enterpriseid INT,
     enterprise_name VARCHAR(64),
     OUT errcode INT ,
     OUT errmsg VARCHAR(64))
begin
 
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
    BEGIN
       SET @SWV_Error = 1;
    END;
    
    sp_err2: begin
    
    sp_err:
    BEGIN
       SET @SWV_Error = 0;
       set errcode = -1;
       
       START TRANSACTION;
 
 	
       if not exists(select 1 from enterprise_ref a where a.enterprise_id = enterpriseid) then
 	
          SET @SWV_Error = 0;
          
          insert into enterprise_ref(enterprise_id, enterprise_name)
 		  values(enterpriseid,enterprise_name);
 		
          if @SWV_Error <> 0 or ROW_COUNT() <> 1 then
 		
             set errmsg = 'Insert to enterprise reference Fail';
             LEAVE sp_err;
          end if;
       else
          SET @SWV_Error = 0;
          
          update enterprise_ref a set a.enterprise_name = enterprise_name
          where a.enterprise_id = enterpriseid;
          
          if @SWV_Error <> 0 or ROW_COUNT() <> 1 then
 		
             set errmsg = 'Updating enterprise reference Fail';
             LEAVE sp_err;
          end if;
       end if;
       
       set errcode = 0;
       set errmsg = 'Set Enterprise on HLR Success';
       
       COMMIT;
       LEAVE sp_err2;
    END;
    ROLLBACK;
 
 end;
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-21  9:51:17
