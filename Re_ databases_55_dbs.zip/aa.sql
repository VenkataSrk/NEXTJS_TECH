-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: aa
-- ------------------------------------------------------
-- Server version	8.0.44-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `aa`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `aa` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `aa`;

--
-- Table structure for table `SupplierProducts`
--

DROP TABLE IF EXISTS `SupplierProducts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SupplierProducts` (
  `supplierId` int NOT NULL,
  `productId` int NOT NULL,
  PRIMARY KEY (`supplierId`,`productId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `aa_setting`
--

DROP TABLE IF EXISTS `aa_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aa_setting` (
  `sitecode` varchar(5) NOT NULL,
  `msg_welcome` varchar(32) DEFAULT NULL,
  `msg_welcome2` varchar(32) DEFAULT NULL,
  `msg_greeting` varchar(32) DEFAULT NULL,
  `operator` varchar(5) NOT NULL,
  `fwd_operator` varchar(5) DEFAULT NULL,
  `def_language` varchar(2) DEFAULT NULL,
  `len_extno` int NOT NULL,
  `default_trunkout` varchar(16) DEFAULT NULL,
  `call_autorejection` int DEFAULT NULL,
  `call_accept` int DEFAULT NULL,
  `call_screening` int DEFAULT NULL,
  `call_through` int DEFAULT NULL,
  PRIMARY KEY (`sitecode`),
  KEY `FK_aa_setting1Idx` (`sitecode`),
  CONSTRAINT `FK_aa_setting1` FOREIGN KEY (`sitecode`) REFERENCES `sites` (`sitecode`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `groups`
--

DROP TABLE IF EXISTS `groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `groups` (
  `groupid` int NOT NULL,
  `name` varchar(16) NOT NULL,
  PRIMARY KEY (`groupid`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `holiday`
--

DROP TABLE IF EXISTS `holiday`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `holiday` (
  `sitecode` varchar(5) NOT NULL,
  `month` int NOT NULL,
  `date` int NOT NULL,
  `desc` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`sitecode`,`month`,`date`),
  KEY `FK_holiday1Idx` (`sitecode`),
  CONSTRAINT `FK_holiday1` FOREIGN KEY (`sitecode`) REFERENCES `sites` (`sitecode`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `officehour`
--

DROP TABLE IF EXISTS `officehour`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `officehour` (
  `sitecode` varchar(5) NOT NULL,
  `daycode` int NOT NULL,
  `hhopen` int NOT NULL,
  `hhclose` int NOT NULL,
  PRIMARY KEY (`sitecode`,`daycode`),
  KEY `FK_officehour1Idx` (`sitecode`),
  CONSTRAINT `FK_officehour1` FOREIGN KEY (`sitecode`) REFERENCES `sites` (`sitecode`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `phones`
--

DROP TABLE IF EXISTS `phones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `phones` (
  `extension` varchar(5) NOT NULL,
  `type` int NOT NULL,
  `dialnumber` varchar(15) NOT NULL,
  `nocnx_action` int NOT NULL,
  `phonestatus` int NOT NULL,
  `divert_extension` varchar(5) DEFAULT NULL,
  `nocnx_extension` varchar(5) DEFAULT NULL,
  `password` varchar(16) DEFAULT NULL,
  `vtrunkout` varchar(16) DEFAULT NULL,
  `divert_reason` varchar(2) DEFAULT NULL,
  `IP` varchar(24) DEFAULT NULL,
  `trunkout` varchar(24) DEFAULT NULL,
  `sitecode` varchar(5) NOT NULL,
  `dialnumber2` varchar(20) DEFAULT NULL,
  `dialnumber3` varchar(20) DEFAULT NULL,
  `dial_mode` int DEFAULT NULL,
  `dial_timeout` int DEFAULT NULL,
  PRIMARY KEY (`sitecode`,`extension`),
  KEY `FK_userphone2Idx2` (`sitecode`,`extension`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `routing`
--

DROP TABLE IF EXISTS `routing`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `routing` (
  `ddi` varchar(16) NOT NULL,
  `trunkin` varchar(16) NOT NULL,
  `priority` int NOT NULL,
  `trunkout` varchar(16) NOT NULL,
  `servicetype` varchar(8) DEFAULT NULL,
  `serviceinfo` varchar(32) DEFAULT NULL,
  `ddilen` int DEFAULT NULL,
  `desc` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`ddi`,`trunkin`,`priority`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sites`
--

DROP TABLE IF EXISTS `sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sites` (
  `sitecode` varchar(5) NOT NULL,
  `name` varchar(15) DEFAULT NULL,
  `timediff` int NOT NULL,
  `currcode` varchar(3) DEFAULT NULL,
  `servicetype` int DEFAULT NULL,
  PRIMARY KEY (`sitecode`),
  KEY `FK_aa_setting1Idx2` (`sitecode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_phone`
--

DROP TABLE IF EXISTS `user_phone`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_phone` (
  `userid` int NOT NULL,
  `extension` varchar(5) NOT NULL,
  `sitecode` varchar(5) NOT NULL DEFAULT 'LON',
  PRIMARY KEY (`sitecode`,`userid`,`extension`),
  KEY `FK_userphone2Idx` (`sitecode`,`extension`),
  KEY `FK_userphone1Idx` (`sitecode`,`userid`),
  CONSTRAINT `FK_userphone1` FOREIGN KEY (`sitecode`, `userid`) REFERENCES `users` (`sitecode`, `userid`) ON UPDATE CASCADE,
  CONSTRAINT `FK_userphone2` FOREIGN KEY (`sitecode`, `extension`) REFERENCES `phones` (`sitecode`, `extension`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `userid` int NOT NULL,
  `name` varchar(16) NOT NULL,
  `fullname` varchar(64) DEFAULT NULL,
  `login` varchar(16) NOT NULL,
  `password` varchar(16) DEFAULT NULL,
  `startdate` datetime(3) DEFAULT NULL,
  `age` int DEFAULT NULL,
  `email` varchar(32) DEFAULT NULL,
  `userstatus` int NOT NULL,
  `groupid` int NOT NULL,
  `sitecode` varchar(5) NOT NULL DEFAULT 'LON',
  PRIMARY KEY (`sitecode`,`userid`),
  KEY `FK_users2Idx` (`groupid`),
  KEY `FK_users1Idx` (`userstatus`),
  KEY `FK_userphone1Idx2` (`sitecode`,`userid`),
  CONSTRAINT `FK_users1` FOREIGN KEY (`userstatus`) REFERENCES `userstatus` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userstatus`
--

DROP TABLE IF EXISTS `userstatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userstatus` (
  `id` int NOT NULL,
  `name` varchar(24) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_users1Idx2` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping events for database 'aa'
--

--
-- Dumping routines for database 'aa'
--
/*!50003 DROP PROCEDURE IF EXISTS `InsertSupplierProduct` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbteam`@`%` PROCEDURE `InsertSupplierProduct`(
    IN inSupplierId INT, 
    IN inProductId INT
)
BEGIN
    
    DECLARE EXIT HANDLER FOR 1062
    BEGIN
 	SELECT CONCAT('Duplicate key (',inSupplierId,',',inProductId,') occurred') AS message;
    END;
    
    
    INSERT INTO SupplierProducts(supplierId,productId)
    VALUES(inSupplierId,inProductId);
    
    
    SELECT COUNT(*) 
    FROM SupplierProducts
    WHERE supplierId = inSupplierId;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `myproc` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `myproc`()
BEGIN
	DECLARE i INT DEFAULT 1;
	DECLARE xml VARCHAR(500) DEFAULT '<Tier><Range>                <contract contract_period_id="1007" price1="1000" price2="900.00" price3="0"      discount1="10" discount2="0"  months1="0" months2="0" users_type_id="1" min_user_count="1"/></Range><Range></Tier>';

SELECT xml, i, ExtractValue(xml, '//Tier/Range');
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-21  9:49:37
