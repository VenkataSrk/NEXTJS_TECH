-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: crm
-- ------------------------------------------------------
-- Server version	8.0.44-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Hubspot_contact_del_log`
--

DROP TABLE IF EXISTS `Hubspot_contact_del_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Hubspot_contact_del_log` (
  `logid` int NOT NULL AUTO_INCREMENT,
  `mobileno` varchar(20) DEFAULT NULL,
  `freesimid` int DEFAULT NULL,
  `hubspot_contactid` int DEFAULT NULL,
  `create_date` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`logid`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=805 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ctp_fsb_Addon_number_country`
--

DROP TABLE IF EXISTS `ctp_fsb_Addon_number_country`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ctp_fsb_Addon_number_country` (
  `id` int NOT NULL AUTO_INCREMENT,
  `addon_idx` int DEFAULT NULL,
  `account_id` varchar(25) DEFAULT NULL,
  `country` varchar(200) DEFAULT NULL,
  UNIQUE KEY `id` (`id`),
  KEY `FK__ctp_fsb_A__addon__7FE23823Idx` (`addon_idx`),
  CONSTRAINT `FK__ctp_fsb_A__addon__7FE23823` FOREIGN KEY (`addon_idx`) REFERENCES `fsb_addon_number` (`addon_idx`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `freesim`
--

DROP TABLE IF EXISTS `freesim`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `freesim` (
  `freesimid` int NOT NULL AUTO_INCREMENT,
  `subscriberid` int NOT NULL,
  `iccid` varchar(20) DEFAULT NULL,
  `freesimstatus` int DEFAULT NULL,
  `registerdate` datetime(3) DEFAULT NULL,
  `activatedate` datetime(3) DEFAULT NULL,
  `sentdate` datetime(3) DEFAULT NULL,
  `freesimtype` bigint DEFAULT NULL,
  `cybersourceid` varchar(40) DEFAULT NULL,
  `CrmUser` varchar(16) DEFAULT NULL,
  `msisdn_referrer` varchar(15) DEFAULT NULL,
  `postpaidinfo` int DEFAULT NULL,
  `CrmCS` varchar(32) DEFAULT NULL,
  `source_address` varchar(500) DEFAULT NULL,
  `stat_id` int DEFAULT NULL,
  `ordersim_url` varchar(500) DEFAULT NULL,
  `clickid` varchar(32) DEFAULT NULL,
  `hasSend` tinyint(1) NOT NULL,
  `promocode` varchar(32) DEFAULT NULL,
  `royal_mail_ref` varchar(100) DEFAULT NULL,
  `fav_call_country` varchar(250) DEFAULT NULL,
  `sim_type` int DEFAULT NULL,
  `itemid` int DEFAULT NULL,
  `ip_address` varchar(100) DEFAULT NULL,
  `landing_page_url` varchar(500) DEFAULT NULL,
  `last_visit_page_url` varchar(500) DEFAULT NULL,
  `replacement_date` datetime(3) DEFAULT NULL,
  `item_amount` float DEFAULT NULL,
  `postpaid_billtype` int DEFAULT NULL,
  `promo_bundleid` int DEFAULT NULL,
  `hubspot_contactid` int DEFAULT NULL,
  PRIMARY KEY (`freesimid`),
  KEY `freesim_idx1` (`subscriberid`),
  KEY `freesim_idx2` (`subscriberid`,`registerdate`,`freesimstatus`,`freesimtype`),
  KEY `freesim_idx3` (`msisdn_referrer`),
  KEY `idx` (`iccid`),
  KEY `idx_cybersourceid` (`cybersourceid`),
  KEY `idx_date` (`registerdate`),
  KEY `idx_fstatus` (`freesimstatus`),
  KEY `idx_ftyp` (`freesimtype`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=2072311 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fsb_accounts`
--

DROP TABLE IF EXISTS `fsb_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fsb_accounts` (
  `account_number_global_traffic` int NOT NULL,
  `msisdn_main` varchar(20) NOT NULL,
  `msisdn_destination` varchar(20) NOT NULL,
  `reg_idx` int DEFAULT NULL,
  `acc_status` int DEFAULT NULL,
  `expired_date` datetime(3) DEFAULT NULL,
  `bundle_id` int DEFAULT NULL,
  `start_date` datetime(3) DEFAULT NULL,
  `billing_date` datetime(3) DEFAULT NULL,
  `auto_renewal` int DEFAULT NULL,
  `product_type` varchar(100) DEFAULT NULL,
  `join_date` datetime(3) DEFAULT NULL,
  `last_update` datetime(3) DEFAULT NULL,
  `account_id` varchar(100) DEFAULT NULL,
  `changed_main_number` int DEFAULT NULL,
  `addon_bundleid` int DEFAULT '0',
  `isnew` int DEFAULT '0',
  PRIMARY KEY (`account_number_global_traffic`,`msisdn_main`,`msisdn_destination`),
  KEY `IX_fsb_accounts` (`msisdn_main`,`msisdn_destination`),
  KEY `IX_fsb_accounts_1` (`account_id`,`msisdn_destination`),
  KEY `IX_fsb_accounts_2` (`msisdn_main`,`bundle_id`),
  KEY `IX_fsb_accounts_3` (`account_id`,`bundle_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fsb_addon_number`
--

DROP TABLE IF EXISTS `fsb_addon_number`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fsb_addon_number` (
  `addon_idx` int NOT NULL AUTO_INCREMENT,
  `addon_msisdn` varchar(20) DEFAULT NULL,
  `process_status` int DEFAULT NULL,
  `reg_idx` int DEFAULT NULL,
  `join_date` datetime(3) DEFAULT NULL,
  `account_id` varchar(100) DEFAULT NULL,
  `clitypes` int DEFAULT NULL,
  `internal_process_stat` int DEFAULT NULL,
  `country` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`addon_idx`),
  KEY `FK_fsb_addon_number_fsb_ref_process_statusIdx` (`process_status`),
  KEY `FK_fsb_addon_number_fsb_registrationIdx` (`reg_idx`),
  KEY `FK__ctp_fsb_A__addon__7FE23823Idx2` (`addon_idx`),
  CONSTRAINT `FK_fsb_addon_number_fsb_ref_process_status` FOREIGN KEY (`process_status`) REFERENCES `fsb_ref_process_status` (`status_id`),
  CONSTRAINT `FK_fsb_addon_number_fsb_registration` FOREIGN KEY (`reg_idx`) REFERENCES `fsb_registration` (`idx`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fsb_cli_number`
--

DROP TABLE IF EXISTS `fsb_cli_number`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fsb_cli_number` (
  `landline_msisdn` varchar(30) DEFAULT NULL,
  `reg_idx` int DEFAULT NULL,
  `createdate` datetime(3) DEFAULT NULL,
  `cli_idx` int NOT NULL AUTO_INCREMENT,
  `process_status` int DEFAULT '0',
  `process_date` datetime(3) DEFAULT NULL,
  UNIQUE KEY `cli_idx` (`cli_idx`),
  KEY `FK__fsb_cli_n__proce__5ED57EBCIdx` (`process_status`),
  KEY `FK__fsb_cli_n__reg_i__5CED364AIdx` (`reg_idx`),
  CONSTRAINT `FK__fsb_cli_n__proce__5ED57EBC` FOREIGN KEY (`process_status`) REFERENCES `fsb_ref_process_status` (`status_id`),
  CONSTRAINT `FK__fsb_cli_n__reg_i__5CED364A` FOREIGN KEY (`reg_idx`) REFERENCES `fsb_registration` (`idx`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fsb_family_number`
--

DROP TABLE IF EXISTS `fsb_family_number`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fsb_family_number` (
  `dest_msisdn` varchar(20) DEFAULT NULL,
  `title` varchar(16) DEFAULT NULL,
  `firstname` varchar(30) DEFAULT NULL,
  `lastname` varchar(30) DEFAULT NULL,
  `postcode` varchar(8) DEFAULT NULL,
  `houseno` varchar(50) DEFAULT NULL,
  `street` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `country` varchar(2) DEFAULT NULL,
  `dest_idx` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`dest_idx`),
  KEY `FK_fsb_registration_fsb_family_numberIdx2` (`dest_idx`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fsb_main_number`
--

DROP TABLE IF EXISTS `fsb_main_number`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fsb_main_number` (
  `main_msisdn` varchar(20) NOT NULL,
  `title` varchar(16) DEFAULT NULL,
  `firstname` varchar(30) DEFAULT NULL,
  `lastname` varchar(30) DEFAULT NULL,
  `email` varchar(48) DEFAULT NULL,
  `postcode` varchar(8) DEFAULT NULL,
  `houseno` varchar(50) DEFAULT NULL,
  `street` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `country` varchar(2) DEFAULT NULL,
  `msisdn_idx` int NOT NULL AUTO_INCREMENT,
  `process_status` int DEFAULT NULL,
  `main_clitype` int DEFAULT NULL,
  PRIMARY KEY (`msisdn_idx`),
  KEY `FK_fsb_main_number_fsb_ref_process_statusIdx` (`process_status`),
  KEY `FK_fsb_registration_fsb_main_numberIdx2` (`msisdn_idx`),
  CONSTRAINT `FK_fsb_main_number_fsb_ref_process_status` FOREIGN KEY (`process_status`) REFERENCES `fsb_ref_process_status` (`status_id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fsb_ref_process_status`
--

DROP TABLE IF EXISTS `fsb_ref_process_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fsb_ref_process_status` (
  `status_id` int NOT NULL,
  `status_description` varchar(128) NOT NULL,
  PRIMARY KEY (`status_id`),
  KEY `FK_fsb_addon_number_fsb_ref_process_statusIdx2` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fsb_ref_product_type`
--

DROP TABLE IF EXISTS `fsb_ref_product_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fsb_ref_product_type` (
  `producttype_id` varchar(100) NOT NULL,
  `producttype_desc` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`producttype_id`),
  KEY `FK_FSB_REGISTRATION_FSB_REF_PRODUCT_TYPEIdx2` (`producttype_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fsb_ref_status`
--

DROP TABLE IF EXISTS `fsb_ref_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fsb_ref_status` (
  `status_id` int NOT NULL,
  `status_description` varchar(128) NOT NULL,
  PRIMARY KEY (`status_id`),
  KEY `FK_fsb_registration_fsb_ref_statusIdx2` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fsb_registration`
--

DROP TABLE IF EXISTS `fsb_registration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fsb_registration` (
  `idx` int NOT NULL AUTO_INCREMENT,
  `main_msisdn` varchar(20) DEFAULT NULL,
  `dest_msisdn` varchar(20) DEFAULT NULL,
  `registerdate` datetime(3) DEFAULT NULL,
  `status` int DEFAULT NULL,
  `sourcereg` varchar(32) DEFAULT NULL,
  `dest_idx` int DEFAULT NULL,
  `servicesentdate` datetime(3) DEFAULT NULL,
  `serviceresultdate` datetime(3) DEFAULT NULL,
  `main_msisdn_idx` int DEFAULT NULL,
  `last_update` datetime(3) DEFAULT NULL,
  `amount` float DEFAULT NULL,
  `paymode` int DEFAULT NULL,
  `account_id` varchar(100) DEFAULT NULL,
  `product_type` varchar(100) DEFAULT NULL,
  `main_clitypes` int DEFAULT NULL,
  `payref` varchar(50) DEFAULT NULL,
  `internal_process_stat` int DEFAULT NULL,
  `registration_fee` float DEFAULT NULL,
  `landline_msisdn` varchar(30) DEFAULT NULL,
  `cli_idx` int DEFAULT NULL,
  `addonbundle_status` int DEFAULT NULL,
  `act_status` int NOT NULL DEFAULT '0',
  `renewdate` datetime(3) DEFAULT NULL,
  `Intermediateno` varchar(40) DEFAULT NULL,
  `IsMappingConfirmation` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`idx`),
  KEY `FK_fsb_registration_fsb_family_numberIdx` (`dest_idx`),
  KEY `FK_fsb_registration_fsb_main_numberIdx` (`main_msisdn_idx`),
  KEY `FK_FSB_REGISTRATION_FSB_REF_PRODUCT_TYPEIdx` (`product_type`),
  KEY `FK_fsb_registration_fsb_ref_statusIdx` (`status`),
  KEY `FK_fsb_addon_number_fsb_registrationIdx2` (`idx`),
  CONSTRAINT `FK_fsb_registration_fsb_family_number` FOREIGN KEY (`dest_idx`) REFERENCES `fsb_family_number` (`dest_idx`),
  CONSTRAINT `FK_fsb_registration_fsb_main_number` FOREIGN KEY (`main_msisdn_idx`) REFERENCES `fsb_main_number` (`msisdn_idx`),
  CONSTRAINT `FK_FSB_REGISTRATION_FSB_REF_PRODUCT_TYPE` FOREIGN KEY (`product_type`) REFERENCES `fsb_ref_product_type` (`producttype_id`),
  CONSTRAINT `FK_fsb_registration_fsb_ref_status` FOREIGN KEY (`status`) REFERENCES `fsb_ref_status` (`status_id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fsb_registration_log`
--

DROP TABLE IF EXISTS `fsb_registration_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fsb_registration_log` (
  `history_idx` int NOT NULL AUTO_INCREMENT,
  `reg_idx` int DEFAULT NULL,
  `login` varchar(20) DEFAULT NULL,
  `main_msisdn` varchar(20) DEFAULT NULL,
  `dest_msisdn` varchar(20) DEFAULT NULL,
  `verification_code` varchar(5) DEFAULT NULL,
  `verification_status` int DEFAULT NULL,
  `verification_counter` int DEFAULT NULL,
  `create_date` datetime(3) DEFAULT NULL,
  `update_date` datetime(3) DEFAULT NULL,
  `paymode` int DEFAULT NULL,
  `payref` varchar(50) DEFAULT NULL,
  `paydesc` varchar(100) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `source_code` varchar(50) DEFAULT NULL,
  `ip` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`history_idx`),
  KEY `FK_fsb_registration_log_fsb_registrationIdx` (`reg_idx`),
  CONSTRAINT `FK_fsb_registration_log_fsb_registration` FOREIGN KEY (`reg_idx`) REFERENCES `fsb_registration` (`idx`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fsb_registration_ng`
--

DROP TABLE IF EXISTS `fsb_registration_ng`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fsb_registration_ng` (
  `idx` int NOT NULL AUTO_INCREMENT,
  `main_msisdn` varchar(20) DEFAULT NULL,
  `dest_msisdn` varchar(20) DEFAULT NULL,
  `registerdate` datetime(3) DEFAULT NULL,
  `status` int DEFAULT NULL,
  `sourcereg` varchar(32) DEFAULT NULL,
  `dest_idx` int DEFAULT NULL,
  `servicesentdate` datetime(3) DEFAULT NULL,
  `serviceresultdate` datetime(3) DEFAULT NULL,
  `main_msisdn_idx` int DEFAULT NULL,
  `last_update` datetime(3) DEFAULT NULL,
  `amount` float DEFAULT NULL,
  `paymode` int DEFAULT NULL,
  `account_id` varchar(100) DEFAULT NULL,
  `product_type` varchar(100) DEFAULT NULL,
  `main_clitypes` int DEFAULT NULL,
  `payref` varchar(50) DEFAULT NULL,
  `internal_process_stat` int DEFAULT NULL,
  `registration_fee` float DEFAULT NULL,
  `landline_msisdn` varchar(30) DEFAULT NULL,
  `cli_idx` int DEFAULT NULL,
  `addonbundle_status` int DEFAULT NULL,
  PRIMARY KEY (`idx`),
  KEY `FK_fsb_registration_ng_fsb_family_numberIdx` (`dest_idx`),
  KEY `FK_fsb_registration_ng_fsb_main_numberIdx` (`main_msisdn_idx`),
  KEY `FK_FSB_REGISTRATION_ng_FSB_REF_PRODUCT_TYPEIdx` (`product_type`),
  KEY `FK_fsb_registration_ng_fsb_ref_statusIdx` (`status`),
  CONSTRAINT `FK_fsb_registration_ng_fsb_family_number` FOREIGN KEY (`dest_idx`) REFERENCES `fsb_family_number` (`dest_idx`),
  CONSTRAINT `FK_fsb_registration_ng_fsb_main_number` FOREIGN KEY (`main_msisdn_idx`) REFERENCES `fsb_main_number` (`msisdn_idx`),
  CONSTRAINT `FK_FSB_REGISTRATION_ng_FSB_REF_PRODUCT_TYPE` FOREIGN KEY (`product_type`) REFERENCES `fsb_ref_product_type` (`producttype_id`),
  CONSTRAINT `FK_fsb_registration_ng_fsb_ref_status` FOREIGN KEY (`status`) REFERENCES `fsb_ref_status` (`status_id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fsb_registration_return`
--

DROP TABLE IF EXISTS `fsb_registration_return`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fsb_registration_return` (
  `idx` int NOT NULL AUTO_INCREMENT,
  `fsb_registration_idx` int DEFAULT NULL,
  `fsb_addon_idx` int DEFAULT NULL,
  `fsb_destination_idx` int DEFAULT NULL,
  `processing_date` datetime(3) NOT NULL,
  `source_method` varchar(100) NOT NULL,
  `final_status_code` int NOT NULL,
  `status_description_operator` varchar(2048) NOT NULL,
  `status_comments_operator` varchar(2048) DEFAULT NULL,
  PRIMARY KEY (`idx`),
  KEY `FK2_fsb_registration_return_fsb_registrationIdx` (`fsb_addon_idx`),
  KEY `FK_fsb_registration_return_fsb_family_numberIdx` (`fsb_destination_idx`),
  KEY `FK_fsb_registration_return_fsb_ref_statusIdx` (`final_status_code`),
  KEY `FK_fsb_registration_return_fsb_registrationIdx` (`fsb_registration_idx`),
  CONSTRAINT `FK2_fsb_registration_return_fsb_registration` FOREIGN KEY (`fsb_addon_idx`) REFERENCES `fsb_addon_number` (`addon_idx`),
  CONSTRAINT `FK_fsb_registration_return_fsb_family_number` FOREIGN KEY (`fsb_destination_idx`) REFERENCES `fsb_family_number` (`dest_idx`),
  CONSTRAINT `FK_fsb_registration_return_fsb_ref_status` FOREIGN KEY (`final_status_code`) REFERENCES `fsb_ref_status` (`status_id`),
  CONSTRAINT `FK_fsb_registration_return_fsb_registration` FOREIGN KEY (`fsb_registration_idx`) REFERENCES `fsb_registration` (`idx`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pp_bills`
--

DROP TABLE IF EXISTS `pp_bills`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pp_bills` (
  `bill_reference` varchar(32) NOT NULL,
  `pp_customer_id` int NOT NULL,
  `bill_date` datetime(3) NOT NULL,
  `bill_amount` float NOT NULL,
  PRIMARY KEY (`bill_reference`,`pp_customer_id`),
  KEY `pp_customers_pp_bills_fkIdx` (`pp_customer_id`),
  CONSTRAINT `pp_customers_pp_bills_fk` FOREIGN KEY (`pp_customer_id`) REFERENCES `pp_customers` (`pp_customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pp_customers`
--

DROP TABLE IF EXISTS `pp_customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pp_customers` (
  `pp_customer_id` int NOT NULL AUTO_INCREMENT,
  `freesimid` int DEFAULT NULL,
  `service_status` varchar(32) NOT NULL,
  `mobileno` varchar(16) DEFAULT NULL,
  `iccid` varchar(20) DEFAULT NULL,
  `activatedate` datetime(3) DEFAULT NULL,
  `subscriberid` int DEFAULT NULL,
  `fullname` varchar(64) DEFAULT NULL,
  `istest` int DEFAULT NULL,
  `outstanding_amount` float DEFAULT NULL,
  `portin_number` varchar(30) DEFAULT NULL,
  `crmid` int DEFAULT '0',
  `crm2id` int DEFAULT '0',
  `crm2orderid` int DEFAULT '0',
  `bill_type` int NOT NULL DEFAULT '0',
  `plan_value` float DEFAULT NULL,
  `sim_first_update` datetime(3) DEFAULT NULL,
  `billing_date` datetime(3) DEFAULT NULL,
  `disc_apply_flag` int DEFAULT NULL,
  `plan_disc_price` float DEFAULT NULL,
  PRIMARY KEY (`pp_customer_id`),
  KEY `idx1_pp_customers` (`mobileno`),
  KEY `idx2_pp_customers` (`freesimid`),
  KEY `idx3_pp_customers` (`service_status`),
  KEY `idx4_pp_customers` (`activatedate`),
  KEY `idx5_pp_customers` (`subscriberid`),
  KEY `idx6_pp_customers` (`fullname`),
  KEY `idx7_pp_customers` (`istest`),
  KEY `idx8_pp_customers` (`pp_customer_id`),
  CONSTRAINT `pp_ref_service_status_pp_customers_fk` FOREIGN KEY (`service_status`) REFERENCES `pp_ref_service_status` (`service_status`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=40598 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pp_excess_usage`
--

DROP TABLE IF EXISTS `pp_excess_usage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pp_excess_usage` (
  `month` int NOT NULL,
  `year` int NOT NULL,
  `pp_customer_id` int NOT NULL,
  `amount` float NOT NULL,
  `insertdate` datetime(3) NOT NULL,
  `insertedby` varchar(32) NOT NULL,
  PRIMARY KEY (`month`,`year`,`pp_customer_id`),
  KEY `pp_customers_pp_excess_usage_fkIdx` (`pp_customer_id`),
  CONSTRAINT `pp_customers_pp_excess_usage_fk` FOREIGN KEY (`pp_customer_id`) REFERENCES `pp_customers` (`pp_customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pp_fsb_customers`
--

DROP TABLE IF EXISTS `pp_fsb_customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pp_fsb_customers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `reg_idx` int NOT NULL,
  `pp_customer_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_pp_fsb_reg_idxIdx` (`reg_idx`),
  KEY `fk_pp_fsb_pp_customer_idIdx` (`pp_customer_id`),
  CONSTRAINT `fk_pp_fsb_pp_customer_id` FOREIGN KEY (`pp_customer_id`) REFERENCES `pp_customers` (`pp_customer_id`),
  CONSTRAINT `fk_pp_fsb_reg_idx` FOREIGN KEY (`reg_idx`) REFERENCES `fsb_registration` (`idx`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pp_log_iccid_mobileno`
--

DROP TABLE IF EXISTS `pp_log_iccid_mobileno`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pp_log_iccid_mobileno` (
  `idx` int NOT NULL AUTO_INCREMENT,
  `pp_customer_id` int NOT NULL,
  `prev_mobileno` varchar(16) NOT NULL,
  `after_mobileno` varchar(16) NOT NULL,
  `prev_iccid` varchar(20) NOT NULL,
  `after_iccid` varchar(20) NOT NULL,
  `uodatedate` datetime(3) NOT NULL,
  `updateby` varchar(32) NOT NULL,
  PRIMARY KEY (`idx`),
  KEY `pp_customers_pp_log_iccid_mobileno_fkIdx` (`pp_customer_id`),
  CONSTRAINT `pp_customers_pp_log_iccid_mobileno_fk` FOREIGN KEY (`pp_customer_id`) REFERENCES `pp_customers` (`pp_customer_id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pp_log_service_status`
--

DROP TABLE IF EXISTS `pp_log_service_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pp_log_service_status` (
  `idx` int NOT NULL AUTO_INCREMENT,
  `pp_customer_id` int NOT NULL,
  `prev_service_status` varchar(32) NOT NULL,
  `after_service_status` varchar(32) NOT NULL,
  `updatedate` datetime(3) NOT NULL,
  `Updateby` varchar(32) NOT NULL,
  PRIMARY KEY (`idx`),
  KEY `pp_ref_service_status_pp_log_service_status_fkIdx` (`prev_service_status`),
  KEY `pp_ref_service_status_pp_log_service_status_fk1Idx` (`after_service_status`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pp_payments`
--

DROP TABLE IF EXISTS `pp_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pp_payments` (
  `pay_reference` varchar(32) NOT NULL,
  `pp_customer_id` int DEFAULT NULL,
  `pay_date` datetime(3) NOT NULL,
  `pay_method` varchar(32) NOT NULL,
  `amount` float NOT NULL,
  `updatedby` varchar(32) NOT NULL,
  `status` int DEFAULT NULL,
  `idx` int NOT NULL AUTO_INCREMENT,
  `status_updated_date` datetime(3) DEFAULT NULL,
  `status_updated_by` varchar(25) DEFAULT NULL,
  `Org_Pro_Date` datetime(3) DEFAULT NULL,
  `prev_status_queue` int DEFAULT NULL,
  PRIMARY KEY (`idx`),
  KEY `idx1_pp_payments` (`pp_customer_id`),
  KEY `IX_NC_idx_pp_payments` (`idx`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=644029 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pp_plans`
--

DROP TABLE IF EXISTS `pp_plans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pp_plans` (
  `idx` int NOT NULL AUTO_INCREMENT,
  `pp_customer_id` int NOT NULL,
  `plan_name` varchar(32) NOT NULL,
  `plan_active_status` int NOT NULL,
  `plan_start_date` datetime(3) NOT NULL,
  `plan_end_date` datetime(3) DEFAULT NULL,
  `postpaidbundled` int DEFAULT NULL,
  `paymentplanid` int DEFAULT NULL,
  PRIMARY KEY (`idx`),
  KEY `pp_customers_pp_plans_fkIdx` (`pp_customer_id`),
  KEY `pp_plan_active_status_pp_plans_fkIdx` (`plan_active_status`),
  KEY `pp_ref_plan_name_pp_plans_fkIdx` (`plan_name`),
  CONSTRAINT `pp_customers_pp_plans_fk` FOREIGN KEY (`pp_customer_id`) REFERENCES `pp_customers` (`pp_customer_id`),
  CONSTRAINT `pp_plan_active_status_pp_plans_fk` FOREIGN KEY (`plan_active_status`) REFERENCES `pp_ref_plan_active_status` (`plan_active_status`),
  CONSTRAINT `pp_ref_plan_name_pp_plans_fk` FOREIGN KEY (`plan_name`) REFERENCES `pp_ref_plan_name` (`plan_name`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pp_ref_plan_active_status`
--

DROP TABLE IF EXISTS `pp_ref_plan_active_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pp_ref_plan_active_status` (
  `plan_active_status` int NOT NULL,
  `descript` varchar(64) NOT NULL,
  PRIMARY KEY (`plan_active_status`),
  KEY `pp_plan_active_status_pp_plans_fkIdx2` (`plan_active_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pp_ref_plan_name`
--

DROP TABLE IF EXISTS `pp_ref_plan_name`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pp_ref_plan_name` (
  `plan_name` varchar(32) NOT NULL,
  `descript` varchar(64) DEFAULT NULL,
  `plan_value` float DEFAULT NULL,
  PRIMARY KEY (`plan_name`),
  KEY `pp_ref_plan_name_pp_plans_fkIdx2` (`plan_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pp_ref_scheduled_action_type`
--

DROP TABLE IF EXISTS `pp_ref_scheduled_action_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pp_ref_scheduled_action_type` (
  `scheduled_action_type` varchar(32) NOT NULL,
  `descript` varchar(64) NOT NULL,
  PRIMARY KEY (`scheduled_action_type`),
  KEY `pp_ref_scheduled_action_type_pp_scheduled_actions_fkIdx2` (`scheduled_action_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pp_ref_service_status`
--

DROP TABLE IF EXISTS `pp_ref_service_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pp_ref_service_status` (
  `service_status` varchar(32) NOT NULL,
  `descript` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`service_status`),
  KEY `pp_ref_service_status_pp_customers_fkIdx` (`service_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pp_requestlog`
--

DROP TABLE IF EXISTS `pp_requestlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pp_requestlog` (
  `requesttime` datetime(3) DEFAULT NULL,
  `server_address` varchar(32) DEFAULT NULL,
  `client_address` varchar(32) DEFAULT NULL,
  `spname` varchar(64) DEFAULT NULL,
  `params` varchar(2000) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=1759219 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pp_scheduled_actions`
--

DROP TABLE IF EXISTS `pp_scheduled_actions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pp_scheduled_actions` (
  `idx` int NOT NULL AUTO_INCREMENT,
  `scheduledate` datetime(3) NOT NULL,
  `scheduled_action_type` varchar(32) NOT NULL,
  `updatedate` datetime(3) DEFAULT NULL,
  `updateby` varchar(32) NOT NULL,
  `pp_customer_id` int NOT NULL,
  `termination_fee` float DEFAULT NULL,
  `proccess` int DEFAULT NULL,
  `jobstatus` int DEFAULT NULL,
  `sitecode` varchar(3) DEFAULT NULL,
  `insertdate` datetime(3) DEFAULT NULL,
  `balance` float DEFAULT NULL,
  `new_trffclass` varchar(4) DEFAULT NULL,
  `errmessage` varchar(128) DEFAULT NULL,
  `mobileno` varchar(16) DEFAULT NULL,
  PRIMARY KEY (`idx`),
  KEY `pp_customers_pp_scheduled_acions_fkIdx` (`pp_customer_id`),
  KEY `pp_ref_scheduled_action_type_pp_scheduled_actions_fkIdx` (`scheduled_action_type`),
  CONSTRAINT `pp_customers_pp_scheduled_acions_fk` FOREIGN KEY (`pp_customer_id`) REFERENCES `pp_customers` (`pp_customer_id`),
  CONSTRAINT `pp_ref_scheduled_action_type_pp_scheduled_actions_fk` FOREIGN KEY (`scheduled_action_type`) REFERENCES `pp_ref_scheduled_action_type` (`scheduled_action_type`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sim_swap_log`
--

DROP TABLE IF EXISTS `sim_swap_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sim_swap_log` (
  `createdate` datetime(3) DEFAULT NULL,
  `msisdn` varchar(15) DEFAULT NULL,
  `cc_old` varchar(8) DEFAULT NULL,
  `bc_old` int DEFAULT NULL,
  `sc_old` int DEFAULT NULL,
  `iccid_old` varchar(20) DEFAULT NULL,
  `balance_old` float DEFAULT NULL,
  `cc_new` varchar(8) DEFAULT NULL,
  `bc_new` int DEFAULT NULL,
  `sc_new` int DEFAULT NULL,
  `afterbal` float DEFAULT NULL,
  `errcode` int DEFAULT NULL,
  `errmsg` varchar(100) DEFAULT NULL,
  `comment` varchar(100) DEFAULT NULL,
  `iccid_new` varchar(20) DEFAULT NULL,
  `transfertypeid` int DEFAULT NULL,
  `verification` varchar(400) DEFAULT NULL,
  `user` varchar(32) DEFAULT NULL,
  `msisdn_new` varchar(15) DEFAULT NULL,
  `jira_ticket` varchar(64) DEFAULT NULL,
  `charge` float DEFAULT NULL,
  `multiimsi_sitecode_old` varchar(5) DEFAULT NULL,
  `multiimsi_sitecode_new` varchar(5) DEFAULT NULL,
  `brand_type_old` int DEFAULT NULL,
  `brand_tyoe_new` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `subscriber`
--

DROP TABLE IF EXISTS `subscriber`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subscriber` (
  `subscriberid` int NOT NULL AUTO_INCREMENT,
  `title` varchar(16) DEFAULT NULL,
  `firstname` varchar(30) NOT NULL,
  `lastname` varchar(30) NOT NULL,
  `houseno` varchar(50) DEFAULT NULL,
  `address1` varchar(50) DEFAULT NULL,
  `address2` varchar(50) DEFAULT NULL,
  `city` varchar(20) DEFAULT NULL,
  `postcode` varchar(8) DEFAULT NULL,
  `state` varchar(20) DEFAULT NULL,
  `countrycode` char(2) NOT NULL,
  `telephone` varchar(15) DEFAULT NULL,
  `mobilephone` varchar(15) DEFAULT NULL,
  `fax` varchar(15) DEFAULT NULL,
  `email` varchar(48) DEFAULT NULL,
  `birthdate` datetime(3) DEFAULT NULL,
  `securityquestion` varchar(100) DEFAULT NULL,
  `securityanswer` varchar(50) DEFAULT NULL,
  `subscribertype` int NOT NULL,
  `billingtype` varchar(6) DEFAULT NULL,
  `packagetype` int DEFAULT NULL,
  `personnumber` varchar(15) DEFAULT NULL,
  `mobileno` varchar(20) DEFAULT NULL,
  `sourcereg` varchar(50) DEFAULT NULL,
  `createdate` datetime(3) DEFAULT NULL,
  `social_securityno` varchar(16) DEFAULT NULL,
  `subscriberchannel` varchar(50) DEFAULT NULL,
  `personalidtype` int DEFAULT NULL,
  `language` varchar(100) DEFAULT NULL,
  `gender` varchar(20) DEFAULT NULL,
  `bySMS` int DEFAULT NULL,
  `byEmail` int DEFAULT NULL,
  `referenceno` varchar(50) DEFAULT NULL,
  `comment` varchar(1000) DEFAULT NULL,
  `activationdate` datetime(3) DEFAULT NULL,
  `activateby` int DEFAULT NULL,
  `simtype` varchar(15) NOT NULL,
  `address3` varchar(50) DEFAULT NULL,
  `byCall` int DEFAULT NULL,
  `security_answer` varchar(25) DEFAULT NULL,
  `signup_date` datetime(3) DEFAULT NULL,
  `last_login_date` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`subscriberid`),
  KEY `country_iso3166_subscriber_FK1Idx` (`countrycode`),
  KEY `idx` (`mobilephone`),
  KEY `idx_id_firstname_lastname` (`subscriberid`,`firstname`,`lastname`),
  KEY `lf` (`firstname`,`lastname`),
  KEY `pc2profilePK_2` (`subscribertype`),
  KEY `subscriber_idx1` (`houseno`,`postcode`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=2358676 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vmuk_SecurityCode`
--

DROP TABLE IF EXISTS `vmuk_SecurityCode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vmuk_SecurityCode` (
  `idx` int NOT NULL AUTO_INCREMENT,
  `MobileNo` varchar(12) DEFAULT NULL,
  `SecurityCode` varchar(10) DEFAULT NULL,
  `CreatedDate` datetime(3) DEFAULT NULL,
  `lastupDate` datetime(3) DEFAULT NULL,
  `Status` int DEFAULT NULL,
  `productid` int DEFAULT NULL,
  `amount` float DEFAULT NULL,
  `CrmCS` varchar(32) DEFAULT NULL,
  `amountbonus` float DEFAULT NULL,
  `currency` varchar(5) DEFAULT NULL,
  `paymentref` varchar(64) DEFAULT NULL,
  UNIQUE KEY `idx` (`idx`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vt_pp_bills`
--

DROP TABLE IF EXISTS `vt_pp_bills`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vt_pp_bills` (
  `period` varchar(6) NOT NULL,
  `idx` int DEFAULT NULL,
  `customerid` int NOT NULL,
  `freesimid` int DEFAULT NULL,
  `subscriberid` int DEFAULT NULL,
  `mobileno` varchar(16) DEFAULT NULL,
  `iccid` varchar(20) DEFAULT NULL,
  `title` varchar(16) DEFAULT NULL,
  `fullname` varchar(64) DEFAULT NULL,
  `address` varchar(256) DEFAULT NULL,
  `city` varchar(32) DEFAULT NULL,
  `postcode` varchar(12) DEFAULT NULL,
  `activatedate` datetime(3) DEFAULT NULL,
  `old_outstanding` float DEFAULT NULL,
  `old_payments_dd` float DEFAULT NULL,
  `plan` float DEFAULT NULL,
  `excess_usage` float DEFAULT NULL,
  `plan_excess` float DEFAULT NULL,
  `termination_fee` float DEFAULT NULL,
  `termination_date` varchar(64) DEFAULT NULL,
  `terminationfeetxt` varchar(72) DEFAULT NULL,
  `pmboprocess_fee` float DEFAULT NULL,
  `joindate` varchar(64) DEFAULT NULL,
  `prorata` float DEFAULT NULL,
  `proratatxt` varchar(64) DEFAULT NULL,
  `bill` float DEFAULT NULL,
  `vat` float DEFAULT NULL,
  `pay_reference` varchar(32) DEFAULT NULL,
  `service_status` varchar(32) DEFAULT NULL,
  `old_outstanding_txt` varchar(64) DEFAULT NULL,
  `old_payments_dd_txt` varchar(64) DEFAULT NULL,
  `old_outstanding_val` varchar(12) DEFAULT NULL,
  `old_payment_dd_val` varchar(12) DEFAULT NULL,
  `services_status_date` datetime(3) DEFAULT NULL,
  `dd_status` varchar(100) DEFAULT NULL,
  `dd_status_id` int DEFAULT NULL,
  `sort_code` varchar(10) DEFAULT NULL,
  `account_number` varchar(64) DEFAULT NULL,
  `bank_reference` varchar(32) DEFAULT NULL,
  `curr_service_status` varchar(32) DEFAULT NULL,
  `dd_collect` int DEFAULT '0',
  `Prorata_Plan_LLOM` float NOT NULL DEFAULT '0',
  `Next_Price_Plan_LLOM` float DEFAULT '0',
  `LLOM_Subcrip_Date` datetime(3) DEFAULT NULL,
  `BillTakenStatus` int DEFAULT NULL,
  `billing_date` datetime(3) DEFAULT NULL,
  `create_date` datetime(3) DEFAULT NULL,
  `payment_received` float DEFAULT NULL,
  `payment_received_by` varchar(25) DEFAULT NULL,
  `payment_date` datetime(3) DEFAULT NULL,
  `dd_payment` float DEFAULT NULL,
  `cc_payment` float DEFAULT NULL,
  `web_payment` float DEFAULT NULL,
  `excess_usage_payment` float DEFAULT NULL,
  PRIMARY KEY (`period`,`customerid`),
  KEY `index_vt_pp_bills` (`mobileno`,`curr_service_status`,`dd_collect`),
  KEY `IX_NC_service_status_vt_pp_bills` (`service_status`),
  KEY `IX_vt_pp_bills` (`idx`),
  KEY `IX_vt_pp_bills_1` (`dd_collect`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping events for database 'crm'
--

--
-- Dumping routines for database 'crm'
--
/*!50003 DROP PROCEDURE IF EXISTS `crm_pp_customer_change_staus` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `crm_pp_customer_change_staus`(v_mobileno VARCHAR(20),
v_service_status VARCHAR(100))
BEGIN
	
   DECLARE v_pp_customer_id INT; 
	
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   pp_customer_id INTO v_pp_customer_id from pp_customers where mobileno = v_mobileno   order by pp_customer_id desc LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
	
   if IFNULL(v_pp_customer_id,0) <> 0 then
	
		
		
		
		
      UPDATE pp_customers a set a.service_status = v_service_status where pp_customer_id = v_pp_customer_id;
   end if;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `crm_pp_update_billing_date` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `crm_pp_update_billing_date`(
  mobileno VARCHAR(20),  
  billingdate DATETIME(3),  
  firstupdate DATETIME(3))
BEGIN
     
     DECLARE v_pp_customer_id INT;   
     
     SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
     select   pp_customer_id INTO v_pp_customer_id from pp_customers a where a.mobileno = mobileno  order by pp_customer_id desc LIMIT 1;
     SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
     
     if IFNULL(v_pp_customer_id,0) <> 0 
     then
   
        if firstupdate is not null 
        then
    
           update pp_customers set
           sim_first_update = firstupdate
           where pp_customer_id = v_pp_customer_id;
        end if;
        
        if billingdate is not null 
        then
    
           update pp_customers a set a.billing_date = billingdate
           where pp_customer_id = v_pp_customer_id;
        end if;
        
     end if;  
     
    
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `freesim_with_bundle_get_order_ref` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `freesim_with_bundle_get_order_ref`(
	mobileno VARCHAR(20),  
OUT order_reference VARCHAR(50))
begin
   
   DECLARE v_iccid VARCHAR(20);  
   DECLARE v_freesmid INT;   
   
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   iccid INTO v_iccid from esp.mvno_account  a where a.mobileno = mobileno;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
   
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   IFNULL(cybersourceid,'') INTO order_reference from freesim where iccid = v_iccid;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
   
 
   if IFNULL(order_reference,'') = '' then
 
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select   freesimid INTO v_freesmid from pp_customers a where a.mobileno = mobileno   order by pp_customer_id desc LIMIT 1;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
      
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select   IFNULL(cybersourceid,'') INTO order_reference from freesim where freesimid = v_freesmid;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   end if;  
   
   
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `FSB_get_renewdate` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `FSB_get_renewdate`(v_acctype INT, 
v_accinfo VARCHAR(20), 
v_bundleid INT,
INOUT v_startdate DATETIME(3) ,
INOUT v_enddate DATETIME(3) ,
INOUT v_errcode INT ,
INOUT v_errmsg VARCHAR(60))
begin


   DECLARE v_count INT;


   if v_acctype = 1 then 

      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select   count(1) INTO v_count from fsb_accounts acc where msisdn_main = v_accinfo and bundle_id = v_bundleid  and CURRENT_TIMESTAMP between acc.start_date and acc.expired_date;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
      if v_count = 1 then
	
         SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
         select   acc.start_date, acc.expired_date INTO v_startdate,v_enddate from fsb_accounts acc where msisdn_main = v_accinfo and bundle_id = v_bundleid  and CURRENT_TIMESTAMP between acc.start_date and acc.expired_date;
         SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
         set v_errcode = 0;
         set v_errmsg = 'Success';
      else 
         if v_count > 1 then
	
            set v_errcode = -1;
            set v_errmsg = 'Return more than 1 data';
         else
            set v_errcode = -2;
            set v_errmsg = 'Return no data';
         end if;
      end if;
   else
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select   count(1) INTO v_count from fsb_accounts acc where account_id = v_accinfo and bundle_id = v_bundleid  and CURRENT_TIMESTAMP between acc.start_date and acc.expired_date;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
      if v_count = 1 then
	
         SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
         select   acc.start_date, acc.expired_date INTO v_startdate,v_enddate from fsb_accounts acc where account_id = v_accinfo and bundle_id = v_bundleid  and CURRENT_TIMESTAMP between acc.start_date and acc.expired_date;
         SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
         set v_errcode = 0;
         set v_errmsg = 'Success';
      else 
         if v_count > 1 then
	
            set v_errcode = -1;
            set v_errmsg = 'Return more than 1 data';
         else
            set v_errcode = -2;
            set v_errmsg = 'Return no data';
         end if;
      end if;
   end if;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Hubspot_contact_delete_exe_get_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `Hubspot_contact_delete_exe_get_info`()
BEGIN

   DECLARE v_date DATE; 
	
   set v_date = TIMESTAMPADD(DAY,-30,CURRENT_TIMESTAMP);
	
	
   DROP TEMPORARY TABLE IF EXISTS tt_temp_subscriber_info;
	
	
   create TEMPORARY table tt_temp_subscriber_info
   (
      firstname VARCHAR(100),
      lastname VARCHAR(100),
      email VARCHAR(250),
      iccid VARCHAR(20),
      subscriberid INT,
      Hubspot_contatcid INT,
      createdate DATETIME(3),
      msisdn VARCHAR(20)
   );
	
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   insert into tt_temp_subscriber_info(firstname,lastname,email,subscriberid,createdate)
   select firstname,lastname,email,subscriberid ,createdate from  subscriber
   where
   lastname in('TestQA','Mktg','Testphp')
   and CAST(createdate as DATE) <= v_date;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
	
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   UPDATE tt_temp_subscriber_info a
   join  freesim b on a.subscriberid = b.subscriberid set a.Hubspot_contatcid = b.hubspot_contactid,a.iccid = b.iccid where IFNULL(b.hubspot_contactid,0) > 0;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

	
   delete from tt_temp_subscriber_info where IFNULL(Hubspot_contatcid,0) = 0;
	
   select * from tt_temp_subscriber_info
   order by createdate asc;
	 
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Hubspot_exe_delete_contact` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `Hubspot_exe_delete_contact`(
contactid int,
mobileno varchar(20)
)
BEGIN

	declare freesimid int;
	
	select freesimid into freesimid from freesim where hubspot_contactid = contactid;
	
	update freesim set hubspot_contactid = 0 WHERE hubspot_contactid=contactid;
	
	INSERT INTO Hubspot_contact_del_log(mobileno,freesimid,hubspot_contactid,create_date)
	VALUES(mobileno,freesimid,contactid,current_timestamp());
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `PP_insert_pp_payment` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `PP_insert_pp_payment`(v_pay_reference VARCHAR(50),  
v_amount FLOAT,  
v_pay_date DATETIME(3),  
INOUT v_errcode INT ,  
INOUT v_errmsg VARCHAR(255))
begin

  
   
   DECLARE v_pp_customer_id INT;
   DECLARE v_logparams VARCHAR(2000);
   DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
   BEGIN
      SET @SWV_Error = 1;
   END;  
 
 
  
   SET @SWV_Error = 0;
   set v_errcode = 0;    
   set v_errmsg = 'Success';  
    
   SET @SWV_Error = 0;
   insert into pp_payments(pay_reference,pay_date,pay_method,amount,updatedby,status)
   select v_pay_reference,v_pay_date,'credit or debit card-step',v_amount,'Web',0;  
   if @SWV_Error <> 0 then
  
      set v_errmsg = 'Failed Insert to pp_payments ';
      set v_errcode = -1;
   end if;    
  
	
   set v_logparams = CONCAT('@pay_reference=',v_pay_reference,',@amount=',CAST(v_amount as CHAR(30)),
   ',@pay_date=',CAST(v_pay_date as CHAR(30)),',@errcode=',CAST(v_errcode as CHAR(30)),
   ',@errmsg=',v_errmsg);
   CALL pp_log_request('PP_insert_pp_payment',v_logparams);
	
	
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `PP_insert_pp_payment_excess_v2` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `PP_insert_pp_payment_excess_v2`(
	pay_reference VARCHAR(50),      
	amount FLOAT,      
	pay_date DATETIME(3),      
	mobileno VARCHAR(12) ,      
OUT errcode INT ,      
OUT errmsg VARCHAR(255) ,  
	payment_status INT
)
begin
   
   DECLARE v_pp_customer_id INT;
   DECLARE v_period VARCHAR(10);
   DECLARE v_excess_payment_type INT;
   DECLARE v_logparams VARCHAR(2000);
   DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
   BEGIN
      SET @SWV_Error = 1;
   END;  
    
   SET @SWV_Error = 0;
   
   drop TEMPORARY table IF EXISTS tt_ref;  
   create TEMPORARY table tt_ref
   (
      ref VARCHAR(50)
   );  
  
   insert tt_ref
   select pay_reference;  
     
   set errcode = 0;        
   set errmsg = 'Success';      
   set v_excess_payment_type = 0;  
   
   if exists(select * from tt_ref where (ref like 'VMUK-PPEXU%' or ref like 'VMUK-AD%')) 
   then 
      set v_excess_payment_type = 1;
   end if;  
   
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   max(pp_customer_id) INTO v_pp_customer_id from pp_customers  a where a.mobileno = mobileno;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;    
    
   If Not Exists(Select 1 From pp_payments  a Where a.pay_reference = pay_reference) 
   then
 
      if payment_status = 1 and v_excess_payment_type = 0 
      then
    
         SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
         select   MAX(period) INTO v_period from   vt_pp_bills b where customerid = v_pp_customer_id;
         SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
         
         SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
         UPDATE vt_pp_bills b set b.payment_received = IFNULL(payment_received,0)+cast(IFNULL(amount,0) as DECIMAL(10,2)),
         b.payment_received_by = 'WEB-Myacc' where customerid = v_pp_customer_id and period = v_period;
         SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
         
      end if;
      
      SET @SWV_Error = 0;
      
      insert into pp_payments(pay_reference,pp_customer_id,pay_date,pay_method,amount,updatedby,status)
      select pay_reference,IFNULL(v_pp_customer_id,0),pay_date,'Web-credit or debit card',amount,'Web',payment_status;
      
      if @SWV_Error <> 0 
      then
 
         set errmsg = 'Failed Insert to pp_payments ';
         set errcode = -1;
      end if;
      
   end if;  
      
 
 
   set v_logparams = CONCAT('pay_reference=',pay_reference,',amount=',CAST(amount as CHAR(30)),
   ',pay_date=',CAST(pay_date as CHAR(30)),',mobileno=',mobileno,
   ',errcode=',CAST(errcode as CHAR(30)),',errmsg=',errmsg);    
   
   CALL crm.pp_log_request('PP_insert_pp_payment',v_logparams);             
       
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `pp_log_request` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `pp_log_request`(v_spname	VARCHAR(64),
 	v_params VARCHAR(2000))
BEGIN
 	
 	
 
 
 	 INSERT INTO pp_requestlog(requesttime, server_address, client_address, spname, params)
 	VALUES(CURRENT_TIMESTAMP,
 		CAST('local_net_address' as CHAR(30)),
 		CAST('client_net_address' as CHAR(30)),
 		v_spname,
 		v_params);
 
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Rxpaym_cc_payment_getsubscriptionlist_AT` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `Rxpaym_cc_payment_getsubscriptionlist_AT`(
v_account_id VARCHAR(30))
BEGIN  
  
   DECLARE v_is_realx INT;   
   DECLARE v_topup_currency VARCHAR(20);  
   DECLARE v_SubscriptionID VARCHAR(100);  
   DECLARE v_email VARCHAR(150);  
   DECLARE v_iccid VARCHAR(20);  
   DECLARE v_pay_reference VARCHAR(50);  
   DECLARE v_pp_customer_id INT;  
   DECLARE v_CC_NO VARCHAR(10);  
   DECLARE v_counter INT;  
   DECLARE v_ORDER_REFERENCE VARCHAR(50);   
   DECLARE v_purchase_date DATETIME(3);  
   DECLARE v_purchase_format VARCHAR(250);  
   
   DECLARE v_activate_date VARCHAR(50);
   
   drop TEMPORARY table IF EXISTS  tt_paym_subscribtion_info;  
   create TEMPORARY table tt_paym_subscribtion_info
   (
      subscribtionid VARCHAR(100),
      ccdc_no VARCHAR(10),
      account_id VARCHAR(20)
   );  
  
   set v_counter = 0;  
      
   select   DATE_FORMAT(activatedate,'%Y%m%d'), pp_customer_id INTO v_activate_date,v_pp_customer_id 
   from crm.pp_customers where mobileno = v_account_id   order by pp_customer_id desc LIMIT 1;   
   
   if  exists(select  1 from tSubscription  where account_id = v_account_id LIMIT 1) then
  
     insert into tt_paym_subscribtion_info(subscribtionid,ccdc_no,account_id)
      Select  SubscriptionID,last6digitscc,account_id From tSubscription
      where account_id = v_account_id and  SubscriptionID REGEXP('^[+-.$.]?[[0-9,]+...]?$')
      and ((IFNULL(v_pp_customer_id,0) <> 0 and purchasedate >= v_activate_date) or (IFNULL(v_pp_customer_id,0) = 0))  order by idx desc LIMIT 1;
   end if;        
  
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   count(1) INTO v_counter from tt_paym_subscribtion_info;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
    
   if v_counter = 0 then
 
      CALL freesim_with_bundle_get_order_ref(v_account_id,v_ORDER_REFERENCE);
      IF IFNULL(v_ORDER_REFERENCE,'') <> '' then
     
    
         SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
         select   CC_NO, CREATED_DATE, ACCOUNT_ID INTO v_CC_NO,v_purchase_date,v_account_id from tpayment where REFERENCE_ID = v_ORDER_REFERENCE    LIMIT 1;
         SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
         set v_purchase_format = DATE_FORMAT(v_purchase_date,'%Y%m%d');
         insert into tt_paym_subscribtion_info(ACCOUNT_ID,subscribtionid,ccdc_no)
         Select  ACCOUNT_ID,SubscriptionID,v_CC_NO From tSubscription
         where (last6digitscc = v_CC_NO AND ACCOUNT_ID = v_account_id AND
         purchasedate = v_purchase_format) and  SubscriptionID REGEXP('^[+-.$.]?[[0-9,]+...]?$') order by idx desc LIMIT 1;
      end if;
   end if;  
     
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select account_id,subscribtionid,ccdc_no as last6digitscc
   from tt_paym_subscribtion_info;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;   
   
   
      
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `vmuk_validatesecuritycode` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `vmuk_validatesecuritycode`(
 mobileno VARCHAR(12),
  securitycode VARCHAR(10))
begin
 
 
    DECLARE v_errcode INT;
    DECLARE v_errmsg VARCHAR(200);
    DECLARE v_productid INT;
    DECLARE v_amount FLOAT;
    DECLARE v_amountbonus FLOAT;
    DECLARE v_currency VARCHAR(5);
    DECLARE v_paymentref VARCHAR(64);
    DECLARE v_status INT;
    DECLARE v_prev_bal FLOAT;
    DECLARE v_after_bal FLOAT;
    DECLARE v_amountret FLOAT;
 
 
   
  
  
    sp_end:
    BEGIN
     
      
     
   
       set v_errcode = -1;
 
 
  
     
       
       select 2,a.productid,a.amount,a.amountbonus,a.currency,a.paymentref into v_status,v_productid,v_amount,v_amountbonus,v_currency,v_paymentref
       from vmuk_SecurityCode a  where a.mobileno = mobileno and a.securitycode = securitycode and a.status in(0,1);
       
       set v_errmsg = case
       when ROW_COUNT() = 0 then 'Failed validating security code, invalid mobile number and security code'
       when @@error_count <> 0 then 'Error validating security code'
       else null
       end;
       if v_errmsg is not null then 
          LEAVE sp_end;
       end if;
 
 
      
 
          set v_amountret = v_amountbonus*-1;
          CALL mvno.WEB_update_balance_ccdc_temporary(2,mobileno,v_paymentref,v_productid,v_amountret,v_currency,'SVC',v_prev_bal,
          v_after_bal,v_errcode,v_errmsg);
          if v_errcode <> 0 then 
             LEAVE sp_end;
          end if;
     
 
       set v_errcode = 1;
       set v_errmsg = 'Mobile number and security code valid';
    END;
    select
    v_errcode errcode, v_errmsg errmsg, mobileno mobileno, securitycode securitycode,
  v_productid productid, v_amount amount, v_amountbonus amountbonus, v_paymentref paymentref, v_status status;
 
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-21  9:50:07
