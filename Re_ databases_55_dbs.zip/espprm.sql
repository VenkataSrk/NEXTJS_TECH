-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: espprm
-- ------------------------------------------------------
-- Server version	8.0.44-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `CardFeatures`
--

DROP TABLE IF EXISTS `CardFeatures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CardFeatures` (
  `CardID` int NOT NULL,
  `FeatureType` int NOT NULL,
  `Status` int NOT NULL,
  `Param1` varchar(100) DEFAULT NULL,
  `Param2` varchar(100) DEFAULT NULL,
  `Param3` varchar(256) DEFAULT NULL,
  `Comment` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`CardID`,`FeatureType`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `DestName`
--

DROP TABLE IF EXISTS `DestName`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `DestName` (
  `destcode` varchar(100) NOT NULL,
  `destname` varchar(100) DEFAULT NULL,
  `destfile` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`destcode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `GPRSCDR`
--

DROP TABLE IF EXISTS `GPRSCDR`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GPRSCDR` (
  `cnxdate` datetime(3) DEFAULT NULL,
  `SessionID` varchar(60) DEFAULT NULL,
  `imsi` varchar(15) DEFAULT NULL,
  `Msisdn` varchar(16) DEFAULT NULL,
  `telcocode` varchar(4) DEFAULT NULL,
  `custcode` varchar(8) DEFAULT NULL,
  `batchcode` int DEFAULT NULL,
  `serialcode` int DEFAULT NULL,
  `package_id` int DEFAULT NULL,
  `chargingtype` int DEFAULT NULL,
  `allocation` float DEFAULT NULL,
  `allocation_charge` float DEFAULT NULL,
  `balance` float DEFAULT NULL,
  `totalcons` float DEFAULT NULL,
  `tariffclass` varchar(4) DEFAULT NULL,
  `sample_delay` int DEFAULT NULL,
  `sample_unit` float DEFAULT NULL,
  `is_roaming` int DEFAULT NULL,
  `cnx_charge` float DEFAULT NULL,
  `timeperiod` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Results`
--

DROP TABLE IF EXISTS `Results`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Results` (
  `telcocode` varchar(4) NOT NULL,
  `sitecode` varchar(3) NOT NULL,
  `destcode` varchar(32) NOT NULL,
  `trffclass` varchar(4) NOT NULL,
  `charge` int NOT NULL,
  `timeperiod` int NOT NULL,
  `cnxdelay` int DEFAULT NULL,
  `cnxunit` float NOT NULL,
  `sampdelay` int DEFAULT NULL,
  `sampunit` float NOT NULL,
  `freesec` int DEFAULT NULL,
  `premiumdest` int DEFAULT NULL,
  `cfreemin` int DEFAULT NULL,
  `routeclass` int NOT NULL,
  `percentage` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Shopblock`
--

DROP TABLE IF EXISTS `Shopblock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Shopblock` (
  `telcocode` varchar(4) DEFAULT NULL,
  `custcode` varchar(8) DEFAULT NULL,
  `batchcode` int DEFAULT NULL,
  `serialcode` int DEFAULT NULL,
  `langcode` varchar(8) DEFAULT NULL,
  `lastbal` float DEFAULT NULL,
  `person` varchar(12) DEFAULT NULL,
  `dateblocked` datetime(3) DEFAULT NULL,
  `reason` char(40) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `UK_NUMBER_PLAN_PREFIX`
--

DROP TABLE IF EXISTS `UK_NUMBER_PLAN_PREFIX`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UK_NUMBER_PLAN_PREFIX` (
  `sitecode` varchar(3) NOT NULL,
  `prefixcode` varchar(30) NOT NULL,
  `destcode` varchar(64) NOT NULL,
  `mindigit` int DEFAULT NULL,
  `maxdigit` int DEFAULT NULL,
  `isactive` int DEFAULT NULL,
  `comment` varchar(64) DEFAULT NULL,
  `prefixset` int NOT NULL,
  `prefixtype` int DEFAULT NULL,
  `mobilecdrop` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `UK_access`
--

DROP TABLE IF EXISTS `UK_access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UK_access` (
  `S#No` float DEFAULT NULL,
  `Country` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `Country Code` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `MO Call` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `MT Call` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `MO SMS` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Unblocktab`
--

DROP TABLE IF EXISTS `Unblocktab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Unblocktab` (
  `telcocode` varchar(4) DEFAULT NULL,
  `custcode` varchar(8) DEFAULT NULL,
  `batchcode` int DEFAULT NULL,
  `serialcode` int DEFAULT NULL,
  `pincode` varchar(12) DEFAULT NULL,
  `langcode` varchar(8) DEFAULT NULL,
  `lastbal` float DEFAULT NULL,
  `person` varchar(10) DEFAULT NULL,
  `unblockdate` datetime(3) DEFAULT NULL,
  `reason` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`),
  KEY `IX_Unblocktab` (`telcocode`,`custcode`,`batchcode`,`serialcode`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `UploadPack_Cnxcharge_history`
--

DROP TABLE IF EXISTS `UploadPack_Cnxcharge_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UploadPack_Cnxcharge_history` (
  `idx` int NOT NULL AUTO_INCREMENT,
  `site` varchar(3) DEFAULT NULL,
  `sourcefile` varchar(100) DEFAULT NULL,
  `login` varchar(32) DEFAULT NULL,
  `status` int DEFAULT NULL,
  `date` datetime(3) DEFAULT NULL,
  UNIQUE KEY `idx` (`idx`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `accdbl`
--

DROP TABLE IF EXISTS `accdbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `accdbl` (
  `telcocode` varchar(3) NOT NULL,
  `custcode` char(8) DEFAULT NULL,
  `batchcode` int DEFAULT NULL,
  `serialcode` int DEFAULT NULL,
  `status` int NOT NULL,
  `pincode` char(12) DEFAULT NULL,
  `langcode` varchar(8) DEFAULT NULL,
  `acctype` int NOT NULL,
  `phonenb` char(30) DEFAULT NULL,
  `firstusg` datetime(3) DEFAULT NULL,
  `spdial` varchar(1) NOT NULL,
  `cug` varchar(1) NOT NULL,
  `did` char(6) DEFAULT NULL,
  `ani` char(30) DEFAULT NULL,
  `balance` float DEFAULT NULL,
  `nbaccess` int NOT NULL,
  `maxaccess` int NOT NULL,
  `trffclass` char(4) DEFAULT NULL,
  `security` int DEFAULT NULL,
  `totalcons` float DEFAULT NULL,
  `monthlim` float DEFAULT NULL,
  `startdate` datetime(3) DEFAULT NULL,
  `enddate` datetime(3) DEFAULT NULL,
  `lang` varchar(2) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `access`
--

DROP TABLE IF EXISTS `access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `access` (
  `sitecode` varchar(3) NOT NULL,
  `switchcode` varchar(3) NOT NULL,
  `acsscode` varchar(3) DEFAULT NULL,
  `comment` varchar(30) DEFAULT NULL,
  `isactive` int DEFAULT NULL,
  `calltype` int DEFAULT NULL,
  `charge` int DEFAULT NULL,
  `mode` int DEFAULT NULL,
  `langcode` varchar(8) DEFAULT NULL,
  `telcocode` varchar(4) DEFAULT NULL,
  `custcode` varchar(8) DEFAULT NULL,
  `batchcode` int DEFAULT NULL,
  `serialcode` int DEFAULT NULL,
  `lang` varchar(10) DEFAULT NULL,
  `did` varchar(15) NOT NULL,
  `trunkcode` varchar(8) NOT NULL,
  `fullno` varchar(30) DEFAULT NULL,
  `publishno` varchar(30) DEFAULT NULL,
  `routeclass` varchar(4) DEFAULT NULL,
  `aniblockgrp` int DEFAULT NULL,
  `usrmonitor` int DEFAULT NULL,
  `anicharge` int DEFAULT NULL,
  `didtype` int DEFAULT NULL,
  `counter` int DEFAULT NULL,
  `maxaccess` int DEFAULT NULL,
  `accesstype` char(1) DEFAULT NULL,
  `sharedtype` int DEFAULT NULL,
  `blockpayphone` int DEFAULT NULL,
  `autodetect_pphone` int DEFAULT NULL,
  `costa` double DEFAULT NULL,
  `legA_tariffclass` varchar(4) DEFAULT NULL,
  `logfile` int DEFAULT NULL,
  `min_dialdigits` int DEFAULT NULL,
  `prefix_set` int DEFAULT NULL,
  `xlat_set` varchar(4) DEFAULT NULL,
  `timeclass_set` varchar(5) DEFAULT NULL,
  `langcode_flag` int DEFAULT NULL,
  PRIMARY KEY (`sitecode`,`switchcode`,`did`,`trunkcode`),
  UNIQUE KEY `access_PK` (`sitecode`,`did`,`trunkcode`),
  KEY `IX1_access224A0` (`sitecode`,`trunkcode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `access_charge`
--

DROP TABLE IF EXISTS `access_charge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `access_charge` (
  `charge` int NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `description` varchar(128) NOT NULL,
  `status` int NOT NULL,
  PRIMARY KEY (`charge`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `access_charge_callmode`
--

DROP TABLE IF EXISTS `access_charge_callmode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `access_charge_callmode` (
  `sitecode` char(3) NOT NULL,
  `prefix` char(6) NOT NULL,
  `callmode` int NOT NULL,
  `trunkcode` char(8) NOT NULL,
  `charge` int DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`sitecode`,`prefix`,`callmode`,`trunkcode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `access_complete`
--

DROP TABLE IF EXISTS `access_complete`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `access_complete` (
  `sitecode` varchar(3) NOT NULL,
  `switchcode` varchar(3) DEFAULT NULL,
  `acsscode` varchar(3) DEFAULT NULL,
  `comment` varchar(30) DEFAULT NULL,
  `isactive` int DEFAULT NULL,
  `calltype` int DEFAULT NULL,
  `charge` int DEFAULT NULL,
  `mode` int DEFAULT NULL,
  `langcode` varchar(8) DEFAULT NULL,
  `telcocode` varchar(4) DEFAULT NULL,
  `custcode` varchar(8) DEFAULT NULL,
  `batchcode` int DEFAULT NULL,
  `serialcode` int DEFAULT NULL,
  `lang` varchar(2) DEFAULT NULL,
  `did` varchar(6) NOT NULL,
  `trunkcode` varchar(5) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `access_failed`
--

DROP TABLE IF EXISTS `access_failed`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `access_failed` (
  `sitecode` varchar(3) NOT NULL,
  `switchcode` varchar(3) DEFAULT NULL,
  `acsscode` varchar(3) DEFAULT NULL,
  `comment` varchar(30) DEFAULT NULL,
  `isactive` int DEFAULT NULL,
  `calltype` int DEFAULT NULL,
  `charge` int DEFAULT NULL,
  `mode` int DEFAULT NULL,
  `langcode` varchar(8) DEFAULT NULL,
  `telcocode` varchar(4) DEFAULT NULL,
  `custcode` varchar(8) DEFAULT NULL,
  `batchcode` int DEFAULT NULL,
  `serialcode` int DEFAULT NULL,
  `lang` varchar(10) DEFAULT NULL,
  `did` varchar(6) NOT NULL,
  `trunkcode` varchar(5) DEFAULT NULL,
  `fullno` varchar(30) DEFAULT NULL,
  `publishno` varchar(30) DEFAULT NULL,
  `routeclass` varchar(4) DEFAULT NULL,
  `aniblockgrp` int DEFAULT NULL,
  `aniblock` int DEFAULT NULL,
  `anichargegrp` int DEFAULT NULL,
  `anicharge` int DEFAULT NULL,
  `anirouteclassgrp` int DEFAULT NULL,
  `anirouteclass` varchar(4) DEFAULT NULL,
  `didtype` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `access_mode`
--

DROP TABLE IF EXISTS `access_mode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `access_mode` (
  `mode` int NOT NULL,
  `name` varchar(32) NOT NULL,
  `description` varchar(128) NOT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `access_new`
--

DROP TABLE IF EXISTS `access_new`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `access_new` (
  `sitecode` varchar(3) NOT NULL,
  `switchcode` varchar(3) DEFAULT NULL,
  `acsscode` varchar(3) DEFAULT NULL,
  `comment` varchar(30) DEFAULT NULL,
  `isactive` int DEFAULT NULL,
  `calltype` int DEFAULT NULL,
  `charge` int DEFAULT NULL,
  `mode` int DEFAULT NULL,
  `langcode` varchar(8) DEFAULT NULL,
  `telcocode` varchar(4) DEFAULT NULL,
  `custcode` varchar(8) DEFAULT NULL,
  `batchcode` int DEFAULT NULL,
  `serialcode` int DEFAULT NULL,
  `lang` varchar(10) DEFAULT NULL,
  `did` varchar(6) NOT NULL,
  `trunkcode` varchar(8) NOT NULL,
  `fullno` varchar(30) DEFAULT NULL,
  `publishno` varchar(30) DEFAULT NULL,
  `routeclass` varchar(4) DEFAULT NULL,
  `aniblockgrp` int DEFAULT NULL,
  `usrmonitor` int DEFAULT NULL,
  `anicharge` int DEFAULT NULL,
  `didtype` int DEFAULT NULL,
  `counter` int DEFAULT NULL,
  `maxaccess` int DEFAULT NULL,
  `accesstype` char(1) DEFAULT NULL,
  `sharedtype` int DEFAULT NULL,
  PRIMARY KEY (`sitecode`,`did`,`trunkcode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `acclock`
--

DROP TABLE IF EXISTS `acclock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `acclock` (
  `calldate` datetime(3) DEFAULT NULL,
  `switchcode` varchar(3) DEFAULT NULL,
  `fulldid` varchar(15) DEFAULT NULL,
  `ani` varchar(20) DEFAULT NULL,
  `pid` int DEFAULT NULL,
  `telcocode` varchar(4) NOT NULL,
  `custcode` varchar(8) NOT NULL,
  `batchcode` int NOT NULL,
  `serialcode` int NOT NULL,
  `langcode` varchar(8) DEFAULT NULL,
  `pincode` varchar(12) DEFAULT NULL,
  `startcall` datetime(3) DEFAULT NULL,
  `xgateid` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`telcocode`,`custcode`,`batchcode`,`serialcode`),
  KEY `acclock_idx1` (`telcocode`,`custcode`,`batchcode`,`serialcode`,`switchcode`),
  KEY `acclock_idx2` (`telcocode`,`langcode`,`pincode`),
  KEY `acclock_idx3` (`switchcode`,`pid`),
  KEY `acclock_idx4` (`switchcode`),
  KEY `acclock_idx5` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `acclocked`
--

DROP TABLE IF EXISTS `acclocked`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `acclocked` (
  `calldate` datetime(3) DEFAULT NULL,
  `switchcode` varchar(3) DEFAULT NULL,
  `fulldid` varchar(15) DEFAULT NULL,
  `ani` varchar(20) DEFAULT NULL,
  `pid` int DEFAULT NULL,
  `telcocode` varchar(4) NOT NULL,
  `custcode` varchar(8) NOT NULL,
  `batchcode` int NOT NULL,
  `serialcode` int NOT NULL,
  `langcode` varchar(8) DEFAULT NULL,
  `pincode` varchar(12) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `account`
--

DROP TABLE IF EXISTS `account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `account` (
  `telcocode` varchar(3) NOT NULL,
  `custcode` char(8) DEFAULT NULL,
  `batchcode` int DEFAULT NULL,
  `serialcode` int DEFAULT NULL,
  `status` int NOT NULL,
  `pincode` char(12) DEFAULT NULL,
  `langcode` varchar(8) DEFAULT NULL,
  `acctype` int NOT NULL,
  `phonenb` char(30) DEFAULT NULL,
  `firstusg` datetime(3) DEFAULT NULL,
  `spdial` varchar(1) NOT NULL,
  `cug` varchar(1) NOT NULL,
  `did` char(6) DEFAULT NULL,
  `ani` char(30) DEFAULT NULL,
  `balance` float DEFAULT NULL,
  `nbaccess` int NOT NULL,
  `maxaccess` int NOT NULL,
  `trffclass` char(4) DEFAULT NULL,
  `security` int DEFAULT NULL,
  `totalcons` float DEFAULT NULL,
  `monthlim` float DEFAULT NULL,
  `startdate` datetime(3) DEFAULT NULL,
  `enddate` datetime(3) DEFAULT NULL,
  `lang` varchar(2) DEFAULT NULL,
  `cnxcount` int DEFAULT NULL,
  `currcode` varchar(5) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`),
  KEY `accountidx1` (`telcocode`,`langcode`,`pincode`),
  KEY `accountidx2` (`telcocode`,`custcode`,`batchcode`,`serialcode`),
  KEY `accountidx3` (`telcocode`,`ani`,`did`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `account_archive`
--

DROP TABLE IF EXISTS `account_archive`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `account_archive` (
  `telcocode` varchar(3) NOT NULL,
  `custcode` char(8) DEFAULT NULL,
  `batchcode` int DEFAULT NULL,
  `serialcode` int DEFAULT NULL,
  `status` int NOT NULL,
  `pincode` char(12) DEFAULT NULL,
  `langcode` varchar(8) DEFAULT NULL,
  `acctype` int NOT NULL,
  `phonenb` char(30) DEFAULT NULL,
  `firstusg` datetime(3) DEFAULT NULL,
  `spdial` varchar(1) NOT NULL,
  `cug` varchar(1) NOT NULL,
  `did` char(6) DEFAULT NULL,
  `ani` char(30) DEFAULT NULL,
  `balance` float DEFAULT NULL,
  `nbaccess` int NOT NULL,
  `maxaccess` int NOT NULL,
  `trffclass` char(4) DEFAULT NULL,
  `security` int DEFAULT NULL,
  `totalcons` float DEFAULT NULL,
  `monthlim` float DEFAULT NULL,
  `startdate` datetime(3) DEFAULT NULL,
  `enddate` datetime(3) DEFAULT NULL,
  `lang` varchar(2) DEFAULT NULL,
  `cnxcount` int DEFAULT NULL,
  `currcode` varchar(5) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`),
  KEY `archiveidx1` (`telcocode`,`custcode`,`batchcode`,`serialcode`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `account_callhistory`
--

DROP TABLE IF EXISTS `account_callhistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `account_callhistory` (
  `telcocode` varchar(3) NOT NULL,
  `custcode` varchar(8) NOT NULL,
  `batchcode` int NOT NULL,
  `serialcode` int NOT NULL,
  `accessmode` int NOT NULL,
  `lastcalldate` datetime(3) DEFAULT NULL,
  `lastdestcode` varchar(25) DEFAULT NULL,
  `lastsampunit` char(10) DEFAULT NULL,
  `accesstype` char(1) DEFAULT NULL,
  `status` int DEFAULT NULL,
  PRIMARY KEY (`telcocode`,`custcode`,`batchcode`,`serialcode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `account_dublong`
--

DROP TABLE IF EXISTS `account_dublong`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `account_dublong` (
  `telcocode` varchar(3) NOT NULL,
  `custcode` char(8) DEFAULT NULL,
  `batchcode` int DEFAULT NULL,
  `serialcode` int DEFAULT NULL,
  `status` int NOT NULL,
  `pincode` char(12) DEFAULT NULL,
  `langcode` varchar(8) DEFAULT NULL,
  `acctype` int NOT NULL,
  `phonenb` char(30) DEFAULT NULL,
  `firstusg` datetime(3) DEFAULT NULL,
  `spdial` varchar(1) NOT NULL,
  `cug` varchar(1) NOT NULL,
  `did` char(6) DEFAULT NULL,
  `ani` char(30) DEFAULT NULL,
  `balance` float DEFAULT NULL,
  `nbaccess` int NOT NULL,
  `maxaccess` int NOT NULL,
  `trffclass` char(4) DEFAULT NULL,
  `security` int DEFAULT NULL,
  `totalcons` float DEFAULT NULL,
  `monthlim` float DEFAULT NULL,
  `startdate` datetime(3) DEFAULT NULL,
  `enddate` datetime(3) DEFAULT NULL,
  `lang` varchar(2) DEFAULT NULL,
  `cnxcount` int DEFAULT NULL,
  `currcode` varchar(5) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `account_uselimit_charge`
--

DROP TABLE IF EXISTS `account_uselimit_charge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `account_uselimit_charge` (
  `groupid` int NOT NULL,
  `sitecode` varchar(3) NOT NULL,
  `tariffclass` varchar(5) NOT NULL,
  `charge` int NOT NULL,
  `insertby` varchar(8) DEFAULT NULL,
  `lastupd` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`groupid`,`sitecode`,`tariffclass`,`charge`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `account_uselimit_group`
--

DROP TABLE IF EXISTS `account_uselimit_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `account_uselimit_group` (
  `groupid` int NOT NULL,
  `sitecode` varchar(3) NOT NULL,
  `status` int DEFAULT NULL,
  `uselimit_mode` int NOT NULL,
  `uselimit_datemode` int NOT NULL,
  `uselimit_delay` int DEFAULT NULL,
  `uselimit_amount` float NOT NULL,
  `warning_threshold1` float DEFAULT NULL,
  `warning_message1` varchar(256) DEFAULT NULL,
  `warning_threshold2` float DEFAULT NULL,
  `warning_message2` varchar(256) DEFAULT NULL,
  `warning_threshold3` float DEFAULT NULL,
  `warning_message3` varchar(128) DEFAULT NULL,
  `notif_type` int DEFAULT NULL,
  `description` varchar(24) DEFAULT NULL,
  `insertby` varchar(8) DEFAULT NULL,
  `lastupd` datetime(3) DEFAULT NULL,
  `uselimit_action` int DEFAULT NULL,
  `uselimit_SubsID` int DEFAULT NULL,
  `uselimit_SubsID_roaming` int DEFAULT NULL,
  PRIMARY KEY (`groupid`,`sitecode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `acctemplate`
--

DROP TABLE IF EXISTS `acctemplate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `acctemplate` (
  `telcocode` varchar(3) NOT NULL,
  `custcode` char(8) DEFAULT NULL,
  `batchcode` int DEFAULT NULL,
  `serialcode` int DEFAULT NULL,
  `status` int NOT NULL,
  `pincode` char(12) DEFAULT NULL,
  `langcode` varchar(8) DEFAULT NULL,
  `acctype` int NOT NULL,
  `phonenb` char(30) DEFAULT NULL,
  `firstusg` datetime(3) DEFAULT NULL,
  `spdial` varchar(1) NOT NULL,
  `cug` varchar(1) NOT NULL,
  `did` char(6) DEFAULT NULL,
  `ani` char(30) DEFAULT NULL,
  `balance` float DEFAULT NULL,
  `nbaccess` int NOT NULL,
  `maxaccess` int NOT NULL,
  `trffclass` char(4) DEFAULT NULL,
  `security` int DEFAULT NULL,
  `totalcons` float DEFAULT NULL,
  `monthlim` float DEFAULT NULL,
  `startdate` datetime(3) DEFAULT NULL,
  `enddate` datetime(3) DEFAULT NULL,
  `lang` varchar(2) DEFAULT NULL,
  `cnxcount` int DEFAULT NULL,
  `currcode` varchar(5) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `all_destination`
--

DROP TABLE IF EXISTS `all_destination`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `all_destination` (
  `destcode` varchar(32) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `allowed_cli_gx`
--

DROP TABLE IF EXISTS `allowed_cli_gx`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `allowed_cli_gx` (
  `pfxcode` varchar(12) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `alt_tariffclass`
--

DROP TABLE IF EXISTS `alt_tariffclass`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `alt_tariffclass` (
  `telcocode` varchar(4) NOT NULL,
  `sitecode` varchar(3) NOT NULL,
  `trffclass` varchar(4) NOT NULL,
  `altprog_flag` int DEFAULT NULL,
  `altprog_intrvl` int DEFAULT NULL,
  `altmaint_flag` int DEFAULT NULL,
  `altmaint_intrvl` int DEFAULT NULL,
  `altmaintdelay` int DEFAULT NULL,
  `altmaintunit` float DEFAULT NULL,
  `altmaxnbcharge` int DEFAULT NULL,
  `altsamp_flag` int DEFAULT NULL,
  `altsamp_intrvl` int DEFAULT NULL,
  `altsamp_mfactor` float DEFAULT NULL,
  `createdate` datetime(3) DEFAULT NULL,
  `moddate` datetime(3) DEFAULT NULL,
  `comment` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`telcocode`,`sitecode`,`trffclass`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ani`
--

DROP TABLE IF EXISTS `ani`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ani` (
  `sitecode` varchar(3) NOT NULL,
  `did` varchar(30) NOT NULL,
  `aniprefix` varchar(30) NOT NULL,
  `isactive` int DEFAULT NULL,
  `feature1` int DEFAULT NULL,
  `feature2` int DEFAULT NULL,
  `comment` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`sitecode`,`did`,`aniprefix`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `aniblockgroup`
--

DROP TABLE IF EXISTS `aniblockgroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aniblockgroup` (
  `aniblockgroup` int NOT NULL,
  `desc` varchar(100) DEFAULT NULL,
  `createdby` varchar(50) DEFAULT NULL,
  `createdon` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`aniblockgroup`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `anigroup`
--

DROP TABLE IF EXISTS `anigroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `anigroup` (
  `sitecode` varchar(3) NOT NULL,
  `groupno` int NOT NULL,
  `ani` varchar(30) NOT NULL,
  PRIMARY KEY (`sitecode`,`groupno`,`ani`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `aniprefix`
--

DROP TABLE IF EXISTS `aniprefix`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aniprefix` (
  `sitecode` varchar(3) NOT NULL,
  `trunkcode` varchar(20) NOT NULL,
  `prefix` varchar(20) NOT NULL,
  `type` char(1) NOT NULL,
  `comment` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`sitecode`,`trunkcode`,`prefix`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `at_Destcode`
--

DROP TABLE IF EXISTS `at_Destcode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `at_Destcode` (
  `destcode` varchar(100) NOT NULL,
  PRIMARY KEY (`destcode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `bak_gprs_tariffclass`
--

DROP TABLE IF EXISTS `bak_gprs_tariffclass`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bak_gprs_tariffclass` (
  `sitecode` char(3) NOT NULL,
  `trffclass` char(4) NOT NULL,
  `isroaming` int NOT NULL,
  `chargingtype` int DEFAULT NULL,
  `allocationvalue` int DEFAULT NULL,
  `charge` int DEFAULT NULL,
  `destcode` varchar(32) DEFAULT NULL,
  `minunit` float DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `batch`
--

DROP TABLE IF EXISTS `batch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `batch` (
  `telcocode` varchar(4) DEFAULT NULL,
  `custcode` varchar(8) DEFAULT NULL,
  `batchcode` int DEFAULT NULL,
  `faceunit` int DEFAULT NULL,
  `tclassaleg` varchar(4) DEFAULT NULL,
  `routeclass` varchar(4) DEFAULT NULL,
  `tclasscost` varchar(4) DEFAULT NULL,
  `billmode` int DEFAULT NULL,
  `balance` float DEFAULT NULL,
  `comment` varchar(32) DEFAULT NULL,
  `createdate` datetime(3) DEFAULT NULL,
  `startdate` datetime(3) DEFAULT NULL,
  `expdate` datetime(3) DEFAULT NULL,
  `credinit` float DEFAULT NULL,
  `daysvalid` int DEFAULT NULL,
  `playblc` int DEFAULT NULL,
  `currcode` varchar(5) DEFAULT NULL,
  `maxdnum` int DEFAULT NULL,
  `danb` varchar(50) DEFAULT NULL,
  `warntime` int DEFAULT NULL,
  `maxalloc` float DEFAULT NULL,
  `totalalloc` float DEFAULT NULL,
  `totalcons` float DEFAULT NULL,
  `monthlim` float DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`),
  KEY `batchidx1` (`telcocode`,`custcode`,`batchcode`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `batch_archive`
--

DROP TABLE IF EXISTS `batch_archive`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `batch_archive` (
  `telcocode` varchar(4) DEFAULT NULL,
  `custcode` varchar(8) DEFAULT NULL,
  `batchcode` int DEFAULT NULL,
  `faceunit` int DEFAULT NULL,
  `tclassaleg` varchar(4) DEFAULT NULL,
  `routeclass` varchar(4) DEFAULT NULL,
  `tclasscost` varchar(4) DEFAULT NULL,
  `billmode` int DEFAULT NULL,
  `balance` float DEFAULT NULL,
  `comment` varchar(32) DEFAULT NULL,
  `createdate` datetime(3) DEFAULT NULL,
  `startdate` datetime(3) DEFAULT NULL,
  `expdate` datetime(3) DEFAULT NULL,
  `credinit` float DEFAULT NULL,
  `daysvalid` int DEFAULT NULL,
  `playblc` int DEFAULT NULL,
  `currcode` varchar(5) DEFAULT NULL,
  `maxdnum` int DEFAULT NULL,
  `danb` varchar(50) DEFAULT NULL,
  `warntime` int DEFAULT NULL,
  `maxalloc` float DEFAULT NULL,
  `totalalloc` float DEFAULT NULL,
  `totalcons` float DEFAULT NULL,
  `monthlim` float DEFAULT NULL,
  `rid` int NOT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `bau_destcode`
--

DROP TABLE IF EXISTS `bau_destcode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bau_destcode` (
  `destcode` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `blocked_prefix`
--

DROP TABLE IF EXISTS `blocked_prefix`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blocked_prefix` (
  `prefixcode` varchar(16) NOT NULL,
  `createdate` datetime(3) DEFAULT NULL,
  `createby` varchar(32) DEFAULT NULL,
  `destcode` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`prefixcode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `blocked_tariffclass`
--

DROP TABLE IF EXISTS `blocked_tariffclass`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blocked_tariffclass` (
  `sitecode` varchar(3) NOT NULL,
  `tariffclass` varchar(5) NOT NULL,
  `pr_block` varchar(30) DEFAULT NULL,
  `lastupdate` datetime(3) DEFAULT NULL,
  `updateby` varchar(30) DEFAULT NULL,
  `comment` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`sitecode`,`tariffclass`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `blockedani`
--

DROP TABLE IF EXISTS `blockedani`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blockedani` (
  `sitecode` varchar(3) NOT NULL,
  `aniblockgrp` int NOT NULL,
  `ani` varchar(30) NOT NULL,
  PRIMARY KEY (`sitecode`,`aniblockgrp`,`ani`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `blocktab`
--

DROP TABLE IF EXISTS `blocktab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blocktab` (
  `telcocode` varchar(4) DEFAULT NULL,
  `custcode` varchar(8) DEFAULT NULL,
  `batchcode` int DEFAULT NULL,
  `serialcode` int DEFAULT NULL,
  `pincode` varchar(12) DEFAULT NULL,
  `langcode` varchar(8) DEFAULT NULL,
  `lastbal` float DEFAULT NULL,
  `person` varchar(12) DEFAULT NULL,
  `dateblocked` datetime(3) DEFAULT NULL,
  `reason` int NOT NULL,
  `fromno` int DEFAULT NULL,
  `tono` int DEFAULT NULL,
  `id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IX_blocktab` (`telcocode`,`langcode`,`pincode`),
  KEY `IX_blocktab_1` (`telcocode`,`custcode`,`batchcode`,`serialcode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `call_type`
--

DROP TABLE IF EXISTS `call_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `call_type` (
  `type` int DEFAULT NULL,
  `desc` varchar(120) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `callback_cli`
--

DROP TABLE IF EXISTS `callback_cli`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `callback_cli` (
  `sitecode` varchar(3) NOT NULL,
  `cli` varchar(20) NOT NULL,
  `cnxdate` datetime(3) NOT NULL,
  `status` int NOT NULL,
  PRIMARY KEY (`sitecode`,`cli`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `callcount`
--

DROP TABLE IF EXISTS `callcount`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `callcount` (
  `sitecode` varchar(3) NOT NULL,
  `did` varchar(6) NOT NULL,
  `calldate` varchar(10) NOT NULL,
  `callsec` int DEFAULT NULL,
  `counter` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`),
  UNIQUE KEY `acclock_pk` (`sitecode`,`did`,`calldate`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `calldrop`
--

DROP TABLE IF EXISTS `calldrop`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `calldrop` (
  `cardid` int NOT NULL,
  `charge` int NOT NULL,
  `timeperiod` tinyint unsigned NOT NULL,
  `destcode` varchar(32) NOT NULL,
  PRIMARY KEY (`cardid`,`charge`,`timeperiod`,`destcode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `calltype`
--

DROP TABLE IF EXISTS `calltype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `calltype` (
  `calltype` int NOT NULL,
  `name` varchar(32) NOT NULL,
  `description` varchar(128) NOT NULL,
  PRIMARY KEY (`calltype`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `camel_callout`
--

DROP TABLE IF EXISTS `camel_callout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `camel_callout` (
  `sitecode` varchar(3) NOT NULL,
  `prefix` varchar(30) NOT NULL,
  `nbtype` int NOT NULL,
  `oa_prefix` varchar(30) NOT NULL,
  `oa_nbtype` int NOT NULL,
  `free_flag` int NOT NULL,
  `oprmode` int NOT NULL,
  `xlat_pfx` varchar(30) DEFAULT NULL,
  `xlat_nbtype` int DEFAULT NULL,
  `comment` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`sitecode`,`prefix`,`nbtype`,`oa_prefix`,`oa_nbtype`,`free_flag`,`oprmode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `camel_callout_64`
--

DROP TABLE IF EXISTS `camel_callout_64`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `camel_callout_64` (
  `sitecode` varchar(3) NOT NULL,
  `prefix` varchar(30) NOT NULL,
  `nbtype` int NOT NULL,
  `oa_prefix` varchar(30) NOT NULL,
  `oa_nbtype` int NOT NULL,
  `free_flag` int NOT NULL,
  `oprmode` int NOT NULL,
  `xlat_pfx` varchar(30) DEFAULT NULL,
  `xlat_nbtype` int DEFAULT NULL,
  `comment` varchar(64) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `camel_callout_65`
--

DROP TABLE IF EXISTS `camel_callout_65`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `camel_callout_65` (
  `sitecode` varchar(3) NOT NULL,
  `prefix` varchar(30) NOT NULL,
  `nbtype` int NOT NULL,
  `oa_prefix` varchar(30) NOT NULL,
  `oa_nbtype` int NOT NULL,
  `free_flag` int NOT NULL,
  `oprmode` int NOT NULL,
  `xlat_pfx` varchar(30) DEFAULT NULL,
  `xlat_nbtype` int DEFAULT NULL,
  `comment` varchar(64) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `camel_callout_66`
--

DROP TABLE IF EXISTS `camel_callout_66`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `camel_callout_66` (
  `sitecode` varchar(3) NOT NULL,
  `prefix` varchar(30) NOT NULL,
  `nbtype` int NOT NULL,
  `oa_prefix` varchar(30) NOT NULL,
  `oa_nbtype` int NOT NULL,
  `free_flag` int NOT NULL,
  `oprmode` int NOT NULL,
  `xlat_pfx` varchar(30) DEFAULT NULL,
  `xlat_nbtype` int DEFAULT NULL,
  `comment` varchar(64) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `camel_callout_67`
--

DROP TABLE IF EXISTS `camel_callout_67`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `camel_callout_67` (
  `sitecode` varchar(3) NOT NULL,
  `prefix` varchar(30) NOT NULL,
  `nbtype` int NOT NULL,
  `oa_prefix` varchar(30) NOT NULL,
  `oa_nbtype` int NOT NULL,
  `free_flag` int NOT NULL,
  `oprmode` int NOT NULL,
  `xlat_pfx` varchar(30) DEFAULT NULL,
  `xlat_nbtype` int DEFAULT NULL,
  `comment` varchar(64) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `camel_callout_68`
--

DROP TABLE IF EXISTS `camel_callout_68`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `camel_callout_68` (
  `sitecode` varchar(3) NOT NULL,
  `prefix` varchar(30) NOT NULL,
  `nbtype` int NOT NULL,
  `oa_prefix` varchar(30) NOT NULL,
  `oa_nbtype` int NOT NULL,
  `free_flag` int NOT NULL,
  `oprmode` int NOT NULL,
  `xlat_pfx` varchar(30) DEFAULT NULL,
  `xlat_nbtype` int DEFAULT NULL,
  `comment` varchar(64) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `camel_callout_69`
--

DROP TABLE IF EXISTS `camel_callout_69`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `camel_callout_69` (
  `sitecode` varchar(3) NOT NULL,
  `prefix` varchar(30) NOT NULL,
  `nbtype` int NOT NULL,
  `oa_prefix` varchar(30) NOT NULL,
  `oa_nbtype` int NOT NULL,
  `free_flag` int NOT NULL,
  `oprmode` int NOT NULL,
  `xlat_pfx` varchar(30) DEFAULT NULL,
  `xlat_nbtype` int DEFAULT NULL,
  `comment` varchar(64) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `camel_prefixNB`
--

DROP TABLE IF EXISTS `camel_prefixNB`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `camel_prefixNB` (
  `sitecode` varchar(3) NOT NULL,
  `prefix` varchar(30) NOT NULL,
  `mode` int NOT NULL,
  `oprmode` int NOT NULL,
  `oa_prefix` varchar(30) NOT NULL,
  `free_flag` int DEFAULT NULL,
  PRIMARY KEY (`sitecode`,`mode`,`oprmode`,`prefix`,`oa_prefix`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `camel_uk_backup`
--

DROP TABLE IF EXISTS `camel_uk_backup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `camel_uk_backup` (
  `sitecode` varchar(3) NOT NULL,
  `prefix` varchar(30) NOT NULL,
  `nbtype` int NOT NULL,
  `oa_prefix` varchar(30) NOT NULL,
  `oa_nbtype` int NOT NULL,
  `free_flag` int NOT NULL,
  `oprmode` int NOT NULL,
  `xlat_pfx` varchar(30) DEFAULT NULL,
  `xlat_nbtype` int DEFAULT NULL,
  `comment` varchar(64) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cardName`
--

DROP TABLE IF EXISTS `cardName`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cardName` (
  `cardname` varchar(32) NOT NULL,
  PRIMARY KEY (`cardname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cardTariffClass`
--

DROP TABLE IF EXISTS `cardTariffClass`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cardTariffClass` (
  `siteCode` varchar(3) NOT NULL,
  `cardId` int NOT NULL,
  `trffclass` varchar(4) NOT NULL,
  PRIMARY KEY (`siteCode`,`cardId`,`trffclass`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `card_messages`
--

DROP TABLE IF EXISTS `card_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `card_messages` (
  `sitecode` varchar(3) NOT NULL,
  `brand_type` int NOT NULL,
  `cardid` int NOT NULL,
  `tariffclass` varchar(5) NOT NULL,
  `messageid` int NOT NULL,
  `roaming` int NOT NULL,
  `text` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`sitecode`,`brand_type`,`cardid`,`tariffclass`,`messageid`,`roaming`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `card_messages_reference`
--

DROP TABLE IF EXISTS `card_messages_reference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `card_messages_reference` (
  `messageid` int NOT NULL,
  `comment` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`messageid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cardfamily`
--

DROP TABLE IF EXISTS `cardfamily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cardfamily` (
  `CardID` int NOT NULL,
  `Sitecode` varchar(3) DEFAULT NULL,
  `CardName` varchar(32) DEFAULT NULL,
  `Denomination` float DEFAULT NULL,
  `Description` varchar(100) DEFAULT NULL,
  `DefaultTrffclass` varchar(4) DEFAULT NULL,
  `LatestTrffclass` varchar(4) DEFAULT NULL,
  `Daysvalid` int DEFAULT NULL,
  `Langcode` varchar(8) DEFAULT NULL,
  `Currcode` varchar(3) DEFAULT NULL,
  `cardtype` int DEFAULT NULL,
  `status` int DEFAULT NULL,
  `AccountType` int DEFAULT NULL,
  `hotlineNB` varchar(32) DEFAULT NULL,
  `svcNB_topup` varchar(32) DEFAULT NULL,
  `svcNB_AccEarly` varchar(30) DEFAULT NULL,
  `svcNB_AccExprd` varchar(30) DEFAULT NULL,
  `svcNB_NoEnough` varchar(30) DEFAULT NULL,
  `svcNB_NoDest` varchar(30) DEFAULT NULL,
  `svcNB_ResBlock` varchar(30) DEFAULT NULL,
  `Createdby` varchar(40) DEFAULT NULL,
  `Createddate` datetime(3) DEFAULT NULL,
  `URL_autotopup` varchar(125) DEFAULT NULL,
  PRIMARY KEY (`CardID`),
  UNIQUE KEY `idx_1` (`Sitecode`,`CardName`,`Denomination`,`Currcode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `country_config`
--

DROP TABLE IF EXISTS `country_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `country_config` (
  `sitecode` varchar(3) NOT NULL,
  `countrycode` varchar(5) NOT NULL,
  `VPLMN_type` int NOT NULL,
  `comment` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`sitecode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `daycode`
--

DROP TABLE IF EXISTS `daycode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `daycode` (
  `daycode` int NOT NULL,
  `dayfrom` int NOT NULL,
  `dayto` int NOT NULL,
  `comment` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`daycode`),
  KEY `idx1_daycode` (`dayfrom`,`dayto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `daytime`
--

DROP TABLE IF EXISTS `daytime`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `daytime` (
  `daytime_id` int NOT NULL,
  `sitecode` varchar(3) NOT NULL,
  `tclstype` int NOT NULL,
  `tclskey` varchar(15) NOT NULL,
  `daycode` int NOT NULL,
  `timecode` int NOT NULL,
  `timeclass` int NOT NULL,
  `comment` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`daytime_id`),
  UNIQUE KEY `idx1` (`sitecode`,`tclstype`,`tclskey`,`daycode`,`timecode`),
  KEY `idx2` (`sitecode`,`tclstype`,`tclskey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `exchangerate`
--

DROP TABLE IF EXISTS `exchangerate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `exchangerate` (
  `currcode1` varchar(8) DEFAULT NULL,
  `currcode2` varchar(8) DEFAULT NULL,
  `factor` float DEFAULT NULL,
  `lastupdate` datetime(3) DEFAULT NULL,
  `lastuser` varchar(20) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gprs_tariffclass`
--

DROP TABLE IF EXISTS `gprs_tariffclass`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gprs_tariffclass` (
  `sitecode` char(3) NOT NULL,
  `trffclass` char(4) NOT NULL,
  `chargingtype` int DEFAULT NULL,
  `allocationvalue` bigint DEFAULT NULL,
  `destcode` varchar(32) DEFAULT NULL,
  `minunit` float DEFAULT NULL,
  `RatingID` int NOT NULL,
  `APN` varchar(32) NOT NULL,
  `allocationdelay` bigint DEFAULT NULL,
  `balance_threshold` float DEFAULT NULL,
  `old_allocation_value` float DEFAULT NULL,
  `cdr_flag` int DEFAULT NULL,
  `allow_minusbal` int DEFAULT NULL,
  PRIMARY KEY (`sitecode`,`trffclass`,`RatingID`,`APN`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gprstariff`
--

DROP TABLE IF EXISTS `gprstariff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gprstariff` (
  `telcocode` varchar(4) NOT NULL,
  `sitecode` varchar(3) NOT NULL,
  `destcode` varchar(64) NOT NULL,
  `trffclass` varchar(4) NOT NULL,
  `charge` int NOT NULL,
  `timeperiod` int NOT NULL,
  `cnxdelay` int DEFAULT NULL,
  `cnxunit` float NOT NULL,
  `sampdelay` int DEFAULT NULL,
  `sampunit` float NOT NULL,
  `freesec` int DEFAULT NULL,
  `premiumdest` int DEFAULT NULL,
  `cfreemin` int DEFAULT NULL,
  `routeclass` int NOT NULL,
  `percentage` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `holiday`
--

DROP TABLE IF EXISTS `holiday`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `holiday` (
  `holiday_id` int NOT NULL,
  `sitecode` varchar(3) NOT NULL,
  `hdate` varchar(10) NOT NULL,
  `tclstype` int NOT NULL,
  `tclskey` varchar(15) NOT NULL,
  `timeclass` int NOT NULL,
  `comment` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`holiday_id`),
  UNIQUE KEY `idx1` (`sitecode`,`hdate`,`tclstype`,`tclskey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `homephone`
--

DROP TABLE IF EXISTS `homephone`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `homephone` (
  `sitecode` varchar(3) NOT NULL,
  `prefix` varchar(10) NOT NULL,
  `comment` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`sitecode`,`prefix`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `mvno_notification_config`
--

DROP TABLE IF EXISTS `mvno_notification_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mvno_notification_config` (
  `sitecode` varchar(8) NOT NULL,
  `cardid` int NOT NULL,
  `sms_interface` int DEFAULT NULL,
  `sms_url` varchar(64) DEFAULT NULL,
  `oa_addr` varchar(20) DEFAULT NULL,
  `oa_addr_type` int DEFAULT NULL,
  `servicename` varchar(32) DEFAULT NULL,
  `accountid` varchar(20) DEFAULT NULL,
  `dcs` int DEFAULT NULL,
  `ussd_url` varchar(64) DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL,
  `brandtype` int NOT NULL,
  `tariffclass` varchar(5) NOT NULL,
  `sms_iwmsc_url` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`sitecode`,`brandtype`,`cardid`,`tariffclass`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `mvno_tsan`
--

DROP TABLE IF EXISTS `mvno_tsan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mvno_tsan` (
  `sitecode` varchar(3) NOT NULL,
  `TSAN` varchar(30) NOT NULL,
  `TSAN_noa` int NOT NULL,
  `status` int NOT NULL,
  `CdPN` varchar(30) DEFAULT NULL,
  `CdPN_noa` int DEFAULT NULL,
  `CgPN` varchar(30) DEFAULT NULL,
  `CgPN_noa` int DEFAULT NULL,
  `RN` varchar(30) DEFAULT NULL,
  `RN_noa` int DEFAULT NULL,
  `OCN` varchar(30) DEFAULT NULL,
  `OCN_noa` int DEFAULT NULL,
  `IMSI` varchar(15) DEFAULT NULL,
  `OA` varchar(30) DEFAULT NULL,
  `OA_noa` int DEFAULT NULL,
  `entrydate` datetime(3) DEFAULT NULL,
  `charge` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `mvno_xlattonormal`
--

DROP TABLE IF EXISTS `mvno_xlattonormal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mvno_xlattonormal` (
  `sitecode` varchar(3) DEFAULT NULL,
  `comment` varchar(32) DEFAULT NULL,
  `pfx` varchar(30) NOT NULL,
  `nbtype` int NOT NULL,
  `normalnbpfx` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`pfx`,`nbtype`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `onegocharge`
--

DROP TABLE IF EXISTS `onegocharge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `onegocharge` (
  `trffclass` varchar(4) NOT NULL,
  `destcode` varchar(32) NOT NULL,
  `value` float DEFAULT NULL,
  `timeperiod` tinyint unsigned NOT NULL,
  `charge` tinyint unsigned NOT NULL,
  `inpercentage` int DEFAULT NULL,
  PRIMARY KEY (`trffclass`,`destcode`,`charge`,`timeperiod`),
  KEY `idx1` (`trffclass`,`destcode`,`timeperiod`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `prefix`
--

DROP TABLE IF EXISTS `prefix`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prefix` (
  `sitecode` varchar(3) NOT NULL,
  `prefixcode` varchar(30) NOT NULL,
  `destcode` varchar(64) NOT NULL,
  `mindigit` int DEFAULT NULL,
  `maxdigit` int DEFAULT NULL,
  `isactive` int DEFAULT NULL,
  `comment` varchar(64) DEFAULT NULL,
  `prefixset` int NOT NULL,
  `prefixtype` int DEFAULT NULL,
  `mobilecdrop` int DEFAULT NULL,
  PRIMARY KEY (`sitecode`,`prefixset`,`prefixcode`),
  KEY `prefix_idx1` (`prefixset`,`prefixcode`),
  KEY `prefixidxtemp` (`sitecode`,`prefixcode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `premdest`
--

DROP TABLE IF EXISTS `premdest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `premdest` (
  `destcode` varchar(15) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `premiumnb`
--

DROP TABLE IF EXISTS `premiumnb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `premiumnb` (
  `phonenb` varchar(20) NOT NULL,
  `user` varchar(10) NOT NULL,
  `reason` varchar(32) NOT NULL,
  `date` varchar(10) NOT NULL,
  PRIMARY KEY (`phonenb`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `progcharge`
--

DROP TABLE IF EXISTS `progcharge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `progcharge` (
  `trffclass` varchar(4) NOT NULL,
  `minsec` int NOT NULL,
  `maxsec` int DEFAULT NULL,
  `ccfactor` int DEFAULT NULL,
  PRIMARY KEY (`trffclass`,`minsec`),
  KEY `pch1` (`trffclass`,`minsec`),
  KEY `pch2` (`trffclass`,`maxsec`),
  KEY `pch3` (`trffclass`,`ccfactor`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `progcharge1`
--

DROP TABLE IF EXISTS `progcharge1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `progcharge1` (
  `trffclass` varchar(4) NOT NULL,
  `destcode` varchar(32) NOT NULL,
  `minsec` int NOT NULL,
  `maxsec` int DEFAULT NULL,
  `ccfactor` int DEFAULT NULL,
  `charge` int NOT NULL,
  `timeperiod` tinyint unsigned NOT NULL,
  `progdec` int DEFAULT NULL,
  `ccfactordec` float DEFAULT NULL,
  PRIMARY KEY (`trffclass`,`destcode`,`charge`,`timeperiod`,`minsec`),
  KEY `idx1` (`trffclass`,`destcode`,`charge`,`minsec`),
  KEY `idx2` (`trffclass`,`destcode`,`charge`,`timeperiod`),
  KEY `pch11` (`trffclass`,`destcode`,`maxsec`),
  KEY `pch12` (`trffclass`,`ccfactor`),
  KEY `pch13` (`trffclass`,`destcode`,`charge`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `progcharge2`
--

DROP TABLE IF EXISTS `progcharge2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `progcharge2` (
  `cardid` int NOT NULL,
  `charge` int NOT NULL,
  `timeperiod` tinyint unsigned NOT NULL,
  `minsec` int NOT NULL,
  `maxsec` int NOT NULL,
  `unitcharge` float DEFAULT NULL,
  PRIMARY KEY (`cardid`,`charge`,`timeperiod`,`minsec`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `progsampling`
--

DROP TABLE IF EXISTS `progsampling`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `progsampling` (
  `sitecode` varchar(3) NOT NULL,
  `telcocode` varchar(3) NOT NULL,
  `trffclass` varchar(8) NOT NULL,
  `destcode` varchar(32) NOT NULL,
  `charge` int NOT NULL,
  `timeperiod` int NOT NULL,
  `minsec` int DEFAULT NULL,
  `maxsec` int NOT NULL,
  `sampdelay` int NOT NULL,
  `sampunit` float NOT NULL,
  PRIMARY KEY (`sitecode`,`telcocode`,`trffclass`,`destcode`,`charge`,`timeperiod`,`maxsec`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `promotion`
--

DROP TABLE IF EXISTS `promotion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `promotion` (
  `promoid` int NOT NULL,
  `promoname` varchar(32) NOT NULL,
  `sitecode` varchar(5) NOT NULL,
  `trffclass` varchar(8) NOT NULL,
  `accesstype` int NOT NULL,
  `startdate` datetime(3) NOT NULL,
  `enddate` datetime(3) NOT NULL,
  `iparam` int NOT NULL,
  `cparam` varchar(32) NOT NULL,
  `insertby` varchar(32) NOT NULL,
  `comment` varchar(128) NOT NULL,
  `promotype` int DEFAULT NULL,
  `minbal` double DEFAULT NULL,
  `proportion` float DEFAULT NULL,
  `cnxcharge_mode` int DEFAULT NULL,
  `cnxcharge_delay` int DEFAULT NULL,
  `cnxcharge_factor` float DEFAULT NULL,
  `report_flag` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`),
  KEY `promotion_idx` (`sitecode`,`trffclass`,`accesstype`,`startdate`),
  KEY `promotion_idx1` (`promoid`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `promotion_counter`
--

DROP TABLE IF EXISTS `promotion_counter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `promotion_counter` (
  `custcode` char(8) NOT NULL,
  `batchcode` int NOT NULL,
  `serialcode` int NOT NULL,
  `mobileNo` varchar(16) DEFAULT NULL,
  `counter` int DEFAULT NULL,
  `total_bonus` float DEFAULT NULL,
  `promotype` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`),
  KEY `idx1_promo` (`custcode`,`batchcode`,`serialcode`),
  KEY `idx2_promo` (`mobileNo`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `promotion_dest`
--

DROP TABLE IF EXISTS `promotion_dest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `promotion_dest` (
  `promoid` int NOT NULL,
  `destcode` varchar(32) NOT NULL,
  `proportion` float DEFAULT NULL,
  `dest_cnxcharge_delay` int DEFAULT NULL,
  `dest_cnxcharge_dactor` float DEFAULT NULL,
  `dest_cnxcharge_freedelay` int DEFAULT NULL,
  `accesstype` int NOT NULL,
  `timeperiod` int NOT NULL,
  PRIMARY KEY (`promoid`,`destcode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `promotion_freeminute`
--

DROP TABLE IF EXISTS `promotion_freeminute`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `promotion_freeminute` (
  `promoid` int NOT NULL,
  `custcode` varchar(8) NOT NULL,
  `batchcode` int NOT NULL,
  `serialcode` int NOT NULL,
  `freeminute` int NOT NULL,
  `insdate` datetime(3) NOT NULL,
  `insby` varchar(12) NOT NULL,
  `promodest` varchar(32) DEFAULT NULL,
  `lastusg` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`promoid`,`custcode`,`batchcode`,`serialcode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `promotion_topup`
--

DROP TABLE IF EXISTS `promotion_topup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `promotion_topup` (
  `promoid` int NOT NULL,
  `promoname` varchar(32) NOT NULL,
  `promotype` int NOT NULL,
  `sitecode` varchar(5) NOT NULL,
  `startdate` datetime(3) NOT NULL,
  `enddate` datetime(3) NOT NULL,
  `extra_amount` double NOT NULL,
  `currcode` varchar(3) DEFAULT NULL,
  `max_counter` int DEFAULT NULL,
  `insertby` varchar(32) DEFAULT NULL,
  `comment` varchar(128) DEFAULT NULL,
  `minbal` double DEFAULT NULL,
  `cardid` int DEFAULT NULL,
  `vc_tariffclass` varchar(4) NOT NULL,
  `vc_price` float NOT NULL,
  `accum_extra_amount` float NOT NULL,
  `accum_delay` int NOT NULL,
  `accum_maxcounter` int NOT NULL,
  `custcode` char(8) NOT NULL,
  `batchcode` int NOT NULL,
  `serialcode_fr` int NOT NULL,
  `serialcode_to` int NOT NULL,
  `status` int DEFAULT NULL,
  PRIMARY KEY (`sitecode`,`promotype`,`custcode`,`batchcode`,`serialcode_fr`,`serialcode_to`),
  UNIQUE KEY `idx_site_cc_bc_sc_trf_prc` (`sitecode`,`custcode`,`batchcode`,`serialcode_fr`,`serialcode_to`,`vc_tariffclass`,`vc_price`),
  KEY `promotion_topup_idx1` (`sitecode`,`promotype`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `promotion_topup_minute`
--

DROP TABLE IF EXISTS `promotion_topup_minute`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `promotion_topup_minute` (
  `promoid` int DEFAULT NULL,
  `promoname` varchar(32) NOT NULL,
  `promotype` int NOT NULL,
  `sitecode` varchar(5) NOT NULL,
  `startdate` datetime(3) NOT NULL,
  `enddate` datetime(3) NOT NULL,
  `extra_minute` int NOT NULL,
  `insertby` varchar(32) DEFAULT NULL,
  `comment` varchar(128) DEFAULT NULL,
  `vc_tariffclass` varchar(4) NOT NULL,
  `vc_price` float NOT NULL,
  `custcode` char(8) NOT NULL,
  `batchcode` int NOT NULL,
  `serialcode_fr` int NOT NULL,
  `serialcode_to` int NOT NULL,
  `status` int DEFAULT NULL,
  PRIMARY KEY (`sitecode`,`promotype`,`custcode`,`batchcode`,`serialcode_fr`,`serialcode_to`,`vc_tariffclass`,`vc_price`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `promotiontypes`
--

DROP TABLE IF EXISTS `promotiontypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `promotiontypes` (
  `type` int NOT NULL,
  `desc` varchar(32) NOT NULL,
  PRIMARY KEY (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `rcid_setting`
--

DROP TABLE IF EXISTS `rcid_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rcid_setting` (
  `sitecode` varchar(3) NOT NULL,
  `rcid` varchar(50) NOT NULL,
  `ported_prompt` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`sitecode`,`rcid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `roamcheckdest`
--

DROP TABLE IF EXISTS `roamcheckdest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roamcheckdest` (
  `sitecode` varchar(3) NOT NULL,
  `destcode` varchar(32) NOT NULL,
  `status` int DEFAULT NULL,
  `comment` varchar(32) DEFAULT NULL,
  `xlatedpfx` varchar(30) DEFAULT NULL,
  `normalnbpfx` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`sitecode`,`destcode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `route`
--

DROP TABLE IF EXISTS `route`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `route` (
  `sitecode` varchar(3) NOT NULL,
  `switchcode` varchar(3) NOT NULL,
  `routeclass` varchar(4) NOT NULL,
  `destcode` varchar(15) NOT NULL,
  `priority` int NOT NULL,
  `isactive` int DEFAULT NULL,
  `trunkcode` varchar(8) DEFAULT NULL,
  `playddial` varchar(1) DEFAULT NULL,
  `sectoremov` varchar(2) DEFAULT NULL,
  `comment` varchar(30) DEFAULT NULL,
  `direction` int DEFAULT NULL,
  PRIMARY KEY (`sitecode`,`switchcode`,`routeclass`,`destcode`,`priority`),
  KEY `routeidx1` (`sitecode`,`switchcode`,`routeclass`,`destcode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `shop`
--

DROP TABLE IF EXISTS `shop`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shop` (
  `shopname` varchar(20) DEFAULT NULL,
  `telcocode` varchar(4) NOT NULL,
  `custcode` varchar(8) NOT NULL,
  `batchcode` int NOT NULL,
  `contact` varchar(30) DEFAULT NULL,
  `phonenb1` varchar(20) DEFAULT NULL,
  `phonenb2` varchar(20) DEFAULT NULL,
  `fax` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`telcocode`,`custcode`,`batchcode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `site`
--

DROP TABLE IF EXISTS `site`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `site` (
  `sitecode` varchar(3) NOT NULL,
  `name` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`sitecode`),
  KEY `siteidx1` (`sitecode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sms_cost`
--

DROP TABLE IF EXISTS `sms_cost`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sms_cost` (
  `sitecode` varchar(3) NOT NULL,
  `prefixcode` varchar(32) NOT NULL,
  `trunk` varchar(64) DEFAULT NULL,
  `sampunit` float NOT NULL,
  PRIMARY KEY (`sitecode`,`prefixcode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `smscb`
--

DROP TABLE IF EXISTS `smscb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `smscb` (
  `destcode` varchar(64) DEFAULT NULL,
  `legacost` float DEFAULT NULL,
  `legbcost` float DEFAULT NULL,
  `currcode` varchar(3) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `special_number`
--

DROP TABLE IF EXISTS `special_number`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `special_number` (
  `cardid` int NOT NULL,
  `prefix` varchar(20) NOT NULL,
  `nbtype` int NOT NULL,
  `pr_message` varchar(20) DEFAULT NULL,
  `action_mode` int DEFAULT NULL,
  `desctiption` varchar(138) DEFAULT NULL,
  PRIMARY KEY (`cardid`,`prefix`,`nbtype`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `speeddial`
--

DROP TABLE IF EXISTS `speeddial`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `speeddial` (
  `telcocode` varchar(4) NOT NULL,
  `custcode` varchar(8) NOT NULL,
  `batchcode` int NOT NULL,
  `serialcode` int NOT NULL,
  `sdnum` int NOT NULL,
  `phnumber` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`telcocode`,`custcode`,`batchcode`,`serialcode`,`sdnum`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tariff`
--

DROP TABLE IF EXISTS `tariff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tariff` (
  `telcocode` varchar(4) NOT NULL,
  `sitecode` varchar(3) NOT NULL,
  `destcode` varchar(64) NOT NULL,
  `trffclass` varchar(4) NOT NULL,
  `charge` int NOT NULL,
  `timeperiod` int NOT NULL,
  `cnxdelay` int DEFAULT NULL,
  `cnxunit` float NOT NULL,
  `sampdelay` int DEFAULT NULL,
  `sampunit` float NOT NULL,
  `freesec` int DEFAULT NULL,
  `premiumdest` int DEFAULT NULL,
  `cfreemin` int DEFAULT NULL,
  `routeclass` int NOT NULL,
  `percentage` int DEFAULT NULL,
  PRIMARY KEY (`telcocode`,`sitecode`,`destcode`,`trffclass`,`charge`,`timeperiod`,`routeclass`),
  KEY `someindex` (`telcocode`,`sitecode`,`trffclass`,`charge`,`timeperiod`,`routeclass`),
  KEY `tariff_idx1` (`trffclass`,`timeperiod`,`charge`,`destcode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tariff_by_balance`
--

DROP TABLE IF EXISTS `tariff_by_balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tariff_by_balance` (
  `telcocode` varchar(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sitecode` varchar(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `trffclass` varchar(4) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `percent_balfrom` double NOT NULL,
  `percent_balto` double DEFAULT NULL,
  `percent_cnxunit_increase` double DEFAULT NULL,
  PRIMARY KEY (`telcocode`,`sitecode`,`trffclass`,`percent_balfrom`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tariff_temp_viewer`
--

DROP TABLE IF EXISTS `tariff_temp_viewer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tariff_temp_viewer` (
  `sitecode` varchar(3) NOT NULL,
  `trffclass` varchar(4) NOT NULL,
  `destcode` varchar(64) NOT NULL,
  `SampMinute_0` float NOT NULL,
  `CnxMinute_0` float NOT NULL,
  `sampdelay_0` int NOT NULL,
  `cnxdelay_0` int NOT NULL,
  `SampMinute_1` float NOT NULL,
  `CnxMinute_1` float NOT NULL,
  `sampdelay_1` int NOT NULL,
  `cnxdelay_1` int NOT NULL,
  `SampMinute_2` float NOT NULL,
  `CnxMinute_2` float NOT NULL,
  `sampdelay_2` int NOT NULL,
  `cnxdelay_2` int NOT NULL,
  `SampMinute_3` float NOT NULL,
  `CnxMinute_3` float NOT NULL,
  `sampdelay_3` int NOT NULL,
  `cnxdelay_3` int NOT NULL,
  `SampMinute_4` float NOT NULL,
  `CnxMinute_4` float NOT NULL,
  `sampdelay_4` int NOT NULL,
  `cnxdelay_4` int NOT NULL,
  `SampMinute_5` float NOT NULL,
  `CnxMinute_5` float NOT NULL,
  `sampdelay_5` int NOT NULL,
  `cnxdelay_5` int NOT NULL,
  `SampMinute_6` float NOT NULL,
  `CnxMinute_6` float NOT NULL,
  `sampdelay_6` int NOT NULL,
  `cnxdelay_6` int NOT NULL,
  `SampMinute_7` float NOT NULL,
  `CnxMinute_7` float NOT NULL,
  `sampdelay_7` int NOT NULL,
  `cnxdelay_7` int NOT NULL,
  `SampMinute_8` float NOT NULL,
  `CnxMinute_8` float NOT NULL,
  `sampdelay_8` int NOT NULL,
  `cnxdelay_8` int NOT NULL,
  `SampMinute_9` float NOT NULL,
  `CnxMinute_9` float NOT NULL,
  `sampdelay_9` int NOT NULL,
  `cnxdelay_9` int NOT NULL,
  `SampMinute_10` float NOT NULL,
  `CnxMinute_10` float NOT NULL,
  `sampdelay_10` int NOT NULL,
  `cnxdelay_10` int NOT NULL,
  `SampMinute_11` float NOT NULL,
  `CnxMinute_11` float NOT NULL,
  `sampdelay_11` int NOT NULL,
  `cnxdelay_11` int NOT NULL,
  `SampMinute_12` float NOT NULL,
  `CnxMinute_12` float NOT NULL,
  `sampdelay_12` int NOT NULL,
  `cnxdelay_12` int NOT NULL,
  `SampMinute_13` float NOT NULL,
  `CnxMinute_13` float NOT NULL,
  `sampdelay_13` int NOT NULL,
  `cnxdelay_13` int NOT NULL,
  `SampMinute_14` float NOT NULL,
  `CnxMinute_14` float NOT NULL,
  `sampdelay_14` int NOT NULL,
  `cnxdelay_14` int NOT NULL,
  `SampMinute_15` float NOT NULL,
  `CnxMinute_15` float NOT NULL,
  `sampdelay_15` int NOT NULL,
  `cnxdelay_15` int NOT NULL,
  `SampMinute_16` float NOT NULL,
  `CnxMinute_16` float NOT NULL,
  `sampdelay_16` int NOT NULL,
  `cnxdelay_16` int NOT NULL,
  `SampMinute_17` float NOT NULL,
  `CnxMinute_17` float NOT NULL,
  `sampdelay_17` int NOT NULL,
  `cnxdelay_17` int NOT NULL,
  `SampMinute_18` float DEFAULT NULL,
  `CnxMinute_18` float DEFAULT NULL,
  `sampdelay_18` int DEFAULT NULL,
  `cnxdelay_18` int DEFAULT NULL,
  `SampMinute_19` float DEFAULT NULL,
  `CnxMinute_19` float DEFAULT NULL,
  `sampdelay_19` int DEFAULT NULL,
  `cnxdelay_19` int DEFAULT NULL,
  `SampMinute_20` float DEFAULT NULL,
  `CnxMinute_20` float DEFAULT NULL,
  `sampdelay_20` int DEFAULT NULL,
  `cnxdelay_20` int DEFAULT NULL,
  `SampMinute_21` float DEFAULT NULL,
  `CnxMinute_21` float DEFAULT NULL,
  `sampdelay_21` int DEFAULT NULL,
  `cnxdelay_21` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tariffclass`
--

DROP TABLE IF EXISTS `tariffclass`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tariffclass` (
  `telcocode` varchar(4) NOT NULL,
  `sitecode` varchar(3) NOT NULL,
  `trffclass` varchar(4) NOT NULL,
  `maintdelay` int DEFAULT NULL,
  `maintunit` float DEFAULT NULL,
  `firstcnx` int DEFAULT NULL,
  `newdelay` int DEFAULT NULL,
  `trffmode` int DEFAULT NULL,
  `prefixset` int DEFAULT NULL,
  `createdate` datetime(3) DEFAULT NULL,
  `moddate` datetime(3) DEFAULT NULL,
  `comment` varchar(20) DEFAULT NULL,
  `cnxcharge` int DEFAULT NULL,
  `freecnxdelay` int DEFAULT NULL,
  `ceilingtt` int DEFAULT NULL,
  `calld` int DEFAULT NULL,
  `minunit` int DEFAULT NULL,
  `cnxunit` int DEFAULT NULL,
  `progcharge` int DEFAULT NULL,
  `onegocharge` float DEFAULT NULL,
  `vcalld` int DEFAULT NULL,
  `routeclass` varchar(4) DEFAULT NULL,
  `maxnbcharge` int DEFAULT NULL,
  `def_routecls` int DEFAULT NULL,
  `prem_routecls` int DEFAULT NULL,
  `historycharge` float DEFAULT NULL,
  `acchischarge` float DEFAULT NULL,
  `desthischarge` float DEFAULT NULL,
  `currcode` varchar(5) DEFAULT NULL,
  `gradeWorst` int DEFAULT NULL,
  `gradeBest` int DEFAULT NULL,
  `gradecode` varchar(5) DEFAULT NULL,
  `chgpersec` int DEFAULT NULL,
  `initcredit` int DEFAULT NULL,
  `samphischarge` float DEFAULT NULL,
  `roam_surcharge` float DEFAULT NULL,
  `xlatset` int DEFAULT NULL,
  PRIMARY KEY (`telcocode`,`sitecode`,`trffclass`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tclass`
--

DROP TABLE IF EXISTS `tclass`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tclass` (
  `telcocode` varchar(4) DEFAULT NULL,
  `sitecode` varchar(3) DEFAULT NULL,
  `trffclass` varchar(4) DEFAULT NULL,
  `cnxdelay` int DEFAULT NULL,
  `cnxunit` float DEFAULT NULL,
  `maintdelay` int DEFAULT NULL,
  `maintunit` float DEFAULT NULL,
  `sampdelay` int DEFAULT NULL,
  `unitfactor` float DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tempdata`
--

DROP TABLE IF EXISTS `tempdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tempdata` (
  `prefix` int NOT NULL,
  `prefixinfo` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`prefix`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `timeclass`
--

DROP TABLE IF EXISTS `timeclass`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `timeclass` (
  `timeclass` int NOT NULL,
  `comment` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`timeclass`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `timecode`
--

DROP TABLE IF EXISTS `timecode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `timecode` (
  `timecode` int NOT NULL,
  `timefrom` int NOT NULL,
  `timeto` int NOT NULL,
  `timeto2` int DEFAULT NULL,
  `comment` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`timecode`),
  KEY `idx1_timecode` (`timefrom`,`timeto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `toriff`
--

DROP TABLE IF EXISTS `toriff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `toriff` (
  `telcocode` varchar(4) NOT NULL,
  `sitecode` varchar(3) NOT NULL,
  `destcode` varchar(64) DEFAULT NULL,
  `trffclass` varchar(4) NOT NULL,
  `charge` int NOT NULL,
  `timeperiod` int NOT NULL,
  `cnxdelay` int DEFAULT NULL,
  `cnxunit` float NOT NULL,
  `sampdelay` int DEFAULT NULL,
  `sampunit` float NOT NULL,
  `freesec` int DEFAULT NULL,
  `premiumdest` int DEFAULT NULL,
  `cfreemin` int DEFAULT NULL,
  `routeclass` int NOT NULL,
  `percentage` int DEFAULT NULL,
  `idpk` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`idpk`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ttx`
--

DROP TABLE IF EXISTS `ttx`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ttx` (
  `telcocode` varchar(4) NOT NULL,
  `sitecode` varchar(3) NOT NULL,
  `destcode` varchar(64) NOT NULL,
  `trffclass` varchar(4) NOT NULL,
  `charge` int NOT NULL,
  `timeperiod` int NOT NULL,
  `cnxdelay` int DEFAULT NULL,
  `cnxunit` float NOT NULL,
  `sampdelay` int DEFAULT NULL,
  `sampunit` float NOT NULL,
  `freesec` int DEFAULT NULL,
  `premiumdest` int DEFAULT NULL,
  `cfreemin` int DEFAULT NULL,
  `routeclass` int NOT NULL,
  `percentage` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userlog`
--

DROP TABLE IF EXISTS `userlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userlog` (
  `userid` char(10) NOT NULL,
  `extime` datetime(3) DEFAULT NULL,
  `Comment` char(100) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpwd`
--

DROP TABLE IF EXISTS `userpwd`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpwd` (
  `passwd` char(12) DEFAULT NULL,
  `usrname` varchar(15) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vbcp_access_template`
--

DROP TABLE IF EXISTS `vbcp_access_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vbcp_access_template` (
  `sitecode` varchar(3) NOT NULL,
  `switchcode` varchar(3) NOT NULL,
  `acsscode` varchar(3) DEFAULT NULL,
  `comment` varchar(30) DEFAULT NULL,
  `isactive` int DEFAULT NULL,
  `calltype` int DEFAULT NULL,
  `charge` int DEFAULT NULL,
  `mode` int DEFAULT NULL,
  `langcode` varchar(8) DEFAULT NULL,
  `telcocode` varchar(4) DEFAULT NULL,
  `custcode` varchar(8) DEFAULT NULL,
  `batchcode` int DEFAULT NULL,
  `serialcode` int DEFAULT NULL,
  `lang` varchar(10) DEFAULT NULL,
  `did` varchar(12) NOT NULL,
  `trunkcode` varchar(8) NOT NULL,
  `fullno` varchar(30) DEFAULT NULL,
  `publishno` varchar(30) DEFAULT NULL,
  `routeclass` varchar(4) DEFAULT NULL,
  `aniblockgrp` int DEFAULT NULL,
  `usrmonitor` int DEFAULT NULL,
  `anicharge` int DEFAULT NULL,
  `didtype` int DEFAULT NULL,
  `counter` int DEFAULT NULL,
  `maxaccess` int DEFAULT NULL,
  `accesstype` char(1) DEFAULT NULL,
  `sharedtype` int DEFAULT NULL,
  `blockpayphone` int DEFAULT NULL,
  `autodetect_pphone` int DEFAULT NULL,
  `costa` double DEFAULT NULL,
  `legA_tariffclass` varchar(4) DEFAULT NULL,
  `logfile` int DEFAULT NULL,
  `min_dialdigits` int DEFAULT NULL,
  `prefix_set` int DEFAULT NULL,
  `xlat_set` varchar(4) DEFAULT NULL,
  `timeclass_set` varchar(5) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `xlat`
--

DROP TABLE IF EXISTS `xlat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `xlat` (
  `sitecode` varchar(3) NOT NULL,
  `switchcode` varchar(3) NOT NULL,
  `prefix` varchar(20) NOT NULL,
  `trunkcode` varchar(8) NOT NULL,
  `direction` int NOT NULL,
  `xlatpfx` varchar(30) DEFAULT NULL,
  `pfxlen` int DEFAULT NULL,
  `comment` varchar(64) DEFAULT NULL,
  `numbertype` int DEFAULT NULL,
  `xlatNBtype` int DEFAULT NULL,
  `id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `xlat_idx1` (`sitecode`,`switchcode`,`prefix`,`trunkcode`,`direction`,`numbertype`),
  KEY `xlat_idx0` (`sitecode`,`switchcode`,`prefix`,`trunkcode`,`direction`),
  KEY `xlat_idx2` (`switchcode`,`prefix`),
  KEY `xlat_idx3` (`trunkcode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `xlat_byset`
--

DROP TABLE IF EXISTS `xlat_byset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `xlat_byset` (
  `sitecode` varchar(3) DEFAULT NULL,
  `switchcode` varchar(3) DEFAULT NULL,
  `prefix` varchar(25) DEFAULT NULL,
  `trunkcode` varchar(8) DEFAULT NULL,
  `direction` int DEFAULT NULL,
  `xlatpfx` varchar(30) DEFAULT NULL,
  `pfxlen` int DEFAULT NULL,
  `comment` varchar(64) DEFAULT NULL,
  `numbertype` int DEFAULT NULL,
  `xlatNBtype` int DEFAULT NULL,
  `id` int NOT NULL,
  `xlatSet` int DEFAULT NULL,
  `nblen` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx0_xlat_byset` (`sitecode`,`switchcode`,`prefix`,`trunkcode`,`direction`,`numbertype`,`xlatSet`,`nblen`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping events for database 'espprm'
--

--
-- Dumping routines for database 'espprm'
--
/*!50003 DROP PROCEDURE IF EXISTS `as_gettimeclass` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `as_gettimeclass`(v_site VARCHAR(3),
v_date VARCHAR(30),
v_key VARCHAR(8), 
v_type INT 
)
SWL_return:
begin
   DECLARE v_tc INT;
   DECLARE v_found INT;
   DECLARE v_pdate VARCHAR(10);
   DECLARE v_pday INT;  
   DECLARE v_ptime INT;

	
   IF v_type is null then
      set v_type = 3;
   END IF;
   set v_found = 0;
   set v_pdate = convert(v_date,CHAR(10));
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   1, timeclass INTO v_found,v_tc from holiday  where sitecode = v_site and hdate = v_pdate and tclstype = v_type and (tclskey = v_key or tclskey = '*')   order by tclstype,tclskey desc LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

   if v_found = 1 then
	
      select v_tc timeclass;
      LEAVE SWL_return;
   end if;

	
   set v_pday = 1+(DAYOFWEEK(v_date)+v_datefirst -2)%7;  
   set v_ptime = EXTRACT(HOUR FROM v_date)*100+EXTRACT(MINUTE FROM v_date);  
   
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select  a.timeclass from daytime a, daycode b, timecode c 
   where sitecode = v_site and tclstype = v_type and (tclskey = v_key or tclskey = '*')
   and a.daycode = b.daycode and a.timecode = c.timecode
   and v_pday between b.dayfrom and b.dayto
   and ((c.timefrom <= v_ptime and v_ptime < c.timeto) or
  		(c.timeto2 < c.timeto and v_ptime < c.timeto2))
   order by tclstype,tclskey desc LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `as_get_prefix` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `as_get_prefix`(v_sitecode CHAR(8), 
v_dialednum CHAR(30), 
v_prefix_set INT)
begin
  
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select * from prefix 
   where prefixset = v_prefix_set
   and prefixcode between SUBSTR(v_dialednum,1,1) and v_dialednum
   and v_dialednum like CONCAT(prefixcode,'%')  
	  
   order by prefixcode desc LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `as_get_tariffclass` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `as_get_tariffclass`(v_telcocode CHAR(4), 
v_sitecode CHAR(3),
v_trffclass VARCHAR(4))
begin
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select prefixset,minunit,maintunit,maintdelay,cnxcharge,freecnxdelay,
    firstcnx,newdelay,calld,vcalld,ceilingtt,ceilingtt,progcharge,onegocharge,
    historycharge,acchischarge,desthischarge,samphischarge,createdate,maxnbcharge,
    def_routecls,prem_routecls,gradecode,gradeWorst,gradeBest,chgpersec
   from tariffclass 
   where telcocode = v_telcocode
   and sitecode = v_sitecode
   and trffclass = v_trffclass;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `as_restore_TSAN` */;
ALTER DATABASE `espprm` CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `as_restore_TSAN`(v_site VARCHAR(3),      
v_TSAN VARCHAR(30))
begin

      
   DECLARE v_CdPN VARCHAR(30);      
   DECLARE v_CdPN_noa INT;      
   DECLARE v_CgPN VARCHAR(30);      
   DECLARE v_CgPN_noa INT;      
   DECLARE v_RN VARCHAR(30);      
   DECLARE v_RN_noa INT;      
   DECLARE v_OCN VARCHAR(30);      
   DECLARE v_OCN_noa INT;      
   DECLARE v_IMSI VARCHAR(15);      
   DECLARE v_OA VARCHAR(30);      
   DECLARE v_OA_noa INT;      
   DECLARE v_charge INT;      
   DECLARE v_err INT;     
 
      
   set v_err = -1;       
      
      
  
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   -2, CdPN, CdPN_noa, CgPN, CgPN_noa, RN, RN_noa, OCN, OCN_noa, IMSI, OA, OA_noa, charge INTO v_err,v_CdPN,v_CdPN_noa,v_CgPN,v_CgPN_noa,v_RN,v_RN_noa,v_OCN,v_OCN_noa,
   v_IMSI,v_OA,v_OA_noa,v_charge from mvno_tsan  where sitecode = v_site and TSAN = v_TSAN and status <> 0    LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;   
      
   update  mvno_tsan set
   status = 0,v_err = 0,CdPN = null,CdPN_noa = null,CgPN = null,CgPN_noa = null,RN = null, 
   RN_noa = null,OCN = null,OCN_noa = null,IMSI = null,OA = null,OA_noa = null,charge = null,
   entrydate = null
   where sitecode = v_site and TSAN = v_TSAN and status <> 0;     
      
   select v_err err,
  IFNULL(v_CdPN,'') CdPN, IFNULL(v_CdPN_noa,-1) CdPN_noa,
  IFNULL(v_CgPN,'') CgPN, IFNULL(v_CgPN_noa,-1) CgPN_noa,
  IFNULL(v_RN,'') RN, IFNULL(v_RN_noa,-1) RN_noa,
  IFNULL(v_OCN,'') OCN, IFNULL(v_OCN_noa,-1) OCN_noa,
  IFNULL(v_IMSI,'') IMSI,
  IFNULL(v_OA,'') OA, IFNULL(v_OA_noa,-1) OA_noa,
  IFNULL(v_charge,-1) charge;      
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `espprm` CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `BMS_portal_get_tariff_download` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `BMS_portal_get_tariff_download`(sitecode VARCHAR(3),
  tariff VARCHAR(4),
  accesscharge INT)
BEGIN
 
     SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
     select destcode,charge,timeperiod,cnxdelay,cnxunit/100 as cnxprice,sampdelay,
  	sampunit/100  pricemin ,
  	premiumdest,freesec
     from tariff a where telcocode = 'ics' and a.sitecode = sitecode
     and a.trffclass = tariff and a.charge = accesscharge
     ORDER by destcode asc;
     SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `BMS_portal_get_tariff_dtl_by_destcode` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `BMS_portal_get_tariff_dtl_by_destcode`(sitecode VARCHAR(3),
tariff VARCHAR(4),
timeperiod INT,
accesscharge INT,
destcode VARCHAR(250))
BEGIN


	
	
	
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   Select   destcode,trffclass,
	cnxdelay,cnxunit,sampdelay,sampunit,freesec,premiumdest,cfreemin,
	routeclass from  tariff a where a.sitecode = sitecode and telcocode = 'ics'
   and trffclass = tariff
   and charge = accesscharge and timeperiod = timeperiod and
   destcode like CONCAT_WS('',destcode,'%') LIMIT 20;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ; 
	

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `bms_portal_get_tariff_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `bms_portal_get_tariff_info`(sitecode VARCHAR(3),
tariff VARCHAR(4))
BEGIN

	
	
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select b.cardid,b.CardName,b.DefaultTrffclass,a.Currcode,
	case when c.package_id is null then 'Master' else 'Bundle' end  as tariff_type,a.createdate from tariffclass a 
   join cardfamily b  on a.trffclass = b.DefaultTrffclass
   left join esp.packages c on b.DefaultTrffclass = c.tariffclass  where a.sitecode = sitecode
   and trffclass = tariff;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `booth_setbalance` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `booth_setbalance`(ani CHAR(30),did CHAR(6),bal FLOAT)
begin
   update account a set balance = bal where telcocode = 'ICS' and a.ani = ani and a.did = did;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `booth_unblock` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `booth_unblock`(ani CHAR(30),did CHAR(6))
begin
   update account a set status = 1 where telcocode = 'ICS' and a.ani = ani and a.did = did;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `cardfeature_getsetting_callmeback` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `cardfeature_getsetting_callmeback`(cardid INT,
INOUT notiftext VARCHAR(100) ,
INOUT allowedcount INT ,
INOUT delay INT ,
INOUT errcode INT ,
INOUT errmsg VARCHAR(100))
SWL_return:
begin


   DECLARE v_param2 VARCHAR(50);
   DECLARE v_param2_1 VARCHAR(50);
   DECLARE v_param2_2 VARCHAR(50);
   DECLARE Swv_RowCount INT;
	
   set errcode = -1;
   set errmsg = '';

   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select param1, param2 INTO notiftext,v_param2 from  CardFeatures a where a.cardid = cardid and featuretype = 32 and status = 1;
   SET Swv_RowCount = ROW_COUNT();
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   if Swv_RowCount = 0 then
	
      set errmsg = 'Setting not found.';
      LEAVE SWL_return;
   end if;
	
   if v_param2 is not null and v_param2 <> '' then
	
      if LOCATE(':',v_param2) = 0 then
		
         set errmsg = 'Incorrect setting: Param 2';
         LEAVE SWL_return;
      end if;
      set v_param2_1 = SWF_SUBSTRING(v_param2,1,LOCATE(':',v_param2) -1);
      set v_param2_2 = SWF_SUBSTRING(v_param2,LOCATE(':',v_param2)+1, CHAR_LENGTH(v_param2));
      if v_param2_1 <> '' and v_param2_1 REGEXP('^[+-.$.]?[[0-9,]+...]?$') then
         set allowedcount = v_param2_1;
      else
         set errmsg = 'Incorrect setting: Param 2.1';
         LEAVE SWL_return;
      end if;
      if v_param2_2 <> '' and v_param2_2 REGEXP('^[+-.$.]?[[0-9,]+...]?$') then
         set delay = v_param2_2;
      else
         set errmsg = 'Incorrect setting: Param 2.2';
         LEAVE SWL_return;
      end if;
   else
      set errmsg = 'Incorrect setting.';
   end if;
	
   set errcode = 0;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `CardPromo_UpdateCardFeature` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `CardPromo_UpdateCardFeature`(promoid INT,
promoname VARCHAR(30),
cardid INT)
Begin

   update CardFeatures a
   set Param1 = promoid,Comment = promoname
   where a.CardID = cardid and FeatureType = 3; 
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `direct_topup_do_xlat` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `direct_topup_do_xlat`(v_sitecode VARCHAR(3),
v_mobileno VARCHAR(20),
INOUT v_xlat_prefix VARCHAR(20) ,
INOUT v_pref_ln INT ,
INOUT v_errcode INT ,
INOUT v_errmsg VARCHAR(500))
SWL_return:
begin



   DECLARE Swv_RowCount INT;
   set v_errcode = -1;
   set v_errmsg = '';
	
	
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   xlat_prefix,  CHAR_LENGTH(prefix) INTO v_xlat_prefix,v_pref_ln from xlat_tp_rms  where sitecode = v_sitecode
   and SWF_SUBSTRING(v_mobileno,1, CHAR_LENGTH(prefix)) = prefix   order by  CHAR_LENGTH(prefix) desc LIMIT 1;
   SET Swv_RowCount = ROW_COUNT();
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   if Swv_RowCount = 0 then
	
      set v_errmsg = 'No xlat found.';
      LEAVE SWL_return;
   end if;
	
   set v_errcode = 0;
   set v_errmsg = 'Success';
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es1_account_clisc` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `es1_account_clisc`(v_telcocode CHAR(4), v_ani CHAR(30), v_did CHAR(6), v_pincode CHAR(12))
begin
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select * from account 
   where telcocode = v_telcocode
   and ani = v_ani
   and did = v_did
   and pincode = v_pincode;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es1_AllocBatchBal` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `es1_AllocBatchBal`(v_telcocode CHAR(4), v_custcode CHAR(8),v_batchcode INT)
begin
   update batch
   set totalalloc = totalalloc+maxalloc
   where telcocode = v_telcocode
   and custcode = v_custcode
   and batchcode = v_batchcode
   and totalalloc+maxalloc <= balance;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es1_anigroup` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `es1_anigroup`(v_sitecode CHAR(3),
v_cli CHAR(30), 
v_group INT)
begin
   if v_cli is null or  CHAR_LENGTH(v_cli) = 0 or v_cli = '' then
	
      set v_cli = 'blank';
   end if;
	
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select * from anigroup 
   where sitecode = v_sitecode
   and groupno = v_group
   and left(v_cli, CHAR_LENGTH(ani)) = ani
   order by ani desc LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es1_anigroup_test` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `es1_anigroup_test`(v_sitecode CHAR(3), v_cli CHAR(30), v_group INT)
begin
  
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select * from  anigroup 
   where sitecode = v_sitecode
   and groupno = v_group
   and left(v_cli, CHAR_LENGTH(ani)) = ani
   order by ani desc LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es1_CheckAccountBal` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `es1_CheckAccountBal`(v_telcocode CHAR(4), v_custcode CHAR(8), v_batchcode INT, 
	v_serialcode INT, v_balAlloc REAL)
begin
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select balance total
   from account 
   where telcocode = v_telcocode
   and custcode = v_custcode
   and batchcode = v_batchcode
   and serialcode = v_serialcode
   and balance >= v_balAlloc;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es1_CheckBatchBal` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `es1_CheckBatchBal`(v_telcocode CHAR(4), v_custcode CHAR(8), v_batchcode INT, v_balAlloc REAL)
begin

   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select balance total
   from batch 
   where telcocode = v_telcocode
   and custcode = v_custcode
   and batchcode = v_batchcode
   and balance >= v_balAlloc;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es1_check_ani` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `es1_check_ani`(v_psitecode VARCHAR(3),
v_ptrunkcode VARCHAR(20),
v_pcli VARCHAR(20))
begin

   select * from  aniprefix
   where sitecode = v_psitecode
   and (trunkcode = v_ptrunkcode or trunkcode = '*')
   and v_pcli like CONCAT(prefix,'%')
   order by trunkcode desc, CHAR_LENGTH(prefix) desc LIMIT 1;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es1_cliacc_recredit` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `es1_cliacc_recredit`(v_telcocode CHAR(4), v_custcode CHAR(8),v_batchcode INT,v_serialcode INT, v_credit REAL)
BEGIN
   DECLARE v_balance FLOAT;
	
   update account
   set v_balance = balance+v_credit
   where telcocode = v_telcocode
   and custcode = v_custcode
   and batchcode = v_batchcode
   and serialcode = v_serialcode;
	
   select v_balance balance;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es1_del_SD` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `es1_del_SD`(telcocode CHAR(4), custcode CHAR(8),batchcode INT,serialcode INT, sdnum INT)
begin

   delete FROM speeddial a
   where a.telcocode = telcocode
   and a.custcode = custcode
   and a.batchcode = batchcode
   and a.serialcode = serialcode
   and a.sdnum = sdnum;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es1_get_alttariffclass` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `es1_get_alttariffclass`(telcocode CHAR(4),   
sitecode CHAR(3),  
trffclass VARCHAR(4))
begin    
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select  altprog_flag,altprog_intrvl,altmaint_flag,altmaint_intrvl,altmaintdelay,altmaintunit,altmaxnbcharge,
		altsamp_flag,altsamp_intrvl,altsamp_mfactor,createdate
   from alt_tariffclass a
   where a.telcocode = telcocode and a.sitecode = sitecode and a.trffclass = trffclass LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es1_get_bal_batch` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `es1_get_bal_batch`(v_telcocode CHAR(4), v_custcode CHAR(8),v_batchcode INT)
begin
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select sum(balance) total
   from account 
   where telcocode = v_telcocode
   and custcode = v_custcode
   and batchcode = v_batchcode;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es1_get_clicat` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `es1_get_clicat`(sitecode VARCHAR(3),
trunkin VARCHAR(15),
cli VARCHAR(16))
begin
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select 
   clicode,category,charge,surcharge,type from
    cli_category a
   where a.sitecode = sitecode
   and a.trunkin = trunkin
   and (left(cli, CHAR_LENGTH(clicode)) = clicode  or
   clicode = '*')
   order by clicode desc LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es1_get_costBmargin_bydest` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `es1_get_costBmargin_bydest`(cardid INT,
destcode VARCHAR(32))
begin

   select * from costb_margin a
   where (a.cardid = cardid or cardid = 0)
   and a.destcode = destcode
   order by cardid desc LIMIT 1;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es1_get_premiumnb` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `es1_get_premiumnb`(nb VARCHAR(20))
begin
 
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select  a.phonenb from premiumnb a 
    where a.phonenb = nb LIMIT 1;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es1_get_progsampl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `es1_get_progsampl`(telcocode VARCHAR(4),
 sitecode VARCHAR(3),
 tclass VARCHAR(8),
 dest  VARCHAR(200),
 charge   INT,
 period INT,
 talktime INT)
begin
    select * from  progsampling a
    where a.sitecode = sitecode
    and a.telcocode = telcocode
    and trffclass = tclass
    and (a.destcode  = dest or destcode = '*')
    and a.charge    = charge
    and (a.timeperiod = period or timeperiod = 1)
    and (talktime between minsec and maxsec)
    order by timeperiod desc,destcode desc LIMIT 1;
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es1_get_SD` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `es1_get_SD`(telcocode CHAR(4),custcode CHAR(8),batchcode INT,serialcode INT, sdnum INT)
begin

   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select * from speeddial a
   where a.telcocode = telcocode
   and a.custcode =custcode
   and a.batchcode = batchcode
   and a.serialcode = serialcode
   and a.sdnum = sdnum;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es1_get_tariffclass` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `es1_get_tariffclass`(telcocode CHAR(4),       
 sitecode CHAR(3),      
 trffclass VARCHAR(4))
begin
 
 
         
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select prefixset,cast(minunit as float) minunit,maintunit,maintdelay,cnxcharge,freecnxdelay,
     firstcnx,newdelay,calld,vcalld,ceilingtt,ceilingtt,progcharge,onegocharge,
     historycharge,acchischarge,desthischarge,samphischarge,createdate,maxnbcharge,
     def_routecls,prem_routecls,gradecode,gradeWorst,gradeBest,chgpersec,roam_surcharge,xlatset
    from tariffclass a
    where a.telcocode = telcocode
    and a.sitecode = sitecode
    and a.trffclass = trffclass;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;        
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es1_max_cnxunit` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `es1_max_cnxunit`(v_trffclass CHAR(4))
begin
   select * from progcharge
   where trffclass = v_trffclass
   order by ccfactor desc;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es1_max_sampunit` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `es1_max_sampunit`(telcocode VARCHAR(4),
sitecode VARCHAR(3),
tclass VARCHAR(8),
dest  VARCHAR(20),
charge   INT,
period INT)
begin

   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select * from  progsampling a
   where a.sitecode = sitecode
   and a.telcocode = telcocode
   and trffclass = tclass
   and (a.destcode  = dest or destcode = '*')
   and a.charge     = charge
   and (a.timeperiod = period or timeperiod = 1)
   order by timeperiod desc,destcode desc,maxsec;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ; 
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es1_prog_charge` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `es1_prog_charge`(v_trffclass CHAR(4), v_talktime INT)
begin
   select * from progcharge
   where trffclass = v_trffclass
   and (v_talktime between minsec and maxsec)
   order by ccfactor desc;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es1_store_SD` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `es1_store_SD`(telcocode CHAR(4), custcode CHAR(8),batchcode INT,serialcode INT,sdnum INT, phnumber VARCHAR(30))
begin

   delete FROM speeddial a
   where a.telcocode = telcocode
   and a.custcode = custcode
   and a.batchcode = batchcode
   and a.serialcode = serialcode
   and a.sdnum =sdnum;
     
   insert into speeddial(telcocode, custcode, batchcode, serialcode, sdnum, phnumber)
     values(telcocode, custcode, batchcode, serialcode,sdnum, phnumber);
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es1_UpdateBatchBal` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `es1_UpdateBatchBal`(v_telcocode CHAR(4), v_custcode CHAR(8),v_batchcode INT, v_talkcharge FLOAT, v_balalloc FLOAT)
begin
   update batch
   set balance = balance -v_talkcharge,totalalloc = totalalloc -v_balalloc,
   totalcons = totalcons+v_talkcharge
   where telcocode = v_telcocode
   and custcode = v_custcode
   and batchcode = v_batchcode;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es2_account_by_cbs` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `es2_account_by_cbs`(telcocode CHAR(4), custcode CHAR(8),batchcode INT,serialcode INT)
begin  
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select * from account a
   where a.telcocode = telcocode
   and a.custcode = custcode
   and a.batchcode = batchcode
   and a.serialcode = serialcode;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es2_account_by_pin` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `es2_account_by_pin`(telcocode CHAR(4),langcode CHAR(8),pincode CHAR(12))
begin
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select * from account a
   where a.telcocode = telcocode
   and a.langcode =langcode
   and a.pincode =pincode;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es2_account_by_telco_pin` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `es2_account_by_telco_pin`(v_telcocode CHAR(4),v_pincode CHAR(12))
begin
   DECLARE v_n INT;
	
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   count(*) INTO v_n from account  where telcocode = v_telcocode and pincode = v_pincode;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
	
   if v_n > 1 then
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select   count(*) INTO v_n from account_dublong  where telcocode = v_telcocode and pincode = v_pincode;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
		
      if v_n = 0 then
         SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
         insert into account_dublong
         select * from account 
         where telcocode = v_telcocode and pincode = v_pincode;
         SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
      end if;
   end if;
	
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select * from account 
   where telcocode = v_telcocode and pincode = v_pincode LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es2_checklock` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `es2_checklock`(v_telcocode CHAR(4),v_custcode CHAR(8),v_batchcode INT,v_serialcode INT)
begin
   select * from acclock
   where telcocode = v_telcocode
   and custcode = v_custcode
   and batchcode = v_batchcode
   and serialcode = v_serialcode;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es2_debit_balance` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `es2_debit_balance`(v_telcocode CHAR(4), v_custcode CHAR(8),v_batchcode INT,v_serialcode INT, v_talkcharge FLOAT)
begin
   update account SET balance = balance -v_talkcharge,totalcons = totalcons+v_talkcharge
   where telcocode = v_telcocode
   and custcode = v_custcode
   and batchcode = v_batchcode
   and serialcode = v_serialcode;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es2_droplock` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `es2_droplock`(v_telcocode CHAR(4),v_custcode CHAR(8),v_batchcode INT,v_serialcode INT)
begin

   delete FROM acclock
   where telcocode = v_telcocode
   and custcode = v_custcode
   and batchcode = v_batchcode
   and serialcode = v_serialcode;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es2_droplock_org` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `es2_droplock_org`(v_telcocode CHAR(4),v_custcode CHAR(8),v_batchcode INT,v_serialcode INT)
begin
   delete FROM acclock
   where telcocode = v_telcocode
   and custcode = v_custcode
   and batchcode = v_batchcode
   and serialcode = v_serialcode;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es2_firstusg` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `es2_firstusg`(v_now DATETIME(3), v_telcocode CHAR(4), v_custcode CHAR(8),
	v_batchcode INT,v_serialcode INT)
begin
   update account
   set firstusg = v_now
   where telcocode = v_telcocode
   and custcode = v_custcode
   and batchcode = v_batchcode
   and serialcode = v_serialcode;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es2_gettimeclass` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `es2_gettimeclass`(site VARCHAR(3),
 date DATETIME(3),
 type INT,
 `key` VARCHAR(8))
SWL_return:
 begin
    DECLARE v_tc INT;
    DECLARE v_found INT;
    DECLARE v_pdate VARCHAR(10);
    DECLARE v_pday INT;  
    DECLARE v_ptime INT;
    DECLARE datefirst DATETIME(3);
    
 	
    set v_found = 0;
    set v_pdate = DATE_FORMAT(date,'%Y-%m-%d');
    
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    SELECT 1,timeclass INTO v_found,v_tc from holiday where sitecode = site and hdate =v_pdate and tclstype =type and (tclskey=`key`  or tclskey = '*') order by tclstype,tclskey desc LIMIT 1;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 
    if v_found = 1 then
 	
       select v_tc timeclass;
       LEAVE SWL_return;
    end if;
 
 	
    
    set v_pday = 1+(DAYOFWEEK(date)+7 -2)%7;  
    set v_ptime = EXTRACT(HOUR FROM date)*100+EXTRACT(MINUTE FROM date);  
    
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select  a.timeclass from daytime a, daycode b, timecode c 
    where sitecode = site and tclstype = type and (tclskey = `key` or tclskey = '*')
    and a.daycode = b.daycode and a.timecode = c.timecode
    and v_pday between b.dayfrom and b.dayto
    and ((c.timefrom <= v_ptime and v_ptime < c.timeto) or
   		(c.timeto2 < c.timeto and v_ptime < c.timeto2))
    order by tclstype,tclskey desc LIMIT 1;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
 
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es2_get_ani` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `es2_get_ani`(sitecode CHAR(3),did CHAR(30),cli CHAR(30))
begin
 
    select * from ani a
    where a.sitecode = sitecode
    and a.did = did
    and cli like CONCAT(aniprefix,'%');
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es2_get_bal_batch` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `es2_get_bal_batch`(v_telcocode CHAR(4), v_custcode CHAR(8), v_batchcode INT)
begin
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select balance
   from batch 
   where telcocode = v_telcocode
   and custcode = v_custcode
   and batchcode = v_batchcode;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es2_get_batch` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `es2_get_batch`(v_telcocode CHAR(4), v_custcode CHAR(8),v_batchcode INT)
begin
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select * from batch 
   where telcocode = v_telcocode
   and custcode = v_custcode
   and batchcode = v_batchcode;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es2_get_packcnxcharge` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `es2_get_packcnxcharge`(v_trffclass VARCHAR(4),
v_charge INT,
v_timeprd INT,
v_destcode VARCHAR(64),
v_master_trffclass VARCHAR(4))
begin

 
	
	
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select * from pack_cnxcharge
   where (trffclass = v_trffclass or trffclass = '*')
   and (charge = v_charge or charge = -1)
   and (timeperiod = v_timeprd or timeperiod = 1)
   and (destcode = v_destcode or destcode = '*')
   and (IFNULL(master_trffclass,'*') = v_master_trffclass or IFNULL(master_trffclass,'*') = '*')
   order by trffclass desc,charge desc,timeperiod desc,destcode desc,master_trffclass desc LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es2_get_prefix` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `es2_get_prefix`(v_sitecode CHAR(3), v_dialednum CHAR(30))
begin
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select * from prefix 
   where sitecode = v_sitecode
   and v_dialednum like CONCAT(prefixcode,'%')
   order by prefixcode desc;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es2_get_tariff` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `es2_get_tariff`(telcocode VARCHAR(4),       
sitecode VARCHAR(3),      
destcode VARCHAR(60),      
trffclass VARCHAR(4),      
charge INT,      
timeperiod INT,      
routeclass INT)
begin
      
   IF routeclass is null then
      set routeclass = 0;
   END IF;
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select * from tariff a
   where a.telcocode = telcocode
   and a.sitecode = sitecode
   and a.destcode = destcode
   and a.trffclass = trffclass
   and a.charge = charge
   and a.timeperiod = timeperiod
   and a.routeclass = routeclass
   union
   select * from tariff a
   where a.telcocode = telcocode
   and a.sitecode = sitecode
   and a.destcode = destcode
   and a.trffclass = trffclass
   and a.charge = charge
   and a.timeperiod = 1
   and a.routeclass = routeclass
   order by  1 desc;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;      
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es2_get_tariff_by_balance` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `es2_get_tariff_by_balance`(v_telcocode VARCHAR(3),
v_sitecode VARCHAR(3),
v_trffclass VARCHAR(4),
v_percent_balance REAL)
begin
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select * from tariff_by_balance 
   where telcocode = v_telcocode and sitecode = v_sitecode and trffclass = v_trffclass
   and (v_percent_balance between percent_balfrom and percent_balto)
   order by percent_balfrom desc LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es2_max_cnxunit` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `es2_max_cnxunit`(v_trffclass CHAR(4), v_destcode CHAR(15))
begin
   select * from progcharge1
   where trffclass = v_trffclass
   and (destcode = v_destcode or destcode = '')
   order by ccfactor desc;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es2_prog_charge` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `es2_prog_charge`(trffclass CHAR(4), talktime INT,destcode CHAR(15))
begin
   select * from progcharge1 a
   where a.trffclass = trffclass
   and (a.destcode =destcode or destcode = '')
   and (talktime between minsec and maxsec)
   order by destcode desc LIMIT 1;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es2_UniCheckAccount` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `es2_UniCheckAccount`(v_telcocode CHAR(4),v_pincode CHAR(12))
begin
   select pincode
   from account
   where telcocode = v_telcocode and pincode = v_pincode;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es2_UpSharedAccountBal` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `es2_UpSharedAccountBal`(v_telcocode CHAR(4), v_custcode CHAR(8),v_batchcode INT, 
	v_serialcode INT, v_talkcharge FLOAT)
begin

   update account
   set balance = balance -v_talkcharge,totalcons = totalcons+v_talkcharge
   where telcocode = v_telcocode
   and custcode = v_custcode
   and batchcode = v_batchcode
   and serialcode = v_serialcode;
	
   select totalcons
   from account
   where telcocode = v_telcocode
   and custcode = v_custcode
   and batchcode = v_batchcode
   and serialcode = v_serialcode;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es3_get_prefix` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `es3_get_prefix`(sitecode CHAR(3), 
  dialednum CHAR(30), 
  prefix_set INT)
begin
  	
     SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
     select * from prefix a
     where a.sitecode = sitecode
     and a.prefixset = prefix_set
     and dialednum like CONCAT(a.prefixcode,'%')
     order by a.prefixcode desc LIMIT 1;
     SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
  	
  end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es3_get_route` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `es3_get_route`(sitecode CHAR(3),routeclass CHAR(6),destcode CHAR(15),switchcode CHAR(3))
begin

   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select * from route a
   where a.sitecode = sitecode
   and a.routeclass = routeclass
   and a.destcode in(destcode,'')
   and (a.switchcode =switchcode or switchcode = 'ALL')
   order by switchcode,destcode desc,priority LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es3_max_cnxunit` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `es3_max_cnxunit`(v_trffclass CHAR(4), v_destcode CHAR(15),v_charge INT)
begin
   select * from progcharge1
   where trffclass = v_trffclass
   and (destcode = v_destcode or destcode = '')
   and (charge = v_charge or charge = 0)
   order by ccfactor asc;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es3_prog_charge` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `es3_prog_charge`(v_trffclass CHAR(4), v_talktime INT, v_destcode CHAR(15),v_charge INT)
begin

   select * from progcharge1
   where trffclass = v_trffclass
   and (destcode = v_destcode or destcode = '')
   and (charge = v_charge or charge = 0)
   and (v_talktime between minsec and maxsec)
   order by destcode desc LIMIT 1;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es4_max_cnxunit` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `es4_max_cnxunit`(v_trffclass CHAR(4),
v_destcode CHAR(32),
v_charge INT,
v_timeperiod INT)
begin
   select * from progcharge1
   where trffclass = v_trffclass
   and (destcode = v_destcode or destcode = '*')
   and (charge = v_charge or charge = 0)
   and (timeperiod = v_timeperiod or timeperiod = 1)
   order by destcode desc,charge desc,timeperiod desc,maxsec;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es4_prog_charge` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `es4_prog_charge`(v_trffclass CHAR(4),
v_talktime INT,
v_destcode CHAR(32),
v_charge INT,
v_timeperiod INT)
begin
   select * from progcharge1
   where trffclass = v_trffclass
   and (destcode = v_destcode or destcode = '*')
   and (charge = v_charge or charge = 0)
   and (timeperiod = v_timeperiod or timeperiod = 1)
   and (v_talktime between minsec and maxsec)
   order by destcode desc,charge desc,timeperiod desc LIMIT 1;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es4_UpSharedBatchBal` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `es4_UpSharedBatchBal`(v_telcocode CHAR(4), v_custcode CHAR(8),v_batchcode INT, v_talkcharge FLOAT)
begin
   update batch
   set balance = balance -v_talkcharge,totalcons = totalcons+v_talkcharge
   where telcocode = v_telcocode
   and custcode = v_custcode
   and batchcode = v_batchcode;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es5_GetDefaultDbByDid` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `es5_GetDefaultDbByDid`(did VARCHAR(6),
trunkcode VARCHAR(10))
begin
   select * from dbdefault1 a
   where (a.did = did or did = '*')
   and (a.trunkcode = trunkcode or trunkcode = '*')
   order by did desc,trunkcode desc LIMIT 1;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es5_get_access` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `es5_get_access`(sitecode CHAR(3),  
  did CHAR(55),  
  trunkcode CHAR(16))
begin
     SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
     select * from access a
     where a.sitecode = sitecode
     and a.did in('*',did,right(did,6),CONCAT(left(did, CHAR_LENGTH(a.did) -1),'*'))
     and a.trunkcode = trunkcode
     order by a.did desc, CHAR_LENGTH(a.did) desc;
     SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;      
  end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es5_get_xlat` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `es5_get_xlat`(sitecode CHAR(8),    
prefix CHAR(30),    
trunkcode CHAR(8),    
direction INT,    
switchcode CHAR(3),    
nbtype INT ,
xlatset INT)
begin


	
	

   IF nbtype is null then
      set nbtype = -1;
   END IF;
   if xlatset = 0 then
	
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select * from  xlat a
      where a.sitecode = sitecode
      and (switchcode = switchcode or switchcode = '*')          
	    
      and prefix like CONCAT(prefix,'%')
      and (trunkcode = trunkcode  or trunkcode = '*')
      and direction = direction
      and (numbertype = nbtype or nbtype = -1 or numbertype is null or numbertype = -1)
      order by switchcode desc,pfxlen desc,trunkcode desc,numbertype desc LIMIT 1;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   else
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select * from xlat_byset b
      where b.sitecode = sitecode
      and (switchcode = switchcode or switchcode = '*')          
	    
      and prefix like CONCAT(prefix,'%')
      and (trunkcode = trunkcode  or trunkcode = '*')
      and direction = direction
      and (numbertype = nbtype or nbtype = -1 or numbertype is null or numbertype = -1)
      and xlatset = xlatset
      and (nblen = 0 or  CHAR_LENGTH(prefix) = nblen)
      order by switchcode desc, CHAR_LENGTH(prefix) desc,trunkcode desc,numbertype desc, 
      nblen desc LIMIT 1;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   end if;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es5_UpSharedBatchBal` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `es5_UpSharedBatchBal`(v_telcocode CHAR(4), v_custcode CHAR(8),v_batchcode INT, 
v_talkcharge FLOAT)
begin

   START TRANSACTION;

   update batch
   set balance = balance -v_talkcharge,totalcons = totalcons+v_talkcharge
   where telcocode = v_telcocode
   and custcode = v_custcode
   and batchcode = v_batchcode;

   select balance
   from batch
   where telcocode = v_telcocode
   and custcode = v_custcode
   and batchcode = v_batchcode;

   COMMIT;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es6_get_xlat` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `es6_get_xlat`(sitecode CHAR(8),    
 prefix CHAR(30),    
 trunkcode CHAR(8),    
 direction INT,    
 switchcode CHAR(3),    
 nbtype INT ,
 xlatset INT,
 did_prefix VARCHAR(20),
 charge INT,
 cli VARCHAR(20))
begin
 
 	
    DECLARE v_ivr_extnsion VARCHAR(50); 
    DECLARE v_normal_extension INT; 
 
    IF nbtype is null then
       set nbtype = -1;
    END IF;
    IF did_prefix is null then
       set did_prefix = '';
    END IF;
    IF charge is null then
       set charge = 0;
    END IF;
    IF cli is null then
       set cli = '';
    END IF;
    if xlatset = 0 then
 	
       SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
       select * from xlat a
       where a.sitecode = sitecode
       and (a.switchcode = switchcode or a.switchcode = '*')          
 	    
       and prefix like CONCAT(a.prefix,'%')
       and (a.trunkcode = trunkcode  or a.trunkcode = '*')
       and a.direction = direction
       and (a.numbertype = nbtype or nbtype = -1 or a.numbertype is null or a.numbertype = -1)
       order by a.switchcode desc,a.pfxlen desc,a.trunkcode desc,a.numbertype desc LIMIT 1;
       SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
    else
       IF trunkcode = 'pbizzmob' and cli REGEXP('^[+-.$.]?[[0-9,]+...]?$') AND cli between 3000 AND 3500 then
 		
 			
 			
 			
 			
 			
 			
          if left(did_prefix,2) = '00' or left(did_prefix,2) = '01' then
 			
             set did_prefix = insert(replace(did_prefix,'*',''),1,2,'');
          end if;
          IF CHAR_LENGTH(RTRIM(did_prefix)) = 4 then
 			
             SET v_ivr_extnsion = SUBSTR(prefix,7,4);
          end if;
          IF CHAR_LENGTH(RTRIM(did_prefix)) = 5 then
 			
             SET v_ivr_extnsion = SUBSTR(prefix,8,4);
          end if;
          if v_ivr_extnsion REGEXP('^[+-.$.]?[[0-9,]+...]?$') and v_ivr_extnsion between 3000 and 3500 then
             set trunkcode = 'pbxivr';
          end if;
       end if;
 		
 		
       IF IFNULL(charge,0) = 78 then
 		
          if left(did_prefix,2) = '00' or left(did_prefix,2) = '01' then
 			
             set did_prefix = insert(replace(did_prefix,'*',''),1,2,'');
          end if;
          if CHAR_LENGTH(RTRIM(did_prefix)) = 5 then
             set xlatset = 6;
          end if;
       end if;
       SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
       select * from xlat_byset b
       where b.sitecode = sitecode
       and (b.switchcode = switchcode or b.switchcode = '*')          
 	    
       and prefix like CONCAT(b.prefix,'%')
       and (b.trunkcode = trunkcode  or b.trunkcode = '*')
       and b.direction = direction
       and (b.numbertype = nbtype or nbtype = -1 or b.numbertype is null or b.numbertype = -1)
       and b.xlatset = xlatset
       and (b.nblen = 0 or CHAR_LENGTH(RTRIM(prefix)) = b.nblen)
       order by b.switchcode desc,CHAR_LENGTH(RTRIM(b.prefix)) desc,b.trunkcode desc,b.numbertype desc, 
       nblen desc LIMIT 1;
       SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
    end if;
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es6_UpSharedBatchBal` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `es6_UpSharedBatchBal`(v_telcocode CHAR(4), v_custcode CHAR(8),v_batchcode INT, 
v_talkcharge FLOAT)
begin

   DECLARE v_stat INT;

   START TRANSACTION;

   update batch
   set balance = balance -v_talkcharge,totalcons = totalcons+v_talkcharge
   where telcocode = v_telcocode
   and custcode = v_custcode
   and batchcode = v_batchcode;

   set v_stat = ROW_COUNT();

   if v_stat > 0 then
	
      select balance , totalcons, v_stat stat
      from batch
      where telcocode = v_telcocode
      and custcode = v_custcode
      and batchcode = v_batchcode;
   else
      select 0,0,v_stat stat;
   end if;

   COMMIT;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es7_UpSharedBatchBal` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `es7_UpSharedBatchBal`(v_telcocode CHAR(4), v_custcode CHAR(8),v_batchcode INT, v_talkcharge FLOAT)
begin

   DECLARE v_balance FLOAT;
   DECLARE v_totalcons FLOAT;

   update batch
   set v_balance = balance -v_talkcharge,v_totalcons = totalcons+v_talkcharge
   where telcocode = v_telcocode
   and custcode = v_custcode
   and batchcode = v_batchcode;
	
   select v_balance balance , v_totalcons totalcons; 
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `esmgtV20_getCardTrfClass` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `esmgtV20_getCardTrfClass`(v_cardId  INT

)
begin
   select upper(A.trffclass) TariffClass,
     DATE_FORMAT(B.CreateDate,'%Y-%m-%d %T') CreateDate,
     DATE_FORMAT(B.ModDate,'%Y-%m-%d %T') ModifyDate  from cardTariffClass A join  tariffclass B
   on A.sitecode = B.sitecode and A.trffclass = B.trffclass  where cardId = v_cardId  order by moddate desc;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `espmgt_destcodegroup_create` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `espmgt_destcodegroup_create`(v_groupname VARCHAR(100),  
 v_updatedby VARCHAR(100))
SWL_return:
BEGIN

   DECLARE v_errcode INT;    
   DECLARE v_errmsg VARCHAR(255);
   DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
   BEGIN
      SET @SWV_Error = 1;
   END;      
    
   SET @SWV_Error = 0;
   set v_errcode = 0;    
   set v_errmsg = 'Success';      
    
 
   if  exists(select 1 from espmgt_destcodegroup   where groupname = v_groupname) then
  
      set v_errcode = -1;
      set v_errmsg = CONCAT_WS('',v_groupname,' already exist.');
      select v_errcode errcode,v_errmsg errmsg;
      LEAVE SWL_return;
   end if;  
  
   SET @SWV_Error = 0;
   INSERT INTO espmgt_destcodegroup(groupname,updatedby,dtUpdate)
 VALUES(v_groupname, v_updatedby,CURRENT_TIMESTAMP);    
      
 
   if @SWV_Error <> 0 then
 
      set v_errmsg = 'Failed to CREATE group.';
      set v_errcode = -1;
   end if;    
   select v_errcode errcode,v_errmsg errmsg;    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `espmgt_destcodegroup_edit` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `espmgt_destcodegroup_edit`(v_groupid INT,
 v_groupname  VARCHAR(100),  
 v_updatedby  VARCHAR(100))
BEGIN
   DECLARE v_errcode INT;  
   DECLARE v_errmsg VARCHAR(255);
   DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
   BEGIN
      SET @SWV_Error = 1;
   END;    
  
   SET @SWV_Error = 0;
   set v_errcode = 0;  
   set v_errmsg = '';    
  
   SET @SWV_Error = 0;
   UPDATE espmgt_destcodegroup
   set groupname = v_groupname,updatedby = v_updatedby,dtUpdate = CURRENT_TIMESTAMP  
    
   WHERE groupid = v_groupid;  
  
   if @SWV_Error <> 0 then
 
      set v_errmsg = 'Failed to UPDATE group.';
      set v_errcode = -1;
   end if;  
   select v_errcode errcode,v_errmsg errmsg;  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `espmgt_destcodegroup_list` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `espmgt_destcodegroup_list`(v_groupid INT)
BEGIN
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   SELECT groupid, groupname, updatedby, dtUpdate FROM espmgt_destcodegroup 
   order by groupname;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `espmgt_getdescfromtariff` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `espmgt_getdescfromtariff`(v_sitecode VARCHAR(3),  
v_siteowner INT,         
v_trffclass VARCHAR(4),   
v_timeperiod INT,          
v_charge INT, 
v_cnxdelay INT,
v_sampMinute FLOAT,
v_cnxMinute FLOAT, 
v_sampdelay INT)
begin
   DECLARE v_linksrv VARCHAR(50);  
   DECLARE v_prmdb VARCHAR(50);  
   DECLARE v_newsampunit FLOAT;          
   DECLARE v_newcnxunit FLOAT;

   IF v_siteowner is null then
      set v_siteowner = 0;
   END IF;
   set  v_newsampunit =(v_sampMinute*100)*(v_sampdelay/60.0);          
   set  v_newcnxunit =(v_newsampunit*v_cnxMinute)*60/(v_sampdelay);  

   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select distinct destcode from tariff  
   where  telcocode = 'ICS' and  sitecode = v_sitecode  and trffclass = v_trffclass and
   charge = v_charge and
   timeperiod = v_timeperiod  and
   cnxdelay = v_cnxdelay  and
   cnxunit = v_newcnxunit  and
   sampdelay = v_sampdelay  and
   sampunit = v_newsampunit;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `espmgt_SetPromotion` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `espmgt_SetPromotion`(v_cardid INT,
v_promoname VARCHAR(30),
v_sitecode VARCHAR(10),
v_trffclass VARCHAR(10),
v_accesstype VARCHAR(100),
v_duration INT,
v_iparam INT,
v_user VARCHAR(30),
v_promotype INT,
v_minbal INT,
v_dest VARCHAR(4000))
Begin
   DECLARE v_strquery VARCHAR(4000);
   DECLARE v_a INT;  
   DECLARE v_p INT;    
   DECLARE v_actype VARCHAR(30);
   DECLARE v_destcode VARCHAR(30);
   DECLARE v_enddate DATETIME(3);
   DECLARE v_startdate DATETIME(3);
   DECLARE v_promoid INT;
   DECLARE v_idpromo INT;
	
   set v_startdate = CURRENT_TIMESTAMP;
   set v_enddate = TIMESTAMPADD(month,v_duration,CURRENT_TIMESTAMP);	
   select   max(promoid) INTO v_idpromo from  promotion;
   set v_promoid = v_idpromo+1;
	
   set v_p = 1;  
   set v_a = LOCATE(',',v_accesstype,v_p);  
   while v_a > 0 DO
      set v_actype = SWF_SUBSTRING(v_accesstype,v_p,v_a -v_p);  

    		
      
		
		
		
		
		
		
		
		insert into promotion
		 values(v_promoid,v_promoname,v_sitecode,'',v_actype,v_startdate,v_enddate,v_iparam,0,v_user,'',v_promotype,v_minbal);
      set v_p = v_a+1;
      set v_a = LOCATE(',',v_accesstype,v_p);
   END WHILE;  
	
   if v_dest = '*,' then
      set v_destcode = '*';
      insert into promotion_dest(promoid,destcode)
	 	values(v_promoid,v_destcode);
   else
      set v_p = 1;
      set v_a = LOCATE(',',v_dest,v_p);
      while v_a > 0 DO
         set v_destcode = SWF_SUBSTRING(v_dest,v_p,v_a -v_p);
         insert into promotion_dest(promoid,destcode)
	    		values(v_promoid,v_destcode);
    			
         set v_p = v_a+1;
         set v_a = LOCATE(',',v_dest,v_p);
      END WHILE;
   end if;
	
	
   update CardFeatures
   set Param1 = v_promoid,comment = v_promoname
   where CardID = v_cardid and FeatureType = 3;

	
   insert into CardPromoHistory
	 values(v_promoid,v_cardid,v_user,CURRENT_TIMESTAMP);

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `espmgt_UpdateTariff` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `espmgt_UpdateTariff`(v_site VARCHAR(10),  
v_trfclass VARCHAR(10),  
v_destcode VARCHAR(64),  
v_charge INT,  
v_tmprd INT,  
v_cnxunit FLOAT,  
v_sampunit FLOAT,  
v_sampdelay INT,  
v_freesec INT,  
v_premdest INT)
begin
   update tariff
   set cnxunit = v_cnxunit,sampunit = v_sampunit,sampdelay = v_sampdelay,freesec = v_freesec,
   premiumdest = v_premdest
   where telcocode = 'ics' and sitecode = v_site
   and destcode = v_destcode and trffclass = v_trfclass
   and charge = v_charge and timeperiod = v_tmprd;  
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `espmgt_UpdateTariffV2` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `espmgt_UpdateTariffV2`(v_site VARCHAR(10),  
v_trfclass VARCHAR(10),  
v_destcode VARCHAR(64),  
v_charge INT,  
v_tmprd INT,  
v_cnxunit FLOAT,  
v_sampunit FLOAT,  
v_sampdelay INT,  
v_freesec INT,  
v_premdest INT,
v_cnxdelay INT  
)
begin
   update tariff
   set cnxunit = v_cnxunit,sampunit = v_sampunit,sampdelay = v_sampdelay,freesec = v_freesec,
   premiumdest = v_premdest,cnxdelay = v_cnxdelay
   where telcocode = 'ics' and sitecode = v_site
   and destcode = v_destcode and trffclass = v_trfclass
   and charge = v_charge and timeperiod = v_tmprd;  
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `esp_checkroaming_dest` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `esp_checkroaming_dest`(sitecode VARCHAR(3),      
 destcode VARCHAR(32),    
 xlatednb VARCHAR(30))
begin
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select  sitecode,destcode,status
  ,case when normalnbpfx = '' or normalnbpfx is null then SUBSTRING(xlatednb, CHAR_LENGTH(xlatedpfx) - CHAR_LENGTH(normalnbpfx)+1, CHAR_LENGTH(xlatednb))
    else CONCAT(normalnbpfx,SUBSTRING(xlatednb, CHAR_LENGTH(a.xlatedpfx)+1, CHAR_LENGTH(xlatednb))) end mobileno
    from roamcheckdest a
    where a.sitecode = sitecode and a.destcode = destcode and a.xlatedpfx = left(xlatednb, CHAR_LENGTH(a.xlatedpfx)) LIMIT 1;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;    
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `esp_check_block_tariffclass` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `esp_check_block_tariffclass`(sitecode VARCHAR(3),
tariffclass VARCHAR(5))
begin

   select IFNULL(pr_block,'') pr_block from  blocked_tariffclass a where a.sitecode = sitecode and a.tariffclass = tariffclass;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `esp_check_special_number` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `esp_check_special_number`(cardid INT, 
 phoneNB VARCHAR(30), 
 nbtype INT)
begin
    select  pr_message, action_mode from special_number a
    where a.cardid = cardid
    and (a.nbtype = nbtype or nbtype = 0)
    and a.prefix = left(phoneNB, CHAR_LENGTH(prefix))
    order by  CHAR_LENGTH(prefix) desc,nbtype desc LIMIT 1;
 	
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `esp_check_timecode` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `esp_check_timecode`(v_date DATETIME(3),
v_tcode INT)
begin
   DECLARE v_ptime INT;
   set v_ptime = EXTRACT(HOUR FROM v_date)*100+EXTRACT(MINUTE FROM v_date);  
   select * from timecode where timecode = v_tcode and
   timefrom <= v_ptime and v_ptime < timeto;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `esp_getmax_progcharge2` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `esp_getmax_progcharge2`(cardid INT,
charge INT,
timeprd INT)
begin
   select cardid,charge,timeperiod,minsec,maxsec,unitcharge from progcharge2 a
   where (a.cardid = cardid or cardid = 0) and
   a.charge = charge and
		(a.timeperiod = timeprd or timeperiod = 1)
   order by cardid desc,timeperiod desc,minsec asc;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `esp_getmvno_notif_config` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `esp_getmvno_notif_config`(
sitecode VARCHAR(3), 
 cardid INT,
 brandtype INT,     
 tariffclass VARCHAR(5)
 )
begin
 
        
    IF brandtype is null then
       set brandtype = 0;
    END IF;
    
    IF tariffclass is null then
       set tariffclass = '*';
    END IF;
    
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
		select * from mvno_notification_config a
		where (a.sitecode = sitecode or sitecode = '*')
		and (a.brandtype = brandtype or brandtype = 0)
		and (a.cardid = cardid or cardid = 0)
		and (a.tariffclass = tariffclass or a.tariffclass = '*')
		order by a.sitecode desc,a.brandtype desc,a.cardid desc,a.tariffclass desc LIMIT 1;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `esp_getquickdialdestfile` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `esp_getquickdialdestfile`(v_site CHAR(3),
v_dest VARCHAR(64))
begin
   select destfile from  DestName where destcode = v_dest;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `esp_gettotal_progcharge2` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `esp_gettotal_progcharge2`(v_cardid INT,
v_charge INT)
begin
   select  cardid,charge,timeperiod,minsec,maxsec,unitcharge from progcharge2
   where (cardid = v_cardid or cardid = 0) and
   charge = v_charge
   order by cardid desc,unitcharge desc LIMIT 1;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `esp_get_access_charge` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `esp_get_access_charge`(sitecode CHAR(3),
did CHAR(6),
callmode_trunk CHAR(8),
trunkin CHAR(8),
call_mode INT)
begin


   if exists(select * from access_charge_callmode a
   where a.sitecode = sitecode and a.prefix in('*',did,right(did,6),CONCAT(left(did, CHAR_LENGTH(prefix) -1),'*')) and trunkcode = trunkin and a.callmode = call_mode LIMIT 1) then
	
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select * from access_charge_callmode a
      where a.sitecode = sitecode
      and a.prefix in('*',did,right(did,6),CONCAT(left(did, CHAR_LENGTH(prefix) -1),'*'))
      and a.trunkcode = trunkin
      and a.callmode = call_mode
      order by prefix desc, CHAR_LENGTH(prefix) desc LIMIT 1;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   else
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select * from access b
      where b.sitecode = sitecode
      and b.did in('*',did,right(did,6),CONCAT(left(did, CHAR_LENGTH(did) -1),'*'))
      and b.trunkcode = callmode_trunk
      order by did desc, CHAR_LENGTH(did) desc LIMIT 1;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   end if;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `esp_get_cardfamily` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `esp_get_cardfamily`(cardid INT)
begin
  
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select * from  cardfamily a where a.cardid = cardid LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `esp_get_cardfeatures` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `esp_get_cardfeatures`(cardid INT)
begin
 
   select cardid,featuretype,status,param1,param2,param3 from CardFeatures a
   where a.cardid = cardid or cardid = 0 order by featuretype,cardid desc;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `esp_get_card_message` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `esp_get_card_message`(site_code VARCHAR(3),
brand_type INT,
card_id INT,
tariff_class VARCHAR(5),
roaming INT,
message_id INT)
begin


   DECLARE v_message VARCHAR(1000);
   DECLARE v_datepart_mm VARCHAR(3);
	
   set v_message = '';
	
   set v_datepart_mm = right(CONCAT('00',cast(EXTRACT(MONTH FROM TIMESTAMPADD(MONTH,1,CURRENT_TIMESTAMP)) as CHAR(2))),2);
	
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select  replace(text,'%nextMM',v_datepart_mm) text
   from card_messages a
   where (a.sitecode = site_code or sitecode = '*')
   and (a.brand_type = brand_type or brand_type = 0)
   and (a.cardid = card_id or cardid = 0)
   and (a.tariffclass = tariff_class or tariffclass = '*')
   and (a.roaming = roaming or roaming = -1)
   and a.messageid = message_id
   order by sitecode desc,brand_type desc,cardid desc,tariffclass desc,roaming desc LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
	
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `esp_get_charge_amount` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `esp_get_charge_amount`(v_sitecode VARCHAR(3),      
v_dialednum VARCHAR(50),    
INOUT v_cost FLOAT)
BEGIN

      
      
      
   DECLARE v_xlatpfx VARCHAR(16);    
   DECLARE v_tariffclass VARCHAR(8);    
   DECLARE v_destcode VARCHAR(50);    
   DECLARE v_charge FLOAT;    
   DECLARE v_prefix_set INT;    
   DECLARE v_dailed_number_nonprefix VARCHAR(50);    
   DECLARE v_dailed_number VARCHAR(50);      
      
   set v_prefix_set = 4;      
      

      
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   xlatpfx INTO v_xlatpfx from  xlat_byset  where v_dialednum like CONCAT(prefix,'%')   order by switchcode desc,pfxlen desc,trunkcode desc,numbertype desc LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;        
      
   set v_dailed_number_nonprefix = right(v_dialednum,12);      
      
   Set v_dailed_number = CONCAT_WS('',LEFT(v_xlatpfx,6),v_dailed_number_nonprefix);      

      
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   destcode INTO v_destcode from prefix  where sitecode = v_sitecode
   and prefixset = v_prefix_set
   and v_dailed_number like CONCAT(prefixcode,'%')   order by prefixcode desc LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;        
    

   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   sampunit/100 INTO v_cost from tariff   where sitecode = v_sitecode
   and destcode = v_destcode
   and charge = 47;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;    
  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `esp_get_maintenancecharge2` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `esp_get_maintenancecharge2`(telco VARCHAR(3),
site VARCHAR(3),
trffclass VARCHAR(4),
accbal FLOAT)
begin

   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select * from maintenance_charge2 a
   where telcocode = telco and sitecode = site and a.trffclass = trffclass and
   accbal between mc2_balmin and mc2_balmax
   order by mc2_balmin desc LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `esp_get_ported_prompt` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `esp_get_ported_prompt`(v_sitecode VARCHAR(3),
v_mnp_rcid VARCHAR(50))
begin


   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select  ported_prompt
   from rcid_setting 
   where (sitecode = v_sitecode or sitecode = '*')
   and v_mnp_rcid LIKE CONCAT(rcid,'%')
   order by sitecode desc,rcid desc LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
	
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `esp_xlatdest_tomsisdn` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `esp_xlatdest_tomsisdn`(xlatednb VARCHAR(30),
nbtype INT)
begin

   IF nbtype is null then
      set nbtype = 0;
   END IF;
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select  case when IFNULL(normalnbpfx,'') = '' then SUBSTRING(xlatednb, CHAR_LENGTH(pfx)+1, CHAR_LENGTH(xlatednb))
   else CONCAT(normalnbpfx,SUBSTRING(xlatednb, CHAR_LENGTH(pfx)+1, CHAR_LENGTH(xlatednb))) end mobileno
   from mvno_xlattonormal 
   where pfx = left(xlatednb, CHAR_LENGTH(pfx)) and (nbtype = nbtype or nbtype = 0)
   order by  CHAR_LENGTH(pfx) desc,nbtype desc LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `esX_get_bal_batch` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `esX_get_bal_batch`(telcocode CHAR(4), custcode CHAR(8), batchcode INT)
begin

   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select balance total
   from account a
   where a.telcocode = telcocode
   and a.custcode = custcode
   and a.batchcode = batchcode;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es_gettimeclass_daytime` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `es_gettimeclass_daytime`(v_site VARCHAR(3),  
v_date DATETIME(3),  
v_type INT,  
v_key VARCHAR(8))
begin  
   DECLARE v_pday INT;  
   DECLARE v_ptime INT;  
   
   set v_pday = 1+(DAYOFWEEK(v_date)+v_datefirst -2)%7;  
   set v_ptime = EXTRACT(HOUR FROM v_date)*100+EXTRACT(MINUTE FROM v_date);  
   
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select  a.timeclass from daytime a, daycode b, timecode c 
   where sitecode = v_site and tclstype = v_type and (tclskey = v_key or tclskey = '*')
   and a.daycode = b.daycode and a.timecode = c.timecode
   and v_pday between b.dayfrom and b.dayto
   and ((c.timefrom <= v_ptime and v_ptime < c.timeto) or
  (c.timeto2 < c.timeto and v_ptime < c.timeto2))
   order by tclstype,tclskey desc LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es_isprefixblocked` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `es_isprefixblocked`(prefixcode VARCHAR(32))
begin
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select * from blocked_prefix a
    where prefixcode like CONCAT(a.prefixcode,'%') LIMIT 1;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetAccessList` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `GetAccessList`()
Begin
   select * from access_charge;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetCharge` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `GetCharge`(v_trfcls VARCHAR(10))
Begin

   select * from progcharge1 where trffclass = v_trfcls;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetCharge_ProgCharge1` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `GetCharge_ProgCharge1`(v_trfcls VARCHAR(10),
v_tmprd INT)
Begin

   select * from  progcharge1 where trffclass = v_trfcls and timeperiod = v_tmprd;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetDestination` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `GetDestination`(trffclass VARCHAR(10),
dest VARCHAR(30))
Begin

   DECLARE v_str VARCHAR(100);
   set v_str =CONCAT( 'select distinct destcode from tariff a ', 'where a.trffclass = ''', trffclass, ''' and destcode like ''', dest,  ''''); 
   
SET @SWV_Stmt = v_str;
   PREPARE SWT_Stmt FROM @SWV_Stmt;
   EXECUTE SWT_Stmt;
   DEALLOCATE PREPARE SWT_Stmt;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getprefix` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `getprefix`(v_ddi VARCHAR(32))
begin

   DECLARE SWV_ddi_Str VARCHAR(32);
   if left(v_ddi,2) = '00' then 
      SET SWV_ddi_Str = SUBSTR(v_ddi,3,32);
      SET v_ddi = SWV_ddi_Str;
   end if;
   select prefixcode, destcode, mindigit, maxdigit, isactive, comment
   from prefix
   where prefixset = 4
   and v_ddi like CONCAT(prefixcode,'%')
   order by prefixcode desc;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_account_limit_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `get_account_limit_details`(v_sitecode VARCHAR(3),
v_tariffclass VARCHAR(5),
v_charge INT,
v_uselimit_mode INT,
v_now DATETIME(3),
INOUT v_groupid INT ,
INOUT v_uselimit_delay INT ,
INOUT v_uselimit_datemode INT ,
INOUT v_uselimit_amount FLOAT ,
INOUT v_startdate DATETIME(3) ,
INOUT v_enddate DATETIME(3) ,
INOUT v_errcode INT ,
INOUT v_errmsg VARCHAR(56))
SWL_return:
begin



   DECLARE Swv_RowCount INT;
   set v_errcode = -1;
		
	
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   a.groupid, b.uselimit_delay, uselimit_datemode, b.uselimit_amount INTO v_groupid,v_uselimit_delay,v_uselimit_datemode,v_uselimit_amount from account_uselimit_charge a 
   join account_uselimit_group b  on a.sitecode = b.sitecode and a.groupid = b.groupid where a.sitecode = v_sitecode
   and (a.tariffclass = v_tariffclass or a.tariffclass = '*')
   and a.charge = v_charge
   and (b.uselimit_mode = v_uselimit_mode or b.uselimit_mode = 0)
   and b.status = 1   order by a.tariffclass desc,b.uselimit_mode desc,b.lastupd LIMIT 1;
   SET Swv_RowCount = ROW_COUNT();
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
   if Swv_RowCount = 0 then
      LEAVE SWL_return;
   end if;

	
   if v_uselimit_datemode = 2 then 
	
      set v_startdate = v_now;
      set v_enddate = v_now;
      set v_startdate = TIMESTAMPADD(DAY,1,v_startdate -day(v_startdate));
      set v_startdate = TIMESTAMPADD(HOUR,-EXTRACT(HOUR FROM v_startdate),v_startdate);
      set v_startdate = TIMESTAMPADD(MINUTE,-EXTRACT(MINUTE FROM v_startdate),v_startdate);
      set v_startdate = TIMESTAMPADD(SECOND,-EXTRACT(SECOND FROM v_startdate),v_startdate);
      set v_startdate = TIMESTAMPADD(MICROSECOND,-EXTRACT(MICROSECOND FROM v_startdate),v_startdate);
      set v_enddate = TIMESTAMPADD(MONTH,1,v_enddate -day(v_enddate));
      set v_enddate = TIMESTAMPADD(HOUR,-EXTRACT(HOUR FROM v_enddate)+23,v_enddate);
      set v_enddate = TIMESTAMPADD(MINUTE,-EXTRACT(MINUTE FROM v_enddate)+59,v_enddate);
      set v_enddate = TIMESTAMPADD(SECOND,-EXTRACT(SECOND FROM v_enddate)+59,v_enddate);
      set v_enddate = TIMESTAMPADD(MICROSECOND,-EXTRACT(MICROSECOND FROM v_enddate),v_enddate);
   else
      set v_errmsg = 'MODE is not supported yet.';
      LEAVE SWL_return;
   end if;
		
   set v_errcode = 0;
   set v_errmsg = 'Account Usage Limit found.';

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_account_limit_details_v2` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `get_account_limit_details_v2`(
sitecode VARCHAR(3),
 tariffclass VARCHAR(5),
 charge INT,
 uselimit_mode INT,
 now DATETIME(3),
 acc_startdate DATETIME(3),
 acc_enddate DATETIME(3),
 INOUT groupid INT ,
 INOUT uselimit_delay INT ,
 INOUT uselimit_datemode INT ,
 INOUT uselimit_amount FLOAT ,
 INOUT startdate DATETIME(3) ,
 INOUT enddate DATETIME(3) ,
 INOUT errcode INT ,
 INOUT errmsg VARCHAR(156) ,
 INOUT limit_action INT ,    
 INOUT uselimit_SubsID INT ,
 INOUT uselimit_SubsID_roaming INT)
SWL_return:
 begin
 
 
 
 
    DECLARE Swv_RowCount INT;
    set errcode = -1;
 		
 	
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select   a.groupid, b.uselimit_delay, uselimit_datemode, b.uselimit_amount, IFNULL(uselimit_action,0), IFNULL(uselimit_SubsID,0), IFNULL(uselimit_SubsID_roaming,0) INTO groupid,uselimit_delay,uselimit_datemode,uselimit_amount,limit_action,
    uselimit_SubsID,uselimit_SubsID_roaming from  account_uselimit_charge a 
    join  account_uselimit_group b  on a.sitecode = b.sitecode and a.groupid = b.groupid where a.sitecode = sitecode
    and (a.tariffclass = tariffclass or a.tariffclass = '*')
    and a.charge = charge
    and (b.uselimit_mode = uselimit_mode or b.uselimit_mode = 0)
    and b.status = 1   order by a.tariffclass desc,b.uselimit_mode desc,b.lastupd LIMIT 1;
    SET Swv_RowCount = ROW_COUNT();
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
 
    if Swv_RowCount = 0 then
       LEAVE SWL_return;
    end if;
 
    if uselimit_datemode not in(1,2,3) then 
 	
       set errmsg = 'DATE MODE is not supported yet.';
       LEAVE SWL_return;
    end if;
 	
    if uselimit_datemode = 1 then
 	
       set startdate = now;
       set enddate = TIMESTAMPADD(DAY,uselimit_delay,now);
    end if;
 
 	
    if uselimit_datemode = 2 then 
 	
       set startdate = now;
       set enddate = now;
 		
 		
       set startdate = TIMESTAMPADD(day,-1,TIMESTAMPADD(DAY,1,TIMESTAMPADD(day,1,startdate -day(startdate))));
       set startdate = TIMESTAMPADD(HOUR,-EXTRACT(HOUR FROM  startdate),startdate);
       set startdate = TIMESTAMPADD(MINUTE,-EXTRACT(MINUTE FROM startdate),startdate);
       set startdate = TIMESTAMPADD(SECOND,-EXTRACT(SECOND FROM startdate),startdate);
       set startdate = TIMESTAMPADD(MICROSECOND,-EXTRACT(MICROSECOND FROM startdate),startdate);
 		
 		
       set enddate = TIMESTAMPADD(day,-1,TIMESTAMPADD(MONTH,1,TIMESTAMPADD(day,1,enddate -day(enddate))));
       set enddate = TIMESTAMPADD(HOUR,-EXTRACT(HOUR FROM enddate)+23,enddate);
       set enddate = TIMESTAMPADD(MINUTE,-EXTRACT(MINUTE FROM enddate)+59,enddate);
       set enddate = TIMESTAMPADD(SECOND,-EXTRACT(SECOND FROM enddate)+59,enddate);
       set enddate = TIMESTAMPADD(MICROSECOND,-EXTRACT(MICROSECOND FROM enddate),enddate);
    end if;
 
    if uselimit_datemode = 3 then
 	
       set startdate = acc_startdate;
       set enddate   = acc_enddate;
    end if;
  		
    set errcode = 0;
    set errmsg = 'Account Usage Limit found.';
 
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_account_uselimit_config_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `get_account_uselimit_config_info`(sitecode VARCHAR(3),
tariffclass VARCHAR(5),
uselimit_mode INT,
INOUT errcode INT ,
INOUT errmsg VARCHAR(250) ,
INOUT use_limit_action INT,
INOUT uselimit_SubsID INT)
begin

   DECLARE v_found INT; 

   IF use_limit_action is null then
      set use_limit_action = 0;
   END IF;
   IF uselimit_SubsID is null then
      set uselimit_SubsID = 0;
   END IF;
   set v_found = 0;
   set errcode = -1;
   set errmsg = '';
		
	
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   1, IFNULL(uselimit_action,0), IFNULL(uselimit_SubsID,0) INTO v_found,use_limit_action,uselimit_SubsID from account_uselimit_charge a 
   join account_uselimit_group b  on a.sitecode = b.sitecode and a.groupid = b.groupid where a.sitecode = sitecode
   and a.tariffclass = tariffclass and
   b.uselimit_mode = uselimit_mode
   and b.status = 1    LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
		
   if v_found = 1 then
	
      set errcode = 0;
      set errmsg = 'Success to get config details';
   end if; 
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_account_uselimit_config_info_V2` */;
ALTER DATABASE `espprm` CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `get_account_uselimit_config_info_V2`(v_sitecode VARCHAR(3),
v_tariffclass VARCHAR(5),
v_uselimit_mode INT,
INOUT v_errcode INT ,
INOUT v_errmsg VARCHAR(250) ,
v_groupid INT)
begin



	
	
   DECLARE v_found INT; 

   set v_found = 0;
   set v_errcode = -1;
   set v_errmsg = '';
		
	
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   1, a.groupid INTO v_found,v_groupid from  account_uselimit_charge a 
   join  account_uselimit_group b  on a.sitecode = b.sitecode and a.groupid = b.groupid where a.sitecode = v_sitecode
   and a.tariffclass = v_tariffclass and
   b.uselimit_mode = v_uselimit_mode
   and b.status = 1    LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
		
   if v_found = 1 then
	
      set v_errcode = 0;
      set v_errmsg = 'Success to get config details';
   end if; 
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `espprm` CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `gprs_cnxcharge_v2` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `gprs_cnxcharge_v2`(v_cnxallocval INT,
v_destcode VARCHAR(60),
v_trffclass VARCHAR(4),
v_m_trffclass VARCHAR(4),
v_charge INT, 
INOUT v_cnxchargepack FLOAT ,
INOUT v_errcode INT ,
INOUT v_errmsg VARCHAR(64))
SWL_return:
begin

	
	
   DECLARE v_cnxunit INT;
   DECLARE v_sampunit FLOAT;
   DECLARE v_sampdelay INT;
   DECLARE v_ccmode INT;
   DECLARE v_ccdelay INT;
   DECLARE v_ccfactor FLOAT;
   DECLARE v_nb_cc INT;
   DECLARE Swv_RowCount INT;
   DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
   BEGIN
      SET @SWV_Error = 1;
   END;
	
   SET @SWV_Error = 0;
   set v_errcode = -1;
   set v_nb_cc = 0;
   set v_cnxchargepack = 0.0;
	
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   cnxunit, sampunit, sampdelay INTO v_cnxunit,v_sampunit,v_sampdelay from tariff  where trffclass = v_trffclass and destcode = v_destcode and charge = v_charge;
   SET Swv_RowCount = ROW_COUNT();
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   if @SWV_Error <> 0 or Swv_RowCount < 1 then
	
      set v_errmsg = 'Failed to get tariff for cnxcharge';
      LEAVE SWL_return;
   end if;
	
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   cnxcharge_mode, cnxcharge_delay, cnxcharge_ccfactor INTO v_ccmode,v_ccdelay,v_ccfactor from pack_cnxcharge  where trffclass = v_m_trffclass and destcode = v_destcode and charge = v_charge;
   SET Swv_RowCount = ROW_COUNT();
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   if @SWV_Error <> 0 or Swv_RowCount < 1 then
	
      set v_errmsg = 'Failed to get pack_cnxcharge for cnxcharge';
      LEAVE SWL_return;
   end if;
	
	
   if v_ccmode = 1 then
	
      if v_ccdelay > 0 then
		
         set v_nb_cc = v_cnxallocval/v_ccdelay;
         if v_cnxallocval%v_ccdelay > 0 then
            set v_nb_cc = v_nb_cc+1;
         end if;
         if v_ccfactor > 0.0 then
            set v_cnxchargepack = v_nb_cc*v_ccfactor;
         else
            set v_cnxchargepack = v_nb_cc*v_ccfactor*v_cnxunit*(-1);
         end if;
      end if;
   end if;
	
   if v_ccmode = 2 then
	
      if v_cnxallocval >= v_ccdelay then
		
         if v_ccfactor > 0 then
            set v_cnxchargepack = v_ccfactor;
         else
            set v_cnxchargepack = v_cnxunit*v_ccfactor*(-1);
         end if;
      end if;
   end if;
	
   if v_ccmode = 3 then
	
      if v_ccdelay > 0 then
		
         set v_nb_cc = v_cnxallocval/v_ccdelay;
         if v_cnxallocval%v_ccdelay > 0 then
            set v_nb_cc = v_nb_cc+1;
         end if;
         if v_ccfactor > 0.0 then
            set v_cnxchargepack =(v_nb_cc*v_ccfactor)+v_cnxunit;
         else
            set v_cnxchargepack =(v_nb_cc*v_ccfactor*v_cnxunit*(-1))+v_cnxunit;
         end if;
      end if;
   end if;
	
   if v_ccmode = 4 then
	
      if v_sampdelay > 0 then
		
         set v_nb_cc = v_cnxallocval/v_sampdelay;
         if v_cnxallocval%v_sampdelay > 0 then
            set v_nb_cc = v_nb_cc+1;
         end if;
         if v_ccfactor > 0.0 then
            set v_cnxchargepack = v_nb_cc*v_ccfactor;
         else
            set v_cnxchargepack = v_nb_cc*v_ccfactor*v_sampunit*(-1);
         end if;
      end if;
   end if;
	
   if v_ccmode = 5 then
	
      if v_sampdelay > 0 then
		
         set v_nb_cc = v_cnxallocval/v_sampdelay;
         if v_cnxallocval%v_sampdelay > 0 then
            set v_nb_cc = v_nb_cc+1;
         end if;
         if v_ccfactor > 0.0 then
            set v_cnxchargepack =(v_nb_cc*v_ccfactor)+v_cnxunit;
         else
            set v_cnxchargepack =(v_nb_cc*v_ccfactor*v_sampunit*(-1))+v_cnxunit;
         end if;
      end if;
   end if;
	
   set v_errcode = 0;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `gprs_get_tariffclass_v3` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `gprs_get_tariffclass_v3`(sitecode CHAR(3),
trffclass VARCHAR(5),
ratingid INT,
apn VARCHAR(32),
roaming_zone INT,
INOUT errcode INT ,
INOUT errmsg VARCHAR(255) ,
INOUT chargingtype INT ,
INOUT allocationvalue BIGINT ,
INOUT destcode VARCHAR(23) ,
INOUT charge INT ,
INOUT allocationdelay BIGINT)
SWL_return:
begin


	
		
			


   DECLARE Swv_RowCount INT;
   set errcode = -5;
   set errmsg = '';
   set charge = 0;

   set charge = roaming_zone;
	
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   chargingtype, destcode, allocationvalue, IFNULL(allocationdelay,0) INTO chargingtype,destcode,allocationvalue,allocationdelay from gprs_tariffclass a where a.sitecode = sitecode and a.trffclass = trffclass and a.RatingID = ratingid and a.APN = apn;
   SET Swv_RowCount = ROW_COUNT();
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
	
   if Swv_RowCount = 0 or allocationvalue <= 0 or chargingtype < 0 then
	
      set errmsg = CONCAT_WS('','Failed to get tariffclass for sitecode=',sitecode,',tariffclass=',
      trffclass,',ratingid=',rtrim(ltrim(cast(ratingid as char(10)))),
      ',APN=',apn); 
      LEAVE SWL_return;
   end if;
	
   set errcode = 0;
   set errmsg = 'Get tariffclass success';
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `gprs_get_tariffclass_v4` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `gprs_get_tariffclass_v4`(v_sitecode CHAR(3),
v_trffclass VARCHAR(5),
v_ratingid INT,
v_apn VARCHAR(32),
v_roaming_zone INT,
INOUT v_errcode INT ,
INOUT v_errmsg VARCHAR(255) ,
INOUT v_chargingtype INT ,
INOUT v_allocationvalue BIGINT ,
INOUT v_destcode VARCHAR(23) ,
INOUT v_charge INT ,
INOUT v_allocationdelay BIGINT ,
INOUT v_balance_threshold FLOAT  
)
SWL_return:
begin



   DECLARE Swv_RowCount INT;
   set v_errcode = -5;
   set v_errmsg = '';
   set v_charge = 0;

   set v_charge = v_roaming_zone;
	
	
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   chargingtype, destcode, allocationvalue, IFNULL(allocationdelay,0), IFNULL(balance_threshold,0.0) INTO v_chargingtype,v_destcode,v_allocationvalue,v_allocationdelay,v_balance_threshold from  gprs_tariffclass where sitecode = v_sitecode
   and trffclass = v_trffclass
   and RatingID = v_ratingid
   and (APN = v_apn or APN = '*')   order by APN desc LIMIT 1;
   SET Swv_RowCount = ROW_COUNT();
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   if Swv_RowCount = 0 or v_allocationvalue <= 0 or v_chargingtype < 0 then
	
      set v_errmsg = CONCAT_WS('','Failed to get tariffclass for sitecode=',v_sitecode,',tariffclass=',
      v_trffclass,',ratingid=',rtrim(ltrim(cast(v_ratingid as char(10)))),
      ',APN=',v_apn); 
      LEAVE SWL_return;
   end if;
	
   set v_errcode = 0;
   set v_errmsg = 'Get tariffclass success';
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `gprs_get_tariffclass_v5` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `gprs_get_tariffclass_v5`(v_sitecode CHAR(3),
v_trffclass VARCHAR(5),
v_ratingid INT,
v_apn VARCHAR(32),
v_roaming_zone INT,
INOUT v_errcode INT ,
INOUT v_errmsg VARCHAR(255) ,
INOUT v_chargingtype INT ,
INOUT v_allocationvalue BIGINT ,
INOUT v_destcode VARCHAR(23) ,
INOUT v_charge INT ,
INOUT v_allocationdelay BIGINT ,
INOUT v_balance_threshold FLOAT ,
INOUT v_cdr_flag INT , 
INOUT v_allow_minusbal INT)
SWL_return:
begin



   DECLARE Swv_RowCount INT;
   set v_errcode = -5;
   set v_errmsg = '';
   set v_charge = 0;

   set v_charge = v_roaming_zone;
	
	
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   chargingtype, destcode, allocationvalue, IFNULL(allocationdelay,0), IFNULL(balance_threshold,0.0), IFNULL(cdr_flag,0), IFNULL(allow_minusbal,0) INTO v_chargingtype,v_destcode,v_allocationvalue,v_allocationdelay,v_balance_threshold,
   v_cdr_flag,v_allow_minusbal from gprs_tariffclass where sitecode = v_sitecode
   and trffclass = v_trffclass
   and RatingID = v_ratingid
   and (APN = v_apn or APN = '*')   order by APN desc LIMIT 1;
   SET Swv_RowCount = ROW_COUNT();
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   if Swv_RowCount = 0 or v_allocationvalue <= 0 or v_chargingtype < 0 then
	
      set v_errmsg = CONCAT_WS('','Failed to get tariffclass for sitecode=',v_sitecode,',tariffclass=',
      v_trffclass,',ratingid=',rtrim(ltrim(cast(v_ratingid as char(10)))),
      ',APN=',v_apn); 
      LEAVE SWL_return;
   end if;
	
   set v_errcode = 0;
   set v_errmsg = 'Get tariffclass success';
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `gprs_get_tariff_v4` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `gprs_get_tariff_v4`(telcocode VARCHAR(3),
sitecode CHAR(3),
trffclass VARCHAR(5),
trf_timeperiod INT,
trf_destcode VARCHAR(23),
trf_charge INT,
INOUT errcode INT ,
INOUT errmsg VARCHAR(255) ,
INOUT trf_sampdelay INT ,
INOUT trf_sampunit FLOAT ,
INOUT premiumdest INT)
SWL_return:
begin



   DECLARE Swv_RowCount INT;
   set errcode = -1;
   set errmsg = '';
   set premiumdest = 0;
	
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   sampdelay, case
   when premiumdest = 5 then 0.0
   else sampunit
   end, premiumdest INTO trf_sampdelay,trf_sampunit,premiumdest from tariff a where a.telcocode = telcocode
   and a.sitecode = sitecode
   and destcode = trf_destcode
   and a.trffclass = trffclass
   and charge = trf_charge
   and (a.timeperiod = trf_timeperiod or timeperiod = 1)   order by timeperiod desc LIMIT 1;
   SET Swv_RowCount = ROW_COUNT();
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;   
   if (premiumdest <> 5) and ((Swv_RowCount = 0) or (trf_sampdelay <= 0) or (trf_sampunit is null) or (trf_sampunit <= 0)) then
	
      set errmsg = CONCAT_WS('','Tariff Not Found for telcocode=',telcocode,', site=',sitecode,
      ', dest=',trf_destcode,', trffcls=',trffclass,', charge=',rtrim(ltrim(cast(trf_charge as CHAR(3)))),
      ', timeperiod=',rtrim(ltrim(cast(trf_timeperiod as CHAR(2)))));
      LEAVE SWL_return;
   end if; 
	
   set errcode = 0;
   set errmsg = 'Get Tariff success';
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `gprs_get_timeperiod_v2` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `gprs_get_timeperiod_v2`(
site VARCHAR(3),  
 date DATETIME(3),  
 type INT,  
 `key` VARCHAR(8),
 INOUT timeperiod INT ,
 INOUT errcode INT ,
 INOUT errmsg VARCHAR(160))
SWL_return:
 begin
   
 
 
    DECLARE v_tc INT;  
    DECLARE v_found INT;
    DECLARE v_pdate VARCHAR(10);  
    DECLARE v_pday INT;    
    DECLARE v_ptime INT;
    DECLARE Swv_RowCount INT;
    DECLARE datefirst  DATETIME(3);
 	
    set errcode = -3;
    set errmsg = '';
 	 
 	
    set v_found = 0;  
    set v_pdate = DATE_FORMAT(date,'%Y-%m-%d');  
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select   1, timeclass INTO v_found,v_tc from holiday  where sitecode = site and hdate = v_pdate and tclstype = type and (tclskey = `key` or tclskey = '*')   order by tclstype,tclskey desc LIMIT 1;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
  
    if v_found = 1 then
 	
       select v_tc timeclass;
       LEAVE SWL_return;
    end if;  
  
 	
    set v_pday = 1+(DAYOFWEEK(date)+datefirst -2)%7;    
    set v_ptime = EXTRACT(HOUR FROM date)*100+EXTRACT(MINUTE FROM date);    
 	   
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select   a.timeclass INTO timeperiod from daytime a, daycode b, timecode c  where sitecode = site and tclstype = type and (tclskey = `key` or tclskey = '*')
    and a.daycode = b.daycode and a.timecode = c.timecode
    and v_pday between b.dayfrom and b.dayto
    and ((c.timefrom <= v_ptime and v_ptime < c.timeto) or
 		(c.timeto2 < c.timeto and v_ptime < c.timeto2))   order by tclstype,tclskey desc LIMIT 1;
    SET Swv_RowCount = ROW_COUNT();
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
    if (Swv_RowCount = 0) then
 	
       set errmsg = CONCAT('gettimeclass: failed to find timeclass for tariffclass= ',rtrim(`key`),
       ' date=',DATE_FORMAT(date,'%Y-%m-%d %T:%f'));
       LEAVE SWL_return;
    end if;
 	
    set errcode = 0;
    set errmsg = 'Timeperiod found';
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `hlr_ussd_gettimeclass` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `hlr_ussd_gettimeclass`(v_site VARCHAR(3),  
v_date DATETIME(3),  
v_type INT,  
v_key VARCHAR(8),  
INOUT v_timeperiod INT)
SWL_return:
begin
  
   DECLARE v_found INT;
   DECLARE v_pdate VARCHAR(10);  
   DECLARE v_pday INT;    
   DECLARE v_ptime INT;  
  
 
   set v_found = 0;  
   set v_pdate = DATE_FORMAT(v_date,'%Y-%m-%d');  
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   1, timeclass INTO v_found,v_timeperiod from holiday  where sitecode = v_site and hdate = v_pdate and tclstype = v_type and (tclskey = v_key or tclskey = '*')   order by tclstype,tclskey desc LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
  
   if v_found = 1 then
      LEAVE SWL_return;
   end if;  
  
 
   set v_pday = 1+(DAYOFWEEK(v_date)+v_datefirst -2)%7;    
   set v_ptime = EXTRACT(HOUR FROM v_date)*100+EXTRACT(MINUTE FROM v_date);    
     
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   a.timeclass INTO v_timeperiod from daytime a, daycode b, timecode c  where sitecode = v_site and tclstype = v_type and (tclskey = v_key or tclskey = '*')
   and a.daycode = b.daycode and a.timecode = c.timecode
   and v_pday between b.dayfrom and b.dayto
   and ((c.timefrom <= v_ptime and v_ptime < c.timeto) or
    (c.timeto2 < c.timeto and v_ptime < c.timeto2))   order by tclstype,tclskey desc LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;    
  
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `insert_new_prefix` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `insert_new_prefix`(v_destcode VARCHAR(40),
  v_prefixcode VARCHAR(40),
  v_ref VARCHAR(40))
begin

   if v_ref is null then 
      set v_ref = v_destcode;
   end if;

   DROP TEMPORARY TABLE IF EXISTS tt_x;

   CREATE TEMPORARY TABLE tt_x AS select * from prefix
      where destcode = v_ref
      and prefixset = 4
      order by prefixcode LIMIT 1;

   delete from prefix
   where prefixcode = v_prefixcode
   and prefixset = 4;

   insert into prefix
   select sitecode, v_prefixcode, v_destcode, mindigit, maxdigit,
         isactive, '', prefixset, prefixtype, mobilecdrop
   from ttx;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `load_tariff_class` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `load_tariff_class`()
begin
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   SELECT trffclass TariffClass from tariffclass 
   where sitecode = 'BDK';
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `mvno_get_lowbal_notif` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `mvno_get_lowbal_notif`(v_sitecode VARCHAR(3),
v_brandtype INT,
v_tariffclass VARCHAR(5),
v_roaming INT,
v_cardid INT,
INOUT v_bal_warning_mode INT ,
INOUT v_bal_notif_mode INT ,
INOUT v_message1 VARCHAR(256) ,
INOUT v_message2 VARCHAR(256) ,
INOUT v_threshold1 FLOAT ,
INOUT v_threshold2 FLOAT ,
INOUT v_errcode INT ,
INOUT v_errmsg VARCHAR(100))
SWL_return:
begin



   DECLARE v_param1 VARCHAR(100);
   DECLARE v_param2 VARCHAR(100);
   DECLARE v_param3 VARCHAR(256);
   DECLARE v_param1_1 VARCHAR(100);
   DECLARE v_param1_2 VARCHAR(100);
   DECLARE v_param2_1 VARCHAR(100);
   DECLARE v_param2_2 VARCHAR(100);
   DECLARE v_param2_3 VARCHAR(100);
   DECLARE v_param2_4 VARCHAR(100);
   DECLARE v_param2_temp VARCHAR(100);
   DECLARE v_is_roaming INT;
   DECLARE v_loops INT;
   DECLARE v_pos INT;
   DECLARE v_datepart_mm VARCHAR(3);
   DECLARE Swv_RowCount INT;
   DECLARE SWV_param2_temp_Str VARCHAR(100);
	
   set v_bal_warning_mode = -1;
   set v_bal_notif_mode = -1;
   set v_threshold1 = -1;
   set v_threshold2 = -1;
   set v_is_roaming = 0;
   set v_loops = 0;
	
   set v_errcode = -1;
   set v_errmsg = '';
	
	
   if v_roaming <> 1 then
      set v_is_roaming = 1;
   end if;
	
	
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   IFNULL(param1,''), IFNULL(param2,''), IFNULL(param3,'') INTO v_param1,v_param2,v_param3 from CardFeatures  where cardid = v_cardid and featuretype = 25 and status = 1;
   SET Swv_RowCount = ROW_COUNT();
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   if Swv_RowCount = 0 then
	
      set v_errmsg = 'No setting found.';
      LEAVE SWL_return;
   end if;
	
	
   if v_param1 is not null and v_param1 <> '' then
	
      set v_param1_1 = SWF_SUBSTRING(v_param1,1,LOCATE(':',v_param1) -1);
      set v_param1_2 = SWF_SUBSTRING(v_param1,LOCATE(':',v_param1)+1, CHAR_LENGTH(v_param1));
   else
      set v_errmsg = 'Wrong setting at param1.';
      LEAVE SWL_return;
   end if;
	
	
   if v_param1_1 <> '' and v_param1_1 REGEXP('^[+-.$.]?[[0-9,]+...]?$') then
      set v_bal_warning_mode = v_param1_1;
   else
      set v_errmsg = 'Wrong setting at param1_1.';
      LEAVE SWL_return;
   end if;
	
	
   if v_param1_2 <> '' and v_param1_2 REGEXP('^[+-.$.]?[[0-9,]+...]?$') then
      set v_bal_notif_mode = v_param1_2;
   else
      set v_errmsg = 'Wrong setting at param1_2.';
      LEAVE SWL_return;
   end if;
	
   if v_param2 is not null and v_param2 <> '' then
	
		
      set v_param2_temp = v_param2;
      set v_loops = 4 -( CHAR_LENGTH(v_param2_temp) - CHAR_LENGTH(replace(v_param2_temp,':','')));
      while v_loops > 0 DO
         set v_param2_temp = CONCAT_WS('',v_param2_temp,':');
         set v_loops = v_loops -1;
      END WHILE;
      set v_pos = LOCATE(':',v_param2_temp,1);
      set v_param2_1 = SWF_SUBSTRING(v_param2_temp,1,v_pos -1);
      SET SWV_param2_temp_Str = SWF_SUBSTRING(v_param2_temp,v_pos+1, CHAR_LENGTH(v_param2_temp) -v_pos);
      SET v_param2_temp = SWV_param2_temp_Str;
      set v_pos = LOCATE(':',v_param2_temp,1);
      set v_param2_2 = SWF_SUBSTRING(v_param2_temp,1,v_pos -1);
      SET SWV_param2_temp_Str = SWF_SUBSTRING(v_param2_temp,v_pos+1, CHAR_LENGTH(v_param2_temp) -v_pos);
      SET v_param2_temp = SWV_param2_temp_Str;
      set v_pos = LOCATE(':',v_param2_temp,1);
      set v_param2_3 = SWF_SUBSTRING(v_param2_temp,1,v_pos -1);
      SET SWV_param2_temp_Str = SWF_SUBSTRING(v_param2_temp,v_pos+1, CHAR_LENGTH(v_param2_temp) -v_pos);
      SET v_param2_temp = SWV_param2_temp_Str;
      set v_pos = LOCATE(':',v_param2_temp,1);
      set v_param2_4 = SWF_SUBSTRING(v_param2_temp,1,v_pos -1);
      SET SWV_param2_temp_Str = SWF_SUBSTRING(v_param2_temp,v_pos+1, CHAR_LENGTH(v_param2_temp) -v_pos);
      SET v_param2_temp = SWV_param2_temp_Str;
   else
      set v_errmsg = 'Wrong setting at param2.';
      LEAVE SWL_return;
   end if;
	
	
   if v_param2_1 <> '' and v_param2_1 REGEXP('^[+-.$.]?[[0-9,]+...]?$') then
      set v_threshold1 = v_param2_1;
   else
      set v_threshold1 = 0.0;
   end if;
	
   if v_param2_2 <> '' and v_param2_2 REGEXP('^[+-.$.]?[[0-9,]+...]?$') then
      set v_threshold2 = v_param2_2;
   else
      set v_threshold2 = 0.0;
   end if;
	
   if v_threshold1 = 0.0 and v_threshold2 = 0.0 then
	
      set v_errmsg = 'No threshold has been set.';
      LEAVE SWL_return;
   end if;
	
	
   set v_message1 = '';
   set v_message2 = '';
	
	
   if v_param2_3 <> '' and v_param2_3 REGEXP('^[+-.$.]?[[0-9,]+...]?$') then
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select   text INTO v_message1 from card_messages  where (sitecode = v_sitecode or sitecode = '*')
      and (brand_type = IFNULL(v_brandtype,0) or brand_type = 0)
      and (cardid = v_cardid or cardid = 0)
      and (tariffclass = v_tariffclass or tariffclass = '*')
      and messageid = v_param2_3
      and (roaming = v_is_roaming or roaming = -1)   order by sitecode desc,brand_type desc,cardid desc,tariffclass desc,roaming desc LIMIT 1;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   end if;
	
	
   if v_param2_4 <> '' and v_param2_4 REGEXP('^[+-.$.]?[[0-9,]+...]?$') then
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select   text INTO v_message2 from card_messages  where (sitecode = v_sitecode or sitecode = '*')
      and (brand_type = IFNULL(v_brandtype,0) or brand_type = 0)
      and (cardid = v_cardid or cardid = 0)
      and (tariffclass = v_tariffclass or tariffclass = '*')
      and messageid = v_param2_4
      and (roaming = v_is_roaming or roaming = -1)   order by sitecode desc,brand_type desc,cardid desc,tariffclass desc,roaming desc LIMIT 1;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   end if;
	
   set v_datepart_mm = right(CONCAT('00',cast(EXTRACT(MONTH FROM TIMESTAMPADD(MONTH,1,CURRENT_TIMESTAMP)) as CHAR(2))),2);
	
   if v_message1 <> '' then
      set v_message1 = replace(v_message1,'%nextMM',v_datepart_mm);
   end if;
	
   if v_message2 <> '' then
      set v_message2 = replace(v_message2,'%nextMM',v_datepart_mm);
   end if;
	
   set v_errcode = 0;
   set v_errmsg = 'Okay.';
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `mvno_get_lowbal_notif_v2` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `mvno_get_lowbal_notif_v2`(v_sitecode VARCHAR(3),
v_brandtype INT,
v_tariffclass VARCHAR(5),
v_roaming INT,
v_cardid INT,
INOUT v_bal_warning_mode INT ,
INOUT v_bal_notif_mode INT ,
INOUT v_message1 VARCHAR(256) ,
INOUT v_message2 VARCHAR(256) ,
INOUT v_message3 VARCHAR(256) ,
INOUT v_threshold1 FLOAT ,
INOUT v_threshold2 FLOAT ,
INOUT v_threshold3 FLOAT ,
INOUT v_errcode INT ,
INOUT v_errmsg VARCHAR(100))
SWL_return:
begin



   DECLARE v_param1 VARCHAR(100);
   DECLARE v_param2 VARCHAR(100);
   DECLARE v_param3 VARCHAR(256);
   DECLARE v_param1_1 VARCHAR(100);
   DECLARE v_param1_2 VARCHAR(100);
   DECLARE v_param2_1 VARCHAR(100);
   DECLARE v_param2_2 VARCHAR(100);
   DECLARE v_param2_3 VARCHAR(100);
   DECLARE v_param2_4 VARCHAR(100);
   DECLARE v_param2_5 VARCHAR(100);
   DECLARE v_param2_6 VARCHAR(100);
	
   DECLARE v_param2_temp VARCHAR(100);
   DECLARE v_is_roaming INT;
   DECLARE v_loops INT;
   DECLARE v_pos INT;
   DECLARE v_datepart_mm VARCHAR(3);
   DECLARE Swv_RowCount INT;
   DECLARE SWV_param2_temp_Str VARCHAR(100);
	
   set v_bal_warning_mode = -1;
   set v_bal_notif_mode = -1;
   set v_threshold1 = -1;
   set v_threshold2 = -1;
   set v_is_roaming = 0;
   set v_loops = 0;
	
   set v_errcode = -1;
   set v_errmsg = '';
	
	
   if v_roaming <> 1 then
      set v_is_roaming = 1;
   end if;
	
	
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   IFNULL(param1,''), IFNULL(param2,''), IFNULL(param3,'') INTO v_param1,v_param2,v_param3 from CardFeatures  where cardid = v_cardid and featuretype = 25 and status = 1;
   SET Swv_RowCount = ROW_COUNT();
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   if Swv_RowCount = 0 then
	
      set v_errmsg = 'No setting found.';
      LEAVE SWL_return;
   end if;
	
	
   if v_param1 is not null and v_param1 <> '' then
	
      set v_param1_1 = SWF_SUBSTRING(v_param1,1,LOCATE(':',v_param1) -1);
      set v_param1_2 = SWF_SUBSTRING(v_param1,LOCATE(':',v_param1)+1, CHAR_LENGTH(v_param1));
   else
      set v_errmsg = 'Wrong setting at param1.';
      LEAVE SWL_return;
   end if;
	
	
   if v_param1_1 <> '' and v_param1_1 REGEXP('^[+-.$.]?[[0-9,]+...]?$') then
      set v_bal_warning_mode = v_param1_1;
   else
      set v_errmsg = 'Wrong setting at param1_1.';
      LEAVE SWL_return;
   end if;
	
	
   if v_param1_2 <> '' and v_param1_2 REGEXP('^[+-.$.]?[[0-9,]+...]?$') then
      set v_bal_notif_mode = v_param1_2;
   else
      set v_errmsg = 'Wrong setting at param1_2.';
      LEAVE SWL_return;
   end if;
	
   if v_param2 is not null and v_param2 <> '' then
	
		
      set v_param2_temp = v_param2;
      set v_loops = 6 -( CHAR_LENGTH(v_param2_temp) - CHAR_LENGTH(replace(v_param2_temp,':','')));
      while v_loops > 0 DO
         set v_param2_temp = CONCAT_WS('',v_param2_temp,':');
         set v_loops = v_loops -1;
      END WHILE;
      set v_pos = LOCATE(':',v_param2_temp,1);
      set v_param2_1 = SWF_SUBSTRING(v_param2_temp,1,v_pos -1);
      SET SWV_param2_temp_Str = SWF_SUBSTRING(v_param2_temp,v_pos+1, CHAR_LENGTH(v_param2_temp) -v_pos);
      SET v_param2_temp = SWV_param2_temp_Str;
      set v_pos = LOCATE(':',v_param2_temp,1);
      set v_param2_2 = SWF_SUBSTRING(v_param2_temp,1,v_pos -1);
      SET SWV_param2_temp_Str = SWF_SUBSTRING(v_param2_temp,v_pos+1, CHAR_LENGTH(v_param2_temp) -v_pos);
      SET v_param2_temp = SWV_param2_temp_Str;
      set v_pos = LOCATE(':',v_param2_temp,1);
      set v_param2_3 = SWF_SUBSTRING(v_param2_temp,1,v_pos -1);
      SET SWV_param2_temp_Str = SWF_SUBSTRING(v_param2_temp,v_pos+1, CHAR_LENGTH(v_param2_temp) -v_pos);
      SET v_param2_temp = SWV_param2_temp_Str;
      set v_pos = LOCATE(':',v_param2_temp,1);
      set v_param2_4 = SWF_SUBSTRING(v_param2_temp,1,v_pos -1);
      SET SWV_param2_temp_Str = SWF_SUBSTRING(v_param2_temp,v_pos+1, CHAR_LENGTH(v_param2_temp) -v_pos);
      SET v_param2_temp = SWV_param2_temp_Str;
      set v_pos = LOCATE(':',v_param2_temp,1);
      set v_param2_5 = SWF_SUBSTRING(v_param2_temp,1,v_pos -1);
      SET SWV_param2_temp_Str = SWF_SUBSTRING(v_param2_temp,v_pos+1, CHAR_LENGTH(v_param2_temp) -v_pos);
      SET v_param2_temp = SWV_param2_temp_Str;
      set v_pos = LOCATE(':',v_param2_temp,1);
      set v_param2_6 = SWF_SUBSTRING(v_param2_temp,1,v_pos -1);
      SET SWV_param2_temp_Str = SWF_SUBSTRING(v_param2_temp,v_pos+1, CHAR_LENGTH(v_param2_temp) -v_pos);
      SET v_param2_temp = SWV_param2_temp_Str;
   else
      set v_errmsg = 'Wrong setting at param2.';
      LEAVE SWL_return;
   end if;
	
	
   if v_param2_1 <> '' and v_param2_1 REGEXP('^[+-.$.]?[[0-9,]+...]?$') then
      set v_threshold1 = v_param2_1;
   else
      set v_threshold1 = 0.0;
   end if;
	
   if v_param2_2 <> '' and v_param2_2 REGEXP('^[+-.$.]?[[0-9,]+...]?$') then
      set v_threshold2 = v_param2_2;
   else
      set v_threshold2 = 0.0;
   end if;

   if v_param2_5 <> '' and v_param2_5 REGEXP('^[+-.$.]?[[0-9,]+...]?$') then
      set v_threshold3 = v_param2_5;
   else
      set v_threshold3 = 0.0;
   end if;
	
	
   if v_threshold1 = 0.0 and v_threshold2 = 0.0 then
	
      set v_errmsg = 'No threshold has been set.';
      LEAVE SWL_return;
   end if;
	
	
   set v_message1 = '';
   set v_message2 = '';
	
	
   if v_param2_3 <> '' and v_param2_3 REGEXP('^[+-.$.]?[[0-9,]+...]?$') then
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select   text INTO v_message1 from card_messages  where (sitecode = v_sitecode or sitecode = '*')
      and (brand_type = IFNULL(v_brandtype,0) or brand_type = 0)
      and (cardid = v_cardid or cardid = 0)
      and (tariffclass = v_tariffclass or tariffclass = '*')
      and messageid = v_param2_3
      and (roaming = v_is_roaming or roaming = -1)   order by sitecode desc,brand_type desc,cardid desc,tariffclass desc,roaming desc LIMIT 1;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   end if;
	
	
   if v_param2_4 <> '' and v_param2_4 REGEXP('^[+-.$.]?[[0-9,]+...]?$') then
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select   text INTO v_message2 from card_messages  where (sitecode = v_sitecode or sitecode = '*')
      and (brand_type = IFNULL(v_brandtype,0) or brand_type = 0)
      and (cardid = v_cardid or cardid = 0)
      and (tariffclass = v_tariffclass or tariffclass = '*')
      and messageid = v_param2_4
      and (roaming = v_is_roaming or roaming = -1)   order by sitecode desc,brand_type desc,cardid desc,tariffclass desc,roaming desc LIMIT 1;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   end if;

	
	
   if v_param2_6 <> '' and v_param2_6 REGEXP('^[+-.$.]?[[0-9,]+...]?$') then
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select   text INTO v_message3 from card_messages  where (sitecode = v_sitecode or sitecode = '*')
      and (brand_type = IFNULL(v_brandtype,0) or brand_type = 0)
      and (cardid = v_cardid or cardid = 0)
      and (tariffclass = v_tariffclass or tariffclass = '*')
      and messageid = v_param2_6
      and (roaming = v_is_roaming or roaming = -1)   order by sitecode desc,brand_type desc,cardid desc,tariffclass desc,roaming desc LIMIT 1;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   end if;
	
   set v_datepart_mm = right(CONCAT('00',cast(EXTRACT(MONTH FROM TIMESTAMPADD(MONTH,1,CURRENT_TIMESTAMP)) as CHAR(2))),2);
	
   set v_datepart_mm = right(CONCAT('00',cast(EXTRACT(MONTH FROM TIMESTAMPADD(MONTH,1,CURRENT_TIMESTAMP)) as CHAR(2))),2);
	
   if v_message1 <> '' then
      set v_message1 = replace(v_message1,'%nextMM',v_datepart_mm);
   end if;
	
   if v_message2 <> '' then
      set v_message2 = replace(v_message2,'%nextMM',v_datepart_mm);
   end if;

   if v_message3 <> '' then
      set v_message3 = replace(v_message3,'%nextMM',v_datepart_mm);
   end if;
	
   set v_errcode = 0;
   set v_errmsg = 'Okay.';
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `notify_get_config` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `notify_get_config`(sitecode VARCHAR(3),
cardid INT,
brandtype INT,
tariffclass VARCHAR(5))
begin


   IF brandtype is null then
      set brandtype = 0;
   END IF;
   IF tariffclass is null then
      set tariffclass = '*';
   END IF;
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select * from mvno_notification_config a
   where (a.sitecode = sitecode or sitecode = '*')
   and (a.brandtype = brandtype or brandtype = 0)
   and (a.cardid = cardid or cardid = 0)
   and (a.tariffclass = tariffclass or tariffclass = '*')
   order by sitecode desc,brandtype desc,cardid desc,tariffclass desc LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `notify_get_ext_config` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `notify_get_ext_config`(v_sitecode VARCHAR(3),
v_cardid INT,
v_brandtype INT,
v_tariffclass VARCHAR(5),
v_dest VARCHAR(20))
begin



   IF v_brandtype is null then
      set v_brandtype = 0;
   END IF;
   IF v_tariffclass is null then
      set v_tariffclass = '*';
   END IF;
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select * from ext_notification_config 
   where (sitecode = v_sitecode or sitecode = '*')
   and (brandtype = v_brandtype or brandtype = 0)
   and (cardid = v_cardid or cardid = 0)
   and (tariffclass = v_tariffclass or tariffclass = '*')
   and v_dest like CONCAT(prefix_dest,'%')
   order by sitecode desc,brandtype desc,cardid desc,tariffclass desc,prefix_dest desc LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `rad_clear_acclock` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `rad_clear_acclock`(v_username VARCHAR(12), INOUT v_theresult INT)
begin


   delete FROM acclock 
   where
   telcocode = 'ics' and
   custcode = CONCAT('0000',SUBSTR(v_username,1,4)) and
   batchcode = SUBSTR(v_username,5,4) and
   serialcode = SUBSTR(v_username,9,4) and
   switchcode = 'RAD';
	
   SET v_theresult = ROW_COUNT();
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `rad_gset_acclock` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `rad_gset_acclock`(v_username VARCHAR(12), v_password VARCHAR(12), v_did VARCHAR(15), v_cli VARCHAR(20), INOUT v_theresult INT)
begin

   DECLARE v_somesql VARCHAR(500);
   if exists(select  telcocode from acclock 
   where
   telcocode = 'ics' and
   custcode = CONCAT('0000',SUBSTR(v_username,1,4)) and
   batchcode = SUBSTR(v_username,5,4) and
   serialcode = SUBSTR(v_username,9,4) LIMIT 1) then
	
      set v_theresult = 0;
   else
		 insert into acclock(calldate, switchcode, fulldid, ani, pid, telcocode, custcode, batchcode, serialcode, langcode, pincode)
		values(CURRENT_TIMESTAMP, 'RAD', v_did, v_cli, 4503333, 'ICS', CONCAT('0000',SUBSTR(v_username, 1, 4)), SUBSTR(v_username, 5, 4), SUBSTR(v_username, 9, 4), 'RX', v_password);
		
	
      SET @SWV_Stmt = v_somesql;
      PREPARE SWT_Stmt FROM @SWV_Stmt;
      EXECUTE SWT_Stmt;
      DEALLOCATE PREPARE SWT_Stmt;
      set v_theresult = 1;
   end if;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `simplify_prefix` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `simplify_prefix`(v_pfx VARCHAR(16))
begin
   DECLARE SWV_c_ColID INT;
   DECLARE v_pc1 VARCHAR(32);
   DECLARE v_dc1 VARCHAR(32);
   DECLARE v_ac1 INT;
   DECLARE v_pc2 VARCHAR(32);
   DECLARE v_dc2 VARCHAR(32);
   DECLARE v_ac2 INT;
   DECLARE SWV_NO_DATA INT DEFAULT 0;
   declare c cursor for 
   select prefixcode, destcode, isactive, SWC_ColID
   from prefix
   where prefixset = 4
   and prefixcode like CONCAT_WS('',v_pfx,'%')
   order by prefixcode;
   DECLARE CONTINUE HANDLER FOR NOT FOUND SET SWV_NO_DATA = -1;
   open c;
   SET SWV_NO_DATA = 0;
   FETCH c
   into v_pc1,v_dc1,v_ac1,SWV_c_ColID;
   while SWV_NO_DATA = 0 DO
      if v_ac1 = 1 then
         set v_dc2 = null;
         select   prefixcode, destcode, isactive INTO v_pc2,v_dc2,v_ac2 from prefix where prefixset = 4
         and v_pc1 like CONCAT(prefixcode,'%')
         and prefixcode < v_pc1   order by prefixcode desc LIMIT 1;
         if v_dc2 = v_dc1 and v_ac2 = 1 then
    
            
delete FROM prefix WHERE prefix.SWC_ColID = SWV_c_ColID;
         end if;
      end if;
      SET SWV_NO_DATA = 0;
      FETCH c
      into v_pc1,v_dc1,v_ac1,SWV_c_ColID;
   END WHILE;

   close c;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sl_boothshow` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sl_boothshow`(v_custcode CHAR(8))
SWL_return:
begin
   DECLARE v_company CHAR(30);
   DECLARE v_contact CHAR(30);
   DECLARE v_phone CHAR(30);
   DECLARE v_fax CHAR(30);
   DECLARE v_batchcode INT;
   DECLARE v_shop CHAR(30);
   DECLARE v_trffclass CHAR(5);
   DECLARE v_balance FLOAT;
   DECLARE v_Monthlyexp FLOAT;
   DECLARE v_AgentCode VARCHAR(10);
   DECLARE v_credinit FLOAT;
   DECLARE SWV_NO_DATA INT DEFAULT 0;
   declare cu cursor for
   select batchcode, comment 
   from batch 
   where telcocode = 'ics' 
   and custcode = v_custcode
   order by batchcode;
   DECLARE CONTINUE HANDLER FOR NOT FOUND SET SWV_NO_DATA = -1;

	
   if upper(v_custcode) = 'ALL' then
	
      select custcode, company, contact, phonenb1, phonenb2, fax from customer;
      LEAVE SWL_return;
   end if;

   select   company, contact, CONCAT(phonenb1,'/',phonenb2), fax, AgentCode, Monthlyexp INTO v_company,v_contact,v_phone,v_fax,v_AgentCode,v_Monthlyexp from customer where telcocode = 'ics' and custcode = v_custcode;

   if ROW_COUNT() = 0 then 
      



select custcode, company, contact, phonenb1, phonenb2, fax from customer;
      LEAVE SWL_return;
   end if;

   








OPEN cu;
  
   SET SWV_NO_DATA = 0;
   FETCH cu INTO v_batchcode,v_shop;
  
   WHILE SWV_NO_DATA = 0 DO
      select   balance/100, credinit/100 INTO v_balance,v_credinit from batch where telcocode = 'ics' and custcode = v_custcode and batchcode = v_batchcode;
      





select CONCAT('   ',convert(serialcode,CHAR(4))) Booth, ani `Booth Phone No.`,
			firstusg `1st Usage`
      from account
      where telcocode = 'ics'
      and custcode = v_custcode
      and batchcode = v_batchcode
      order by serialcode;
      SET SWV_NO_DATA = 0;
      FETCH cu INTO v_batchcode,v_shop;
   END WHILE;

   CLOSE cu;
	
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sl_checkbatch` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sl_checkbatch`(v_fbn FLOAT)
begin
   DECLARE v_cc CHAR(8);
   DECLARE v_bc INT;
   DECLARE v_bn VARCHAR(16);
   set v_bn = ltrim(SWF_STR(v_fbn,8));
   set v_bn = right(CONCAT_WS('','0000',v_bn),8);
   set v_cc = CONCAT('0000',left(v_bn,4));
   set v_bc = cast(SUBSTR(v_bn,5,4) as SIGNED INTEGER);
   select * from batch where telcocode = 'ics' and custcode = v_cc and batchcode = v_bc;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sl_checktimeclass_daytime` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sl_checktimeclass_daytime`(v_sitecode VARCHAR(3),
v_tclstype INT,
v_tclskey VARCHAR(15))
begin

   DECLARE v_dayname VARCHAR(10);
   DECLARE v_tclsname VARCHAR(15);
   DECLARE v_timeclass INT;
   DECLARE v_dayfrom INT;
   DECLARE v_dayto INT;
   DECLARE v_timefrom INT;
   DECLARE v_timeto INT;
   DECLARE v_timeto2 INT;
   DECLARE v_ctr INT;
   DECLARE v_i INT;
   DECLARE SWV_NO_DATA INT DEFAULT 0;
   declare cc cursor for
   select a.timeclass,b.dayfrom,b.dayto,c.timefrom,c.timeto,c.timeto2
   from daytime a, daycode b, timecode c 
   where a.sitecode = v_sitecode and a.tclstype = v_tclstype and a.tclskey = v_tclskey 
   and a.daycode = b.daycode and a.timecode = c.timecode
   order by b.dayfrom,c.timefrom;
   DECLARE CONTINUE HANDLER FOR NOT FOUND SET SWV_NO_DATA = -1;

   




set v_i = 1;
   while v_i <= 7 DO
      SET v_dayname = case v_i
      when 1 then 'MONDAY'
      when 2 then 'TUEDAY'
      when 3 then 'WEDNESDAY'
      when 4 then 'THURSDAY'
      when 5 then 'FRIDAY'
      when 6 then 'SATURDAY'
      when 7 then 'SUNDAY'
      end;
      
open cc;
      SET SWV_NO_DATA = 0;
      FETCH cc into v_timeclass,v_dayfrom,v_dayto,v_timefrom,v_timeto,v_timeto2;
      set v_ctr = 0;
      while SWV_NO_DATA = 0 DO
         if v_dayfrom <= v_i and v_i <= v_dayto then
			
            if v_timeto2 is not null then 
               set v_timeto = v_timeto2;
            end if;
            SET v_tclsname = case v_timeclass
            when 1 then '  Flat     : '
            when 2 then '  Off Peak : '
            when 3 then '  Peak     : '
            end;
            
set v_ctr = v_ctr+1;
         end if;
         SET SWV_NO_DATA = 0;
         FETCH cc into v_timeclass,v_dayfrom,v_dayto,v_timefrom,v_timeto,v_timeto2;
      END WHILE;
      if v_ctr = 0 then
         
SET @SWV_Null_Var = 0;
      end if;
      set v_i = v_i+1;
      close cc;
   END WHILE;
   
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sl_cheklock` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sl_cheklock`(v_cardno VARCHAR(12))
begin
   select * from acclock where telcocode = 'ics'
   and custcode = CONCAT('0000',left(v_cardno,4))
   and batchcode = cast(SUBSTR(v_cardno,5,4) as SIGNED INTEGER)
   and serialcode = cast(right(v_cardno,4) as SIGNED INTEGER); 

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sl_clearlock` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sl_clearlock`(v_hr INT)
begin

   DECLARE v_d1 DATETIME(3);
 
   IF v_hr is null then
      set v_hr = 2;
   END IF;
   set v_d1 = CURRENT_TIMESTAMP;
   delete from acclock where calldate <= TIMESTAMPADD(HOUR,v_hr*-1,v_d1) and switchcode <> 'RAD';
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sl_cli` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sl_cli`(fbn FLOAT)
begin
select ' ';
select  ' This command is obselete.';
select ' Please use sl_unlockpin or sl_unlockacc';
select ' For a detailed commands please type sl_help';
select ' ';

SET @SWV_Null_Var = 0;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sl_get_tariff_ppm` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sl_get_tariff_ppm`(site VARCHAR(3),
trffclass VARCHAR(4),
timeperiod INT,
charge INT)
begin

   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select destcode, FORMAT((sampunit*60)/(100*sampdelay),4) `price/min`,
  sampdelay,cnxdelay, (cnxunit/100) cnxprice,freesec,premiumdest
   from tariff a where a.trffclass = trffclass
   and a.timeperiod = timeperiod and a.charge = charge
   order by destcode;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sl_insert_tariff_detail` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sl_insert_tariff_detail`(
site    VARCHAR(5),    
 trffcls VARCHAR(4),                
 tmperiod INT,    
 chrge  INT,                
 dnom   INT)
exxxit:
 begin
                 
    DECLARE v_charge VARCHAR(4);                
    DECLARE v_denom VARCHAR(8);                
    DECLARE v_sql VARCHAR(2000);
    IF tmperiod is null then
       set tmperiod = 1;
    END IF;
    errnocol:
    BEGIN
       IF tmperiod is null then
          set tmperiod = 1;
       END IF;
       set v_charge = convert(chrge,CHAR(4));
       set v_denom  = convert(dnom,CHAR(5));
     
       
        if not exists(select * from information_schema.tables a where a.TABLE_NAME = CONCAT_WS('','sampminute_',v_charge))
        then 
           LEAVE errnocol;
        end if;   
        
        if not exists(select * from information_schema.columns b  where b.TABLE_NAME = trffcls LIMIT 1)
        then
           LEAVE errnocol;
        end if; 
                 
 
       delete FROM tariff where sitecode = site and trffclass = trffcls and charge = chrge;
     
 
       set v_sql =CONCAT(
       ' insert into tariff' OR char(13) OR
       ' select ''ICS'',''' OR site OR ''',destcode,''' OR trffcls OR ''',' OR v_charge OR ',' OR tmperiod OR ',' OR char(13) OR
       ' cnxdelay_' OR v_charge OR ' cnxdelay,' OR  char(13) OR
       ' convert(float,cnxminute_' OR v_charge OR ')* (' OR v_denom OR '*1./ convert(float,sampminute_' OR v_charge OR ' )*sampdelay_' OR v_charge OR '/60 /(case sampdelay_' OR v_charge OR ' when 0 then 60 else sampdelay_' OR v_charge OR ' end) )*60 cnxunit,' OR char(13) OR
       ' (case sampdelay_' OR v_charge OR ' when 0 then 60 else sampdelay_' OR v_charge OR ' end) sampdelay,' OR  char(13) OR
       ' ' OR v_denom OR '*1. / convert(float,sampminute_' OR v_charge OR ') * (case sampdelay_' OR v_charge OR ' when 0 then 60 else sampdelay_' OR v_charge OR ' end)/60  sampunit,' OR char(13) OR
       '  0,0,0,0,null' OR char(13) OR
       ' from  ' OR trffcls OR ' where convert(float,sampminute_' OR v_charge OR ')>0' OR char(13) OR
       ' order by destcode',  char(13));                 
 
       SET @SWV_Stmt = v_sql;
       PREPARE SWT_Stmt FROM @SWV_Stmt;
       EXECUTE SWT_Stmt;
       DEALLOCATE PREPARE SWT_Stmt;
       LEAVE exxxit;
    END;
    
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sl_insert_tariff_smscb` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sl_insert_tariff_smscb`(site VARCHAR(5),        
 trffcls VARCHAR(4),                    
 tmperiod INT,        
 chrge INT,                    
 dnom INT,
 acctype INT)
exitt: begin
    
		DECLARE v_sampdelay INT;
		DECLARE Swv_RowCount INT;
        
		IF tmperiod is null then set tmperiod = 1; END IF;
		IF acctype is null then set acctype = 0; END IF;
        
    nosmstrff: BEGIN
		   IF tmperiod is null then set tmperiod = 1; END IF;
		   IF acctype is null then set acctype = 0; END IF;
           
		   if not exists(select  trffclass from tariff  where sitecode = site and trffclass = 'smsa' and charge = 14 LIMIT 1) then 
			  LEAVE nosmstrff;
		   end if;	
           
		
		   delete FROM tariff where sitecode = site and trffclass = trffcls and timeperiod = tmperiod and charge = 14;    
		 
		
		   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
		   select sampdelay INTO v_sampdelay from tariff  where sitecode = site and trffclass = trffcls and charge = 2 LIMIT 1;
		   SET Swv_RowCount = ROW_COUNT();
		   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
		   
		   if Swv_RowCount = 0 then  set v_sampdelay = 60; end if;
       
		   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
		   insert into tariff(telcocode,sitecode,destcode,trffclass,charge,timeperiod,cnxdelay,cnxunit,sampdelay,
           sampunit,freesec,premiumdest,cfreemin,routeclass,percentage)
		   select telcocode,sitecode,destcode,trffcls trffclass, 14 charge,timeperiod,cnxdelay,cnxunit,v_sampdelay sampdelay, 
           (sampunit*v_sampdelay*1/sampdelay)*sampunit,0 freesec,0 premiumdest, 0 cfreemin,0 routeclass,0 percentage
		   from tariff  where sitecode = site and trffclass = 'smsa' and charge = 14;
		   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
       LEAVE exitt;
    END nosmstrff;
		select 'Charge 14 : No SMSA tariff';
 end exitt ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sl_Listcardscancelled` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sl_Listcardscancelled`(v_fromdate CHAR(10), v_todate CHAR(10))
`out`:
begin
   DECLARE v_date3 DATETIME(3);
   if  CHAR_LENGTH(v_fromdate) <> 10 or  CHAR_LENGTH(v_todate) <> 10 then
      
LEAVE `out`;
   end if;
	    
   If v_fromdate = v_todate then
	     
      set  v_date3 = v_todate;
      SET v_date3 =(select TIMESTAMPADD(DAY,1,v_date3));
      

select right(a.custcode,4) Custcode, a.batchcode , count(distinct a.serialcode) Cardsblocked , avg(a.balance+a.totalcons) units
      from account a, blocktab b  where a.telcocode = b.telcocode  and a.langcode = b.langcode and a.pincode = b.pincode  and a.status = 3
      and b.dateblocked >= v_fromdate and b.dateblocked <= v_date3 group by a.custcode,a.batchcode order by a.custcode;
		    
      if ROW_COUNT() = 0 then
		    
         
LEAVE `out`;
      end if;
      LEAVE `out`;
   end if;
   

select right(a.custcode,4) Custcode, a.batchcode , count(distinct a.serialcode) Cardsblocked , avg(a.balance+a.totalcons) units
   from account a, blocktab b  where a.telcocode = b.telcocode  and a.langcode = b.langcode and a.pincode = b.pincode  and a.status = 3
   and b.dateblocked >= v_fromdate and b.dateblocked <= v_todate group by a.custcode,a.batchcode order by a.custcode;
		    
   if ROW_COUNT() = 0 then
      
LEAVE `out`;
   end if;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sl_shopadd` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sl_shopadd`(v_custcode VARCHAR(8), v_shopname VARCHAR(30), v_balance FLOAT)
begin
   DECLARE v_cust VARCHAR(8);
   DECLARE v_batchcode INT;
   select   custcode INTO v_cust from customer where telcocode = 'ics' and custcode = v_custcode;
	
   if v_cust is not null then
	
      select   max(batchcode)+1 INTO v_batchcode from batch where telcocode = 'ics' and custcode = v_custcode;
      if v_batchcode is null then 
         set v_batchcode = 1;
      end if;
      insert into batch  values('ics'  		,	
            v_custcode   ,	
            v_batchcode   ,	
            4    ,			
            'XX'  ,			
            ''  ,			
            ''  ,			
            5    ,			
            v_balance*100     ,	
            v_shopname     ,	
            CURRENT_TIMESTAMP  ,	
            CURRENT_TIMESTAMP   ,	
            '2010-12-25 00:00:00' ,	
            v_balance*100    ,	
            0   ,			
            0     ,			
            'GBP'    ,		
            30     ,		
            ''        ,		
            0    ,			
            0.0	,			
            0.0	,			
            0.0 ,			
            0.0);			
        
		
      if ROW_COUNT() = 1 then
         
SET @SWV_Null_Var = 0;
      else
         
SET @SWV_Null_Var = 0;
      end if;
   else
      
SET @SWV_Null_Var = 0;
   end if;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sl_shopdet` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sl_shopdet`()
begin
   DECLARE v_custcode VARCHAR(4);
   DECLARE v_name VARCHAR(20);
   DECLARE v_date VARCHAR(12);
   DECLARE v_balance FLOAT;
   DECLARE v_totalcons FLOAT;
   DECLARE v_totalc VARCHAR(15);
   DECLARE v_bal VARCHAR(15);
   DECLARE SWV_NO_DATA INT DEFAULT 0;
   declare cur_shop cursor

   for select right(custcode,4) custcode , left(comment,20) name, convert(createdate,CHAR(12)) createdate, (balance/100) Balance, (totalcons/100) Consumption

   from batch where telcocode = 'ics' 

   and custcode > '00008201' and custcode  not in('0000test','link','lnk');
   DECLARE CONTINUE HANDLER FOR NOT FOUND SET SWV_NO_DATA = -1;

   open cur_shop;

   SET SWV_NO_DATA = 0;
   FETCH cur_shop into v_custcode,v_name,v_date,v_balance,v_totalcons;
    
   

while SWV_NO_DATA = 0 DO
      set v_bal        = convert(v_balance,CHAR(15));
      set v_totalc        = convert(v_totalcons,CHAR(15));
      
SET SWV_NO_DATA = 0;
      FETCH cur_shop into v_custcode,v_name,v_date,v_balance,v_totalcons;
   END WHILE;
   close cur_shop;
   

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sl_showtclass` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sl_showtclass`()
begin
   DECLARE v_site CHAR(4);
   DECLARE v_sampdelay INT;
   

select CONCAT('     ',trffclass)
   from  tclass
   order by trffclass;
   


end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sl_unlockacc` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sl_unlockacc`(v_CardNumber VARCHAR(20))
`out`:
begin


   DECLARE v_cc CHAR(8);
   DECLARE v_bc INT;
   DECLARE v_bn VARCHAR(16);
   DECLARE v_sc INT;
   DECLARE v_bal FLOAT;    
   DECLARE v_pc VARCHAR(12);
   DECLARE v_person VARCHAR(10);
   DECLARE v_dateblock VARCHAR(20);
   DECLARE v_sts INT;
   DECLARE v_pincode VARCHAR(30);
   DECLARE v_langcode VARCHAR(4);
   DECLARE v_parm CHAR(200);
    

   if  CHAR_LENGTH(v_CardNumber) > 13 then
    
      
LEAVE `out`;
   end if;

   set v_cc = CONCAT('0000',left(v_CardNumber,4));
   set v_bc = cast(SUBSTR(v_CardNumber,5,4) as SIGNED INTEGER);
   set v_sc = cast(SWF_SUBSTRING(v_CardNumber,9, CHAR_LENGTH(v_CardNumber)) as SIGNED INTEGER);

    
   select   pincode INTO v_pincode from account where  telcocode = 'ics' and custcode = v_cc and batchcode = v_bc and serialcode = v_sc;
    
    
   if ROW_COUNT() = 0 then
    
      
LEAVE `out`;
   end if;

   update account set nbaccess = 0
   where telcocode = 'ics' and custcode = v_cc and batchcode = v_bc and serialcode = v_sc;
    
   
set  v_parm =(CONCAT('sl_unlockacc',',',ltrim(v_CardNumber)));
    
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sl_Updateaccount` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sl_Updateaccount`(v_batchNumber VARCHAR(15), v_serialfrom INT, v_serialto INT,  v_trffclass CHAR(4))
`out`:
begin
   DECLARE v_telcocode CHAR(3);
   DECLARE v_cc CHAR(8);
   DECLARE v_bc INT;
   DECLARE v_bn VARCHAR(16);
   DECLARE v_parm CHAR(200);
   DECLARE v_serfr VARCHAR(4);
   DECLARE v_serto VARCHAR(4);
   if  CHAR_LENGTH(v_batchNumber) > 8 then
      
LEAVE `out`;
   end if;
   set v_cc = CONCAT('0000',left(v_batchNumber,4));
   set v_bc = cast(SUBSTR(v_batchNumber,5,4) as SIGNED INTEGER);
   set v_serfr = convert(v_serialfrom,CHAR(4));

    

   select   telcocode INTO v_telcocode from account where  telcocode = 'ICS' and custcode = v_cc and batchcode = v_bc and serialcode = v_serialfrom;
    
    
   if ROW_COUNT() = 0 then
    
      
LEAVE `out`;
   end if;
    
    
   update account set  trffclass = v_trffclass
   where telcocode = 'ICS' and custcode = v_cc and batchcode = v_bc and serialcode >= v_serialfrom and serialcode <= v_serialto;
    

   set v_serto = convert(v_serialto,CHAR(4));

   




    
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sms_get_cnxcharge_v2` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sms_get_cnxcharge_v2`(v_telcocode VARCHAR(3),
v_sitecode VARCHAR(3),
v_trffclass VARCHAR(4),
v_master_trffclass VARCHAR(4),
v_destcode VARCHAR(80),
v_charge INT,
INOUT v_cnxunit FLOAT ,
INOUT v_cc_factor FLOAT)
begin


   DECLARE v_timeclass INT;
   DECLARE v_pday INT;  
   DECLARE v_ptime INT; 
   DECLARE v_now DATETIME(3);

   set v_cnxunit = 0.0;
   set v_cc_factor = 0.0;
   set v_now = CURRENT_TIMESTAMP;
	
   set v_pday = 1+(DAYOFWEEK(v_now)+v_datefirst -2)%7;  
   set v_ptime = EXTRACT(HOUR FROM v_now)*100+EXTRACT(MINUTE FROM v_now);  
   
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   a.timeclass INTO v_timeclass from daytime a, daycode b, timecode c  where sitecode = v_sitecode and tclstype = 1 and (tclskey = v_trffclass or tclskey = '*')
   and a.daycode = b.daycode and a.timecode = c.timecode
   and v_pday between b.dayfrom and b.dayto
   and ((c.timefrom <= v_ptime and v_ptime < c.timeto) or
  		(c.timeto2 < c.timeto and v_ptime < c.timeto2))   order by tclstype,tclskey desc LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ; 
 	
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   a.cnxunit, b.cnxcharge_ccfactor INTO v_cnxunit,v_cc_factor from tariff a  join pack_cnxcharge b
   on b.destcode = a.destcode
   and b.charge = a.charge and b.timeperiod = a.timeperiod where a.telcocode = v_telcocode and a.sitecode = v_sitecode and a.trffclass = v_master_trffclass and b.trffclass = v_trffclass
	
   and a.destcode = v_destcode and a.charge = v_charge and (a.timeperiod = v_timeclass or a.timeperiod = 1)   order by a.timeperiod desc;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;    

   set v_cnxunit = IFNULL(v_cnxunit,0.0);
   set v_cc_factor = IFNULL(v_cc_factor,0.0);

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sms_get_cnxcharge_v3` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sms_get_cnxcharge_v3`(v_telcocode VARCHAR(3),
v_sitecode VARCHAR(3),
v_trffclass VARCHAR(4),
v_master_trffclass VARCHAR(4),
v_destcode VARCHAR(80),
v_charge INT,
INOUT v_cnxunit FLOAT ,
INOUT v_cc_factor FLOAT ,
INOUT v_cc_mode INT , 
INOUT v_cc_delay INT  
)
begin



   DECLARE v_timeclass INT;
   DECLARE v_pday INT;  
   DECLARE v_ptime INT; 
   DECLARE v_now DATETIME(3);

   set v_cnxunit = 0.0;
   set v_cc_factor = 0.0;
   set v_now = CURRENT_TIMESTAMP;
	
   set v_pday = 1+(DAYOFWEEK(v_now)+v_datefirst -2)%7;  
   set v_ptime = EXTRACT(HOUR FROM v_now)*100+EXTRACT(MINUTE FROM v_now);  
   
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   a.timeclass INTO v_timeclass from daytime a, daycode b, timecode c  where sitecode = v_sitecode and tclstype = 1 and (tclskey = v_trffclass or tclskey = '*')
   and a.daycode = b.daycode and a.timecode = c.timecode
   and v_pday between b.dayfrom and b.dayto
   and ((c.timefrom <= v_ptime and v_ptime < c.timeto) or
  		(c.timeto2 < c.timeto and v_ptime < c.timeto2))   order by tclstype,tclskey desc LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ; 
 	
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   a.cnxunit, b.cnxcharge_ccfactor, b.cnxcharge_mode, b.cnxcharge_delay INTO v_cnxunit,v_cc_factor,v_cc_mode,v_cc_delay from tariff a  join pack_cnxcharge b
   on b.destcode = a.destcode
   and b.charge = a.charge and b.timeperiod = a.timeperiod where a.telcocode = v_telcocode and a.sitecode = v_sitecode and a.trffclass = v_master_trffclass and b.trffclass = v_trffclass
   and a.destcode = v_destcode and a.charge = v_charge and (a.timeperiod = v_timeclass or a.timeperiod = 1)   order by a.timeperiod desc LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;    

   set v_cnxunit = IFNULL(v_cnxunit,0.0);
   set v_cc_factor = IFNULL(v_cc_factor,0.0);

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sms_get_destcode` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sms_get_destcode`(telcocode VARCHAR(3),          
  sitecode VARCHAR(3),          
  trffclass VARCHAR(4),          
  to_address VARCHAR(30),          
  charge INT,          
  INOUT destcode VARCHAR(64) ,          
  INOUT errcode INT ,          
  INOUT errmsg VARCHAR(64))
SWL_return:
BEGIN
	
   DECLARE v_prefixset INT;
   DECLARE Swv_RowCount INT;
   DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
   BEGIN
      SET @SWV_Error = 1;
   END;          
   IF telcocode is null then
      set telcocode = 'ics';
   END IF;
   SET @SWV_Error = 0;
   set errcode = 21;          
          
		
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   IFNULL(prefixset,4) INTO v_prefixset from tariffclass a where a.telcocode = telcocode and a.sitecode = sitecode and a.trffclass = trffclass;
   SET Swv_RowCount = ROW_COUNT();
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;          
   if Swv_RowCount <= 0 or @SWV_Error <> 0 then
		
      set errmsg = CONCAT_WS('','Prefix not found. Nb=',to_address);
      LEAVE SWL_return;
   end if;           
          
		
		
		
		
          
		
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   destcode INTO destcode from prefix b where b.sitecode = sitecode
   and prefixset = v_prefixset
   and prefixcode between left(to_address,2) and to_address
   and left(to_address, CHAR_LENGTH(prefixcode)) = prefixcode   order by prefixcode desc LIMIT 1;
   SET Swv_RowCount = ROW_COUNT();
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;          
          
   if Swv_RowCount = 0 then
		
      set errmsg = CONCAT_WS('','Prefix not found. Nb=',to_address,'. pfxset=',ltrim(rtrim(v_prefixset)));
      LEAVE SWL_return;
   end if;          
          
   set errcode = 0;          
   set errmsg = 'OK';          
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sms_get_tariff_by_destcode` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sms_get_tariff_by_destcode`(telcocode VARCHAR(3),
sitecode VARCHAR(3),
trffclass VARCHAR(4),
to_address VARCHAR(11),
destcode VARCHAR(64),
charge INT,  
INOUT sampunit FLOAT ,
INOUT costunit FLOAT ,
INOUT trunk VARCHAR(64) ,
INOUT errcode INT ,
INOUT errmsg VARCHAR(255))
SWL_return:
begin


   DECLARE v_now DATETIME(3);
   DECLARE v_timeclass INT;
   DECLARE v_pday INT;
   DECLARE v_ptime INT;
   DECLARE Swv_RowCount INT;
   DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
   BEGIN
      SET @SWV_Error = 1;
   END;
	
   IF telcocode is null then
      set telcocode = 'ics';
   END IF;
   SET @SWV_Error = 0;
   set errcode = 21;
   set v_now = CURRENT_TIMESTAMP;
   set costunit = 0.0;
   set trunk = '';	
	
	
   set v_pday = 1+(DAYOFWEEK(v_now)+v_datefirst -2)%7;
   set v_ptime = EXTRACT(HOUR FROM v_now)*100+EXTRACT(MINUTE FROM v_now);
	
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   a.timeclass INTO v_timeclass from  daytime a, daycode b, timecode c  where a.sitecode = sitecode and tclstype = 1 and (a.tclskey = trffclass or tclskey = '*')
   and a.daycode = b.daycode and a.timecode = c.timecode
   and v_pday between b.dayfrom and b.dayto
   and ((c.timefrom <= v_ptime and v_ptime < c.timeto) or
  		(c.timeto2 < c.timeto and v_ptime < c.timeto2))   order by tclstype,tclskey desc LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
	
	
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   IFNULL(sampunit,0.0), IFNULL(trunk,'') INTO costunit,trunk from sms_cost d where d.sitecode = sitecode and prefixcode = left(to_address, CHAR_LENGTH(prefixcode))   order by  CHAR_LENGTH(prefixcode) desc LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
  
	
	
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   case
   when premiumdest = 5 then 0.0 else sampunit end INTO sampunit from tariff e  where e.telcocode = telcocode and e.sitecode = sitecode and e.destcode = destcode
   and e.trffclass = trffclass and e.charge = charge and (timeperiod = v_timeclass or timeperiod = 1)   order by timeperiod desc LIMIT 1;
   SET Swv_RowCount = ROW_COUNT();
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
	
   if Swv_RowCount <= 0 or @SWV_Error <> 0 then
	
      set errmsg = CONCAT_WS('','Tariff not found. Dest=',rtrim(destcode),'. Trfcls=',trffclass,
      '. Charge=',ltrim(rtrim(charge)));
      LEAVE SWL_return;
   end if;
	
   set errcode = 0;
   set errmsg = 'OK';
	
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sms_get_xlat` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sms_get_xlat`(sitecode VARCHAR(8),    
prefix VARCHAR(30),    
trunkcode VARCHAR(8),    
direction INT ,    
switchcode VARCHAR(3),    
nbtype INT ,
xlatset INT ,
INOUT xlat_sms VARCHAR(200))
begin

	
   DECLARE v_pfx VARCHAR(30);
   DECLARE v_xlatpfx VARCHAR(30);

	
   IF nbtype is null then
      set nbtype = -1;
   END IF;
   IF xlatset is null then
      set xlatset = 0;
   END IF;
   set xlat_sms = prefix; 	

   if xlatset = 0 then
	
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select   xlatpfx, prefix INTO v_xlatpfx,v_pfx from xlat a where a.sitecode = sitecode
      and (switchcode = switchcode or switchcode = '*')
      and SUBSTRING(prefix,1, CHAR_LENGTH(prefix)) = prefix
      and (trunkcode = trunkcode  or trunkcode = '*')
      and direction = direction
      and (numbertype = nbtype or nbtype = -1 or numbertype is null or numbertype = -1)   order by switchcode desc,pfxlen desc,trunkcode desc,numbertype desc LIMIT 1;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   else
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select   xlatpfx, prefix INTO v_xlatpfx,v_pfx from xlat_byset b where b.sitecode = sitecode
      and (switchcode = switchcode or switchcode = '*')
      and SUBSTRING(prefix,1, CHAR_LENGTH(prefix)) = prefix
      and (trunkcode = trunkcode  or trunkcode = '*')
      and direction = direction
      and (numbertype = nbtype or nbtype = -1 or numbertype is null or numbertype = -1)
      and xlatset = xlatset   order by switchcode desc,pfxlen desc,trunkcode desc,numbertype desc LIMIT 1;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   end if;
	
   if (xlat_sms is not Null and xlat_sms <> '') and (v_pfx is not Null and v_pfx <> '') then
      set xlat_sms = CONCAT_WS('',v_xlatpfx,SUBSTRING(prefix, CHAR_LENGTH(v_pfx)+1, CHAR_LENGTH(prefix)));
   end if; 
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sms_get_xlat_test2` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sms_get_xlat_test2`(v_sitecode VARCHAR(8),    
v_prefix VARCHAR(30),    
v_trunkcode VARCHAR(8),    
v_direction INT ,    
v_switchcode VARCHAR(3),    
v_nbtype INT ,
v_xlatset INT ,
INOUT v_xlat_sms VARCHAR(200))
begin

	
   DECLARE v_pfx VARCHAR(30);
   DECLARE v_xlatpfx VARCHAR(30);

	
   IF v_nbtype is null then
      set v_nbtype = -1;
   END IF;
   IF v_xlatset is null then
      set v_xlatset = 0;
   END IF;
   set v_xlat_sms = v_prefix; 	

   if v_xlatset = 0 then
	
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select   xlatpfx, prefix INTO v_xlatpfx,v_pfx from  xlat  where sitecode = v_sitecode
      and (switchcode = v_switchcode or switchcode = '*')
      and SWF_SUBSTRING(v_prefix,1, CHAR_LENGTH(prefix)) = prefix
      and (trunkcode = v_trunkcode  or trunkcode = '*')
      and direction = v_direction
      and (numbertype = v_nbtype or v_nbtype = -1 or numbertype is null or numbertype = -1)   order by switchcode desc,pfxlen desc,trunkcode desc,numbertype desc LIMIT 1;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   else
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select   xlatpfx, prefix INTO v_xlatpfx,v_pfx from   xlat_byset  where sitecode = v_sitecode
      and (switchcode = v_switchcode or switchcode = '*')
      and SWF_SUBSTRING(v_prefix,1, CHAR_LENGTH(prefix)) = prefix
      and (trunkcode = v_trunkcode  or trunkcode = '*')
      and direction = v_direction
      and (numbertype = v_nbtype or v_nbtype = -1 or numbertype is null or numbertype = -1)
      and xlatset = v_xlatset   order by switchcode desc,pfxlen desc,trunkcode desc,numbertype desc LIMIT 1;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   end if;
	
   if (v_xlat_sms is not Null and v_xlat_sms <> '') and (v_pfx is not Null and v_pfx <> '') then
      set v_xlat_sms = CONCAT_WS('',v_xlatpfx,SWF_SUBSTRING(v_prefix, CHAR_LENGTH(v_pfx)+1, CHAR_LENGTH(v_prefix)));
   end if; 
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sms_pack_cnxcharge` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sms_pack_cnxcharge`(v_sitecode VARCHAR(3),
v_trffclass VARCHAR(4),
v_cc VARCHAR(8),
v_bc INT,
v_sc INT,
v_master_trffclass VARCHAR(4),
v_destcode VARCHAR(80),
v_charge INT,
INOUT v_cnx_charge FLOAT ,
INOUT v_errcode INT ,
INOUT v_errmsg VARCHAR(100) ,
v_authtype INT)
SWL_return:
begin


   DECLARE v_sampunit FLOAT;
   DECLARE v_cnx_unit FLOAT;
   DECLARE v_cc_mode INT;
   DECLARE v_cc_delay INT;
   DECLARE v_cc_factor FLOAT;
   DECLARE v_pack_cnxunit FLOAT;
   DECLARE v_pack_sampunit FLOAT;
   DECLARE v_ischarge INT;
	
   DECLARE v_timeperiod INT;
   DECLARE v_pday INT;
   DECLARE v_ptime INT;
   DECLARE v_now DATETIME(3);
   DECLARE Swv_RowCount INT;
   DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
   BEGIN
      SET @SWV_Error = 1;
   END;
	
   IF v_authtype is null then
      set v_authtype = 0;
   END IF;
   SET @SWV_Error = 0;
   set v_cnx_unit = 0.0;
   set v_cc_factor = 0.0;
   set v_now = CURRENT_TIMESTAMP;
	
   set v_errcode = -1;
   set v_errmsg = '';
	
   set v_pday = 1+(DAYOFWEEK(v_now)+v_datefirst -2)%7;  
   set v_ptime = EXTRACT(HOUR FROM v_now)*100+EXTRACT(MINUTE FROM v_now);  
   
   
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   a.timeclass INTO v_timeperiod from daytime a, daycode b, timecode c  where sitecode = v_sitecode and tclstype = 1 and (tclskey = v_trffclass or tclskey = '*')
   and a.daycode = b.daycode and a.timecode = c.timecode
   and v_pday between b.dayfrom and b.dayto
   and ((c.timefrom <= v_ptime and v_ptime < c.timeto) or
  		(c.timeto2 < c.timeto and v_ptime < c.timeto2))   order by tclstype,tclskey desc LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ; 
	
	
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   cnxunit, sampunit INTO v_cnx_unit,v_sampunit from tariff  where telcocode = 'ics'
   and sitecode = v_sitecode
   and destcode = v_destcode
   and trffclass = v_master_trffclass
   and charge = v_charge
   and (timeperiod = v_timeperiod or timeperiod = 1)   order by timeperiod desc LIMIT 1;
   SET Swv_RowCount = ROW_COUNT();
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   if @SWV_Error <> 0 or Swv_RowCount < 1 then
	
      set v_errmsg = 'Failed to get tariff for cnxcharge';
      LEAVE SWL_return;
   end if;
	
	
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   cnxcharge_mode, cnxcharge_delay, cnxcharge_ccfactor INTO v_cc_mode,v_cc_delay,v_cc_factor from  pack_cnxcharge  where (trffclass = v_trffclass or trffclass = '*')
   and (destcode = v_destcode or destcode = '*')
   and (charge = v_charge or charge = -1)
   and (timeperiod = v_timeperiod or timeperiod = 1)
   and (IFNULL(master_trffclass,'*') = v_master_trffclass or IFNULL(master_trffclass,'*') = '*')   order by trffclass desc,destcode desc,charge desc,timeperiod desc LIMIT 1;
   SET Swv_RowCount = ROW_COUNT();
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   if @SWV_Error <> 0 or Swv_RowCount < 1 then
	
      set v_errmsg = 'Failed to get pack_cnxcharge for cnxcharge';
      LEAVE SWL_return;
   end if;
	
	
   if v_cc_mode in(1,2) then
	
      if v_cc_factor > 0.0 then
         set v_cnx_charge = v_cc_factor;
      else
         set v_cnx_charge = v_cc_factor*v_cnx_unit*(-1);
      end if;
   end if;
	
   if v_cc_mode = 3 then
	
      if v_cc_factor > 0.0 then
         set v_cnx_charge = v_cc_factor+v_cnx_unit;
      else
         set v_cnx_charge = v_cc_factor*v_cnx_unit*(-1)+v_cnx_unit;
      end if;
   end if;
	
   if v_cc_mode = 4 then
	
      if v_cc_factor > 0.0 then
         set v_cnx_charge = v_cc_factor;
      else
         set v_cnx_charge = v_cc_factor*v_sampunit*(-1);
      end if;
   end if;
	
   if v_cc_mode = 5 then
	
      if v_cc_factor > 0.0 then
         set v_cnx_charge = v_cc_factor+v_cnx_unit;
      else
         set v_cnx_charge = v_cc_factor*v_sampunit*(-1)+v_cnx_unit;
      end if;
   end if;
	
   if v_cc_mode = 6 then
	
		
      if v_authtype in(1,2,3) then
         CALL get_packcnx_ischarge(v_cc,v_bc,v_sc,v_cc_delay,v_ischarge);
      else
         CALL get_packcnx_ischarge(v_cc,v_bc,v_sc,v_cc_delay,v_ischarge);
      end if;
      if v_ischarge = 1 then
		
         if v_cc_factor > 0.0 then
            set v_cnx_charge = v_cc_factor;
         else
            set v_cnx_charge = v_cnx_unit*v_cc_factor*(-1);
         end if;
      end if;
   end if;
	
   if v_cc_mode = 7 then
	
		
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select   cnxunit, sampunit INTO v_pack_cnxunit,v_pack_sampunit from tariff  where telcocode = 'ics'
      and sitecode = v_sitecode
      and destcode = v_destcode
      and trffclass = v_trffclass
      and charge = v_charge
      and (timeperiod = v_timeperiod or timeperiod = 1)   order by timeperiod desc LIMIT 1;
      SET Swv_RowCount = ROW_COUNT();
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
      if @SWV_Error <> 0 or Swv_RowCount < 1 then
		
         set v_errmsg = 'Failed to get cnxunit and sampunit of pack for cnxcharge';
         LEAVE SWL_return;
      end if;
      if v_cc_factor > 0.0 then
         set v_cnx_charge = v_cc_factor+v_pack_cnxunit;
      else
         set v_cnx_charge = v_cc_factor*v_pack_sampunit*(-1)+v_pack_cnxunit;
      end if;
   end if;
	
   set v_errcode = 0;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `tp_rms_xlated` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `tp_rms_xlated`(v_sitecode VARCHAR(3),
v_mobileno VARCHAR(20),
INOUT v_xlat_prefix VARCHAR(20) ,
INOUT v_pref_ln INT ,
INOUT v_errcode INT ,
INOUT v_errmsg VARCHAR(500))
SWL_return:
begin



   DECLARE Swv_RowCount INT;
   set v_errcode = -1;
   set v_errmsg = '';
	
	
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   xlat_prefix,  CHAR_LENGTH(prefix) INTO v_xlat_prefix,v_pref_ln from xlat_tp_rms  where sitecode = v_sitecode
   and SWF_SUBSTRING(v_mobileno,1, CHAR_LENGTH(prefix)) = prefix   order by  CHAR_LENGTH(prefix) desc LIMIT 1;
   SET Swv_RowCount = ROW_COUNT();
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   if Swv_RowCount = 0 then
	
      set v_errmsg = 'No xlat found.';
      LEAVE SWL_return;
   end if;
	
   set v_errcode = 0;
   set v_errmsg = 'Success';
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `trff_ActivateTClass` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `trff_ActivateTClass`(v_site	   VARCHAR(3),
v_trffClass VARCHAR(4))
begin
   update tariffClass 
   set moddate = CURRENT_TIMESTAMP
   where telcocode = 'ICS' and sitecode = v_site and trffclass = v_trffClass;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `trff_copyTariff` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `trff_copyTariff`(site VARCHAR(3),
 trffclass	VARCHAR(4),
 timeperiod	INT,
 type INT,
 ppm INT,
 accType INT)
begin
  
  
     DECLARE v_sql VARCHAR(8000);
     DECLARE v_espmgt_link VARCHAR(20);
  
     if type = 1 then 
  
			SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
			select   a.name INTO v_espmgt_link from espprm.site a where a.sitecode = site;
			SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
		
		
			insert into tariff(telcocode,sitecode,destcode,trffclass,charge,timeperiod,cnxdelay,
			cnxunit,sampdelay,sampunit,freesec,premiumdest,cfreemin,routeclass,percentage)
			select telcocode,sitecode,destcode,trffclass,charge,timeperiod,cnxdelay,
			cnxunit,sampdelay,sampunit,freesec,premiumdest,cfreemin,routeclass,percentage 
			from espmgt.toriff a  where a.siteCode=site and a.trffclass=trffclass and a.timeperiod=timeperiod ;

		
			if site <> 'LOW' and ppm = 0 then 
			   CALL sl_insert_tariff_smscb(site,trffclass,timeperiod,14,0,accType);
		   
		
				update tariffclass a set a.moddate = CURRENT_TIMESTAMP
				where a.telcocode = 'ICS' and a.sitecode = site and a.trffclass = trffclass;
			end if;
        
     else
     
        if type = 2 then 

			insert into tariff(telcocode,sitecode,destcode,trffclass,charge,timeperiod,cnxdelay,
			cnxunit,sampdelay,sampunit,freesec,premiumdest,cfreemin,routeclass,percentage)
			select telcocode,sitecode,destcode,trffclass,charge,timeperiod,cnxdelay,
			cnxunit,sampdelay,sampunit,freesec,premiumdest,cfreemin,routeclass,percentage 
			from espmgt.toriff b where b.siteCode=site and b.trffclass= trffclass  and b.timeperiod=timeperiod;
        end if;

     end if;
  end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `trff_get_progcharge` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `trff_get_progcharge`(v_site VARCHAR(3),
v_tcls VARCHAR(4))
begin
   select timeperiod,charge,destcode,minsec,maxsec,
         case when ccfactor > 0 then CONCAT(replace(ccfactor,' ',''),' unit') else
      CONCAT(replace(ccfactor,' ',''),' cnx') end progcharge from progcharge1
   where trffclass = v_tcls
   order by timeperiod,charge,destcode,minsec;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `trff_InsertProgCharge` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `trff_InsertProgCharge`(v_destcode VARCHAR(32),
v_charge VARCHAR(100),
v_values VARCHAR(2000),
v_trffclass VARCHAR(4),
v_timeperiod INT)
begin

   DECLARE v_lala VARCHAR(32);
   DECLARE v_lili INT;
   DECLARE v_lulu VARCHAR(50);
 
   DECLARE v_a INT;
   DECLARE v_p INT;
   DECLARE v_c INT;
   DECLARE v_h INT;
   DECLARE v_Sql VARCHAR(5000);
  
   DECLARE v_x INT;
   DECLARE v_y INT;
   DECLARE v_t INT;
   DECLARE v_o INT;
   DECLARE v_minsec INT;
   DECLARE v_maxsec INT;
   DECLARE v_ccfactor INT;
   DECLARE v_count INT;
   DECLARE v_val VARCHAR(10);
   set v_p = 1;
   set v_a = LOCATE(',',v_destcode,v_p);
   while v_a > 0 DO
 
    
      set v_lala = SWF_SUBSTRING(v_destcode,v_p,v_a -v_p);
    

    
      set v_h = 1;
      set v_c = LOCATE(',',v_charge,v_h);
      while v_c > 0 DO
      
         set v_lili = SWF_SUBSTRING(v_charge,v_h,v_c -v_h);
      


         if exists(select * from progcharge1 where trffclass = v_trffclass and destcode = v_lala and
         charge = v_lili and timeperiod = v_timeperiod LIMIT 1) then
  
            delete from progcharge1 where trffclass = v_trffclass and destcode = v_lala and
            charge = v_lili and timeperiod = v_timeperiod;
            
end if;


      
         set v_y = 1;
         set v_x = LOCATE(';',v_values,v_y);
         while v_x > 0 DO
        
            set v_lulu = SWF_SUBSTRING(v_values,v_y,v_x -v_y);
        
	
            set v_t = 1;
            set v_o = LOCATE(',',v_lulu,v_t);
            set v_count = 1;
            while v_count < 4 DO
            
               set v_val = SWF_SUBSTRING(v_lulu,v_t,v_o -v_t);
           
               if v_count = 1 then
                  set v_minsec = v_val;
               end if;
               if v_count = 2 then
                  set v_maxsec = v_val;
               end if;
               if v_count = 3 then
                  set v_ccfactor = v_val;
               end if;
               set v_t = v_o+1;
               set v_o = LOCATE(',',v_lulu,v_t);
               set v_count = v_count+1;
            END WHILE;
	
	






   
            set v_Sql =CONCAT(
            'insert into progcharge1(trffclass,destcode,minsec,maxsec,ccfactor,charge,timeperiod)
   	values(''', v_trffclass, ''',''', v_lala, ''',', ltrim(v_minsec), ',', ltrim(v_maxsec), ',', ltrim(v_ccfactor), ',', ltrim(v_lili), ',', ltrim(v_timeperiod),  ')');
            

SET @SWV_Stmt = v_Sql;
            PREPARE SWT_Stmt FROM @SWV_Stmt;
            EXECUTE SWT_Stmt;
            DEALLOCATE PREPARE SWT_Stmt;
   

            set v_y = v_x+1;
            set v_x = LOCATE(';',v_values,v_y);
         END WHILE;
        

         set v_h = v_c+1;
         set v_c = LOCATE(',',v_charge,v_h);
      END WHILE;
      

      set v_p = v_a+1;
      set v_a = LOCATE(',',v_destcode,v_p);
   END WHILE;
   
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `trff_InsertProgCharge_old` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `trff_InsertProgCharge_old`(v_destcode VARCHAR(32),
v_charge VARCHAR(100),
v_values VARCHAR(2000),
v_trffclass VARCHAR(4),
v_timeperiod INT)
begin

   DECLARE v_lala VARCHAR(32);
   DECLARE v_lili INT;
   DECLARE v_lulu VARCHAR(50);
 
   DECLARE v_a INT;
   DECLARE v_p INT;
   DECLARE v_c INT;
   DECLARE v_h INT;
   DECLARE v_Sql VARCHAR(5000);
  
   DECLARE v_x INT;
   DECLARE v_y INT;
   DECLARE v_t INT;
   DECLARE v_o INT;
   DECLARE v_minsec INT;
   DECLARE v_maxsec INT;
   DECLARE v_ccfactor INT;
   DECLARE v_count INT;
   DECLARE v_val VARCHAR(10);
   set v_p = 1;
   set v_a = LOCATE(',',v_destcode,v_p);
   while v_a > 0 DO
    
      set v_lala = SWF_SUBSTRING(v_destcode,v_p,v_a -v_p);
    
    
      set v_h = 1;
      set v_c = LOCATE(',',v_charge,v_h);
      while v_c > 0 DO
      
         set v_lili = SWF_SUBSTRING(v_charge,v_h,v_c -v_h);
      
         if exists(select * from progcharge1 where trffclass = v_trffclass and destcode = v_lala and
         charge = v_lili and timeperiod = v_timeperiod LIMIT 1) then
  
            delete from progcharge1 where trffclass = v_trffclass and destcode = v_lala and
            charge = v_lili and timeperiod = v_timeperiod;
            
end if;
      
         set v_y = 1;
         set v_x = LOCATE(';',v_values,v_y);
         while v_x > 0 DO
        
            set v_lulu = SWF_SUBSTRING(v_values,v_y,v_x -v_y);
        
	
            set v_t = 1;
            set v_o = LOCATE(',',v_lulu,v_t);
            set v_count = 1;
            while v_count < 4 DO
            
               set v_val = SWF_SUBSTRING(v_lulu,v_t,v_o -v_t);
           
               if v_count = 1 then
                  set v_minsec = v_val;
               end if;
               if v_count = 2 then
                  set v_maxsec = v_val;
               end if;
               if v_count = 3 then
                  set v_ccfactor = v_val;
               end if;
               set v_t = v_o+1;
               set v_o = LOCATE(',',v_lulu,v_t);
               set v_count = v_count+1;
            END WHILE;
	





   
            set v_Sql =CONCAT(
            'insert into progcharge1(trffclass,destcode,minsec,maxsec,ccfactor,charge,timeperiod)
   	values(''', v_trffclass, ''',''', v_lala, ''',', ltrim(v_minsec), ',', ltrim(v_maxsec), ',', ltrim(v_ccfactor), ',', ltrim(v_lili), ',', ltrim(v_timeperiod),  ')');
            

SET @SWV_Stmt = v_Sql;
            PREPARE SWT_Stmt FROM @SWV_Stmt;
            EXECUTE SWT_Stmt;
            DEALLOCATE PREPARE SWT_Stmt;
   
            set v_y = v_x+1;
            set v_x = LOCATE(';',v_values,v_y);
         END WHILE;
        
         set v_h = v_c+1;
         set v_c = LOCATE(',',v_charge,v_h);
      END WHILE;
      
      set v_p = v_a+1;
      set v_a = LOCATE(',',v_destcode,v_p);
   END WHILE;
   
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `trff_replaceTariff_v2` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `trff_replaceTariff_v2`(site   VARCHAR(3),  
     trffclass VARCHAR(4),  
     timeperiod INT,
     charge INT)
begin
         
        DECLARE v_i INT;  
        DECLARE v_espmgt_link VARCHAR(20);
        DECLARE v_sql VARCHAR(8000); 
     
		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
			select name INTO v_espmgt_link from espprm.site  where sitecode = site;
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
     
     	
        set v_i = charge;
        
	if exists(select 1 from espmgt.toriff a where a.siteCode=site and a.trffclass=trffclass and a.charge =cast(v_i as CHAR(30))  and a.timeperiod= ltrim(timeperiod) limit 1) then
			if exists(select  1 from tariff b where b.siteCode= site  and b.trffclass=trffclass  and b.charge= ltrim(v_i)  and timeperiod=ltrim(timeperiod) limit 1) then  
				delete from tariff c where c.siteCode= site  and c.trffclass=trffclass and c.charge = cast(v_i as CHAR(30)) and timeperiod=ltrim(timeperiod) ;
     		end if ;
    
			insert into tariff (telcocode,sitecode,destcode,trffclass,charge,timeperiod,cnxdelay,cnxunit,sampdelay,sampunit,freesec,premiumdest,cfreemin,routeclass,percentage)  
     		select telcocode,sitecode,destcode,trffclass,charge,timeperiod,cnxdelay, cnxunit,sampdelay,sampunit,freesec,premiumdest,cfreemin,routeclass,percentage   
			from espmgt.toriff c
            where c.siteCode= site 
            and c.trffclass= trffclass
            and c.charge=ltrim(v_i) and c.timeperiod= ltrim(timeperiod) 
			and c.charge =cast(v_i as CHAR(30));
		end if;
     end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `trf_AddTariffClass` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `trf_AddTariffClass`(INOUT v_errCode INT ,
v_site VARCHAR(3),
v_card INT,
v_tariff VARCHAR(8),
v_comment VARCHAR(64),
v_prefixset INT,
v_minunit FLOAT,
v_nbcalld INT,
v_chargesec INT,
v_maintdelay INT,
v_maintunit FLOAT,
v_maintnb INT,
v_cnxmode INT,
v_freecnxdelay INT,
v_onego FLOAT,
v_progressive INT,
v_vcalld INT,
v_historydate FLOAT,
v_historyaccess FLOAT,
v_historydest FLOAT,
v_historysample FLOAT,
v_bestgrade VARCHAR(3),
v_worstgrade VARCHAR(3),
v_currcode VARCHAR(4),
v_creditinit FLOAT,
v_graderoute VARCHAR(7))
Endx:
begin
   DECLARE v_now DATETIME(3);
   Failed:
   BEGIN
      set v_now = CURRENT_TIMESTAMP;
      set v_errCode = 0;
      START TRANSACTION;
      insert into tariffclass(telcocode, sitecode, trffclass, maintdelay, maintunit, firstcnx, newdelay, trffmode,
		prefixset, createdate, moddate, comment, cnxcharge, freecnxdelay, ceilingtt, calld,
		minunit, cnxunit, progcharge, onegocharge, vcalld, routeclass, maxnbcharge,
		def_routecls, prem_routecls, historycharge, acchischarge, desthischarge, samphischarge,
		currcode,gradeWorst, gradeBest, gradecode, chgpersec, initcredit)
	values('ICS', v_site, v_tariff, v_maintdelay, v_maintunit, 0, 0, 1,
		v_prefixset,v_now,v_now, v_comment, v_cnxmode, v_freecnxdelay, null, v_nbcalld,
		v_minunit, 0.0, v_progressive, v_onego, v_vcalld, null, v_maintnb,
		0, null, v_historydate, v_historyaccess, v_historydest,v_historysample, v_currcode,
		null, null, v_graderoute, v_chargesec, v_creditinit);

      if ROW_COUNT() = 0 then   
         LEAVE Failed;
      end if;
      insert into cardtariffclass(cardid, sitecode, trffclass)
values(v_card, v_site, v_tariff);

      if ROW_COUNT() = 0 then   
         LEAVE Failed;
      end if;
      COMMIT;
      LEAVE Endx;
   END;
   begin
      ROLLBACK;
      set v_errCode = -1;
      LEAVE Endx;
   end;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `trf_UpdateTariffClass` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `trf_UpdateTariffClass`(INOUT v_errCode INT ,
v_site VARCHAR(3),
v_card VARCHAR(32),
v_tariff VARCHAR(8),
v_comment VARCHAR(20),
v_prefixset INT,
v_minunit FLOAT,
v_nbcalld INT,
v_chargesec INT,
v_maintdelay INT,
v_maintunit FLOAT,
v_maintnb INT,
v_cnxmode INT,
v_freecnxdelay INT,
v_onego FLOAT,
v_progressive INT,
v_vcalld INT,
v_historydate FLOAT,
v_historyaccess FLOAT,
v_historydest FLOAT,
v_historysample FLOAT,
v_bestgrade VARCHAR(3),
v_worstgrade VARCHAR(3),
v_graderoute VARCHAR(7))
begin
   update tariffclass set
   maintdelay = v_maintdelay,maintunit = v_maintunit,prefixset = v_prefixset,moddate = CURRENT_TIMESTAMP,
   comment = v_comment,cnxcharge = v_cnxmode,freecnxdelay = v_freecnxdelay,
   calld = v_nbcalld,minunit = v_minunit,progcharge = v_progressive,
   onegocharge = v_onego,vcalld = v_vcalld,maxnbcharge = v_maintnb,historycharge = v_historydate,
   acchischarge = v_historyaccess,desthischarge = v_historydest,
   samphischarge = v_historysample,gradecode = v_graderoute,chgpersec = v_chargesec
   where telcocode = 'ics' and sitecode = v_site and trffclass = v_tariff;
   if ROW_COUNT() = 0 then
      set v_errCode = -1;
   else
      set v_errCode = 0;
   end if;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `tt_trff_replaceTariff_v211` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `tt_trff_replaceTariff_v211`(v_site   VARCHAR(3),  
v_trffclass VARCHAR(4),  
v_timeperiod INT,
v_charge INT)
begin
   DECLARE v_i INT;  
	 set v_i = v_charge;
   if exists(select * from toriff where siteCode = v_site and trffclass = v_trffclass and charge =v_i and timeperiod = ltrim(v_timeperiod) LIMIT 1) then  
		  
      if exists(select * from tariff where siteCode = v_site and trffclass = v_trffclass and charge = ltrim(v_i) and timeperiod = ltrim(v_timeperiod) LIMIT 1) then  
						   
         delete from  tariff where siteCode = v_site and  trffclass = v_trffclass and charge = v_i and timeperiod = ltrim(v_timeperiod);
      end if;  
      insert into tariff(telcocode,sitecode,destcode,trffclass,charge,timeperiod,cnxdelay,
					cnxunit,sampdelay,sampunit,freesec,premiumdest,cfreemin,routeclass,percentage)
      select telcocode,sitecode,destcode,trffclass,charge,timeperiod,cnxdelay,
					cnxunit,sampdelay,sampunit,freesec,premiumdest,cfreemin,routeclass,percentage
      from  toriff
      where siteCode = v_site and trffclass = v_trffclass and charge = ltrim(v_i) and timeperiod = ltrim(v_timeperiod)
      and charge = v_i;
   end if;  
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `tvselectddi` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `tvselectddi`(v_publishno VARCHAR(12))
begin
   select * from access
   where publishno like CONCAT_WS('','%',v_publishno);
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `USP_web_update_packconnectioncharge` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `USP_web_update_packconnectioncharge`(v_tariifClass VARCHAR(4),          
v_charge INT,          
v_timePeriod INT,          
v_destcode VARCHAR(64),  
v_cnxchargeMode INT,  
v_cnxchargeDelay INT,  
v_cnxchargeccfactor FLOAT)
begin
   DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
   BEGIN
      SET @SWV_Error = 1;
   END;
   SET @SWV_Error = 0;
   Update pack_cnxcharge
   set
   cnxcharge_mode = v_cnxchargeMode,cnxcharge_delay =  v_cnxchargeDelay,cnxcharge_ccfactor = v_cnxchargeccfactor
   where
   trffclass = v_tariifClass and
   charge = v_charge and
   timeperiod = v_timePeriod and
   destcode = v_destcode;  
   select case when @SWV_Error <> 0 then -1 else 0 end;   
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `vox_addaccount` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `vox_addaccount`(
    tc VARCHAR(8),
 	cc VARCHAR(8),
 	bc INT,
 	sc INT,
 	langcode VARCHAR(8),
 	did	VARCHAR(6),
 	bal FLOAT,
 	trffclass VARCHAR(8),
 	cli1 VARCHAR(30),
 	cli2 VARCHAR(30),
 	cli3 VARCHAR(30))
SWL_return:
 begin
    DECLARE v_status INT;
    DECLARE v_freeminute INT;
    DECLARE v_unit FLOAT;
    DECLARE v_accstat INT;
    set v_freeminute = 100;
    if bal > 0.0 then
       set v_accstat = 1;
    else
       set v_accstat = 3;
    end if;
    set cli1 = replace(cli1,' ','');
    set cli2 = replace(cli2,' ','');
    set cli3 = replace(cli3,' ','');
    if cli1 <> '' then
 		  insert into cliaccount(telcocode,did, ani, pincode, custcode,batchcode, serialcode)
 		values(tc,did,cli1,'',cc,bc,sc);
       if ROW_COUNT() = 0 then
          set v_status = 0;
          select v_status status;
          LEAVE SWL_return;
       end if;
    end if;
    if cli2 <> '' then
 		  insert into cliaccount(telcocode,did, ani, pincode, custcode,batchcode, serialcode)
 		values(tc,did,cli2,'',cc,bc,sc);
       if ROW_COUNT() = 0 then
          set v_status = 0;
          select v_status status;
          LEAVE SWL_return;
       end if;
    end if;
    if cli3 <> '' then
 		  insert into cliaccount(telcocode,did, ani, pincode, custcode,batchcode, serialcode)
 		values(tc,did,cli3,'',cc,bc,sc);
       if ROW_COUNT() = 0 then
          set v_status = 0;
          select v_status status;
          LEAVE SWL_return;
       end if;
    end if;
    set v_unit = 0;
    select   unitexcg INTO v_unit from ccy where sitecode = 'LO2' and currcode = 'GBP';
 	
    insert into account(telcocode,custcode,batchcode,serialcode,status,pincode,langcode,acctype,phonenb,firstusg,
		spdial,cug,did,ani,balance,nbaccess,maxaccess,trffclass,security,totalcons,
		monthlim,startdate,enddate,lang,cnxcount,currcode)
	values(tc,cc,bc,sc,v_accstat,CONCAT('voxpad_',right(CONCAT('0000',(rtrim(ltrim(sc)))),4)),langcode,4,'',null,'','',did,'',bal*v_unit,0,0,trffclass,0,0.0,v_freeminute,CURRENT_TIMESTAMP,null,'',1,'GBP');
    
    
    if ROW_COUNT() = 0 then
 	
       set v_status = 0;
       select v_status status;
       LEAVE SWL_return;
    end if;
 
    set v_status = 1;
    select v_status status;
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `vox_addbalance` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `vox_addbalance`(v_tc VARCHAR(8),
	v_cc VARCHAR(8),
	v_bc INT,
	v_sc INT,
	v_bal FLOAT)
SWL_return:
begin
   DECLARE v_prevbal FLOAT;
   DECLARE v_status INT;
   DECLARE v_unit FLOAT;
   DECLARE v_accstat INT;

   if v_bal > 0.0 then
      set v_accstat = 1;
   else
      set v_accstat = 3;
   end if;
   set v_unit = 0;
   select   unitexcg INTO v_unit from ccy where sitecode = 'LO2' and currcode = 'GBP';
   select   balance INTO v_prevbal from account where telcocode = v_tc and custcode = v_cc and batchcode = v_bc and serialcode = v_sc;
   update account set status = v_accstat,balance = balance+v_bal*v_unit where telcocode = v_tc and custcode = v_cc and batchcode = v_bc and serialcode = v_sc;
   if ROW_COUNT() = 0 then
      set v_status = 0;
      select v_status status;
      LEAVE SWL_return;
   end if;
   set v_status = 1;
   select v_status status;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `web_as_tariffclass_list` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `web_as_tariffclass_list`()
begin

   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select trffclass from tariffclass
   order by trffclass;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `web_as_timeclass_list` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `web_as_timeclass_list`()
begin
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select timeclass,comment from timeclass;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `web_insert_tariff` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `web_insert_tariff`(
site    VARCHAR(5),    
 trffcls VARCHAR(4),                
 tmperiod INT,    
 chrge  INT,                
 dnom   INT)
exxxit:
 begin
                 
    DECLARE v_charge VARCHAR(4);                
    DECLARE v_denom VARCHAR(8);                
    DECLARE v_sql VARCHAR(2000);
    IF tmperiod is null then
       set tmperiod = 1;
    END IF;
    errnocol:
    BEGIN
       IF tmperiod is null then
          set tmperiod = 1;
       END IF;
       set v_charge = convert(chrge,CHAR(4));
       set v_denom  = convert(dnom,CHAR(5));
       
       if not exists(select * from information_schema.tables a where a.TABLE_NAME = CONCAT_WS('','sampminute_',v_charge))
       then 
          LEAVE errnocol;
       end if;   
       
       if not exists(select * from information_schema.columns b  where b.TABLE_NAME = 'Sheet1$' LIMIT 1)
       then
          LEAVE errnocol;
       end if; 
       
                  
     
 
       set v_sql =CONCAT(
       ' insert into  toriff' OR char(13) OR
       ' select ''ICS'',''' OR site OR ''',destcode,''' OR trffcls OR ''',' OR v_charge OR ',' OR tmperiod OR ',' OR char(13) OR
       ' cnxdelay_' OR v_charge OR ' cnxdelay,' OR  char(13) OR
       ' convert(float,cnxminute_' OR v_charge OR ')* (' OR v_denom OR '*1./ convert(float,sampminute_' OR v_charge OR ' )*sampdelay_' OR v_charge OR '/60 /(case sampdelay_' OR v_charge OR ' when 0 then 60 else sampdelay_' OR v_charge OR ' end) )*60 cnxunit,' OR char(13) OR
       ' (case sampdelay_' OR v_charge OR ' when 0 then 60 else sampdelay_' OR v_charge OR ' end) sampdelay,' OR  char(13) OR
       ' ' OR v_denom OR '*1. / convert(float,sampminute_' OR v_charge OR ') * (case sampdelay_' OR v_charge OR ' when 0 then 60 else sampdelay_' OR v_charge OR ' end)/60  sampunit,' OR char(13) OR
       '  0,0,0,0,null' OR char(13) OR
       ' from  [Sheet1$] where convert(float,sampminute_' OR v_charge OR ')>0' OR char(13) OR
       ' order by destcode',  char(13));                 
 
       SET @SWV_Stmt = v_sql;
       PREPARE SWT_Stmt FROM @SWV_Stmt;
       EXECUTE SWT_Stmt;
       DEALLOCATE PREPARE SWT_Stmt;
       LEAVE exxxit;
    END;
    
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `xget_acclock` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `xget_acclock`(v_site VARCHAR(3), 
 v_switch VARCHAR(5))
begin

   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select  pid,calldate from acclock 
   where switchcode = v_switch
   order by calldate LIMIT 200;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ; 
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-21  9:51:10
