-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: affiliate
-- ------------------------------------------------------
-- Server version	8.0.44-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `affiliate`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `affiliate` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `affiliate`;

--
-- Table structure for table `affiliate_commisson_info`
--

DROP TABLE IF EXISTS `affiliate_commisson_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `affiliate_commisson_info` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userid` int DEFAULT NULL,
  `total_purchase_amount` float DEFAULT NULL,
  `comm_per` int DEFAULT NULL,
  `company_id` int DEFAULT NULL,
  `comm_amount` float DEFAULT NULL,
  `pay_Reference_No` varchar(50) DEFAULT NULL,
  `created` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `affiliate_incentive_config`
--

DROP TABLE IF EXISTS `affiliate_incentive_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `affiliate_incentive_config` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userid` int DEFAULT NULL,
  `typename` varchar(50) DEFAULT NULL,
  `aff_type` int DEFAULT NULL,
  `status` int DEFAULT NULL,
  `inc_percentage` float DEFAULT NULL,
  `duration` int DEFAULT NULL,
  `bonus_amount` float DEFAULT NULL,
  `allocation_range` int DEFAULT NULL,
  `created` datetime DEFAULT CURRENT_TIMESTAMP,
  `createdby` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `affiliate_incentive_config_log`
--

DROP TABLE IF EXISTS `affiliate_incentive_config_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `affiliate_incentive_config_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userid` int DEFAULT NULL,
  `typename` varchar(50) DEFAULT NULL,
  `aff_type` int DEFAULT NULL,
  `status` int DEFAULT NULL,
  `inc_percentage` float DEFAULT NULL,
  `duration` int DEFAULT NULL,
  `bonus_amount` float DEFAULT NULL,
  `allocation_range` int DEFAULT NULL,
  `created` datetime DEFAULT CURRENT_TIMESTAMP,
  `createdby` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=250 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `affiliate_incentive_configuration`
--

DROP TABLE IF EXISTS `affiliate_incentive_configuration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `affiliate_incentive_configuration` (
  `typeid` int NOT NULL AUTO_INCREMENT,
  `typename` varchar(20) DEFAULT NULL,
  `aff_type` int DEFAULT NULL,
  `status` int DEFAULT NULL,
  `inc_percentage` float DEFAULT NULL,
  `duration` int DEFAULT NULL,
  `bonus_amount` float DEFAULT NULL,
  PRIMARY KEY (`typeid`)
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `affiliate_incentive_type_info`
--

DROP TABLE IF EXISTS `affiliate_incentive_type_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `affiliate_incentive_type_info` (
  `typeid` int NOT NULL AUTO_INCREMENT,
  `typename` varchar(10) DEFAULT NULL,
  `ranges` int DEFAULT NULL,
  PRIMARY KEY (`typeid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `affiliate_pay_per_comm_allocation`
--

DROP TABLE IF EXISTS `affiliate_pay_per_comm_allocation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `affiliate_pay_per_comm_allocation` (
  `id` int NOT NULL AUTO_INCREMENT,
  `pay_per` varchar(10) DEFAULT NULL,
  `pay_per_comm` int DEFAULT NULL,
  `pay_per_value` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `affiliate_referral_code_click_info`
--

DROP TABLE IF EXISTS `affiliate_referral_code_click_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `affiliate_referral_code_click_info` (
  `clickid` int NOT NULL AUTO_INCREMENT,
  `referral_code` varchar(50) DEFAULT NULL,
  `landing_link` varchar(50) DEFAULT NULL,
  `ipaddress` varchar(50) DEFAULT NULL,
  `created` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`clickid`)
) ENGINE=InnoDB AUTO_INCREMENT=130 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `affiliate_referral_code_signup_info`
--

DROP TABLE IF EXISTS `affiliate_referral_code_signup_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `affiliate_referral_code_signup_info` (
  `signupid` int NOT NULL AUTO_INCREMENT,
  `referral_code` varchar(50) DEFAULT NULL,
  `landing_link` varchar(50) DEFAULT NULL,
  `productId` int DEFAULT NULL,
  `source_prod_id` varchar(50) DEFAULT NULL,
  `prod_amount` float DEFAULT NULL,
  `tier_id` int DEFAULT NULL,
  `ipaddress` varchar(50) DEFAULT NULL,
  `created` datetime DEFAULT CURRENT_TIMESTAMP,
  `free_paid` int DEFAULT NULL,
  `tier_duration` int DEFAULT NULL,
  `company_id` int DEFAULT NULL,
  `pay_reference_no` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`signupid`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `affiliate_user_account_dtl`
--

DROP TABLE IF EXISTS `affiliate_user_account_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `affiliate_user_account_dtl` (
  `account_id` int NOT NULL AUTO_INCREMENT,
  `fk_userid` int DEFAULT NULL,
  `account_name` varchar(150) DEFAULT NULL,
  `bankname` varchar(150) DEFAULT NULL,
  `account_number` int DEFAULT NULL,
  `sortcode` int DEFAULT NULL,
  `created` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`account_id`),
  KEY `fk_affiliate_user_account_dtl_fk_userid` (`fk_userid`),
  CONSTRAINT `fk_affiliate_user_account_dtl_fk_userid` FOREIGN KEY (`fk_userid`) REFERENCES `affiliate_user_master_dtl` (`userid`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `affiliate_user_company_link_dtl`
--

DROP TABLE IF EXISTS `affiliate_user_company_link_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `affiliate_user_company_link_dtl` (
  `linkid` int NOT NULL AUTO_INCREMENT,
  `fk_userid` int DEFAULT NULL,
  `ref_source_link` text,
  `created` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`linkid`),
  KEY `fk_affiliate_user_company_link_dtl_fk_userid` (`fk_userid`),
  CONSTRAINT `fk_affiliate_user_company_link_dtl_fk_userid` FOREIGN KEY (`fk_userid`) REFERENCES `affiliate_user_master_dtl` (`userid`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `affiliate_user_master_dtl`
--

DROP TABLE IF EXISTS `affiliate_user_master_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `affiliate_user_master_dtl` (
  `userid` int NOT NULL AUTO_INCREMENT,
  `company_name` varchar(150) DEFAULT NULL,
  `firstname` varchar(150) DEFAULT NULL,
  `lastname` varchar(150) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `mobilenumber` varchar(20) DEFAULT NULL,
  `postcode` varchar(10) DEFAULT NULL,
  `address` text,
  `city` text,
  `country` text,
  `business_type` int DEFAULT NULL,
  `business_othername` varchar(150) DEFAULT NULL,
  `business_desc` text,
  `aff_status` int DEFAULT NULL,
  `userrole` int DEFAULT NULL,
  `aff_password` varchar(20) DEFAULT NULL,
  `isdeleted` int DEFAULT '0',
  `created` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated` datetime DEFAULT NULL,
  `updatedby` int DEFAULT NULL,
  `payment_method` int DEFAULT NULL,
  `payment_email` varchar(100) DEFAULT NULL,
  `payment_accountid` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`userid`),
  KEY `fk_affiliate_user_master_dtl_userrole` (`userrole`),
  CONSTRAINT `fk_affiliate_user_master_dtl_userrole` FOREIGN KEY (`userrole`) REFERENCES `affiliate_user_role` (`roleid`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=1191 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `affiliate_user_referral_code`
--

DROP TABLE IF EXISTS `affiliate_user_referral_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `affiliate_user_referral_code` (
  `refcodeid` int NOT NULL AUTO_INCREMENT,
  `fk_userid` int NOT NULL,
  `productid` int NOT NULL,
  `region` int NOT NULL,
  `referral_code` varchar(50) DEFAULT NULL,
  `referral_link` varchar(50) NOT NULL,
  `created` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`refcodeid`,`fk_userid`,`productid`,`region`,`referral_link`),
  KEY `fk_affiliate_user_referral_code_fk_userid` (`fk_userid`),
  CONSTRAINT `fk_affiliate_user_referral_code_fk_userid` FOREIGN KEY (`fk_userid`) REFERENCES `affiliate_user_master_dtl` (`userid`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `affiliate_user_referral_view_info`
--

DROP TABLE IF EXISTS `affiliate_user_referral_view_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `affiliate_user_referral_view_info` (
  `viewid` int NOT NULL AUTO_INCREMENT,
  `referral_code` varchar(50) NOT NULL,
  `socialsource` varchar(50) NOT NULL,
  `sourceurl` varchar(50) NOT NULL,
  `desturl` varchar(50) NOT NULL,
  `ipaddress` varchar(20) NOT NULL,
  `created` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`viewid`,`referral_code`,`socialsource`,`sourceurl`,`desturl`,`ipaddress`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `affiliate_user_role`
--

DROP TABLE IF EXISTS `affiliate_user_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `affiliate_user_role` (
  `roleid` int NOT NULL AUTO_INCREMENT,
  `rolename` varchar(150) DEFAULT NULL,
  `rolestatus` int DEFAULT '1',
  `created` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`roleid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping events for database 'affiliate'
--

--
-- Dumping routines for database 'affiliate'
--
/*!50003 DROP PROCEDURE IF EXISTS `affiliate_approved_user_comm_report` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `affiliate_approved_user_comm_report`(
    	p_from varchar(10),
    	p_to varchar(10)
  )
Begin
  
 	select a.userid as affiliateid ,concat(a.firstname,' ',a.lastname) as member_name,sum(f.total_purchase_amount) as revenue_generated,a.country ,f.comm_amount
 	from affiliate_user_master_dtl a
 	join affiliate_commisson_info f on a.userid = f.userid  and comm_amount <> 0 and total_purchase_amount <> 0
 	where aff_status = 1 
 	and ((cast(a.created as DATE) >= p_from) or (ifnull(p_from,'') = '')) 
 	and ((cast(a.created as DATE) <= p_to) or (ifnull(p_to,'') = ''))
 	group by a.userid ,concat(a.firstname,' ',a.lastname),f.comm_amount;
  
  End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `affiliate_create_comm_incentive_structure` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `affiliate_create_comm_incentive_structure`(
  p_userid INT,
  p_comm_info_xml LONGTEXT,
  p_createdby int
  )
BEGIN
  
  	DECLARE v_errcode INT; 
  	DECLARE v_errmsg VARCHAR(160);  
  
  	DECLARE v_typename text ;
  	DECLARE v_aff_type text;
  	DECLARE v_status text ;
  	DECLARE v_inc_percentage text;
  	DECLARE v_duration text;
  	DECLARE v_bonus_amount text;
  	DECLARE v_allocation_range text;
           
          sp_exit:BEGIN
          
  		DROP TEMPORARY TABLE IF EXISTS tt_temp_aff_comm_structure;          
  		create TEMPORARY table tt_temp_aff_comm_structure
  		(
  			id INT AUTO_INCREMENT PRIMARY KEY, typename varchar(50), aff_type int, status int, inc_percentage float, duration int, bonus_amount float, allocation_range int,createdby int
  		);
  		
         drop temporary table if exists xml_typename_tbl; create temporary table xml_typename_tbl( id int auto_increment primary key,typename varchar(50));
         drop temporary table if exists xml_aff_type_tbl; create temporary table xml_aff_type_tbl( id int auto_increment primary key,aff_type int);
         drop temporary table if exists xml_status_tbl; create temporary table xml_status_tbl( id int auto_increment primary key,status float);
         drop temporary table if exists xml_inc_percentage_tbl; create temporary table xml_inc_percentage_tbl( id int auto_increment primary key,inc_percentage float);
         drop temporary table if exists xml_duration_tbl; create temporary table xml_duration_tbl( id int auto_increment primary key,duration int);
         drop temporary table if exists xml_bonus_amount_tbl; create temporary table xml_bonus_amount_tbl( id int auto_increment primary key,bonus_amount float);
         drop temporary table if exists xml_allocation_range_tbl; create temporary table xml_allocation_range_tbl( id int auto_increment primary key,allocation_range int);
         
        SELECT 
            REPLACE(EXTRACTVALUE(p_comm_info_xml, '//typename[1]'),' ',','),          REPLACE(EXTRACTVALUE(p_comm_info_xml, '//aff_type[1]'),' ',','),
            REPLACE(EXTRACTVALUE(p_comm_info_xml, '//status[1]'),' ',','),          	REPLACE(EXTRACTVALUE(p_comm_info_xml,'//inc_percentage[1]'),' ',','),
            REPLACE(EXTRACTVALUE(p_comm_info_xml,'//duration[1]'),' ',','),          	REPLACE(EXTRACTVALUE(p_comm_info_xml,'//bonus_amount[1]'),' ',','),
            REPLACE(EXTRACTVALUE(p_comm_info_xml,'//allocation_range[1]'),' ',',')
        	INTO v_typename , v_aff_type , v_status , v_inc_percentage,v_duration,v_bonus_amount,v_allocation_range;	
    
           call unifiedring.Split(v_typename,','); insert into xml_typename_tbl(typename) select Items from unifiedring.tt_Split_temptable;
           call unifiedring.Split(v_aff_type,','); insert into xml_aff_type_tbl(aff_type) select Items from unifiedring.tt_Split_temptable;
           call unifiedring.Split(v_status,','); insert into xml_status_tbl(status) select Items from unifiedring.tt_Split_temptable;
           call unifiedring.Split(v_inc_percentage,','); insert into xml_inc_percentage_tbl(inc_percentage) select Items from unifiedring.tt_Split_temptable;     
           call unifiedring.Split(v_duration,','); insert into xml_duration_tbl(duration) select Items from unifiedring.tt_Split_temptable;     
           call unifiedring.Split(v_bonus_amount,','); insert into xml_bonus_amount_tbl(bonus_amount) select Items from unifiedring.tt_Split_temptable;     
           call unifiedring.Split(v_allocation_range,','); insert into xml_allocation_range_tbl(allocation_range) select Items from unifiedring.tt_Split_temptable;
                
           insert into tt_temp_aff_comm_structure(typename, aff_type, status, inc_percentage, duration, bonus_amount,allocation_range,createdby)
           select typename, aff_type, status, inc_percentage, duration, bonus_amount, allocation_range,p_createdby
           from xml_typename_tbl a 
           left join xml_aff_type_tbl b on a.id = b.id
           left join xml_status_tbl c on a.id = c.id
           left join xml_inc_percentage_tbl d on a.id = d.id
           left join xml_duration_tbl e on a.id = e.id
           left join xml_bonus_amount_tbl f on a.id = f.id
           left join xml_allocation_range_tbl g on a.id = g.id;
                
                

             IF EXISTS(SELECT  1 FROM affiliate_incentive_config d WHERE  d.userid = p_userid LIMIT 1) 
             then
				insert into affiliate_incentive_config_log( userid, typename, aff_type, status, inc_percentage, duration, bonus_amount, allocation_range, created,createdby)
				select userid, typename, aff_type, status, inc_percentage, duration, bonus_amount, allocation_range,current_timestamp,p_createdby  
				from affiliate_incentive_config e WHERE  e.userid = p_userid;
				   
				DELETE FROM affiliate_incentive_config e WHERE  e.userid = p_userid;
             end if;
             
             INSERT INTO  affiliate_incentive_config(userid, typename, aff_type, status, inc_percentage, duration, bonus_amount, allocation_range, created, createdby)
             SELECT p_userid, typename, aff_type, status, inc_percentage, duration, bonus_amount, allocation_range, current_timestamp,p_createdby FROM tt_temp_aff_comm_structure;
             
             IF ROW_COUNT() > 0 then
                SET v_errcode = 0;
                SET v_errmsg = 'Success to create the Incentive Structre';
             end if;
          END;
          select v_errcode as errcode,v_errmsg as errmsg; 
       
       END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `affiliate_create_referral_code_click_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `affiliate_create_referral_code_click_info`(
	p_referral_code varchar(50),
	p_landing_link varchar(50),
	p_ipaddress varchar(50)
)
Begin

	declare v_errcode int default -1;
    declare v_errmsg varchar(100) default 'Failure';

    
    sp_exit : Begin

		if not exists(select 1 from affiliate_user_referral_code where referral_code = p_referral_code limit 1) then
			set v_errcode = -1;
            set v_errmsg = 'Product referral code not found';
            leave sp_exit;
        end if;
    
		if exists(select 1 from affiliate_referral_code_click_info where referral_code = p_referral_code and ipaddress = p_ipaddress and cast(created as date) = cast(current_timestamp as date) limit 1) then
			set v_errcode = -1;
            set v_errmsg = 'Today limit reached';
            leave sp_exit;
        end if;
                
			insert into affiliate_referral_code_click_info(referral_code,landing_link,ipaddress)
            values(p_referral_code,p_landing_link,p_ipaddress);
            
            if row_count() > 0 then
				set v_errcode = 0;
				set v_errmsg = 'Success'; 
            End if;
            
    End;
	select v_errcode as errcode, v_errmsg as errmsg;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `affiliate_create_referral_code_signup_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `affiliate_create_referral_code_signup_info`(
 	p_referral_code varchar(50),
 	p_landing_link varchar(50),
 	p_productId int,
 	p_source_prod_id varchar(50),
 	p_prod_amount float,
 	p_tier_id int,
 	p_ipaddress varchar(50),
 	p_free_paid int, 
 	p_tier_duration int,
 	p_company_id int,
 	p_pay_reference_no varchar(50)
    )
Begin
    
    	declare v_errcode int default -1;
        declare v_errmsg varchar(100) default 'Failure';
        declare v_fk_userid int;
        declare v_comm_amount float;
        declare v_inc_percentage int;
        declare v_alloc_range int;
    
        sp_exit : Begin
        	if not exists(select 1 from affiliate_user_referral_code where referral_code = p_referral_code limit 1) then
    			set v_errcode = -1;
                set v_errmsg = 'Product referral code not found';
                leave sp_exit;
            end if;
            
            select fk_userid into v_fk_userid from affiliate_user_referral_code where referral_code = p_referral_code limit 1;
            
         
    			insert into affiliate_referral_code_signup_info(referral_code,landing_link,productId,source_prod_id,prod_amount,tier_id,ipaddress,free_paid,tier_duration,company_id,pay_reference_no)
                values(p_referral_code,p_landing_link,p_productId,p_source_prod_id,p_prod_amount,p_tier_id,p_ipaddress,p_free_paid,p_tier_duration,p_company_id,p_pay_reference_no);
                
                if row_count() > 0 then
    				set v_errcode = 0;
    				set v_errmsg = 'Success'; 
                               
					select count(1) into v_alloc_range from affiliate_referral_code_signup_info a where a.referral_code = p_referral_code and free_paid = 3;
					select inc_percentage into v_inc_percentage from affiliate_incentive_config where duration = p_tier_duration and userid = v_fk_userid and allocation_range >= v_alloc_range order by allocation_range asc limit 1;
                               
                    set v_comm_amount = p_prod_amount * (ifnull(v_inc_percentage,0)/100.00);

					insert into affiliate_commisson_info(userid,total_purchase_amount,comm_per,company_id,comm_amount,pay_Reference_No)
					values(v_fk_userid,p_prod_amount,v_inc_percentage,p_company_id,v_comm_amount,p_pay_reference_no);
                    
                    
                End if;    
        end;
        	select v_errcode as errcode, v_errmsg as errmsg;
    End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `affiliate_create_referral_code_view_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `affiliate_create_referral_code_view_info`(
 	p_referral_code varchar(50),
 	p_socialsource varchar(50),
    p_sourceurl varchar(50),
    p_desturl varchar(50),
 	p_ipaddress varchar(50)
 )
Begin
 
 	declare v_errcode int default -1;
	declare v_errmsg varchar(100) default 'Failure';
 
     
     sp_exit : Begin
 
 		if not exists(select 1 from affiliate_user_referral_code where referral_code = p_referral_code limit 1) then
 			set v_errcode = -1;
             set v_errmsg = 'Product referral code not found';
             leave sp_exit;
         end if;
     
 		if exists(select 1 from affiliate_user_referral_view_info where referral_code = p_referral_code and ipaddress = p_ipaddress 
					and socialsource = p_socialsource and sourceurl = p_sourceurl and desturl = p_desturl and cast(created as date) = cast(current_timestamp as date) limit 1) then
			set v_errcode = -1;
			set v_errmsg = 'Today limit reached';
			leave sp_exit;
         end if;
                 
 			insert into affiliate_user_referral_view_info(referral_code,socialsource,sourceurl,desturl,ipaddress)
			values(p_referral_code,p_socialsource,p_sourceurl,p_desturl,p_ipaddress);
             
             if row_count() > 0 then
 				set v_errcode = 0;
 				set v_errmsg = 'Success'; 
             End if;
             
     End;
 	select v_errcode as errcode, v_errmsg as errmsg;
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `affiliate_create_user_master_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `affiliate_create_user_master_dtl`(
 p_company_name varchar(150),
 p_firstname varchar(150),
 p_lastname varchar(150),
 p_email varchar(30),
 p_mobilenumber varchar(20),
 p_postcode varchar(10),
 p_address text,
 p_city text,
 p_country text,
 p_business_type int,
 p_business_othername varchar(150),
 p_business_desc text,
 p_aff_status int,
 p_userrole int,
 p_ref_source_link text,
 p_account_name varchar(150),
 p_bankname varchar(150),
 p_account_number int,
 p_sortcode int
 )
Begin
 
 	declare v_errcode int;
     declare v_errmsg varchar(50) default 'failure';
     declare v_userid int;
     
     sp_exit : Begin
     
 		DROP TEMPORARY TABLE IF EXISTS temp_ref_source_link; CREATE TEMPORARY TABLE temp_ref_source_link (ref_source_link VARCHAR(255));
 		call Split(p_ref_source_link,','); INSERT INTO temp_ref_source_link (ref_source_link) select items from tt_Split_temptable;
 		
		if exists(select 1 from affiliate_user_master_dtl where email = p_email limit 1)then
			set v_errcode = -1;
			set v_errmsg = 'Email already exists';
			leave sp_exit;
		end if;
        
 			insert into affiliate_user_master_dtl(company_name,firstname,lastname,email,mobilenumber,postcode,address,city,country,business_type,business_othername,business_desc,aff_status,userrole) 
 			values(p_company_name,p_firstname,p_lastname,p_email,p_mobilenumber,p_postcode,p_address,p_city,p_country,p_business_type,p_business_othername,p_business_desc,p_aff_status,p_userrole);
         
 			set v_userid = last_insert_id();
         
 			If v_userid is not null then
 				insert into affiliate_user_company_link_dtl(fk_userid,ref_source_link)
 				select v_userid,ref_source_link
 				from temp_ref_source_link;
 		  
 				insert into affiliate_user_account_dtl(fk_userid,account_name,bankname,account_number,sortcode)
 				values(v_userid,p_account_name,p_bankname,p_account_number,p_sortcode);	
             
                set v_errcode = 0;
                set v_errmsg = 'Success';
 			End if;
     
 	End ;
 	select v_errcode as errcode, v_errmsg as errmsg;
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `affiliate_create_user_referral_code_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `affiliate_create_user_referral_code_dtl`(
 p_userid int,
 p_productid int,
 p_region int,
 p_referral_code varchar(50),
 p_referral_link text
 )
Begin
 
 	declare v_errcode int default -1;
     declare v_errmsg varchar(150) default 'Failure';
 
 	sp_exit:Begin 
 			if exists(select 1 from affiliate_user_referral_code where fk_userid = p_userid and productid = p_productid and region = p_region and referral_link = p_referral_link and referral_code = p_referral_code limit 1)then
 				set v_errcode = -1;
 				set v_errmsg = 'Already exists';
                 leave sp_exit;
 			End if;
             
             insert into affiliate_user_referral_code(fk_userid,productid,region,referral_code,referral_link)
             values(p_userid,p_productid,p_region,p_referral_code,p_referral_link);
 			
 			if row_count() > 0 then
 				set v_errcode = 0;
 				set v_errmsg = 'Success';
                 leave sp_exit;
 			End if;
 	End;
 		select v_errcode as errcode, v_errmsg as errmsg;
 
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `affiliate_delete_user_referral_code_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `affiliate_delete_user_referral_code_dtl`(
p_refcodeid int
)
Begin
	
	declare v_errcode int default -1;
    declare v_errmsg varchar(150) default 'Failure';
    
	sp_exit:Begin 
		if not exists(select 1 from affiliate_user_referral_code where refcodeid = p_refcodeid limit 1)then
			set v_errcode = -1;
			set v_errmsg = 'Record not found';
			leave sp_exit;
		End if;

		delete from affiliate_user_referral_code where fk_userid = p_userid;
		
		if row_count() > 0 then
			set v_errcode = 0;
			set v_errmsg = 'Success: Records deleted';
			leave sp_exit;
		End if;
    end ;
	select v_errcode as errcode, v_errmsg as errmsg;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `affiliate_get_analytics_referral_link_dashboard` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `affiliate_get_analytics_referral_link_dashboard`(
p_userid int,
p_from varchar(10),
p_to varchar(10)
)
Begin
		select cast(b.created as date) as date,count(*) as ref_link 
		from affiliate.affiliate_user_referral_code a 
		join affiliate.affiliate_referral_code_click_info b on a.referral_code = b.referral_code
		where a.fk_userid = p_userid  
		and ((cast(b.created as DATE) >= p_from) or (ifnull(p_from,'') = '')) 
		and ((cast(b.created as DATE) <= p_to) or (ifnull(p_to,'') = ''))
		group by cast(b.created as date) ;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `affiliate_get_analytics_sales_of_month_dashboard` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `affiliate_get_analytics_sales_of_month_dashboard`(
p_userid int,
p_from varchar(10),
p_to varchar(10)
)
Begin
		select source_prod_id,count(*) as sale_count 
		from affiliate.affiliate_user_referral_code a 
		join affiliate.affiliate_referral_code_signup_info b on a.referral_code = b.referral_code
		where a.fk_userid = p_userid and free_paid = 3
		and ((cast(b.created as DATE) >= p_from) or (ifnull(p_from,'') = '')) 
		and ((cast(b.created as DATE) <= p_to) or (ifnull(p_to,'') = ''))
		group by source_prod_id;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `affiliate_get_comm_incentive_structure` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `affiliate_get_comm_incentive_structure`(
p_userid INT
)
Begin
	select * from affiliate_incentive_config where userid = p_userid;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `affiliate_get_incentive_configuration` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `affiliate_get_incentive_configuration`(
p_typeid int
)
Begin
select * from affiliate_incentive_configuration  where (typeid = p_typeid  or ifnull(p_typeid ,0)=0);
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `affiliate_get_incentive_type_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `affiliate_get_incentive_type_info`(
p_typeid int
)
Begin
select * from affiliate_incentive_type_info where (typeid = p_typeid or (ifnull(p_typeid,0)=0));

End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `affiliate_get_master_comm_incentive_structure` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `affiliate_get_master_comm_incentive_structure`()
Begin
 	select * from affiliate_incentive_configuration;
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `affiliate_get_pay_per_comm_allocation` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `affiliate_get_pay_per_comm_allocation`()
Begin
	select * from affiliate_pay_per_comm_allocation;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `affiliate_get_user_dashboard` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `affiliate_get_user_dashboard`(
    	p_userid int,
    	p_from varchar(10),
    	p_to varchar(10),
    	p_prod_id int, 
    	p_tier_id int,
    	p_free_paid int,
    	p_region int
    )
Begin
    		select 	concat(e.Firstname,' ',e.Surname) as Customert_name,e.company_id,
   				c.prod_name as product_name,d.tier_name as plan_name,
    				case when b.tier_duration = 1 then 'Monthly' else 'Yearly' end as subscription_type,
    				case when b.free_paid  = 1 then 'Free' when b.free_paid  = 2 then 'Free Trail' when b.free_paid = 3 then 'Paid' end as contact_type,
    				case when free_paid in (1,2) then 'Lead' else 'Paid' end as comm_type,f.comm_amount as comm_earned,a.region,b.source_prod_id
    		from affiliate.affiliate_user_referral_code a 
    		join affiliate.affiliate_referral_code_signup_info b on a.referral_code = b.referral_code
    		left join wtms.product_master c on a.productid = c.prod_id
    		left join wtms.wtms_copy_of_tier_management_temp d on b.tier_id = d.fk_tier_id
  		left join unifiedring.UR_ECom_User_Extension_Dtl e on b.company_id = e.company_id and e.Extension_number = 200
          left join affiliate_commisson_info f on a.fk_userid = f.userid  and comm_amount <> 0 and f.pay_reference_no = b.pay_reference_no
    		where a.fk_userid = p_userid
    		and (c.prod_id = p_prod_id or ifnull(p_prod_id,0)=0)
    		and (d.fk_tier_id = p_tier_id or ifnull(p_tier_id,0)=0)
    		and (b.free_paid = p_free_paid or ifnull(p_free_paid,0)=0)
    		and (a.region = p_region or ifnull(p_region,0)=0)
    		and ((cast(b.created as DATE) >= p_from) or (ifnull(p_from,'') = '')) 
    		and ((cast(b.created as DATE) <= p_to) or (ifnull(p_to,'') = ''))
    		order by b.created desc ;
    End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `affiliate_get_user_main_dashboard` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `affiliate_get_user_main_dashboard`(
   	p_userid int,
   	p_from varchar(10),
   	p_to varchar(10)
   )
Begin
   
		declare v_sales int;
		declare v_Leads_gen int;
		declare v_comm_earned float;
		declare v_current_revenue float;
		declare clicks int;
		declare v_chatbox int;
		declare v_ucaas int;
		declare v_ccaas int;
        declare v_SMTotal int;
      
		drop temporary table if exists tt_prod_id;
		create temporary table tt_prod_id
		(
		prod_id int,
		prod_name varchar(30),
		count_sales_made int
		);
      
      insert into tt_prod_id values(1,'Contact Centre Platform',0),(2,'Unified Communications',0),(15,'Chat Bot',0);
      
      select count(*) into v_sales
      from affiliate.affiliate_user_referral_code a 
  	join affiliate.affiliate_referral_code_signup_info b on a.referral_code = b.referral_code
      where a.fk_userid = p_userid and b.free_paid = 3
      and ((cast(b.created as DATE) >= p_from) or (ifnull(p_from,'') = '')) 
  	and ((cast(b.created as DATE) <= p_to) or (ifnull(p_to,'') = ''));
      
      select count(*) into v_Leads_gen
      from affiliate.affiliate_user_referral_code a 
  	join affiliate.affiliate_referral_code_signup_info b on a.referral_code = b.referral_code
      where a.fk_userid = p_userid and b.free_paid in (1,2)
  	and ((cast(b.created as DATE) >= p_from) or (ifnull(p_from,'') = '')) 
  	and ((cast(b.created as DATE) <= p_to) or (ifnull(p_to,'') = ''));
     
     select sum(comm_amount),sum(total_purchase_amount) into v_comm_earned,v_current_revenue 
     from affiliate_commisson_info f where f.userid = p_userid  and comm_amount <> 0 and total_purchase_amount <> 0
     and ((cast(f.created as DATE) >= p_from) or (ifnull(p_from,'') = '')) 
  	and ((cast(f.created as DATE) <= p_to) or (ifnull(p_to,'') = ''));
      
  	select count(*) into clicks
      from affiliate.affiliate_user_referral_code a 
  	join affiliate.affiliate_referral_code_click_info b on a.referral_code = b.referral_code
      where a.fk_userid = p_userid
  	and ((cast(b.created as DATE) >= p_from) or (ifnull(p_from,'') = '')) 
  	and ((cast(b.created as DATE) <= p_to) or (ifnull(p_to,'') = ''));
      
    
	drop temporary table if exists tt_prod_id_output;
	create temporary table tt_prod_id_output 
	as
	select c.prod_name as product_name,count(*) as count_sales_made 
	from affiliate.affiliate_user_referral_code a 
	join affiliate.affiliate_referral_code_signup_info b on a.referral_code = b.referral_code
	left join wtms.product_master c on a.productid = c.prod_id
	left join wtms.wtms_copy_of_tier_management_temp d on b.tier_id = d.fk_tier_id
	left join unifiedring.UR_ECom_User_Extension_Dtl e on b.company_id = e.company_id and e.Extension_number = 200
	where a.fk_userid = p_userid
	and ((cast(b.created as DATE) >= p_from) or (ifnull(p_from,'') = '')) 
	and ((cast(b.created as DATE) <= p_to) or (ifnull(p_to,'') = ''))
	group by c.prod_name ;
   
   update tt_prod_id a
   join tt_prod_id_output b on a.prod_name = b.product_name
   set a.count_sales_made = b.count_sales_made;
   
    select sum(count_sales_made) into v_SMTotal from tt_prod_id;
   
	select v_sales as sales,v_Leads_gen as Leads_gen,clicks,sum(ifnull(v_sales,0)+ifnull(v_Leads_gen,0)+ifnull(clicks,0)) as CETotal,ifnull(v_comm_earned,0) as comm_earned,ifnull(v_current_revenue,0) as current_revenue,v_SMTotal as SMTotal;
      
	select prod_name,count_sales_made from tt_prod_id;
   
   End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `affiliate_get_user_master_by_Id` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `affiliate_get_user_master_by_Id`(
 p_userid int
 )
Begin
 
 	declare v_ref_source_link text;
     
     select replace(group_concat(ref_source_link),',',', ') into v_ref_source_link from affiliate_user_company_link_dtl where fk_userid = p_userid;
     
 	select userid,company_name,firstname,lastname,email,mobilenumber,postcode,address,city,country,business_type,business_othername,business_desc,aff_status,userrole,account_name,bankname,account_number,sortcode,
     v_ref_source_link as ref_source_link,payment_method,payment_email,payment_accountid
     from affiliate_user_master_dtl a 
     left join affiliate_user_account_dtl b on a.userid = b.fk_userid
     where a.userid = p_userid;
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `affiliate_get_user_master_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `affiliate_get_user_master_dtl`(
 p_status_filter varchar(20),
 p_from varchar(10),
 p_to varchar(10)
 )
Begin
 
 		
 		
 		
 		
 		
         
         
 		DROP TEMPORARY TABLE IF EXISTS temp_status_filter; CREATE TEMPORARY TABLE temp_status_filter (status_filter VARCHAR(255));
 		call Split(p_status_filter,','); INSERT INTO temp_status_filter (status_filter) select items from tt_Split_temptable;
 
 			select userid as affiliateID,firstname,lastname,mobilenumber,email,company_name,aff_status as status 
             from affiliate_user_master_dtl a
             where userrole = 5
             and ((cast(a.created as DATE) >= p_from) or (ifnull(p_from,'') = '')) 
             and ((cast(a.created as DATE) <= p_to) or (ifnull(p_to,'') = ''))
             and (aff_status in (select Distinct status_filter from temp_status_filter) or ifnull(p_status_filter,'')='')
             ORDER BY userid DESC;
 
 
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `affiliate_get_user_referral_code_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `affiliate_get_user_referral_code_dtl`(
  p_userid int
  )
Begin
 		select a.productid,c.prod_name as product_name,a.referral_code,a.referral_link
 	,(	select 	count(1) as clicks
 		from 	affiliate_referral_code_click_info b 
 		where 	a.referral_code = b.referral_code) clicks
 	,(	select 	count(1) as signup
 		from 	affiliate_referral_code_signup_info b 
 		where  	a.referral_code = b.referral_code) signup
	,a.region
 	from affiliate_user_referral_code a 
     left join wtms.product_master c on a.productid = c.prod_id
 	where a.fk_userid = p_userid;
     
  End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `affiliate_login_forgot_pwd` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `affiliate_login_forgot_pwd`(
  p_email VARCHAR(80),
  p_new_password VARCHAR(50)
)
begin    
       DECLARE v_errcode INT DEFAULT 0;
       DECLARE v_errmsg VARCHAR(100) DEFAULT 'success';
    
       sp_end:BEGIN
             if not exists(select 1 from affiliate_user_master_dtl a where a.email = p_email) then
                SET v_errcode = -1;
                SET v_errmsg = 'Please enter a valid email address';
                LEAVE sp_end;
             end if;
    		
			UPDATE affiliate_user_master_dtl t set t.aff_password = p_new_password where t.email = p_email;
            
            SET v_errcode = 0;
			SET v_errmsg = 'Success: New password updated';
       END;

       select v_errcode errcode,v_errmsg errmsg; 
    
    end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `affiliate_login_validation` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `affiliate_login_validation`(
p_login_user_name VARCHAR(50),   
p_login_password  VARCHAR(50)
)
sp_exit: Begin
    
		if not exists(select 1 from affiliate_user_master_dtl where email = p_login_user_name limit 1) then
			 select -1 as errcode, 'Incorrect email address' as errmsg;
			 leave sp_exit;
		end if;
		 
		if exists(select 1 from affiliate_user_master_dtl where email = p_login_user_name and aff_password <> p_login_password limit 1) then
			select -1 as errcode, 'Incorrect Password' as errmsg;
			leave sp_exit;
		end if;
		 
		 if exists(select 1 from affiliate_user_master_dtl where email = p_login_user_name and aff_password = p_login_password limit 1) then
			select 0 as errcode, 'Login Successful' as errmsg,a.* from affiliate_user_master_dtl a where a.email = p_login_user_name and a.aff_password = p_login_password;
			leave sp_exit;
		end if;
	End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `affiliate_update_incentive_configuration` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `affiliate_update_incentive_configuration`(
 p_comm_info_xml LONGTEXT
)
Begin

	DECLARE v_errcode INT; 
  	DECLARE v_errmsg VARCHAR(160);  
    
    DECLARE v_typename text ;
  	DECLARE v_aff_type text;
  	DECLARE v_status text ;
  	DECLARE v_inc_percentage text;
  	DECLARE v_duration text;
  	DECLARE v_bonus_amount text;
    
    DROP TEMPORARY TABLE IF EXISTS tt_temp_master_aff_comm_structure;          
	create TEMPORARY table tt_temp_master_aff_comm_structure
  	(
  		id INT AUTO_INCREMENT PRIMARY KEY, typename varchar(50), aff_type int, status int, inc_percentage float, duration int, bonus_amount float
  	);
  		
	 drop temporary table if exists xml_typename_tbl; create temporary table xml_typename_tbl( id int auto_increment primary key,typename varchar(50));
	 drop temporary table if exists xml_aff_type_tbl; create temporary table xml_aff_type_tbl( id int auto_increment primary key,aff_type int);
	 drop temporary table if exists xml_status_tbl; create temporary table xml_status_tbl( id int auto_increment primary key,status float);
	 drop temporary table if exists xml_inc_percentage_tbl; create temporary table xml_inc_percentage_tbl( id int auto_increment primary key,inc_percentage float);
	 drop temporary table if exists xml_duration_tbl; create temporary table xml_duration_tbl( id int auto_increment primary key,duration int);
	 drop temporary table if exists xml_bonus_amount_tbl; create temporary table xml_bonus_amount_tbl( id int auto_increment primary key,bonus_amount float);
         
        SELECT 
            REPLACE(EXTRACTVALUE(p_comm_info_xml, '//typename[1]'),' ',','),          REPLACE(EXTRACTVALUE(p_comm_info_xml, '//aff_type[1]'),' ',','),
            REPLACE(EXTRACTVALUE(p_comm_info_xml, '//status[1]'),' ',','),          	REPLACE(EXTRACTVALUE(p_comm_info_xml,'//inc_percentage[1]'),' ',','),
            REPLACE(EXTRACTVALUE(p_comm_info_xml,'//duration[1]'),' ',','),          	REPLACE(EXTRACTVALUE(p_comm_info_xml,'//bonus_amount[1]'),' ',',')
        	INTO v_typename, v_aff_type, v_status, v_inc_percentage, v_duration, v_bonus_amount;	
    
           call unifiedring.Split(v_typename,','); insert into xml_typename_tbl(typename) select Items from unifiedring.tt_Split_temptable;
           call unifiedring.Split(v_aff_type,','); insert into xml_aff_type_tbl(aff_type) select Items from unifiedring.tt_Split_temptable;
           call unifiedring.Split(v_status,','); insert into xml_status_tbl(status) select Items from unifiedring.tt_Split_temptable;
           call unifiedring.Split(v_inc_percentage,','); insert into xml_inc_percentage_tbl(inc_percentage) select Items from unifiedring.tt_Split_temptable;     
           call unifiedring.Split(v_duration,','); insert into xml_duration_tbl(duration) select Items from unifiedring.tt_Split_temptable;     
           call unifiedring.Split(v_bonus_amount,','); insert into xml_bonus_amount_tbl(bonus_amount) select Items from unifiedring.tt_Split_temptable;     
                
           insert into tt_temp_master_aff_comm_structure(typename, aff_type, status, inc_percentage, duration, bonus_amount)
           select typename, aff_type, status, inc_percentage, duration, bonus_amount
           from xml_typename_tbl a 
           left join xml_aff_type_tbl b on a.id = b.id
           left join xml_status_tbl c on a.id = c.id
           left join xml_inc_percentage_tbl d on a.id = d.id
           left join xml_duration_tbl e on a.id = e.id
           left join xml_bonus_amount_tbl f on a.id = f.id;
		
              
			IF EXISTS(SELECT 1 FROM affiliate_incentive_configuration) 
			then
				DELETE FROM affiliate_incentive_configuration;
			end if;

			INSERT INTO affiliate_incentive_configuration(typename, aff_type, status, inc_percentage, duration, bonus_amount)
			SELECT typename, aff_type, status, inc_percentage, duration, bonus_amount 
			FROM tt_temp_master_aff_comm_structure;

			IF ROW_COUNT() > 0 then
				SET v_errcode = 0;
				SET v_errmsg = 'Success: Master Incentive Structure';
			end if;
   
	select v_errcode as errcode,v_errmsg as errmsg; 

End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `affiliate_update_incentive_type_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `affiliate_update_incentive_type_info`(
p_inc_type longtext
)
Begin
	declare cnt int default 1;
	declare tcnt int;
    declare v_errcode int;
    declare v_errmsg varchar(50) default '';
    
    set tcnt = extractvalue(p_inc_type,'count(//bulk)');
    
    drop temporary table if exists tt_temp_inc_type;
    create temporary table tt_temp_inc_type
    (
		id int auto_increment primary key,
        typename varchar(20), 
        ranges int
    );
    
    while cnt <= tcnt do
		
			insert into tt_temp_inc_type(typename,ranges)
            select 
            EXTRACTVALUE(p_inc_type,CONCAT('/bulk[', cnt,']/typename')),
            EXTRACTVALUE(p_inc_type,CONCAT('/bulk[', cnt,']/ranges'));
		set cnt = cnt + 1;
    end while;
    
	if exists(select 1 from tt_temp_inc_type) then
		truncate table affiliate_incentive_type_info;
    end if;
    
    insert into affiliate_incentive_type_info(typename,ranges)
    select typename,ranges from tt_temp_inc_type;
    
    if row_count() > 0 then
		set v_errcode = 0;
        set v_errmsg = 'Success';
    End if;
    
    select v_errcode as errcode, v_errmsg as errmsg;
    
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `affiliate_update_member_approval_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `affiliate_update_member_approval_info`(
p_userid int,
p_aff_status int,
p_aff_password varchar(50),
p_updatedby int
)
begin
	declare v_errcode int;
	declare v_errmsg varchar(55) default 'Details not found';
    
    if exists(select 1 from affiliate_user_master_dtl where userid = p_userid) then
		
        update affiliate_user_master_dtl
        set aff_status 	= ifnull(p_aff_status,aff_status),
			aff_password = ifnull(p_aff_password,aff_password),
			updated = now(),
            updatedby = ifnull(p_updatedby,updatedby)
        where userid = p_userid;
        
        set v_errcode = 0;
		set v_errmsg = 'Success';
	end if;

	select v_errcode as errcode,  v_errmsg as errmsg;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `affiliate_update_pay_per_comm_allocation_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `affiliate_update_pay_per_comm_allocation_info`(
  p_pay_per_xml longtext
  )
Begin
  	declare cnt int default 1;
  	declare tcnt int;
      declare v_errcode int;
      declare v_errmsg varchar(50) default '';
      
      set tcnt = extractvalue(p_pay_per_xml,'count(//bulk)');
      
      drop temporary table if exists tt_temp_pp_type;
      create temporary table tt_temp_pp_type
      (
  		id int auto_increment primary key,
          pay_per varchar(20), 
          pay_per_comm int,
          pay_per_value int
      );
      
      while cnt <= tcnt do
  		
  			insert into tt_temp_pp_type(pay_per,pay_per_comm,pay_per_value)
              select 
              EXTRACTVALUE(p_pay_per_xml,CONCAT('/bulk[', cnt,']/pay_per')),
              EXTRACTVALUE(p_pay_per_xml,CONCAT('/bulk[', cnt,']/pay_per_comm')),
              EXTRACTVALUE(p_pay_per_xml,CONCAT('/bulk[', cnt,']/pay_per_value'));
  		set cnt = cnt + 1;
      end while;
      
  	if exists(select 1 from tt_temp_pp_type) then
  		truncate table affiliate_pay_per_comm_allocation;
      end if;
      
      insert into affiliate_pay_per_comm_allocation(pay_per,pay_per_comm,pay_per_value)
      select pay_per,pay_per_comm,pay_per_value from tt_temp_pp_type;
      
      if row_count() > 0 then
  		set v_errcode = 0;
          set v_errmsg = 'Success';
      End if;
      
      select v_errcode as errcode, v_errmsg as errmsg;
      
  End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `affiliate_update_user_payment_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `affiliate_update_user_payment_dtl`(
 p_userid int,
 p_payment_method int,
 p_payment_email varchar(100),
 p_payment_accountid varchar(100)
 )
Begin
 	
     declare v_errcode int;
     declare v_errmsg varchar(100);
    sp_exit:begin 
     if not exists(select 1 from affiliate_user_master_dtl where userid = p_userid limit 1 ) then
 		set v_errcode = -1;
         set v_errmsg = 'User Details not found';
         leave sp_exit;
     End if;
     
 		update affiliate_user_master_dtl 
         set payment_method = ifnull(p_payment_method ,payment_method),
 			payment_email = ifnull(p_payment_email,payment_email),
 			payment_accountid = ifnull(p_payment_accountid ,payment_accountid)
         where userid = p_userid;
     
 		set v_errcode = 0;
         set v_errmsg = 'Success: Updated';

     end;
     select v_errcode as errcode, v_errmsg as errmsg;
 
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `affiliate_user_validate_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `affiliate_user_validate_info`(
 p_email varchar(255)
 )
begin
 
 	declare v_errcode int;
 	declare v_errmsg varchar(55);
     
 		if exists(select 1 from smereseller.Reseller where Email = p_email limit 1) then
 			set v_errcode = -1;
             set v_errmsg = 'Email already exists';
			else if exists(select 1 from affiliate_user_master_dtl where email = p_email limit 1)then
				set v_errcode = -1;
				 set v_errmsg = 'Email already exists';
			else
				set v_errcode = 0;
				 set v_errmsg = 'New EmailID';
			 End if;
         end if;
         
 	select v_errcode as errcode, v_errmsg as errmsg;
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Split` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `Split`(v_String VARCHAR(8000), v_Delimiter CHAR(1))
SWL_return:
 begin
 
      
    DECLARE v_idx INT;     
    DECLARE v_slice VARCHAR(8000);     
 
    DROP TEMPORARY TABLE IF EXISTS tt_Split_temptable;
    CREATE TEMPORARY TABLE IF NOT EXISTS tt_Split_temptable
    (
       items VARCHAR(8000)
    );
    SET v_idx = 1;     
    if  CHAR_LENGTH(v_String) < 1 or v_String is null then  
       LEAVE SWL_return;
    end if;     
 
    SWL_Label:
    while v_idx != 0 DO
       set v_idx = LOCATE(v_Delimiter,v_String);
       if v_idx != 0 then
          set v_slice = left(v_String,v_idx -1);
       else
          set v_slice = v_String;
       end if;
       if( CHAR_LENGTH(v_slice) > 0) then
          insert into tt_Split_temptable(Items) values(v_slice);
       end if;
       set v_String = right(v_String, CHAR_LENGTH(v_String) -v_idx);
       if  CHAR_LENGTH(v_String) = 0 then 
          LEAVE SWL_Label;
       end if;
    END WHILE; 
    LEAVE SWL_return;     
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ur_crm_portal_get_test_companies_list` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ur_crm_portal_get_test_companies_list`(
       From_date VARCHAR(50),
        to_date VARCHAR(50)
   )
Begin
         
         sp_exit:BEGIN
        
           DECLARE v_errcode INT;
           DECLARE v_errmsg VARCHAR(150);
       
         IF (From_date <> '') and (to_date <> '') then
              SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
              select Distinct b.company_id,
        				ec.comp_name,
        				c.tier_name as Pln_Name,
        				case when a.plan_duration = 1 then 'Monthly' 
   						when a.plan_duration = 12  then '1 year'
                           when a.plan_duration = 24  then '2 years'
                           when a.plan_duration = 36  then '3 years' end as Subscription_type,
        				e.createdate as Subscription_date,
        				b.city as Location,
        				case when a.status = 1 then 'Active' else 'Inactive' end as status,
        				b.email  as email,
        				case when ec.Comp_is_free_trail = 1 then 'Free Trial' else '' end as Comp_is_free_trail,
        				a.plan_end_date as plan_end_date,
        				case when f.Pk_rs_cmpid is not null then 'RESELLER' else 'WEBSITE' end as create_from,
        				case when f.Pk_rs_cmpid is not null then cast(f.reseller_id as CHAR(30)) else  '' end as create_by
              from ur_company_plan a 
              join vbcp_company b  on a.company_id = b.company_id
              join UR_ECom_Company ec on ec.Comp_Id = b.eshop_comp_id
             
             
             join wtms.wtms_copy_of_tier_management_temp c on a.plan_id = c.fk_tier_id
              join vtos_customer e on b.customer_id = e.customer_id
              left join smereseller.reseller_company f on b.company_id = f.Vpcp_Company_Id
              where  (cast(e.createdate as DATE) >= From_date) and  (cast(e.createdate as DATE) <= to_date) and IFNULL(is_deleted,0) = 0 
              and ( b.company_name like '%test%' or b.email like '%test%' or ec.comp_name like '%test%' or b.company_name like '%ws_test%' or b.email like '%ws_test%'  or ec.comp_name like '%ws_test%'
              or b.company_name like '%wt%test%' or b.email like '%wt%test%' or ec.comp_name like '%wt%test%'
              or b.company_name like '%wt_%' or b.email like '%wt_%' or ec.comp_name like '%wt_%'
              or b.company_name like '%wst%' or b.email like '%wst%' or ec.comp_name like '%wst%'
              )
              order by e.createdate desc LIMIT 1000;
              SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
         
              else         
     
           SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
              select Distinct b.company_id,
        				ec.comp_name,
        				c.tier_name as Pln_Name,
        				case when a.plan_duration = 1 then 'Monthly' 
   						when a.plan_duration = 12  then '1 year'
                           when a.plan_duration = 24  then '2 years'
                           when a.plan_duration = 36  then '3 years' end as Subscription_type,
        				e.createdate as Subscription_date,
        				b.city as Location,
        				case when a.status = 1 then 'Active' else 'Inactive' end as status,
        				b.email  as email,
        				case when ec.Comp_is_free_trail = 1 then 'Free Trial' else '' end as Comp_is_free_trail,
        				a.plan_end_date as plan_end_date,
        				case when f.Pk_rs_cmpid is not null then 'RESELLER' else 'WEBSITE' end as create_from,
        				case when f.Pk_rs_cmpid is not null then cast(f.reseller_id as CHAR(30)) else  '' end as create_by
              from ur_company_plan a 
              join vbcp_company b on a.company_id = b.company_id
              join UR_ECom_Company ec on ec.Comp_Id = b.eshop_comp_id
              
              
              join wtms.wtms_copy_of_tier_management_temp c on a.plan_id = c.fk_tier_id
              join vtos_customer e on b.customer_id = e.customer_id
              left join smereseller.reseller_company f  on b.company_id = f.Vpcp_Company_Id
              where ( b.company_name like '%test%' or b.email like '%test%'  or ec.comp_name like '%test%' or b.company_name like '%ws_test%' or b.email like '%ws_test%'  or ec.comp_name like '%ws_test%'
              or b.company_name like '%wt%test%' or b.email like '%wt%test%' or ec.comp_name like '%wt%test%'
              or b.company_name like '%wt_%' or b.email like '%wt_%' or ec.comp_name like '%wt_%'
              or b.company_name like '%wst%' or b.email like '%wst%' or ec.comp_name like '%wst%')
              and IFNULL(is_deleted,0) = 0
              order by e.createdate desc LIMIT 1000;
              end if;
           
   			If found_rows() > 0 then
   				set v_errcode = 0;
   				set v_errmsg = 'Success - Records found!.';
   				LEAVE sp_exit;
   			else
   				set v_errcode  = -1;
   				set v_errmsg  = 'Failure to get company details!';
   				LEAVE sp_exit;
   			end if;
        
           select v_errcode as errcode,v_errmsg as errmsg;
           END;
        End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `USP_API_Get_API_Details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `USP_API_Get_API_Details`(User_Id VARCHAR(200),        
Pwd     VARCHAR(200),    
Proj_Id    INT)
Begin

   DECLARE v_errcode INT;        
   DECLARE v_errmsg VARCHAR(20);      
        
   If Exists(Select  1 from APIKey_details a
   join Project_details b on a.PROJ_Id = b.PROJ_Id where a.User_Id = User_Id and a.pwd = Pwd and a.proj_id = Proj_Id LIMIT 1) then
 
      Set v_errcode = 1;
      Set v_errmsg  = 'Success';
   Else
      Set v_errcode = 0;
      Set v_errmsg  = 'Failure';
   end if;        
      
   Select v_errcode as errcode ,v_errmsg as errmsg;      
      
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Usp_API_Insert_Token_Master` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `Usp_API_Insert_Token_Master`(Proj_ID INT,      
AToken_ID VARCHAR(250),      
AToken_Min INT,      
RToken_ID VARCHAR(250),      
RToken_Min INT)
Begin     
  
   DECLARE v_Current DATETIME(3);      
   DECLARE v_errcode INT;        
   DECLARE v_errmsg VARCHAR(250);       
       
   Set v_errcode = 0;        
   Set v_errmsg = 'Success';        
        
     
   Set v_Current = CURRENT_TIMESTAMP;    
  
   Insert into API_Proj_Token_Master(PTM_Proj_ID,PTM_Token_ID,PTM_Token_Start_date,PTM_Token_End_Time,
  PTM_Refresh_Token_ID,PTM_Refresh_Token_SDate,PTM_Refresh_Token_EDate)
     Values(Proj_ID,AToken_ID,v_Current,TIMESTAMPADD(MINUTE,AToken_Min,v_Current) ,
     RToken_ID,TIMESTAMPADD(MINUTE,AToken_Min+1,v_Current),TIMESTAMPADD(MINUTE,AToken_Min+RToken_Min,v_Current));     

   Select v_errcode errcode,v_errmsg errmsg;     

ENd ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Usp_API_Return_Token_Status` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `Usp_API_Return_Token_Status`(
Proj_Name VARCHAR(250),
Token_ID VARCHAR(150)
)
SWL_return:
 Begin

    DECLARE v_start_Date DATETIME(3);
    DECLARE v_End_time INT;
    DECLARE v_End_Date DATETIME(3);
    DECLARE v_Current DATETIME(3);
    DECLARE v_Proj_ID INT;
    DECLARE v_Status VARCHAR(1);
 
 
 
  
 
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select   IFNULL(PROJ_Id,0) INTO v_Proj_ID from Project_details  where ProjectName = Proj_Name limit 1;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 
    
 if v_Proj_ID is null  or v_Proj_ID = 0 then
       Select 'Enter valid Project Name'   Status;
       LEAVE SWL_return;
    end if; 
 
    if Exists(Select 1 from API_Proj_Token_Master  Where PTM_Proj_ID = v_Proj_ID and PTM_Token_ID =  Token_ID limit 1) then
   
       
 SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
       select   PTM_Token_Start_date, PTM_Token_End_Time INTO v_start_Date,v_End_Date from API_Proj_Token_Master  Where PTM_Proj_ID = v_Proj_ID and PTM_Token_ID =  Token_ID limit 1;
       SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
    Else
       If Exists(Select 1 from API_Proj_Token_Master  Where PTM_Proj_ID = v_Proj_ID and PTM_Refresh_Token_ID =  Token_ID limit 1) then
   
          
 SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
          select   PTM_Refresh_Token_SDate, PTM_Refresh_Token_EDate INTO v_start_Date,v_End_Date from API_Proj_Token_Master  Where PTM_Proj_ID = v_Proj_ID and PTM_Refresh_Token_ID =  Token_ID limit 1;
          SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
       end if;
    end if;
 
 
 
    Set v_Current = CURRENT_TIMESTAMP;
	If  (v_Current >= v_start_Date) and (v_Current <= v_End_Date) then
       Select 'OK'  Status;
    Else
       Select 'Token Expired'  Status;
    end if;

 
 ENd ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-21  9:49:46
