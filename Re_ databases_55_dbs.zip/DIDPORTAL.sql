-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: DIDPORTAL
-- ------------------------------------------------------
-- Server version	8.0.44-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `DIDPORTAL`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `DIDPORTAL` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `DIDPORTAL`;

--
-- Table structure for table `BICS_DID_NUMBER_ADDR_INFO`
--

DROP TABLE IF EXISTS `BICS_DID_NUMBER_ADDR_INFO`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `BICS_DID_NUMBER_ADDR_INFO` (
  `id` int NOT NULL AUTO_INCREMENT,
  `did_number` varchar(20) NOT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `vat_number` varchar(50) DEFAULT NULL,
  `company_name` varchar(150) DEFAULT NULL,
  `alias_name` varchar(150) DEFAULT NULL,
  `street` varchar(150) DEFAULT NULL,
  `streetNumber` varchar(100) DEFAULT NULL,
  `box` varchar(100) DEFAULT NULL,
  `residence` varchar(100) DEFAULT NULL,
  `floor_info` varchar(100) DEFAULT NULL,
  `postal_code` varchar(50) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `country` varchar(50) DEFAULT NULL,
  `reference` varchar(100) NOT NULL,
  `status` varchar(100) DEFAULT NULL,
  `comment` varchar(500) DEFAULT NULL,
  `serviceUsage` varchar(500) DEFAULT NULL,
  `addressDocuments` varchar(500) DEFAULT NULL,
  `email_id` varchar(100) DEFAULT NULL,
  `create_date` datetime(3) DEFAULT NULL,
  `last_update` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`did_number`,`reference`),
  UNIQUE KEY `id` (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `TBL_TEST`
--

DROP TABLE IF EXISTS `TBL_TEST`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TBL_TEST` (
  `did` varchar(20) DEFAULT NULL,
  `did_to` varchar(20) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `TBL_TEST_LOG`
--

DROP TABLE IF EXISTS `TBL_TEST_LOG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TBL_TEST_LOG` (
  `country_id` int DEFAULT NULL,
  `city_id` int DEFAULT NULL,
  `operatorid` int DEFAULT NULL,
  `in_xml_data` longtext,
  `in_user_name` varchar(50) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `TESTCHECK`
--

DROP TABLE IF EXISTS `TESTCHECK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TESTCHECK` (
  `country` varchar(20) DEFAULT NULL,
  `country_id` int DEFAULT NULL,
  `city_name` varchar(155) DEFAULT NULL,
  `area_code` varchar(20) DEFAULT NULL,
  `vendor_name` varchar(125) DEFAULT NULL,
  `vendor_preference` varchar(555) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `VOTG_VIRTUAL_NUMBER_POOL_UR`
--

DROP TABLE IF EXISTS `VOTG_VIRTUAL_NUMBER_POOL_UR`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `VOTG_VIRTUAL_NUMBER_POOL_UR` (
  `ID` int NOT NULL,
  `MUNDIO_COUNTRY` varchar(150) DEFAULT NULL,
  `MUNDIO_SITECODE` varchar(5) DEFAULT NULL,
  `COUNTRY_PREFIX` varchar(10) DEFAULT NULL,
  `MUNDIO_NUMBER` varchar(20) NOT NULL,
  `AMOUNT` float DEFAULT NULL,
  `STATUS` int DEFAULT NULL,
  `DIR_USER_ID` int DEFAULT NULL,
  `REG_SITECODE` varchar(5) DEFAULT NULL,
  `REG_MSISDN` varchar(20) DEFAULT NULL,
  `REG_BY` varchar(20) DEFAULT NULL,
  `REG_DATE` datetime(3) DEFAULT NULL,
  `COUNTRY_CODE` varchar(5) DEFAULT NULL,
  `VEC_USER` int NOT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=2003 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `country_config`
--

DROP TABLE IF EXISTS `country_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `country_config` (
  `id` int DEFAULT NULL,
  `iso` char(2) NOT NULL,
  `name` varchar(80) NOT NULL,
  `nicename` varchar(80) NOT NULL,
  `iso3` char(3) DEFAULT NULL,
  `phonecode` int NOT NULL,
  `phonecode_len` int DEFAULT NULL,
  `is_free_call` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=251 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dcapp_recycle_log`
--

DROP TABLE IF EXISTS `dcapp_recycle_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dcapp_recycle_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `acountid` varchar(20) DEFAULT NULL,
  `did` varchar(20) DEFAULT NULL,
  `insert_date` datetime(3) DEFAULT NULL,
  `reg_sitecode` varchar(3) DEFAULT NULL,
  `exp_date` datetime(3) DEFAULT NULL,
  `status` int DEFAULT NULL,
  `recycle_process_date` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `did_list_all`
--

DROP TABLE IF EXISTS `did_list_all`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `did_list_all` (
  `Operator` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `Country` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `City` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `DID` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `Product` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `Status` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=4113 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `did_number_LCR_vendor_price_master_dtl`
--

DROP TABLE IF EXISTS `did_number_LCR_vendor_price_master_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `did_number_LCR_vendor_price_master_dtl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `Fk_country_id` int DEFAULT NULL,
  `Fk_did_type_id` int DEFAULT NULL,
  `Fk_operator_id` int DEFAULT NULL,
  `Price_updatedate` datetime DEFAULT NULL,
  `DID_NRC_price` float DEFAULT NULL,
  `DID_MRC_price` float DEFAULT NULL,
  `Inbound_per_min_price` float DEFAULT NULL,
  `Outbound_per_min_price` float DEFAULT NULL,
  `Emergency_Calls` varchar(10) DEFAULT NULL,
  `KYC` varchar(10) DEFAULT NULL,
  `LCR_position_id` int DEFAULT NULL,
  `Currency` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `did_number_LCR_vendor_price_master_dtl_ibfk_1` (`Fk_country_id`),
  KEY `did_number_LCR_vendor_price_master_dtl_ibfk_2` (`Fk_did_type_id`),
  KEY `did_number_LCR_vendor_price_master_dtl_ibfk_3` (`Fk_operator_id`),
  CONSTRAINT `did_number_LCR_vendor_price_master_dtl_ibfk_1` FOREIGN KEY (`Fk_country_id`) REFERENCES `ref_did_country` (`pk_country_id`),
  CONSTRAINT `did_number_LCR_vendor_price_master_dtl_ibfk_2` FOREIGN KEY (`Fk_did_type_id`) REFERENCES `ref_LCR_did_type_list` (`did_type_id`),
  CONSTRAINT `did_number_LCR_vendor_price_master_dtl_ibfk_3` FOREIGN KEY (`Fk_operator_id`) REFERENCES `ref_did_operator` (`pk_operator_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `did_number_lcr_price_master_dtl`
--

DROP TABLE IF EXISTS `did_number_lcr_price_master_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `did_number_lcr_price_master_dtl` (
  `country` varchar(50) DEFAULT NULL,
  `location` longtext,
  `area_code` longtext,
  `number_Type` varchar(30) DEFAULT NULL,
  `installation_fee` float DEFAULT NULL,
  `monthly_fee` float DEFAULT NULL,
  `usage_fee` float DEFAULT NULL,
  `per_minute_usage_fee` float DEFAULT NULL,
  `channels` int DEFAULT NULL,
  `currency` varchar(5) DEFAULT NULL,
  `price_updatedate` datetime(3) DEFAULT NULL,
  `source_name` varchar(50) DEFAULT NULL,
  `is_document_req` int DEFAULT NULL,
  `is_support_flag` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=21483 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `did_number_pool`
--

DROP TABLE IF EXISTS `did_number_pool`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `did_number_pool` (
  `id` int NOT NULL AUTO_INCREMENT,
  `did_number` varchar(20) NOT NULL,
  `fk_operator_id` int DEFAULT NULL,
  `fk_country_id` int DEFAULT NULL,
  `fk_city_id` int DEFAULT NULL,
  `fk_product_id` int DEFAULT NULL,
  `status` int DEFAULT NULL,
  `create_date` datetime(3) DEFAULT NULL,
  `last_update` datetime(3) DEFAULT NULL,
  `update_by` varchar(100) DEFAULT NULL,
  `uploaded_by` varchar(50) DEFAULT NULL,
  `assigned_date` datetime(3) DEFAULT NULL,
  `area_code` varchar(50) DEFAULT NULL,
  `fk_num_range_id` int DEFAULT NULL,
  `CUPID` int DEFAULT NULL,
  PRIMARY KEY (`did_number`),
  UNIQUE KEY `id` (`id`),
  KEY `FK__did_numbe__fk_ci__182C9B23Idx` (`fk_city_id`),
  KEY `FK__did_numbe__fk_op__2F10007BIdx` (`fk_operator_id`),
  KEY `Fk_did_number_pool_productIdx` (`fk_product_id`),
  KEY `idx1_did_number_pool` (`fk_operator_id`,`fk_country_id`,`fk_city_id`,`fk_product_id`),
  KEY `idx2_did_number_pool` (`status`),
  KEY `idx3_did_number_pool` (`status`,`fk_country_id`),
  KEY `idx4_did_number_pool` (`fk_country_id`),
  KEY `nx_did_number_pool_NumRangeCountry` (`fk_num_range_id`,`fk_country_id`,`status`,`did_number`),
  CONSTRAINT `did_number_pool_ibfk_1` FOREIGN KEY (`fk_city_id`) REFERENCES `ref_did_city` (`pk_city_id`),
  CONSTRAINT `did_number_pool_ibfk_10` FOREIGN KEY (`fk_operator_id`) REFERENCES `ref_did_operator` (`pk_operator_id`),
  CONSTRAINT `did_number_pool_ibfk_11` FOREIGN KEY (`fk_operator_id`) REFERENCES `ref_did_operator` (`pk_operator_id`),
  CONSTRAINT `did_number_pool_ibfk_12` FOREIGN KEY (`fk_operator_id`) REFERENCES `ref_did_operator` (`pk_operator_id`),
  CONSTRAINT `did_number_pool_ibfk_13` FOREIGN KEY (`status`) REFERENCES `ref_did_number_status` (`status_id`),
  CONSTRAINT `did_number_pool_ibfk_14` FOREIGN KEY (`status`) REFERENCES `ref_did_number_status` (`status_id`),
  CONSTRAINT `did_number_pool_ibfk_15` FOREIGN KEY (`status`) REFERENCES `ref_did_number_status` (`status_id`),
  CONSTRAINT `did_number_pool_ibfk_16` FOREIGN KEY (`status`) REFERENCES `ref_did_number_status` (`status_id`),
  CONSTRAINT `did_number_pool_ibfk_2` FOREIGN KEY (`fk_city_id`) REFERENCES `ref_did_city` (`pk_city_id`),
  CONSTRAINT `did_number_pool_ibfk_3` FOREIGN KEY (`fk_city_id`) REFERENCES `ref_did_city` (`pk_city_id`),
  CONSTRAINT `did_number_pool_ibfk_4` FOREIGN KEY (`fk_city_id`) REFERENCES `ref_did_city` (`pk_city_id`),
  CONSTRAINT `did_number_pool_ibfk_5` FOREIGN KEY (`fk_country_id`) REFERENCES `ref_did_country` (`pk_country_id`),
  CONSTRAINT `did_number_pool_ibfk_6` FOREIGN KEY (`fk_country_id`) REFERENCES `ref_did_country` (`pk_country_id`),
  CONSTRAINT `did_number_pool_ibfk_7` FOREIGN KEY (`fk_country_id`) REFERENCES `ref_did_country` (`pk_country_id`),
  CONSTRAINT `did_number_pool_ibfk_8` FOREIGN KEY (`fk_country_id`) REFERENCES `ref_did_country` (`pk_country_id`),
  CONSTRAINT `did_number_pool_ibfk_9` FOREIGN KEY (`fk_operator_id`) REFERENCES `ref_did_operator` (`pk_operator_id`),
  CONSTRAINT `FK__did_numbe__fk_ci__182C9B23` FOREIGN KEY (`fk_city_id`) REFERENCES `ref_did_city` (`pk_city_id`),
  CONSTRAINT `FK__did_numbe__fk_ci__32AB8735` FOREIGN KEY (`fk_city_id`) REFERENCES `ref_did_city` (`pk_city_id`),
  CONSTRAINT `FK__did_numbe__fk_ci__395884C4` FOREIGN KEY (`fk_city_id`) REFERENCES `ref_did_city` (`pk_city_id`),
  CONSTRAINT `FK__did_numbe__fk_ci__40058253` FOREIGN KEY (`fk_city_id`) REFERENCES `ref_did_city` (`pk_city_id`),
  CONSTRAINT `FK__did_numbe__fk_op__2F10007B` FOREIGN KEY (`fk_operator_id`) REFERENCES `ref_did_operator` (`pk_operator_id`),
  CONSTRAINT `FK__did_numbe__fk_op__3493CFA7` FOREIGN KEY (`fk_operator_id`) REFERENCES `ref_did_operator` (`pk_operator_id`),
  CONSTRAINT `FK__did_numbe__fk_op__3B40CD36` FOREIGN KEY (`fk_operator_id`) REFERENCES `ref_did_operator` (`pk_operator_id`),
  CONSTRAINT `FK__did_numbe__fk_op__41EDCAC5` FOREIGN KEY (`fk_operator_id`) REFERENCES `ref_did_operator` (`pk_operator_id`),
  CONSTRAINT `Fk_did_number_pool_product` FOREIGN KEY (`fk_product_id`) REFERENCES `ref_did_product` (`pk_product_id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=4766383 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `did_number_user_info`
--

DROP TABLE IF EXISTS `did_number_user_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `did_number_user_info` (
  `id` int NOT NULL AUTO_INCREMENT,
  `did_number` varchar(20) DEFAULT NULL,
  `assigned_user` varchar(20) DEFAULT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `fk_product_id` int DEFAULT NULL,
  `assigned_date` datetime(3) DEFAULT NULL,
  `assigned_by` varchar(250) DEFAULT NULL,
  `purchase_price` float DEFAULT NULL,
  `exp_date` datetime(3) DEFAULT NULL,
  `number_status` int DEFAULT NULL,
  `reg_country` varchar(50) DEFAULT NULL,
  `company_id` int DEFAULT NULL,
  `company_name` varchar(150) DEFAULT NULL,
  UNIQUE KEY `id` (`id`),
  KEY `FK__did_numbe__did_n__4BAC3F29Idx` (`did_number`),
  KEY `Fk_did_number_user_infoIdx` (`fk_product_id`),
  CONSTRAINT `FK__did_numbe__did_n__4BAC3F29` FOREIGN KEY (`did_number`) REFERENCES `did_number_pool` (`did_number`),
  CONSTRAINT `Fk_did_number_user_info` FOREIGN KEY (`fk_product_id`) REFERENCES `ref_did_product` (`pk_product_id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=102401 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `did_pool_temp`
--

DROP TABLE IF EXISTS `did_pool_temp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `did_pool_temp` (
  `did_number` varchar(20) NOT NULL,
  `last_update` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`did_number`),
  KEY `idx2_did_pool_temp` (`last_update`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `did_price_Master`
--

DROP TABLE IF EXISTS `did_price_Master`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `did_price_Master` (
  `id` int NOT NULL AUTO_INCREMENT,
  `Fk_Product_ID` int NOT NULL,
  `Fk_Country_ID` int NOT NULL,
  `Fk_Numbertype` int NOT NULL,
  `Setup_Fee` float DEFAULT NULL,
  `Monthly_Fee` float DEFAULT NULL,
  `create_date` datetime(3) DEFAULT NULL,
  `create_by` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`Fk_Product_ID`,`Fk_Country_ID`,`Fk_Numbertype`),
  UNIQUE KEY `id` (`id`),
  KEY `FK__did_price__Fk_Co__19AACF41Idx` (`Fk_Country_ID`),
  KEY `FK__did_price__Fk_Nu__1A9EF37AIdx` (`Fk_Numbertype`),
  KEY `FK__did_price__Fk_Pr__18B6AB08Idx` (`Fk_Product_ID`),
  CONSTRAINT `FK__did_price__Fk_Co__19AACF41` FOREIGN KEY (`Fk_Country_ID`) REFERENCES `ref_did_country` (`pk_country_id`),
  CONSTRAINT `FK__did_price__Fk_Nu__1A9EF37A` FOREIGN KEY (`Fk_Numbertype`) REFERENCES `ref_did_number_range` (`pk_num_range_id`),
  CONSTRAINT `FK__did_price__Fk_Pr__18B6AB08` FOREIGN KEY (`Fk_Product_ID`) REFERENCES `ref_did_product` (`pk_product_id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `did_rate_master`
--

DROP TABLE IF EXISTS `did_rate_master`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `did_rate_master` (
  `rate_id` int NOT NULL AUTO_INCREMENT,
  `country_id` int DEFAULT NULL,
  `mrc_rate` float DEFAULT NULL,
  `status` int DEFAULT NULL,
  `fk_operator_id` int DEFAULT NULL,
  PRIMARY KEY (`rate_id`),
  KEY `FK__did_rate___count__45F365D3Idx` (`country_id`),
  KEY `FK__did_rate___fk_op__48CFD27EIdx` (`fk_operator_id`),
  CONSTRAINT `FK__did_rate___count__45F365D3` FOREIGN KEY (`country_id`) REFERENCES `ref_did_country` (`pk_country_id`),
  CONSTRAINT `FK__did_rate___fk_op__48CFD27E` FOREIGN KEY (`fk_operator_id`) REFERENCES `ref_did_operator` (`pk_operator_id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `did_removal_log`
--

DROP TABLE IF EXISTS `did_removal_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `did_removal_log` (
  `logid` int NOT NULL AUTO_INCREMENT,
  `logdate` datetime(3) DEFAULT NULL,
  `did_from` varchar(20) DEFAULT NULL,
  `did_to` varchar(20) DEFAULT NULL,
  `product_id` int DEFAULT NULL,
  `username` varchar(100) DEFAULT NULL,
  `assigned_number` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`logid`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=90990 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `did_vendor_preference`
--

DROP TABLE IF EXISTS `did_vendor_preference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `did_vendor_preference` (
  `country` varchar(150) NOT NULL,
  `vendor_name` varchar(125) NOT NULL,
  `vendor_preference` int DEFAULT NULL,
  `city_name` varchar(125) NOT NULL,
  PRIMARY KEY (`country`,`vendor_name`,`city_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `didportal_assign_number_to_product_OUT`
--

DROP TABLE IF EXISTS `didportal_assign_number_to_product_OUT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `didportal_assign_number_to_product_OUT` (
  `in_xml_data` longtext,
  `in_user_name` varchar(50) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `didportal_unifiedring_recycle_master_log_details`
--

DROP TABLE IF EXISTS `didportal_unifiedring_recycle_master_log_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `didportal_unifiedring_recycle_master_log_details` (
  `id` int NOT NULL AUTO_INCREMENT,
  `did` varchar(25) DEFAULT NULL,
  `sitecode` varchar(15) DEFAULT NULL,
  `currentdate` datetime DEFAULT NULL,
  `recycle_startdate` datetime DEFAULT NULL,
  `recycle_enddate` datetime DEFAULT NULL,
  `recycle_status` varchar(150) DEFAULT NULL,
  `reassign_to_mainpooldate` datetime DEFAULT NULL,
  `company_id` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=243 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `lcr_country_list`
--

DROP TABLE IF EXISTS `lcr_country_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lcr_country_list` (
  `country_id` varchar(10) DEFAULT NULL,
  `country_name` varchar(100) NOT NULL,
  PRIMARY KEY (`country_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `msisdn_number_pool`
--

DROP TABLE IF EXISTS `msisdn_number_pool`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `msisdn_number_pool` (
  `msisdn` varchar(20) NOT NULL,
  `fk_country_id` int DEFAULT NULL,
  `fk_product_id` int DEFAULT NULL,
  `status` int DEFAULT NULL,
  `create_date` datetime(3) DEFAULT NULL,
  `create_by` varchar(50) DEFAULT NULL,
  `last_update` datetime(3) DEFAULT NULL,
  `last_update_by` varchar(50) DEFAULT NULL,
  `assigned_date` datetime(3) DEFAULT NULL,
  `price` float DEFAULT NULL,
  `pick_date` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`msisdn`),
  KEY `FK__msisdn_nu__fk_co__2F9A1060Idx` (`fk_country_id`),
  KEY `FK__msisdn_nu__fk_pr__308E3499Idx` (`fk_product_id`),
  KEY `FK__msisdn_nu__msisd__36470DEFIdx2` (`msisdn`),
  KEY `idx_msisdn_num_1` (`fk_country_id`,`fk_product_id`),
  FULLTEXT KEY `idx_full_msisdn_num_1` (`msisdn`),
  CONSTRAINT `FK__msisdn_nu__fk_co__2F9A1060` FOREIGN KEY (`fk_country_id`) REFERENCES `ref_did_country` (`pk_country_id`),
  CONSTRAINT `FK__msisdn_nu__fk_pr__308E3499` FOREIGN KEY (`fk_product_id`) REFERENCES `ref_did_product` (`pk_product_id`),
  CONSTRAINT `msisdn_number_pool_ibfk_1` FOREIGN KEY (`fk_country_id`) REFERENCES `ref_did_country` (`pk_country_id`),
  CONSTRAINT `msisdn_number_pool_ibfk_2` FOREIGN KEY (`fk_product_id`) REFERENCES `ref_did_product` (`pk_product_id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `msisdn_number_user_info`
--

DROP TABLE IF EXISTS `msisdn_number_user_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `msisdn_number_user_info` (
  `id` int NOT NULL AUTO_INCREMENT,
  `first_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `fk_product_id` int DEFAULT NULL,
  `assigned_date` datetime(3) DEFAULT NULL,
  `assigned_by` varchar(250) DEFAULT NULL,
  `purchase_price` float DEFAULT NULL,
  `exp_date` datetime(3) DEFAULT NULL,
  `number_status` int DEFAULT NULL,
  `reg_country` varchar(50) DEFAULT NULL,
  `company_id` int DEFAULT NULL,
  `company_name` varchar(150) DEFAULT NULL,
  `msisdn_number` varchar(20) DEFAULT NULL,
  UNIQUE KEY `id` (`id`),
  KEY `FK__msisdn_nu__msisd__6A30C649Idx` (`msisdn_number`),
  KEY `idx_msisdn_number_user_1` (`fk_product_id`,`company_id`),
  FULLTEXT KEY `idx_full_msisdn_number_user_1` (`company_name`,`first_name`,`last_name`),
  CONSTRAINT `FK__msisdn_nu__msisd__6A30C649` FOREIGN KEY (`msisdn_number`) REFERENCES `msisdn_number_pool` (`msisdn`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=1842 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `porting`
--

DROP TABLE IF EXISTS `porting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `porting` (
  `port_id` int NOT NULL AUTO_INCREMENT,
  `did_number` varchar(20) NOT NULL,
  `portout_date` datetime(3) DEFAULT NULL,
  `port_network` varchar(150) DEFAULT NULL,
  `create_date` datetime(3) DEFAULT NULL,
  `create_by` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`did_number`),
  UNIQUE KEY `port_id` (`port_id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `purchase_did_number_by_country_city_log`
--

DROP TABLE IF EXISTS `purchase_did_number_by_country_city_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchase_did_number_by_country_city_log` (
  `product_id` int DEFAULT NULL,
  `country` varchar(150) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `price` float DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ref_LCR_did_type_list`
--

DROP TABLE IF EXISTS `ref_LCR_did_type_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ref_LCR_did_type_list` (
  `did_type_id` int NOT NULL AUTO_INCREMENT,
  `did_type_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`did_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ref_did_chart_type`
--

DROP TABLE IF EXISTS `ref_did_chart_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ref_did_chart_type` (
  `pk_chart_id` int NOT NULL,
  `chart_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`pk_chart_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ref_did_city`
--

DROP TABLE IF EXISTS `ref_did_city`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ref_did_city` (
  `pk_city_id` int NOT NULL,
  `fk_country_id` int DEFAULT NULL,
  `city_name` varchar(100) DEFAULT NULL,
  `city_code` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`pk_city_id`),
  KEY `FK__ref_did_c__fk_co__03317E3DIdx` (`fk_country_id`),
  KEY `FK__did_numbe__fk_ci__182C9B23Idx2` (`pk_city_id`),
  CONSTRAINT `FK__ref_did_c__fk_co__03317E3D` FOREIGN KEY (`fk_country_id`) REFERENCES `ref_did_country` (`pk_country_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ref_did_country`
--

DROP TABLE IF EXISTS `ref_did_country`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ref_did_country` (
  `pk_country_id` int NOT NULL,
  `country_name` varchar(100) DEFAULT NULL,
  `country_code` varchar(5) DEFAULT NULL,
  `iso2_code` varchar(10) DEFAULT NULL,
  `is_local` int NOT NULL DEFAULT '0',
  `is_ur_enable` int DEFAULT NULL,
  `iso3` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`pk_country_id`),
  KEY `FK__did_numbe__fk_co__2E1BDC42Idx` (`pk_country_id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ref_did_number_range`
--

DROP TABLE IF EXISTS `ref_did_number_range`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ref_did_number_range` (
  `pk_num_range_id` int NOT NULL,
  `num_range_name` varchar(30) DEFAULT NULL,
  `is_freephone` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`pk_num_range_id`),
  KEY `FK__did_price__Fk_Nu__1A9EF37AIdx2` (`pk_num_range_id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ref_did_number_status`
--

DROP TABLE IF EXISTS `ref_did_number_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ref_did_number_status` (
  `status_id` int NOT NULL,
  `status` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`status_id`),
  KEY `FK__did_numbe__statu__1A14E395Idx` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ref_did_operator`
--

DROP TABLE IF EXISTS `ref_did_operator`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ref_did_operator` (
  `pk_operator_id` int NOT NULL AUTO_INCREMENT,
  `operator_name` varchar(100) DEFAULT NULL,
  `status` int DEFAULT NULL,
  `Is_Api` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`pk_operator_id`),
  KEY `FK__did_numbe__fk_op__2F10007BIdx2` (`pk_operator_id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ref_did_product`
--

DROP TABLE IF EXISTS `ref_did_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ref_did_product` (
  `pk_product_id` int NOT NULL,
  `product_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`pk_product_id`),
  KEY `Fk_did_number_pool_productIdx2` (`pk_product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_logu`
--

DROP TABLE IF EXISTS `tbl_logu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_logu` (
  `country_id` int DEFAULT NULL,
  `pk_city_id` int DEFAULT NULL,
  `city_name` varchar(150) DEFAULT NULL,
  `process_type` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `temp_ur_did_number`
--

DROP TABLE IF EXISTS `temp_ur_did_number`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `temp_ur_did_number` (
  `sitecode` varchar(5) NOT NULL,
  `switchcode` varchar(5) NOT NULL,
  `trunkout` varchar(16) NOT NULL,
  `pfx` varchar(32) NOT NULL,
  `xlatout` varchar(24) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `trmop_did`
--

DROP TABLE IF EXISTS `trmop_did`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `trmop_did` (
  `did` varchar(15) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ur_extn_did_number_allocation_log`
--

DROP TABLE IF EXISTS `ur_extn_did_number_allocation_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ur_extn_did_number_allocation_log` (
  `company_id` int DEFAULT NULL,
  `mobileno` varchar(20) DEFAULT NULL,
  `product_id` int DEFAULT NULL,
  `country_id` int DEFAULT NULL,
  `city_id` int DEFAULT NULL,
  `assigned_by` varchar(20) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=42315 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vectone_as_vendor_did_number_pool`
--

DROP TABLE IF EXISTS `vectone_as_vendor_did_number_pool`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vectone_as_vendor_did_number_pool` (
  `id` int NOT NULL AUTO_INCREMENT,
  `did_number` varchar(20) NOT NULL,
  `fk_operator_id` int DEFAULT NULL,
  `fk_country_id` int DEFAULT NULL,
  `fk_city_id` int DEFAULT NULL,
  `fk_product_id` int DEFAULT NULL,
  `status` int DEFAULT NULL,
  `create_date` datetime(3) DEFAULT NULL,
  `last_update` datetime(3) DEFAULT NULL,
  `update_by` varchar(100) DEFAULT NULL,
  `uploaded_by` varchar(50) DEFAULT NULL,
  `assigned_date` datetime(3) DEFAULT NULL,
  `area_code` varchar(50) DEFAULT NULL,
  `fk_num_range_id` int DEFAULT NULL,
  `CUPID` int DEFAULT NULL,
  PRIMARY KEY (`did_number`),
  UNIQUE KEY `id` (`id`),
  KEY `FK__vectone_a__fk_ci__4A8310C6Idx` (`fk_city_id`),
  KEY `FK__vectone_a__fk_co__4B7734FFIdx` (`fk_country_id`),
  KEY `FK__vectone_a__statu__4D5F7D71Idx` (`status`),
  KEY `FK__vectone_a__fk_op__4C6B5938Idx` (`fk_operator_id`),
  KEY `Fk_did_number_pool_product1Idx` (`fk_product_id`),
  CONSTRAINT `FK__vectone_a__fk_ci__4A8310C6` FOREIGN KEY (`fk_city_id`) REFERENCES `ref_did_city` (`pk_city_id`),
  CONSTRAINT `FK__vectone_a__fk_ci__4F47C5E3` FOREIGN KEY (`fk_city_id`) REFERENCES `ref_did_city` (`pk_city_id`),
  CONSTRAINT `FK__vectone_a__fk_co__4B7734FF` FOREIGN KEY (`fk_country_id`) REFERENCES `ref_did_country` (`pk_country_id`),
  CONSTRAINT `FK__vectone_a__fk_co__503BEA1C` FOREIGN KEY (`fk_country_id`) REFERENCES `ref_did_country` (`pk_country_id`),
  CONSTRAINT `FK__vectone_a__fk_op__4C6B5938` FOREIGN KEY (`fk_operator_id`) REFERENCES `ref_did_operator` (`pk_operator_id`),
  CONSTRAINT `FK__vectone_a__fk_op__51300E55` FOREIGN KEY (`fk_operator_id`) REFERENCES `ref_did_operator` (`pk_operator_id`),
  CONSTRAINT `FK__vectone_a__statu__4D5F7D71` FOREIGN KEY (`status`) REFERENCES `ref_did_number_status` (`status_id`),
  CONSTRAINT `FK__vectone_a__statu__5224328E` FOREIGN KEY (`status`) REFERENCES `ref_did_number_status` (`status_id`),
  CONSTRAINT `Fk_did_number_pool_product1` FOREIGN KEY (`fk_product_id`) REFERENCES `ref_did_product` (`pk_product_id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping events for database 'DIDPORTAL'
--

--
-- Dumping routines for database 'DIDPORTAL'
--
/*!50003 DROP FUNCTION IF EXISTS `didnumber_stock_count` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` FUNCTION `didnumber_stock_count`(
status INT,
country_id INT,
city_id INT,  
operator_id INT,
product_id INT,
number_range INT) RETURNS longtext CHARSET utf8mb4
    DETERMINISTIC
begin

  
  
   DECLARE v_count LONGTEXT;  
   
   
   if country_id <> 29 and number_range <> 0 then
 
      Set number_range = 0;
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select   count(1) INTO v_count from did_number_pool a where a.status = status AND
  (fk_country_id = country_id or country_id = 0) and
  (fk_city_id = city_id or city_id = 0) and
  (fk_operator_id = operator_id or operator_id = 0) and
  (fk_product_id = product_id or product_id = 0);
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   ELSE
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select   count(1) INTO v_count from did_number_pool a where a.status = status AND
  (fk_country_id = country_id or country_id = 0) and
  (fk_city_id = city_id or city_id = 0) and
  (fk_operator_id = operator_id or operator_id = 0) and
  (fk_product_id = product_id or product_id = 0) and
  (a.fk_num_range_id = number_range or number_range = 0);
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   end if;  
   return v_count;  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `did_func_porting_number` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` FUNCTION `did_func_porting_number`(orderid INT,numbertype INT) RETURNS longtext CHARSET utf8mb4
    DETERMINISTIC
BEGIN
   
    DECLARE v_number LONGTEXT;  
    
    IF numbertype = 1 then
  
       SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
       select   group_concat(transfer_no) INTO v_number
       from unifiedring.ur_portin_req_no_info where reqid = orderid   order by id asc;
       SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
    end if;  
    
    IF numbertype = 2 then
  
       SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
       select   group_concat(replace_no)   INTO v_number 
       from unifiedring.ur_portin_req_no_info  where reqid = orderid   order by id asc;
       SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
    end if;  
    
    set v_number = insert(v_number,1,0,'');  
    
    return v_number;  
    
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `did_func_porting_number_test` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` FUNCTION `did_func_porting_number_test`(orderid INT,numbertype INT) RETURNS longtext CHARSET utf8mb4
    DETERMINISTIC
BEGIN
   
    DECLARE v_number LONGTEXT;  
    
    IF numbertype = 1 then
  
       SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
       select   group_concat(transfer_no) INTO v_number
       from unifiedring.ur_portin_req_no_info where reqid = orderid   order by id asc;
       SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
    end if;  
    
    IF numbertype = 2 then
  
       SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
       select   group_concat(replace_no)   INTO v_number 
       from unifiedring.ur_portin_req_no_info  where reqid = orderid   order by id asc;
       SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
    end if;  
    
    set v_number = insert(v_number,1,0,'');  
    
    return v_number;  
    
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `fn_get_country_formated_number` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` FUNCTION `fn_get_country_formated_number`(did VARCHAR(20)) RETURNS varchar(20) CHARSET utf8mb4
    DETERMINISTIC
begin
   DECLARE v_country_prefix VARCHAR(4);
   DECLARE v_prefix_len INT; 
	
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   a.country_code INTO v_country_prefix from ref_did_country a where a.country_code = left(did,CHAR_LENGTH(RTRIM(a.country_code)))
   and IFNULL(is_local,0) = 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
	
   if IFNULL(v_country_prefix,'') <> '' then
      set did = insert(did,1,CHAR_LENGTH(RTRIM(v_country_prefix)),'0');
   end if;

   return   did;  
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `get_vendor_preference_by_arecode` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` FUNCTION `get_vendor_preference_by_arecode`(v_country VARCHAR(125),v_area_code VARCHAR(30)) RETURNS longtext CHARSET utf8mb4
    DETERMINISTIC
begin
 
    DECLARE v_output LONGTEXT;
    DECLARE v_output2 LONGTEXT;
 	
    select  group_CONCAT(vendor_name,' ',vendor_preference )  INTO v_output from   did_vendor_preference where country = v_country and city_name = v_area_code   order by vendor_preference asc;
 	 
    return v_output;
 	
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `get_vendor_preference_by_arecode_1` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` FUNCTION `get_vendor_preference_by_arecode_1`(country VARCHAR(125),
area_code VARCHAR(15)) RETURNS longtext CHARSET utf8mb4
    DETERMINISTIC
begin

    DECLARE v_output LONGTEXT;
    DECLARE v_output2 LONGTEXT;
 	
    select   group_concat(((v_output,','),' '),IFNULL(vendor_name,''),' ', IFNULL(CAST(vendor_preference AS CHAR(30)),'')) INTO v_output 
     from   did_vendor_preference  a where a.country = country and city_name = area_code   order by vendor_preference asc;
 	 
    return v_output;
 	
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `get_vendor_preference_by_arecode_vendor` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` FUNCTION `get_vendor_preference_by_arecode_vendor`(v_country VARCHAR(125),v_city VARCHAR(30)) RETURNS longtext CHARSET utf8mb4
    DETERMINISTIC
begin
 
    DECLARE v_output LONGTEXT;
    DECLARE v_output2 LONGTEXT;
 	
    select   group_CONCAT(v_output,' ',vendor_name) INTO v_output from  did_vendor_preference where country = v_country and city_name = v_city   order by vendor_preference asc;
 	 
    return v_output;
 	
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `didportal_assign_number_to_product` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `didportal_assign_number_to_product`(in_xml_data LONGTEXT,
 number_range INT ,
 in_user_name VARCHAR(50),
 CUPID INT)
begin
 
    DECLARE v_error_code INT; 
    DECLARE v_error_msg VARCHAR(250); 
    DECLARE v_hDoc INT; 
    DECLARE v_insert_list LONGTEXT; 
    DECLARE v_xml_list LONGTEXT; 
    DECLARE v_SQL LONGTEXT; 
    DECLARE v_update_col LONGTEXT;
    DECLARE v_push_notify_flag INT;
    DECLARE Swv_RowCount INT; 
    
    DECLARE v_did_no varchar(25);
    DECLARE v_product_id int;
    
    DECLARE v_out_varchar_handle varchar(125) default '';
    DECLARE v_out_numbertype int default 1;
 	DECLARE v_out_status int default 0;
 	DECLARE v_out_NULL int default NULL;	 
         
    IF CUPID is null then
       set CUPID = 0;
    END IF;
    SET v_error_code = -1;
    SET v_error_msg = 'Number is Invalid'; 
 	  
    drop TEMPORARY table IF EXISTS tt_bulk_uplaod_did_product;
 
    CREATE TEMPORARY TABLE tt_bulk_uplaod_did_product
    (
       idx INT   AUTO_INCREMENT PRIMARY KEY,
       did_no VARCHAR(20),
       number_range INT,
       product_id INT
    )  AUTO_INCREMENT = 1; 
 
 
 	
    
 
    
 
 
 
 			
    
   
 				
   
        Drop temporary table IF EXISTS xml_did_no_tbl; create temporary table xml_did_no_tbl(id int auto_increment primary key, did_no varchar(20));
  		Drop temporary table IF EXISTS xml_product_id_tbl; create temporary table xml_product_id_tbl(id int auto_increment primary key, product_id int);
        
         SELECT replace(ExtractValue(in_xml_data, '//did[1]'),' ',','), 
                replace(ExtractValue(in_xml_data, '//area_code[1]'),' ',',')
                   into v_did_no,v_product_id ;
                   
         
                   
  			call unifiedring.Split(v_did_no,',');  insert into xml_did_no_tbl (did_no) select Items from unifiedring.tt_Split_temptable;
              call unifiedring.Split(v_product_id,',');  insert into xml_product_id_tbl (product_id) select Items from unifiedring.tt_Split_temptable;
 
              
              INSERT INTO tt_bulk_uplaod_did_product(did_no,product_id)
            	select did_no,product_id
              from xml_did_no_tbl a join xml_product_id_tbl b on a.id = b.id;	 
              
             
               	
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    UPDATE did_number_pool a
    JOIN tt_bulk_uplaod_did_product b on a.did_number = b.did_no
    and IFNULL(a.fk_product_id,0) = 0 set a.fk_product_id = b.product_id,a.assigned_date = CURRENT_TIMESTAMP,a.status = 1,
    a.fk_num_range_id = IFNULL(number_range,v_out_NULL),a.CUPID = IFNULL(CUPID,v_out_NULL);
    SET Swv_RowCount = ROW_COUNT();
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 		  
    if Swv_RowCount > 0 then
 		  
       set v_error_code = 0;
       set v_error_msg = 'Number was assigned to particular product';
    end if;
 		  
 		 
 	
 		
    IF v_error_code = 0 AND  EXISTS(SELECT  1 FROM tt_bulk_uplaod_did_product WHERE  product_id = 1 AND IFNULL(did_no,v_out_varchar_handle) <> '' LIMIT 1) then
 		
 			  insert into multinb.multi_number_pool(normalized_number,number,number_type,country_name,country_code,area_name,area_code,status)
       select did_no,right(did_no,7) as did,v_out_numbertype as numbertype,c.country_name,
 			IFNULL(c.country_code,v_out_varchar_handle) as country_code,d.city_name,IFNULL(d.city_code,v_out_varchar_handle) as city_code,v_out_status as status from tt_bulk_uplaod_did_product a
       join did_number_pool b on b.did_number = a.did_no
       join ref_did_country c on b.fk_country_id = c.pk_country_id
       join ref_did_city d on b.fk_city_id = d.pk_city_id
       and IFNULL(b.fk_product_id,v_out_status) <> 0 and did_number not in(select normalized_number from multinb.multi_number_pool);
    end if;
 	
 
 	
 
 
 
    select v_error_code as errcode,v_error_msg as errmsg;
 
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `didportal_create_city` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `didportal_create_city`(country_id INT,
   pk_city_id INT,
   city_name VARCHAR(150),
   process_type INT)
BEGIN
   
   	
   	
      DECLARE v_errcode INT;
      DECLARE v_errmsg VARCHAR(150);
      declare v_zero_handle int default 0;
      sp_exit:
      BEGIN 
   insert into  tbl_logu(country_id,pk_city_id,city_name,process_type)  values(country_id,pk_city_id,city_name,process_type);
   	
         IF process_type = 1 then
   	
            IF EXISTS(SELECT  1 FROM ref_did_city a where a.city_name = city_name and fk_country_id = country_id LIMIT 1) then
   		
               SET v_errcode = -1;
               SET v_errmsg = 'City name already exists';
               LEAVE sp_exit;
            end if;
            SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
            select   a.pk_city_id INTO pk_city_id from ref_did_city  a  order by a.pk_city_id desc LIMIT 1;
            SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
            set pk_city_id = IFNULL(pk_city_id,v_zero_handle)+1;
            INSERT INTO ref_did_city(pk_city_id,fk_country_id,city_name)
   		VALUES(pk_city_id,country_id,city_name);
   		
            IF ROW_COUNT() > 0 then
   		
               SET v_errcode = 0;
               SET v_errmsg = 'City was created successfully.';
               LEAVE sp_exit;
            end if;
         end if;
         IF process_type = 2 then
   	
            IF  EXISTS(SELECT  1 FROM ref_did_city a where a.pk_city_id <> pk_city_id AND a.city_name = city_name
            and fk_country_id = country_id LIMIT 1) then
   		
               SET v_errcode = -1;
               SET v_errmsg = 'City name already exists.';
               LEAVE sp_exit;
            end if;
            update ref_did_city a set a.city_name = city_name
            where a.pk_city_id = pk_city_id and fk_country_id = country_id;
            IF ROW_COUNT() > 0 then
   		
               SET v_errcode = 0;
               SET v_errmsg = 'City was created successfully.';
               LEAVE sp_exit;
            end if;
         end if;
         IF process_type = 3 then
   	
            IF EXISTS(SELECT  1 FROM did_number_pool where fk_city_id = pk_city_id LIMIT 1) then
   		
               SET v_errcode = -1;
               SET v_errmsg = 'Number already assigned for this City.Remove restricted!';
               LEAVE sp_exit;
            end if;
            delete from ref_did_city a where a.pk_city_id = pk_city_id and fk_country_id = country_id;
            IF ROW_COUNT() > 0 then
   		
               SET v_errcode = 0;
               SET v_errmsg = 'City Removed successfully.';
               LEAVE sp_exit;
            end if;
         end if;
      END;
      select v_errcode as errcode,v_errmsg as errmsg;
   	
   END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `didportal_create_country` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `didportal_create_country`(pk_country_id INT,
country_name VARCHAR(150),
process_type INT,
country_code VARCHAR(10))
BEGIN

   DECLARE v_errcode INT;
   DECLARE v_errmsg VARCHAR(150);
   
   declare pk_country_id_incr int;
   
   set v_errcode = -1;
   set v_errmsg = 'Failure';
   
   sp_exit:
   BEGIN
      IF process_type = 1 then
	
         IF EXISTS(SELECT  1 FROM ref_did_country a where a.country_name = country_name LIMIT 1) then
		
            SET v_errcode = -1;
            SET v_errmsg = 'Country name already exists';
            LEAVE sp_exit;
         end if;
         IF EXISTS(SELECT  1 FROM ref_did_country a where a.country_code = country_code LIMIT 1) then
		
            SET v_errcode = -1;
            SET v_errmsg = 'Country code already exists';
            LEAVE sp_exit;
         end if;
                  
         SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
         select   max(b.pk_country_id) INTO pk_country_id from ref_did_country  b  order by pk_country_id desc LIMIT 1;
         
         SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
         set pk_country_id = ifnull(pk_country_id,0)+1;

         INSERT INTO ref_did_country(pk_country_id,country_name,country_code)
		VALUES(pk_country_id,country_name,country_code);
        
        
		
         IF ROW_COUNT() > 0 then
		
            SET v_errcode = 0;
            SET v_errmsg = 'Country was created successfully.';
            LEAVE sp_exit;
         end if;
      end if;
      IF process_type = 2 then
	
         IF  EXISTS(SELECT  1 FROM ref_did_country a where a.pk_country_id <> pk_country_id
         AND  a.country_name = country_name LIMIT 1) then
		
            SET v_errcode = -1;
            SET v_errmsg = 'Country name already exists.';
            LEAVE sp_exit;
         end if;
         IF  EXISTS(SELECT 1 FROM ref_did_country a where a.pk_country_id <> pk_country_id
         AND  a.country_code = country_code LIMIT 1) then
		
            SET v_errcode = -1;
            SET v_errmsg = 'Country code already exists.';
            LEAVE sp_exit;
         end if;
         update ref_did_country a set a.country_name = country_name,a.country_code = country_code
         where a.pk_country_id = pk_country_id;
         IF ROW_COUNT() > 0 then
		
            SET v_errcode = 0;
            SET v_errmsg = 'Country was updated successfully.';
            LEAVE sp_exit;
         end if;
      end if;
      IF process_type = 3 then
	
         IF EXISTS(SELECT  1 FROM did_number_pool where fk_country_id = pk_country_id LIMIT 1) then
		
            SET v_errcode = -1;
            SET v_errmsg = 'Number already assigned for this Country.Remove restricted!';
            LEAVE sp_exit;
         end if;
         
         delete from ref_did_country a where a.pk_country_id = pk_country_id;
         
         IF ROW_COUNT() > 0 then
		
            SET v_errcode = 0;
            SET v_errmsg = 'Country Removed successfully.';
            LEAVE sp_exit;
         end if;
      end if;
   END;
   select v_errcode as errcode,v_errmsg as errmsg;
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `didportal_create_mrc_rate` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `didportal_create_mrc_rate`(country_id INT,
operator_id INT,
rate FLOAT)
BEGIN
	
   DECLARE v_errcode INT; 
   DECLARE v_errmsg VARCHAR(250);
	
   IF EXISTS(SELECT  1 FROM did_rate_master a where a.country_id = country_id
   and fk_operator_id = operator_id LIMIT 1) then
	
      update did_rate_master a set mrc_rate = rate where a.country_id = country_id
      and fk_operator_id = operator_id;
      if ROW_COUNT() > 0 then
		
         set v_errcode = 0;
         set v_errmsg = 'Success to update rate details.';
      end if;
   ELSE
		 insert into did_rate_master(country_id,fk_operator_id,mrc_rate,status)
		values(country_id,operator_id,rate,1);
		
      if ROW_COUNT() > 0 then
		
         set v_errcode = 0;
         set v_errmsg = 'Success to create rate details.';
      end if;
   end if;
	

   select v_errcode as errcode,v_errmsg as errmsg;
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `didportal_create_operator` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `didportal_create_operator`(pk_operator_id INT,
operator_name VARCHAR(50),
status INT,
process_type INT)
BEGIN

	
	
   DECLARE v_errcode INT;
   DECLARE v_errmsg VARCHAR(150);
	
   sp_exit:
   BEGIN
      IF process_type = 1 then
	
         IF EXISTS(SELECT  1 FROM ref_did_operator a where a.operator_name = operator_name LIMIT 1) then
		
            SET v_errcode = -1;
            SET v_errmsg = 'Operator name already exists';
            LEAVE sp_exit;
         end if;
         INSERT INTO ref_did_operator(operator_name,status)
		VALUES(operator_name,status);
		
         IF ROW_COUNT() > 0 then
		
            SET v_errcode = 0;
            SET v_errmsg = 'Operator was created successfully.';
            LEAVE sp_exit;
         end if;
      end if;
      IF process_type = 2 then
	
         IF  EXISTS(SELECT  1 FROM ref_did_operator a where a.operator_name = operator_name LIMIT 1) then
		
            SET v_errcode = -1;
            SET v_errmsg = 'Operator name already exists.';
            LEAVE sp_exit;
         end if;
         update ref_did_operator a set a.operator_name = operator_name,a.status = status
         where a.pk_operator_id = pk_operator_id;
         IF ROW_COUNT() > 0 then
		
            SET v_errcode = 0;
            SET v_errmsg = 'Operator was updated successfully.';
            LEAVE sp_exit;
         end if;
      end if;
      IF process_type = 3 then
	
         IF NOT  EXISTS(SELECT  1 FROM ref_did_operator a where a.pk_operator_id = pk_operator_id LIMIT 1) then
		
            SET v_errcode = -1;
            SET v_errmsg = 'Operator not exists.';
            LEAVE sp_exit;
         end if;
         IF EXISTS(SELECT  1 FROM did_number_pool where fk_operator_id = pk_operator_id LIMIT 1) then
		
            SET v_errcode = -1;
            SET v_errmsg = 'Did Number uploaded for this operator.can not able to delete';
            LEAVE sp_exit;
         end if;
         delete from ref_did_operator a where a.pk_operator_id = pk_operator_id;
         IF ROW_COUNT() > 0 then
		
            SET v_errcode = 0;
            SET v_errmsg = 'Operator Deleted successfully.';
            LEAVE sp_exit;
         end if;
      end if;
   END;
   select v_errcode as errcode,v_errmsg as errmsg;
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `didportal_create_products` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `didportal_create_products`(pk_product_id INT,
product_name VARCHAR(100),
process_type INT)
BEGIN
	
	
   DECLARE v_errcode INT;
   DECLARE v_errmsg VARCHAR(150);
	
   sp_exit:
   BEGIN
      IF process_type = 1 then
	
         IF EXISTS(SELECT  1 FROM ref_did_product a where a.product_name = product_name LIMIT 1) then
            SET v_errcode = -1;
            SET v_errmsg = 'Product name already exists';
            LEAVE sp_exit;
         end if;
         SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
         select   b.pk_product_id INTO pk_product_id from ref_did_product b   order by b.pk_product_id desc LIMIT 1;
         SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
         SET pk_product_id = IFNULL(pk_product_id,0)+1;
         INSERT INTO ref_did_product(pk_product_id,product_name)
		VALUES(pk_product_id,product_name);
		
         IF ROW_COUNT() > 0 then
		
            SET v_errcode = 0;
            SET v_errmsg = 'Product was created successfully.';
            LEAVE sp_exit;
         end if;
      end if;
      IF process_type = 2 then
	
         IF  EXISTS(SELECT  1 FROM ref_did_product a where a.product_name = product_name
         and a.pk_product_id <> pk_product_id LIMIT 1) then
		    
            SET v_errcode = -1;
            SET v_errmsg = 'Product name not exists';
            LEAVE sp_exit;
         end if;
   
         update ref_did_product a set a.product_name = product_name
         where a.pk_product_id = pk_product_id;
         IF ROW_COUNT() > 0 then
		
            SET v_errcode = 0;
            SET v_errmsg = 'Product was created successfully.';
            LEAVE sp_exit;
         end if;
      end if;
      IF process_type = 3 then
	
         IF EXISTS(SELECT  1 FROM did_number_pool where fk_product_id = pk_product_id LIMIT 1) then
		
            SET v_errcode = -1;
            SET v_errmsg = 'Number already assigned for this Product.Remove restricted!';
            LEAVE sp_exit;
         end if;
         delete from ref_did_product a where a.pk_product_id = pk_product_id;
         IF ROW_COUNT() > 0 then
		
            SET v_errcode = 0;
            SET v_errmsg = 'Product Removed successfully.';
            LEAVE sp_exit;
         end if;
      end if;
   END;
   select v_errcode as errcode,v_errmsg as errmsg;
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `didportal_get_city_by_country` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `didportal_get_city_by_country`(country_id INT)
BEGIN
	
   IF country_id is null then
      set country_id = 0;
   END IF;
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select pk_city_id,city_name,fk_country_id as country_id from ref_did_city
   where (country_id = 0 or fk_country_id = country_id)
   order by city_name;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `didportal_get_country` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `didportal_get_country`()
BEGIN

	
	
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select pk_country_id,country_name,country_code from ref_did_country order by country_name asc;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `didportal_get_country_by_iso3` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `didportal_get_country_by_iso3`(
p_iso2_code varchar(5)
)
Begin
	select * from ref_did_country where iso2_code = p_iso2_code;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `didportal_get_dashboard_chart` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `didportal_get_dashboard_chart`(
	chart_type INT  ,
 	number_range INT , 
 	CUPID INT
)
BEGIN
 	
    DECLARE v_errcode INT; 
    DECLARE v_errmsg VARCHAR(250);
 	  
    sp_exit:
    BEGIN
       IF chart_type is null then
          set chart_type = 0;
       END IF;
       IF number_range is null then
          set number_range = 0;
       END IF;
       IF CUPID is null then
          set CUPID = 0;
       END IF;
       IF chart_type = 1 then
 	
          CALL get_didportal_product_chart(number_range,CUPID);
          set v_errcode = 0;
          set v_errmsg = 'Success - Product chart details.';
          LEAVE sp_exit;
       ELSE 
          IF chart_type = 2 then
 	
             CALL get_didportal_vendor_chart(number_range,CUPID);
             set v_errcode = 0;
             set v_errmsg = 'Success - Vendor chart details.';
             LEAVE sp_exit;
          ELSE 
             IF chart_type = 3 then
 	
                CALL get_didportal_country_chart(number_range,CUPID);
                set v_errcode = 0;
                set v_errmsg = 'Success - Country chart details.';
                LEAVE sp_exit;
             ELSE 
                IF chart_type = 4 then 
 	
                   CALL get_didportal_number_range_chart(number_range,CUPID);
                   set v_errcode = 0;
                   set v_errmsg = 'Success - Number Range chart details.';
                   LEAVE sp_exit;
                ELSE
                   set v_errcode = -1;
                   set v_errmsg = 'Failure unable to fetch chart.';
                   LEAVE sp_exit;
                end if;
             end if;
          end if;
       end if;
    END;
    select v_errcode as errcode,v_errmsg as errmsg;
 
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `didportal_get_mrc_rate` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `didportal_get_mrc_rate`(
country_id INT,  
operator_id INT
)
BEGIN
   
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select a.country_id,b.country_name,a.mrc_rate,a.fk_operator_id as opr_id ,c.operator_name from did_rate_master a 
   join ref_did_country b on a.country_id = b.pk_country_id
   join ref_did_operator c on a.fk_operator_id = c.pk_operator_id;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;    
  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `didportal_get_number_country` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `didportal_get_number_country`(
didnumber varchar(20),
out countryid int ,
out city_id int 
)
BEGIN
	
	
	select a.fk_country_id,a.fk_city_id into countryid,city_id from  did_number_pool a where a.did_number=didnumber;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `didportal_get_number_list` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `didportal_get_number_list`(
 	country_id INT,    
 	number_status INT, 
 	number_range INT,
 	city_id INT,  
 	operator_id INT,  
 	CUPID INT
 )
SWL_return:
 BEGIN
      
      
    IF city_id is null then set city_id = 0;  END IF;
    IF operator_id is null then set operator_id = 0; END IF;
    IF CUPID is null then set CUPID = 0; END IF;
    if country_id <> 29 and number_range <> 0 then set number_range = 0; end if;  
 
  
  
    if number_status = 2 then 
       SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
       select did_number,b.country_name,d.city_name,c.operator_name,IFNULL(e.product_name,'') as product_name,
 	  a.fk_country_id,a.fk_operator_id,a.fk_city_id,a.fk_product_id,IFNULL(n.num_range_name,null) as Numbers_Range,
   case when a.status = 1 then 'Inuse'
       when a.status = 0 then 'Free' end as number_status,a.CUPID as CUPID
       from did_number_pool a 
       join ref_did_country b  on a.fk_country_id = b.pk_country_id
       join ref_did_operator c on a.fk_operator_id = c.pk_operator_id
       join ref_did_city d on a.fk_city_id = d.pk_city_id
       left join ref_did_number_range n on IFNULL(a.fk_num_range_id,0) = n.pk_num_range_id
       left join ref_did_product e on a.fk_product_id = e.pk_product_id
       where  a.fk_country_id = country_id  and
      (a.fk_city_id = city_id or city_id = 0) and
      ((a.fk_num_range_id = number_range) or (number_range = 0)) and
      (a.fk_operator_id = operator_id or operator_id = 0) and
      (a.CUPID = CUPID or CUPID = 0);
       SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
       LEAVE SWL_return;
    end if;  
      
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select did_number,b.country_name,d.city_name,c.operator_name,IFNULL(e.product_name,'') as product_name,
         a.fk_country_id,a.fk_operator_id,a.fk_city_id,a.fk_product_id,IFNULL(n.num_range_name,null) as Numbers_Range,
         case when a.status = 1 then 'Used'
    when a.status = 0 then 'Free' end as number_status ,a.CUPID as CUPID
    from did_number_pool a 
    join ref_did_country b  on a.fk_country_id = b.pk_country_id
    join ref_did_operator c on a.fk_operator_id = c.pk_operator_id
    join ref_did_city d on a.fk_city_id = d.pk_city_id
    left join ref_did_number_range n on IFNULL(a.fk_num_range_id,0) = n.pk_num_range_id
    left join ref_did_product e on a.fk_product_id = e.pk_product_id
    where a.fk_country_id = country_id and a.status = number_status and
        (a.fk_city_id = city_id or city_id = 0) and
        ((a.fk_num_range_id = number_range) or (number_range = 0)) and
        (a.fk_operator_id = operator_id or operator_id = 0) and (a.CUPID = CUPID or CUPID = 0);
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;   
      
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `didportal_get_number_range` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `didportal_get_number_range`()
BEGIN

  
   
   
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select pk_num_range_id,num_range_name from ref_did_number_range order by pk_num_range_id asc;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
   
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `didportal_get_number_stock` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `didportal_get_number_stock`(
  	country_id INT,
  	city_id INT,
  	number_range INT ,
  	operator_id INT,
  	product_id INT,
  	CUPID INT
  )
SWL_return:
     begin
     	
     	
  	DECLARE v_errcode INT DEFAULT -1; 
  	DECLARE v_errmsg VARCHAR(50) DEFAULT 'Failure';
  	DECLARE v_out_varchar_handle varchar(125) default '';
  	DECLARE v_out_zero_handle varchar(20) default '0';
  	DECLARE v_out_float_handle float default 0;
        
        IF country_id is null then set country_id = 0; END IF;
        IF city_id is null then set city_id = 0; END IF;
        IF operator_id is null then set operator_id = 0; END IF;
        IF product_id is null then set product_id = 0; END IF;
        IF CUPID is null then set CUPID = 0; END IF;
        
        if (number_range is null or number_range = '') then set number_range = 0; end if;
        
  sp_exit:BEGIN
  
           set number_range = IFNULL(number_range,v_out_zero_handle);
           set CUPID = IFNULL(CUPID,v_out_zero_handle);
           
           If country_id <> 29 and IFNULL(number_range,v_out_zero_handle) <> 0 then
     	
              set number_range = 0;
              IF country_id = 0 AND city_id = 0 AND operator_id = 0 AND product_id = 0 then
     		
                 SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
 					select b.country_name,v_out_varchar_handle as city,v_out_varchar_handle as Operator_name,
 							cast(didnumber_stock_count(1,a.fk_country_id,0,0,0,0) as double) used_count,
 							v_out_zero_handle as Numbers_Range,a.CUPID as CUPID,
 							cast(didnumber_stock_count(0,a.fk_country_id,0,0,0,0) as double) free_count,fk_country_id as country_id,
 							v_out_zero_handle fk_city_id,v_out_zero_handle fk_operator_id,v_out_float_handle as mrc_rate
 					from did_number_pool a 
 					join ref_did_country b  on a.fk_country_id = b.pk_country_id  
 					left outer join ref_did_product p  on a.fk_operator_id = p.pk_product_id
 					where status in(0,1) 
 					group by b.country_name,a.fk_country_id,a.CUPID;
                     
 				SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
                 
                 if row_count() > 0 then 
 					set v_errcode = 0;
 					set v_errmsg  = 'Success';
                 end if;
                 
                 LEAVE SWL_return;
                 
                 
              end if;
              
              SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
  				select b.country_name,d.city_name as city,c.operator_name as Operator_name,
  						cast(didnumber_stock_count(1,a.fk_country_id,a.fk_city_id,a.fk_operator_id,product_id,number_range) as double) used_count,
  						cast(didnumber_stock_count(0,a.fk_country_id,a.fk_city_id,a.fk_operator_id,product_id,number_range) as double) free_count,
  						v_out_zero_handle as Numbers_Range,a.CUPID as CUPID,
  						a.fk_country_id as country_id,a.fk_operator_id fk_operator_id,a.fk_city_id fk_city_id,IFNULL(r.mrc_rate,v_out_float_handle) as mrc_rate
  				from did_number_pool a 
  				join ref_did_country b  on a.fk_country_id = b.pk_country_id
  				join ref_did_operator c on a.fk_operator_id = c.pk_operator_id
  				join ref_did_city d on a.fk_city_id = d.pk_city_id
  				left outer join ref_did_product p  on a.fk_operator_id = p.pk_product_id
  				left join  did_rate_master r on a.fk_operator_id = r.fk_operator_id and
  				a.fk_country_id = r.country_id
  				where ((ifnull(operator_id,0) = 0) or a.fk_operator_id = operator_id) 
                and ((ifnull(country_id,0) = 0) or a.fk_country_id = country_id) 
                and ((ifnull(city_id,0) = 0) or a.fk_city_id = city_id) 
                and ((ifnull(product_id,0) = 0) or a.fk_product_id = product_id) 
  				group by b.country_name,a.fk_country_id,a.fk_city_id,a.fk_operator_id,d.city_name, c.operator_name,a.CUPID,IFNULL(r.mrc_rate,v_out_float_handle);
                 
                   if row_count() > 0 then 
 					set v_errcode = 0;
 					set v_errmsg  = 'Success';
                 end if;
                 
              SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
           end if;
           
           If country_id = 29 and IFNULL(number_range,v_out_zero_handle) <> 0 then
     	
              IF country_id = 0 AND city_id = 0 AND operator_id = 0 AND product_id = 0 then
     		
                 SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
 					select b.country_name,v_out_varchar_handle as city,v_out_varchar_handle as Operator_name,
 							cast(didnumber_stock_count(1,a.fk_country_id,0,0,0,0) as double) used_count,
 							n.num_range_name as Numbers_Range,CAST(a.CUPID AS CHAR(30)) as CUPID,
 							cast(didnumber_stock_count(0,a.fk_country_id,0,0,0,0) as double) free_count,fk_country_id as country_id,
 							v_out_zero_handle fk_city_id,v_out_zero_handle fk_operator_id,v_out_float_handle as mrc_rate
 					from did_number_pool a 
 					join ref_did_country b  on a.fk_country_id = b.pk_country_id
 					left join ref_did_number_range n on a.fk_num_range_id = n.pk_num_range_id
 					left outer join ref_did_product p  on a.fk_operator_id = p.pk_product_id
 					where status in(0,1) and ((a.fk_num_range_id = number_range) or (ifnull(number_range,0) = 0)) and ((a.CUPID = CUPID) or (ifnull(CUPID,0) = 0))
 					group by b.country_name,a.fk_country_id,n.num_range_name,a.CUPID;
                 
                   if row_count() > 0 then 
 					set v_errcode = 0;
 					set v_errmsg  = 'Success';
                 end if;
                 SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
                 LEAVE SWL_return;
              end if;
           end if;
           
           DROP TEMPORARY TABLE IF EXISTS tt_temp_did_portal_info;
           SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
           CREATE TEMPORARY TABLE tt_temp_did_portal_info 
           AS 
           SELECT fk_country_id,fk_operator_id,fk_city_id,fk_product_id,a.fk_num_range_id,count(1) as total_count,
  			(select count(1) from did_number_pool b where
                 a.fk_country_id = b.fk_country_id and a.fk_operator_id = b.fk_operator_id and
                 a.fk_city_id = b.fk_city_id and a.fk_product_id = b.fk_product_id
                 and status = 1
  			) as used_count,
  			(select count(1) from did_number_pool c where
                 a.fk_country_id = c.fk_country_id and IFNULL(a.fk_operator_id,v_out_zero_handle) = IFNULL(c.fk_operator_id,v_out_zero_handle) and
                 a.fk_city_id = c.fk_city_id and IFNULL(a.fk_product_id,v_out_zero_handle) = IFNULL(c.fk_product_id,v_out_zero_handle)
                 and IFNULL(status,v_out_zero_handle) = 0
  			) as Free_count,CUPID 
              from did_number_pool a 
              group by fk_country_id,fk_operator_id,fk_city_id,fk_product_id,a.fk_num_range_id,CUPID;
              
                if row_count() > 0 then 
 					set v_errcode = 0;
 					set v_errmsg  = 'Success';
                 end if;
              
              
           SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
           
           SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
  			select b.country_name,d.city_name as city,c.operator_name as Operator_name,sum(used_count) AS used_count,sum(Free_count) AS free_count,
  					n.num_range_name as Numbers_Range,a.CUPID as CUPID,a.fk_country_id as country_id,a.fk_operator_id fk_operator_id,
  					a.fk_city_id fk_city_id,IFNULL(r.mrc_rate,v_out_float_handle) as mrc_rate
  			from tt_temp_did_portal_info a 
  			join ref_did_country b  on a.fk_country_id = b.pk_country_id
  			join ref_did_operator c on a.fk_operator_id = c.pk_operator_id
  			join ref_did_city d on a.fk_city_id = d.pk_city_id
  			left join ref_did_number_range n on a.fk_num_range_id = n.pk_num_range_id
  			left outer join ref_did_product p  on a.fk_operator_id = p.pk_product_id
  			left join  did_rate_master r on a.fk_operator_id = r.fk_operator_id and
  			a.fk_country_id = r.country_id
  			where ((ifnull(operator_id,0) = 0) or (a.fk_operator_id = operator_id)) 
			and ((ifnull(country_id,0) = 0) or (a.fk_country_id = country_id)) 
            and ((ifnull(city_id,0) = 0) or (a.fk_city_id = city_id)) 
            and ((ifnull(product_id,0) = 0) or (a.fk_product_id = product_id)) 
            and ((ifnull(number_range,0) = 0) or (a.fk_num_range_id = number_range)) 
            and ((ifnull(CUPID,0) = 0) or (a.CUPID = CUPID))
  			group by b.country_name,a.fk_country_id,a.fk_city_id,a.fk_operator_id,d.city_name,c.operator_name,n.num_range_name,a.CUPID,IFNULL(r.mrc_rate,v_out_float_handle);
             
           if ROW_COUNT() > 0 then
              set v_errcode = 0;
              set v_errmsg  = 'Success';
              LEAVE sp_exit;
           end if;
           SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
        END;
        select v_errcode as errcode, v_errmsg as errmsg;
     
     END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `didportal_get_operator` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `didportal_get_operator`()
BEGIN

  
   
   
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select pk_operator_id,operator_name from ref_did_operator
   where status = 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
   
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `didportal_get_product` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `didportal_get_product`()
BEGIN

  
   
   
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select pk_product_id,product_name from ref_did_product order by product_name asc;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
   
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `didportal_number_search` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `didportal_number_search`(
 did VARCHAR(20),
 did_to VARCHAR(20),
 search_type INT,
 number_range INT,
 countrty_id INT,
 city_id INT,
 operator_id INT,
 area_code VARCHAR(50),
 Number_Type VARCHAR(50),
 Date_range_from VARCHAR(50),
 Date_range_to VARCHAR(50),
 CUPID INT)
SWL_return:
 BEGIN
 
 	
    DECLARE v_msisdn_found INT; 
 	
 	
    IF number_range is null then
       set number_range = 0;
    END IF;
    IF countrty_id is null then
       set countrty_id = 0;
    END IF;
    IF city_id is null then
       set city_id = 0;
    END IF;
    IF operator_id is null then
       set operator_id = 0;
    END IF;
    IF area_code is null then
       set area_code = '';
    END IF;
    IF Number_Type is null then
       set Number_Type = '1';
    END IF;
    IF Date_range_from is null then
       set Date_range_from = '';
    END IF;
    IF Date_range_to is null then
       set Date_range_to = '';
    END IF;
    IF CUPID is null then
       set CUPID = 0;
    END IF;
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select   1 INTO v_msisdn_found from  msisdn_number_user_info a where a.msisdn_number = did    LIMIT 1;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 	
    IF v_msisdn_found = 1 then
 	
       SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
       SELECT 	a.msisdn,	'Vectone' as operator_name,
 						0 as operator_id,				a.fk_country_id as country_id,
 						b.country_name,									804 as fk_city_id,
 						'' as city_name,									IFNULL(a.fk_product_id,0) as fk_product_id,
 						IFNULL(e.product_name,'') as product_name,		CAST(IFNULL(f.company_id,'') AS CHAR(30)) as assigned_user,
 						IFNULL(f.first_name,'') as first_name,			IFNULL(f.last_name,'') as last_name,
 						IFNULL(a.price,0) as purchase_price,	f.assigned_date as subs_start_date,
 						TIMESTAMPADD(YEAR,5,f.assigned_date) as exp_date,							a.create_date as purchase_date,
 						f.exp_date as Subs_End_Date,					'' as Area_code,
 						'' as Number_Type,								g.Status,'Mobile Number' as Numbers_Range,
 						0 as CUPID,								NULL as activity_log_usage_info,
 						f.company_name as company_name,
 						f.company_id as company_id		 from msisdn_number_pool a
       join ref_did_country b on a.fk_country_id = b.pk_country_id
       left join ref_did_product e on IFNULL(a.fk_product_id,0) = e.pk_product_id
       left join msisdn_number_user_info f on a.msisdn = f.msisdn_number
       join ref_did_number_status g on a.Status = g.status_id  
       where (a.msisdn = did and IFNULL(did_to,'') = '') or
 			  ((a.msisdn between did and did_to) and (did <> '' and did_to <> '')) LIMIT 1;
       SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
       LEAVE SWL_return;
    end if;
 	
 	
    IF countrty_id <> 29 and countrty_id <> 0 and number_range <> 0 then
 	
       SET number_range = 0;
       IF (did IS NOT NULL) and (did <> '') then
 		
          SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
          Select 	a.did_number,								d.operator_name as operator_name,
 					a.fk_operator_id as operator_id,				a.fk_country_id as country_id,
 					b.country_name,									a.fk_city_id,
 					c.city_name,									IFNULL(a.fk_product_id,0) as fk_product_id,
 					IFNULL(e.product_name,'') as product_name,		IFNULL(f.assigned_user,'') as assigned_user,
 					IFNULL(f.first_name,'') as first_name,			IFNULL(f.last_name,'') as last_name,
 					IFNULL(f.purchase_price,0) as purchase_price,	f.assigned_date as subs_start_date,
 					f.exp_date as exp_date,							a.create_date as purchase_date,
 					f.exp_date as Subs_End_Date,					a.area_code as Area_code,
 					'1' as Number_Type,								g.Status,'GEO' as Numbers_Range,
 					IFNULL(a.CUPID,0) as CUPID,								NULL as activity_log_usage_info,
 					f.company_name as company_name
          from did_number_pool a
          join ref_did_country b on a.fk_country_id = b.pk_country_id
          join ref_did_city c on a.fk_city_id = c.pk_city_id
          join ref_did_operator d on a.fk_operator_id = d.pk_operator_id
          left join ref_did_product e on IFNULL(a.fk_product_id,0) = e.pk_product_id
          left join did_number_user_info f on a.did_number = f.did_number
          join ref_did_number_status g on a.Status = g.status_id  
          where (a.did_number = did and IFNULL(did_to,'') = '') or
 			  ((a.did_number between did and did_to) and (did <> '' and did_to <> '')) and
 			  ((Date_range_from = '') or (a.create_date >= Date_range_from)) and
 			  ((Date_range_to = '') or (a.create_date <= Date_range_to)) and
 			  (IFNULL(search_type,100) = 100 or a.status = search_type) and
 			  ((a.fk_operator_id = operator_id) or (operator_id = 0)) and
 			  ((a.fk_country_id = countrty_id) or (countrty_id = 0)) and
 			  ((a.fk_city_id = city_id) or(city_id = 0)) and
 			  ((a.CUPID = CUPID) or (CUPID = 0)) and
 			  ((area_code = '') or(a.area_code = area_code) or (area_code is NULL)) LIMIT 1000;
          SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 	
       ELSE 
          IF (did IS NULL) or (did = '') then
 		
             SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
             select 	a.did_number,									d.operator_name as operator_name,
 						a.fk_operator_id as operator_id,				a.fk_country_id as country_id,
 						b.country_name,									a.fk_city_id,
 						c.city_name,									IFNULL(a.fk_product_id,0) as fk_product_id,
 						IFNULL(e.product_name,'') as product_name,		IFNULL(f.assigned_user,'') as assigned_user,
 						IFNULL(f.first_name,'') as first_name,			IFNULL(f.last_name,'') as last_name,
 						IFNULL(f.purchase_price,0) as purchase_price,	f.assigned_date as subs_start_date,
 						f.exp_date as exp_date,							a.create_date as purchase_date,
 						f.exp_date as Subs_End_Date,					a.area_code as Area_code,
 						'1' as Number_Type,								g.Status,'GEO' as Numbers_Range,
 						IFNULL(a.CUPID,0) as CUPID,								NULL as activity_log_usage_info,
 						f.company_name as company_name
             from did_number_pool a
             join ref_did_country b on a.fk_country_id = b.pk_country_id
             join ref_did_city c on a.fk_city_id = c.pk_city_id
             join ref_did_operator d on a.fk_operator_id = d.pk_operator_id
             left join ref_did_product e on IFNULL(a.fk_product_id,0) = e.pk_product_id
             left join did_number_user_info f on a.did_number = f.did_number
             join ref_did_number_status g on a.Status = g.status_id  
             where 
 			  
 			  ((Date_range_from = '') or (a.create_date >= Date_range_from)) and
 			  ((Date_range_to = '') or (a.create_date <= Date_range_to)) and
 			  (IFNULL(search_type,100) = 100 or a.status = search_type) and
 			  ((a.fk_operator_id = operator_id) or (operator_id = 0)) and
 			  ((a.fk_country_id = countrty_id) or (countrty_id = 0)) and
 			  ((a.fk_city_id = city_id) or(city_id = 0)) and
 			  ((a.CUPID = CUPID) or (CUPID = 0)) and
 			  ((area_code = '') or(a.area_code = area_code) or (area_code is NULL)) 
             order by f.id desc LIMIT 1;
             SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
          end if;
       end if;
    ELSE  
 	
       IF (did IS NOT NULL) and (did <> '') then
 	
          SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
          select 	a.did_number,									d.operator_name as operator_name,
 						a.fk_operator_id as operator_id,				a.fk_country_id as country_id,
 						b.country_name,									a.fk_city_id,
 						c.city_name,									IFNULL(a.fk_product_id,0) as fk_product_id,
 						IFNULL(e.product_name,'') as product_name,		IFNULL(f.assigned_user,'') as assigned_user,
 						IFNULL(f.first_name,'') as first_name,			IFNULL(f.last_name,'') as last_name,
 						IFNULL(f.purchase_price,0) as purchase_price,	f.assigned_date as subs_start_date,
 						f.exp_date as exp_date,							a.create_date as purchase_date,
 						f.exp_date as Subs_End_Date,					a.area_code as Area_code,
 						'1' as Number_Type,								g.Status,IFNULL(n.num_range_name,'') as Numbers_Range,
 						IFNULL(a.CUPID,0) as CUPID,								NULL as activity_log_usage_info	,
 						f.company_name as company_name,
 						f.company_id as company_id
          from did_number_pool a
          join ref_did_country b on a.fk_country_id = b.pk_country_id
          join ref_did_city c on a.fk_city_id = c.pk_city_id
          join ref_did_operator d on a.fk_operator_id = d.pk_operator_id
          left join ref_did_number_range n on a.fk_num_range_id = n.pk_num_range_id
          left join ref_did_product e on IFNULL(a.fk_product_id,0) = e.pk_product_id
          left join did_number_user_info f on a.did_number = f.did_number
          join ref_did_number_status g on a.Status = g.status_id  
          where (a.did_number = did and IFNULL(did_to,'') = '') or
 			  ((a.did_number between did and did_to) and (did <> '' and did_to <> '')) and
 			  ((Date_range_from = '') or (a.create_date >= Date_range_from)) and
 			  ((Date_range_to = '') or (a.create_date <= Date_range_to)) and
 			  (IFNULL(search_type,100) = 100 or a.status = search_type) and
 			  ((a.fk_operator_id = operator_id) or (operator_id = 0)) and
 			  ((a.fk_country_id = countrty_id) or (countrty_id = 0)) and
 			  ((a.fk_city_id = city_id) or(city_id = 0)) and
 			  ((a.fk_num_range_id = number_range) or (number_range = 0)) and
 			  ((a.CUPID = CUPID) or (CUPID = 0)) and
 			  ((area_code = '') or(a.area_code = area_code) or (area_code is NULL)) 
          order by f.id desc LIMIT 1;
          SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 	
       ELSE 
          IF (did IS NULL) or (did = '') then
 		
             SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
             select 	a.did_number,									d.operator_name as operator_name,
 						a.fk_operator_id as operator_id,				a.fk_country_id as country_id,
 						b.country_name,									a.fk_city_id,
 						c.city_name,									IFNULL(a.fk_product_id,0) as fk_product_id,
 						IFNULL(e.product_name,'') as product_name,		IFNULL(f.assigned_user,'') as assigned_user,
 						IFNULL(f.first_name,'') as first_name,			IFNULL(f.last_name,'') as last_name,
 						IFNULL(f.purchase_price,0) as purchase_price,	f.assigned_date as subs_start_date,
 						f.exp_date as exp_date,							a.create_date as purchase_date,
 						f.exp_date as Subs_End_Date,					a.area_code as Area_code,
 						'1' as Number_Type,								g.Status,IFNULL(n.num_range_name,'') as Numbers_Range,
 						IFNULL(a.CUPID,0) as CUPID,								NULL as activity_log_usage_info,
 						f.company_name as company_name,
 						f.company_id as company_id
             from did_number_pool a
             join ref_did_country b on a.fk_country_id = b.pk_country_id
             join ref_did_city c on a.fk_city_id = c.pk_city_id
             join ref_did_operator d on a.fk_operator_id = d.pk_operator_id
             left join ref_did_number_range n on a.fk_num_range_id = n.pk_num_range_id
             left join ref_did_product e on IFNULL(a.fk_product_id,0) = e.pk_product_id
             left join did_number_user_info f on a.did_number = f.did_number
             join ref_did_number_status g on a.Status = g.status_id  
             where 
 			  
 			  ((Date_range_from = '') or (a.create_date >= Date_range_from)) and
 			  ((Date_range_to = '') or (a.create_date <= Date_range_to)) and
 			  (IFNULL(search_type,100) = 100 or a.status = search_type) and
 			  ((a.fk_operator_id = operator_id) or (operator_id = 0)) and
 			  ((a.fk_country_id = countrty_id) or (countrty_id = 0)) and
 			  ((a.fk_city_id = city_id) or(city_id = 0)) and
 			  ((a.CUPID = CUPID) or (CUPID = 0)) and
 			  ((a.fk_num_range_id = number_range) or (number_range = 0)) and
 			  ((area_code = '') or(a.area_code = area_code) or (area_code is NULL));
             SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
          end if;
       end if;
    end if;
 		
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `didportal_remove_numbers` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `didportal_remove_numbers`(country_id INT,  
city_id INT,  
operatorid INT,  
number_range INT,
in_xml_data LONGTEXT,
in_user_name VARCHAR(50),
CUPID INT)
begin

   
   DECLARE v_error_code INT;   
   DECLARE v_error_msg LONGTEXT;   
   DECLARE v_hDoc INT;   
   DECLARE v_insert_list LONGTEXT;   
   DECLARE v_xml_list LONGTEXT;   
   DECLARE v_SQL LONGTEXT;   
   DECLARE v_update_col longtext;  
   DECLARE v_push_notify_flag INT;       
   DECLARE v_List longtext;
   
   DECLARE v_did_from VARCHAR(20);
   DECLARE v_did_to VARCHAR(20);
   
  
   
   sp_exit:BEGIN
   
      IF CUPID is null 
      then
         set CUPID = 0;
      END IF;
      
      SET v_error_code = -1;
      SET v_error_msg = 'Failure to remove did number.';
            
      drop TEMPORARY table IF EXISTS tt_bulk_remove_did;
      CREATE TEMPORARY TABLE tt_bulk_remove_did
      (
         idx INT   AUTO_INCREMENT PRIMARY KEY,
         country_id INT,
         city_id INT,
         operatorid INT,
         number_range INT,
         CUPID INT,
         did_from VARCHAR(20),
         did_to VARCHAR(20),
         product_id INT
      )  AUTO_INCREMENT = 1;
      
      
      
      
      

      
      
      
      
      
      
      
Drop temporary table IF EXISTS xml_did_from_tbl; create temporary table xml_did_from_tbl(id int auto_increment primary key, did_from varchar(100));
Drop temporary table IF EXISTS xml_did_to_tbl; create temporary table xml_did_to_tbl(id int auto_increment primary key, did_to VARCHAR(150));
       
      
        SELECT replace(ExtractValue(in_xml_data, '//did_from[1]'),' ',','), 
               replace(ExtractValue(in_xml_data, '//did_to[1]'),' ',',')
			   into v_did_from,v_did_to ;
               
       
                  
	call unifiedring.Split(v_did_from,',');  insert into xml_did_from_tbl (did_from) select Items from unifiedring.tt_Split_temptable;
	call unifiedring.Split(v_did_to,',');  insert into xml_did_to_tbl (did_to) select Items from unifiedring.tt_Split_temptable;
             
	INSERT INTO tt_bulk_remove_did(did_from,did_to)
	select did_from,did_to from xml_did_from_tbl a join xml_did_to_tbl b on a.id = b.id;
      
   
      
      UPDATE tt_bulk_remove_did a
      join did_number_pool b on b.did_number between a.did_from and a.did_to set a.product_id = b.fk_product_id;
      
      
      if not exists(select  1 from did_number_pool a
      join tt_bulk_remove_did b on a.did_number between b.did_from and b.did_to
      and a.fk_country_id = country_id and a.fk_city_id = city_id and fk_operator_id = operatorid LIMIT 1)
      then

         LEAVE sp_exit;
      end if;
      
      
      
      if exists(select  1 from did_number_pool a
      join tt_bulk_remove_did b on a.did_number between b.did_from and b.did_to
      and a.fk_country_id = country_id and a.fk_city_id = city_id and fk_operator_id = operatorid
      and a.status = 1 and ((a.fk_num_range_id = number_range) or (number_range = 0))
      and ((a.CUPID = CUPID) or (CUPID = 0)) LIMIT 1)            
      
      then

         SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
         select  group_concat(did_number) INTO v_List from did_number_pool a
         join tt_bulk_remove_did b on a.did_number between b.did_from and b.did_to
         and a.fk_country_id = country_id and a.fk_city_id = city_id and fk_operator_id = operatorid
         and a.status = 1;
         SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
         
         SET v_error_code = -1;
         SET v_error_msg = CONCAT_WS('','some number range already allocated:',v_List);
         LEAVE sp_exit;
         
      end if;                  
      
      delete a from did_number_user_info a
      join tt_bulk_remove_did b on a.did_number between b.did_from and b.did_to;
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      delete a from did_number_pool a
     join tt_bulk_remove_did b on a.did_number between b.did_from and b.did_to
      and a.fk_country_id = country_id and a.fk_city_id = city_id and fk_operator_id = operatorid
      and ((a.fk_num_range_id = number_range) or (number_range = 0))
      and ((a.CUPID = CUPID) or (CUPID = 0));
      

      
    
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

      if found_rows() > 0 
      then   
         set v_error_code = 0;
         set v_error_msg = 'DID Number removed successfully.';
      end if;
      
      if v_error_code = 0 
      then

    
         delete a from multinb.multi_number_pool a
         join tt_bulk_remove_did b on a.normalized_number between b.did_from and b.did_to
         and a.status = 0 and b.product_id = 1;  
     
   
         SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
         insert into did_removal_log(logdate,did_from,did_to,product_id,username)
         select CURRENT_TIMESTAMP,did_from,did_to,product_id,in_user_name from tt_bulk_remove_did;
         SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
         
      end if;
      
   END;
   
   select v_error_code as errcode,v_error_msg as errmsg;  
  
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `didportal_unifiedring_recycle_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `didportal_unifiedring_recycle_details`(`Product_name` VARCHAR(50))
begin



   IF `Product_name` is null then
      set `Product_name` = 'UR';
   END IF;
   IF `Product_name` = 'UR' then
	
      select did,currentdate,	recycle_startdate,	recycle_enddate,recycle_status,reassign_to_mainpooldate
      from didportal_unifiedring_recycle_master_log_details;
   end if;
	
   IF `Product_name` = 'DC' then
	
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select did,insert_date,CAST(TIMESTAMPADD(DAY,1,insert_date) AS DATE) as recycle_startdate,
	 CAST(TIMESTAMPADD(DAY,1,recycle_process_date) as DATE) AS recycle_enddate,
	 case when status = 0 then 'IN-Progress'
      when status = 1 then 'Completed' end as recycle_status,CAST(recycle_process_date as DATE)
      from dcapp_recycle_log;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   end if;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `didportal_update_portout_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `didportal_update_portout_info`(
  did_number VARCHAR(20),
  portdate DATETIME(3),
  port_network VARCHAR(150),
  processby VARCHAR(50))
BEGIN
 
     DECLARE v_errcode INT;   
     DECLARE v_errmsg VARCHAR(160);  
     
     sp_exit:
     BEGIN
     
        set v_errcode = -1;
        set v_errmsg = 'No record found';
        
        IF NOT EXISTS(SELECT  1 FROM did_number_pool a where a.did_number = did_number LIMIT 1) then
   
           set v_errcode = -1;
           set v_errmsg = 'Did Number is invalid.';
           LEAVE sp_exit;
        end if;
        
        IF NOT EXISTS(SELECT 1 FROM porting a WHERE a.did_number = did_number LIMIT 1) then
        
		  INSERT INTO porting(did_number,portout_date,port_network,create_date,create_by)
		  VALUES(did_number,portdate,port_network,CURRENT_TIMESTAMP,processby);
    
           if row_count() > 0 then

              set v_errcode = 0;
              set v_errmsg = 'OK';
           end if;
           
           IF v_errcode = 0 then
    
              UPDATE did_number_pool a SET status = 5 where a.did_number = did_number;
           end if;
        end if;
     END;
     select v_errcode as errcode,v_errmsg as errmsg;  
     
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `didportal_upload_numbers` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `didportal_upload_numbers`(
 country_id INT,  
 city_id INT,  
 operatorid INT,  
 number_range INT , 
 in_xml_data LONGTEXT,
 in_user_name VARCHAR(50),
 installation_fee FLOAT,
 monthly_fee FLOAT,
 usage_fee FLOAT,
 per_minute_usage_fee FLOAT,
 document_reqired INT,
 support_flag INT,
 CUPID VARCHAR(150))
begin
 
  

    
    DECLARE v_error_code INT;   
    DECLARE v_error_msg VARCHAR(250);   
    DECLARE v_hDoc INT;   
    DECLARE v_insert_list LONGTEXT;   
    DECLARE v_xml_list LONGTEXT;   
    DECLARE v_SQL LONGTEXT;   
    DECLARE v_update_col longtext;  
    DECLARE v_push_notify_flag INT;  
    DECLARE v_operator_name VARCHAR(250);       
    DECLARE v_country VARCHAR(250);  
    DECLARE v_city VARCHAR(250);  
    DECLARE v_number_desc VARCHAR(250);       
    DECLARE v_country_code VARCHAR(10);
    
     DECLARE v_did VARCHAR(100);
     DECLARE v_area_code VARCHAR(150);
    
    
    sp_exit:BEGIN
    
       IF installation_fee is null 
       then
          set installation_fee = 0;
       END IF;
       
       IF monthly_fee is null 
       then
          set monthly_fee = 0;
       END IF;
       
       IF usage_fee is null 
       then
          set usage_fee = 0;
       END IF;
       
       IF per_minute_usage_fee is null 
       then
          set per_minute_usage_fee = 0;
       END IF;
       
       IF document_reqired is null 
       then
          set document_reqired = 0;
       END IF;
       
       IF support_flag is null 
       then
          set support_flag = 0;
       END IF;
       
       IF CUPID is null 
       then
          set CUPID = '';
       END IF;
       
       SET v_error_code = -1;
       SET v_error_msg = 'NUMBER ALREADY UPLOADED';
       
       SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
       select   country_name INTO v_country from ref_did_country  where pk_country_id = country_id    LIMIT 1;
       SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
       
       SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
       select   city_name INTO v_city from ref_did_city where fk_country_id = country_id and pk_city_id = city_id    LIMIT 1;
       SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
       
       select  num_range_name INTO v_number_desc from ref_did_number_range where pk_num_range_id = number_range;     
      
 	 drop TEMPORARY table IF EXISTS tt_bulk_uplaod_did;
      CREATE TEMPORARY TABLE tt_bulk_uplaod_did
       (
          idx INT   AUTO_INCREMENT PRIMARY KEY,
          country_id INT,
          city_id INT,
          operatorid INT,
          number_range INT,
          did VARCHAR(20),
          product_id INT,
          price FLOAT,
          product_name VARCHAR(100),
          area_code VARCHAR(50)
       )  AUTO_INCREMENT = 1;
       
       
      
 
       
      
      
      
      
      
 Drop temporary table IF EXISTS xml_did_tbl; create temporary table xml_did_tbl(id int auto_increment primary key, did varchar(100));
 Drop temporary table IF EXISTS xml_area_code_tbl; create temporary table xml_area_code_tbl(id int auto_increment primary key, area_code VARCHAR(150));
        
      
   SELECT replace(ExtractValue(in_xml_data, '//did[1]'),' ',','), 
 		  replace(ExtractValue(in_xml_data, '//area_code[1]'),' ',',')
 		  into v_did,v_area_code ;
 			
 	
 			
 	call unifiedring.Split(v_did,',');  insert into xml_did_tbl (did) select Items from unifiedring.tt_Split_temptable;
 	call unifiedring.Split(v_area_code,',');  insert into xml_area_code_tbl (area_code) select Items from unifiedring.tt_Split_temptable;
 		
 		INSERT INTO tt_bulk_uplaod_did(did,area_code)
 	    select did,area_code
 		from xml_did_tbl a join xml_area_code_tbl b on a.id = b.id;
       
      update tt_bulk_uplaod_did a set a.country_id = country_id, a.city_id = city_id,a.operatorid = operatorid,a.number_range = number_range;
      
      if exists(select did,count(1) from tt_bulk_uplaod_did
       group by did having count(1) > 1) 
       then 
          set v_error_code = -1;
          set v_error_msg = 'Duplicate number found in file.Please check';
          LEAVE sp_exit;
       end if;
       
       SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
       INSERT INTO did_number_pool(did_number,fk_operator_id,fk_country_id,fk_city_id,fk_product_id,status,create_date,
       uploaded_by,area_code,fk_num_range_id)
    
       SELECT did,operatorid,country_id,city_id,null,0 as status,CURRENT_TIMESTAMP,in_user_name,area_code,number_range
       from tt_bulk_uplaod_did where did not in(select did_number from did_number_pool);
    
    
       SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
       
       
       if found_rows() > 0 
       then   
          set v_error_code = 0;
          set v_error_msg = 'DID Number uploaded successfully.';
       end if;
       
       SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
       select   operator_name INTO v_operator_name from ref_did_operator where pk_operator_id = operatorid    LIMIT 1;
       SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
       
       if IFNULL(v_operator_name,'') like '%Vectone%' 
       then
    
          IF EXISTS(SELECT  1 FROM did_number_lcr_price_master_dtl where country = v_country and
          location = v_city and source_name = v_operator_name LIMIT 1)
          then
     
             UPDATE did_number_lcr_price_master_dtl SET a.installation_fee = installation_fee,a.monthly_fee = monthly_fee,usage_fee = usage_fee,
             per_minute_usage_fee = usage_fee,price_updatedate = CURRENT_TIMESTAMP,
             is_document_req = document_reqired,is_support_flag = support_flag
             where location = v_country  and source_name = v_operator_name;
             
          ELSE
          
      INSERT INTO did_number_lcr_price_master_dtl(country,location,area_code,number_Type,installation_fee,
     monthly_fee,usage_fee,per_minute_usage_fee,channels,price_updatedate,source_name,is_document_req,is_support_flag)
     
     VALUES(v_country,v_city,'',v_number_desc,installation_fee,monthly_fee,usage_fee,per_minute_usage_fee,
     0,CURRENT_TIMESTAMP,v_operator_name,document_reqired,support_flag);
     
          end if;
          
       end if;
 
    END;
    
    select v_error_code as errcode,v_error_msg as errmsg;  
   
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `didportal_vectoneapp_dashboard_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `didportal_vectoneapp_dashboard_details`(country_id VARCHAR(5),  
Date_range_from VARCHAR(50),  
Date_range_to VARCHAR(50))
BEGIN

   IF Date_range_from is null 
   then
      set Date_range_from = '';
   END IF;
   
   IF Date_range_to is null 
   then
      set Date_range_to = '';
   END IF;
   
   CALL votg_pbx.vectoneapp_dashboard_details(country_id,Date_range_from,Date_range_to);  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `didportal_vectoneapp_get_stock_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `didportal_vectoneapp_get_stock_details`(operator_id INT,  
 country_id VARCHAR(5))
BEGIN
 
 if (operator_id is null or operator_id = '') then set operator_id = 0; end if;
 
    CALL votg_pbx.vectoneapp_get_stock_details(operator_id,country_id);  
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `didportal_vectoneapp_get_stock_details_result_to_file` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `didportal_vectoneapp_get_stock_details_result_to_file`(
operator_id int,
country_id varchar(5)
)
BEGIN
	call votg_pbx.vectoneapp_get_stock_details_result_to_file (operator_id,country_id);
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `didportal_vectoneapp_orders_history_search` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `didportal_vectoneapp_orders_history_search`(order_id VARCHAR(10),  
country_id VARCHAR(5),  
Date_range_from VARCHAR(50),  
Date_range_to VARCHAR(50))
BEGIN
  
   IF Date_range_from is null then
      set Date_range_from = '';
   END IF;
   IF Date_range_to is null then
      set Date_range_to = '';
   END IF;
   CALL votg_pbx.vectoneapp_orders_history_search(order_id,country_id,Date_range_from,Date_range_to);  
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `didportal_vectoneapp_remove_number_list` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `didportal_vectoneapp_remove_number_list`(country_id INT,  
mobilenofrom VARCHAR(50),  
mobilenoto VARCHAR(50),  
processtype INT 
)
BEGIN
   CALL votg_pbx.didportal_vectoneapp_remove_number_list(country_id,mobilenofrom,mobilenoto,processtype);  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `didportal_vectoneapp_Reports_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `didportal_vectoneapp_Reports_details`(nos_Type VARCHAR(20),   
country_id VARCHAR(5),  
Date_range_from VARCHAR(50),  
Date_range_to VARCHAR(50))
BEGIN
  
   IF Date_range_from is null 
   then
      set Date_range_from = '';
   END IF;
   
   IF Date_range_to is null 
   then
      set Date_range_to = '';
   END IF;
   
   CALL votg_pbx.vectoneapp_Reports_details(nos_Type,country_id,Date_range_from,Date_range_to);  
   
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `didportal_vectoneapp_upload_numbers` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `didportal_vectoneapp_upload_numbers`(country_id INT,  
in_xml_data VARCHAR(2000),  
in_user_name VARCHAR(50))
BEGIN

   CALL votg_pbx.vectoneapp_upload_numbers(country_id,in_xml_data,in_user_name);  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `didportal_vectoneapp_vectoneapp_recycle_log_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `didportal_vectoneapp_vectoneapp_recycle_log_details`(country_id INT)
BEGIN

   CALL votg_pbx.vectoneapp_recycle_log_details(country_id);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `didportal_votg_number_lookup_search` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `didportal_votg_number_lookup_search`(mobileno VARCHAR(20) ,  
operator_id INT,  
country_id VARCHAR(5))
BEGIN

   CALL votg_pbx.votg_number_lookup_search(mobileno,operator_id,country_id);  
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `did_number_delete_vendor_preference` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `did_number_delete_vendor_preference`(country_name VARCHAR(150),
city_name VARCHAR(155))
begin
   DECLARE v_errcode INT DEFAULT -1;
   DECLARE v_errmsg VARCHAR(125) DEFAULT 'Failure';
 
   if exists(select  1 from did_vendor_preference a
   where country = country_name and a.city_name = city_name LIMIT 1) then

      delete  a  from  did_vendor_preference  a
      where country = country_name and a.city_name = city_name;
   end if;
   
   if ROW_COUNT() > 0 then
   
      set v_errcode = 0;
      set v_errmsg = 'Vendor preference has been deleted successfully';
   end if;

   select v_errcode as errcode,v_errmsg errmsg;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `did_number_get_country_city` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `did_number_get_country_city`(
 did_number VARCHAR(20),
OUT country_id INT ,
OUT city_id INT)
BEGIN

 	
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select   a.fk_country_id, a.fk_city_id INTO country_id,city_id from did_number_pool a where a.did_number = did_number;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 	
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `did_number_get_lcr_price_master_dtl_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `did_number_get_lcr_price_master_dtl_info`(  
country varchar(50),  
location varchar(50),  
area_code longtext    
)
Begin  
  
  declare v_country_name varchar(50);     
  declare v_loc longtext;  
  declare v_area varchar(250);   

drop temporary table if exists tt_temp_lcr_loc_tmp;
 create temporary table tt_temp_lcr_loc_tmp  
 (  
   country varchar(50),  
   loc varchar(100)  
 );  
   
 drop temporary table if exists tt_temp_lcr_area_tmp;
 create temporary table tt_temp_lcr_area_tmp  
 (  
   country varchar(50),  
   area_code varchar(100)  
 );  
 
  
  select d.name into v_country_name from country_config d where d.iso = country;  
  
  insert into tt_temp_lcr_loc_tmp(country,loc)  
  select a.country,a.location  from did_number_lcr_price_master_dtl a 
  where a.country = v_country_name and a.location like Concat('%',location,'%') ; 
  
  insert into tt_temp_lcr_area_tmp(country,area_code)  
  select a.country,a.area_code  from did_number_lcr_price_master_dtl  a
  where a.country = v_country_name and a.location like Concat('%',location,'%')  ;
  
    
    select   d.nicename country,b.loc as location,c.area_code,a.monthly_fee monthly_fee,  
    installation_fee as installation_fee,a.source_name,a.currency,d.iso,d.iso3,ifnull(e.reference,'') as address_reference   
    from did_number_lcr_price_master_dtl a    
    join tt_temp_lcr_loc_tmp b on a.country=b.country and a.location=b.loc  
    join tt_temp_lcr_area_tmp c  on a.country=c.country AND a.area_code=c.area_code  
    join country_config d  on a.country=d.name  
    LEFT JOIN BICS_DID_NUMBER_ADDR_INFO e on a.country=e.country and a.location=e.city  
    where (a.country = v_country_name)   
    and  (b.loc like Concat('%',location,'%'))    
    and  ((ifnull(c.area_code,'')=area_code) or ifnull(area_code,'')='')  
    order by a.monthly_fee asc  limit 1;
       
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `did_number_get_vendor_preference` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `did_number_get_vendor_preference`()
begin
 declare v_out_country_id int default 0;
 declare v_out_area_code varchar(151) default '';
    select Distinct v_out_country_id AS country_id,country,v_out_area_code AS area_code,city_name,
 IFNULL(get_vendor_preference_by_arecode(country,city_name),v_out_area_code) as vendor_preference_name,
 IFNULL(get_vendor_preference_by_arecode_vendor(country,city_name),v_out_area_code) as vendor_name
    from did_vendor_preference ; 
  
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `did_number_insert_address_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `did_number_insert_address_info`(
did_number	VARCHAR(20),
first_name	VARCHAR(50),
last_name	VARCHAR(50),
vat_number	VARCHAR(50),
company_name	VARCHAR(150),
alias_name	VARCHAR(150),
street	VARCHAR(150),
streetNumber	VARCHAR(100),
box	VARCHAR(100),
residence	VARCHAR(100),
floor_info	VARCHAR(100),
postal_code	VARCHAR(50),
city	VARCHAR(100),
state	VARCHAR(100),
country	VARCHAR(50),
reference	VARCHAR(100),
status	VARCHAR(100),
comment	VARCHAR(500),
serviceUsage	VARCHAR(500),
addressDocuments	VARCHAR(500),
email_id	VARCHAR(100))
BEGIN


	
	
   DECLARE v_errcode INT; 
   DECLARE v_errmsg VARCHAR(250);
   DECLARE v_now DATETIME(3); 
	
   set v_errcode = -1;
   set v_errmsg = 'Failure to do process';
   set v_now = CURRENT_TIMESTAMP;
	
   IF EXISTS(SELECT  1 FROM  BICS_DID_NUMBER_ADDR_INFO a WHERE a.reference = reference and  a.did_number = did_number LIMIT 1) then
	
      UPDATE BICS_DID_NUMBER_ADDR_INFO a SET a.did_number = did_number,a.first_name = first_name,a.last_name = last_name,
      a.vat_number = vat_number,a.company_name = company_name,a.alias_name = alias_name,
      a.street = street,a.streetNumber = streetNumber,a.box = box,a.residence = residence,
      a.floor_info = floor_info,a.postal_code = postal_code,a.city = city,
      a.state = state,a.country = country,a.status = status,a.comment = comment,
      a.serviceUsage = serviceUsage,a.addressDocuments = addressDocuments,a.email_id = email_id,
      a.last_update = v_now
      WHERE a.reference = reference;
            
   ELSE
		 INSERT INTO BICS_DID_NUMBER_ADDR_INFO(did_number,first_name,last_name,vat_number,company_name,alias_name,
		street,streetNumber,box,residence,floor_info,postal_code,city,state,country,reference,status,comment,serviceUsage,
		addressDocuments,email_id,create_date)
		VALUES(did_number,first_name,last_name,vat_number,company_name,alias_name,
		street,streetNumber,box,residence,floor_info,postal_code,city,state,country,reference,status,comment,serviceUsage,
		addressDocuments,email_id,v_now);
	
   end if;
   
         IF row_Count() > 0 then
			 set v_errcode = 0;
			 set v_errmsg = 'Success to do the address info';
		end if;
	
   Select v_errcode as errcode,v_errmsg as errmsg;
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `did_number_insert_vendor_preference` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `did_number_insert_vendor_preference`(
country VARCHAR(155),
 country_id INT,
 city_name VARCHAR(155),
 area_code VARCHAR(155),
 vendor_name VARCHAR(555),
 vendor_preference VARCHAR(555)
 )
begin
    DECLARE v_errcode INT DEFAULT -1;
    DECLARE v_errmsg VARCHAR(125) DEFAULT 'Failure';
   
    DROP TEMPORARY TABLE IF EXISTS tt_temp_vendor;
    create TEMPORARY table tt_temp_vendor
    (
       id INT   AUTO_INCREMENT PRIMARY KEY,
       country VARCHAR(155),
       country_id INT,
       city_name VARCHAR(155),
       area_code VARCHAR(20),
       vendor_name VARCHAR(125)
    )  AUTO_INCREMENT = 1;
 	
    DROP TEMPORARY TABLE IF EXISTS tt_temp_vendor_preference;
    create TEMPORARY table tt_temp_vendor_preference
    (
       id INT   AUTO_INCREMENT PRIMARY KEY,
       country VARCHAR(155),
       country_id INT,
       city_name VARCHAR(155),
       vendor_name VARCHAR(555),
       vendor_preference VARCHAR(555)
    )  AUTO_INCREMENT = 1;
 	
    DROP TEMPORARY TABLE IF EXISTS tt_temp_total;
    create TEMPORARY table tt_temp_total
    (
       id INT AUTO_INCREMENT PRIMARY KEY,
       country VARCHAR(155),
       country_id INT,
       city_name VARCHAR(155),
       vendor_name VARCHAR(555),
       vendor_preference VARCHAR(555)
    )  AUTO_INCREMENT = 1;
 	
   
 
          call unifiedring.split(vendor_name,',') ;
          
          insert into tt_temp_vendor(country,country_id,city_name,vendor_name)
          select country,country_id,city_name,Items from unifiedring.tt_Split_temptable;
 	    
   
 	  
    call unifiedring.split(vendor_preference,',') ;
          
 		insert into tt_temp_vendor_preference(country,country_id,city_name,vendor_name,vendor_preference)
          select country,country_id,city_name,vendor_name,Items from unifiedring.tt_Split_temptable;
 	  
    insert into tt_temp_total(country,country_id,city_name,vendor_name,vendor_preference)
    select a.country,a.country_id,a.city_name,a.vendor_name,b.vendor_preference from tt_temp_vendor a
    join tt_temp_vendor_preference b on a.id = b.id;
 
    if exists(select  1 from did_vendor_preference a
    join tt_temp_total b on a.country = country and a.city_name = b.city_name LIMIT 1) then
 		
       delete from did_vendor_preference a where a.country = country and a.city_name = city_name;
    end if;
 
    insert into did_vendor_preference(country,city_name,vendor_name,vendor_preference)
    select a.country,ltrim(rtrim(a.city_name)),a.vendor_name,a.vendor_preference from tt_temp_total a;

    
    if ROW_COUNT() > 0 then
    
       set v_errcode = 0;
       set v_errmsg = 'Vendor preference added successfully';
    end if;
 
  
    select v_errcode as errcode,v_errmsg errmsg;
 
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `did_number_update_vendor_preference` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `did_number_update_vendor_preference`(
 country VARCHAR(155),
 country_id INT,
 city_name VARCHAR(155),
 area_code VARCHAR(155),
 vendor_name VARCHAR(555),
 vendor_preference VARCHAR(555))
begin
    DECLARE v_errcode INT DEFAULT -1;
    DECLARE v_errmsg VARCHAR(125) DEFAULT 'Failure';
    DROP TEMPORARY TABLE IF EXISTS tt_temp_vendor;
    create TEMPORARY table tt_temp_vendor
    (
       id INT   AUTO_INCREMENT PRIMARY KEY,
       country VARCHAR(20),
       country_id INT,
       city_name VARCHAR(155),
       area_code VARCHAR(20),
       vendor_name VARCHAR(555),
       vendor_preference VARCHAR(555)
    )  AUTO_INCREMENT = 1;
 	
    DROP TEMPORARY TABLE IF EXISTS tt_temp_vendor_preference;
 	
    create TEMPORARY table tt_temp_vendor_preference
    (
       id INT   AUTO_INCREMENT PRIMARY KEY,
       country VARCHAR(20),
       country_id INT,
       city_name VARCHAR(155),
       area_code VARCHAR(20),
       vendor_name VARCHAR(555),
       vendor_preference VARCHAR(555)
    )  AUTO_INCREMENT = 1;
 	
    DROP TEMPORARY TABLE IF EXISTS tt_temp_total;
 	
    create TEMPORARY table tt_temp_total
    (
       id INT   AUTO_INCREMENT PRIMARY KEY,
       country VARCHAR(20),
       country_id INT,
       city_name VARCHAR(155),
       area_code VARCHAR(20),
       vendor_name VARCHAR(555),
       vendor_preference VARCHAR(555)
    )  AUTO_INCREMENT = 1;
 	
   
 	  
       call unifiedring.split(vendor_name,',') ;

          insert into tt_temp_vendor(country,country_id,city_name,area_code,vendor_preference,vendor_name)
          select country,country_id,city_name,area_code,vendor_preference, Items from unifiedring.tt_Split_temptable;

   
 	  
       call unifiedring.split(vendor_preference,',') ;

 		insert into tt_temp_vendor_preference(country,country_id,city_name,area_code,vendor_name,vendor_preference)
          select country,country_id,city_name,area_code,vendor_name, Items from unifiedring.tt_Split_temptable;
 	  


    insert into tt_temp_total(country,country_id,city_name,area_code,vendor_name,vendor_preference)
    select a.country,a.country_id,a.city_name,b.area_code,a.vendor_name,b.vendor_preference
    from tt_temp_vendor a join tt_temp_vendor_preference b on a.id = b.id;
 	
 	
 	
 	

 	
    if exists(select  1 from did_vendor_preference a
    join tt_temp_total b on a.country = country and a.city_name = b.city_name LIMIT 1) then
 	
       delete from did_vendor_preference b where b.country = country and b.city_name = city_name;
    end if;
 	

    insert into did_vendor_preference(country,city_name,vendor_name,vendor_preference)
    select a.country,ltrim(rtrim(a.city_name)),a.vendor_name,a.vendor_preference from tt_temp_total a;
   
    if ROW_COUNT() > 0 then
    
       set v_errcode = 0;
       set v_errmsg = 'Vendor preference updated successfully';
    end if;
 
 
    select v_errcode as errcode,v_errmsg errmsg;
 
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `did_number_upload_integration` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `did_number_upload_integration`(
   	country_id int, 
   	city_id varchar(255),
   	operator_id int, 
   	number_range int , 
   	did_number_data varchar(30)
   )
Begin	
   		DECLARE v_errcode 		int default -1;
   		DECLARE v_errmsg 		varchar(50) default 'Failure';
   		DECLARE v_Maxi 			int;   
   		DECLARE v_i 			int;
   	 	DECLARE v_did_number 	BIGINT;
  		DECLARE v_product_id 	int;
  		DECLARE v_city_id 		int;
  		DECLARE max_pk_city_id 	int;
  		DECLARE v_pk_city_id 	int;
         
     Exit_Block: BEGIN      
  		SELECT 	pk_city_id 		INTO v_city_id 
  		FROM 	DIDPORTAL.ref_did_city 
  		WHERE 	fk_country_id 	= country_id 
  		AND 	city_name 		= city_id;
         
         SELECT 	did_number INTO v_did_number	
         FROM 	DIDPORTAL.did_number_pool
         WHERE 	did_number = did_number_data;
         
         IF v_did_number IS NOT NULL
         THEN
 			SET v_errcode 	= -1 ;
             SET v_errmsg 	= 'DID Number is already purchased' ;		
             LEAVE Exit_Block;
         END IF; 
           
 		if v_city_id is null then
 			select a.pk_city_id INTO max_pk_city_id from DIDPORTAL.ref_did_city a order by a.pk_city_id desc LIMIT 1;
 
 			set v_city_id = IFNULL(max_pk_city_id,0)+1;
 			 
 			INSERT INTO ref_did_city (pk_city_id,fk_country_id,city_name,city_code)
 			VALUES(v_city_id,country_id,city_id,null);            
 		End if;
           
 		INSERT INTO DIDPORTAL.did_number_pool (did_number,fk_operator_id,fk_country_id,fk_city_id,fk_product_id,status,create_date,last_update,update_by,uploaded_by,assigned_date,area_code,fk_num_range_id,CUPID)
 		VALUES(did_number_data,operator_id,country_id,v_city_id,1,1,current_timestamp,current_timestamp,null,'Admin-purchase',current_timestamp,20,1,0);
           
           if row_count() > 0 then
   			set v_errcode = 0 ;
               set v_errmsg = 'Succes: Inserted' ;
           End if;
 	END;
     
 	SELECT v_errcode as errcode, v_errmsg as errmsg;
   		
   		
   		
     		             
     	             
   End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `did_number_view_vendor_pricing` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `did_number_view_vendor_pricing`()
begin
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select a.operator_name as vendor_name,b.Country as country,b.location as location,b.area_code as area_code,b.number_Type as NumberType,
   b.installation_fee as installation_fee,b.monthly_fee as monthly_fee,b.usage_fee as usage_fee,b.per_minute_usage_fee as per_minute_usage_fee,
   b.channels as channels,b.currency,b.price_updatedate as price_updatedate,
   case when IFNULL(is_document_req,0) = 1 then 'Yes' else 'No' end as  is_document_req,
   case when IFNULL(b.is_support_flag,0) = 1 then 'Self'
   when IFNULL(b.is_support_flag,0) = 2 then 'Agent Support' else 'No' end as support_desc
   from ref_did_operator a
   join did_number_lcr_price_master_dtl b
   on a.operator_name = b.source_name
   order by b.price_updatedate desc;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `did_portal_get_imsi_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `did_portal_get_imsi_info`(country_code VARCHAR(20),
msisdn VARCHAR(20))
BEGIN
	
   IF msisdn is null then
      set msisdn = '';
   END IF;
   if country_code = '44' then
      CALL hlrdb.did_portal_get_imsi_pool(msisdn);
   end if;
		
	
   if country_code = '43' then
      CALL hlrdb.did_portal_get_imsi_pool(msisdn);
   end if;
		
	
   if country_code = '32' then
      CALL hlrdb.did_portal_get_imsi_pool(msisdn);
   end if;
		
		
   if country_code = '33' then
      CALL hlrdb.did_portal_get_imsi_pool(msisdn);
   end if;
		
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `did_portal_get_recycle_number_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `did_portal_get_recycle_number_info`()
BEGIN
  
   CALL multinb.LLOM_number_get_recycle_number();  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `did_portal_map_did_number` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `did_portal_map_did_number`(
    did_number VARCHAR(20),
    mobileno VARCHAR(20),
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    email VARCHAR(150),
    product_id INT,
    assign_date DATETIME(3),
    purchase_date DATETIME(3),
    purchase_price FLOAT,
    exp_date DATETIME(3),
    company_id INT,
    company_name VARCHAR(150),
    Number_Type VARCHAR(100),
    OUT city_code VARCHAR(50))
SWL_return:
    BEGIN
  
           
           
       DECLARE country_id INT; 
       DECLARE country_prefix VARCHAR(5);
       DECLARE is_flag int;
           
       IF company_id is null then set company_id = 0; END IF;      
       IF company_name is null then set company_name = ''; END IF;      
       IF Number_Type is null then set Number_Type = ''; END IF;      
       IF city_code is null then set city_code = ''; END IF;
       
       set is_flag = 0;
       
       IF IFNULL(Number_Type,'') = 'mobile_number' then
           
          CALL msisdn_update_available_no_list(did_number,product_id,first_name,last_name,company_id,company_name,is_flag);
          LEAVE SWL_return;
       end if;
           
           select fk_country_id,fk_city_id into country_id,city_code from did_number_pool a WHERE a.did_number = did_number;
      
      UPDATE did_number_pool a SET a.status = 1,a.fk_product_id = product_id,a.assigned_date = CURRENT_TIMESTAMP
       WHERE a.did_number = did_number;
           
		if row_Count() > 0 then        
			if not exists(select * from did_number_user_info a where a.did_number = did_number limit 1) then
				INSERT INTO did_number_user_info(did_number,assigned_user,first_name,last_name,email,fk_product_id,
				assigned_date,assigned_by,purchase_price,exp_date,company_id,company_name)
				VALUES(did_number,mobileno,first_name,last_name,email,product_id,assign_date,purchase_date,
				purchase_price,exp_date,company_id,company_name);
			end if;
		end if;
           
       select country_code INTO country_prefix from ref_did_country a where a.pk_country_id = country_id;
           
       if IFNULL(country_prefix,'') <> '' then
           
          CALL unifiedring.ur_did_update_country_prefix(did_number,country_prefix);
       end if;
           
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `did_portal_report_search` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `did_portal_report_search`(`product_id` INT,
  `country_id` INT,
  `operator_id` INT,
  `number_range` INT ,
  `number_status` INT,
  `CUPID` INT)
BEGIN
  	
     declare out_put_handle varchar(150) default '';
      declare out_put_handle_zero int default 0;
      declare v_out_put_handle_CUPID int ;
      
      set v_out_put_handle_CUPID= `CUPID`;
      
     IF `product_id` is null then
        set `product_id` = 0;
     END IF;
     IF `country_id` is null then
        set `country_id` = 0;
     END IF;
     IF `operator_id` is null then
        set `operator_id` = 0;
     END IF;
     IF `CUPID` is null then
        set `CUPID` = 0;
     END IF;
     IF `country_id` <> 29 AND `number_range` <> 0 then
  	
        SET `number_range` = 0;
        SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        select a.did_number,c.operator_name,f.country_name,
  		g.city_name as city,IFNULL(area_code,out_put_handle) as area_code,IFNULL(d.product_name,out_put_handle) as product_name,
  		out_put_handle_zero as Numbers_Range,v_out_put_handle_CUPID as CUPID,
  		IFNULL(e.assigned_user,out_put_handle) as assigned_user,IFNULL(e.first_name,out_put_handle) as customer_name from did_number_pool a
        join ref_did_number_status b  on a.status = b.status_id
        join ref_did_operator c  on a.fk_operator_id = c.pk_operator_id
  		
        left join ref_did_product d on a.fk_product_id = d.pk_product_id
        left join did_number_user_info e on a.did_number = e.did_number
        join ref_did_country f on a.fk_country_id = f.pk_country_id
        join ref_did_city g on a.fk_city_id = g.pk_city_id and g.fk_country_id = f.pk_country_id
        where a.status = `number_status` and
  		 ((`country_id` = 0) or (a.fk_country_id = `country_id`)) and
  		 ((`operator_id` = 0) or (a.fk_operator_id = `operator_id`)) and 
  		 
  		  ((`product_id` = 0) or (a.fk_product_id = `product_id`));
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
     else
        SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        select a.did_number,c.operator_name,f.country_name,
  		g.city_name as city,IFNULL(area_code,out_put_handle) as area_code,IFNULL(d.product_name,out_put_handle) as product_name,
  		IFNULL(n.num_range_name,out_put_handle_zero) as Numbers_Range,v_out_put_handle_CUPID as CUPID,
  		IFNULL(e.assigned_user,out_put_handle) as assigned_user,IFNULL(e.first_name,out_put_handle) as customer_name from did_number_pool a
        join ref_did_number_status b  on a.status = b.status_id
        join ref_did_operator c  on a.fk_operator_id = c.pk_operator_id
        left join ref_did_number_range n on a.fk_num_range_id = n.pk_num_range_id
        left join ref_did_product d on a.fk_product_id = d.pk_product_id
        left join did_number_user_info e on a.did_number = e.did_number
        join ref_did_country f on a.fk_country_id = f.pk_country_id
        join ref_did_city g on a.fk_city_id = g.pk_city_id and g.fk_country_id = f.pk_country_id
        where a.status = `number_status` and
  		 ((`country_id` = 0) or (a.fk_country_id = `country_id`)) and
  		 ((`operator_id` = 0) or (a.fk_operator_id = `operator_id`)) and
  		 ((a.fk_num_range_id = `number_range`) or (`number_range` = 0)) and
  		  ((`product_id` = 0) or (a.fk_product_id = `product_id`));
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
     end if;
  	
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `did_portal_update_did_number` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `did_portal_update_did_number`(
 did_number VARCHAR(20),
 mobileno VARCHAR(20),
 first_name VARCHAR(50),
 last_name VARCHAR(50),
 email VARCHAR(150),
 product_id INT,
 purchase_date DATETIME(3),
 purchase_price FLOAT,
 exp_date DATETIME(3),
 reg_country VARCHAR(100))
BEGIN
 
 	
    DECLARE v_country_id INT; 
    DECLARE v_country_prefix VARCHAR(5);
 	
      select a.fk_country_id into v_country_id from did_number_pool a    WHERE a.did_number = did_number;
     
    UPDATE  did_number_pool a SET a.status = 1,a.fk_product_id = product_id,a.assigned_date = CURRENT_TIMESTAMP
    WHERE a.did_number = did_number;
 	
    IF found_rows() > 0 then
		if not exists(select * from did_number_user_info a where a.did_number = did_number limit 1) then
			INSERT INTO did_number_user_info(did_number,assigned_user,first_name,last_name,email,fk_product_id,assigned_by,purchase_price,exp_date,reg_country)
			VALUES(did_number,mobileno,first_name,last_name,email,product_id,purchase_date, purchase_price,exp_date,reg_country);
		end if;
    end if;
 	
    select   b.country_code INTO v_country_prefix from ref_did_country b where b.pk_country_id = v_country_id;
 	
    if IFNULL(v_country_prefix,'') <> '' and product_id = 7 then
 	
       CALL unifiedring.ur_did_update_country_prefix(did_number,v_country_prefix);
    end if;
 	
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `did_portin_request_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `did_portin_request_details`()
begin
   
    select firstname as customer_name,bill_tele_ph_no as Number,'UK' as country,'Unifiedring' as Product_Name,
    did_func_porting_number(reqid,2) as Temporary_Number,reqdate as Request_Date,
    case when status = 1 then 'Inprogress'
    when status = 2 then 'Completed'
    when status = 3 then 'Failed' end as porting_status ,transfer_date as ported_date,cupid_id as cupid_id,
    did_func_porting_number(reqid,1) as transfer_no
    from unifiedring.ur_portin_request limit 100;  
       
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetAgentBasedChatReport` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `GetAgentBasedChatReport`(
p_startTmpstmp 			BIGINT,
p_endTmpstmp			BIGINT,
p_timeZone				VARCHAR(150),
p_domainId				INT,
p_agentName				VARCHAR(55),
p_queueName 			VARCHAR(255),
p_disposition 			VARCHAR(255),
p_limit					INT,
p_offset				INT
  )
BEGIN 

select sessionStartTime,
	   agentName,
       queueName,
       customerDetails,
       agentConnectTime,
       agentDisconnectTime,
       agentDuration,
       `source`,
       callType,
       activeChatTime,
       responseTime,
       disposition,
       chatStatus,
       queueDuration as queueWaitTime,
       afterCallWorkTime as ACWTime,
       '0%' as CSATScore 
from   sessionHistory
where  sessionStartTime 	= p_startTmpstmp
and    sessionEndTime   	= p_endTmpstmp
and    domainId		   		= p_domainId
and    agentName        	= p_agentName
and    queueName        	= p_queueName
and    disposition      	= p_disposition
order by p_limit,p_offset;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_didportal_country_chart` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `get_didportal_country_chart`(
 number_range INT ,
 CUPID INT
 )
BEGIN
 
 declare v_out_zero_handle int default 0;
     
   
    IF number_range is null then
       set number_range = 0;
    END IF;
    IF CUPID is null then
       set CUPID = 0;
    END IF;
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select IFNULL(b.country_name,'others') as Name,count(pk_country_id) as Total_purchased
    from did_number_pool a 
    join ref_did_country b on IFNULL(a.fk_country_id,v_out_zero_handle) = b.pk_country_id
    left join ref_did_number_range n on IFNULL(a.fk_num_range_id,v_out_zero_handle) = n.pk_num_range_id
    left join did_number_user_info c on a.did_number = c.did_number
    join ref_did_number_status e on a.Status = e.status_id
    where e.status_id  in(0,1)
    and IFNULL(c.purchase_price,v_out_zero_handle) = 0 
    and ((a.fk_num_range_id = number_range) or (number_range = 0))
    and ((a.CUPID = CUPID) or (CUPID = 0))
    group by b.country_name;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
     
   
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select IFNULL(b.country_name,'others') as Name,count(pk_country_id) as cancel_count
    from did_number_pool a 
    join ref_did_country b on IFNULL(a.fk_country_id,v_out_zero_handle) = b.pk_country_id
    left join ref_did_number_range n on IFNULL(a.fk_num_range_id,v_out_zero_handle) = n.pk_num_range_id
    left join did_number_user_info c on a.did_number = c.did_number
    join ref_did_number_status e on a.Status = e.status_id
    where e.status_id in(3)
    and IFNULL(c.purchase_price,v_out_zero_handle) = 0 
    and ((a.fk_num_range_id = number_range) or (number_range = 0))
    and ((a.CUPID = CUPID) or (CUPID = 0))
    group by b.country_name;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
     
   
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select IFNULL(b.country_name,'others') as Name,count(pk_country_id) as expiry_counts
    from did_number_pool a 
    join ref_did_country b on IFNULL(a.fk_country_id,v_out_zero_handle) = b.pk_country_id
    left join ref_did_number_range n on IFNULL(a.fk_num_range_id,v_out_zero_handle) = n.pk_num_range_id
    left join did_number_user_info c on a.did_number = c.did_number
    join ref_did_number_status e on a.Status = e.status_id
    where c.exp_date < CURRENT_TIMESTAMP 
    and IFNULL(c.purchase_price,v_out_zero_handle) = 0 
    and ((a.fk_num_range_id = number_range) or (number_range = 0))
    and ((a.CUPID = CUPID) or (CUPID = 0))   
   
    group by b.country_name;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
     
   
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select IFNULL(b.country_name,'others') as Name,count(pk_country_id) as recycle_counts
    from did_number_pool a 
    join ref_did_country b on IFNULL(a.fk_country_id,v_out_zero_handle) = b.pk_country_id
    left join ref_did_number_range n on IFNULL(a.fk_num_range_id,v_out_zero_handle) = n.pk_num_range_id
    left join did_number_user_info c on a.did_number = c.did_number
    join ref_did_number_status e on a.Status = e.status_id
    where e.status_id in(4)
    and IFNULL(c.purchase_price,v_out_zero_handle) = 0 
   
    group by b.country_name;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
     
   
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select IFNULL(b.country_name,'others') as Name,count(pk_country_id) as pred_counts
    from did_number_pool a 
    join ref_did_country b on IFNULL(a.fk_country_id,v_out_zero_handle) = b.pk_country_id
    left join did_number_user_info c on a.did_number = c.did_number
    join ref_did_number_status e on a.Status = e.status_id
    where c.exp_date between CURRENT_TIMESTAMP and  TIMESTAMPADD(day,5,CURRENT_TIMESTAMP)
    and IFNULL(c.purchase_price,v_out_zero_handle) = 0 
    and ((a.fk_num_range_id = number_range) or (number_range = 0))
    and ((a.CUPID = CUPID) or (CUPID = 0))
    group by b.country_name;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
     
   
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select IFNULL(b.country_name,'others') as Name,count(pk_country_id) as availno_counts
    from did_number_pool a 
    join ref_did_country b on IFNULL(a.fk_country_id,v_out_zero_handle) = b.pk_country_id
    left join ref_did_number_range n on IFNULL(a.fk_num_range_id,v_out_zero_handle) = n.pk_num_range_id
    left join did_number_user_info c on a.did_number = c.did_number
    join ref_did_number_status e on a.Status = e.status_id
    where e.status_id  in(4)
    and IFNULL(c.purchase_price,v_out_zero_handle) = 0 
    and ((a.fk_num_range_id = number_range) or (number_range = 0))
    and ((a.CUPID = CUPID) or (CUPID = 0))    
   
    group by b.country_name;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
     
   
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select IFNULL(b.country_name,'others') as Name,count(pk_country_id) as usedno_counts
    from did_number_pool a 
    join ref_did_country b on IFNULL(a.fk_country_id,v_out_zero_handle) = b.pk_country_id
    left join ref_did_number_range n on IFNULL(a.fk_num_range_id,v_out_zero_handle) = n.pk_num_range_id
    left join did_number_user_info c on a.did_number = c.did_number
    join ref_did_number_status e on a.Status = e.status_id
    where e.status_id  in(1)
    and IFNULL(c.purchase_price,v_out_zero_handle) = 0 
    and ((a.fk_num_range_id = number_range) or (number_range = 0))
    and ((a.CUPID = CUPID) or (CUPID = 0))   
   
    group by b.country_name;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
   
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_didportal_number_range_chart` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `get_didportal_number_range_chart`(number_range INT ,
  CUPID INT)
BEGIN
 declare v_out_zero_handle int default 0;
  	
     IF number_range is null then
        set number_range = 0;
     END IF;
     IF CUPID is null then
        set CUPID = 0;
     END IF;
     SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
     select IFNULL(n.num_range_name,'Others') as name, COUNT(1) as Total_purchased
     from did_number_pool a
     left join ref_did_number_range n on IFNULL(a.fk_num_range_id,v_out_zero_handle) = n.pk_num_range_id
     left join did_number_user_info f on a.did_number = f.did_number
     join ref_did_number_status g on a.Status = g.status_id  
     where g.status_id in(0,1)
     and a.fk_country_id = 29 
     and IFNULL(f.purchase_price,v_out_zero_handle) = 0 
     and ((a.fk_num_range_id = number_range) or (number_range = 0))
     and ((a.CUPID = CUPID) or (CUPID = 0))
     group by n.num_range_name
     order by n.num_range_name;
     SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
  
  	
     SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
     select IFNULL(n.num_range_name,'Others') as name, COUNT(1) as cancel_count
     from did_number_pool a
     left join ref_did_number_range n on IFNULL(a.fk_num_range_id,v_out_zero_handle) = n.pk_num_range_id
     left join did_number_user_info f on a.did_number = f.did_number
     join ref_did_number_status g on a.Status = g.status_id  
     where g.status_id in(3)
     and a.fk_country_id = 29 
     and IFNULL(f.purchase_price,v_out_zero_handle) = 0 
     and ((a.fk_num_range_id = number_range) or (number_range = 0))
     and ((a.CUPID = CUPID) or (CUPID = 0))
     group by n.num_range_name
     order by n.num_range_name;
     SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
  
  	
     SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
     select IFNULL(n.num_range_name,'Others') as name, COUNT(1) as expiry_counts
     from did_number_pool a
     left join ref_did_number_range n on IFNULL(a.fk_num_range_id,v_out_zero_handle) = n.pk_num_range_id
     left join did_number_user_info f on a.did_number = f.did_number
     join ref_did_number_status g on a.Status = g.status_id  
     where f.exp_date < CURRENT_TIMESTAMP 
     and IFNULL(f.purchase_price,v_out_zero_handle) = 0 
     and ((a.fk_num_range_id = number_range) or (number_range = 0))
     and ((a.CUPID = CUPID) or (CUPID = 0))
     and a.fk_country_id = 29 
     group by n.num_range_name
     order by n.num_range_name;
     SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
  
  	
     SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
     select IFNULL(n.num_range_name,'Others') as name, COUNT(1) as cancel_count
     from did_number_pool a
     left join ref_did_number_range n on IFNULL(a.fk_num_range_id,v_out_zero_handle) = n.pk_num_range_id
     left join did_number_user_info f on a.did_number = f.did_number
     join ref_did_number_status g on a.Status = g.status_id  
     where g.status_id in(4)
     and a.fk_country_id = 29 
     and IFNULL(f.purchase_price,v_out_zero_handle) = 0 
     and ((a.fk_num_range_id = number_range) or (number_range = 0))
     and ((a.CUPID = CUPID) or (CUPID = 0))
     group by n.num_range_name
     order by n.num_range_name;
     SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
  
  	
     SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
     select IFNULL(n.num_range_name,'Others') as name, COUNT(1) as cancel_count
     from did_number_pool a
     left join ref_did_number_range n on IFNULL(a.fk_num_range_id,v_out_zero_handle) = n.pk_num_range_id
     left join did_number_user_info f on a.did_number = f.did_number
     join ref_did_number_status g on a.Status = g.status_id  
     where f.exp_date between CURRENT_TIMESTAMP and  TIMESTAMPADD(day,5,CURRENT_TIMESTAMP)
     and IFNULL(f.purchase_price,v_out_zero_handle) = 0 
     and a.fk_country_id = 29 
     and ((a.fk_num_range_id = number_range) or (number_range = 0))
     and ((a.CUPID = CUPID) or (CUPID = 0))
     group by n.num_range_name
     order by n.num_range_name;
     SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
  
  	
     SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
     select IFNULL(n.num_range_name,'Others') as name, COUNT(1) as cancel_count
     from did_number_pool a
     left join ref_did_number_range n on IFNULL(a.fk_num_range_id,v_out_zero_handle) = n.pk_num_range_id
     left join did_number_user_info f on a.did_number = f.did_number
     join ref_did_number_status g on a.Status = g.status_id  
     where g.status_id  in(4)
     and IFNULL(f.purchase_price,v_out_zero_handle) = 0 
     and a.fk_country_id = 29 
     and ((a.fk_num_range_id = number_range) or (number_range = 0))
     and ((a.CUPID = CUPID) or (CUPID = 0))
     group by n.num_range_name
     order by n.num_range_name;
     SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
  
  	
     SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
     select IFNULL(n.num_range_name,'Others') as name, COUNT(1) as cancel_count
     from did_number_pool a
     left join ref_did_number_range n on IFNULL(a.fk_num_range_id,v_out_zero_handle) = n.pk_num_range_id
     left join did_number_user_info f on a.did_number = f.did_number
     join ref_did_number_status g on a.Status = g.status_id  
     where g.status_id  in(1)
     and IFNULL(f.purchase_price,v_out_zero_handle) = 0 
     and a.fk_country_id = 29 
     and ((a.fk_num_range_id = number_range) or (number_range = 0))
     and ((a.CUPID = CUPID) or (CUPID = 0))
     group by n.num_range_name
     order by n.num_range_name;
     SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_didportal_product_chart` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `get_didportal_product_chart`(
 number_range INT ,
 CUPID INT)
BEGIN
 
  declare v_handle_zero int default 0;
     
   
    IF number_range is null then
       set number_range = 0;
    END IF;
    IF CUPID is null then
       set CUPID = 0;
    END IF;
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select IFNULL(b.product_name,'Others') as Name,count(pk_product_id) as Total_purchased
    from did_number_pool a 
    left join ref_did_product b  on IFNULL(a.fk_product_id,v_handle_zero) = b.pk_product_id
    left join ref_did_number_range n on IFNULL(a.fk_num_range_id,v_handle_zero) = n.pk_num_range_id
    left join did_number_user_info c on a.did_number = c.did_number
    join ref_did_number_status e on a.Status = e.status_id
    where e.status_id  in(0,1)
    and IFNULL(c.purchase_price,v_handle_zero) = 0 
    and ((a.fk_num_range_id = number_range) or (number_range = 0))
    and ((a.CUPID = CUPID) or (CUPID = 0))
    group by b.product_name;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
     
   
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select IFNULL(b.product_name,'Others') as Name ,count(pk_product_id) as cancel_count
    from did_number_pool a 
    left join ref_did_product b  on IFNULL(a.fk_product_id,v_handle_zero) = b.pk_product_id
    left join ref_did_number_range n on IFNULL(a.fk_num_range_id,v_handle_zero) = n.pk_num_range_id
    left join did_number_user_info c on a.did_number = c.did_number
    join ref_did_number_status e on a.Status = e.status_id
    where e.status_id in(3)
    and IFNULL(c.purchase_price,v_handle_zero) = 0 
    and ((a.fk_num_range_id = number_range) or (number_range = 0))
    and ((a.CUPID = CUPID) or (CUPID = 0))
    group by b.product_name;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
   
   
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select IFNULL(b.product_name,'Others') as Name ,count(pk_product_id) as expiry_counts
    from did_number_pool a 
    left join ref_did_product b  on IFNULL(a.fk_product_id,v_handle_zero) = b.pk_product_id
    left join ref_did_number_range n on IFNULL(a.fk_num_range_id,v_handle_zero) = n.pk_num_range_id
    left join did_number_user_info c on a.did_number = c.did_number
    join ref_did_number_status e on a.Status = e.status_id
    where c.exp_date < CURRENT_TIMESTAMP 
    and IFNULL(c.purchase_price,v_handle_zero) = 0 
    and ((a.fk_num_range_id = number_range) or (number_range = 0))
    and ((a.CUPID = CUPID) or (CUPID = 0))   
   
    group by b.product_name;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
     
   
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select IFNULL(b.product_name,'Others') as Name ,count(pk_product_id) as recycle_counts
    from did_number_pool a 
    left join ref_did_product b  on IFNULL(a.fk_product_id,v_handle_zero) = b.pk_product_id
    left join ref_did_number_range n on IFNULL(a.fk_num_range_id,v_handle_zero) = n.pk_num_range_id
    left join did_number_user_info c on a.did_number = c.did_number
    join ref_did_number_status e on a.Status = e.status_id
    where e.status_id in(4)
    and IFNULL(c.purchase_price,v_handle_zero) = 0 
    and ((a.fk_num_range_id = number_range) or (number_range = 0))
    and ((a.CUPID = CUPID) or (CUPID = 0))  
   
    group by b.product_name;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
     
   
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select IFNULL(b.product_name,'Others') as Name ,count(pk_product_id) as pred_counts
    from did_number_pool a 
    left join ref_did_product b  on IFNULL(a.fk_product_id,v_handle_zero) = b.pk_product_id
    left join ref_did_number_range n on IFNULL(a.fk_num_range_id,v_handle_zero) = n.pk_num_range_id
    left join did_number_user_info c on a.did_number = c.did_number
    join ref_did_number_status e on a.Status = e.status_id
    where c.exp_date between CURRENT_TIMESTAMP and  TIMESTAMPADD(day,5,CURRENT_TIMESTAMP)
    and IFNULL(c.purchase_price,v_handle_zero) = 0 
    and ((a.fk_num_range_id = number_range) or (number_range = 0))
    and ((a.CUPID = CUPID) or (CUPID = 0))
    group by b.product_name;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
     
   
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select IFNULL(b.product_name,'Others') as Name ,count(pk_product_id) as availno_counts
    from did_number_pool a 
    left join ref_did_product b  on IFNULL(a.fk_product_id,v_handle_zero) = b.pk_product_id
    left join ref_did_number_range n on IFNULL(a.fk_num_range_id,v_handle_zero) = n.pk_num_range_id
    left join did_number_user_info c on a.did_number = c.did_number
    join ref_did_number_status e on a.Status = e.status_id
    where e.status_id  in(4)
    and IFNULL(c.purchase_price,v_handle_zero) = 0 
    and ((a.fk_num_range_id = number_range) or (number_range = 0))
    and ((a.CUPID = CUPID) or (CUPID = 0))  
   
    group by b.product_name;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
     
   
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select IFNULL(b.product_name,'Others') as Name ,count(pk_product_id) as usedno_counts
    from did_number_pool a 
    left join ref_did_product b  on IFNULL(a.fk_product_id,v_handle_zero) = b.pk_product_id
    left join ref_did_number_range n on IFNULL(a.fk_num_range_id,v_handle_zero) = n.pk_num_range_id
    left join did_number_user_info c on a.did_number = c.did_number
    join ref_did_number_status e on a.Status = e.status_id
    where e.status_id  in(1)
    and IFNULL(c.purchase_price,v_handle_zero) = 0 
    and ((a.fk_num_range_id = number_range) or (number_range = 0))
    and ((a.CUPID = CUPID) or (CUPID = 0))  
   
    group by b.product_name;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
   
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_didportal_vendor_chart` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `get_didportal_vendor_chart`(
 number_range INT ,
 CUPID INT)
BEGIN
declare v_out_zer_handle int default 0;
     
   
    IF number_range is null then
       set number_range = 0;
    END IF;
    IF CUPID is null then
       set CUPID = 0;
    END IF;
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select IFNULL(b.operator_name,'Others') as Name,count(pk_operator_id) as Total_purchased
    from did_number_pool a 
    join ref_did_operator b on IFNULL(a.fk_operator_id,v_out_zer_handle) = b.pk_operator_id
    left join ref_did_number_range n on IFNULL(a.fk_num_range_id,v_out_zer_handle) = n.pk_num_range_id
    left join did_number_user_info c on a.did_number = c.did_number
    join ref_did_number_status e on a.Status = e.status_id
    where e.status_id  in(0,1)
    and ((a.fk_num_range_id = number_range) or (number_range = 0))
    and ((a.CUPID = CUPID) or (CUPID = 0))
    and IFNULL(c.purchase_price,v_out_zer_handle) = 0 
    group by b.operator_name;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
     
   
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select IFNULL(b.operator_name,'Others') as Name,count(pk_operator_id) as cancel_count
    from did_number_pool a 
    join ref_did_operator b on IFNULL(a.fk_operator_id,v_out_zer_handle) = b.pk_operator_id
    left join ref_did_number_range n on IFNULL(a.fk_num_range_id,v_out_zer_handle) = n.pk_num_range_id
    left join did_number_user_info c on a.did_number = c.did_number
    join ref_did_number_status e on a.Status = e.status_id
    where e.status_id in(3)
    and IFNULL(c.purchase_price,v_out_zer_handle) = 0 
    and ((a.fk_num_range_id = number_range) or (number_range = 0))
    and ((a.CUPID = CUPID) or (CUPID = 0))
    group by b.operator_name;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
     
   
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select IFNULL(b.operator_name,'Others') as Name,count(pk_operator_id) as expiry_counts
    from did_number_pool a 
    join ref_did_operator b on IFNULL(a.fk_operator_id,v_out_zer_handle) = b.pk_operator_id
    left join ref_did_number_range n on IFNULL(a.fk_num_range_id,v_out_zer_handle) = n.pk_num_range_id
    left join did_number_user_info c on a.did_number = c.did_number
    join ref_did_number_status e on a.Status = e.status_id
    where c.exp_date < CURRENT_TIMESTAMP 
    and IFNULL(c.purchase_price,v_out_zer_handle) = 0 
    and ((a.fk_num_range_id = number_range) or (number_range = 0))
    and ((a.CUPID = CUPID) or (CUPID = 0))   
   
    group by b.operator_name;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
     
   
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select IFNULL(b.operator_name,'Others') as Name,count(pk_operator_id) as recycle_counts
    from did_number_pool a 
    join ref_did_operator b on IFNULL(a.fk_operator_id,v_out_zer_handle) = b.pk_operator_id
    left join ref_did_number_range n on IFNULL(a.fk_num_range_id,v_out_zer_handle) = n.pk_num_range_id
    left join did_number_user_info c on a.did_number = c.did_number
    join ref_did_number_status e on a.Status = e.status_id
    where e.status_id in(4)
    and IFNULL(c.purchase_price,v_out_zer_handle) = 0 
    and ((a.fk_num_range_id = number_range) or (number_range = 0))
    and ((a.CUPID = CUPID) or (CUPID = 0))   
   
    group by b.operator_name;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
     
   
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select IFNULL(b.operator_name,'Others') as Name,count(pk_operator_id) as pred_counts
    from did_number_pool a 
    join ref_did_operator b on IFNULL(a.fk_operator_id,v_out_zer_handle) = b.pk_operator_id
    left join ref_did_number_range n on IFNULL(a.fk_num_range_id,v_out_zer_handle) = n.pk_num_range_id
    left join did_number_user_info c on a.did_number = c.did_number
    join ref_did_number_status e on a.Status = e.status_id
    where c.exp_date between CURRENT_TIMESTAMP and  TIMESTAMPADD(day,5,CURRENT_TIMESTAMP)
    and IFNULL(c.purchase_price,v_out_zer_handle) = 0 
    and ((a.fk_num_range_id = number_range) or (number_range = 0))
    and ((a.CUPID = CUPID) or (CUPID = 0))
    group by b.operator_name;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
     
   
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select IFNULL(b.operator_name,'Others') as Name,count(pk_operator_id) as availno_counts
    from did_number_pool a 
    join ref_did_operator b on IFNULL(a.fk_operator_id,v_out_zer_handle) = b.pk_operator_id
    left join ref_did_number_range n on IFNULL(a.fk_num_range_id,v_out_zer_handle) = n.pk_num_range_id
    left join did_number_user_info c on a.did_number = c.did_number
    join ref_did_number_status e on a.Status = e.status_id
    where e.status_id  in(4)
    and IFNULL(c.purchase_price,v_out_zer_handle) = 0 
    and ((a.fk_num_range_id = number_range) or (number_range = 0))
    and ((a.CUPID = CUPID) or (CUPID = 0))   
   
    group by b.operator_name;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
     
   
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select IFNULL(b.operator_name,'Others') as Name,count(pk_operator_id) as usedno_counts
    from did_number_pool a 
    join ref_did_operator b on IFNULL(a.fk_operator_id,v_out_zer_handle) = b.pk_operator_id
    left join ref_did_number_range n on IFNULL(a.fk_num_range_id,v_out_zer_handle) = n.pk_num_range_id
    left join did_number_user_info c on a.did_number = c.did_number
    join ref_did_number_status e on a.Status = e.status_id
    where e.status_id  in(1)
    and IFNULL(c.purchase_price,v_out_zer_handle) = 0 
    and ((a.fk_num_range_id = number_range) or (number_range = 0))
    and ((a.CUPID = CUPID) or (CUPID = 0))    
   
    group by b.operator_name;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
   
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_location_by_country` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `get_location_by_country`(country VARCHAR(250),  
OUT city_list LONGTEXT)
BEGIN        
   
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   group_concat(CONCAT('',a.location)) INTO city_list from did_number_lcr_price_master_dtl a 
   WHERE a.country = country;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `msisdn_get_available_list` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `msisdn_get_available_list`(
 country_id INT,
 no_count INT)
BEGIN
 
      
    DECLARE v_country VARCHAR(100);
      
    IF no_count is null then
       set no_count = 5;
    END IF;
    DROP TEMPORARY TABLE IF EXISTS tt_temp_msisdn_info;
    create TEMPORARY table tt_temp_msisdn_info
    (
       number VARCHAR(100),
       country VARCHAR(150),
       price FLOAT,
       currency VARCHAR(50),
       number_display VARCHAR(50)
    ); 	
 	
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select   country_name INTO v_country from  ref_did_country  where pk_country_id = country_id;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 	
 
    UPDATE  msisdn_number_pool a set a.status = 0,a.pick_date = null where a.status = 2 and TIMESTAMPDIFF(HOUR,pick_date,CURRENT_TIMESTAMP) >= 1
    and a.fk_country_id = country_id;
 
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    insert into tt_temp_msisdn_info
    select Distinct number,country,price,currency,
 	fn_get_country_formated_number(number) as number_display
    from(select msisdn as number,v_country as country,price as price,'GBP' as currency,
 	ROW_NUMBER() over(order by msisdn) row_no
       from msisdn_number_pool a
       WHERE a.fk_country_id = country_id
       and a.status = 0)   ob where row_no <= no_count;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 	
    UPDATE msisdn_number_pool a
    join tt_temp_msisdn_info  b on a.msisdn = b.number set a.status = 2,a.pick_date = CURRENT_TIMESTAMP;
 	
    select *from tt_temp_msisdn_info; 
 	
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `msisdn_update_available_no_list` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `msisdn_update_available_no_list`(
         msisdn LONGTEXT,
         product_id INT,
         first_name VARCHAR(50),
         last_name  VARCHAR(50),
         company_id INT,
         company_name  VARCHAR(150),
         is_flag INT)
BEGIN
        
        
            IF is_flag is null 
            then
               set is_flag = 0;
            END IF;
            
            DROP TEMPORARY TABLE IF EXISTS tt_msisdn_pool;
            create TEMPORARY table tt_msisdn_pool
            (
               msisdn VARCHAR(20)
            );
         	
     		call unifiedring.Split(msisdn,',');
     
    		insert into tt_msisdn_pool(msisdn)
    		select Items from unifiedring.tt_Split_temptable;
       
            UPDATE  msisdn_number_pool a
            join tt_msisdn_pool b on a.msisdn = b.msisdn
            set a.status = 1,a.fk_product_id = product_id,a.last_update = CURRENT_TIMESTAMP,
            a.assigned_date = CURRENT_TIMESTAMP
            where a.status <> 1;
            
            IF IFNULL(is_flag,0) = 0  then 
  
 			if not exists(select * from msisdn_number_user_info where msisdn_number in (select Distinct d.msisdn from tt_msisdn_pool d) limit 1) then
         	  insert into msisdn_number_user_info(msisdn_number,first_name,last_name,fk_product_id,assigned_date,company_id,company_name)
               select Distinct a.msisdn,first_name,last_name,product_id,CURRENT_TIMESTAMP,company_id,company_name
               from tt_msisdn_pool a;
              End if; 
            end if;
         END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Partner_portal_update_did_number` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `Partner_portal_update_did_number`(
 did_number VARCHAR(20),  
  product_id INT,  
  calledby VARCHAR(50),  
  OUT avail_number VARCHAR(20))
BEGIN
  
     DECLARE v_country_id VARCHAR(20);  
     
     IF avail_number is null 
     then
        set avail_number = '';
     END IF;
     
     SET avail_number = did_number;  
     
     
     IF EXISTS(SELECT  * FROM did_number_pool a where a.did_number = did_number AND STATUS <> 0 LIMIT 1) 
     then 
        SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        select   pk_country_id INTO v_country_id from ref_did_country where country_code = LEFT(did_number, CHAR_LENGTH(country_code));
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
        SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        select   a.did_number INTO did_number from did_number_pool a where fk_country_id = v_country_id and status = 0    LIMIT 1;
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
        
        IF IFNULL(did_number,'') <> '' 
        then
           SET avail_number = did_number;
        end if;
        
     end if;  
     
     
     
     Update did_number_pool a set status = 1,fk_product_id = product_id,assigned_date = CURRENT_TIMESTAMP,last_update = CURRENT_TIMESTAMP,
     update_by = calledby
     where a.did_number = did_number;  
        
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `pref_get_country_name` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `pref_get_country_name`()
begin

   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select distinct CAST(0 AS CHAR(150)) as country_id,country from did_number_lcr_price_master_dtl
   order by country asc;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
  
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `pref_get_loca_area_code` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `pref_get_loca_area_code`(country text(555),  
location text(555))
begin
  
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select a.country,a.location, a.area_code  from did_number_lcr_price_master_dtl a
   where a.country = country and ((IFNULL(location,'') = '' 
   or IFNULL(a.location,'') = location));
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
     
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `pref_get_loca_name` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `pref_get_loca_name`(country VARCHAR(555))
BEGIN
 
    DECLARE v_city_list LONGTEXT; 
    declare default_int_val int;
    set default_int_val = 0;
    
	
    DROP TEMPORARY TABLE IF EXISTS tt_temp_loc;
    create TEMPORARY table tt_temp_loc
    (
       location VARCHAR(150)
    );
  
    CALL get_location_by_country(country,v_city_list);

	call unifiedring.split(v_city_list,',');
          
	insert into tt_temp_loc
	select Items from unifiedring.tt_Split_temptable;
    
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select distinct location,default_int_val  area_code_flag  from tt_temp_loc;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `purchase_did_number_update_status` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `purchase_did_number_update_status`(
 did_number varchar(20),
 product_id int,
 accountid varchar(20),
 price float,
 calledby varchar(50),
 exp_date datetime,
 out errcode INT,
 out errmsg varchar(250)
 )
BEGIN
 
 	
 	set errcode=-1;
 	set errmsg='';
 	
 	Update did_number_pool a set a.status=1,a.fk_product_id=4,a.assigned_date=current_timestamp,
 	a.last_update=current_timestamp,a.update_by=calledby where a.did_number=did_number;
 	
 	
 		if not exists(select * from did_number_user_info a  where a.did_number  = did_number limit 1) then
 			INSERT INTO did_number_user_info(did_number,assigned_user,fk_product_id,assigned_date,assigned_by,purchase_price,exp_date,reg_country)
 			VALUES(did_number,accountid,product_id,current_timestamp,calledby,price,exp_date,calledby);
 		end if;	
 		Set errcode=0;
 		Set errmsg='';
 	
 	
 	
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `uk_portin_port_out_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `uk_portin_port_out_details`(
country VARCHAR(15),  
 request_date_from VARCHAR(35),  
 request_date_to VARCHAR(35),  
 port_date_from VARCHAR(30),  
 port_date_to VARCHAR(30),  
 port_type INT
 )
begin
   
    DECLARE v_errcode INT DEFAULT -1; 
    DECLARE v_errmsg VARCHAR(50) DEFAULT 'Failure';  
   
    sp_exit:BEGIN
    
       if country = 'UK' AND port_type = 1 
       then   
          select b.contact_name as customer_name,insert(a.MSISDN,1,1,'44') AS Number,'UK' as country,
          'Vectone' as Product_Name,d.name as ported_from,insert(a.BB_MSISDN,1,1,'44') AS Temporary_Number,
          b.SUBMIT_DATE as Requested_date,
      c.DESCRIPTION  as porting_status,a.PORT_DATE as ported_date
 		 from npadm_uk.MSISDN_IN a
          join npadm_uk.REQUEST b
          on a.REQUEST_ID = b.REQUEST_ID
          join npadm_uk.REF_STATUS c
          on c.status = a.status
          left join  npadm_uk.REF_SERVICE_PROVIDER d
          on left(b.pac,3) = d.code 
          where (b.SUBMIT_DATE between request_date_from and request_date_to)
          or (a.PORT_DATE between port_date_from and port_date_to);
       
       else
       
          if country = 'UK' AND port_type = 2 
          then   
             select b.contact_name as customer_name,insert(a.PRIMARY_MSISDN,1,1,'44') AS Number,'UK' as country,
             'Vectone' as Product_Name,o2.name as ported_from,b.CREATION_DATE as Requested_date,
      c.DESCRIPTION  as porting_status,a.PORT_DATE as ported_date
             from npadm_uk.MSISDN_OUT a
             join npadm_uk.ENTRY b
             on b.entry_id = a.entry_id
             join npadm_uk.REF_STATUS c
             on c.status = a.status
             left join npadm_uk.REF_OPR o1 on a.ono = o1.code
             left join npadm_uk.REF_OPR o2 on a.rno = o2.code
             where (CAST(b.CREATION_DATE AS DATE) between request_date_from and request_date_to)
             or (a.PORT_DATE between port_date_from and port_date_to);
          end if;
       end if;
       
       if found_rows() > 0 
       then 
          set v_errcode = 0;
          set v_errmsg  = 'Success';
          LEAVE sp_exit;
       end if;
    END;
    select v_errcode as errcode, v_errmsg as errmsg;  
   
   
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `urmyaccount_get_city_by_country` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `urmyaccount_get_city_by_country`(country VARCHAR(10))
BEGIN
   
   
   	 
   	
      select b.city_name as area,a.country_name as country,'Local number' as landline_type,
   	
     case  when left(IFNULL(b.city_code,''),1)=0  then IFNULL(b.city_code,'') else concat('0',IFNULL(b.city_code,'')) end as area_code
     ,null as state_id,b.pk_city_id as city_id from ref_did_country a
      join ref_did_city b on a.pk_country_id = b.fk_country_id
      where a.iso2_code = country AND IFNULL(b.city_code,'')<>'';
   	
   END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `urmyaccount_get_number_by_country_city` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `urmyaccount_get_number_by_country_city`(
    country VARCHAR(150),  
     city VARCHAR(250),  
     landline_type VARCHAR(250),
     loc_display int
     )
BEGIN
        DECLARE v_country_id INT;   
        DECLARE v_city_id INT;  
        IF loc_display is null
        then
        set loc_display=0;
        end if;
        if IFNULL(city,'') <> ''
        then
        SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
         select   pk_country_id, c.pk_city_id INTO v_country_id,v_city_id from  ref_did_country a 
           join ref_did_city c  on  a.pk_country_id = c.fk_country_id where a.country_name = country and c.city_name = city    LIMIT 1;      
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
        else 
        SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
           select   pk_country_id INTO v_country_id from ref_did_country a  where a.country_name = country    LIMIT 1; 
          SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ; 
        end if;  
        delete from  did_pool_temp A where TIMESTAMPDIFF(MINUTE,A.last_update,CURRENT_TIMESTAMP) >= 5;  
        DROP TEMPORARY TABLE IF EXISTS tt_temp_did_number_ur;  
        CREATE TEMPORARY table tt_temp_did_number_ur
        (
           landline_number VARCHAR(20)
        );  
        IF IFNULL(landline_type,'') = '0800 Number'
        then
        SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
           insert into tt_temp_did_number_ur(landline_number)
           select  a.did_number as landline_number   from  did_number_pool a
           WHERE  a.fk_country_id = v_country_id  AND a.fk_num_range_id = 3
           and a.status = 0
           order by a.did_number asc LIMIT 5;
          SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ; 
        ELSE
        SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
           insert into tt_temp_did_number_ur(landline_number)
           select  a.did_number as landline_number  from did_number_pool a
           WHERE  a.fk_country_id = v_country_id AND a.fk_city_id = v_city_id
           and a.status = 0
           order by a.did_number asc LIMIT 5;     
           SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
        end if;    
        
   
        
		insert into did_pool_temp(did_number,last_update)
        select 	landline_number,CURRENT_TIMESTAMP 
        from 	tt_temp_did_number_ur	tt_dn
        left join did_pool_temp 		dpt		on tt_dn.landline_number = dpt.did_number
        where 	dpt.did_number is null;  
        
          IF IFNULL(loc_display,0) = 0 then
          select tt_temp_did_number_ur.*,'VECT' as Product from tt_temp_did_number_ur;
       ELSE
          select tt_temp_did_number_ur.*,fn_get_country_formated_number(landline_number) as landline_number_display,'VECT' as Product
          from tt_temp_did_number_ur;
       end if;
     END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `urmyaccount_get_number_by_country_city_1` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `urmyaccount_get_number_by_country_city_1`(
    country VARCHAR(150),  
     city VARCHAR(250),  
     landline_type VARCHAR(250),
     loc_display int
     )
BEGIN
		DECLARE v_country_id INT;   
		DECLARE v_city_id INT; 
        
        IF loc_display is null
        then
			set loc_display=0;
        end if;
        
        
        
        if IFNULL(city,'') <> ''
        then
        SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
			select   pk_country_id, c.pk_city_id INTO v_country_id,v_city_id from  ref_did_country a 
			join ref_did_city c  on  a.pk_country_id = c.fk_country_id where a.country_name = country and c.city_name = city    LIMIT 1;      
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
        else 
        SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
           select   pk_country_id INTO v_country_id from ref_did_country a  where a.country_name = country    LIMIT 1; 
          SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ; 
        end if;  
        
        
        
        delete from  did_pool_temp A where TIMESTAMPDIFF(MINUTE,A.last_update,CURRENT_TIMESTAMP) >= 5;  
        
        DROP TEMPORARY TABLE IF EXISTS tt_temp_did_number_ur;  
        CREATE TEMPORARY table tt_temp_did_number_ur
        (
           landline_number VARCHAR(20)
        );  
        
         
                
        IF IFNULL(landline_type,'') = '0800 Number'
        then
			SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
           insert into tt_temp_did_number_ur(landline_number)
           select  	a.did_number as landline_number   
           from  	did_number_pool a
           WHERE  	a.fk_country_id = v_country_id  
           AND 		a.fk_num_range_id = 3
           and 		a.status = 0
           order by a.did_number asc LIMIT 5;
           
            
           
          SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ; 
        ELSE
        SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
           insert into tt_temp_did_number_ur(landline_number)
           select  a.did_number as landline_number  from did_number_pool a
           WHERE  a.fk_country_id = v_country_id AND a.fk_city_id = v_city_id
           and a.status = 0
           order by a.did_number asc LIMIT 5;     
           SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
        end if;    
        
		
        
        insert into did_pool_temp(did_number,last_update)
        select 	landline_number,CURRENT_TIMESTAMP 
        from 	tt_temp_did_number_ur	tt_dn
        left join did_pool_temp 		dpt		on tt_dn.landline_number = dpt.did_number
        where 	dpt.did_number is null;  
        
        
        
       IF IFNULL(loc_display,0) = 0 then
          select tt_temp_did_number_ur.*,'VECT' as Product from tt_temp_did_number_ur;
       ELSE
          select tt_temp_did_number_ur.*,fn_get_country_formated_number(landline_number) as landline_number_display,'VECT' as Product
          from tt_temp_did_number_ur;
       end if;
        
     END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `urmyaccount_get_number_by_country_city_old` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `urmyaccount_get_number_by_country_city_old`(
  country VARCHAR(150),  
   city VARCHAR(250),  
   landline_type VARCHAR(250),
   loc_display int
   )
BEGIN
      DECLARE v_country_id INT;   
      DECLARE v_city_id INT;  
      IF loc_display is null
      then
      set loc_display=0;
      end if;
      if IFNULL(city,'') <> ''
      then
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
       select   pk_country_id, c.pk_city_id INTO v_country_id,v_city_id from  ref_did_country a 
         join ref_did_city c  on  a.pk_country_id = c.fk_country_id where a.country_name = country and c.city_name = city    LIMIT 1;      
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
      else 
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
         select   pk_country_id INTO v_country_id from ref_did_country a  where a.country_name = country    LIMIT 1; 
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ; 
      end if;  
      delete from  did_pool_temp A where TIMESTAMPDIFF(MINUTE,A.last_update,CURRENT_TIMESTAMP) >= 5;  
      DROP TEMPORARY TABLE IF EXISTS tt_temp_did_number_ur;  
      CREATE TEMPORARY table tt_temp_did_number_ur
      (
         landline_number VARCHAR(20)
      );  
      IF IFNULL(landline_type,'''') = '0800 Number'
      then
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
         insert into tt_temp_did_number_ur(landline_number)
         select  a.did_number as landline_number   from  did_number_pool a
         WHERE  a.fk_country_id = v_country_id  AND a.fk_num_range_id = 3
         and a.status = 0
         order by a.did_number asc LIMIT 5;
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ; 
      ELSE
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
         insert into tt_temp_did_number_ur(landline_number)
         select  a.did_number as landline_number  from did_number_pool a
         WHERE  a.fk_country_id = v_country_id AND a.fk_city_id = v_city_id
         and a.status = 0
         order by a.did_number asc LIMIT 5;     
         SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
      end if;    
      insert into did_pool_temp(did_number,last_update)
      select landline_number,CURRENT_TIMESTAMP from tt_temp_did_number_ur;  
        IF IFNULL(loc_display,0) = 0 then
        select * from tt_temp_did_number_ur;
     ELSE
        select tt_temp_did_number_ur.*,fn_get_country_formated_number(landline_number) as landline_number_display
        from tt_temp_did_number_ur;
     end if;
   END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `urmyaccount_get_number_list` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `urmyaccount_get_number_list`(
       country VARCHAR(150),  
       city VARCHAR(250),  
       landline_type VARCHAR(250),  
       loc_display INT,  
       number_count INT,  
       from_range VARCHAR(50))
SWL_return:BEGIN
             
          
          DECLARE v_country_id INT;   
          DECLARE v_city_id INT;  
          
          IF loc_display is null then set loc_display = 0; END IF;
          
          if IFNULL(city,'') <> ''  then
      
             SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
             select   pk_country_id, c.pk_city_id INTO v_country_id,v_city_id from ref_did_country a 
             join ref_did_city c  on  a.pk_country_id = c.fk_country_id where a.country_name = country and c.city_name = city LIMIT 1;
             SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
             
          else
          
             SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
             select   pk_country_id INTO v_country_id from ref_did_country a  where a.country_name = country    LIMIT 1;
             SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
             
          end if;  
          
          delete from did_pool_temp where TIMESTAMPDIFF(MINUTE,last_update,CURRENT_TIMESTAMP) >= 30;  
          
          DROP TEMPORARY TABLE IF EXISTS tt_temp_did_number_ur;     
          CREATE TEMPORARY table tt_temp_did_number_ur
          (
             landline_number VARCHAR(20)
          );  
          
          IF IFNULL(landline_type,'') = '0800 Number' then
        
             SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
             insert into tt_temp_did_number_ur(landline_number)
             select a.did_number as landline_number   from  did_number_pool a
             join ref_did_number_range b on a.fk_num_range_id = b.pk_num_range_id
             WHERE  a.fk_country_id = v_country_id
             and status = 0 and a.did_number not in(select b.did_number from did_pool_temp b)
             AND  (IFNULL(v_city_id,0) = 0 OR (a.fk_city_id = v_city_id))
             AND (IFNULL(from_range,'') = '' or (left(a.did_number,6) = from_range))
             and IFNULL(b.is_freephone,0) = 1  limit number_count;
             SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
             
 
             
          ELSE
      
             SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
             insert into tt_temp_did_number_ur (landline_number)
             select a.did_number as landline_number from did_number_pool a
             WHERE  a.fk_country_id = v_country_id
             and status = 0 and a.did_number not in (select b.did_number from did_pool_temp b)
             and fk_num_range_id = 1
             AND a.fk_city_id = v_city_id 
      		AND (IFNULL(from_range,'') = '' or (left(a.did_number,6) = from_range)) limit number_count;
             SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
                 
          end if;  
          
        insert into did_pool_temp(did_number,last_update)
        select a.landline_number,CURRENT_TIMESTAMP from tt_temp_did_number_ur a;  
          
          IF IFNULL(loc_display,0) = 0 then
        
             select tt_temp_did_number_ur.*,'VECT' as Product from tt_temp_did_number_ur
             order by landline_number asc;
             LEAVE SWL_return;
          end if;  
           
          select tt_temp_did_number_ur.*,fn_get_country_formated_number(landline_number) as landline_number_display,'VECT' as Product
          from tt_temp_did_number_ur
          order by landline_number asc;  
      
       END SWL_return ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `urmyaccount_get_number_list_old` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `urmyaccount_get_number_list_old`(
    country VARCHAR(150),  
    city VARCHAR(250),  
    landline_type VARCHAR(250),  
    loc_display INT,  
    number_count INT,  
    from_range VARCHAR(50))
SWL_return:BEGIN
          
       
       DECLARE v_country_id INT;   
       DECLARE v_city_id INT;  
       
       IF loc_display is null then set loc_display = 0; END IF;
       
       if IFNULL(city,'') <> ''  then
   
          SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
          select   pk_country_id, c.pk_city_id INTO v_country_id,v_city_id from ref_did_country a 
          join ref_did_city c  on  a.pk_country_id = c.fk_country_id where a.country_name = country and c.city_name = city LIMIT 1;
          SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
          
       else
       
          SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
          select   pk_country_id INTO v_country_id from ref_did_country a  where a.country_name = country    LIMIT 1;
          SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
          
       end if;  
       
       delete from did_pool_temp where TIMESTAMPDIFF(MINUTE,last_update,CURRENT_TIMESTAMP) >= 30;  
       
       DROP TEMPORARY TABLE IF EXISTS tt_temp_did_number_ur;     
       CREATE TEMPORARY table tt_temp_did_number_ur
       (
          landline_number VARCHAR(20)
       );  
       
       IF IFNULL(landline_type,'') = '0800 Number' then
     
          SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
          insert into tt_temp_did_number_ur(landline_number)
          select a.did_number as landline_number   from  did_number_pool a
          join ref_did_number_range b on a.fk_num_range_id = b.pk_num_range_id
          WHERE  a.fk_country_id = v_country_id
          and status = 0 and a.did_number not in(select b.did_number from did_pool_temp b)
          AND  (IFNULL(v_city_id,0) = 0 OR (a.fk_city_id = v_city_id))
          AND (IFNULL(from_range,'') = '' or (left(a.did_number,6) = from_range))
          and IFNULL(b.is_freephone,0) = 1 limit number_count;
          SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
          
       ELSE
   
          SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
          insert into tt_temp_did_number_ur (landline_number)
          select a.did_number as landline_number from did_number_pool a
          WHERE  a.fk_country_id = v_country_id
          and status = 0 and a.did_number not in (select b.did_number from did_pool_temp b)
          and fk_num_range_id = 1
          AND a.fk_city_id = v_city_id
   		AND (IFNULL(from_range,'') = '' or (left(a.did_number,6) = from_range)) limit number_count;
          SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
          
       end if;  
       
     insert into did_pool_temp(did_number,last_update)
     select a.landline_number,CURRENT_TIMESTAMP from tt_temp_did_number_ur a;  
       
       IF IFNULL(loc_display,0) = 0 then
     
          select * from tt_temp_did_number_ur
          order by landline_number asc;
          LEAVE SWL_return;
       end if;  
        
       select tt_temp_did_number_ur.*,fn_get_country_formated_number(landline_number) as landline_number_display
       from tt_temp_did_number_ur
       order by landline_number asc;  
   
    END SWL_return ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `urmyaccount_web_number_list` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `urmyaccount_web_number_list`(v_country_id INT,
v_city_id INT,
v_no_user INT)
BEGIN


	 
     
   DECLARE v_country VARCHAR(100);	
	
   IF v_no_user is null then
      set v_no_user = 5;
   END IF;
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   country_name INTO v_country from ref_did_country  where pk_country_id = v_country_id;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
	
	
	
	
	
	
	
	


   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select Distinct number,country,price,currency from(select did_number as number,v_country as country,2 as price,'GBP' as currency,
	ROW_NUMBER() over(order by c.vendor_preference) row_no
      from did_number_pool a
      join ref_did_operator b on a.fk_operator_id = b.pk_operator_id
      join did_vendor_preference c on ltrim(rtrim(c.vendor_name)) = ltrim(rtrim(b.operator_name))
      WHERE  a.fk_country_id = v_country_id AND a.fk_city_id = v_city_id and c.country = v_country
      and a.status = 0) ob where row_no <= v_no_user;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `urmyaccount_web_number_list_v2` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `urmyaccount_web_number_list_v2`(country_id INT,
city_id INT,
no_user INT)
BEGIN

   DECLARE v_country VARCHAR(100);	
	
   IF no_user is null then
      set no_user = 5;
   END IF;
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   country_name INTO v_country from  ref_did_country  where pk_country_id = country_id;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
	

	
   delete from did_pool_temp
   where TIMESTAMPDIFF(MINUTE,last_update,CURRENT_TIMESTAMP) >= 15;


   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   CREATE TEMPORARY TABLE tt_temp_did_number_list AS select Distinct number,country,price,currency,
	fn_get_country_formated_number(number) as number_display  from(select did_number as number,v_country as country,2 as price,'GBP' as currency,
	ROW_NUMBER() over(order by c.vendor_preference) row_no
         from did_number_pool a
         join ref_did_operator b on a.fk_operator_id = b.pk_operator_id
         join did_vendor_preference c on ltrim(rtrim(c.vendor_name)) = ltrim(rtrim(b.operator_name))
         WHERE  a.fk_country_id = country_id AND a.fk_city_id = city_id and c.country = v_country
         and a.status = 0
         and did_number not in(select did_number from did_pool_temp)) ob where row_no <= no_user;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
	
   insert into did_pool_temp(did_number,last_update)
   select number,CURRENT_TIMESTAMP from tt_temp_did_number_list; 
	
	
   select * from tt_temp_did_number_list; 
	
	
   drop TEMPORARY table IF EXISTS tt_temp_did_number_list;  
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ur_desktop_pref_email_mobile_notification_update` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ur_desktop_pref_email_mobile_notification_update`(company_id INT,  
    extn INT,  
    notification_info VARCHAR(500))
begin
      DECLARE v_errcode INT DEFAULT -1;
       DECLARE v_errmsg VARCHAR(30) DEFAULT 'failure';  
       DECLARE v_hdoc INT;  
       DECLARE v_pref_type VARCHAR(20);  
       
       DECLARE v_notifications_type VARCHAR(200);
   	DECLARE v_mobile_status VARCHAR(200);
   	DECLARE v_email_status VARCHAR(200);
       DECLARE v_ec_id_auto_increment int;
      
       set v_pref_type = 'email_mobile';  
      
        drop temporary table if exists tt_pref_notification;
       create TEMPORARY table tt_pref_notification
       (
          notifications_type VARCHAR(100),
          mobile_status VARCHAR(100),
          email_status VARCHAR(100)
       );   
      
     
     
        drop temporary table if exists xml_notifications_type_tbl; create temporary table xml_notifications_type_tbl (id int auto_increment primary key ,notifications_type VARCHAR(100));
        drop temporary table if exists xml_mobile_status_tbl; create temporary table xml_mobile_status_tbl (id int auto_increment primary key ,mobile_status VARCHAR(100));
        drop temporary table if exists xml_email_status_tbl; create temporary table xml_email_status_tbl (id int auto_increment primary key ,email_status VARCHAR(100));
   
     
     SELECT replace(ExtractValue(notification_info, '//notifications_type[1]'),' ',','), 
           replace(ExtractValue(notification_info, '//mobile_status[1]'),' ',','), 
    	   replace(ExtractValue(notification_info, '//email_status[1]'),' ',',')
    	   into v_notifications_type,v_mobile_status,v_email_status;
      
        call Split(v_notifications_type,','); insert into xml_notifications_type_tbl(notifications_type) select Items from tt_Split_temptable;
      call Split(v_mobile_status,','); insert into xml_mobile_status_tbl(mobile_status) select Items from tt_Split_temptable;
      call Split(v_email_status,','); insert into xml_email_status_tbl(email_status) select Items from tt_Split_temptable;
      
       insert into tt_pref_notification(notifications_type,mobile_status,email_status)
      select notifications_type,mobile_status,email_status 
      from xml_notifications_type_tbl a 
      join xml_mobile_status_tbl b on a.id = b.id
      join xml_email_status_tbl c on c.id = b.id;
        
      
      
       if exists(select 1 from ur_desktop_extn_preference a where a.company_id = company_id and a.extension = extn and
       a.pref_type = v_pref_type) then
    
          delete d from ur_desktop_extn_preference d
          where d.company_id = company_id and d.extension = extn and d.pref_type = v_pref_type;
       end if;  
      
        set v_ec_id_auto_increment=0;
        select max(ec_id)+1 into v_ec_id_auto_increment from ur_desktop_extn_preference;
         
      
       insert into  ur_desktop_extn_preference(ec_id,company_id,extension,pref_type,pref_sub_type,mobile_status,email_status,createdate)
       select v_ec_id_auto_increment,company_id,extn,v_pref_type,notifications_type,mobile_status,email_status,CURRENT_TIMESTAMP from tt_pref_notification;  
      
       if found_rows() > 0 then 
          SET v_errcode = 0;
          SET v_errmsg = 'success';
       end if;  
      
       select v_errcode errcode,v_errmsg errmsg;  
      
   
      
    end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ur_ecom_pricing_get_freephone_no_prefix` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ur_ecom_pricing_get_freephone_no_prefix`(country VARCHAR(150))
BEGIN
 
 
 
    DECLARE country_id INT; 
 
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select   a.pk_country_id INTO country_id from ref_did_country a  where ltrim(rtrim(a.country_name)) = ltrim(rtrim(country))    LIMIT 1;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
    

       
    
 
 
    DROP TEMPORARY TABLE IF EXISTS tt_temp_did_prefix;
 
 
 
 
    
    CREATE TEMPORARY TABLE tt_temp_did_prefix (Number_prefix varchar(6)) ;
 
            SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   insert into tt_temp_did_prefix (Number_prefix)
      select distinct left(a.did_number,6) as Number_prefix 
       from did_number_pool a
       join ref_did_number_range b on a.fk_num_range_id = b.pk_num_range_id
       where
       fk_country_id = country_id
       and b.is_freephone = 1
      order by left(a.did_number,6)  asc; 
  SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 	
        SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select Number_prefix,fn_get_country_formated_number(Number_prefix) as Number_prefix_display
    from tt_temp_did_prefix
     order by Number_prefix asc;
  SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ur_extn_did_number_allocation` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ur_extn_did_number_allocation`(  
       	company_id int,  
       	mobileno varchar(20),  
       	product_id int,  
       	country_id int,  
       	city_id int,  
       	assigned_by varchar(20),  
       out did_number varchar(20),  
       out errcode int  
        )
Begin  
           
       declare v_expdate datetime(3); 
       declare v_assign_date datetime(3);  
       declare v_country_prefix varchar(20);  
       
       INSERT INTO ur_extn_did_number_allocation_log(company_id,mobileno,product_id,country_id,city_id,assigned_by) 
       VALUES(company_id,mobileno,product_id,country_id,city_id,assigned_by);  
           
       set v_expdate=timestampadd(year,10,Now(3));  
       set v_assign_date=now(3);    
       set errcode=-1;  
         
       select a.did_number into did_number from did_number_pool a
       join ref_did_number_range b on a.fk_num_range_id=b.pk_num_range_id      
       WHERE  a.fk_country_id=country_id AND a.fk_city_id=city_id  
       and status=0  
       and ifnull(b.is_freephone,0)<>1  
       limit 1; 
           
       UPDATE did_number_pool a SET status=1,fk_product_id=product_id,assigned_date=now(3)  
       WHERE a.did_number=did_number;  
         
       if Found_rows()>0  then 
        set errcode=0;
       end if;  
         
       
         
        IF errcode=0  and did_number is not null THEN   
         insert into did_number_user_info(did_number,assigned_user,fk_product_id,assigned_date,assigned_by,purchase_price,exp_date)  
         values(did_number,mobileno,product_id,v_assign_date,assigned_by,0,v_expdate);    
        END IF;  
          
        select country_code into v_country_prefix from ref_did_country where pk_country_id=country_id limit 1;  
          
        if ifnull(v_country_prefix,'')<>''  
        then     
         call unifiedring.ur_did_update_country_prefix (did_number,v_country_prefix);     
        end if;  
         
       End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ur_extn_did_number_reassign` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ur_extn_did_number_reassign`(
v_company_id INT,
 v_did_number VARCHAR(20) ,
 INOUT v_errcode INT)
Begin

   set v_errcode = -1;


   UPDATE   did_number_pool SET status = 0,fk_product_id = null,assigned_date = null
   WHERE did_number = v_did_number;

   if ROW_COUNT() > 0 then 
      SET v_errcode = 0;
   end if;



   IF v_errcode = 0 then
	
      DELETE FROM did_number_user_info WHERE did_number = v_did_number;
   end if;

End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ur_ma_get_extn_call_log` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ur_ma_get_extn_call_log`(domain_id INT,
   company_id INT,
   extension INT,
   from_date DATETIME(3),
   todate DATETIME(3),
   search_type INT,
   search_type_text VARCHAR(100),
   department VARCHAR(200),
   call_type VARCHAR(50))
begin
  
      DECLARE role INT;
      SET from_date = Cast(from_date As DATE);
      SET todate = Cast(todate As DATE);
   
      SET todate = TIMESTAMPADD(MICROSECOND,-3,TIMESTAMPADD(day,1,todate));
 
      set role = 0;
   
      if IFNULL(search_type,0) = 0 then set search_type = 0; end if;
      if IFNULL(department,'') = '' then set department = 'ALL'; end if;
      if IFNULL(call_type,'') = '' then set call_type = 'ALL'; end if;
   
 	drop temporary table if exists tt_search_dept;
 	create temporary table tt_search_dept(dept longtext);
 	drop temporary table if exists tt_search_calltype;
 	create temporary table tt_search_calltype(dept longtext);
   
 	call split(department,',');
   
   insert into tt_search_dept(dept)
   select * from tt_Split_temptable;
   
    call split(call_type,',');
   
   insert into tt_search_calltype
   select * from tt_Split_temptable;
   
      create TEMPORARY table tt_call_log
      (
         dialled_from VARCHAR(25),
         dialled_to VARCHAR(25),
         start_time DATETIME(3),
         end_time DATETIME(3),
         duration INT,
         call_recording VARCHAR(100),
         call_action VARCHAR(30),
         call_result VARCHAR(30),
         logid INT,
         call_type VARCHAR(20),
         did_type VARCHAR(50),
         call_group_type VARCHAR(50)
      );
   
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select Role_Id INTO role from UR_ECom_User_Extension_Dtl d where d.Company_id = company_id and Extension_Number = extension LIMIT 1;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   
      insert into tt_call_log(dialled_from,dialled_to,start_time,end_time,duration,call_recording,call_action,call_result,logid,call_type,did_type,call_group_type)
      select  dialled_from,dialled_to,start_time,end_time,duration,call_recording,'Phone call' call_action,
 	  case when answered_on like 'Missed call%' then 'Missed'
 			when answered_on like 'Disconnected%' then 'Rejected'
 			when answered_on like '%50VMD%' then 'Missed' else 'Accepted' end call_result, logid,'outgoing call' call_type,did_type,call_type
      from cdr
      where start_time between from_date and todate and IFNULL(dialled_to,'') <> '' and (dialled_from = cast(extension as CHAR(30)) or IFNULL(extension,0) = 0)
      and source_domain_id = cast(domain_id as CHAR(30))
      order by logid desc LIMIT 200;
   
   
      drop TEMPORARY table IF EXISTS tt_call_log;
   
   End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UR_myacc_add_phone_get_direct_number` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `UR_myacc_add_phone_get_direct_number`(
  company_id INT,        
  domain_id INT,        
  number_type INT,    
  type INT,  
  extn VARCHAR(20))
Begin
  
  
      
     declare v_def_int_val_0 int;
     declare v_def_int_val_1 int;
     
     set v_def_int_val_0 = 0;
     set v_def_int_val_1 = 1;
     
     IF extn is null 
     then
        set extn = '';
     END IF;   
     
     DROP TEMPORARY TABLE IF EXISTS tt_temp_external_number_list;
     create TEMPORARY table tt_temp_external_number_list
     (
        od_id INT,
        external_number VARCHAR(20),
        country VARCHAR(20),
        assigned_to VARCHAR(50),
        assign_date DATETIME(3),
        assign_type INT,
        status INT,
        external_number_display VARCHAR(50),
        number_Type VARCHAR(150)
     );  
    
     Drop TEMPORARY table IF EXISTS tt_temp;  
     CREATE TEMPORARY TABLE tt_temp AS select did_number  
     from unifiedring.dir_users a where user_id = extn
        and a.domain_id = domain_id
        and IFNULL(did_number,'') <> '';  
       
    
     SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
     insert into tt_temp_external_number_list(od_id,external_number,country,assigned_to,assign_date,assign_type,
     status,external_number_display,number_Type)
     select od_id,external_number,country,IFNULL(assigned_to,'') as assigned_to,assign_date, assign_type,
     d.status,fn_get_country_formated_number(external_number) as external_number_display,
     case when IFNULL(d.number_Type,'') = 'free_phone' then 'Free Phone'
     when IFNULL(d.number_Type,'') like '%local%'  then 'Local Number'
     when IFNULL(d.number_Type,'') like '%Mobile%' then 'Mobile Number' end as number_Type    
     from unifiedring.UR_phone_add_number_order o
     inner join unifiedring.UR_phone_add_number_order_dtl d  on o.order_id = d.order_id
     where (assign_type = number_type or(number_type = 7 and assign_type in(6,7,1,2,16))) 
     and ((status = IFNULL(type,v_def_int_val_0) or type = v_def_int_val_1))
     and o.company_id = company_id and o.domain_id = domain_id
     and ((IFNULL(extn,'') = '') or (extension = extn)) and 	 ifnull(external_number,'')<>'';
     SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;    
    
     select a.*,IFNULL(c.city_name,'') AS city from tt_temp_external_number_list a
     LEFT join did_number_pool b on a.external_number = b.did_number
     LEFT join ref_did_city c on b.fk_country_id = b.fk_country_id and c.pk_city_id = b.fk_city_id;  
  
  End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ur_my_account_comp_wise_country_drp` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ur_my_account_comp_wise_country_drp`(company_id INT)
BEGIN
	
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   SELECT pk_country_id,country_name FROM ref_did_country
   WHERE IFNULL(is_ur_enable,0) = 1
   order by country_name asc;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `vectoneapp_orders_history_search_1` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `vectoneapp_orders_history_search_1`(order_id VARCHAR(20),  
    country_id VARCHAR(5),  
    Date_range_from VARCHAR(50),  
    Date_range_to VARCHAR(50))
BEGIN
      
       DECLARE v_COUNTRY_NAME VARCHAR(65);  
       DECLARE v_Sitecode VARCHAR(50);  
       DECLARE v_linkedserver longtext;  
       DECLARE v_linksrv longtext;  
       DECLARE v_sql_qry LONGTEXT;  
       DECLARE v_errcode INT;  
       DECLARE v_errmsg VARCHAR(250);  
          
       sp_exit:BEGIN
       
          if order_id = ''
          then
          set order_id = null;
          end if;
          
          IF Date_range_from is null 
          then
             set Date_range_from = '';
          END IF;
          
          IF Date_range_to is null 
          then
             set Date_range_to = '';
          END IF;
          
          set v_errcode = -1;
          set v_errmsg = 'Failure to get details.';
 
          
          SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
          select   sitecode, COUNTRY_NAME INTO v_Sitecode,v_COUNTRY_NAME FROM 
          crm3.country_code WHERE COUNTRY_NUMBER = country_id    LIMIT 1;
          SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
          
          IF v_Sitecode IS NULL 
          then   
             SET v_errcode = -1;
             SET v_errmsg  = 'Unable to fetch sitecode';
             LEAVE sp_exit;
          end if;
          
          Drop TEMPORARY table IF EXISTS tt_temp_sms_xtrapp_imsi_mapping;
          create TEMPORARY table tt_temp_sms_xtrapp_imsi_mapping
          (
             id INT,
             msisdn VARCHAR(20),
             imsi VARCHAR(20),
             sms_relay VARCHAR(25),
             status INT,
             create_date DATETIME(3),
             main_msisdn VARCHAR(20),
             exp_date DATETIME(3)
          );
          
          SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
         
         
          SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
          
          set v_linkedserver = CONCAT_WS('hlrdb.','sms_xtrapp_imsi_mapping');
          
          if v_linkedserver is null 
          then 
             set v_errcode = -1;
             set v_errmsg = 'internal configuration error.';
             LEAVE sp_exit;
          end if;
          
          insert into tt_temp_sms_xtrapp_imsi_mapping
          select id ,msisdn ,imsi ,sms_relay ,status ,create_date ,main_msisdn ,exp_date from hlrdb.sms_xtrapp_imsi_mapping;
 
          IF (order_id IS NOT NULL) and (order_id <> '') 
          then 
             set order_id = replace(order_id,'vt_ext_','');
          end if;  
 
 	SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
       
       DROP TEMPORARY TABLE IF EXISTS tt_temp2;
       
       CREATE TEMPORARY TABLE tt_temp2 AS 
       select IFNULL(account_info,'') as reg_mobileno,   
       cast(a.ID as CHAR(10)) as order_id,
       IFNULL(reg_mobileno,'') as Xtra_Number,
       b.create_date as Purchased_Date,
       'Vectone' as Operator_name,v_COUNTRY_NAME as COUNTRY_NAME 
             from VOTG_VIRTUAL_NUMBER_REGISTER a 
             join tt_temp_sms_xtrapp_imsi_mapping b  
             on a.reg_mobileno = b.msisdn
             and ((Date_range_from = '') or (b.create_date >= Date_range_from) 
             or (Date_range_from is null))
             and ((Date_range_to = '') or (b.create_date <= Date_range_to) 
             or (Date_range_to is null))
             and ((IFNULL(order_id,'') = '') or (a.ID = order_id));
          SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
          
 
          IF v_Sitecode = 'MBE' 
          then
     
             SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
             select(CONCAT(IFNULL(d.firstname,''),' ',IFNULL(d.lastname,'')))  
             as Customername,
 		   a.reg_mobileno,
 		   CONCAT('vt_ext_',order_id) AS order_id,
 		   IFNULL(a.Xtra_Number,'') as Xtra_Number,
 		   'FREE' Number_type,
 		   a.Purchased_Date,
 		   IFNULL(a.Operator_name,'') as Operator_name,
 		   a.COUNTRY_NAME as Country
             from tt_temp2 a
             left join esp.mvno_account b 
             on a.reg_mobileno = b.mobileno
             left join crm.freesim c 
             on b.iccid = c.iccid
             left join crm.subscriber d 
             on c.subscriberid = d.subscriberid
             where b.mobileno is not null
             and d.subscriberid is not null;
             SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
             
             
             set v_errcode = 0;
             set v_errmsg = 'Success to get the sitecode info.';
             LEAVE sp_exit;
             
          ELSE 
          
             IF v_Sitecode = 'MCM' 
             then
     
                SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
                select(CONCAT(IFNULL(d.firstname,''),' ',IFNULL(d.lastname,'')))  
                as Customername,
 			   a.reg_mobileno,
 			   CONCAT('vt_ext_',order_id) AS order_id,
 			   IFNULL(a.Xtra_Number,'') as Xtra_Number,
 			   'FREE' Number_type,
 			   a.Purchased_Date,
 			   IFNULL(a.Operator_name,'') as Operator_name,
 			   a.COUNTRY_NAME as Country
                from tt_temp2 a
                left join esp.mvno_account b 
                on a.reg_mobileno = b.mobileno
                left join crm.freesim c 
                on b.iccid = c.iccid
                left join crm.subscriber d 
                on c.subscriberid = d.subscriberid
                where b.mobileno is not null
                and d.subscriberid is not null;
                SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 
                set v_errcode = 0;
                set v_errmsg = 'Success to get the sitecode info.';
                LEAVE sp_exit;
                
             ELSE 
             
                IF v_Sitecode = 'BAU' 
                then
     
                   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
                   select(CONCAT(IFNULL(d.firstname,''),' ',IFNULL(d.lastname,'')))  
                   as Customername,
 				   a.reg_mobileno,
 				   CONCAT('vt_ext_',order_id) AS order_id,
 				   IFNULL(a.Xtra_Number,'') as Xtra_Number,
 				   'FREE' Number_type,
 				   a.Purchased_Date,
 				   IFNULL(a.Operator_name,'') as Operator_name,
 				   a.COUNTRY_NAME as Country
                   from tt_temp2 a
                   left join esp.mvno_account b 
                   on a.reg_mobileno = b.mobileno
                   left join crm.freesim c 
                   on b.iccid = c.iccid
                   left join crm.subscriber d 
                   on c.subscriberid = d.subscriberid
                   where b.mobileno is not null
                   and d.subscriberid is not null;
                   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
                   
                   
                   set v_errcode = 0;
                   set v_errmsg = 'Success to get the sitecode info.';
                   LEAVE sp_exit;
                   
                ELSE 
                
                   IF v_Sitecode = 'MFR' 
                   then
     
                      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
                      select(CONCAT(IFNULL(d.firstname,''),' ',IFNULL(d.lastname,'')))  
                      as Customername,
 				   a.reg_mobileno,
 				   CONCAT('vt_ext_',order_id) AS order_id,
 				   IFNULL(a.Xtra_Number,'') as Xtra_Number,
 				   'FREE' Number_type,
 				   a.Purchased_Date,
 				   IFNULL(a.Operator_name,'') as Operator_name,
 				   a.COUNTRY_NAME as Country
                      from tt_temp2 a
                      left join esp.mvno_account b 
                      on a.reg_mobileno = b.mobileno
                      left join crm.freesim c 
                      on b.iccid = c.iccid
                      left join crm.subscriber d 
                      on c.subscriberid = d.subscriberid
                      where b.mobileno is not null
                      and d.subscriberid is not null;
                      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
                      
                      
                      set v_errcode = 0;
                      set v_errmsg = 'Success to get the sitecode info.';
                      LEAVE sp_exit;
                      
                   ELSE
                   
                      set v_errcode = -1;
                      set v_errmsg = 'Failure to get sitecode details.';
                      LEAVE sp_exit;
                   end if;
                end if;
             end if;
          end if;
                
       END;
       select v_errcode as errcode,v_errmsg as errmsg;  
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `vectone_as_vendor_did_portal_upload_numbers` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `vectone_as_vendor_did_portal_upload_numbers`(
  country_id INT,
  city_id INT,
  operatorid INT,
  number_range INT , 
  in_xml_data LONGTEXT,
  in_user_name VARCHAR(50))
begin
  
   
     DECLARE v_error_code INT; 
     DECLARE v_error_msg VARCHAR(250); 
     DECLARE v_hDoc INT; 
     DECLARE v_insert_list LONGTEXT; 
     DECLARE v_xml_list LONGTEXT; 
     DECLARE v_SQL LONGTEXT; 
     DECLARE v_update_col LONGTEXT;
     DECLARE v_push_notify_flag INT; 		
     DECLARE v_country_code VARCHAR(10);
     
     DECLARE v_did VARCHAR(100);
     DECLARE v_area_code VARCHAR(150);
     declare default_int_val int;
     
     set default_int_val = 0 ;
  
          
     sp_exit:BEGIN
     
     
        SET v_error_code = -1;
        SET v_error_msg = 'NUMBER ALREADY UPLOADED';
        
        drop TEMPORARY table IF EXISTS tt_bulk_uplaod_did;
        CREATE TEMPORARY TABLE tt_bulk_uplaod_did
        (
           idx INT   AUTO_INCREMENT PRIMARY KEY,
           country_id INT,
           city_id INT,
           operatorid INT,
           number_range INT,
           did VARCHAR(20),
           product_id INT,
           price FLOAT,
           product_name VARCHAR(100),
           area_code VARCHAR(50)
        )  AUTO_INCREMENT = 1;
        
        
      
  
       
      
       
  	
       
        
 	Drop temporary table IF EXISTS xml_did_tbl; create temporary table xml_did_tbl(id int auto_increment primary key, did varchar(100));
  	Drop temporary table IF EXISTS xml_area_code_tbl; create temporary table xml_area_code_tbl(id int auto_increment primary key, area_code VARCHAR(150));
        
         SELECT replace(ExtractValue(in_xml_data, '//did[1]'),' ',','), 
                replace(ExtractValue(in_xml_data, '//area_code[1]'),' ',',')
 			   into v_did,v_area_code ;
                   
            
                   
 	call unifiedring.Split(v_did,',');  insert into xml_did_tbl (did) select Items from unifiedring.tt_Split_temptable;
 	call unifiedring.Split(v_area_code,',');  insert into xml_area_code_tbl (area_code) select Items from unifiedring.tt_Split_temptable;
              
 			INSERT INTO tt_bulk_uplaod_did(did,area_code)
            	select did,area_code from xml_did_tbl a join xml_area_code_tbl b on a.id = b.id; 
     
        update tt_bulk_uplaod_did a set a.country_id = country_id,a.city_id = city_id,a.operatorid = operatorid,a.number_range = number_range;
                
  	
  	
  	
  	
        if exists(select did,count(1) from tt_bulk_uplaod_did
        group by did having count(1) > 1) 
        then 	
           set v_error_code = -1;
           set v_error_msg = 'Duplicate number found in file.Please check';
           LEAVE sp_exit;
        end if;
        
        SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        INSERT INTO vectone_as_vendor_did_number_pool(did_number,fk_operator_id,fk_country_id,fk_city_id,fk_product_id,status,create_date,uploaded_by,area_code,fk_num_range_id)
        
        SELECT did,operatorid,country_id,city_id,null,default_int_val status,CURRENT_TIMESTAMP,in_user_name,area_code,number_range
        from tt_bulk_uplaod_did b where b.did not in(select a.did_number from did_number_pool a);
     
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
        
        if found_rows() > 0
        then	
           set v_error_code = 0;
           set v_error_msg = 'DID Number uploaded successfully.';
        end if;
  
     END;
     select v_error_code as errcode,v_error_msg as errmsg;
  
  end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `votg_number_lookup_search` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `votg_number_lookup_search`(mobileno VARCHAR(20) ,  
  operator_id INT,  
  country_id VARCHAR(5))
BEGIN
  
    
     DECLARE v_COUNTRY_NAME VARCHAR(65);  
   
     DECLARE v_Sitecode VARCHAR(50);  
     DECLARE v_linkedserver VARCHAR(1000);  
     DECLARE v_linksrv VARCHAR(1000);  
     DECLARE v_sql_qry LONGTEXT;  
     DECLARE v_errcode INT;  
     DECLARE v_errmsg VARCHAR(250);  
     DECLARE v_out_handle_varchar varchar(150) default '';
     DECLARE v_Number_type varchar(150) default 'FREE';
     
     sp_exit:BEGIN
     
        set v_errcode = -1;
        set v_errmsg = 'Failure to get details.';
        
        IF (mobileno is null) or(mobileno = '') 
        then  
        
           SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
           select   sitecode, COUNTRY_NAME INTO v_Sitecode,v_COUNTRY_NAME FROM crm3.country_code  
           WHERE COUNTRY_NUMBER = country_id    LIMIT 1;
           SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
           
        ELSE 
        
           if mobileno is not null and country_id is not null 
           then  
              
              SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
              select   sitecode, COUNTRY_NUMBER, COUNTRY_NAME INTO v_Sitecode,country_id,v_COUNTRY_NAME FROM crm3.country_code  
              WHERE COUNTRY_NUMBER = left(mobileno, CHAR_LENGTH(COUNTRY_NUMBER))
              and COUNTRY_NUMBER = country_id    LIMIT 1;
              SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
              
              IF v_Sitecode IS NULL 
              then   
                 SET v_errcode = -1;
                 SET v_errmsg  = 'Unable to fetch sitecode';
                 LEAVE sp_exit;
              end if;
              
           end if;
           
        end if;
        
        Drop TEMPORARY table IF EXISTS tt_temp_sms_xtrapp_imsi_mapping;      
        create TEMPORARY table tt_temp_sms_xtrapp_imsi_mapping
        (
           id INT,
           msisdn VARCHAR(20),
           imsi VARCHAR(20),
           sms_relay VARCHAR(25),
           status INT,
           create_date DATETIME(3),
           main_msisdn VARCHAR(20),
           exp_date DATETIME(3)
        );
        
        
        SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        select   linkedserver INTO v_linksrv from votg_linkedservers where sitecode = v_Sitecode and db_type = 'MVNO'    LIMIT 1;
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
        
        set v_linkedserver = CONCAT_WS('','hlrdb.','sms_xtrapp_imsi_mapping');
        
        if v_linkedserver is null 
        then 
           set v_errcode = -1;
           set v_errmsg = 'internal configuration error.';
           LEAVE sp_exit;
        end if;
        
        set v_sql_qry =CONCAT( 'select * from ',  v_linkedserver);
        SET @SWV_Stmt = CONCAT_WS('','insert into tt_temp_sms_xtrapp_imsi_mapping ',v_sql_qry);
        PREPARE SWT_Stmt FROM @SWV_Stmt;
        EXECUTE SWT_Stmt;
        DEALLOCATE PREPARE SWT_Stmt;
        
        SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        
        DROP TEMPORARY TABLE IF EXISTS tt_temp2;      
        CREATE TEMPORARY TABLE tt_temp2 AS select IFNULL(account_info,v_out_handle_varchar) as reg_mobileno,'Vectone' as Operator_name,
        v_COUNTRY_NAME as COUNTRY_NAME,IFNULL(reg_mobileno,v_out_handle_varchar) as Xtra_Number,b.imsi as imsi_number,b.create_date as Purchased_Date,
     case when R.lastactive_duration < 15 then 'Active'
           when R.lastactive_duration >= 15 then 'Inactive for 15 days'
           when R.lastactive_duration = 0 then 'Unused'
           when R.lastactive_duration >= 30  then 'Recycling'
           end as status ,R.lastactive_duration 
           from VOTG_VIRTUAL_NUMBER_REGISTER a 
           join tt_temp_sms_xtrapp_imsi_mapping b  
           on a.reg_mobileno = b.msisdn
           join didportal_vectoneapp_recycle_master_log_table R
           on a.reg_mobileno = R.ani
           and ((a.account_info = mobileno) or IFNULL(mobileno,v_out_handle_varchar) = '');
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
        
        select * from tt_temp2;
        
        IF v_Sitecode = 'MBE' 
        then 
           SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
           select(CONCAT(IFNULL(d.firstname,v_out_handle_varchar),' ',IFNULL(d.lastname,v_out_handle_varchar)))  as Customername,
      a.reg_mobileno,
      IFNULL(a.Operator_name,v_out_handle_varchar) as Operator_name,
      a.COUNTRY_NAME as Country,
      IFNULL(a.Xtra_Number,v_out_handle_varchar) as Xtra_Number,
      IFNULL(a.imsi_number,v_out_handle_varchar) as imsi_number,
      v_Number_type as Number_type,
      a.Purchased_Date,
      status
           from tt_temp2 a
           left join esp.mvno_account b 
           on a.reg_mobileno = b.mobileno
           left join crm.freesim c 
           on b.iccid = c.iccid
           left join crm.subscriber d 
           on c.subscriberid = d.subscriberid
           where b.mobileno is not null
           and d.subscriberid is not null;
           SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
           
           if found_rows()> 0 then
           set v_errcode = 0;
           set v_errmsg = 'Success to get the sitecode info.';
           LEAVE sp_exit;
           end if;
           
        ELSE 
        
           IF v_Sitecode = 'MCM' 
           then
   
              SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
              select(CONCAT(IFNULL(d.firstname,v_out_handle_varchar),' ',IFNULL(d.lastname,v_out_handle_varchar)))  as Customername,
      a.reg_mobileno,
      IFNULL(a.Operator_name,v_out_handle_varchar) as Operator_name,
      a.COUNTRY_NAME as Country,
      IFNULL(a.Xtra_Number,v_out_handle_varchar) as Xtra_Number,
      IFNULL(a.imsi_number,v_out_handle_varchar) as imsi_number,
      v_Number_type as Number_type,
      a.Purchased_Date,
      status
              from tt_temp2 a
              left join esp.mvno_account b 
              on a.reg_mobileno = b.mobileno
              left join crm.freesim c 
              on b.iccid = c.iccid
              left join crm.subscriber d 
              on c.subscriberid = d.subscriberid
              where b.mobileno is not null
              and d.subscriberid is not null;
              SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
              if found_rows()> 0 then
              set v_errcode = 0;
              set v_errmsg = 'Success to get the sitecode info.';
              LEAVE sp_exit;
              end if;
              
           ELSE 
           
              IF v_Sitecode = 'BAU' 
              then 
                 SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
                 select(CONCAT(IFNULL(d.firstname,v_out_handle_varchar),' ',IFNULL(d.lastname,v_out_handle_varchar)))  as Customername,
      a.reg_mobileno,
      IFNULL(a.Operator_name,v_out_handle_varchar) as Operator_name,
      a.COUNTRY_NAME as Country,
      IFNULL(a.Xtra_Number,v_out_handle_varchar) as Xtra_Number,
      IFNULL(a.imsi_number,v_out_handle_varchar) as imsi_number,
      v_Number_type as Number_type,
      a.Purchased_Date,
      status
                 from tt_temp2 a
                 left join esp.mvno_account b 
                 on a.reg_mobileno = b.mobileno
                 left join crm.freesim c 
                 on b.iccid = c.iccid
                 left join crm.subscriber d 
                 on c.subscriberid = d.subscriberid
                 where b.mobileno is not null
                 and d.subscriberid is not null;
                 SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
                 if found_rows()> 0 then
                 set v_errcode = 0;
                 set v_errmsg = 'Success to get the sitecode info.';
                 LEAVE sp_exit;
                 end if;
              ELSE 
              
                 IF v_Sitecode = 'MFR' 
                 then
   
                    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
                    select(CONCAT(IFNULL(d.firstname,v_out_handle_varchar),' ',IFNULL(d.lastname,v_out_handle_varchar)))  as Customername,
      a.reg_mobileno,
      IFNULL(a.Operator_name,v_out_handle_varchar) as Operator_name,
      a.COUNTRY_NAME as Country,
      IFNULL(a.Xtra_Number,v_out_handle_varchar) as Xtra_Number,
      IFNULL(a.imsi_number,v_out_handle_varchar) as imsi_number,
      v_Number_type as Number_type,
      a.Purchased_Date,
      status
                    from tt_temp2 a
                    left join esp.mvno_account b 
                    on a.reg_mobileno = b.mobileno
                    left join crm.freesim c 
                    on b.iccid = c.iccid
                    left join crm.subscriber d 
                    on c.subscriberid = d.subscriberid
                    where b.mobileno is not null
                    and d.subscriberid is not null;
                    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
                    
                    if found_rows()> 0 then
                    set v_errcode = 0;
                    set v_errmsg = 'Success to get the sitecode info.';
                    LEAVE sp_exit;
                    end if;
                 ELSE
                 
                    set v_errcode = -1;
                    set v_errmsg = 'Failure to get sitecode details.';
                    LEAVE sp_exit;
                 end if;
                 
              end if;
           end if;
        end if;            
        
     END;
     
     select v_errcode as errcode,v_errmsg as errmsg;  
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-21  9:50:34
