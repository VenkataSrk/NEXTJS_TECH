-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: payment
-- ------------------------------------------------------
-- Server version	8.0.44-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `payment`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `payment` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `payment`;

--
-- Table structure for table `AFS`
--

DROP TABLE IF EXISTS `AFS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AFS` (
  `requestID` varchar(50) DEFAULT NULL,
  `merchantReferenceCode` varchar(50) DEFAULT NULL,
  `decision` varchar(20) DEFAULT NULL,
  `reasonCode` varchar(5) DEFAULT NULL,
  `addressInfoCode` varchar(50) DEFAULT NULL,
  `afsFactorCode` varchar(50) DEFAULT NULL,
  `afsResult` varchar(5) DEFAULT NULL,
  `consumerLocalTime` varchar(50) DEFAULT NULL,
  `hostSeverity` varchar(5) DEFAULT NULL,
  `hotlistInfoCode` varchar(50) DEFAULT NULL,
  `internetInfoCode` varchar(50) DEFAULT NULL,
  `ipCity` varchar(50) DEFAULT NULL,
  `ipCountry` varchar(50) DEFAULT NULL,
  `ipRoutingMethod` varchar(50) DEFAULT NULL,
  `ipState` varchar(50) DEFAULT NULL,
  `phoneInfoCode` varchar(50) DEFAULT NULL,
  `scoreModelUsed` varchar(50) DEFAULT NULL,
  `suspiciousInfoCode` varchar(50) DEFAULT NULL,
  `velocityInfoCode` varchar(50) DEFAULT NULL,
  `Transaction_date` datetime(3) DEFAULT NULL,
  `requestIDCapture` varchar(50) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `AIRTIME_FINAL_DEBIT`
--

DROP TABLE IF EXISTS `AIRTIME_FINAL_DEBIT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AIRTIME_FINAL_DEBIT` (
  `logdate` datetime(3) DEFAULT NULL,
  `AirtimeId` varchar(15) NOT NULL,
  `DonorId` varchar(30) NOT NULL,
  `RecipientId` varchar(30) NOT NULL,
  `amount_charge` float DEFAULT NULL,
  `errmsg` varchar(100) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ATFranceSecretCode`
--

DROP TABLE IF EXISTS `ATFranceSecretCode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ATFranceSecretCode` (
  `SecretCode` varchar(30) NOT NULL,
  `Amount` decimal(8,2) NOT NULL,
  `IsUsed` tinyint(1) NOT NULL,
  `IsTest` tinyint(1) NOT NULL,
  `DateCreated` datetime(3) NOT NULL,
  `LastUpdated` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`SecretCode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `AirtimeTransferType`
--

DROP TABLE IF EXISTS `AirtimeTransferType`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AirtimeTransferType` (
  `TypeID` int NOT NULL,
  `TransferType` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`TypeID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `AirtimeUserList`
--

DROP TABLE IF EXISTS `AirtimeUserList`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AirtimeUserList` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(30) NOT NULL,
  `Number` varchar(30) NOT NULL,
  `Destination` varchar(30) DEFAULT NULL,
  `Currency` varchar(5) DEFAULT NULL,
  `LastTransferDate` datetime(3) DEFAULT NULL,
  `LastTransferAmount` decimal(8,2) DEFAULT NULL,
  `MobileNo` varchar(30) NOT NULL,
  `IsDeleted` tinyint(1) NOT NULL,
  `DateCreated` datetime(3) NOT NULL,
  `LastUpdated` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=52519 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `BANCONTACT_TRANSACTION`
--

DROP TABLE IF EXISTS `BANCONTACT_TRANSACTION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `BANCONTACT_TRANSACTION` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `MOBILENO` varchar(20) DEFAULT NULL,
  `CUSTOMER_NAME` varchar(150) DEFAULT NULL,
  `CURRENCY` varchar(3) DEFAULT NULL,
  `AMOUNT` float DEFAULT NULL,
  `DESCRIPTION` varchar(250) DEFAULT NULL,
  `PAYMENT_ID` varchar(100) NOT NULL,
  `REFERENCE` varchar(100) DEFAULT NULL,
  `BULK_ID` varchar(100) DEFAULT NULL,
  `PAYMEN_STATUS` varchar(100) DEFAULT NULL,
  `CREEATE_DATE` datetime(3) DEFAULT NULL,
  `EXPIRE_DATE` datetime(3) DEFAULT NULL,
  `CREDITOR_PROFILERID` varchar(100) DEFAULT NULL,
  `CREDITOR_MERCHANTID` varchar(100) DEFAULT NULL,
  `CREDITOR_IBAN` varchar(100) DEFAULT NULL,
  `DEBITOR_IBAN` varchar(100) DEFAULT NULL,
  `INSERT_DATE` datetime(3) DEFAULT NULL,
  `SELF_LINK` varchar(500) DEFAULT NULL,
  `DEEP_LINK` varchar(500) DEFAULT NULL,
  `QRCODE_LINK` varchar(500) DEFAULT NULL,
  `CANCEL_URL` varchar(500) DEFAULT NULL,
  `TRANSFER_AMOUNT` float DEFAULT NULL,
  `TIPPING_AMOUNT` float DEFAULT NULL,
  `TOTAL_AMOUNT` float DEFAULT NULL,
  `CALLBACKURL` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`PAYMENT_ID`),
  UNIQUE KEY `ID` (`ID`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=238 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Bundles`
--

DROP TABLE IF EXISTS `Bundles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Bundles` (
  `BundleID` int NOT NULL,
  `BundleAmount` float DEFAULT NULL,
  PRIMARY KEY (`BundleID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `CHARGEBACK_TRANSACTION`
--

DROP TABLE IF EXISTS `CHARGEBACK_TRANSACTION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CHARGEBACK_TRANSACTION` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `ACCOUNT_ID` varchar(20) DEFAULT NULL,
  `REFERENCE_ID` varchar(50) NOT NULL,
  `CC_NO` varchar(6) DEFAULT NULL,
  `TRANSACTION_DATE` datetime(3) DEFAULT NULL,
  `reason` varchar(250) DEFAULT NULL,
  `INSERT_DATE` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`REFERENCE_ID`),
  UNIQUE KEY `ID` (`ID`),
  KEY `IDX1_CHARGEBACK_TRANSACTION` (`REFERENCE_ID`),
  KEY `IDX2_CHARGEBACK_TRANSACTION` (`CC_NO`,`ACCOUNT_ID`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=305 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `CTP_Payment_ErrorLog`
--

DROP TABLE IF EXISTS `CTP_Payment_ErrorLog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CTP_Payment_ErrorLog` (
  `PAYID` int NOT NULL AUTO_INCREMENT,
  `REFERENCE_ID` varchar(40) DEFAULT NULL,
  `PAY_ERRORID` int DEFAULT NULL,
  `PAY_RESULTID` int DEFAULT NULL,
  `PAYDATE` datetime(3) DEFAULT NULL,
  `CTPMESSAGE` varchar(300) DEFAULT NULL,
  `STAGE` varchar(300) DEFAULT NULL,
  `STEP` int DEFAULT NULL,
  `EXTRAMESSAGE` varchar(600) DEFAULT NULL,
  `ECI` varchar(300) DEFAULT NULL,
  `Status` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`PAYID`),
  KEY `idx1_ctp_payment_errorlog` (`REFERENCE_ID`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=3791739 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `CTP_Transactions_Log`
--

DROP TABLE IF EXISTS `CTP_Transactions_Log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CTP_Transactions_Log` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `logdate` datetime(3) DEFAULT NULL,
  `pay_reference` varchar(32) DEFAULT NULL,
  `country` varchar(65) DEFAULT NULL,
  `total_amount` float DEFAULT NULL,
  `vat` float DEFAULT NULL,
  `actual_value` float DEFAULT NULL,
  `current_bal` float DEFAULT NULL,
  `first_login` datetime(3) DEFAULT NULL,
  UNIQUE KEY `Id` (`Id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=27313 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Chilli_Payment_Reversal_log`
--

DROP TABLE IF EXISTS `Chilli_Payment_Reversal_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Chilli_Payment_Reversal_log` (
  `Idx` int NOT NULL AUTO_INCREMENT,
  `mobileno` varchar(20) DEFAULT NULL,
  `Accountid` varchar(10) DEFAULT NULL,
  `ReferenceID` varchar(40) DEFAULT NULL,
  `UpdatedBy` varchar(120) DEFAULT NULL,
  `Status` int DEFAULT NULL,
  `Reason` varchar(150) DEFAULT NULL,
  `Amount` float DEFAULT NULL,
  `Amount_Reversal` varchar(20) DEFAULT NULL,
  `CreateDate` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`Idx`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Chillitalk_TransStatusChange_Log`
--

DROP TABLE IF EXISTS `Chillitalk_TransStatusChange_Log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Chillitalk_TransStatusChange_Log` (
  `Idx` int NOT NULL AUTO_INCREMENT,
  `REFERENCE_ID` varchar(40) DEFAULT NULL,
  `Reason` varchar(100) DEFAULT NULL,
  `CreateDate` datetime(3) DEFAULT NULL,
  `status` int DEFAULT NULL,
  `updatedby` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`Idx`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `NOTIFY_SMS_CONFIG`
--

DROP TABLE IF EXISTS `NOTIFY_SMS_CONFIG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `NOTIFY_SMS_CONFIG` (
  `SITECODE` varchar(3) NOT NULL,
  `MESSAGE_TEXT` varchar(160) DEFAULT NULL,
  PRIMARY KEY (`SITECODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `OPERATOR_LIST`
--

DROP TABLE IF EXISTS `OPERATOR_LIST`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `OPERATOR_LIST` (
  `opr_name` varchar(250) DEFAULT NULL,
  `currency` varchar(5) DEFAULT NULL,
  `opr` longtext,
  `opr_prefix` longtext,
  `msisdn_length` varchar(15) DEFAULT NULL,
  `prod` int DEFAULT NULL,
  `opr_id` int DEFAULT NULL,
  `id` int NOT NULL AUTO_INCREMENT,
  UNIQUE KEY `id` (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=305 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `OPERATOR_LIST_Final_info`
--

DROP TABLE IF EXISTS `OPERATOR_LIST_Final_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `OPERATOR_LIST_Final_info` (
  `opr_id` int DEFAULT NULL,
  `opr_name` varchar(250) DEFAULT NULL,
  `opr_prefix` longtext,
  `msisdn_length` varchar(15) DEFAULT NULL,
  `country_code` varchar(5) DEFAULT NULL,
  `iso2_code` varchar(50) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=246 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `OPERATOR_LIST_Final_info_opr`
--

DROP TABLE IF EXISTS `OPERATOR_LIST_Final_info_opr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `OPERATOR_LIST_Final_info_opr` (
  `opr_id` int DEFAULT NULL,
  `opr_name` varchar(250) DEFAULT NULL,
  `opr_prefix` longtext,
  `msisdn_length` varchar(15) DEFAULT NULL,
  `country_code` varchar(5) DEFAULT NULL,
  `iso2_code` varchar(50) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=143 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `OPERATOR_LIST_Final_info_opr_final`
--

DROP TABLE IF EXISTS `OPERATOR_LIST_Final_info_opr_final`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `OPERATOR_LIST_Final_info_opr_final` (
  `opr_id` int DEFAULT NULL,
  `opr_prefix` longtext,
  `country_code` varchar(5) DEFAULT NULL,
  `opr_name` varchar(250) DEFAULT NULL,
  `id` int NOT NULL AUTO_INCREMENT,
  UNIQUE KEY `id` (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `PAYMENT_LOG_INFO`
--

DROP TABLE IF EXISTS `PAYMENT_LOG_INFO`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PAYMENT_LOG_INFO` (
  `id` int NOT NULL AUTO_INCREMENT,
  `date` varchar(50) NOT NULL,
  `hh` int NOT NULL,
  `payment_agent` varchar(30) NOT NULL,
  `tcount` int DEFAULT NULL,
  `device` varchar(50) NOT NULL,
  `process_type` int NOT NULL,
  PRIMARY KEY (`date`,`hh`,`payment_agent`,`device`,`process_type`),
  UNIQUE KEY `id` (`id`),
  KEY `idx1_PAYMENT_LOG_INFO` (`date`,`hh`,`payment_agent`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=142 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `PAYMENT_REJECT_LOG`
--

DROP TABLE IF EXISTS `PAYMENT_REJECT_LOG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PAYMENT_REJECT_LOG` (
  `LOGID` int NOT NULL AUTO_INCREMENT,
  `LOGDATE` datetime(3) DEFAULT NULL,
  `ACCOUNT_ID` varchar(25) DEFAULT NULL,
  `TOPUP_AMOUNT` float DEFAULT NULL,
  `IP_ADDRESS` varchar(50) DEFAULT NULL,
  `CARD_TYPE` varchar(50) DEFAULT NULL,
  `CALLED_BY` varchar(50) DEFAULT NULL,
  `TRANS_AMOUNT` float DEFAULT NULL,
  `RULE_STATUS` int DEFAULT NULL,
  `MESSAGE` varchar(160) DEFAULT NULL,
  `CC_NO` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`LOGID`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=4751 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `PaySafe_Pnurl_Log`
--

DROP TABLE IF EXISTS `PaySafe_Pnurl_Log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PaySafe_Pnurl_Log` (
  `Log_Id` int NOT NULL AUTO_INCREMENT,
  `mobileno` varchar(20) DEFAULT NULL,
  `Reference_Id` varchar(40) DEFAULT NULL,
  `SerialNumbers` varchar(600) DEFAULT NULL,
  `EventType` varchar(100) DEFAULT NULL,
  `ISDebited` int DEFAULT NULL,
  `CreateDate` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`Log_Id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Paym_jun201606_balance`
--

DROP TABLE IF EXISTS `Paym_jun201606_balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Paym_jun201606_balance` (
  `account_id` varchar(32) DEFAULT NULL,
  `bill` float DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `ipclient` varchar(20) DEFAULT NULL,
  `payment_agent` varchar(12) NOT NULL,
  `SubscriptionID` varchar(40) DEFAULT NULL,
  `Result` varchar(20) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `PaymentAccountID`
--

DROP TABLE IF EXISTS `PaymentAccountID`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PaymentAccountID` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `AccountID` varchar(40) DEFAULT NULL,
  `CreatedDate` datetime(3) DEFAULT NULL,
  `REFERENCE_ID` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Paysafe_transaction_log`
--

DROP TABLE IF EXISTS `Paysafe_transaction_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Paysafe_transaction_log` (
  `Idx` int NOT NULL AUTO_INCREMENT,
  `CREATED_DATE` datetime(3) DEFAULT NULL,
  `REFERENCE_ID` varchar(32) DEFAULT NULL,
  `CURRENT_STATUS` int DEFAULT NULL,
  `LAST_GENERAL_ERROR_CODE` int DEFAULT NULL,
  PRIMARY KEY (`Idx`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Profiles`
--

DROP TABLE IF EXISTS `Profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Profiles` (
  `ProfileId` varchar(15) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `UserId` int NOT NULL,
  `ProfileValue` varchar(2000) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  PRIMARY KEY (`ProfileId`,`UserId`),
  KEY `fk_profiles_useridIdx` (`UserId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `REF_CARD_TYPE`
--

DROP TABLE IF EXISTS `REF_CARD_TYPE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `REF_CARD_TYPE` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `CARDTYPE` varchar(20) DEFAULT NULL,
  `NAME` varchar(30) DEFAULT NULL,
  `PROVIDER_CODE` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_REF_CARD_REFERENCE_REF_PAYMIdx` (`PROVIDER_CODE`),
  CONSTRAINT `FK_REF_CARD_REFERENCE_REF_PAYM` FOREIGN KEY (`PROVIDER_CODE`) REFERENCES `REF_PAYMENT_PROVIDER` (`PROVIDER_CODE`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `REF_PAYMENT_AGENT`
--

DROP TABLE IF EXISTS `REF_PAYMENT_AGENT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `REF_PAYMENT_AGENT` (
  `PAYMENT_AGENT` varchar(12) NOT NULL,
  `NAME` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`PAYMENT_AGENT`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `REF_PAYMENT_MODE`
--

DROP TABLE IF EXISTS `REF_PAYMENT_MODE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `REF_PAYMENT_MODE` (
  `PAYMENT_MODE` char(3) NOT NULL,
  `NAME` varchar(32) NOT NULL,
  `PROVIDER_CODE` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`PAYMENT_MODE`),
  KEY `FK_REF_PAYM_FK_REF_PA_REF_PAYMIdx` (`PROVIDER_CODE`),
  CONSTRAINT `FK_REF_PAYM_FK_REF_PA_REF_PAYM` FOREIGN KEY (`PROVIDER_CODE`) REFERENCES `REF_PAYMENT_PROVIDER` (`PROVIDER_CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `REF_PAYMENT_PROVIDER`
--

DROP TABLE IF EXISTS `REF_PAYMENT_PROVIDER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `REF_PAYMENT_PROVIDER` (
  `PROVIDER_CODE` varchar(5) NOT NULL,
  `NAME` varchar(32) NOT NULL,
  PRIMARY KEY (`PROVIDER_CODE`),
  KEY `FK_REF_CARD_REFERENCE_REF_PAYMIdx2` (`PROVIDER_CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `REF_PAYMENT_STATUS`
--

DROP TABLE IF EXISTS `REF_PAYMENT_STATUS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `REF_PAYMENT_STATUS` (
  `PAYMENT_STATUS` int NOT NULL,
  `NAME` varchar(32) NOT NULL,
  PRIMARY KEY (`PAYMENT_STATUS`),
  KEY `FK_TCS_TRAN_FK_TCS_TR_REF_PAYMIdx2` (`PAYMENT_STATUS`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `REF_PAYMENT_STEP`
--

DROP TABLE IF EXISTS `REF_PAYMENT_STEP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `REF_PAYMENT_STEP` (
  `PAYMENT_STEP` int NOT NULL AUTO_INCREMENT,
  `NAME` varchar(32) NOT NULL,
  `PROVIDER_CODE` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`PAYMENT_STEP`),
  KEY `FK_REF_PAY_STEP_REFERENCE_REF_PROVIdx` (`PROVIDER_CODE`),
  KEY `FK_TCS_TRANS_REFER_FK_REF_PAY_STEPIdx2` (`PAYMENT_STEP`),
  CONSTRAINT `FK_REF_PAY_STEP_REFERENCE_REF_PROV` FOREIGN KEY (`PROVIDER_CODE`) REFERENCES `REF_PAYMENT_PROVIDER` (`PROVIDER_CODE`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `REF_PAYSAFE_PAYMENT_STATUS`
--

DROP TABLE IF EXISTS `REF_PAYSAFE_PAYMENT_STATUS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `REF_PAYSAFE_PAYMENT_STATUS` (
  `PAYMENT_STATUS` int DEFAULT NULL,
  `NAME` varchar(600) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=133 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `REF_REASON_CODE`
--

DROP TABLE IF EXISTS `REF_REASON_CODE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `REF_REASON_CODE` (
  `General_Error_Code` int DEFAULT NULL,
  `Provider_Reason_Code` varchar(30) DEFAULT NULL,
  `Provider_Message` varchar(512) DEFAULT NULL,
  `Possible_Action` varchar(512) DEFAULT NULL,
  `Payment_Status` int DEFAULT NULL,
  `Provider_Code` char(10) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `REF_SERVICE_TYPE`
--

DROP TABLE IF EXISTS `REF_SERVICE_TYPE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `REF_SERVICE_TYPE` (
  `SERVICE_TYPE` char(4) NOT NULL,
  `NAME` varchar(32) NOT NULL,
  PRIMARY KEY (`SERVICE_TYPE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `REF_SITECODE`
--

DROP TABLE IF EXISTS `REF_SITECODE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `REF_SITECODE` (
  `SITECODE` varchar(5) NOT NULL,
  `NAME` varchar(32) NOT NULL,
  PRIMARY KEY (`SITECODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `REF_TOPUP_MODE`
--

DROP TABLE IF EXISTS `REF_TOPUP_MODE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `REF_TOPUP_MODE` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `MODE` varchar(100) NOT NULL,
  PRIMARY KEY (`MODE`),
  UNIQUE KEY `ID` (`ID`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `RXTPAYMENT`
--

DROP TABLE IF EXISTS `RXTPAYMENT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RXTPAYMENT` (
  `REFERENCE_ID` varchar(32) NOT NULL,
  `SITECODE` varchar(5) DEFAULT NULL,
  `PAYMENT_AGENT` varchar(12) NOT NULL,
  `SERVICE_TYPE` char(4) NOT NULL,
  `PRODUCT_CODE` varchar(64) DEFAULT NULL,
  `PAYMENT_MODE` char(3) NOT NULL,
  `ACCOUNT_ID` varchar(32) DEFAULT NULL,
  `CC_NO` char(6) DEFAULT NULL,
  `TOTALAMOUNT` float DEFAULT NULL,
  `CURRENCY` varchar(3) DEFAULT NULL,
  `CREATED_DATE` datetime(3) DEFAULT NULL,
  `SUBSCRIPTIONID` varchar(40) DEFAULT NULL,
  `CURRENT_STATUS` int DEFAULT NULL,
  `LAST_STEP` int DEFAULT NULL,
  `MERCHANT_ID` varchar(10) DEFAULT NULL,
  `PROVIDER_CODE` varchar(5) DEFAULT NULL,
  `LAST_GENERAL_ERROR_CODE` int DEFAULT NULL,
  `sendToProduction` varchar(5) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `IPpaymentagent` varchar(20) DEFAULT NULL,
  `IPClient` varchar(20) DEFAULT NULL,
  `3DFlag` char(1) DEFAULT NULL,
  `ReplyMessage` varchar(512) DEFAULT NULL,
  `ReviewQueue` varchar(50) DEFAULT NULL,
  `Selectedprofile` varchar(50) DEFAULT NULL,
  `ThreeDFlag` char(1) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `RX_PAYMENT_DETAIL`
--

DROP TABLE IF EXISTS `RX_PAYMENT_DETAIL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RX_PAYMENT_DETAIL` (
  `REFERENCE_ID` varchar(32) NOT NULL,
  `LAST_CS_ERROR_CODE` varchar(30) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `RX_RECEIPTIN_DETAIL`
--

DROP TABLE IF EXISTS `RX_RECEIPTIN_DETAIL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RX_RECEIPTIN_DETAIL` (
  `REFERENCE_ID` varchar(32) NOT NULL,
  `LAST_CS_ERROR_CODE` varchar(30) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=937991 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `RX_RECEIPTIN_PAYMENT`
--

DROP TABLE IF EXISTS `RX_RECEIPTIN_PAYMENT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RX_RECEIPTIN_PAYMENT` (
  `REFERENCE_ID` varchar(32) NOT NULL,
  `SITECODE` varchar(5) DEFAULT NULL,
  `PAYMENT_AGENT` varchar(12) NOT NULL,
  `SERVICE_TYPE` char(4) NOT NULL,
  `PRODUCT_CODE` varchar(64) DEFAULT NULL,
  `PAYMENT_MODE` char(3) NOT NULL,
  `ACCOUNT_ID` varchar(32) DEFAULT NULL,
  `CC_NO` char(6) DEFAULT NULL,
  `TOTALAMOUNT` float DEFAULT NULL,
  `CURRENCY` varchar(3) DEFAULT NULL,
  `CREATED_DATE` datetime(3) DEFAULT NULL,
  `SUBSCRIPTIONID` varchar(40) DEFAULT NULL,
  `CURRENT_STATUS` int DEFAULT NULL,
  `LAST_STEP` int DEFAULT NULL,
  `MERCHANT_ID` varchar(10) DEFAULT NULL,
  `PROVIDER_CODE` varchar(5) DEFAULT NULL,
  `LAST_GENERAL_ERROR_CODE` int DEFAULT NULL,
  `sendToProduction` varchar(5) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `IPpaymentagent` varchar(20) DEFAULT NULL,
  `IPClient` varchar(20) DEFAULT NULL,
  `3DFlag` char(1) DEFAULT NULL,
  `ReplyMessage` varchar(512) DEFAULT NULL,
  `ReviewQueue` varchar(50) DEFAULT NULL,
  `Selectedprofile` varchar(50) DEFAULT NULL,
  `ThreeDFlag` char(1) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=937991 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `RX_RECEIPTIN_TRANSACTION`
--

DROP TABLE IF EXISTS `RX_RECEIPTIN_TRANSACTION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RX_RECEIPTIN_TRANSACTION` (
  `REFERENCE_ID` varchar(32) NOT NULL,
  `CS_ERROR_CODE` varchar(30) DEFAULT NULL,
  `EXECUTION_DATE` datetime(3) DEFAULT NULL,
  `PAYMENT_STEP` int NOT NULL,
  `PAYMENT_STATUS` int DEFAULT NULL,
  `REQUEST_ID` varchar(64) DEFAULT NULL,
  `REQUEST_TOKEN` varchar(512) DEFAULT NULL,
  `GENERAL_ERROR_CODE` int DEFAULT NULL,
  `ReplyMessage` varchar(512) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=937991 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `SET_PAYMENT_RULE`
--

DROP TABLE IF EXISTS `SET_PAYMENT_RULE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SET_PAYMENT_RULE` (
  `Site_code` varchar(5) NOT NULL,
  `ENR` int DEFAULT NULL,
  `DCS` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `SHEET_MCM`
--

DROP TABLE IF EXISTS `SHEET_MCM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SHEET_MCM` (
  `pay_reference` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `transaction_date` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `mobileno` float DEFAULT NULL,
  `reason` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `chargeback_claim_date` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `customer_name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`),
  KEY `idx1_SHEET_MCM` (`pay_reference`(191))
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=168 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `SubcriptionID`
--

DROP TABLE IF EXISTS `SubcriptionID`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SubcriptionID` (
  `id` int NOT NULL AUTO_INCREMENT,
  `subscription` varchar(40) DEFAULT NULL,
  `REFERENCE_ID` varchar(32) DEFAULT NULL,
  `CreatedDate` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `TCS_PAYMENT_DETAIL`
--

DROP TABLE IF EXISTS `TCS_PAYMENT_DETAIL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TCS_PAYMENT_DETAIL` (
  `REFERENCE_ID` varchar(32) NOT NULL,
  `LAST_CS_ERROR_CODE` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`REFERENCE_ID`),
  KEY `FK_TCS_PAYM_REFERENCE_TPAYMENTIdx` (`REFERENCE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `TCS_TRANSACTION`
--

DROP TABLE IF EXISTS `TCS_TRANSACTION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TCS_TRANSACTION` (
  `REFERENCE_ID` varchar(32) NOT NULL,
  `CS_ERROR_CODE` varchar(30) DEFAULT NULL,
  `EXECUTION_DATE` datetime(3) DEFAULT NULL,
  `PAYMENT_STEP` int NOT NULL,
  `PAYMENT_STATUS` int DEFAULT NULL,
  `REQUEST_ID` varchar(64) DEFAULT NULL,
  `REQUEST_TOKEN` varchar(512) DEFAULT NULL,
  `GENERAL_ERROR_CODE` int DEFAULT NULL,
  `ReplyMessage` varchar(512) DEFAULT NULL,
  PRIMARY KEY (`REFERENCE_ID`,`PAYMENT_STEP`),
  KEY `FK_TCS_TRAN_FK_TCS_TR_REF_PAYMIdx` (`PAYMENT_STATUS`),
  KEY `FK_TCS_TRANS_REFER_FK_REF_PAY_STEPIdx` (`PAYMENT_STEP`),
  KEY `FK_TCS_TRAN_REFERENCE_TPAYMENTIdx` (`REFERENCE_ID`),
  CONSTRAINT `FK_TCS_TRAN_FK_TCS_TR_REF_PAYM` FOREIGN KEY (`PAYMENT_STATUS`) REFERENCES `REF_PAYMENT_STATUS` (`PAYMENT_STATUS`),
  CONSTRAINT `FK_TCS_TRANS_REFER_FK_REF_PAY_STEP` FOREIGN KEY (`PAYMENT_STEP`) REFERENCES `REF_PAYMENT_STEP` (`PAYMENT_STEP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `TEMP_DATA_out`
--

DROP TABLE IF EXISTS `TEMP_DATA_out`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TEMP_DATA_out` (
  `reference_id` varchar(32) NOT NULL,
  `date` varchar(30) DEFAULT NULL,
  `CC_NO` char(6) DEFAULT NULL,
  `replymessage` varchar(512) DEFAULT NULL,
  `LAST_GENERAL_ERROR_CODE` int DEFAULT NULL,
  `CREATED_DATE` datetime(3) DEFAULT NULL,
  `next_reference_id` varchar(50) DEFAULT NULL,
  `next_payment_date` datetime(3) DEFAULT NULL,
  `status` int NOT NULL,
  `next_payment_message` varchar(100) DEFAULT NULL,
  `account_id` varchar(250) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=703 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `THREED_TRANSACTION_FAILURE_DAEMON`
--

DROP TABLE IF EXISTS `THREED_TRANSACTION_FAILURE_DAEMON`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `THREED_TRANSACTION_FAILURE_DAEMON` (
  `id` int NOT NULL AUTO_INCREMENT,
  `account_id` varchar(20) DEFAULT NULL,
  `email` varchar(250) DEFAULT NULL,
  `sitecode` varchar(5) DEFAULT NULL,
  `insert_date` datetime(3) DEFAULT NULL,
  `email_sent_flag` int DEFAULT NULL,
  `sms_id` int DEFAULT NULL,
  `sms_url` varchar(160) DEFAULT NULL,
  PRIMARY KEY (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=9843 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `THREED_TRANSACTION_FAILURE_TBL`
--

DROP TABLE IF EXISTS `THREED_TRANSACTION_FAILURE_TBL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `THREED_TRANSACTION_FAILURE_TBL` (
  `ACCOUNT_ID` varchar(32) DEFAULT NULL,
  `REFERENCE_ID` varchar(32) NOT NULL,
  `CREATED_DATE` datetime(3) DEFAULT NULL,
  `ReplyMessage` varchar(512) DEFAULT NULL,
  `payment_status` int NOT NULL,
  `3Dstatus` char(1) NOT NULL,
  `success` int NOT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `TPAYMENT`
--

DROP TABLE IF EXISTS `TPAYMENT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TPAYMENT` (
  `REFERENCE_ID` varchar(32) NOT NULL,
  `SITECODE` varchar(5) DEFAULT NULL,
  `PAYMENT_AGENT` varchar(12) NOT NULL,
  `SERVICE_TYPE` char(4) NOT NULL,
  `PRODUCT_CODE` varchar(64) DEFAULT NULL,
  `PAYMENT_MODE` char(3) NOT NULL,
  `ACCOUNT_ID` varchar(32) DEFAULT NULL,
  `CC_NO` char(6) DEFAULT NULL,
  `TOTALAMOUNT` float DEFAULT NULL,
  `CURRENCY` varchar(3) DEFAULT NULL,
  `CREATED_DATE` datetime(3) DEFAULT NULL,
  `SUBSCRIPTIONID` varchar(40) DEFAULT NULL,
  `CURRENT_STATUS` int DEFAULT NULL,
  `LAST_STEP` int DEFAULT NULL,
  `MERCHANT_ID` varchar(10) DEFAULT NULL,
  `PROVIDER_CODE` varchar(5) DEFAULT NULL,
  `LAST_GENERAL_ERROR_CODE` int DEFAULT NULL,
  `sendToProduction` varchar(5) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `IPpaymentagent` varchar(100) DEFAULT NULL,
  `IPClient` varchar(20) DEFAULT NULL,
  `3DFlag` char(1) DEFAULT '0',
  `ReplyMessage` varchar(512) DEFAULT NULL,
  `ReviewQueue` varchar(50) DEFAULT NULL,
  `Selectedprofile` varchar(50) DEFAULT NULL,
  `ThreeDFlag` char(1) DEFAULT '0',
  `3Dstatus` char(1) DEFAULT NULL,
  `device_type` varchar(50) DEFAULT NULL,
  `browser` varchar(500) DEFAULT NULL,
  `os_version` varchar(100) DEFAULT NULL,
  `topup_url` varchar(500) DEFAULT NULL,
  `bundle_id` int DEFAULT NULL,
  `expirydate` varchar(10) DEFAULT NULL,
  `cardtype` varchar(20) DEFAULT NULL,
  `srd` varchar(100) DEFAULT NULL,
  `cardholder_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`REFERENCE_ID`),
  KEY `FK_TPAYMENT_REF_PAYMENT_AGENT_PAYMENT_AGENTIdx` (`PAYMENT_AGENT`),
  KEY `FK_TPAYM_REFERENCE_REF_PAY_MODEIdx` (`PAYMENT_MODE`),
  KEY `FK_TPAYMENT_REFERENCE_REF_PAYMIdx` (`PROVIDER_CODE`),
  KEY `FK_TPAY_REFERENCE_PAY_STATUSIdx` (`CURRENT_STATUS`),
  KEY `FK_TPAY_REFERENCE_REF_PAY_STEPIdx` (`LAST_STEP`),
  KEY `FK_TPAYMENT_REFERENCE_REF_SERVIdx` (`SERVICE_TYPE`),
  KEY `FK_TPAYMENT_REFERENCE_REF_SITEIdx` (`SITECODE`),
  KEY `idx_tpayment_account_id` (`ACCOUNT_ID`),
  KEY `idx_tpayment_created_date` (`CREATED_DATE`),
  KEY `idx3_tpayment_ccno` (`CC_NO`),
  KEY `IX_TPAYMENT_REFERENCE_ID` (`REFERENCE_ID`,`SITECODE`,`PAYMENT_AGENT`,`SERVICE_TYPE`,`PRODUCT_CODE`,`PAYMENT_MODE`,`ACCOUNT_ID`,`CC_NO`,`TOTALAMOUNT`,`CURRENCY`,`CREATED_DATE`,`SUBSCRIPTIONID`),
  KEY `FK_TUkash_TRAN_REFERENCE_TPAYMENTIdx2` (`REFERENCE_ID`),
  CONSTRAINT `FK_TPAY_REFERENCE_PAY_STATUS` FOREIGN KEY (`CURRENT_STATUS`) REFERENCES `REF_PAYMENT_STATUS` (`PAYMENT_STATUS`),
  CONSTRAINT `FK_TPAY_REFERENCE_REF_PAY_STEP` FOREIGN KEY (`LAST_STEP`) REFERENCES `REF_PAYMENT_STEP` (`PAYMENT_STEP`),
  CONSTRAINT `FK_TPAYM_REFERENCE_REF_PAY_MODE` FOREIGN KEY (`PAYMENT_MODE`) REFERENCES `REF_PAYMENT_MODE` (`PAYMENT_MODE`),
  CONSTRAINT `FK_TPAYMENT_REF_PAYMENT_AGENT_PAYMENT_AGENT` FOREIGN KEY (`PAYMENT_AGENT`) REFERENCES `REF_PAYMENT_AGENT` (`PAYMENT_AGENT`),
  CONSTRAINT `FK_TPAYMENT_REFERENCE_REF_PAYM` FOREIGN KEY (`PROVIDER_CODE`) REFERENCES `REF_PAYMENT_PROVIDER` (`PROVIDER_CODE`),
  CONSTRAINT `FK_TPAYMENT_REFERENCE_REF_SERV` FOREIGN KEY (`SERVICE_TYPE`) REFERENCES `REF_SERVICE_TYPE` (`SERVICE_TYPE`),
  CONSTRAINT `FK_TPAYMENT_REFERENCE_REF_SITE` FOREIGN KEY (`SITECODE`) REFERENCES `REF_SITECODE` (`SITECODE`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `TPAYMENT_DESCRIPTION`
--

DROP TABLE IF EXISTS `TPAYMENT_DESCRIPTION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TPAYMENT_DESCRIPTION` (
  `REFERENCE_ID` varchar(32) DEFAULT NULL,
  `DESCRIPTION` varchar(2048) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`),
  KEY `FK_TPAYMENT_DESCRIPTION_TPAYMENT_REFERENCE_IDIdx` (`REFERENCE_ID`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=27311 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `TPAYMENT_Mani`
--

DROP TABLE IF EXISTS `TPAYMENT_Mani`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TPAYMENT_Mani` (
  `REFERENCE_ID` varchar(35) DEFAULT NULL,
  `PRODUCT_CODE` varchar(64) DEFAULT NULL,
  `Account_ID` varchar(32) DEFAULT NULL,
  `CREATED_DATE` datetime(3) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=3233 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `TPAYMENT_UKASH`
--

DROP TABLE IF EXISTS `TPAYMENT_UKASH`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TPAYMENT_UKASH` (
  `logId` int NOT NULL AUTO_INCREMENT,
  `referenceId` varchar(50) DEFAULT NULL,
  `serviceOperation` varchar(50) DEFAULT NULL,
  `serviceCalled` datetime(3) DEFAULT NULL,
  `voucherNumber` varchar(50) DEFAULT NULL,
  `voucherValue` float DEFAULT NULL,
  `ticketValue` float DEFAULT NULL,
  `baseCurr` varchar(5) DEFAULT NULL,
  `settleAmount` float DEFAULT NULL,
  `changeIssueVoucherNumber` varchar(50) DEFAULT NULL,
  `changeIssueAmount` float DEFAULT NULL,
  `changeIssueVoucherCurr` varchar(5) DEFAULT NULL,
  `changeIssueExpiryDate` varchar(10) DEFAULT NULL,
  `ukashTransactionId` varchar(50) DEFAULT NULL,
  `currencyConversion` varchar(5) DEFAULT NULL,
  `txCode` int DEFAULT NULL,
  `txDescription` varchar(255) DEFAULT NULL,
  `errCode` int DEFAULT NULL,
  `errDescription` varchar(255) DEFAULT NULL,
  `sendToProduction` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`logId`),
  KEY `ix_TPAYMENT_UKASH_changeIssueVoucherNumber` (`changeIssueVoucherNumber`),
  KEY `ix_TPAYMENT_UKASH_referenceId` (`referenceId`),
  KEY `ix_TPAYMENT_UKASH_voucherNumber` (`voucherNumber`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=7822 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `TPAYMENT_review_log`
--

DROP TABLE IF EXISTS `TPAYMENT_review_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TPAYMENT_review_log` (
  `REFERENCE_ID` varchar(32) DEFAULT NULL,
  `CREATED_DATE` datetime(3) DEFAULT NULL,
  `ACCOUNT_ID` varchar(32) DEFAULT NULL,
  `PRODUCT_CODE` varchar(64) DEFAULT NULL,
  `PAYMENT_AGENT` varchar(12) DEFAULT NULL,
  `PROVIDER_CODE` varchar(5) DEFAULT NULL,
  `TOTALAMOUNT` float DEFAULT NULL,
  `CURRENCY` varchar(3) DEFAULT NULL,
  `CC_NO` char(6) DEFAULT NULL,
  `decision` varchar(50) DEFAULT NULL,
  `product_name` varchar(50) DEFAULT NULL,
  `users` varchar(50) DEFAULT NULL,
  `note` varchar(2000) DEFAULT NULL,
  `decision_payment` varchar(50) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `TPayment_Balance_Master`
--

DROP TABLE IF EXISTS `TPayment_Balance_Master`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TPayment_Balance_Master` (
  `BM_ID` int NOT NULL AUTO_INCREMENT,
  `BM_Date` datetime(3) DEFAULT NULL,
  `BM_REFERENCE_ID` varchar(32) DEFAULT NULL,
  `ACCOUNT_ID` varchar(32) DEFAULT NULL,
  `Current_Balance` float DEFAULT NULL,
  UNIQUE KEY `BM_ID` (`BM_ID`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=29345 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `TROUTING`
--

DROP TABLE IF EXISTS `TROUTING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TROUTING` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `PROVIDER_CODE` varchar(5) DEFAULT NULL,
  `SITECODE` varchar(5) DEFAULT NULL,
  `PRODUCT_CODE_PREFIX` varchar(20) DEFAULT NULL,
  `MERCHANT_ID` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_TROUTING_REFERENCE_REF_PAYMIdx` (`PROVIDER_CODE`),
  KEY `FK_TROUTING_REFERENCE_REF_SITEIdx` (`SITECODE`),
  CONSTRAINT `FK_TROUTING_REFERENCE_REF_PAYM` FOREIGN KEY (`PROVIDER_CODE`) REFERENCES `REF_PAYMENT_PROVIDER` (`PROVIDER_CODE`),
  CONSTRAINT `FK_TROUTING_REFERENCE_REF_SITE` FOREIGN KEY (`SITECODE`) REFERENCES `REF_SITECODE` (`SITECODE`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=150 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `TUkash_TRANSACTION`
--

DROP TABLE IF EXISTS `TUkash_TRANSACTION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TUkash_TRANSACTION` (
  `REFERENCE_ID` varchar(32) NOT NULL,
  `txCode` int DEFAULT NULL,
  `txDescription` varchar(100) DEFAULT NULL,
  `settleAmount` float DEFAULT NULL,
  `transactionId` varchar(50) DEFAULT NULL,
  `changeIssueVoucherNumber` varchar(100) DEFAULT NULL,
  `changeIssueVoucherCurr` varchar(10) DEFAULT NULL,
  `changeIssueAmount` float DEFAULT NULL,
  `changeIssueExpiryDate` datetime(3) DEFAULT NULL,
  `ukashTransactionId` varchar(50) DEFAULT NULL,
  `currencyConversion` tinyint(1) DEFAULT NULL,
  `errCode` int DEFAULT NULL,
  `errDescription` varchar(100) DEFAULT NULL,
  `EXECUTION_DATE` datetime(3) DEFAULT NULL,
  `PAYMENT_STEP` int NOT NULL,
  `PAYMENT_STATUS` int DEFAULT NULL,
  `GENERAL_ERROR_CODE` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`),
  KEY `FK_TUkash_TRAN_FK_TCS_TR_REF_PAYMIdx` (`PAYMENT_STATUS`),
  KEY `FK_TUkash_TRANS_REFER_FK_REF_PAY_STEPIdx` (`PAYMENT_STEP`),
  KEY `FK_TUkash_TRAN_REFERENCE_TPAYMENTIdx` (`REFERENCE_ID`),
  CONSTRAINT `FK_TUkash_TRAN_FK_TCS_TR_REF_PAYM` FOREIGN KEY (`PAYMENT_STATUS`) REFERENCES `REF_PAYMENT_STATUS` (`PAYMENT_STATUS`),
  CONSTRAINT `FK_TUkash_TRAN_REFERENCE_TPAYMENT` FOREIGN KEY (`REFERENCE_ID`) REFERENCES `TPAYMENT` (`REFERENCE_ID`),
  CONSTRAINT `FK_TUkash_TRANS_REFER_FK_REF_PAY_STEP` FOREIGN KEY (`PAYMENT_STEP`) REFERENCES `REF_PAYMENT_STEP` (`PAYMENT_STEP`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Temp_UK_AUT`
--

DROP TABLE IF EXISTS `Temp_UK_AUT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Temp_UK_AUT` (
  `mobileno` varchar(16) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=9252 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Tmp_Sochitel_Rates`
--

DROP TABLE IF EXISTS `Tmp_Sochitel_Rates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Tmp_Sochitel_Rates` (
  `Idx` int NOT NULL AUTO_INCREMENT,
  `Product_Id` varchar(20) DEFAULT NULL,
  `Product_Title` varchar(30) DEFAULT NULL,
  `Product_Seq` int DEFAULT NULL,
  `Charge_Amount` decimal(10,2) DEFAULT NULL,
  `Transfer_Amount` decimal(10,2) DEFAULT NULL,
  `Received_Amount` decimal(10,2) DEFAULT NULL,
  `Base_Country_Id` varchar(5) DEFAULT NULL,
  `Country_Id` varchar(5) DEFAULT NULL,
  `Vendor_Id` varchar(10) DEFAULT NULL,
  `Is_Self` int DEFAULT NULL,
  `Ratio` int DEFAULT NULL,
  UNIQUE KEY `Idx` (`Idx`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=613 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `User_Login`
--

DROP TABLE IF EXISTS `User_Login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `User_Login` (
  `Username` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Users`
--

DROP TABLE IF EXISTS `Users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Users` (
  `Id` int NOT NULL,
  `UserGuid` char(38) NOT NULL,
  `Username` text,
  `Email` text,
  `Password` text,
  `PasswordFormatId` int NOT NULL,
  `PasswordSalt` text,
  `AdminComment` text,
  `Active` bit(1) NOT NULL,
  `Deleted` bit(1) NOT NULL,
  `IsSystemAccount` bit(1) NOT NULL,
  `SystemName` text,
  `LastIpAddress` text,
  `CreateOnUtc` datetime NOT NULL,
  `LastLoginDateUtc` datetime DEFAULT NULL,
  `LastActivityDateUtc` datetime NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `airtime_need_balance`
--

DROP TABLE IF EXISTS `airtime_need_balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `airtime_need_balance` (
  `DonorId` varchar(30) NOT NULL,
  `amount_charge` float DEFAULT NULL,
  `is_debit` int NOT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `airtime_need_debit`
--

DROP TABLE IF EXISTS `airtime_need_debit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `airtime_need_debit` (
  `DonorId` varchar(30) NOT NULL,
  `amount_charge` float DEFAULT NULL,
  `current_balance` float DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `airtime_product`
--

DROP TABLE IF EXISTS `airtime_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `airtime_product` (
  `id` int NOT NULL AUTO_INCREMENT,
  `operator_id` int DEFAULT NULL,
  `Vendorid` varchar(100) DEFAULT NULL,
  `ProductSeq` int DEFAULT NULL,
  `ProductId` varchar(50) DEFAULT NULL,
  `ProductTitle` varchar(150) DEFAULT NULL,
  `ChargeAmount` decimal(10,2) DEFAULT NULL,
  `TransferAmount` decimal(10,2) DEFAULT NULL,
  `ReceivedAmount` decimal(10,2) DEFAULT NULL,
  `basecurrency` varchar(5) DEFAULT NULL,
  `BaseCountryId` varchar(5) DEFAULT NULL,
  `CountryId` varchar(5) DEFAULT NULL,
  `operator_currency` varchar(5) DEFAULT NULL,
  `Ratio` decimal(10,2) DEFAULT NULL,
  `IsSelf` tinyint(1) DEFAULT NULL,
  UNIQUE KEY `id` (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=143 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `airtime_transaction`
--

DROP TABLE IF EXISTS `airtime_transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `airtime_transaction` (
  `AirtimeId` varchar(15) NOT NULL,
  `AirtimeDate` datetime(3) NOT NULL,
  `VendorId` varchar(15) NOT NULL,
  `ReferenceId` varchar(30) DEFAULT NULL,
  `DonorId` varchar(30) NOT NULL,
  `RecipientId` varchar(30) NOT NULL,
  `RecipientName` varchar(30) DEFAULT NULL,
  `DonorCountry` varchar(5) DEFAULT NULL,
  `Country` varchar(5) NOT NULL,
  `Currency` varchar(5) NOT NULL,
  `Amount` decimal(8,2) NOT NULL,
  `TransferAmount` decimal(8,2) DEFAULT NULL,
  `Rate` decimal(8,2) NOT NULL,
  `ReceivedAmount` decimal(8,2) NOT NULL,
  `VoucherCode` varchar(60) DEFAULT NULL,
  `MethodId` varchar(5) NOT NULL,
  `States` varchar(15) NOT NULL,
  `IsDeleted` tinyint(1) NOT NULL,
  `Notes` varchar(300) DEFAULT NULL,
  `DateCreated` datetime(3) NOT NULL,
  `LastUpdated` datetime(3) DEFAULT NULL,
  `Ratio` decimal(8,2) NOT NULL,
  `ProductCode` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`AirtimeId`),
  KEY `ix_airtime_transaction_DonorId` (`DonorId`),
  KEY `ix_airtime_transaction_RecipientId` (`RecipientId`),
  KEY `ix_airtime_transaction_VendorId` (`VendorId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `airtime_transfer_log`
--

DROP TABLE IF EXISTS `airtime_transfer_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `airtime_transfer_log` (
  `Mobile_No` varchar(30) DEFAULT NULL,
  `RecipientId` varchar(30) DEFAULT NULL,
  `Amount` decimal(28,2) DEFAULT NULL,
  `sp_name` varchar(800) DEFAULT NULL,
  `ip_address` varchar(100) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=26380 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `airtimepromo`
--

DROP TABLE IF EXISTS `airtimepromo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `airtimepromo` (
  `id` int NOT NULL,
  `donorCountryId` varchar(5) NOT NULL,
  `countryId` varchar(5) NOT NULL,
  `charge` decimal(8,2) NOT NULL,
  `amount` decimal(8,2) NOT NULL,
  `vendorId` varchar(15) NOT NULL,
  `isactive` tinyint(1) NOT NULL,
  `isDefaultMargin` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `airtimepromo_v2`
--

DROP TABLE IF EXISTS `airtimepromo_v2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `airtimepromo_v2` (
  `id` int NOT NULL,
  `donorCountryId` varchar(5) NOT NULL,
  `countryId` varchar(5) NOT NULL,
  `charge` decimal(8,2) NOT NULL,
  `amount` decimal(8,2) NOT NULL,
  `vendorId` varchar(15) NOT NULL,
  `isactive` tinyint(1) NOT NULL,
  `isDefaultMargin` tinyint(1) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `auttopup_type`
--

DROP TABLE IF EXISTS `auttopup_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auttopup_type` (
  `topup_type` int NOT NULL,
  `topup_name` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`topup_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `blockcard_trans_log`
--

DROP TABLE IF EXISTS `blockcard_trans_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blockcard_trans_log` (
  `logid` int NOT NULL AUTO_INCREMENT,
  `logdate` datetime(3) DEFAULT NULL,
  `cc_no` varchar(6) DEFAULT NULL,
  `amount` float DEFAULT NULL,
  `mobileno` varchar(20) DEFAULT NULL,
  `ipaddress` varchar(50) DEFAULT NULL,
  `card_type` varchar(50) DEFAULT NULL,
  `called_by` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`logid`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=587 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `blocked_card_info`
--

DROP TABLE IF EXISTS `blocked_card_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blocked_card_info` (
  `id` int NOT NULL AUTO_INCREMENT,
  `cc_no` varchar(20) DEFAULT NULL,
  `mobileno` varchar(20) DEFAULT NULL,
  `status` int DEFAULT NULL,
  `block_date` datetime(3) DEFAULT NULL,
  `blocked_by` varchar(50) DEFAULT NULL,
  `unblock_date` datetime(3) DEFAULT NULL,
  `unblock_by` varchar(50) DEFAULT NULL,
  `prod_code` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=1326 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `bundle_product`
--

DROP TABLE IF EXISTS `bundle_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bundle_product` (
  `ProductId` varchar(30) DEFAULT NULL,
  `ProductTitle` varchar(100) DEFAULT NULL,
  `ProductSeq` int DEFAULT NULL,
  `ChargeAmount` decimal(10,5) DEFAULT NULL,
  `TransferAmount` decimal(10,5) DEFAULT NULL,
  `ReceivedAmount` decimal(10,5) DEFAULT NULL,
  `BaseCountryId` varchar(2) DEFAULT NULL,
  `CountryId` varchar(2) DEFAULT NULL,
  `VendorId` varchar(15) DEFAULT NULL,
  `isSelf` tinyint(1) DEFAULT NULL,
  `Ratio` decimal(10,5) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `callingcardpinlog`
--

DROP TABLE IF EXISTS `callingcardpinlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `callingcardpinlog` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `pinCode` varchar(50) NOT NULL,
  `amount` decimal(8,2) NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `notes` varchar(500) DEFAULT NULL,
  `dateCreated` datetime(3) NOT NULL,
  `lastUpdated` datetime(3) NOT NULL,
  PRIMARY KEY (`Id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=1210 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `chargeback`
--

DROP TABLE IF EXISTS `chargeback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chargeback` (
  `Transaction` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `Mobile Number` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `REASON CODE DESCRIPTION` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `Transaction date` datetime(3) DEFAULT NULL,
  `First update` datetime(3) DEFAULT NULL,
  `Last update` datetime(3) DEFAULT NULL,
  `Service status` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `iccid` varchar(25) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=804 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `chargelatest`
--

DROP TABLE IF EXISTS `chargelatest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chargelatest` (
  `pay_reference` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `transaction_date` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `mobileno` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `reason` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `chargeback_claim_date` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `Transaction Amount` float DEFAULT NULL,
  `customer_name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `cardnumber` varchar(15) DEFAULT NULL,
  `chargeback_claim_dateout` datetime(3) DEFAULT NULL,
  `transaction_date_out` datetime(3) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `country`
--

DROP TABLE IF EXISTS `country`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `country` (
  `CountryId` varchar(2) NOT NULL,
  `CountryName` varchar(50) NOT NULL,
  `CountryCode` int NOT NULL,
  `Currency` varchar(3) NOT NULL,
  `IsSelf` tinyint(1) NOT NULL,
  PRIMARY KEY (`CountryId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ctp_tpayment_invoice`
--

DROP TABLE IF EXISTS `ctp_tpayment_invoice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ctp_tpayment_invoice` (
  `id` int NOT NULL AUTO_INCREMENT,
  `account_id` varchar(20) DEFAULT NULL,
  `merchant_reference` varchar(250) DEFAULT NULL,
  `first_name` varchar(30) DEFAULT NULL,
  `last_name` varchar(30) DEFAULT NULL,
  `street` varchar(250) DEFAULT NULL,
  `city` varchar(250) DEFAULT NULL,
  `post_code` varchar(250) DEFAULT NULL,
  `country` varchar(250) DEFAULT NULL,
  `last4` varchar(250) DEFAULT NULL,
  `topup_amount` float DEFAULT NULL,
  `vat_amount` float DEFAULT NULL,
  `total_amount` float DEFAULT NULL,
  `created_date` datetime(3) DEFAULT NULL,
  `currency` varchar(10) DEFAULT NULL,
  `email` varchar(250) DEFAULT NULL,
  `status` int DEFAULT NULL,
  `mobileno` varchar(20) DEFAULT NULL,
  `master_bal` float DEFAULT NULL,
  `bundleid` int DEFAULT NULL,
  `bundlename` varchar(500) DEFAULT NULL,
  UNIQUE KEY `id` (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=12811 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fraud_score_log`
--

DROP TABLE IF EXISTS `fraud_score_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fraud_score_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `logdate` datetime(3) DEFAULT NULL,
  `fraud_score` varchar(32) DEFAULT NULL,
  `referenceid` varchar(32) DEFAULT NULL,
  `requestid` varchar(64) DEFAULT NULL,
  `eci_value` int DEFAULT NULL,
  UNIQUE KEY `id` (`id`),
  KEY `fraud_score_log_nonidx` (`referenceid`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=3313601 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `message_config_text`
--

DROP TABLE IF EXISTS `message_config_text`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `message_config_text` (
  `message_id` int DEFAULT NULL,
  `lang_code` varchar(2) DEFAULT NULL,
  `message_text` varchar(320) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `mvno_auttopup_type_register`
--

DROP TABLE IF EXISTS `mvno_auttopup_type_register`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mvno_auttopup_type_register` (
  `id` int NOT NULL AUTO_INCREMENT,
  `mobileno` varchar(20) NOT NULL,
  `topup_type` int DEFAULT NULL,
  `create_date` datetime(3) DEFAULT NULL,
  `create_by` varchar(25) DEFAULT NULL,
  `lastupdate` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`mobileno`),
  UNIQUE KEY `id` (`id`),
  KEY `FK__mvno_autt__topup__23B427BFIdx` (`topup_type`),
  CONSTRAINT `FK__mvno_autt__topup__23B427BF` FOREIGN KEY (`topup_type`) REFERENCES `auttopup_type` (`topup_type`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=28413 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `mvno_transaction_log`
--

DROP TABLE IF EXISTS `mvno_transaction_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mvno_transaction_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `mobileno` varchar(20) DEFAULT NULL,
  `reference_id` varchar(50) DEFAULT NULL,
  `current_bal` float DEFAULT NULL,
  `topup_amount` float DEFAULT NULL,
  `topup_status` int DEFAULT NULL,
  UNIQUE KEY `id` (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=804867 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `oneweek`
--

DROP TABLE IF EXISTS `oneweek`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oneweek` (
  `mobileno` varchar(16) DEFAULT NULL,
  `paymentRef` varchar(64) DEFAULT NULL,
  `createdate` datetime(3) DEFAULT NULL,
  `subscriptionid` varchar(40) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `payhsopproduct`
--

DROP TABLE IF EXISTS `payhsopproduct`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payhsopproduct` (
  `Id` varchar(15) NOT NULL,
  `Key` decimal(4,0) NOT NULL,
  `Value` decimal(4,0) NOT NULL,
  `Type` varchar(5) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `payment_card_detail`
--

DROP TABLE IF EXISTS `payment_card_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment_card_detail` (
  `id` int NOT NULL AUTO_INCREMENT,
  `account_id` varchar(20) NOT NULL,
  `Last6digitsCC` varchar(20) NOT NULL,
  `expirydate` varchar(6) DEFAULT NULL,
  `card_type` varchar(150) DEFAULT NULL,
  `process_device` varchar(100) DEFAULT NULL,
  `create_date` datetime(3) DEFAULT NULL,
  `card_holder_name` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `postcode` varchar(50) DEFAULT NULL,
  `is_autotopup` int NOT NULL DEFAULT '0',
  `auto_topup_amount` float DEFAULT NULL,
  `is_delightcall` int NOT NULL,
  PRIMARY KEY (`account_id`,`Last6digitsCC`),
  UNIQUE KEY `id` (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=1188 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `payment_detail`
--

DROP TABLE IF EXISTS `payment_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment_detail` (
  `reference_id` varchar(50) DEFAULT NULL,
  `account_id` varchar(20) DEFAULT NULL,
  `email_address` varchar(250) DEFAULT NULL,
  `amount` float DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=177 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `payment_detail_full_detail`
--

DROP TABLE IF EXISTS `payment_detail_full_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment_detail_full_detail` (
  `reference_id` varchar(50) DEFAULT NULL,
  `account_id` varchar(20) DEFAULT NULL,
  `email_address` varchar(250) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `payment_duplicate`
--

DROP TABLE IF EXISTS `payment_duplicate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment_duplicate` (
  `account_id` varchar(20) DEFAULT NULL,
  `total_count` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `payment_gateway_check_rule_v2_log`
--

DROP TABLE IF EXISTS `payment_gateway_check_rule_v2_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment_gateway_check_rule_v2_log` (
  `cc_no` varchar(6) DEFAULT NULL,
  `amount` float DEFAULT NULL,
  `mobileno` varchar(20) DEFAULT NULL,
  `ipaddress` varchar(50) DEFAULT NULL,
  `card_type` varchar(50) DEFAULT NULL,
  `called_by` varchar(25) DEFAULT NULL,
  `product_code` varchar(150) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=86384 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `payment_info`
--

DROP TABLE IF EXISTS `payment_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment_info` (
  `account_id` varchar(32) DEFAULT NULL,
  `REFERENCE_ID` varchar(32) NOT NULL,
  `TOTALAMOUNT` float DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=647 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `payment_restrict_config`
--

DROP TABLE IF EXISTS `payment_restrict_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment_restrict_config` (
  `id` int NOT NULL AUTO_INCREMENT,
  `currency` varchar(10) NOT NULL,
  `max_amount` float DEFAULT NULL,
  `days_valid` int DEFAULT NULL,
  PRIMARY KEY (`currency`),
  UNIQUE KEY `id` (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `payment_restrict_log`
--

DROP TABLE IF EXISTS `payment_restrict_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment_restrict_log` (
  `logid` int NOT NULL AUTO_INCREMENT,
  `logdate` datetime(3) DEFAULT NULL,
  `account_id` varchar(20) DEFAULT NULL,
  `payment_agent` varchar(50) DEFAULT NULL,
  `currency` varchar(5) DEFAULT NULL,
  `topup_amount` float DEFAULT NULL,
  `trans_amount` float DEFAULT NULL,
  `errcode` int DEFAULT NULL,
  `errmsg` varchar(150) DEFAULT NULL,
  `aut_trans_amount` float DEFAULT NULL,
  `appname` varchar(10) DEFAULT NULL,
  `cc_no` varchar(6) DEFAULT NULL,
  PRIMARY KEY (`logid`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=4645 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `payment_restrict_topup_log`
--

DROP TABLE IF EXISTS `payment_restrict_topup_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment_restrict_topup_log` (
  `account_id` varchar(20) DEFAULT NULL,
  `payment_agent` varchar(10) DEFAULT NULL,
  `currency` varchar(5) DEFAULT NULL,
  `topup_amount` float DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `payment_sitecode_mapping`
--

DROP TABLE IF EXISTS `payment_sitecode_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment_sitecode_mapping` (
  `sitecode` varchar(5) NOT NULL,
  `payment_sitecode` varchar(5) NOT NULL,
  `comments` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`sitecode`,`payment_sitecode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `payment_success_info`
--

DROP TABLE IF EXISTS `payment_success_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment_success_info` (
  `CREATED_DATE` datetime(3) DEFAULT NULL,
  `ACCOUNT_ID` varchar(32) DEFAULT NULL,
  `REFERENCE_ID` varchar(32) NOT NULL,
  `TOTALAMOUNT` float DEFAULT NULL,
  `ReplyMessage` varchar(512) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `payment_succsss_case`
--

DROP TABLE IF EXISTS `payment_succsss_case`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment_succsss_case` (
  `REFERENCE_ID` varchar(32) NOT NULL,
  `SITECODE` varchar(5) DEFAULT NULL,
  `PAYMENT_AGENT` varchar(12) NOT NULL,
  `SERVICE_TYPE` char(4) NOT NULL,
  `PRODUCT_CODE` varchar(64) DEFAULT NULL,
  `PAYMENT_MODE` char(3) NOT NULL,
  `ACCOUNT_ID` varchar(32) DEFAULT NULL,
  `CC_NO` char(6) DEFAULT NULL,
  `TOTALAMOUNT` float DEFAULT NULL,
  `CURRENCY` varchar(3) DEFAULT NULL,
  `CREATED_DATE` datetime(3) DEFAULT NULL,
  `SUBSCRIPTIONID` varchar(40) DEFAULT NULL,
  `CURRENT_STATUS` int DEFAULT NULL,
  `LAST_STEP` int DEFAULT NULL,
  `MERCHANT_ID` varchar(10) DEFAULT NULL,
  `PROVIDER_CODE` varchar(5) DEFAULT NULL,
  `LAST_GENERAL_ERROR_CODE` int DEFAULT NULL,
  `sendToProduction` varchar(5) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `IPpaymentagent` varchar(20) DEFAULT NULL,
  `IPClient` varchar(20) DEFAULT NULL,
  `3DFlag` char(1) DEFAULT NULL,
  `ReplyMessage` varchar(512) DEFAULT NULL,
  `ReviewQueue` varchar(50) DEFAULT NULL,
  `Selectedprofile` varchar(50) DEFAULT NULL,
  `ThreeDFlag` char(1) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `paypal_transaction_log`
--

DROP TABLE IF EXISTS `paypal_transaction_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `paypal_transaction_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `trans_id` varchar(100) DEFAULT NULL,
  `reference_id` varchar(50) NOT NULL,
  `paypal_email` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`reference_id`),
  UNIQUE KEY `id` (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `paysaf_merchant_ref_details`
--

DROP TABLE IF EXISTS `paysaf_merchant_ref_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `paysaf_merchant_ref_details` (
  `sitecode` varchar(10) DEFAULT NULL,
  `applicationcode` varchar(10) DEFAULT NULL,
  `reference_id` varchar(150) NOT NULL,
  `accountid` varchar(20) NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `amount` float DEFAULT NULL,
  `vat_amount` float DEFAULT NULL,
  `vatPercentage` float DEFAULT NULL,
  `total_amount` varchar(20) DEFAULT NULL,
  `IPClient` varchar(100) DEFAULT NULL,
  `currency` varchar(10) DEFAULT NULL,
  `OrderNumber` varchar(20) DEFAULT NULL,
  `mobile` varchar(20) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  `street` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `postCode` varchar(50) DEFAULT NULL,
  `country` varchar(50) DEFAULT NULL,
  `pnURL` varchar(200) DEFAULT NULL,
  `OkUrl` varchar(200) DEFAULT NULL,
  `NokUrl` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`accountid`,`reference_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `paysaf_transaction_log`
--

DROP TABLE IF EXISTS `paysaf_transaction_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `paysaf_transaction_log` (
  `logid` int NOT NULL AUTO_INCREMENT,
  `logdate` datetime(3) DEFAULT NULL,
  `processname` varchar(100) DEFAULT NULL,
  `mobileno` varchar(20) DEFAULT NULL,
  `reference_id` varchar(100) DEFAULT NULL,
  `user_currency` varchar(5) DEFAULT NULL,
  `card_currency` varchar(5) DEFAULT NULL,
  `user_amount` float DEFAULT NULL,
  `converted_amount` float DEFAULT NULL,
  `card_balance` float DEFAULT NULL,
  `process_by` varchar(25) DEFAULT NULL,
  `errcode` int DEFAULT NULL,
  `errmsg` varchar(250) DEFAULT NULL,
  UNIQUE KEY `logid` (`logid`),
  KEY `idx_paysaf_transaction_log` (`mobileno`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `paysafe_error_master`
--

DROP TABLE IF EXISTS `paysafe_error_master`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `paysafe_error_master` (
  `idx` int NOT NULL AUTO_INCREMENT,
  `paysafe_code` varchar(5) DEFAULT NULL,
  `paysafe_descript` varchar(250) DEFAULT NULL,
  `Created_by` varchar(50) NOT NULL,
  `Created_date` datetime(3) DEFAULT NULL,
  `modifed_by` varchar(50) DEFAULT NULL,
  `modified_date` datetime(3) DEFAULT NULL,
  UNIQUE KEY `idx` (`idx`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `paysafe_payment_log`
--

DROP TABLE IF EXISTS `paysafe_payment_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `paysafe_payment_log` (
  `idx` int NOT NULL AUTO_INCREMENT,
  `mobile_no` varchar(32) DEFAULT NULL,
  `reference_id` varchar(64) DEFAULT NULL,
  `Pay_step` int DEFAULT NULL,
  `Pay_code` int DEFAULT NULL,
  `Pay_decision` varchar(500) DEFAULT NULL,
  `Pay_description` varchar(500) DEFAULT NULL,
  `Pay_stage` varchar(150) DEFAULT NULL,
  `created_date` datetime(3) DEFAULT NULL,
  UNIQUE KEY `idx` (`idx`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `payshopTransactions`
--

DROP TABLE IF EXISTS `payshopTransactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payshopTransactions` (
  `tid` varchar(15) NOT NULL,
  `amount` decimal(8,2) NOT NULL,
  `productCode` varchar(15) NOT NULL,
  `refId` varchar(15) NOT NULL,
  `tidDateTime` datetime(3) NOT NULL,
  `applyPaymentReply` varchar(15) NOT NULL,
  `confirmPayment` varchar(15) DEFAULT NULL,
  `confirmPaymentReply` varchar(15) DEFAULT NULL,
  `dateCreated` datetime(3) NOT NULL,
  `lastUpdated` datetime(3) NOT NULL,
  PRIMARY KEY (`tid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product` (
  `ProductId` varchar(30) NOT NULL,
  `ProductTitle` varchar(100) NOT NULL,
  `ProductSeq` int NOT NULL,
  `ChargeAmount` decimal(8,2) NOT NULL,
  `TransferAmount` decimal(8,2) NOT NULL,
  `ReceivedAmount` decimal(8,2) NOT NULL,
  `BaseCountryId` varchar(2) NOT NULL,
  `CountryId` varchar(2) NOT NULL,
  `VendorId` varchar(15) NOT NULL,
  `isSelf` tinyint(1) NOT NULL,
  `Ratio` decimal(8,2) NOT NULL,
  `operator_id` int NOT NULL,
  PRIMARY KEY (`ProductId`),
  KEY `ix_product_CountryId` (`CountryId`),
  KEY `ix_product_VendorId` (`VendorId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `product_GH`
--

DROP TABLE IF EXISTS `product_GH`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_GH` (
  `ProductId` varchar(30) NOT NULL,
  `ProductTitle` varchar(100) NOT NULL,
  `ProductSeq` int NOT NULL,
  `ChargeAmount` decimal(8,2) NOT NULL,
  `TransferAmount` decimal(8,2) NOT NULL,
  `ReceivedAmount` decimal(8,2) NOT NULL,
  `BaseCountryId` varchar(2) NOT NULL,
  `CountryId` varchar(2) NOT NULL,
  `VendorId` varchar(15) NOT NULL,
  `isSelf` tinyint(1) NOT NULL,
  `Ratio` decimal(8,2) NOT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `product_cy_gb`
--

DROP TABLE IF EXISTS `product_cy_gb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_cy_gb` (
  `ProductId` varchar(30) NOT NULL,
  `ProductTitle` varchar(100) NOT NULL,
  `ProductSeq` int NOT NULL,
  `ChargeAmount` decimal(8,2) NOT NULL,
  `TransferAmount` decimal(8,2) NOT NULL,
  `ReceivedAmount` decimal(8,2) NOT NULL,
  `BaseCountryId` varchar(2) NOT NULL,
  `CountryId` varchar(2) NOT NULL,
  `VendorId` varchar(15) NOT NULL,
  `isSelf` tinyint(1) NOT NULL,
  `Ratio` decimal(8,2) NOT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `product_dodol`
--

DROP TABLE IF EXISTS `product_dodol`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_dodol` (
  `ProductId` varchar(30) NOT NULL,
  `ProductTitle` varchar(100) NOT NULL,
  `ProductSeq` int NOT NULL,
  `ChargeAmount` decimal(8,2) NOT NULL,
  `TransferAmount` decimal(8,2) NOT NULL,
  `ReceivedAmount` decimal(8,2) NOT NULL,
  `BaseCountryId` varchar(2) NOT NULL,
  `CountryId` varchar(2) NOT NULL,
  `VendorId` varchar(15) NOT NULL,
  `isSelf` tinyint(1) NOT NULL,
  `Ratio` decimal(8,2) NOT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `product_ref`
--

DROP TABLE IF EXISTS `product_ref`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_ref` (
  `product_code` varchar(64) DEFAULT NULL,
  `payment_agent` varchar(5) NOT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ptest`
--

DROP TABLE IF EXISTS `ptest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ptest` (
  `seq` int NOT NULL AUTO_INCREMENT,
  `ref` varchar(100) DEFAULT NULL,
  `rem` varchar(100) DEFAULT NULL,
  UNIQUE KEY `seq` (`seq`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `r`
--

DROP TABLE IF EXISTS `r`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `r` (
  `mobileno` varchar(16) DEFAULT NULL,
  `subscriptionid` varchar(50) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ref_gocard_currency`
--

DROP TABLE IF EXISTS `ref_gocard_currency`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ref_gocard_currency` (
  `id` int DEFAULT NULL,
  `currency` varchar(5) NOT NULL,
  PRIMARY KEY (`currency`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ref_gocard_desiscion`
--

DROP TABLE IF EXISTS `ref_gocard_desiscion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ref_gocard_desiscion` (
  `id` int DEFAULT NULL,
  `desiscion` varchar(50) NOT NULL,
  PRIMARY KEY (`desiscion`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ref_gocard_status`
--

DROP TABLE IF EXISTS `ref_gocard_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ref_gocard_status` (
  `status_id` int DEFAULT NULL,
  `status_name` varchar(50) NOT NULL,
  PRIMARY KEY (`status_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ref_mvno_transaction_Status`
--

DROP TABLE IF EXISTS `ref_mvno_transaction_Status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ref_mvno_transaction_Status` (
  `topup_status` int DEFAULT NULL,
  `description` varchar(50) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ref_porcess_type`
--

DROP TABLE IF EXISTS `ref_porcess_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ref_porcess_type` (
  `process_type` int NOT NULL,
  `process_name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`process_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `rx_routing`
--

DROP TABLE IF EXISTS `rx_routing`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rx_routing` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `sitecode` varchar(3) DEFAULT NULL,
  `provider_code` varchar(3) DEFAULT NULL,
  `merchant_id` varchar(50) DEFAULT NULL,
  `password` varchar(55) DEFAULT NULL,
  UNIQUE KEY `Id` (`Id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `schoitel_final_list`
--

DROP TABLE IF EXISTS `schoitel_final_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `schoitel_final_list` (
  `opr_id` int DEFAULT NULL,
  `opr_name` varchar(250) DEFAULT NULL,
  `opr_prefix` longtext,
  `msisdn_length` varchar(15) DEFAULT NULL,
  `CURRENCY` varchar(1000) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `iso2_code` varchar(1000) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `COUNTRY_CODE` varchar(1000) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `id` int NOT NULL AUTO_INCREMENT,
  UNIQUE KEY `id` (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=244 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `schotiel_product`
--

DROP TABLE IF EXISTS `schotiel_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `schotiel_product` (
  `ProductId` varchar(30) NOT NULL,
  `ProductTitle` varchar(100) NOT NULL,
  `ProductSeq` int NOT NULL,
  `ChargeAmount` decimal(8,2) NOT NULL,
  `TransferAmount` decimal(8,2) NOT NULL,
  `ReceivedAmount` decimal(8,2) NOT NULL,
  `BaseCountryId` varchar(2) NOT NULL,
  `CountryId` varchar(2) NOT NULL,
  `VendorId` varchar(15) NOT NULL,
  `isSelf` tinyint(1) NOT NULL,
  `Ratio` decimal(8,2) NOT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=644 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `score_muni`
--

DROP TABLE IF EXISTS `score_muni`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `score_muni` (
  `id` int NOT NULL AUTO_INCREMENT,
  `score` varchar(32) DEFAULT NULL,
  `referenceid` varchar(32) DEFAULT NULL,
  `requestid` varchar(64) DEFAULT NULL,
  UNIQUE KEY `id` (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sim_info`
--

DROP TABLE IF EXISTS `sim_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sim_info` (
  `first_name` varchar(250) DEFAULT NULL,
  `last_name` varchar(250) DEFAULT NULL,
  `street_name` varchar(150) DEFAULT NULL,
  `city` varchar(250) DEFAULT NULL,
  `postcode` varchar(250) DEFAULT NULL,
  `country` varchar(50) DEFAULT NULL,
  `payment_ref` varchar(250) DEFAULT NULL,
  `id` int NOT NULL,
  `bundle_id` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sochitelOperator`
--

DROP TABLE IF EXISTS `sochitelOperator`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sochitelOperator` (
  `Id` int NOT NULL,
  `Name` varchar(60) NOT NULL,
  `Currency` varchar(3) NOT NULL,
  `Prefixes` longtext,
  `CountryPrefixes` longtext,
  `MsisdnLength` int NOT NULL,
  `productId` varchar(10) DEFAULT NULL,
  `operator_id` int DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sochitelOperator_final`
--

DROP TABLE IF EXISTS `sochitelOperator_final`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sochitelOperator_final` (
  `Id` int NOT NULL,
  `Name` varchar(60) NOT NULL,
  `Currency` varchar(3) NOT NULL,
  `Prefixes` varchar(1024) NOT NULL,
  `CountryPrefixes` varchar(4000) NOT NULL,
  `MsisdnLength` int NOT NULL,
  `productId` varchar(10) DEFAULT NULL,
  `operator_id` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sysarticlecolumns`
--

DROP TABLE IF EXISTS `sysarticlecolumns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sysarticlecolumns` (
  `artid` int NOT NULL,
  `colid` int NOT NULL,
  `is_udt` tinyint(1) DEFAULT NULL,
  `is_xml` tinyint(1) DEFAULT NULL,
  `is_max` tinyint(1) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`),
  UNIQUE KEY `idx_sysarticlecolumns` (`artid`,`colid`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sysarticles`
--

DROP TABLE IF EXISTS `sysarticles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sysarticles` (
  `artid` int NOT NULL AUTO_INCREMENT,
  `creation_script` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `del_cmd` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `description` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `dest_table` varchar(256) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `filter` int NOT NULL,
  `filter_clause` longtext,
  `ins_cmd` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `name` varchar(256) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `objid` int NOT NULL,
  `pubid` int NOT NULL,
  `pre_creation_cmd` tinyint unsigned NOT NULL,
  `status` tinyint unsigned NOT NULL,
  `sync_objid` int NOT NULL,
  `type` tinyint unsigned NOT NULL,
  `upd_cmd` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `schema_option` binary(8) DEFAULT NULL,
  `dest_owner` varchar(256) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `ins_scripting_proc` int DEFAULT NULL,
  `del_scripting_proc` int DEFAULT NULL,
  `upd_scripting_proc` int DEFAULT NULL,
  `custom_script` varchar(2048) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `fire_triggers_on_snapshot` tinyint(1) NOT NULL,
  UNIQUE KEY `artid` (`artid`),
  UNIQUE KEY `c1sysarticles` (`artid`,`pubid`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sysarticleupdates`
--

DROP TABLE IF EXISTS `sysarticleupdates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sysarticleupdates` (
  `artid` int NOT NULL,
  `pubid` int NOT NULL,
  `sync_ins_proc` int NOT NULL,
  `sync_upd_proc` int NOT NULL,
  `sync_del_proc` int NOT NULL,
  `autogen` tinyint(1) NOT NULL,
  `sync_upd_trig` int NOT NULL,
  `conflict_tableid` int DEFAULT NULL,
  `ins_conflict_proc` int DEFAULT NULL,
  `identity_support` tinyint(1) NOT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`),
  UNIQUE KEY `unc1sysarticleupdates` (`artid`,`pubid`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `syspublications`
--

DROP TABLE IF EXISTS `syspublications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `syspublications` (
  `description` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `name` varchar(256) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `pubid` int NOT NULL AUTO_INCREMENT,
  `repl_freq` tinyint unsigned NOT NULL,
  `status` tinyint unsigned NOT NULL,
  `sync_method` tinyint unsigned NOT NULL,
  `snapshot_jobid` binary(16) DEFAULT NULL,
  `independent_agent` tinyint(1) NOT NULL,
  `immediate_sync` tinyint(1) NOT NULL,
  `enabled_for_internet` tinyint(1) NOT NULL,
  `allow_push` tinyint(1) NOT NULL,
  `allow_pull` tinyint(1) NOT NULL,
  `allow_anonymous` tinyint(1) NOT NULL,
  `immediate_sync_ready` tinyint(1) NOT NULL,
  `allow_sync_tran` tinyint(1) NOT NULL,
  `autogen_sync_procs` tinyint(1) NOT NULL,
  `retention` int DEFAULT NULL,
  `allow_queued_tran` tinyint(1) NOT NULL,
  `snapshot_in_defaultfolder` tinyint(1) NOT NULL,
  `alt_snapshot_folder` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `pre_snapshot_script` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `post_snapshot_script` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `compress_snapshot` tinyint(1) NOT NULL,
  `ftp_address` varchar(256) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `ftp_port` int NOT NULL,
  `ftp_subdirectory` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `ftp_login` varchar(256) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `ftp_password` varchar(524) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `allow_dts` tinyint(1) NOT NULL,
  `allow_subscription_copy` tinyint(1) NOT NULL,
  `centralized_conflicts` tinyint(1) DEFAULT NULL,
  `conflict_retention` int DEFAULT NULL,
  `conflict_policy` int DEFAULT NULL,
  `queue_type` int DEFAULT NULL,
  `ad_guidname` varchar(256) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `backward_comp_level` int NOT NULL,
  `allow_initialize_from_backup` tinyint(1) NOT NULL,
  `min_autonosync_lsn` binary(10) DEFAULT NULL,
  `replicate_ddl` int DEFAULT NULL,
  `options` int NOT NULL,
  `originator_id` int DEFAULT NULL,
  UNIQUE KEY `pubid` (`pubid`),
  UNIQUE KEY `uc1syspublications` (`pubid`),
  UNIQUE KEY `unc2syspublications` (`name`(191)),
  KEY `nc3syspublications` (`status`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sysreplservers`
--

DROP TABLE IF EXISTS `sysreplservers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sysreplservers` (
  `srvname` varchar(256) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `srvid` int DEFAULT NULL,
  PRIMARY KEY (`srvname`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sysschemaarticles`
--

DROP TABLE IF EXISTS `sysschemaarticles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sysschemaarticles` (
  `artid` int NOT NULL,
  `creation_script` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `description` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `dest_object` varchar(256) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `name` varchar(256) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `objid` int NOT NULL,
  `pubid` int NOT NULL,
  `pre_creation_cmd` tinyint unsigned NOT NULL,
  `status` int NOT NULL,
  `type` tinyint unsigned NOT NULL,
  `schema_option` binary(8) DEFAULT NULL,
  `dest_owner` varchar(256) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`),
  UNIQUE KEY `c1sysschemaarticles` (`artid`,`pubid`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `syssubscriptions`
--

DROP TABLE IF EXISTS `syssubscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `syssubscriptions` (
  `artid` int NOT NULL,
  `srvid` smallint NOT NULL,
  `dest_db` varchar(256) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `status` tinyint unsigned NOT NULL,
  `sync_type` tinyint unsigned NOT NULL,
  `login_name` varchar(256) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `subscription_type` int NOT NULL,
  `distribution_jobid` binary(16) DEFAULT NULL,
  `timestamp` binary(16) NOT NULL,
  `update_mode` tinyint unsigned NOT NULL,
  `loopback_detection` tinyint(1) NOT NULL,
  `queued_reinit` tinyint(1) NOT NULL,
  `nosync_type` tinyint unsigned NOT NULL,
  `srvname` varchar(256) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`),
  UNIQUE KEY `unc1syssubscriptions` (`artid`,`srvid`,`dest_db`(191),`srvname`(191))
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `systranschemas`
--

DROP TABLE IF EXISTS `systranschemas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `systranschemas` (
  `tabid` int NOT NULL,
  `startlsn` binary(10) NOT NULL,
  `endlsn` binary(10) NOT NULL,
  `typeid` int NOT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`),
  UNIQUE KEY `uncsystranschemas` (`startlsn`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `t`
--

DROP TABLE IF EXISTS `t`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t` (
  `Account_Id` varchar(30) NOT NULL,
  `SubscriptionID` varchar(40) DEFAULT NULL,
  `DateCreated` datetime(3) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=4456 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tSIMOrderPrice`
--

DROP TABLE IF EXISTS `tSIMOrderPrice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tSIMOrderPrice` (
  `Country_Code` varchar(4) NOT NULL,
  `Currency_Code` varchar(4) DEFAULT NULL,
  `Delivery_Cost` decimal(18,0) DEFAULT NULL,
  PRIMARY KEY (`Country_Code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tSubscription`
--

DROP TABLE IF EXISTS `tSubscription`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tSubscription` (
  `Account_Id` varchar(30) NOT NULL,
  `Last6digitsCC` varchar(6) NOT NULL,
  `SubscriptionID` varchar(40) DEFAULT NULL,
  `expirydate` varchar(6) NOT NULL,
  `purchasedate` varchar(8) NOT NULL,
  `provider_code` varchar(5) DEFAULT NULL,
  `idx` int NOT NULL AUTO_INCREMENT,
  `cvv_number` varchar(5) DEFAULT NULL,
  `is_ecom` int DEFAULT NULL,
  `card_type` varchar(100) DEFAULT NULL,
  `status` int NOT NULL DEFAULT (1),
  `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `sc_SubscriptionID` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`Account_Id`,`Last6digitsCC`),
  UNIQUE KEY `idx` (`idx`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=1021611 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tSubscriptionLog`
--

DROP TABLE IF EXISTS `tSubscriptionLog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tSubscriptionLog` (
  `Logid` int NOT NULL AUTO_INCREMENT,
  `Account_Id` varchar(30) NOT NULL,
  `Last6digitsCC` varchar(6) NOT NULL,
  `SubscriptionID` varchar(40) DEFAULT NULL,
  `expirydate` varchar(6) NOT NULL,
  `purchasedate` varchar(8) DEFAULT NULL,
  `actiondate` datetime(3) NOT NULL,
  `provider_code` varchar(5) DEFAULT NULL,
  `Description` varchar(128) DEFAULT NULL,
  `cvv_number` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`Logid`),
  KEY `idx2` (`Account_Id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=3406199 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tSubscriptionUpdateLog`
--

DROP TABLE IF EXISTS `tSubscriptionUpdateLog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tSubscriptionUpdateLog` (
  `Logid` int NOT NULL AUTO_INCREMENT,
  `Account_Id` varchar(30) NOT NULL,
  `Last6digitsCC` varchar(6) NOT NULL,
  `SubscriptionID` varchar(40) DEFAULT NULL,
  `expirydate` varchar(6) NOT NULL,
  `purchasedate` varchar(8) DEFAULT NULL,
  `actiondate` datetime(3) NOT NULL,
  `provider_code` varchar(5) DEFAULT NULL,
  `Description` varchar(128) DEFAULT NULL,
  `cvv_number` varchar(5) DEFAULT NULL,
  `payerefError` int DEFAULT NULL,
  `cardrefError` int DEFAULT NULL,
  PRIMARY KEY (`Logid`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tSubscription_amazon`
--

DROP TABLE IF EXISTS `tSubscription_amazon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tSubscription_amazon` (
  `id` int NOT NULL AUTO_INCREMENT,
  `account_Id` varchar(20) NOT NULL,
  `amz_subscribtionid` varchar(30) NOT NULL,
  `lasttopup_amount` float DEFAULT NULL,
  `currency` varchar(10) DEFAULT NULL,
  `device_type` varchar(50) DEFAULT NULL,
  `create_date` datetime(3) DEFAULT NULL,
  `lastupdate` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`account_Id`,`amz_subscribtionid`),
  UNIQUE KEY `id` (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tSubscription_chargeback`
--

DROP TABLE IF EXISTS `tSubscription_chargeback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tSubscription_chargeback` (
  `Account_Id` varchar(30) NOT NULL,
  `Last6digitsCC` varchar(6) NOT NULL,
  `SubscriptionID` varchar(40) DEFAULT NULL,
  `expirydate` varchar(6) NOT NULL,
  `purchasedate` varchar(8) NOT NULL,
  `provider_code` varchar(5) DEFAULT NULL,
  `idx` int NOT NULL,
  `cvv_number` varchar(5) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=5790 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tSubscription_paypal`
--

DROP TABLE IF EXISTS `tSubscription_paypal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tSubscription_paypal` (
  `idx` int NOT NULL AUTO_INCREMENT,
  `account_Id` varchar(20) NOT NULL,
  `token` varchar(85) NOT NULL,
  `purchasedate` varchar(8) DEFAULT NULL,
  `transaction_reference` varchar(50) DEFAULT NULL,
  `customer_id` varchar(50) DEFAULT NULL,
  `currency` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`account_Id`,`token`),
  UNIQUE KEY `idx` (`idx`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=23240 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tSubscription_token_available`
--

DROP TABLE IF EXISTS `tSubscription_token_available`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tSubscription_token_available` (
  `Account_Id` varchar(30) NOT NULL,
  `Last6digitsCC` varchar(6) NOT NULL,
  `SubscriptionID` varchar(40) DEFAULT NULL,
  `expirydate` varchar(6) NOT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=134713 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tariffclass`
--

DROP TABLE IF EXISTS `tariffclass`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tariffclass` (
  `Id` varchar(15) NOT NULL,
  `tariffId` varchar(15) NOT NULL,
  `primeId` int NOT NULL,
  `productId` varchar(15) NOT NULL,
  `amount` decimal(8,2) NOT NULL,
  `countryId` varchar(2) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `ix_tariffclas_countryId` (`countryId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_test`
--

DROP TABLE IF EXISTS `tbl_test`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_test` (
  `sitecode` varchar(20) DEFAULT NULL,
  `productcode` varchar(200) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_test_logu`
--

DROP TABLE IF EXISTS `tbl_test_logu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_test_logu` (
  `account_id` varchar(20) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tcounter_refid`
--

DROP TABLE IF EXISTS `tcounter_refid`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tcounter_refid` (
  `sitecode` char(5) NOT NULL,
  `counter` bigint NOT NULL,
  `provider_code` varchar(5) NOT NULL,
  PRIMARY KEY (`sitecode`,`provider_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tcs_eci`
--

DROP TABLE IF EXISTS `tcs_eci`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tcs_eci` (
  `id` int NOT NULL AUTO_INCREMENT,
  `reference_id` varchar(32) DEFAULT NULL,
  `eci` int DEFAULT NULL,
  `card_name` varchar(60) DEFAULT NULL,
  `update_date` datetime(3) DEFAULT NULL,
  UNIQUE KEY `id` (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=2698402 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tcs_mani`
--

DROP TABLE IF EXISTS `tcs_mani`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tcs_mani` (
  `REFERENCE_ID` varchar(35) DEFAULT NULL,
  `CS_ERROR_CODE` varchar(30) DEFAULT NULL,
  `CREATED_DATE` datetime(3) DEFAULT NULL,
  `Account_ID` varchar(32) DEFAULT NULL,
  `Title` varchar(10) DEFAULT NULL,
  `Customer_Name` varchar(250) DEFAULT NULL,
  `Email` varchar(250) DEFAULT NULL,
  `iccid` varchar(100) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=1128 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tcs_reason_forpayment`
--

DROP TABLE IF EXISTS `tcs_reason_forpayment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tcs_reason_forpayment` (
  `id` int NOT NULL AUTO_INCREMENT,
  `reference_id` varchar(50) DEFAULT NULL,
  `Reason` varchar(255) DEFAULT NULL,
  `status` varchar(122) DEFAULT NULL,
  `update_date` datetime(3) DEFAULT NULL,
  UNIQUE KEY `id` (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=2707 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tcs_reason_forpayment_v2`
--

DROP TABLE IF EXISTS `tcs_reason_forpayment_v2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tcs_reason_forpayment_v2` (
  `id` int NOT NULL AUTO_INCREMENT,
  `reference_id` varchar(32) DEFAULT NULL,
  `Reason` varchar(255) DEFAULT NULL,
  `statusref` varchar(255) DEFAULT NULL,
  `update_date` datetime(3) DEFAULT NULL,
  `users` varchar(100) DEFAULT NULL,
  UNIQUE KEY `id` (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tcs_transaction_dtls_mani`
--

DROP TABLE IF EXISTS `tcs_transaction_dtls_mani`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tcs_transaction_dtls_mani` (
  `REFERENCE_ID` varchar(35) DEFAULT NULL,
  `PAYMENT_STEP1` int DEFAULT NULL,
  `PRODUCT_CODE` varchar(64) DEFAULT NULL,
  `ACCOUNT_ID` varchar(32) DEFAULT NULL,
  `CREATED_DATE` datetime(3) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=6463 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `temp_out`
--

DROP TABLE IF EXISTS `temp_out`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `temp_out` (
  `pay_reference` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `transaction_date` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `mobileno` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `reason` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `chargeback_claim_date` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `customer_name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `trans_date1` datetime(3) DEFAULT NULL,
  `trans_amout` float DEFAULT NULL,
  `trans_amount` float DEFAULT NULL,
  `cc_no` varchar(20) DEFAULT NULL,
  `cc_no2` varchar(10) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`),
  KEY `idx1_temp_out` (`trans_date1`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=331 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `temp_paymnt`
--

DROP TABLE IF EXISTS `temp_paymnt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `temp_paymnt` (
  `REFERENCE_ID` varchar(32) NOT NULL,
  `SITECODE` varchar(5) DEFAULT NULL,
  `PAYMENT_AGENT` varchar(12) NOT NULL,
  `SERVICE_TYPE` char(4) NOT NULL,
  `PRODUCT_CODE` varchar(64) DEFAULT NULL,
  `PAYMENT_MODE` char(3) NOT NULL,
  `ACCOUNT_ID` varchar(32) DEFAULT NULL,
  `CC_NO` char(6) DEFAULT NULL,
  `TOTALAMOUNT` float DEFAULT NULL,
  `CURRENCY` varchar(3) DEFAULT NULL,
  `CREATED_DATE` datetime(3) DEFAULT NULL,
  `SUBSCRIPTIONID` varchar(40) DEFAULT NULL,
  `CURRENT_STATUS` int DEFAULT NULL,
  `LAST_STEP` int DEFAULT NULL,
  `MERCHANT_ID` varchar(10) DEFAULT NULL,
  `PROVIDER_CODE` varchar(5) DEFAULT NULL,
  `LAST_GENERAL_ERROR_CODE` int DEFAULT NULL,
  `sendToProduction` varchar(5) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `IPpaymentagent` varchar(20) DEFAULT NULL,
  `IPClient` varchar(20) DEFAULT NULL,
  `3DFlag` char(1) DEFAULT NULL,
  `ReplyMessage` varchar(512) DEFAULT NULL,
  `ReviewQueue` varchar(50) DEFAULT NULL,
  `Selectedprofile` varchar(50) DEFAULT NULL,
  `ThreeDFlag` char(1) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `temptest`
--

DROP TABLE IF EXISTS `temptest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `temptest` (
  `values1` varchar(20) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `test`
--

DROP TABLE IF EXISTS `test`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `test` (
  `id` int NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `test_tcs_tran`
--

DROP TABLE IF EXISTS `test_tcs_tran`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `test_tcs_tran` (
  `REFERENCE_ID` varchar(35) DEFAULT NULL,
  `PAYMENT_STEP1` int DEFAULT NULL,
  `product_code` varchar(64) DEFAULT NULL,
  `account_id` varchar(32) DEFAULT NULL,
  `created_date` datetime(3) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=2197 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `test_tcs_transaction`
--

DROP TABLE IF EXISTS `test_tcs_transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `test_tcs_transaction` (
  `REFERENCE_ID` varchar(35) DEFAULT NULL,
  `PAYMENT_STEP1` int DEFAULT NULL,
  `product_code` varchar(64) DEFAULT NULL,
  `account_id` varchar(32) DEFAULT NULL,
  `created_date` datetime(3) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=2197 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `testing_number`
--

DROP TABLE IF EXISTS `testing_number`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `testing_number` (
  `id` int NOT NULL AUTO_INCREMENT,
  `mobileno` varchar(20) DEFAULT NULL,
  `paymentref` varchar(60) DEFAULT NULL,
  `IS_PAYMENT` int DEFAULT NULL,
  UNIQUE KEY `id` (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `threeDS_payment_log`
--

DROP TABLE IF EXISTS `threeDS_payment_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `threeDS_payment_log` (
  `idx` int NOT NULL AUTO_INCREMENT,
  `mobileno` varchar(32) DEFAULT NULL,
  `REFERENCE_ID` varchar(64) DEFAULT NULL,
  `Pay_step` int DEFAULT NULL,
  `Pay_code` int DEFAULT NULL,
  `Pay_decision` varchar(500) DEFAULT NULL,
  `Pay_description` varchar(500) DEFAULT NULL,
  `Pay_stage` varchar(150) DEFAULT NULL,
  `created_date` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`idx`),
  KEY `threeDS_payment_log_idx1` (`REFERENCE_ID`,`Pay_step`,`Pay_code`,`Pay_decision`(255))
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=2642823 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `topup_final_out`
--

DROP TABLE IF EXISTS `topup_final_out`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `topup_final_out` (
  `mobileno` varchar(16) DEFAULT NULL,
  `paymentref` varchar(64) DEFAULT NULL,
  `amount` float DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=842 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `topup_final_out_total`
--

DROP TABLE IF EXISTS `topup_final_out_total`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `topup_final_out_total` (
  `CREATED_DATE` datetime(3) DEFAULT NULL,
  `account_id` varchar(32) DEFAULT NULL,
  `reference_id` varchar(32) NOT NULL,
  `TOTALAMOUNT` float DEFAULT NULL,
  `ReplyMessage` varchar(512) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=654 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tpayment_dm_result`
--

DROP TABLE IF EXISTS `tpayment_dm_result`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tpayment_dm_result` (
  `idx` int NOT NULL AUTO_INCREMENT,
  `request_id` varchar(64) DEFAULT NULL,
  `reference_id` varchar(32) DEFAULT NULL,
  `createdate` datetime(3) DEFAULT NULL,
  `dm_rule_id` varchar(50) DEFAULT NULL,
  `dm_rule_name` varchar(50) DEFAULT NULL,
  `dm_rule_evaluation` varchar(1) DEFAULT NULL,
  `dm_rule_decision` varchar(6) DEFAULT NULL,
  UNIQUE KEY `idx` (`idx`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tpayment_test`
--

DROP TABLE IF EXISTS `tpayment_test`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tpayment_test` (
  `REFERENCE_ID` varchar(32) NOT NULL,
  `SITECODE` varchar(5) DEFAULT NULL,
  `PAYMENT_AGENT` varchar(12) NOT NULL,
  `SERVICE_TYPE` char(4) NOT NULL,
  `PRODUCT_CODE` varchar(64) DEFAULT NULL,
  `PAYMENT_MODE` char(3) NOT NULL,
  `ACCOUNT_ID` varchar(32) DEFAULT NULL,
  `CC_NO` char(6) DEFAULT NULL,
  `TOTALAMOUNT` float DEFAULT NULL,
  `CURRENCY` varchar(3) DEFAULT NULL,
  `CREATED_DATE` datetime(3) DEFAULT NULL,
  `SUBSCRIPTIONID` varchar(40) DEFAULT NULL,
  `CURRENT_STATUS` int DEFAULT NULL,
  `LAST_STEP` int DEFAULT NULL,
  `MERCHANT_ID` varchar(10) DEFAULT NULL,
  `PROVIDER_CODE` varchar(5) DEFAULT NULL,
  `LAST_GENERAL_ERROR_CODE` int DEFAULT NULL,
  `sendToProduction` varchar(5) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `IPpaymentagent` varchar(20) DEFAULT NULL,
  `IPClient` varchar(20) DEFAULT NULL,
  `3DFlag` char(1) DEFAULT NULL,
  `ReplyMessage` varchar(512) DEFAULT NULL,
  `ReviewQueue` varchar(50) DEFAULT NULL,
  `Selectedprofile` varchar(50) DEFAULT NULL,
  `ThreeDFlag` char(1) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tsubs_paid_sim_log`
--

DROP TABLE IF EXISTS `tsubs_paid_sim_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tsubs_paid_sim_log` (
  `account_id` varchar(20) DEFAULT NULL,
  `last4digitscc` varchar(10) DEFAULT NULL,
  `SubscriptionID` varchar(100) DEFAULT NULL,
  `create_date` datetime(3) DEFAULT NULL,
  `oldsubs_id` varchar(100) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`),
  KEY `idx1_tsubs_paid_sim_log` (`account_id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tt`
--

DROP TABLE IF EXISTS `tt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tt` (
  `mobileno` varchar(16) DEFAULT NULL,
  `subscriptionid` varchar(50) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=5993 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ur_crm_monthily_bill_log`
--

DROP TABLE IF EXISTS `ur_crm_monthily_bill_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ur_crm_monthily_bill_log` (
  `umb_id` int NOT NULL,
  `umb_company_id` int DEFAULT NULL,
  `umb_bill_ref` varchar(30) DEFAULT NULL,
  `umb_curr_mnth_amt` decimal(10,2) DEFAULT NULL,
  `umb_previous_ost_amt` decimal(10,2) DEFAULT NULL,
  `umb_payment_received` decimal(10,2) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `created_by` varchar(50) DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL,
  `modified_by` varchar(50) DEFAULT NULL,
  `status_id` int DEFAULT NULL,
  `umb_total_curr_ots_amt` decimal(12,2) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vtos_vat_rate`
--

DROP TABLE IF EXISTS `vtos_vat_rate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vtos_vat_rate` (
  `ID` int NOT NULL,
  `vat_charge_old` float NOT NULL,
  `vat_charge_current` float DEFAULT NULL,
  `processed_date` datetime DEFAULT NULL,
  `vat_live` bit(1) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `web_topup_denomination`
--

DROP TABLE IF EXISTS `web_topup_denomination`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `web_topup_denomination` (
  `Idx` int NOT NULL,
  `Topup_Amount` int DEFAULT NULL,
  `Product_Id` int DEFAULT NULL,
  `Country` varchar(3) DEFAULT NULL,
  `Brand` int DEFAULT NULL,
  `sitecode` varchar(3) DEFAULT NULL,
  `country_prefix` varchar(3) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `web_transaction_Tmp`
--

DROP TABLE IF EXISTS `web_transaction_Tmp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `web_transaction_Tmp` (
  `id` int NOT NULL AUTO_INCREMENT,
  `reference_id` varchar(100) DEFAULT NULL,
  `payment_info` longtext,
  `step_no` int DEFAULT NULL,
  `create_date` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx1_web_transaction_Tmp` (`reference_id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=55363 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `webpages_Membership`
--

DROP TABLE IF EXISTS `webpages_Membership`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `webpages_Membership` (
  `UserId` int NOT NULL,
  `CreateDate` datetime(3) DEFAULT NULL,
  `ConfirmationToken` varchar(128) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `IsConfirmed` tinyint(1) DEFAULT NULL,
  `LastPasswordFailureDate` datetime(3) DEFAULT NULL,
  `PasswordFailuresSinceLastSuccess` int NOT NULL,
  `Password` varchar(128) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `PasswordChangedDate` datetime(3) DEFAULT NULL,
  `PasswordSalt` varchar(128) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `PasswordVerificationToken` varchar(128) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `PasswordVerificationTokenExpirationDate` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`UserId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `webpages_OAuthMembership`
--

DROP TABLE IF EXISTS `webpages_OAuthMembership`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `webpages_OAuthMembership` (
  `Provider` varchar(30) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `ProviderUserId` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `UserId` int NOT NULL,
  PRIMARY KEY (`Provider`,`ProviderUserId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `webpages_Roles`
--

DROP TABLE IF EXISTS `webpages_Roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `webpages_Roles` (
  `RoleId` int NOT NULL AUTO_INCREMENT,
  `RoleName` varchar(256) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  PRIMARY KEY (`RoleId`),
  UNIQUE KEY `UQ__webpages_Roles__7DCDAAA2` (`RoleName`(191)),
  KEY `fk_RoleIdIdx2` (`RoleId`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `webpages_UsersInRoles`
--

DROP TABLE IF EXISTS `webpages_UsersInRoles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `webpages_UsersInRoles` (
  `UserId` int NOT NULL,
  `RoleId` int NOT NULL,
  PRIMARY KEY (`UserId`,`RoleId`),
  KEY `fk_UserIdIdx` (`UserId`),
  KEY `fk_RoleIdIdx` (`RoleId`),
  CONSTRAINT `fk_RoleId` FOREIGN KEY (`RoleId`) REFERENCES `webpages_Roles` (`RoleId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping events for database 'payment'
--

--
-- Dumping routines for database 'payment'
--
/*!50003 DROP FUNCTION IF EXISTS `isnumeric` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` FUNCTION `isnumeric`(val varchar(1024)) RETURNS tinyint(1)
    DETERMINISTIC
return val regexp '^(-|\\+)?([0-9]+\\.[0-9]*|[0-9]*\\.[0-9]+|[0-9]+)$' ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `payment_getCounterRefID_V2` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` FUNCTION `payment_getCounterRefID_V2`(sitecode VARCHAR(5),  
 provider_code VARCHAR(5)) RETURNS int
    DETERMINISTIC
BEGIN
 
 
    DECLARE counter BIGINT;  
 
    IF provider_code is null then
       set provider_code = 'CS';
    END IF;
    if not exists(select 1 from tcounter_refid a where a.sitecode = sitecode LIMIT 1) then
 
       return -1;
    end if;  
    
  
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select   a.counter+1 INTO counter from tcounter_refid a where a.sitecode = sitecode and a.provider_code = provider_code;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   
    update tcounter_refid a
    set a.counter = counter
    where a.sitecode = sitecode
    and a.provider_code = provider_code;
   
 
    return counter;  
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `airtime_eligible_check` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `airtime_eligible_check`(
mobileno varchar(20),
receiver_no varchar(20),
amount float
)
BEGIN

	declare errcode int; 
	declare errmsg varchar(250);
	declare GetDate varchar(10);
	
	declare Already_Trans_Amount float;
	declare eligible_amount float;
	declare Already_Trans_Amount_Rec float;
	
	set errcode=0;
	set errmsg='Eligible to transfer the credit';
	set Already_Trans_Amount=0;
	set GetDate= DATE_FORMAT(CURRENT_TIMESTAMP,'%m/%d/%Y');
	set eligible_amount=10;

sp_exit : Begin	
	
	select Sum(a.Amount) into Already_Trans_Amount from airtime_transaction a where a.DonorId = mobileno and a.states='success' 
	and DATE_FORMAT(a.AirtimeDate,'%m/%d/%Y') = GetDate;
	
 	set Already_Trans_Amount=ifnull(Already_Trans_Amount,0)+ifnull(amount,0);
 	
 	if Already_Trans_Amount>eligible_amount then
 		set errcode=-1;
 		set errmsg='You reached credit transfer limit.';
 		Leave sp_exit;
 	end if;
 	
 	
 	Select Sum(a.Amount) into Already_Trans_Amount_Rec From airtime_transaction a Where Left(a.DonorId, 2) = Left(mobileno, 2)  
	and a.RecipientId = receiver_no and a.states='success' and DATE_FORMAT(AirtimeDate, '%m/%d/%Y') = GetDate;
 		
 	set Already_Trans_Amount_Rec=ifnull(Already_Trans_Amount_Rec,0)+ifnull(amount,0);
 	
 	if Already_Trans_Amount_Rec>eligible_amount then
 		set errcode=-1;
 		set errmsg='You reached credit transfer limit.';
 		Leave sp_exit;
 	end if;

end sp_exit;

	set errcode=0;
	
	select errcode as errcode,errmsg as errmsg;
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Airtime_Transaction_check_rule` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `Airtime_Transaction_check_rule`(
donor varchar(20),
receipient varchar(20),
out errcode int,
out errmsg varchar(160)
)
BEGIN

	
spreturn : Begin

	declare now date; 
	
	declare rec_count int;
	
	set errcode=0;
	set errmsg='Success';
	
	set rec_count=0;
	
	set now=CURRENT_TIMESTAMP;
	
	select count(1) into rec_count from airtime_transaction a where a.DonorId=donor and cast(a.AirtimeDate as date)=now and a.States='success';
	
	IF rec_count<>0 then
		IF NOT EXISTS(SELECT 1 FROM airtime_transaction a where a.DonorId=donor and cast(a.AirtimeDate as date)=now
		and a.States='success' and a.RecipientId = receipient) then
			SET errcode=-1;
			SET errmsg='Airtime not allowed for different number for same day';
			leave spreturn;
		END if;
	END if;
	
	
	set rec_count=0;
	
	select count(distinct a.RecipientId) into rec_count from airtime_transaction a where a.DonorId=donor and year(a.AirtimeDate)=year(now) 
	and month(a.AirtimeDate)=month(now)
	and a.States='success';
	
	if rec_count>3 then
		SET errcode=-1;
		SET errmsg='Airtime not allowed for different number for same day';
		leave spreturn;
	end if;
	
end spreturn;
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `auto_topup_check_payment_type` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `auto_topup_check_payment_type`(msisdn VARCHAR(20))
begin

  
   DECLARE v_autotopup_type INT;
   DECLARE Swv_RowCount INT;  
   
   SET v_autotopup_type = 0;
  
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   IFNULL(topup_type,0) INTO v_autotopup_type from mvno_auttopup_type_register where mobileno = msisdn;
   SET Swv_RowCount = ROW_COUNT();
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
   
   if Swv_RowCount = 0 then
      set v_autotopup_type = 0;
   end if;  

   SELECT v_autotopup_type AS is_payment_type;  
  
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `chillicrm_get_CCProfile_list` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `chillicrm_get_CCProfile_list`(
accountid VARCHAR(15))
begin

   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select distinct cc_no
   from  TPAYMENT a
   where a.account_id = accountid;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;        
  
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `chillitalk_realx_threeds_payment_log_insert` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `chillitalk_realx_threeds_payment_log_insert`(
mobileno varchar(32),
REFERENCE_ID VARCHAR(64),
Pay_step INT,
Pay_code INT,
Pay_decision varchar(100),
Pay_description varchar(500),
Pay_stage VARCHAR(150)
)
BEGIN


	declare defaut_int_val_0 int;
	declare defaut_int_val_1 int;

	set defaut_int_val_0 = 0;
	set defaut_int_val_1 = 1;

	if mobileno = '' then set mobileno = null; end if;
	if Pay_code = '' then set Pay_code = null; end if; 
	if Pay_decision = '' then set Pay_decision = null; end if;
	if Pay_description = '' then set Pay_description = null; end if;
	if Pay_stage = '' then set Pay_stage = null; end if;
	
	Insert into threeDS_payment_log (mobileno,reference_id,Pay_step,Pay_code,Pay_decision,Pay_description,Pay_stage,created_date)
	Values (mobileno,REFERENCE_ID,Pay_step,Pay_code,Pay_decision,Pay_description,Pay_stage,current_timestamp);
    
	IF row_count() > 0 then
		SELECT defaut_int_val_0 as error_code,'Successfully inserted' as error_msg;
	ELSE
		SELECT defaut_int_val_1 as error_code,'Faild to insert' as error_msg;
	END IF;
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `crm_payment_breakup_by_mobileno` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `crm_payment_breakup_by_mobileno`(
mobileno VARCHAR(20),
date_from DATETIME(3),
date_to DATETIME(3),
first_update DATETIME(3),
sim_order_id VARCHAR(60))
BEGIN

	
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   CREATE TEMPORARY TABLE tt_temp_payment_breakge AS select ACCOUNT_ID,TOTALAMOUNT,CASE WHEN REFERENCE_ID LIKE '%RX%'
      AND (REFERENCE_ID LIKE '%WEB%' OR REFERENCE_ID LIKE '%SMS%')  THEN 'Credit/ Debit Card top up'
      WHEN REFERENCE_ID LIKE '%PSC%' THEN 'Paysafe topup'
      WHEN REFERENCE_ID LIKE '%PPL%' and REFERENCE_ID not like '%AUT%'  THEN 'Paypal topup'
      WHEN REFERENCE_ID LIKE '%SIM%' THEN 'Purchase simcard'
      WHEN REFERENCE_ID LIKE '%VRN%' THEN 'LLOM'
      WHEN (REFERENCE_ID LIKE '%BUN%' AND REFERENCE_ID NOT LIKE '%SIM%') THEN 'Purchase bundle'
      WHEN REFERENCE_ID LIKE '%AUT%' and REFERENCE_ID like '%RX%' THEN 'Credit/ Debit Card Auto top up'
      WHEN REFERENCE_ID LIKE '%AUT%' and REFERENCE_ID like '%PPL%' THEN 'Paypal Auto top up'
      WHEN REFERENCE_ID LIKE '%PP%' THEN 'PAYMONTHLY BILL' ELSE 'Others' END AS PAYMENT_MODE    from TPAYMENT
      where (ACCOUNT_ID = mobileno and (CREATED_DATE >= first_update or first_update is null)) or
	(REFERENCE_ID = sim_order_id and IFNULL(sim_order_id,'') <> '') and
	(date_from is null or CREATED_DATE >= date_from) and
	(date_to is null or CREATED_DATE <= date_to) and ReplyMessage like '%succ%';
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;	
	
	
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   insert into tt_temp_payment_breakge(ACCOUNT_ID,TOTALAMOUNT,PAYMENT_MODE)
   SELECT mobileno,sum(amount),'Credit/ Debit Card Auto top up' from webPayment.tCybS_RegisteredPayment
   where(mobileno = mobileno and (reg_date >= first_update or first_update is null)) and
	(date_from is null or reg_date >= date_from) and
	(date_to is null or reg_date <= date_to)
   and decision = 'ACCEPT'
   group by mobileno;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
	
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select mobileno as ACCOUNT_ID,PAYMENT_MODE,IFNULL(SUM(a.TOTALAMOUNT),0) as purchase_amount
   from tt_temp_payment_breakge a
   group by PAYMENT_MODE;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
	
   drop TEMPORARY table IF EXISTS tt_temp_payment_breakge;
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `crm_payment_details_by_mobileno` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `crm_payment_details_by_mobileno`(
searchinfo varchar(50),
date_from datetime,
date_to datetime,
first_update datetime,
sim_order_id varchar(60),
search_type int
)
BEGIN

	if date_from is null then set date_from = null; end if;
	if date_to is null then set date_to = null; end if;
	if (search_type is null or search_type = '' ) then set search_type = 1; end if;


	drop temporary table if exists temp_payment_number_info ;
	create temporary table temp_payment_number_info
	(
		ACCOUNT_ID varchar(32),
		PAYMENT_MODE char(100),
		REFERENCE_ID varchar(32),
		TOTALAMOUNT float,
		CURRENCY varchar(3),
		payment_date datetime,
		email varchar(100),
		IPpaymentagent varchar(20),
		ReplyMessage longtext,
		CC_NO char(6)
	);
    

	insert into temp_payment_number_info(ACCOUNT_ID,PAYMENT_MODE,REFERENCE_ID,TOTALAMOUNT,CURRENCY,payment_date,email,IPpaymentagent,ReplyMessage,CC_NO)
	select a.ACCOUNT_ID as ACCOUNT_ID,
	case when a.REFERENCE_ID LIKE '%RX%' and (a.REFERENCE_ID LIKE '%EWEB-BUN%') then 'Top up & Bundle Purchase - Existing Customer-Credit card'
		when a.REFERENCE_ID LIKE '%RX%' and (a.REFERENCE_ID LIKE '%EWEB%') then 'Top up in Website - Existing customer-Credit card'
		when a.REFERENCE_ID LIKE '%RX%' and (a.REFERENCE_ID LIKE '%EBUN%') then 'Bundle Purchase - Existing customer-Credit card'
		when a.REFERENCE_ID LIKE '%RX%' and (a.REFERENCE_ID LIKE '%NBUN%') then 'Bundle Purchase - New customer-Credit card'
		when a.REFERENCE_ID LIKE '%RX%' and (a.REFERENCE_ID LIKE '%EBUND%') then 'Bundle Purchase - Existing customer-Credit card'
		when a.REFERENCE_ID LIKE '%RX%' and (a.REFERENCE_ID LIKE '%EWEB-BUND%') then 'Top up in Website - Existing customer-Credit card'
		when a.REFERENCE_ID LIKE '%RX%' and (a.REFERENCE_ID LIKE '%NWEB-BUND%') then 'Top up in Website - New customer-Credit card'
		when a.REFERENCE_ID LIKE '%PPL%' and (a.REFERENCE_ID LIKE '%EWEB%') then 'Top up in Website - Existing customer - Paypal'
		when a.REFERENCE_ID LIKE '%PPL%' and (a.REFERENCE_ID LIKE '%EBUN%') then 'Bundle Purchase - Existing customer - Paypal'
		when a.REFERENCE_ID LIKE '%PPL%' and (a.REFERENCE_ID LIKE '%NBUN%') then 'Bundle Purchase - New customer - Paypal'
		when a.REFERENCE_ID LIKE '%PPL%' and (a.REFERENCE_ID LIKE '%NWEB%') then 'Top up in Website - New customer - Paypal'
		when a.REFERENCE_ID LIKE '%PPL%' and (a.REFERENCE_ID LIKE '%EWEB%') then 'Top up in Website - Existing customer - Paypal'
		when a.REFERENCE_ID LIKE '%AMZ%' and (a.REFERENCE_ID LIKE 'EWEB%') then 'Top up in Website - Existing customer - Amazon'
		when a.REFERENCE_ID LIKE '%AMZ%' and (a.REFERENCE_ID LIKE 'NWEB%') then 'Top up in Website - New customer - Amazon'
		when a.REFERENCE_ID LIKE '%AMZ%' and (a.REFERENCE_ID LIKE 'WEB%') then 'Top up in Website - Amazon'
		when a.REFERENCE_ID LIKE '%RX%' and (a.REFERENCE_ID LIKE '%AND%') then 'Topup in Android-Credit card'
		when a.REFERENCE_ID LIKE '%ppl%' and (a.REFERENCE_ID LIKE '%AND%') then 'Topup in Android-Paypal'
		when a.REFERENCE_ID LIKE '%RX%' and (a.REFERENCE_ID LIKE '%IOS%') then 'Topup in IOS-Credit card'
		when a.REFERENCE_ID LIKE '%ppl%' and (a.REFERENCE_ID LIKE '%IOS%') then 'Topup in IOS-Paypal'
		when a.REFERENCE_ID LIKE '%RX%' and (a.REFERENCE_ID LIKE '%PMBO-CC%') then 'Paymonthly Bill Payment'
		when a.REFERENCE_ID LIKE '%AUT%' and (a.REFERENCE_ID LIKE '%RX%') then 'Auto topup-Credit card'
		when a.REFERENCE_ID LIKE '%AUT%' and (a.REFERENCE_ID LIKE '%PPL%') then 'Auto topup-Paypal'
		when a.REFERENCE_ID LIKE '%RX%' and (a.REFERENCE_ID LIKE '%IVR%') then 'IVR Topup-Credit card'
		when a.REFERENCE_ID LIKE '%RX%' and (a.REFERENCE_ID LIKE '%VRN%') then 'LLOM Purchase-Credit card'
		when a.REFERENCE_ID LIKE '%RX%' and (a.REFERENCE_ID LIKE '%PP%') then 'Paymonthly SIM-Purchase-Credit card'
		when a.REFERENCE_ID LIKE '%RX%' and (a.REFERENCE_ID LIKE '%SIM-BUN%') then 'Bundle SIM-Purchase-Credit card'
		when a.REFERENCE_ID LIKE '%PPL%' and (a.REFERENCE_ID LIKE '%SIM-BUN%') then 'Bundle SIM-Purchase-Paypal'
		when a.REFERENCE_ID LIKE '%RX%' and (a.REFERENCE_ID LIKE '%SIMTP%') then 'Topup SIM-Purchase-Credit card'
		when a.REFERENCE_ID LIKE '%PPL%' and (a.REFERENCE_ID LIKE '%SIMTP%') then 'Topup SIM-Purchase-Paypal'
		when a.REFERENCE_ID LIKE '%RX%' and (a.REFERENCE_ID LIKE '%BUN%') then 'Bundle Purchase-Credit card'
		when a.REFERENCE_ID LIKE '%PPL%' and (a.REFERENCE_ID LIKE '%BUN%') then 'Bundle Purchase-Paypal'
		when a.REFERENCE_ID LIKE '%RX%' and (a.REFERENCE_ID LIKE '%WEB%') then 'Topup in Website-Credit card'
		when a.REFERENCE_ID LIKE '%PPL%' and (a.REFERENCE_ID LIKE '%WEB%') then 'Topup in Website-Paypal'
		when a.REFERENCE_ID LIKE '%RX%' and (a.REFERENCE_ID LIKE '%SMS%') then 'Sms Topup-Credit card'
		else 
	     CASE WHEN a.REFERENCE_ID LIKE '%RX%' AND (a.REFERENCE_ID LIKE '%WEB%' OR a.REFERENCE_ID LIKE '%SMS%')  THEN 'Credit/ Debit Card' 
			WHEN a.REFERENCE_ID LIKE '%PSC%' THEN 'Paysafe topup'
			WHEN a.REFERENCE_ID LIKE '%PPL%' and a.REFERENCE_ID not like '%AUT%'  THEN 'Paypal'
			WHEN a.REFERENCE_ID LIKE '%SIM%' THEN 'Credit/ Debit Card' 
			WHEN a.REFERENCE_ID LIKE '%VRN%' THEN 'LLOM'
			WHEN (a.REFERENCE_ID LIKE '%BUN%' AND a.REFERENCE_ID NOT LIKE '%SIM%') THEN 'Credit/ Debit Card' 
			WHEN a.REFERENCE_ID LIKE '%AUT%' and a.REFERENCE_ID like '%RX%' THEN 'Credit/ Debit Card' 
			WHEN a.REFERENCE_ID LIKE '%AUT%' and a.REFERENCE_ID like '%PPL%' THEN 'Paypal' 
			WHEN a.REFERENCE_ID LIKE '%PP%' THEN 'Credit/ Debit Card' ELSE  'Credit/ Debit Card' END  END AS PAYMENT_MODE,	 	 
	a.REFERENCE_ID,a.TOTALAMOUNT,a.CURRENCY,a.CREATED_DATE as payment_date,a.email,a.IPpaymentagent,a.ReplyMessage,a.CC_NO 
	from TPAYMENT a
	where (search_type=1 
	and (a.ACCOUNT_ID=searchinfo and (a.CREATED_DATE>=first_update or first_update is null)) or (a.REFERENCE_ID=sim_order_id and ifnull(sim_order_id,'')<>''))	or(search_type=2 and a.REFERENCE_ID=searchinfo) 
	and (date_from is null or a.CREATED_DATE>=date_from) 
	and (date_to is null or a.CREATED_DATE<=date_to);
	
	insert into temp_payment_number_info(ACCOUNT_ID,PAYMENT_MODE,REFERENCE_ID,TOTALAMOUNT,CURRENCY,payment_date)
	select a.mobileno,'Credit/ Debit Card',a.sorderid,a.amount,a.currency,a.reg_date 
	from webPayment.tCybS_RegisteredPayment a
	where (search_type=1 and (a.mobileno=searchinfo and (a.reg_date>=first_update or first_update is null))) or (search_type=2 and a.sorderid=searchinfo) 
	and (date_from is null or a.reg_date>=date_from) 
	and (date_to is null or a.reg_date<=date_to); 
	

	select * from temp_payment_number_info;
	
	drop temporary table if exists temp_payment_number_info ;
		
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `csPaymentAddDescription` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `csPaymentAddDescription`(
   reference_id varchar(32),
   description varchar(2048),
   out errcode int,
   out errmessage varchar(256) 
   )
begin
 
 declare default_int_val int;
 
 	DECLARE EXIT HANDLER FOR SQLEXCEPTION 
 		BEGIN
 			select -1 as errcode, 'Failed adding payment description' as errmessage;
 			ROLLBACK;
 		END;
 	COMMIT;
     
     set default_int_val = 0 ;
 
 	START TRANSACTION;
 		insert into TPAYMENT_DESCRIPTION (REFERENCE_ID, `DESCRIPTION`) values (reference_id,description);
 
 	if row_count() <> 0 then
 	commit ;
 	  select default_int_val as errcode, 'Payment description added' as errmessage;
 	end if;
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `csPaymentInsert_v3` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `csPaymentInsert_v3`(
  sitecode VARCHAR(5)
 , applicationcode VARCHAR(12) 
 , productcode VARCHAR(20)
 , paymentagent VARCHAR(12)
 , servicetype VARCHAR(4)
 , paymentmode VARCHAR(3)
 , paymentstep INT
 , paymentstatus INT
 , accountid VARCHAR(32)
 , last6digitccno VARCHAR(6)
 , totalamount FLOAT
 , currency VARCHAR(3)
 , subscriptionid VARCHAR(40)
 , merchantid VARCHAR(10)
 , providercode VARCHAR(5)
 , csreasoncode VARCHAR(30)
 , generalerrorcode INT
 , OUT returnerror INT 
 , sendToProduction VARCHAR(5) 
 , email VARCHAR(100)
 , IPpaymentagent VARCHAR(20)
 , IPClient VARCHAR(20))
SWL_return:
 BEGIN
 
    DECLARE v_currenttime DATETIME(3);
    DECLARE v_orderno INT;
    DECLARE v_errorreturn INT;
    DECLARE v_ref_id VARCHAR(32);
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
    BEGIN
       SET @SWV_Error = 1;
    END;
    SET @SWV_Error = 0;
    set returnerror = 0;
 
    START TRANSACTION;
 
    set v_currenttime = CURRENT_TIMESTAMP;
    if (generalerrorcode = 0) then
 
       call  payment_check_mysql(accountid,generalerrorcode);
     
    end if;
 
    if (generalerrorcode = -12) then
 
       set csreasoncode = 12;
       set paymentstatus = -1;
       set returnerror = -12;
    end if;
 
    call payment_getCounterRefID_MYSQL(sitecode,'CS',v_orderno);
 
    if (applicationcode is not null) then
       set v_ref_id = CONCAT_WS('',applicationcode,'-',productcode,'-',cast(v_orderno as CHAR(10)));
    else
       set v_ref_id = CONCAT_WS('',sitecode,'-',productcode,'-',cast(v_orderno as CHAR(10)));
    end if;

    SET @SWV_Error = 0;
    INSERT INTO TPAYMENT(REFERENCE_ID
 , SITECODE
 , PAYMENT_AGENT
 , SERVICE_TYPE
 , PRODUCT_CODE
 , PAYMENT_MODE
 , ACCOUNT_ID
 , CC_NO
 , TOTALAMOUNT
 , CURRENCY
 , CREATED_DATE
 , SUBSCRIPTIONID
 , CURRENT_STATUS
 , LAST_STEP
 , MERCHANT_ID
 , PROVIDER_CODE
 , LAST_GENERAL_ERROR_CODE
 , sendToProduction
 , email
 , IPpaymentagent
 , IPClient)
 VALUES(v_ref_id
 , sitecode
 , paymentagent
 , servicetype
 , productcode
 , paymentmode
 , accountid
 , last6digitccno
 , totalamount
 , currency
 , v_currenttime
 , subscriptionid
 , paymentstatus
 , paymentstep
 , merchantid
 , providercode
 , generalerrorcode
 , sendToProduction
 , email
 , IPpaymentagent
 , IPClient);
 
 
    if @SWV_Error <> 0 then
 
 
       ROLLBACK to savepoint Payment;
       select '0';
     
       LEAVE SWL_return;
    end if;
 
    SET @SWV_Error = 0;
    INSERT INTO TCS_PAYMENT_DETAIL(REFERENCE_ID
 , LAST_CS_ERROR_CODE)
 VALUES(v_ref_id
 , csreasoncode);
 
 
    if @SWV_Error <> 0 then
 
 
       ROLLBACK to savepoint Payment;
       select '0';
 
       LEAVE SWL_return;
    end if;
 
    SET @SWV_Error = 0;
    INSERT INTO TCS_TRANSACTION(REFERENCE_ID
 , CS_ERROR_CODE
 , EXECUTION_DATE
 , PAYMENT_STEP
 , PAYMENT_STATUS
 , GENERAL_ERROR_CODE)
 VALUES(v_ref_id
 , csreasoncode
 , v_currenttime
 , paymentstep
 , paymentstatus
 , generalerrorcode);
 
 
    if @SWV_Error <> 0 then
 
 
       ROLLBACK to savepoint Payment;
       select '0';
 
       LEAVE SWL_return;
    end if;
 
 
    COMMIT;
    select v_ref_id;
    LEAVE SWL_return;
 
 
    ROLLBACK to savepoint Payment;
    select '0';
 
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `csPaymentInsert_v3_ecom_v2` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `csPaymentInsert_v3_ecom_v2`(
 	sitecode VARCHAR(5),
 	applicationcode VARCHAR(12), 
 	productcode VARCHAR(20),
 	paymentagent VARCHAR(12),
 	servicetype VARCHAR(4),
 	paymentmode VARCHAR(3),
 	paymentstep INT,
 	paymentstatus INT,
 	accountid VARCHAR(32),
 	last6digitccno VARCHAR(6),
 	totalamount FLOAT,
 	currency VARCHAR(3),
 	subscriptionid VARCHAR(40),
 	merchantid VARCHAR(10),
 	providercode VARCHAR(5),
 	csreasoncode VARCHAR(30),
 	generalerrorcode INT,
 	OUT returnerror INT,
 	sendToProduction VARCHAR(5),
 	email VARCHAR(100),
 	IPpaymentagent VARCHAR(100),
 	IPClient VARCHAR(20),
 	ReplyMessage VARCHAR(512),
 	ThreeDFlag CHAR(1),
 	device_type VARCHAR(50),
 	browser VARCHAR(100),
 	os_version VARCHAR(100),
 	topup_url VARCHAR(500),
 	bundle_id INT,
 	expirydate VARCHAR(10),
 	cardtype VARCHAR(20)
 )
SWL_return:begin	
 
 	DECLARE v_currenttime DATETIME(3);
 	DECLARE v_orderno INT;
 	DECLARE v_errorreturn INT;
 	DECLARE v_ref_id VARCHAR(32);
     
     DECLARE EXIT HANDLER FOR SQLEXCEPTION
 	BEGIN
 		SET @SWV_Error = 1;
         select -1 as errcode,'' AS ref_id;
 		Rollback;
 	END;
 
 	
 
 
 
 	IF ThreeDFlag is null then  set ThreeDFlag = '0'; END IF;
 	IF device_type is null then set device_type = ''; END IF;
 	IF browser is null then set browser = ''; END IF;
 	IF os_version is null then set os_version = ''; END IF;
 	IF topup_url is null then set topup_url = ''; END IF;
 	IF bundle_id is null then set bundle_id = 0; END IF;
 	IF expirydate is null then set expirydate = ''; END IF;
 	IF cardtype is null then set cardtype = ''; END IF;
    
 	SET @SWV_Error = 0;
 	set returnerror = 0;
 
 	START TRANSACTION;
 
 		set v_currenttime = CURRENT_TIMESTAMP;
 
 		if (generalerrorcode = -12) then
 			set csreasoncode = 12;
 			set paymentstatus = -1;
 			set returnerror = -12;
 		end if;
 
 		CALL payment_getCounterRefID_v3(sitecode,'CS',v_orderno);
 
 		if (applicationcode is not null) then
 			set v_ref_id = CONCAT(applicationcode,'-',productcode,'-EP','-',cast(v_orderno as CHAR(10)));
 		else
 			set v_ref_id = CONCAT(sitecode,'-',productcode,'-EP','-',cast(v_orderno as CHAR(30)));
 		end if; 
 
 		SET @SWV_Error = 0;
           
 		INSERT INTO TPAYMENT(REFERENCE_ID,SITECODE,PAYMENT_AGENT,SERVICE_TYPE,PRODUCT_CODE,PAYMENT_MODE,ACCOUNT_ID,CC_NO,TOTALAMOUNT,CURRENCY,CREATED_DATE,SUBSCRIPTIONID,
 		CURRENT_STATUS,LAST_STEP,MERCHANT_ID,PROVIDER_CODE,LAST_GENERAL_ERROR_CODE,sendToProduction,email,IPpaymentagent,IPClient,ReplyMessage,ThreeDFlag,device_type,
 		browser,os_version,topup_url,bundle_id,expirydate,cardtype)
 		VALUES(v_ref_id,sitecode,paymentagent,servicetype,productcode,paymentmode,accountid,last6digitccno,totalamount,currency,left(v_currenttime,19),subscriptionid,
 		paymentstatus,paymentstep,merchantid,providercode,generalerrorcode,sendToProduction,email,IPpaymentagent,IPClient,ReplyMessage,ThreeDFlag,device_type,
 		browser,os_version,topup_url,bundle_id,expirydate,cardtype);
 
 		if @SWV_Error <> 0 then
 
 			ROLLBACK to savepoint Payment;			
 			select -1 as errcode,'' AS ref_id;
 			LEAVE SWL_return;
 		end if;
 
 		SET @SWV_Error = 0;
 
 		INSERT INTO TCS_PAYMENT_DETAIL(REFERENCE_ID, LAST_CS_ERROR_CODE)
 		VALUES(v_ref_id, csreasoncode);
 
 
 		if @SWV_Error <> 0 then
 
 			ROLLBACK to savepoint Payment;
 			select -1 as errcode,'' AS ref_id;
 			LEAVE SWL_return;
 		end if;
 
 		SET @SWV_Error = 0;
 
 		INSERT INTO TCS_TRANSACTION(REFERENCE_ID,CS_ERROR_CODE,EXECUTION_DATE,PAYMENT_STEP,PAYMENT_STATUS,GENERAL_ERROR_CODE,ReplyMessage)
 		VALUES(v_ref_id,csreasoncode,v_currenttime,paymentstep,paymentstatus,generalerrorcode,ReplyMessage);
 
 
 		if @SWV_Error <> 0 then
 
 			ROLLBACK to savepoint Payment;
 			select -1 as errcode,'' AS ref_id;
 			LEAVE SWL_return;
 		end if;
 
 
 		COMMIT;
 
 		select v_ref_id as ref_id,0 as errcode;
 
 		LEAVE SWL_return;
 
 ROLLBACK to savepoint Payment;
 	select -1 as errcode,'' AS ref_id;
 	LEAVE SWL_return;
 
 END SWL_return ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `csPaymentInsert_v3_ecom_v2_test` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `csPaymentInsert_v3_ecom_v2_test`(
    sitecode VARCHAR(5)        
  , applicationcode VARCHAR(12)         
  , productcode VARCHAR(20)        
  , paymentagent VARCHAR(12)        
  , servicetype VARCHAR(4)        
  , paymentmode VARCHAR(3)        
  , paymentstep INT        
  , paymentstatus INT        
  , accountid VARCHAR(32)        
  , last6digitccno VARCHAR(6)        
  , totalamount FLOAT        
  , currency VARCHAR(3)        
  , subscriptionid VARCHAR(40)        
  , merchantid VARCHAR(10)        
  , providercode VARCHAR(5)        
  , csreasoncode VARCHAR(30)        
  , generalerrorcode INT        
  , OUT returnerror INT         
  , sendToProduction VARCHAR(5)         
  , email VARCHAR(100)        
  , IPpaymentagent VARCHAR(20)        
  , IPClient VARCHAR(20)      
  , ReplyMessage VARCHAR(512)    
  , ThreeDFlag CHAR(1) ,  
    device_type VARCHAR(50),  
    browser VARCHAR(100),  
    os_version VARCHAR(100),  
    topup_url VARCHAR(500),  
    bundle_id INT,  
    expirydate VARCHAR(10),  
    cardtype VARCHAR(20))
SWL_return:begin	
          
     DECLARE v_currenttime DATETIME(3);        
     DECLARE v_orderno INT;        
     DECLARE v_errorreturn INT;
     DECLARE v_ref_id VARCHAR(32);
          
     
     IF ThreeDFlag is null 
     then
        set ThreeDFlag = '0';
     END IF;
     
     IF device_type is null 
     then
        set device_type = '';
     END IF;
     
     IF browser is null 
     then
        set browser = '';
     END IF;
     
     IF os_version is null 
     then
        set os_version = '';
     END IF;
     
     IF topup_url is null 
     then
        set topup_url = '';
     END IF;
     
     IF bundle_id is null 
     then
        set bundle_id = 0;
     END IF;
     
     IF expirydate is null 
     then
        set expirydate = '';
     END IF;
     
     IF cardtype is null 
     then
        set cardtype = '';
     END IF;
     

     set returnerror = 0;        
          
     START TRANSACTION;        
          
     set v_currenttime = CURRENT_TIMESTAMP;        
  
  
  
  
          
     if (generalerrorcode = -12) 
     then
  
        set csreasoncode = 12;
        set paymentstatus = -1;
        set returnerror = -12;
        
     end if;        
          
     CALL payment_getCounterRefID_v3(sitecode,'CS',v_orderno);       
          
     if (applicationcode is not null) 
     then
        set v_ref_id = CONCAT(applicationcode,'-',productcode,'-EP','-',cast(v_orderno as CHAR(10)));
     else
        set v_ref_id = CONCAT(sitecode,'-',productcode,'-EP','-',cast(v_orderno as CHAR(10)));
     end if;         
        
     
  INSERT INTO TPAYMENT(REFERENCE_ID
  , SITECODE
  , PAYMENT_AGENT
  , SERVICE_TYPE
  , PRODUCT_CODE
  , PAYMENT_MODE
  , ACCOUNT_ID
  , CC_NO
  , TOTALAMOUNT
  , CURRENCY
  , CREATED_DATE
  , SUBSCRIPTIONID
  , CURRENT_STATUS
  , LAST_STEP
  , MERCHANT_ID
  , PROVIDER_CODE
  , LAST_GENERAL_ERROR_CODE
  , sendToProduction
  , email
  , IPpaymentagent
  , IPClient
  , ReplyMessage
  , ThreeDFlag
  ,device_type
  ,browser
  ,os_version
  ,topup_url
  ,bundle_id,
  expirydate,
  cardtype)
  VALUES(v_ref_id                 
  , sitecode
  , paymentagent
  , servicetype
  , productcode
  , paymentmode
  , accountid
  , last6digitccno
  , totalamount
  , currency
  , v_currenttime        
  , subscriptionid
  , paymentstatus
  , paymentstep
  , merchantid
  , providercode
  , generalerrorcode
  , sendToProduction
  , email
  , IPpaymentagent
  , IPClient
  , ReplyMessage
  , ThreeDFlag
  ,device_type
  ,browser
  ,os_version
  ,topup_url
  ,bundle_id
  ,expirydate
  ,cardtype);        
          
  
  if @@error_count<> 0 
  then
   
        
        select -1 as errcode,'' AS ref_id;
        LEAVE SWL_return;
   
          
end if;
     
  INSERT INTO TCS_PAYMENT_DETAIL(REFERENCE_ID
  , LAST_CS_ERROR_CODE)
  VALUES(v_ref_id            
  , csreasoncode);        
          
  
     if @@error_count <> 0 
     then
  
   
        select -1 as errcode,'' AS ref_id;
        LEAVE SWL_return;

     end if;        
          

     INSERT INTO TCS_TRANSACTION(REFERENCE_ID
  , CS_ERROR_CODE
  , EXECUTION_DATE
  , PAYMENT_STEP
  , PAYMENT_STATUS
  , GENERAL_ERROR_CODE
  , ReplyMessage)
  VALUES(v_ref_id             
  , csreasoncode
  , v_currenttime           
  , paymentstep
  , paymentstatus
  , generalerrorcode
  , ReplyMessage);        
          
  
  if @@error_count <> 0 
  then
   
     
        select -1 as errcode,'' AS ref_id;
        LEAVE SWL_return;

     end if;        
          
  
  COMMIT;        
    
  select v_ref_id as ref_id,0 as errcode;    
  
  LEAVE SWL_return;        
          
     ROLLBACK to savepoint Payment;        
    
     select -1 as errcode,'' AS ref_id;  
     
     LEAVE SWL_return;  
     
  END SWL_return ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `csPaymentInsert_v3_Rx` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `csPaymentInsert_v3_Rx`(
sitecode VARCHAR(5)
,applicationcode VARCHAR(12) 
,productcode VARCHAR(20)
,paymentagent VARCHAR(12)
,servicetype VARCHAR(4)
,paymentmode VARCHAR(3)
,paymentstep INT
,paymentstatus INT
,accountid VARCHAR(32)
,last6digitccno VARCHAR(6)
,totalamount FLOAT
,currency VARCHAR(3)
,subscriptionid VARCHAR(40)
,merchantid VARCHAR(10)
,providercode VARCHAR(5)
,csreasoncode VARCHAR(30)
,generalerrorcode INT
,OUT returnerror INT 
,sendToProduction VARCHAR(5) 
,email VARCHAR(100)
,IPpaymentagent VARCHAR(20)
,IPClient VARCHAR(20)    
,ReplyMessage VARCHAR(512)  
,ThreeDFlag CHAR(1) 
,device_type VARCHAR(50)
,browser VARCHAR(100)
,os_version VARCHAR(100)
,topup_url VARCHAR(500)
,bundle_id INT
,expirydate VARCHAR(10)
,cardtype VARCHAR(20),
OUT SWP_Ret_Value INT
)
SWL_return:
BEGIN


	

   DECLARE currenttime DATETIME(3);
   DECLARE orderno INT;
   DECLARE errorreturn INT;
   DECLARE ref_id VARCHAR(32);
    
	DECLARE v_ref_code INT;  
	DECLARE v_day_trax FLOAT;  
	DECLARE v_week_trax FLOAT;  
	DECLARE v_month_trax FLOAT; 
	DECLARE v_counter BIGINT;

 

   DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
   BEGIN
      SET @SWError = 1;
   END;

   IF ThreeDFlag is null then set ThreeDFlag = '0'; END IF;
   IF device_type is null then set device_type = ''; END IF;
   IF browser is null then set browser = ''; END IF;
   IF os_version is null then set os_version = ''; END IF;
   IF topup_url is null then set topup_url = ''; END IF;
   IF bundle_id is null then set bundle_id = 0; END IF;
   IF expirydate is null then set expirydate = ''; END IF;
   IF cardtype is null then set cardtype = ''; END IF;

   SET @SWError = 0;
   set returnerror = 0; 
   	 SET v_ref_code = -1;  
     SET v_day_trax = 0.0;  
     SET v_week_trax = 0.0;  
     SET v_month_trax = 0.0;

   START TRANSACTION;

   set currenttime = CURRENT_TIMESTAMP; 
	
	if (generalerrorcode = 0) then
		
		
		
		 select IFNULL(sum(a.TOTALAMOUNT),0) INTO v_day_trax from TPAYMENT a where a.ACCOUNT_ID = account_id and a.CURRENT_STATUS in(3,4) and TIMESTAMPDIFF(day,a.CREATED_DATE,CURRENT_TIMESTAMP) = 0;
		 select IFNULL(sum(b.TOTALAMOUNT),0) INTO v_week_trax from TPAYMENT  b where b.ACCOUNT_ID = account_id and b.CURRENT_STATUS in(3,4) and TIMESTAMPDIFF(day,b.CREATED_DATE,CURRENT_TIMESTAMP) = 7;
		 select IFNULL(sum(c.TOTALAMOUNT),0) INTO v_month_trax from TPAYMENT c where c.ACCOUNT_ID = account_id and c.CURRENT_STATUS in(3,4) and TIMESTAMPDIFF(day,c.CREATED_DATE,CURRENT_TIMESTAMP) = 30;

		 if v_day_trax < 50.0 and v_week_trax < 100.0 and v_month_trax < 150.0 then
			  
			SET generalerrorcode = 1;
		 else
			SET generalerrorcode = -12;
		 end if;
		
	end if;

	if (generalerrorcode = -12) then
		set csreasoncode = 12;
		set paymentstatus = -1;
		set returnerror = -12;
	end if;


   SWL_out : Begin

   
		
	   if not exists(select 1 from tcounter_refid a where a.sitecode = sitecode LIMIT 1) then
		   SET orderno = -1; 
		   LEAVE SWL_out;
		end if; 

		select a.counter+1 INTO v_counter from tcounter_refid a where a.sitecode = sitecode and a.provider_code = provider_code;

		update tcounter_refid b
		set b.counter = v_counter
		where b.sitecode = sitecode
		and b.provider_code = provider_code;

		set orderno = v_counter;
		
   End SWL_out;


   if (applicationcode is not null) then
      set ref_id = CONCAT(applicationcode,'-',productcode,'-RX','-',cast(orderno as CHAR(10)));
   else
      set ref_id = CONCAT(sitecode,'-',productcode,'-RX','-',cast(orderno as CHAR(10)));
   end if; 

   SET @SWError = 0;

   INSERT INTO TPAYMENT(REFERENCE_ID,SITECODE,PAYMENT_AGENT,SERVICE_TYPE,PRODUCT_CODE,PAYMENT_MODE,ACCOUNT_ID,CC_NO,TOTALAMOUNT,
	CURRENCY,CREATED_DATE,SUBSCRIPTIONID,CURRENT_STATUS,LAST_STEP,MERCHANT_ID,PROVIDER_CODE,LAST_GENERAL_ERROR_CODE,sendToProduction,
	email ,IPpaymentagent ,IPClient ,ReplyMessage ,ThreeDFlag,device_type,browser,os_version,topup_url,bundle_id,expirydate,cardtype)
	VALUES(ref_id,sitecode,paymentagent,servicetype,productcode,paymentmode,accountid,last6digitccno,totalamount,
	currency,currenttime,subscriptionid,	paymentstatus,paymentstep,merchantid,providercode,generalerrorcode,sendToProduction,
	email ,IPpaymentagent ,IPClient,ReplyMessage,ThreeDFlag,device_type,browser,os_version,topup_url,bundle_id,expirydate,cardtype);

	
   if @SWError <> 0 then
	
		
      ROLLBACK to savepoint Payment;
      select '0';
      SET SWP_Ret_Value = 0;
      LEAVE SWL_return;
   end if;

   SET @SWError = 0;
   INSERT INTO TCS_PAYMENT_DETAIL(REFERENCE_ID, LAST_CS_ERROR_CODE)
	VALUES(ref_id, csreasoncode);

	
   if @SWError <> 0 then
	
		
      ROLLBACK to savepoint Payment;
      select '0';
      SET SWP_Ret_Value = 0;
      LEAVE SWL_return;
   end if;

   SET @SWError = 0;
   INSERT INTO TCS_TRANSACTION(REFERENCE_ID,CS_ERROR_CODE,EXECUTION_DATE,PAYMENT_STEP,PAYMENT_STATUS,GENERAL_ERROR_CODE,ReplyMessage)
	VALUES(ref_id,csreasoncode,currenttime,paymentstep,paymentstatus,generalerrorcode,ReplyMessage);

	
   if @SWError <> 0 then
	
		
      ROLLBACK to savepoint Payment;
      select '0';
      SET SWP_Ret_Value = 0;
      LEAVE SWL_return;
   end if;


   COMMIT;
   select ref_id;     
   LEAVE SWL_return;


   ROLLBACK to savepoint Payment;
   select '0';
   SET SWP_Ret_Value = 0;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Cspaymentinsert_v3_safecard` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `Cspaymentinsert_v3_safecard`(
                                        sitecode         VARCHAR(5), 
                                        applicationcode  VARCHAR(12) , 
                                        productcode      VARCHAR(20), 
                                        paymentagent     VARCHAR(12), 
                                        servicetype      VARCHAR(4), 
                                        paymentmode      VARCHAR(3), 
                                        paymentstep      INT, 
                                        paymentstatus    INT, 
                                        accountid        VARCHAR(32) , 
                                        totalamount      FLOAT, 
                                        currency         VARCHAR(3) , 
                                        merchantid       VARCHAR(10), 
                                        providercode     VARCHAR(5), 
                                        csreasoncode     VARCHAR(30), 
                                        generalerrorcode INT, 
                                        OUT returnerror      INT , 
                                        sendToProduction VARCHAR(5) , 
                                        email            VARCHAR(100), 
                                        IPpaymentagent   VARCHAR(20), 
                                        IPClient         VARCHAR(20)
                                        )
SWL_return:
BEGIN

   DECLARE v_currenttime DATETIME(3); 
   DECLARE v_orderno INT; 
   DECLARE v_errorreturn INT; 
   DECLARE v_Current_Balance FLOAT;
   DECLARE v_ref_id VARCHAR(32); 

   DECLARE v_Index INT; 
   DECLARE v_Index2 INT;
   DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
   BEGIN
      SET @SWV_Error = 1;
   END;

   SET @SWV_Error = 0;
   SET returnerror = 0; 

   START TRANSACTION; 

   SET v_currenttime = CURRENT_TIMESTAMP; 

   IF (generalerrorcode = 0) then
         
            
      CALL Payment_check_paysafe(accountid,generalerrorcode);
   end if; 

   IF (generalerrorcode = -12) then
        
      SET csreasoncode = 12;
      SET paymentstatus = -1;
      SET returnerror = -12;
   end if; 

   CALL Payment_getcounterrefid_safecard(sitecode,v_orderno); 

   SET v_Index = LOCATE('-',productcode); 

   IF v_Index > 1 AND IFNULL(productcode,'') NOT LIKE '%BUN%' then
        
      SET productcode = substring(productcode,1, CHAR_LENGTH(productcode) -1);
   end if; 

      
   IF applicationcode IS NOT NULL then
      SET v_ref_id = CONCAT_WS('',applicationcode,productcode,Cast(v_orderno AS CHAR(10)));
   end if;
                      
   
IF IFNULL(productcode,'')  LIKE '%BUN%' then
       
      SET v_ref_id = CONCAT_WS('',applicationcode,'-',productcode,'-',cast(totalamount as CHAR(30)),
      '-',Cast(v_orderno AS CHAR(10)));
   end if;
                 

   IF IFNULL(productcode,'') NOT LIKE '%BUN%' then
		

		  
      IF (applicationcode IS NOT NULL
      AND paymentagent NOT LIKE '%CTP%') then
         SET v_ref_id = CONCAT_WS('',applicationcode,'-','WEB0',CASE WHEN  CHAR_LENGTH(totalamount) = 1
         THEN CONCAT('0',Cast(totalamount AS
            CHAR(30)))
         ELSE Cast(totalamount
            AS CHAR(30)) END,'-PSC-',RIGHT(Rand(),4),
         Cast(v_orderno AS CHAR(10))); 
		  
      ELSE 
         IF (applicationcode IS NOT NULL
         AND paymentagent LIKE '%UK%') then 
			
            SET v_ref_id = CONCAT_WS('',sitecode,'PSC',RIGHT(Rand(),4),Cast(v_orderno AS CHAR(10)));
         end if;
      end if;
   end if;
	                      
   SET v_Current_Balance = 0;
                      


   SET @SWV_Error = 0;
   INSERT INTO TPAYMENT(reference_id,
                   sitecode,
                   payment_agent,
                   service_type,
                   product_code,
                   payment_mode,
                   account_id,
                   cc_no,
                   totalamount,
                   currency,
                   created_date,
                   subscriptionid,
                   current_status,
                   last_step,
                   merchant_id,
                   provider_code,
                   last_general_error_code,
                   sendtoproduction,
                   email,
                   ippaymentagent,
                   ipclient,
				   ReplyMessage)
      VALUES(v_ref_id,
                   sitecode,
                   paymentagent,
                   servicetype,
                   productcode,
                   paymentmode,
                   accountid,
                   'PSPS',
                   totalamount,
                   currency,
                   v_currenttime,
                   NULL,
                   paymentstatus,
                   paymentstep,
                   merchantid,
                   providercode,
                   generalerrorcode,
                   sendToProduction,
                   email,
                   IPpaymentagent,
                   IPClient,
				   'Transaction Succeeded'); 

      
   IF @SWV_Error <> 0 then
        
            
      ROLLBACK to savepoint payment;
      SELECT '0';
      LEAVE SWL_return;
   end if; 

   SET @SWV_Error = 0;
   INSERT INTO   TCS_PAYMENT_DETAIL(reference_id,
                   last_cs_error_code)
      VALUES(v_ref_id,
                   csreasoncode); 

      
   IF @SWV_Error <> 0 then
        
            
      ROLLBACK to savepoint payment;
      SELECT '0';
      LEAVE SWL_return;
   end if; 

   SET @SWV_Error = 0;
   INSERT INTO TCS_TRANSACTION(reference_id,
                   cs_error_code,
                   execution_date,
                   payment_step,
                   payment_status,
                   general_error_code,
				   ReplyMessage)
      VALUES(v_ref_id,
                   csreasoncode,
                   v_currenttime,
                   paymentstep,
                   paymentstatus,
                   generalerrorcode,
				   'Transaction Succeeded'); 
                   
                   

      
   IF @SWV_Error <> 0 then
        
            
      ROLLBACK to savepoint payment;
      SELECT '0';
      LEAVE SWL_return;
   end if; 
        
   SET @SWV_Error = 0;
   Insert into TPayment_Balance_Master(BM_Date ,
		BM_REFERENCE_ID	,
		ACCOUNT_ID ,
		Current_Balance)
		Values(v_currenttime,v_ref_id,accountid,v_Current_Balance);
     
   IF @SWV_Error <> 0 then
        
            
      ROLLBACK to savepoint payment;
      SELECT '0';
      LEAVE SWL_return;
   end if; 
        

      
   COMMIT; 

   SELECT v_ref_id           ref_id,
             v_orderno          orderno,
             generalerrorcode generalerrorcode; 

   LEAVE SWL_return; 

      
   ROLLBACK to savepoint payment; 

   SELECT '0'; 


END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `csPaymentInsert_v4_Rx` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `csPaymentInsert_v4_Rx`(
  sitecode VARCHAR(5)      
 , applicationcode VARCHAR(12)       
 , productcode VARCHAR(20)      
 , paymentagent VARCHAR(12)      
 , servicetype VARCHAR(4)      
 , paymentmode VARCHAR(3)      
 , paymentstep INT      
 , paymentstatus INT      
 , accountid VARCHAR(32)      
 , last6digitccno VARCHAR(6)      
 , totalamount FLOAT      
 , currency VARCHAR(3)      
 , subscriptionid VARCHAR(40)      
 , merchantid VARCHAR(10)      
 , providercode VARCHAR(5)      
 , csreasoncode VARCHAR(30)      
 , generalerrorcode INT      
 , INOUT returnerror INT       
 , sendToProduction VARCHAR(5)       
 , email VARCHAR(100)      
 , IPpaymentagent VARCHAR(20)      
 , IPClient VARCHAR(20)    
 , ReplyMessage VARCHAR(512)  
 , ThreeDFlag CHAR(1) ,
 device_type VARCHAR(50),
 browser VARCHAR(100),
 os_version VARCHAR(100),
 topup_url VARCHAR(500),
 bundle_id INT,
 expirydate VARCHAR(10),
 cardtype VARCHAR(20))
SWL_return:
 BEGIN
 
       
    DECLARE v_currenttime DATETIME(3);      
    DECLARE v_orderno INT;      
    DECLARE v_errorreturn INT;      
    DECLARE v_ref_id VARCHAR(32);
  
    IF ThreeDFlag is null then
       set ThreeDFlag = '0';
    END IF;
    IF device_type is null then
       set device_type = '';
    END IF;
    IF browser is null then
       set browser = '';
    END IF;
    IF os_version is null then
       set os_version = '';
    END IF;
    IF topup_url is null then
       set topup_url = '';
    END IF;
    IF bundle_id is null then
       set bundle_id = 0;
    END IF;
    IF expirydate is null then
       set expirydate = '';
    END IF;
    IF cardtype is null then
       set cardtype = '';
    END IF;

    set returnerror = 0;      
       
    set last6digitccno = RIGHT(last6digitccno,4);     
       
    START TRANSACTION;      
       
    set v_currenttime = CURRENT_TIMESTAMP;      
    if (generalerrorcode = 0) then
 
      call  payment_check_mysql(accountid,generalerrorcode);
    end if;      
       
    if (generalerrorcode = -12) then
 
       set csreasoncode = 12;
       set paymentstatus = -1;
       set returnerror = -12;
    end if;      
       
    call payment_getCounterRefID_MYSQL(sitecode,'CS',v_orderno);    
       
    if (applicationcode is not null) then
       set v_ref_id = CONCAT_WS('',applicationcode,'-',productcode,'-RX','-',cast(v_orderno as CHAR(10)));
    else
       set v_ref_id = CONCAT_WS('',sitecode,'-',productcode,'-RX','-',cast(v_orderno as CHAR(10)));
    end if;       
       

    INSERT INTO TPAYMENT(REFERENCE_ID
 , SITECODE
 , PAYMENT_AGENT
 , SERVICE_TYPE
 , PRODUCT_CODE
 , PAYMENT_MODE
 , ACCOUNT_ID
 , CC_NO
 , TOTALAMOUNT
 , CURRENCY
 , CREATED_DATE
 , SUBSCRIPTIONID
 , CURRENT_STATUS
 , LAST_STEP
 , MERCHANT_ID
 , PROVIDER_CODE
 , LAST_GENERAL_ERROR_CODE
 , sendToProduction
 , email
 , IPpaymentagent
 , IPClient
 , ReplyMessage
 , ThreeDFlag
 ,device_type
 ,browser
 ,os_version
 ,topup_url
 ,bundle_id,
 expirydate,
 cardtype)
 VALUES(v_ref_id
 , sitecode
 , paymentagent
 , servicetype
 , productcode
 , paymentmode
 , accountid
 , last6digitccno
 , totalamount
 , currency
 , v_currenttime
 , subscriptionid
 , paymentstatus
 , paymentstep
 , merchantid
 , providercode
 , generalerrorcode
 , sendToProduction
 , email
 , IPpaymentagent
 , IPClient
 , ReplyMessage
 , ThreeDFlag
 ,device_type
 ,browser
 ,os_version
 ,topup_url
 ,bundle_id
 ,expirydate
 ,cardtype);      
       
 
    if @@error_count <> 0 then
 
 
       ROLLBACK to savepoint Payment;
   
       LEAVE SWL_return;
    end if;      
       

    INSERT INTO TCS_PAYMENT_DETAIL(REFERENCE_ID
 , LAST_CS_ERROR_CODE)
 VALUES(v_ref_id
 , csreasoncode);      
       
 
    if  @@error_count <> 0 then
 
 
       ROLLBACK to savepoint Payment;
       select '0';
       LEAVE SWL_return;
    end if;      

    INSERT INTO TCS_TRANSACTION(REFERENCE_ID
 , CS_ERROR_CODE
 , EXECUTION_DATE
 , PAYMENT_STEP
 , PAYMENT_STATUS
 , GENERAL_ERROR_CODE
 , ReplyMessage)
 VALUES(v_ref_id
 , csreasoncode
 , v_currenttime
 , paymentstep
 , paymentstatus
 , generalerrorcode
 , ReplyMessage);      
       
 
    if  @@error_count <> 0 then
 
 
       ROLLBACK to savepoint Payment;

       LEAVE SWL_return;
    end if;      
       
 
    COMMIT;      
    select v_ref_id;     
    LEAVE SWL_return;      
       

    ROLLBACK to savepoint Payment;      
    select '0';      
 
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `csPaymentInsert_v4_Rx_mysql` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `csPaymentInsert_v4_Rx_mysql`(
  sitecode VARCHAR(5)      
 , applicationcode VARCHAR(12)       
 , productcode VARCHAR(20)      
 , paymentagent VARCHAR(12)      
 , servicetype VARCHAR(4)      
 , paymentmode VARCHAR(3)      
 , paymentstep INT      
 , paymentstatus INT      
 , accountid VARCHAR(32)      
 , last6digitccno VARCHAR(6)      
 , totalamount FLOAT      
 , currency VARCHAR(3)      
 , subscriptionid VARCHAR(40)      
 , merchantid VARCHAR(10)      
 , providercode VARCHAR(5)      
 , csreasoncode VARCHAR(30)      
 , generalerrorcode INT      
 , INOUT returnerror INT       
 , sendToProduction VARCHAR(5)       
 , email VARCHAR(100)      
 , IPpaymentagent VARCHAR(20)      
 , IPClient VARCHAR(20)    
 , ReplyMessage VARCHAR(512)  
 , ThreeDFlag CHAR(1) ,
 device_type VARCHAR(50),
 browser VARCHAR(100),
 os_version VARCHAR(100),
 topup_url VARCHAR(500),
 bundle_id INT,
 expirydate VARCHAR(10),
 cardtype VARCHAR(20))
SWL_return:
 BEGIN
 
       
    DECLARE v_currenttime DATETIME(3);      
    DECLARE v_orderno INT;      
    DECLARE v_errorreturn INT;      
    DECLARE v_ref_id VARCHAR(32);
  
    IF ThreeDFlag is null then
       set ThreeDFlag = '0';
    END IF;
    IF device_type is null then
       set device_type = '';
    END IF;
    IF browser is null then
       set browser = '';
    END IF;
    IF os_version is null then
       set os_version = '';
    END IF;
    IF topup_url is null then
       set topup_url = '';
    END IF;
    IF bundle_id is null then
       set bundle_id = 0;
    END IF;
    IF expirydate is null then
       set expirydate = '';
    END IF;
    IF cardtype is null then
       set cardtype = '';
    END IF;

    set returnerror = 0;      
       
    set last6digitccno = RIGHT(last6digitccno,4);     
       
    START TRANSACTION;      
       
    set v_currenttime = CURRENT_TIMESTAMP;      
    if (generalerrorcode = 0) then
 
      call  payment_check_mysql(accountid,generalerrorcode);
    end if;      
       
    if (generalerrorcode = -12) then
 
       set csreasoncode = 12;
       set paymentstatus = -1;
       set returnerror = -12;
    end if;      
       
    call payment_getCounterRefID_MYSQL(sitecode,'CS',v_orderno);    
       
    if (applicationcode is not null) then
       set v_ref_id = CONCAT_WS('',applicationcode,'-',productcode,'-RX','-',cast(v_orderno as CHAR(10)));
    else
       set v_ref_id = CONCAT_WS('',sitecode,'-',productcode,'-RX','-',cast(v_orderno as CHAR(10)));
    end if;       
       

    INSERT INTO TPAYMENT(REFERENCE_ID
 , SITECODE
 , PAYMENT_AGENT
 , SERVICE_TYPE
 , PRODUCT_CODE
 , PAYMENT_MODE
 , ACCOUNT_ID
 , CC_NO
 , TOTALAMOUNT
 , CURRENCY
 , CREATED_DATE
 , SUBSCRIPTIONID
 , CURRENT_STATUS
 , LAST_STEP
 , MERCHANT_ID
 , PROVIDER_CODE
 , LAST_GENERAL_ERROR_CODE
 , sendToProduction
 , email
 , IPpaymentagent
 , IPClient
 , ReplyMessage
 , ThreeDFlag
 ,device_type
 ,browser
 ,os_version
 ,topup_url
 ,bundle_id,
 expirydate,
 cardtype)
 VALUES(v_ref_id
 , sitecode
 , paymentagent
 , servicetype
 , productcode
 , paymentmode
 , accountid
 , last6digitccno
 , totalamount
 , currency
 , v_currenttime
 , subscriptionid
 , paymentstatus
 , paymentstep
 , merchantid
 , providercode
 , generalerrorcode
 , sendToProduction
 , email
 , IPpaymentagent
 , IPClient
 , ReplyMessage
 , ThreeDFlag
 ,device_type
 ,browser
 ,os_version
 ,topup_url
 ,bundle_id
 ,expirydate
 ,cardtype);      
       
 
    if @@error_count <> 0 then
 
 
       ROLLBACK to savepoint Payment;
   
       LEAVE SWL_return;
    end if;      
       

    INSERT INTO TCS_PAYMENT_DETAIL(REFERENCE_ID
 , LAST_CS_ERROR_CODE)
 VALUES(v_ref_id
 , csreasoncode);      
       
 
    if  @@error_count <> 0 then
 
 
       ROLLBACK to savepoint Payment;
       select '0';
       LEAVE SWL_return;
    end if;      

    INSERT INTO TCS_TRANSACTION(REFERENCE_ID
 , CS_ERROR_CODE
 , EXECUTION_DATE
 , PAYMENT_STEP
 , PAYMENT_STATUS
 , GENERAL_ERROR_CODE
 , ReplyMessage)
 VALUES(v_ref_id
 , csreasoncode
 , v_currenttime
 , paymentstep
 , paymentstatus
 , generalerrorcode
 , ReplyMessage);      
       
 
    if  @@error_count <> 0 then
 
 
       ROLLBACK to savepoint Payment;

       LEAVE SWL_return;
    end if;      
       
 
    COMMIT;      
    select v_ref_id;     
    LEAVE SWL_return;      
       

    ROLLBACK to savepoint Payment;      
    select '0';      
 
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `csPaymentUpdate` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `csPaymentUpdate`(
  referenceid VARCHAR(32)
 , paymentstep INT
 , paymentstatus INT
 , providercode VARCHAR(5)
 , csreasoncode VARCHAR(30)
 , requestid VARCHAR(64)
 , requesttoken VARCHAR(512)
 , generalerrorcode INT
 , ReplyMessage VARCHAR(512))
SWL_return:
BEGIN
  DECLARE v_currenttime DATETIME(3);
 
   IF ReplyMessage is null then
      set ReplyMessage = 'N/A';
   END IF;

   START TRANSACTION;

   set v_currenttime = CURRENT_TIMESTAMP;


   if exists(select  1 from TCS_TRANSACTION a
   where a.REFERENCE_ID = referenceid and a.PAYMENT_STEP = paymentstep LIMIT 1) then

      UPDATE TCS_TRANSACTION b
      SET b.CS_ERROR_CODE = csreasoncode,b.EXECUTION_DATE = v_currenttime,b.PAYMENT_STATUS = paymentstatus, 
      b.REQUEST_ID = requestid,b.REQUEST_TOKEN = requesttoken, 
      b.GENERAL_ERROR_CODE = generalerrorcode,b.ReplyMessage = ReplyMessage
      WHERE
      b.REFERENCE_ID = referenceid and b.PAYMENT_STEP = paymentstep;
   else
 INSERT INTO TCS_TRANSACTION(REFERENCE_ID
, CS_ERROR_CODE
, EXECUTION_DATE
, PAYMENT_STEP
, PAYMENT_STATUS
, GENERAL_ERROR_CODE
, REQUEST_ID
, REQUEST_TOKEN
, ReplyMessage)
VALUES(referenceid
, csreasoncode
, v_currenttime
, paymentstep
, paymentstatus
, generalerrorcode
, requestid
, requesttoken
, ReplyMessage);
   end if;
   if @@error_count <> 0 then
      ROLLBACK;
      select 0;
      LEAVE SWL_return;
   end if;

   if paymentstep <> 8 then 
      update TPAYMENT a
      set
      a.current_status = paymentstatus,a.last_step = paymentstep,a.last_general_error_code = generalerrorcode, 
      a.ReplyMessage = ReplyMessage
      where a.reference_id = referenceid;
      if @@error_count <> 0 then
         ROLLBACK;
         select 0;

         LEAVE SWL_return;
      end if;
   
      update TCS_PAYMENT_DETAIL c
      set c.last_cs_error_code = csreasoncode
      where c.reference_id = referenceid;
      if @@error_count <> 0 then
         ROLLBACK;
         select 0;
         LEAVE SWL_return;
      end if;
   end if;


   COMMIT;
   select 1;
   LEAVE SWL_return;


   ROLLBACK;
   select 0;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `csPaymentUpdateValidate` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `csPaymentUpdateValidate`( 
   referenceid varchar(32),
   paymentstep int,
   paymentstatus int,
   providercode varchar(5),
   csreasoncode varchar(30),
   requestid varchar(64),
   requesttoken varchar(512),
   generalerrorcode int,
   ReplyMessage varchar(512), 
   three_d_status char(1),
   srd varchar(100)
 )
error:begin 
   
   	declare currenttime datetime;
   	declare default_int_val_0 int;
 	declare default_int_val_1 int;
 
   	Declare exit handler for sqlexception
   	Begin
   		set default_int_val_0 = 0 ;
   		select default_int_val_0;
   		Rollback;
   	End;
       
   	if ReplyMessage = '' 		then set ReplyMessage = 'N/A'; 	end if;
 	if three_d_status = null	then set three_d_status = '';	end if;
 	 if srd = null 				then set srd = ''; 				end if;
     
   	set currenttime = getdate();
 	set default_int_val_1 = 1 ;
   
   	if exists(select 1 from TCS_TRANSACTION a where a.REFERENCE_ID = referenceid and a.PAYMENT_STEP = paymentstep limit 1) then
   		UPDATE TCS_TRANSACTION a
   		SET a.CS_ERROR_CODE = csreasoncode,a.EXECUTION_DATE= currenttime,a.PAYMENT_STATUS= paymentstatus,a.REQUEST_ID= requestid,
   		a.REQUEST_TOKEN= requesttoken,a.GENERAL_ERROR_CODE= generalerrorcode,a.ReplyMessage = ReplyMessage
   		WHERE a.REFERENCE_ID = referenceid and a.PAYMENT_STEP = paymentstep;
   	else
   		INSERT INTO TCS_TRANSACTION(REFERENCE_ID,CS_ERROR_CODE,EXECUTION_DATE,PAYMENT_STEP,PAYMENT_STATUS,GENERAL_ERROR_CODE,REQUEST_ID,REQUEST_TOKEN,ReplyMessage)
   		VALUES(referenceid,csreasoncode,currenttime,paymentstep,paymentstatus,generalerrorcode,requestid,requesttoken,ReplyMessage);
   	end if;
       
 	if row_count() = 0 then
 		leave error;
 	end if;
       
   	if paymentstep <> 8 then
   		if paymentstep = 6 and paymentstatus = 3 then
   
   			  update TPAYMENT a
   			  set a.CURRENT_STATUS = paymentstatus,a.LAST_STEP = paymentstep, a.LAST_GENERAL_ERROR_CODE = generalerrorcode, a.THREEDFLAG = '1' ,
                 a.REPLYMESSAGE = ReplyMessage,a.`3Dstatus`= three_d_status , a.srd=srd
   			  where a.REFERENCE_ID = referenceid;
   
   				if row_count() = 0 then
   					leave error;
   				end if;
   		 end if;
   	else
   			  update  TPAYMENT a
   			  set a.CURRENT_STATUS = paymentstatus,a.LAST_STEP = paymentstep,a.LAST_GENERAL_ERROR_CODE = generalerrorcode ,
                 a.REPLYMESSAGE = ReplyMessage,a.`3Dstatus`= three_d_status ,a.srd=srd
   			  where a.REFERENCE_ID = referenceid;
   
   				if row_count() = 0 then
   					leave error;
   				end if;
   	end if;
   
   	  update TCS_PAYMENT_DETAIL a
   	  set a.LAST_CS_ERROR_CODE = csreasoncode
   	  where a.REFERENCE_ID = referenceid;
   
   		if row_count() = 0 then
   			leave error;
   		end if;
   
   	COMMIT; 
   		select default_int_val_1;
   end error ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `csPaymentUpdate_safecard` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `csPaymentUpdate_safecard`(
 referenceid VARCHAR(32)          
 , paymentstep INT          
 , paymentstatus INT          
 , csreasoncode VARCHAR(30)          
 , generalerrorcode INT     
 ,description VARCHAR(2048)
 )
SWL_return:
begin
 
          
   DECLARE v_currenttime DATETIME(3);          
          
   DECLARE v_Current_Balance FLOAT;

   DECLARE v_Topup_Amt FLOAT;
   DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
   BEGIN
      SET @SWV_Error = 1;
   END;
   SET @SWV_Error = 0;
   START TRANSACTION;          
          
   set v_currenttime = CURRENT_TIMESTAMP;          
          
   SET @SWV_Error = 0;
   if exists(select  1 from   TCS_TRANSACTION a
   where a.REFERENCE_ID = referenceid and a.PAYMENT_STEP = paymentstep LIMIT 1) then
	 
      UPDATE TCS_TRANSACTION b
      SET b.CS_ERROR_CODE = csreasoncode,b.EXECUTION_DATE = v_currenttime,b.PAYMENT_STATUS = paymentstatus, 
      b.GENERAL_ERROR_CODE = generalerrorcode
      WHERE
      b.REFERENCE_ID = referenceid and b.PAYMENT_STEP = paymentstep;
   else
	   INSERT INTO TCS_TRANSACTION(REFERENCE_ID
	  , CS_ERROR_CODE
	  , EXECUTION_DATE
	  , PAYMENT_STEP
	  , PAYMENT_STATUS
	  , GENERAL_ERROR_CODE)
	  VALUES(referenceid
	  , csreasoncode
	  , v_currenttime
	  , paymentstep
	  , paymentstatus
	  , generalerrorcode);
   end if;    
        
   if @SWV_Error <> 0 then
 
  
      ROLLBACK;
      select 0;
      LEAVE SWL_return;
   end if;          
	   

   select   IFNULL(a.Totalamount,0) INTO v_Topup_Amt from TPAYMENT a Where a.REFERENCE_ID = referenceid;
   if paymentstep = 3 or generalerrorcode = 100 then
 
      Update  TPayment_Balance_Master b Set b.Current_Balance = v_Current_Balance+v_Topup_Amt  Where b.BM_REFERENCE_ID = referenceid;
   end if;  
 
   if paymentstep <> 8 then
 
      SET @SWV_Error = 0;
      update TPAYMENT a
      set
      a.current_status = paymentstatus,a.last_step = paymentstep,a.last_general_error_code = generalerrorcode, 
      a.ReplyMessage =  description
      where a.reference_id = referenceid;
      
      
      if @SWV_Error <> 0 then
         ROLLBACK;
         select 0;
         LEAVE SWL_return;
      end if;
      
      SET @SWV_Error = 0;
      
      
      update   TCS_PAYMENT_DETAIL b
      set b.last_cs_error_code = csreasoncode
      where b.reference_id = referenceid;
      
      if @SWV_Error <> 0 then
         ROLLBACK;
         select 0;
         LEAVE SWL_return;
      end if;
   end if;    
    
   SET @SWV_Error = 0;
   if exists(select  1 from TPAYMENT_DESCRIPTION b
   where b.REFERENCE_ID = referenceid LIMIT 1) then
 
      UPDATE TPAYMENT_DESCRIPTION c
      SET c.DESCRIPTION = description
      WHERE  c.REFERENCE_ID = referenceid;
   else
   insert into TPAYMENT_DESCRIPTION(reference_id, DESCRIPTION) values(referenceid,
      description);
   end if;         
     
   if @SWV_Error <> 0 then
      ROLLBACK;
      select 0;
      LEAVE SWL_return;
   end if;    
     
   
   if exists(select  1 from  Paysafe_transaction_log c where c.REFERENCE_ID = referenceid LIMIT 1) then
   
      UPDATE Paysafe_transaction_log t
      SET t.CURRENT_STATUS = paymentstatus,t.LAST_GENERAL_ERROR_CODE = generalerrorcode
      WHERE  t.REFERENCE_ID = referenceid;
   else
  insert into Paysafe_transaction_log(CREATED_DATE,REFERENCE_ID,CURRENT_STATUS,LAST_GENERAL_ERROR_CODE)
 values(v_currenttime,referenceid,paymentstatus,generalerrorcode);
   end if;         
            
 
   COMMIT;          
   select 1;          
   LEAVE SWL_return;          
          
 
   ROLLBACK;          
   select 0;          
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `csPaymentUpdate_v2` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `csPaymentUpdate_v2`(referenceid VARCHAR(32)
  , paymentstep INT
  , paymentstatus INT
  , providercode VARCHAR(5)
  , csreasoncode VARCHAR(30)
  , requestid VARCHAR(64)
  , requesttoken VARCHAR(512)
  , generalerrorcode INT
  , ReplyMessage VARCHAR(512))
SWL_return:
 BEGIN
    DECLARE v_currenttime DATETIME(3);
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
    BEGIN
       SET @SWV_Error = 1;
    END;
    IF ReplyMessage is null then
       set ReplyMessage = 'N/A';
    END IF;
    error:
    BEGIN
       IF ReplyMessage is null then
          set ReplyMessage = 'N/A';
       END IF;
       SET @SWV_Error = 0;
       START TRANSACTION;
       set v_currenttime = CURRENT_TIMESTAMP;
       SET @SWV_Error = 0;
       if exists(select  1 from TCS_TRANSACTION a
       where a.REFERENCE_ID = referenceid and a.PAYMENT_STEP = paymentstep LIMIT 1) then
 
          UPDATE TCS_TRANSACTION a
          SET a.CS_ERROR_CODE = csreasoncode,EXECUTION_DATE = v_currenttime,a.PAYMENT_STATUS = paymentstatus, 
         a.REQUEST_ID = requestid,a.REQUEST_TOKEN = requesttoken, 
          a.GENERAL_ERROR_CODE = generalerrorcode,a.ReplyMessage = ReplyMessage
          WHERE
          a.REFERENCE_ID = referenceid and a.PAYMENT_STEP = paymentstep;
       else
  INSERT INTO TCS_TRANSACTION(REFERENCE_ID
 , CS_ERROR_CODE
 , EXECUTION_DATE
 , PAYMENT_STEP
 , PAYMENT_STATUS
 , GENERAL_ERROR_CODE
 , REQUEST_ID
 , REQUEST_TOKEN
 , ReplyMessage)
 VALUES(referenceid
 , csreasoncode
 , v_currenttime
 , paymentstep
 , paymentstatus
 , generalerrorcode
 , requestid
 , requesttoken
 , ReplyMessage);
       end if;
       if @SWV_Error <> 0 then
 
          LEAVE error;
       end if;
       if paymentstep <> 8 then 
          SET @SWV_Error = 0;
          update TPAYMENT b
          set
          b.current_status = paymentstatus,b.last_step = paymentstep,b.last_general_error_code = generalerrorcode, 
          b.ReplyMessage = ReplyMessage
          where b.reference_id = referenceid;
          if @SWV_Error <> 0 then
   
             LEAVE error;
          end if;
          SET @SWV_Error = 0;
          update TCS_PAYMENT_DETAIL c
          set c.last_cs_error_code = csreasoncode
          where c.reference_id = referenceid;
          if @SWV_Error <> 0 then
   
             LEAVE error;
          end if;
       end if;
 
       COMMIT;
       select 0 as errcode;
       LEAVE SWL_return;
    END;
    ROLLBACK;
    select -1 as errcode;
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `csTransactionGetByRefIDStep` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `csTransactionGetByRefIDStep`(
 referenceid VARCHAR(32)
, paymentstep INT)
begin


   DECLARE v_last_step INT;
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   max(a.payment_step) INTO v_last_step from TCS_TRANSACTION a where a.reference_id = referenceid;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select
   cs.reference_id
, pay.cc_no last6digitscc
, cs.cs_error_code
, cs.execution_date
, cs.payment_step
, cs.payment_status
, cs.request_id
, cs.request_token
, cs.general_error_code
, pay.currency
, pay.totalamount
   from TCS_TRANSACTION cs
   join TPAYMENT pay
   on cs.reference_id = pay.reference_id
   where
   cs.reference_id = referenceid
   and cs.payment_step = paymentstep
   and v_last_step = paymentstep;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ctpapp_get_payment_saved_card_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ctpapp_get_payment_saved_card_info`(
account_id varchar(20),
process_device varchar(100),
auto_pay int
)
BEGIN

	declare auto_topup int;
	declare auto_topup_amount float;
	declare auto_subsid varchar(100);
	
	set auto_topup=0;
	set auto_topup_amount=0;

	IF (auto_pay is null or auto_pay='')then set auto_pay = 0; END IF;

	drop TEMPORARY TABLE if exists cc_no;
	CREATE TEMPORARY TABLE cc_no
	(
		Last6digitsCC varchar(20)
	);

	drop TEMPORARY TABLE if exists dc_sav_card;
	CREATE TEMPORARY TABLE dc_sav_card
	(
		account_id varchar(20),	Last6digitsCC varchar(20),	expirydate varchar(6), 	card_type varchar(150),	card_holder_name varchar(100),
		postcode varchar(50),	country varchar(50),	is_autotopup int,	SubscriptionID varchar(40),	auto_topup_amount float
	);

	drop TEMPORARY TABLE if exists cc_no;
	CREATE TEMPORARY TABLE cc_no
	(
		Last6digitsCC varchar(20)
	);
	
	IF auto_pay=0 Then
		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

			insert into dc_sav_card(account_id, Last6digitsCC, expirydate, card_type, card_holder_name, postcode, country, is_autotopup, 
			SubscriptionID, auto_topup_amount)
			select a.account_id,a.Last6digitsCC,a.expirydate, card_type,ifnull(card_holder_name,'') as card_holder_name,
			ifnull(postcode,'') as postcode,ifnull(country,'') as country,ifnull(is_autotopup,0) as is_autotopup,
			ifnull(b.SubscriptionID,'') as SubscriptionID,ifnull(auto_topup_amount,0) as auto_topup_amount 
			from payment_card_detail a 
			join tSubscription b on a.account_id=b.account_id and a.Last6digitsCC=b.Last6digitsCC
			where a.account_id=account_id order by id desc;
		SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
	
		insert into cc_no(Last6digitsCC)
		select distinct Last6digitsCC from dc_sav_card;
    
		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
			drop temporary table if exists sav_card_payment;
			create temporary table sav_card_payment as
			select * from TPAYMENT a where a.ACCOUNT_ID=account_id;
		SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

		drop temporary table if exists ThreeDFlag_status;
		create temporary table ThreeDFlag_status as
		select sv.account_id,sv.CC_NO,sv.ThreeDFlag,sv.`3Dstatus` 
		from 
		(select s.account_id,s.CC_NO,ThreeDFlag,`3Dstatus`,row_number() over(partition by s.CC_NO order by s.CREATED_DATE asc)rno from sav_card_payment s
		where exists (select c.Last6digitsCC from cc_no c where s.CC_NO=c.Last6digitsCC) and s.LAST_GENERAL_ERROR_CODE in(0,100))sv where rno=1;

		select * from dc_sav_card s
		where exists (
		select f.CC_NO from ThreeDFlag_status f where s.account_id=s.account_id and f.CC_NO=s.Last6digitsCC
		       and f.ThreeDFlag=1 and f.`3Dstatus`='Y');
		
		drop temporary table IF EXISTS dc_sav_card;	
		drop temporary table IF EXISTS cc_no;
		drop temporary table IF EXISTS ThreeDFlag_status;
		drop temporary table IF EXISTS sav_card_payment;

	ELSE
	
		SELECT distinct a.ACCOUNT_ID AS account_id,CONCAT('XXXXXXXXXXXX',CC_NO) AS Last6digitsCC,b.expirydate,'MC' AS card_type,'' as card_holder_name,'' as postcode,'' as country,
		case when ifnull(c.status,0) = 1 then 1 else 0 end as is_autotopup,
		ifnull(b.SubscriptionID,'') as SubscriptionID,
		case when ifnull(c.TopupAmount,0)>0 and c.Status>1 then CAST(c.TopupAmount AS FLOAT) else CAST(0 AS DECIMAL(15,15)) end as auto_topup_amount
		FROM TPAYMENT a
		join tSubscription b on a.account_id=b.account_id and a.CC_NO=b.Last6digitsCC
		left join  webpayment.tAuxAutoTopup c  on c.MobileNo=a.account_id and c.SubscriptionID=b.SubscriptionID
		where a.account_id=account_id;
	
	END if;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `CTP_Payment_Transaction_ErrorLog` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `CTP_Payment_Transaction_ErrorLog`(
REFERENCE_ID VARCHAR(40),        
ERRORID INT ,        
RESULTID INT,      
MESSAGE VARCHAR(300),      
STAGE VARCHAR(300),      
STEP INT ,    
EXTRAMESSAGE VARCHAR(600),    
ECI VARCHAR(300),
STATUS VARCHAR(100))
Begin
 
        
  Insert into CTP_Payment_ErrorLog(REFERENCE_ID,PAY_ERRORID,PAY_RESULTID,PAYDATE,CTPMESSAGE,STAGE,STEP,EXTRAMESSAGE,ECI,Status)
 Values(REFERENCE_ID,ERRORID,RESULTID,CURRENT_TIMESTAMP(),MESSAGE,STAGE,STEP,EXTRAMESSAGE,ECI,STATUS);        
   
        
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `delightcall_ccdc_insert_card_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `delightcall_ccdc_insert_card_details`(
account_id VARCHAR(20),  
Last6digitsCC VARCHAR(30),  
expirydate VARCHAR(6),  
card_type VARCHAR(50),  
process_device VARCHAR(100),  
card_holder_name VARCHAR(100),  
postcode VARCHAR(50),  
country VARCHAR(100))
BEGIN
   
   DECLARE v_NOW DATETIME(3);   
   
   IF card_holder_name is null 
   then
      set card_holder_name = '';
   END IF;
   
   IF postcode is null 
   then
      set postcode = '';
   END IF;
   
   IF country is null 
   then
      set country = '';
   END IF;
   
   set Last6digitsCC = right(Last6digitsCC,6);  
   
   SET v_NOW = CURRENT_TIMESTAMP;  
   
   IF NOT EXISTS(SELECT  1 FROM payment_card_detail a WHERE a.account_id = account_id and a.Last6digitsCC = Last6digitsCC LIMIT 1) 
   then
 
    INSERT INTO payment_card_detail(account_id,Last6digitsCC,expirydate,card_type,process_device,create_date,card_holder_name,
    country,postcode,is_delightcall)
    VALUES(account_id,Last6digitsCC,expirydate,card_type,process_device,v_NOW,card_holder_name,country,postcode,1);
  
      SELECT 0 errcode, 'Success' errmsg;
      
   ELSE
   
      UPDATE payment_card_detail a SET a.expirydate = expirydate,a.process_device = process_device,a.card_holder_name = card_holder_name,
      a.country = country,a.postcode = postcode,is_delightcall = 1
      WHERE a.account_id = account_id and a.Last6digitsCC = Last6digitsCC;
      
      SELECT 0 errcode, 'Success' errmsg;
      
   end if;  
   
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ecom_pay_get_Subscription_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ecom_pay_get_Subscription_details`(
     Account_Id varchar(50)
   )
begin
    
      declare cardholder_name varchar(100);
   
     select  a.cardholder_name into cardholder_name from TPAYMENT a where a.Account_Id=Account_Id order by CREATED_DATE DESC limit 1;
     
     select a.Account_Id, a.Last6digitsCC, a.SubscriptionID, a.expirydate, a.purchasedate, a.provider_code,a.card_type,a.is_ecom,cardholder_name from tSubscription a where a.Account_Id=Account_Id and a.status=1 order by idx  ;
   
   end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `farud_score_insert` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `farud_score_insert`(
    requestid VARCHAR(64)                  
   , score VARCHAR(32)      
   , referenceid  VARCHAR(240),
   tcs_eci_val VARCHAR(250))
Begin
      
     DECLARE v_errcode INT;                  
     DECLARE v_errmsg longtext;    
     
      if (tcs_eci_val is null or tcs_eci_val = '') then set tcs_eci_val = 0; end if;
  
  Insert Into fraud_score_log(logdate,fraud_score,requestid,referenceid,eci_value)
  Values(CURRENT_TIMESTAMP,score,requestid,referenceid,CAST(tcs_eci_val as UNSIGNED));                
               
     If ROW_COUNT() > 0 then
        Set v_errcode = 1;
        Set v_errmsg = 'Ok';
     else
        Set v_errcode = 0;
        Set v_errmsg = 'Ok';
     end if;            
               
                
     Select v_errcode As errcode ,v_errmsg As errmsg;          
                       
  End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `FINANCE_THREED_SECURE_MONITOR_REPORT` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `FINANCE_THREED_SECURE_MONITOR_REPORT`(v_REPORT_TYPE INT)
BEGIN
		
   DECLARE v_monthly_date DATETIME(3); 
	
   set v_monthly_date = TIMESTAMPADD(month,TIMESTAMPDIFF(month,TIMESTAMPADD(month,0,'1900-01-01 00:00:00'),CURRENT_TIMESTAMP),TIMESTAMPADD(month,0,'1900-01-01 00:00:00'));
	
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   SELECT  CREATED_DATE AS TRANSACTION_DATE,REFERENCE_ID,ACCOUNT_ID,IFNULL(CC_NO,'') AS LAST6DIGICARD,`3Dstatus`,ReplyMessage,LAST_GENERAL_ERROR_CODE AS ERROR_CODE
   FROM  TPAYMENT WHERE IFNULL(3Dstatus,'') <> ''
   AND (((v_REPORT_TYPE = 1) AND (DATE_FORMAT(CREATED_DATE,'%d/%m/%Y') = DATE_FORMAT(CURRENT_TIMESTAMP,'%d/%m/%Y'))) OR 
		((v_REPORT_TYPE = 2) AND (DATE_FORMAT(CREATED_DATE,'%d/%m/%Y') >= DATE_FORMAT(TIMESTAMPADD(day,-7,CURRENT_TIMESTAMP),'%d/%m/%Y'))) or
		 (((v_REPORT_TYPE = 3) AND (CREATED_DATE >= v_monthly_date)) or
		 (v_REPORT_TYPE = 4 AND (DATE_FORMAT(CREATED_DATE,'%d/%m/%Y') = DATE_FORMAT(TIMESTAMPADD(day,-1,CURRENT_TIMESTAMP),'%d/%m/%Y')))))
   ORDER BY CREATED_DATE DESC;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getpaymentcustemailid` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `getpaymentcustemailid`(
account_id varchar(30)
)
begin

	select PAYMENT_AGENT,email 
	from TPAYMENT a 
	where a.ACCOUNT_ID=account_id 
	and a.ReplyMessage='Successful transaction.' 
	order by CREATED_DATE desc limit 1;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Hubspot_Job_get_card_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `Hubspot_Job_get_card_details`()
BEGIN


   DECLARE v_date VARCHAR(10);
   DROP TEMPORARY TABLE IF EXISTS tt_temp_card_info;
   create TEMPORARY table tt_temp_card_info
   (
      Account_Id VARCHAR(20),
      expirydate VARCHAR(10),
      cc_no VARCHAR(4),
      card_name VARCHAR(100)
   );
	
   set v_date = DATE_FORMAT(CURRENT_TIMESTAMP,'%Y%m%d');

   insert into tt_temp_card_info(Account_Id,expirydate,cc_no)
   select Account_Id,expirydate,Right(Last6digitsCC,4) as cc_no
   from  tSubscription
   where account_id like '44%'
   and expirydate = v_date;
  
   UPDATE tt_temp_card_info a
   join TPAYMENT b on a.account_id = b.account_id set a.card_name = b.cardtype;
  
   select * from tt_temp_card_info;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Hubspot_ur_Job_get_card_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `Hubspot_ur_Job_get_card_details`(
date VARCHAR(50))
BEGIN
 
    DROP TEMPORARY TABLE IF EXISTS tt_temp_card_info;
    create TEMPORARY table tt_temp_card_info
    (
       Account_Id VARCHAR(20),
       expirydate VARCHAR(10),
       cc_no VARCHAR(4),
       card_name VARCHAR(100)
    );
 		
    DROP TEMPORARY TABLE IF EXISTS tt_month;		
    CREATE TEMPORARY TABLE tt_month
    (
       expdate VARCHAR(50)
    );
 		                  
    
    
           
     call unifiedring.split(date,',');
 
      insert into tt_month (expdate)
      select Items	from unifiedring.tt_Split_temptable;
      

 
    insert into tt_temp_card_info(Account_Id,expirydate,cc_no)
    select Account_Id,expirydate,Right(Last6digitsCC,4) as cc_no
    from tSubscription 
    where account_id like 'UR%'
    and expirydate in(select expdate from tt_month)
    and  CHAR_LENGTH(Account_Id) > 5;
 
 	  
    UPDATE tt_temp_card_info a
    join TPAYMENT b on a.account_id = b.account_id set a.card_name = b.cardtype;
 	  
    select * from tt_temp_card_info;
 
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `IVR_payment_get_saved_card` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `IVR_payment_get_saved_card`(
account_id varchar(20)
)
BEGIN


	declare cardno1 varchar(10);
	declare cardno1_expdate varchar(10);
	
	declare cardno2 varchar(10);
	declare cardno2_expdate varchar(10);
	
	select a.Last6digitsCC,a.expirydate into cardno1, cardno1_expdate
	from payment_card_detail a 
	join tSubscription b on a.account_id=b.Account_Id and a.Last6digitsCC=b.Last6digitsCC
	where a.account_id=account_id and a.process_device='IVR' 
	order by id desc limit 1;
	
	IF ifnull(cardno1,'')<>'' then
	
		select a.Last6digitsCC,a.expirydate into cardno2,cardno2_expdate
		from payment_card_detail a
		join tSubscription b on a.account_id=b.Account_Id and a.Last6digitsCC=b.Last6digitsCC
		where a.account_id=account_id and a.process_device='IVR' 
		AND a.Last6digitsCC<>cardno1
		order by id desc limit 1;
		
	END if;
	
	IF ifnull(cardno1,'')='' then
		select '' as  cardno1, '' as cardno1_expdate, '' as cardno2, '' as cardno2_expdate;
	Else
		SELECT ifnull(cardno1,'') as cardno1, ifnull(cardno1_expdate,'') as cardno1_expdate,
		ifnull(cardno2,'') as cardno2, ifnull(cardno2_expdate,'') as cardno2_expdate;
	End if;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `IVR_paym_create_save_card_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `IVR_paym_create_save_card_info`(
account_id varchar(20),
Last6digitsCC varchar(6),
expirydate varchar(6)
)
BEGIN

	DECLARE NOW DATETIME; 
	
	IF Length(Last6digitsCC)>4 then
		SET Last6digitsCC=LEFT(Last6digitsCC,4);
	end if;
	
	SET NOW=CURRENT_TIMESTAMP;
	
	IF NOT EXISTS(SELECT 1 FROM payment_card_detail a WHERE a.account_id=account_id and a.Last6digitsCC=Last6digitsCC) then
	
		INSERT INTO payment_card_detail(account_id,Last6digitsCC,expirydate,process_device,create_date,card_holder_name,country,postcode,is_delightcall)
		VALUES(account_id,Last6digitsCC,expirydate,'IVR',NOW,NULL,NULL,NULL,0);
		
	ELSE
		UPDATE payment_card_detail a SET a.expirydate=expirydate,a.process_device='IVR',a.is_delightcall=0
		WHERE a.account_id=account_id and a.Last6digitsCC=Last6digitsCC;
		
	END if;
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `mvno_autotopup_payment_type_register` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `mvno_autotopup_payment_type_register`(
mobileno VARCHAR(20),  
topup_type INT,  
processby VARCHAR(25),  
OUT errcode INT ,  
OUT errmsg VARCHAR(250))
SWL_return:
BEGIN

  
   
   
   DECLARE v_now DATETIME(3);  
   
   set v_now = CURRENT_TIMESTAMP;  
   
   IF NOT EXISTS(SELECT  1 FROM auttopup_type a where a.topup_type = topup_type LIMIT 1) then
 
      set errcode = -1;
      set errmsg = 'Failure to get the autotopup type.';
      LEAVE SWL_return;
   end if;  
   
 
   IF topup_type = 0 then
 
      IF NOT EXISTS(select  1  from tSubscription  where Account_Id = mobileno LIMIT 1) then
  
         set errcode = -1;
         set errmsg = 'You need to do the credit card topup before do the settings ';
         LEAVE SWL_return;
      end if;
   end if;  
   
   
 
   IF topup_type = 1 then
 
      IF NOT EXISTS(select  1  from tSubscription_paypal where account_Id = mobileno LIMIT 1) then
  
         set errcode = -1;
         set errmsg = 'You need to do the paypal topup before do the settings ';
         LEAVE SWL_return;
      end if;
   end if;  
   
 
   IF topup_type = 2 then
 
      IF NOT EXISTS(select  1  from tSubscription_amazon where account_Id = mobileno LIMIT 1) then
  
         set errcode = -1;
         set errmsg = 'You need to do the Amazon topup before do the settings ';
         LEAVE SWL_return;
      end if;
   end if;  
   
   
   IF EXISTS(SELECT  1 FROM mvno_auttopup_type_register a where a.mobileno = mobileno LIMIT 1) then
 
      UPDATE mvno_auttopup_type_register a SET a.topup_type = topup_type,create_by = processby,lastupdate = v_now where a.mobileno = mobileno;
      if ROW_COUNT() > 0 then
  
         set errcode = 0;
         set errmsg = 'Success to update the auto topup register.';
         LEAVE SWL_return;
      end if;
   ELSE
   INSERT INTO mvno_auttopup_type_register(mobileno,topup_type,create_date,create_by,lastupdate)
  VALUES(mobileno,topup_type,v_now,processby,v_now);
  
      if ROW_COUNT() > 0 then
  
         set errcode = 0;
         set errmsg = 'Success to update the auto topup register.';
         LEAVE SWL_return;
      end if;
   end if;  
   
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `mvno_check_realx_transaction` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `mvno_check_realx_transaction`(mobileno VARCHAR(20),
OUT source_type INT  
)
begin

   set source_type = 0;

   if exists(select 1 from TPAYMENT where REFERENCE_ID like '%RX%' and ACCOUNT_ID = mobileno LIMIT 1) then

      set source_type = 1;
   end if; 

   if exists(select 1 from mvno_auttopup_type_register a where a.mobileno = mobileno and topup_type = 1 LIMIT 1) then

      set source_type = 1;
   end if; 

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `paymentgateway_check_cardcount` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `paymentgateway_check_cardcount`(
last6digit varchar(6),
reference_id varchar(50),
mobileno varchar(20)
)
BEGIN

	declare card_count int;
	declare threeD_status char(1);
	
	if (mobileno is null) then set mobileno = ''; end if;

	set card_count=0; 
	
	if exists(select 1 from TPAYMENT a where a.CC_NO=last6digit and a.REFERENCE_ID<>reference_id AND a.REFERENCE_ID like '%RX%' limit 1) then
		set card_count=1;
	end if;
	
	
	IF card_count=1 AND ifnull(mobileno,'')<>'' AND isnumeric(mobileno)=1 then
		SELECT ifnull(a.`3Dstatus`,'') into threeD_status from TPAYMENT a
		where a.ACCOUNT_ID=mobileno and a.CC_NO=last6digit  
		and a.REFERENCE_ID<>reference_id AND a.REFERENCE_ID like '%RX%'
		order by a.CREATED_DATE desc limit 1;
		
		if threeD_status='Y' then
			set card_count=1; 
		else
			set card_count=0; 
		end if;
		
	END if;
	
	select card_count as card_count;
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `PaymentGetPayerPayMethod` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `PaymentGetPayerPayMethod`(accountid VARCHAR(30))
BEGIN

   DECLARE v_idx INT;  
  
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   a.idx INTO v_idx from tSubscription a where a.Account_Id = accountid   order by a.idx desc LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

   SET v_idx = IFNULL(v_idx,0);
  
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   Select b.SubscriptionID,accountid AccountID from tSubscription b where b.idx = v_idx;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;   
  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `paymentRoutingGetData` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `paymentRoutingGetData`(sitecode VARCHAR(5),
productcode VARCHAR(20))
BEGIN

   if not exists(select 1 from TROUTING a where a.SITECODE = sitecode and productcode like CONCAT(a.PRODUCT_CODE_PREFIX,'%') LIMIT 1) then
      set productcode = '_default';
   end if;

   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select ID, PROVIDER_CODE, a.SITECODE, PRODUCT_CODE_PREFIX, LTRIM(RTRIM(MERCHANT_ID)) merchant_id
   from TROUTING a
   where a.SITECODE = sitecode and productcode like CONCAT(a.PRODUCT_CODE_PREFIX,'%');
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `payment_check` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `payment_check`(account_id VARCHAR(32))
SWL_return:
 begin
 
    DECLARE v_ref_code INT;  
    DECLARE v_day_trax FLOAT;  
    DECLARE v_week_trax FLOAT;  
    DECLARE v_month_trax FLOAT;  
   
    SET v_ref_code = -1;  
    SET v_day_trax = 0.0;  
    SET v_week_trax = 0.0;  
    SET v_month_trax = 0.0;  
   
     
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select   IFNULL(sum(a.totalamount),0) INTO v_day_trax from TPAYMENT a where a.account_id = account_id and a.current_status in(3,4)
    and TIMESTAMPDIFF(day,a.created_date,CURRENT_TIMESTAMP) = 0;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select   IFNULL(sum(b.totalamount),0) INTO v_week_trax from TPAYMENT  b where b.account_id = account_id and b.current_status in(3,4)
    and TIMESTAMPDIFF(day,b.created_date,CURRENT_TIMESTAMP) = 7;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select   IFNULL(sum(c.totalamount),0) INTO v_month_trax from TPAYMENT c where c.account_id = account_id and c.current_status in(3,4)
    and TIMESTAMPDIFF(day,c.created_date,CURRENT_TIMESTAMP) = 30;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

     
    if v_day_trax < 50.0 and v_week_trax < 100.0 and v_month_trax < 150.0 then
       
         
       select 1;
       LEAVE SWL_return; 
    else
       select -12;
    end if;
 
 
   
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `payment_check_mysql` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `payment_check_mysql`(account_id VARCHAR(32),out generalerrorcode int)
SWL_return:
  begin
  
     DECLARE v_ref_code INT;  
     DECLARE v_day_trax FLOAT;  
     DECLARE v_week_trax FLOAT;  
     DECLARE v_month_trax FLOAT;  
    
     SET v_ref_code = -1;  
     SET v_day_trax = 0.0;  
     SET v_week_trax = 0.0;  
     SET v_month_trax = 0.0;  
    
      
     SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
     select   IFNULL(sum(a.totalamount),0) INTO v_day_trax from TPAYMENT a where a.account_id = account_id and a.current_status in(3,4)
     and TIMESTAMPDIFF(day,a.created_date,CURRENT_TIMESTAMP) = 0;
     SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 
     SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
     select   IFNULL(sum(b.totalamount),0) INTO v_week_trax from TPAYMENT  b where b.account_id = account_id and b.current_status in(3,4)
     and TIMESTAMPDIFF(day,b.created_date,CURRENT_TIMESTAMP) = 7;
     SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 
     SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
     select   IFNULL(sum(c.totalamount),0) INTO v_month_trax from TPAYMENT c where c.account_id = account_id and c.current_status in(3,4)
     and TIMESTAMPDIFF(day,c.created_date,CURRENT_TIMESTAMP) = 30;
     SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 
      
     if v_day_trax < 50.0 and v_week_trax < 100.0 and v_month_trax < 150.0 then
        
          
        select 1 into generalerrorcode;
        LEAVE SWL_return; 
     else
        select -12 into generalerrorcode;
     end if;
  
  
    
  end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `payment_check_paysafe` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `payment_check_paysafe`(
	account_id VARCHAR(32) ,    
OUT Return_Value INT)
begin

   DECLARE v_ref_code INT;        
   DECLARE v_day_trax FLOAT;        
   DECLARE v_week_trax FLOAT;        
   DECLARE v_month_trax FLOAT;        
        
   SET v_ref_code = -1;        
   SET v_day_trax = 0.0;        
   SET v_week_trax = 0.0;        
   SET v_month_trax = 0.0;        
        
     
     
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   IFNULL(sum(totalamount),0) INTO v_day_trax from TPAYMENT  a where a.account_id = account_id and current_status in(3,4)
   and TIMESTAMPDIFF(day,created_date,CURRENT_TIMESTAMP) = 0;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;      
       
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   IFNULL(sum(totalamount),0) INTO v_week_trax from TPAYMENT  a where a.account_id = account_id and current_status in(3,4)
   and TIMESTAMPDIFF(day,created_date,CURRENT_TIMESTAMP) = 7;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;      
      
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   IFNULL(sum(totalamount),0) INTO v_month_trax from TPAYMENT  a where a.account_id = account_id and current_status in(3,4)
   and TIMESTAMPDIFF(day,created_date,CURRENT_TIMESTAMP) = 30;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;      
       
     
   if v_day_trax < 50.0 and v_week_trax < 100.0 and v_month_trax < 150.0 
   then
             
         
      SET Return_Value = 1;
   else
      SET Return_Value = -12;
   end if;    
       
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `payment_gateway_check_rule_v2` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `payment_gateway_check_rule_v2`(
 cc_no varchar(6),
 amount float,
 mobileno varchar(20),
 ipaddress varchar(50),
 card_type varchar(50),
 called_by varchar(25),
 product_code varchar(150)
 )
BEGIN
  
 	declare rule_status int; 
 	declare errmsg varchar(250);
 	declare max_topup_amount float; 
 	declare tp_amount float; 
 	declare last_payment_reference varchar(50);
 
 
 	if product_code is null then set product_code = ''; end if;
 	
 	insert into  payment_gateway_check_rule_v2_log(cc_no,amount,mobileno,ipaddress,card_type,called_by,product_code) values(cc_no,amount,mobileno,ipaddress,card_type,called_by,product_code);
 	
 	set max_topup_amount=51;
 	
 	IF length(cc_no)>4 then
 		set cc_no=RIGHT(cc_no,4);
 	end if;
 	
 	set rule_status=0;
 	
 	set errmsg='card allowed for transaction';
 	
 SP_EXIT : begin
 
 	if (cc_no IN( '7657' ,'5056','5412') or mobileno  in('FREE SIM','FREE SIM WITH TOPUP')) then
 		leave SP_EXIT;
 	end if;
 	
 	if mobileno LIKE 'UR%' then
 		leave SP_EXIT;
 	END if;
 	
 	if mobileno='447574440203' then
 		leave SP_EXIT;
 	end if;
 	
 	
 	select a.reference_id into last_payment_reference from TPAYMENT a
 	where a.ACCOUNT_ID=mobileno 
 	and a.LAST_GENERAL_ERROR_CODE IN(0,100)
 	ORDER BY a.CREATED_DATE DESC limit 1;
 	
 	IF (last_payment_reference LIKE 'VMUK-PP%') OR (last_payment_reference LIKE 'VMUK-PMPO%') then
 		leave SP_EXIT;
 	END if;
 	
 	IF (last_payment_reference LIKE 'VMAT-PP%') OR (last_payment_reference LIKE 'VMAT-PMPO%') then
 		leave SP_EXIT;
 	END if;
 	
 	
 	
 	select sum(a.TOTALAMOUNT) into tp_amount from TPAYMENT a
 	where cast(a.CREATED_DATE AS DATE)=CAST(current_timestamp AS DATE) 
 	AND a.LAST_GENERAL_ERROR_CODE IN(0,100) AND a.REFERENCE_ID LIKE '%RX%'
 	AND a.CC_NO=cc_no
 	and a.REFERENCE_ID not like '%REN%'
 	and a.REFERENCE_ID not like '%PMP0%'
 	and a.REFERENCE_ID not like '%VRN%';
 	
 	set tp_amount=ifnull(tp_amount,0)+amount;
 	
 	if tp_amount>=max_topup_amount then
 		SET rule_status=1;
 		SET errmsg='Rule enabled for same card can not able to make payment more than 50 pound';
 		leave SP_EXIT;
 		
 	END if;
 	
 	
 	
 	select sum(a.TOTALAMOUNT) into tp_amount from TPAYMENT a
 	where cast(a.CREATED_DATE AS DATE)=CAST(current_timestamp AS DATE) 
 	AND a.LAST_GENERAL_ERROR_CODE IN(0,100)
 	AND ifnull(a.IPClient,'')=ipaddress
 	AND a.REFERENCE_ID LIKE '%RX%'
 	and a.REFERENCE_ID not like '%REN%'
 	and a.REFERENCE_ID not like '%PMP0%'
 	and a.REFERENCE_ID not like '%VRN%';
 	
 	set tp_amount=ifnull(tp_amount,0)+amount;
 	
 	if tp_amount>=max_topup_amount then
 		SET rule_status=1;
 		SET errmsg='Rule enabled for same card can not able to make payment more than 50 pound';
 		leave SP_EXIT;
 	END if;
 	
 	
 	select sum(a.TOTALAMOUNT) into tp_amount from TPAYMENT a 
 	where cast(a.CREATED_DATE AS DATE)=CAST(current_timestamp AS DATE) 
 	AND a.ACCOUNT_ID=mobileno
 	AND a.LAST_GENERAL_ERROR_CODE IN(0,100)
 	AND a.REFERENCE_ID LIKE '%RX%'
 	and a.REFERENCE_ID not like '%REN%'
 	and a.REFERENCE_ID not like '%PMP0%'
 	and a.REFERENCE_ID not like '%VRN%';
 
 	
 	set tp_amount=ifnull(tp_amount,0)+amount;
 	
 	if tp_amount>=max_topup_amount then
 		SET rule_status=1;
 		SET errmsg='Rule enabled for same card can not able to make payment more than 50 pound';
 		leave SP_EXIT;
 		
 	END if;
 	
 	if exists(select 1 from blocked_card_info a where a.cc_no=cc_no and a.status=1 and ((ifnull(a.prod_code,'')='') or (a.prod_code=product_code))) then
 		set rule_status=1;
 	end if;
 	
 	if rule_status=1 then
 		set errmsg='card not allowed for transaction';
 	
 		INSERT INTO blockcard_trans_log(logdate,cc_no,amount,mobileno,ipaddress,card_type,called_by)
 		VALUES(current_timestamp,cc_no,amount,mobileno,ipaddress,card_type,called_by);
 	end if;
 	
 end SP_EXIT;
 
 IF rule_status=1 then
 
 	INSERT INTO PAYMENT_REJECT_LOG(LOGDATE,ACCOUNT_ID,TOPUP_AMOUNT,IP_ADDRESS,CARD_TYPE,CALLED_BY,TRANS_AMOUNT,RULE_STATUS,MESSAGE,CC_NO)
 	VALUES(current_timestamp,mobileno,amount,ipaddress,card_type,called_by,max_topup_amount,rule_status,errmsg,cc_no);
 		
 END if;
 
 
 SELECT errmsg as payment_message,rule_status as rule_status;
 	
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `payment_getCounterRefID` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `payment_getCounterRefID`(
  sitecode VARCHAR(5)  
, provider_code VARCHAR(5) )
SWL_return:
BEGIN
  DECLARE v_counter BIGINT;
   IF provider_code is null then
      set provider_code = 'CS';
   END IF;
   if not exists(select  1 from tcounter_refid a
   where a.sitecode = sitecode LIMIT 1) then

      select -1;

      LEAVE SWL_return;
   end if;  
  
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   a.counter+1 INTO v_counter from tcounter_refid a where a.sitecode = sitecode and a.provider_code = provider_code;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
  
   update tcounter_refid b
   set b.counter = v_counter
   where b.sitecode = sitecode
   and b.provider_code = provider_code;
  
   select v_counter;  
  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `payment_getCounterRefID_MYSQL` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `payment_getCounterRefID_MYSQL`(
   sitecode VARCHAR(5)  
 , provider_code VARCHAR(5)
 , OUT v_orderno int
 )
SWL_return:
 BEGIN
   DECLARE v_counter BIGINT;
    IF provider_code is null then
       set provider_code = 'CS';
    END IF;
    if not exists(select  1 from tcounter_refid a
    where a.sitecode = sitecode LIMIT 1) then
 
       select -1;
 
       LEAVE SWL_return;
    end if;  
   
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select   a.counter+1 INTO v_counter from tcounter_refid a where a.sitecode = sitecode and a.provider_code = provider_code;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   
    update tcounter_refid b
    set b.counter = v_counter
    where b.sitecode = sitecode
    and b.provider_code = provider_code;
   
    select v_counter INTO v_orderno;  
   
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `payment_getCounterRefID_safecard` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `payment_getCounterRefID_safecard`(
sitecode VARCHAR(5) ,            
OUT Rtn_counter BIGINT)
begin

  
   
           
   DECLARE v_counter BIGINT;            
            
   if not exists(select  1 from tcounter_refid a
   where a.sitecode = sitecode LIMIT 1) then
 
      SET Rtn_counter = -1;
   end if;            
            
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   counter+1 INTO v_counter from tcounter_refid a where a.sitecode = sitecode and a.provider_code = 'CS';
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;          
            
   update tcounter_refid a
   set a.counter = v_counter
   where a.sitecode = sitecode
   and a.provider_code = 'CS';          
    
   SET Rtn_counter = v_counter;  
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `payment_getCounterRefID_v3` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `payment_getCounterRefID_v3`(
 	sitecode VARCHAR(5),    
 	provider_code VARCHAR(5) ,  
 OUT counter BIGINT   )
SWL_return:begin
     
    IF provider_code is null 
    then
       set provider_code = 'CS';
    END IF;
    
    if not exists(select  1 from tcounter_refid a where a.sitecode = sitecode LIMIT 1) 
    then
       select -1;
       LEAVE SWL_return;
    end if;    
        
    select a.counter+1 INTO counter from tcounter_refid a where a.sitecode = sitecode and a.provider_code = provider_code;   
     
    update tcounter_refid a set a.counter = counter where a.sitecode = sitecode
    and a.provider_code = provider_code;  
   
 end SWL_return ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `payment_getlastsubcriptionid` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `payment_getlastsubcriptionid`(account_id VARCHAR(30))
begin


   select  a.SubscriptionID
   from tSubscription a
   where a.account_id = account_id
   order by idx desc,purchasedate desc,expirydate desc LIMIT 1;
	
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `payment_remove_subscribtion` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `payment_remove_subscribtion`(
Last6digitsCC VARCHAR(6),
subscribtionid VARCHAR(100))
BEGIN


	
	
   DECLARE v_errcode INT;
   DECLARE v_errmsg VARCHAR(250);
	
   set v_errcode = -1;
   set v_errmsg = 'Failure to delete subscribtion';
	
   delete from tSubscription a where
   a.Last6digitsCC = Last6digitsCC and a.SubscriptionID = subscribtionid;
	
   if ROW_COUNT() > 0 then
	
      set v_errcode = 0;
      set v_errmsg = 'Success to remove subscribtion';
   end if;
	

   select v_errcode as errcode,v_errmsg as errmsg;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `payment_restrict_topup` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `payment_restrict_topup`(account_id VARCHAR(20),  
  payment_agent VARCHAR(10),  
  currency VARCHAR(5),  
  topup_amount FLOAT,  
  appname VARCHAR(10),  
  cc_no VARCHAR(6),  
  appcode VARCHAR(20),  
  lang_code VARCHAR(2))
BEGIN
 
     DECLARE v_max_amount FLOAT;  
     DECLARE v_days_valid INT;   
     DECLARE v_trans_amount FLOAT;  
     
     DECLARE v_errcode INT;   
     DECLARE v_errmsg VARCHAR(250);  
     
     DECLARE v_aut_trans_amount FLOAT;
     DECLARE Swv_RowCount INT;   
     
     IF appcode is null then set appcode = ''; END IF;
     IF lang_code is null then set lang_code = 'EN'; END IF;
 
 sp_exit: BEGIN
        IF appcode is null then set appcode = ''; END IF;
        IF lang_code is null then set lang_code = 'EN'; END IF;
        
        set v_errcode = 0;
        set v_errmsg = 'Customer not reached topup amount.';
        if appcode = 'DCSIM' then
           LEAVE sp_exit;
        end if;
        SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        select max_amount, days_valid INTO v_max_amount,v_days_valid from payment_restrict_config a where a.currency = currency;
        SET Swv_RowCount = ROW_COUNT();
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
        
        if Swv_RowCount = 0 then
           LEAVE sp_exit;
        end if;  
     
   
        SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        select sum(TOTALAMOUNT) INTO v_trans_amount from TPAYMENT a where a.ACCOUNT_ID = account_id
        and TIMESTAMPDIFF(DAY,CREATED_DATE,CURRENT_TIMESTAMP) <= v_days_valid
        and LAST_GENERAL_ERROR_CODE in(0,100) and REFERENCE_ID like '%RX%';
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
     
   
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        select   sum(amount) INTO v_aut_trans_amount from webPayment.tCybS_RegisteredPayment a where a.mobileno = account_id and decision = 'ACCEPT'
        and TIMESTAMPDIFF(DAY,reg_date,CURRENT_TIMESTAMP) <= v_days_valid;
        set v_trans_amount = v_trans_amount + v_aut_trans_amount + topup_amount;  
     SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
     
   
        if v_trans_amount > v_max_amount then
           set v_errcode = -1;  
    
    
     SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
           select IFNULL(message_text,'') INTO v_errmsg from message_config_text a where a.message_id = 1 and a.lang_code = lang_code;
 		insert into payment.payment_restrict_log(logdate,account_id,payment_agent,currency,topup_amount,trans_amount,errcode,errmsg,aut_trans_amount,appname,cc_no)
 		values(CURRENT_TIMESTAMP,account_id,payment_agent,currency,topup_amount,v_trans_amount,v_errcode,v_errmsg,v_aut_trans_amount,appname,cc_no);
         SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
           LEAVE sp_exit;
        end if;
        
     END sp_exit;
     select v_errcode as errcode,v_errmsg as errmsg;  
     
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `paypal_get_subscribtion_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `paypal_get_subscribtion_info`(
mobileno VARCHAR(20),  
firstlogin VARCHAR(12))
begin

   DECLARE v_SubscriptionID VARCHAR(150);  
   DECLARE v_purchasedate VARCHAR(150);  
   DECLARE v_currency VARCHAR(10);  
   DECLARE v_reference_id VARCHAR(50);  
  
   
   IF firstlogin is null 
   then
      set firstlogin = '';
   END IF;
   
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   token, purchasedate, IFNULL(currency,''), transaction_reference 
   INTO v_SubscriptionID,v_purchasedate,v_currency,v_reference_id from tSubscription_paypal where account_id = mobileno
   and ((purchasedate >= firstlogin) or (firstlogin = ''))   order by idx desc LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
  
   if v_currency = '' 
   then
 
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select   currency INTO v_currency from TPAYMENT where reference_id = v_reference_id    LIMIT 1;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
      
   end if;  
  
  
   select v_SubscriptionID as token,v_purchasedate as purchasedate,
	TopupAmount as topup_amount,case when TopupCurr = '' then v_currency else IFNULL(TopupCurr,v_currency) end as topup_currency,
	ProductID,v_currency as currency
   from  webPayment.tAuxAutoTopup a where a.mobileno = mobileno;  
   
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `paypal_insert_payment_transaction_detail` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `paypal_insert_payment_transaction_detail`(sitecode VARCHAR(5),   
productcode VARCHAR(20),   
paymentagent VARCHAR(12),   
ref_id  VARCHAR(150) ,   
servicetype VARCHAR(20),   
paymentmode VARCHAR(3),   
paymentstep INT,   
paymentstatus INT,   
accountid VARCHAR(32),  
last6digitccno VARCHAR(6),        
totalamount FLOAT,       
currency VARCHAR(3),      
merchantid VARCHAR(10),        
providercode VARCHAR(5),       
csreasoncode VARCHAR(30),     
generalerrorcode INT,  
message   VARCHAR(150),  
ip_payment_agent VARCHAR(50),  
ip_payment_client VARCHAR(50),  
email VARCHAR(250),  
paypal_transid VARCHAR(100),  
paypal_email_id VARCHAR(150),  
device_type VARCHAR(50),  
browser VARCHAR(100),  
os_version VARCHAR(100),  
topup_url VARCHAR(500),  
bundle_id INT)
begin

   
   
  
   DECLARE v_currenttime DATETIME(3);        
   DECLARE v_orderno INT;        
   DECLARE v_errorreturn INT;   
   
   DECLARE v_errcode INT;     
   DECLARE v_errmsg VARCHAR(250);
   DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
   BEGIN
      SET @SWV_Error = 1;
   END;  
   
     
   IF device_type is null then
      set device_type = '';
   END IF;
   IF browser is null then
      set browser = '';
   END IF;
   IF os_version is null then
      set os_version = '';
   END IF;
   IF topup_url is null then
      set topup_url = '';
   END IF;
   IF bundle_id is null then
      set bundle_id = 0;
   END IF;
   sp_exit:
   BEGIN
      IF device_type is null then
         set device_type = '';
      END IF;
      IF browser is null then
         set browser = '';
      END IF;
      IF os_version is null then
         set os_version = '';
      END IF;
      IF topup_url is null then
         set topup_url = '';
      END IF;
      IF bundle_id is null then
         set bundle_id = 0;
      END IF;
      SET @SWV_Error = 0;
      set v_currenttime = CURRENT_TIMESTAMP;
      set v_errcode = 0;
      set v_errmsg = 'Ok';
      if servicetype = 'CHILLITALK' OR sitecode = 'ST1' or sitecode = 'UFUK' then
         set servicetype = 'RES';
      end if;
      SET @SWV_Error = 0;
      INSERT INTO TPAYMENT(REFERENCE_ID,SITECODE,PAYMENT_AGENT,SERVICE_TYPE,PRODUCT_CODE,PAYMENT_MODE,ACCOUNT_ID,CC_NO,
 TOTALAMOUNT,CURRENCY,CREATED_DATE,CURRENT_STATUS,LAST_STEP,MERCHANT_ID,PROVIDER_CODE,LAST_GENERAL_ERROR_CODE,
 IPpaymentagent,IPClient,ReplyMessage,email,device_type,browser,os_version,topup_url,bundle_id)
        VALUES(ref_id,sitecode,paymentagent,servicetype,productcode,paymentmode,accountid,last6digitccno,totalamount,
 currency, v_currenttime, paymentstatus, paymentstep, merchantid,providercode, generalerrorcode,ip_payment_agent,
 ip_payment_client,message,email,device_type,browser,os_version,topup_url,bundle_id);
 
      if @SWV_Error <> 0 then
 
         LEAVE sp_exit;
      end if;
      SET @SWV_Error = 0;
      INSERT INTO TCS_PAYMENT_DETAIL(REFERENCE_ID, LAST_CS_ERROR_CODE)
 VALUES(ref_id, csreasoncode);
 
      if @SWV_Error <> 0 then
 
         LEAVE sp_exit;
      end if;
      INSERT INTO TCS_TRANSACTION(REFERENCE_ID,CS_ERROR_CODE, EXECUTION_DATE, PAYMENT_STEP, PAYMENT_STATUS,GENERAL_ERROR_CODE)
 VALUES(ref_id, csreasoncode, v_currenttime, paymentstep, paymentstatus,generalerrorcode);   
   
 
 
      insert into paypal_transaction_log(trans_id,reference_id,paypal_email)
 values(paypal_transid,ref_id,paypal_email_id);


   END;
   SELECT v_errcode as errcode,v_errmsg as errmsg;  
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `paypal_insert_subscribtion_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `paypal_insert_subscribtion_info`(
account_id VARCHAR(20),  
token VARCHAR(80),  
purchas_date VARCHAR(50),  
trans_reference  VARCHAR(40),  
customer_id VARCHAR(50),  
currency VARCHAR(10))
BEGIN
   
   IF currency is null 
   then
      set currency = '';
   END IF;
   
   IF NOT EXISTS(SELECT  1 FROM tSubscription_paypal a WHERE a.account_Id = account_id
   and a.token = token LIMIT 1) 
   then
 
    INSERT INTO tSubscription_paypal(account_Id,token,purchasedate,transaction_reference,customer_id,currency)
    VALUES(account_id,token,purchas_date,trans_reference,customer_id,currency);
  
      SELECT 0 errcode, 'Success' errmsg;
   Else
      SELECT -1 errcode, 'Failure' errmsg;
   end if;   
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `paysafe_error_msg_get` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `paysafe_error_msg_get`(paysafe_code VARCHAR(10))
begin

  
  
   IF  CHAR_LENGTH(IFNULL(paysafe_code,'')) = 0 then
   
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select idx,paysafe_code,paysafe_descript from paysafe_error_master;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   ELSE
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select idx,paysafe_code,paysafe_descript from paysafe_error_master a 
      where a.paysafe_code = paysafe_code;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   end if;  
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `PaySafe_Get_Pnurl_Log` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `PaySafe_Get_Pnurl_Log`(
mobileno VARCHAR(20) ,    
refId VARCHAR(40))
Begin
    
   DECLARE v_Errcode INT;  
   DECLARE v_Errmsg VARCHAR(30); 
   DECLARE v_SerialNumbers VARCHAR(600); 
   DECLARE v_EventType VARCHAR(100);
   DECLARE v_ISDebited INT;
   DECLARE Swv_RowCount INT;    
    
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   SerialNumbers, EventType, ISDebited INTO v_SerialNumbers,v_EventType,v_ISDebited 
   from  PaySafe_Pnurl_Log a where a.mobileno = mobileno and Reference_Id = refId    LIMIT 1;
   SET Swv_RowCount = ROW_COUNT();
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
    
   if Swv_RowCount > 0 
   then 
      SET v_Errcode = 0;
      SET v_Errmsg = 'Success';
   end if;    
   
   if ROW_COUNT() = 0 
   then 
      SET v_Errcode = -1;
      SET v_Errmsg = 'failure';
   end if;    
    
   Select v_SerialNumbers SerialNumbers,v_EventType EventType,v_ISDebited ISDebited ,v_Errcode Errcode,v_Errmsg Errmsg;    
     
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `paysafe_insert_payment_transaction_detail` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `paysafe_insert_payment_transaction_detail`(
sitecode VARCHAR(5), 
productcode VARCHAR(20), 
paymentagent VARCHAR(12), 
ref_id  VARCHAR(150) , 
servicetype VARCHAR(4), 
paymentmode VARCHAR(3), 
paymentstep INT, 
paymentstatus INT, 
accountid VARCHAR(32),
last6digitccno VARCHAR(6),      
totalamount FLOAT,     
currency VARCHAR(3),    
merchantid VARCHAR(10),      
providercode VARCHAR(5),     
csreasoncode VARCHAR(30),   
generalerrorcode INT)
begin


   DECLARE v_currenttime DATETIME(3);      
   DECLARE v_orderno INT;      
   DECLARE v_errorreturn INT;   
   DECLARE v_errcode INT; 
   DECLARE v_errmsg VARCHAR(150);
   DECLARE v_replymessage VARCHAR(150);
   DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
   BEGIN
      SET @SWV_Error = 1;
   END;
	
   
   sp_exit:
   BEGIN
      SET @SWV_Error = 0;
      set v_currenttime = CURRENT_TIMESTAMP;
      set v_errcode = -1;
      set v_errmsg = 'Failure to insert tpayment';
      set v_replymessage = 'Transaction Succeeded.';
      if generalerrorcode <> 0 AND generalerrorcode <> 100 then
	
         set v_replymessage = 'Transaction Failed.';
      end if;
      SET @SWV_Error = 0;
      INSERT INTO  TPAYMENT(REFERENCE_ID,SITECODE,PAYMENT_AGENT,SERVICE_TYPE,PRODUCT_CODE,PAYMENT_MODE,ACCOUNT_ID,CC_NO,
	TOTALAMOUNT,CURRENCY,CREATED_DATE,CURRENT_STATUS,LAST_STEP,MERCHANT_ID,PROVIDER_CODE,LAST_GENERAL_ERROR_CODE,ReplyMessage)
        VALUES(ref_id,sitecode,paymentagent,servicetype,productcode,paymentmode,accountid,last6digitccno,totalamount,
	currency, v_currenttime, paymentstatus, paymentstep, merchantid,providercode, generalerrorcode,v_replymessage);
	
      if @SWV_Error <> 0 then
	
         LEAVE sp_exit;
      end if;
      SET @SWV_Error = 0;
      INSERT INTO  TCS_PAYMENT_DETAIL(REFERENCE_ID, LAST_CS_ERROR_CODE)
	VALUES(ref_id, csreasoncode);
	
      if @SWV_Error <> 0 then
	
         LEAVE sp_exit;
      end if;
      INSERT INTO  TCS_TRANSACTION(REFERENCE_ID,CS_ERROR_CODE, EXECUTION_DATE, PAYMENT_STEP, PAYMENT_STATUS,GENERAL_ERROR_CODE,ReplyMessage)
	VALUES(ref_id, csreasoncode, v_currenttime, paymentstep, paymentstatus,generalerrorcode,v_replymessage);
	
      set v_errcode = 0;
      set v_errmsg = 'Success to insert tpayment';
   END;
   select v_errcode as errcode,v_errmsg as errmsg;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `PaySafe_Insert_Pnurl_Log` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `PaySafe_Insert_Pnurl_Log`(
mobileNo varchar(20) ,
refId varchar(40) ,
serialNumbers varchar(600) ,
eventType varchar(100) ,
ISDebited Int
)
Begin

Declare Errcode int;
Declare Errmsg varchar(30); 

Insert into PaySafe_Pnurl_Log (mobileno,Reference_Id,SerialNumbers,EventType,ISDebited,CreateDate)
values (mobileNo,refId,serialNumbers,eventType,ISDebited,current_timestamp);
                              

	if row_count() = 0 then
		set Errcode = -1;
		set Errmsg ='failure';
	else
		set Errcode = 0;
		set Errmsg ='Success';
	end if;

 Select Errcode as Errcode,Errmsg as Errmsg;

End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `paysafe_payment_log_insert` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `paysafe_payment_log_insert`(
mobileno VARCHAR(32) ,
REFERENCE_ID VARCHAR(64),
Pay_step INT,
Pay_code INT ,
Pay_decision VARCHAR(100) ,
Pay_description VARCHAR(500) ,
Pay_stage VARCHAR(150))
begin


	 Insert into  paysafe_payment_log(mobile_no,reference_id,Pay_step,Pay_code,Pay_decision,Pay_description,Pay_stage,created_date)
	Values(mobileno,REFERENCE_ID,Pay_step,Pay_code,Pay_decision,Pay_description,Pay_stage,CURRENT_TIMESTAMP);
	
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `paysaf_insert_ctp_transaction_log` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `paysaf_insert_ctp_transaction_log`(
reference_id VARCHAR(50),  
country VARCHAR(50),  
actual_amount FLOAT,  
vat_amount FLOAT,  
total_amount FLOAT)
begin

  
  
   
   DECLARE v_now DATETIME(3);   
   DECLARE v_errcode INT;  
   DECLARE v_errormsg VARCHAR(60);  
     
   DECLARE v_accountid VARCHAR(20);  
   DECLARE v_balance FLOAT;   
   
   
   select   account_id INTO v_accountid from TPAYMENT a where a.reference_id = reference_id    LIMIT 1;  
   
 
   select   cast(IFNULL(b.balance,0)/100 as DECIMAL(10,2)) INTO v_balance from esp.res_account  a
   join  esp.account b on a.custcode = b.custcode and a.batchcode = b.batchcode and
   a.serialcode = b.serialcode and b.telcocode = 'ics'
   and a.accountid = v_accountid;   
  
   set v_now = CURRENT_TIMESTAMP;  
   set v_errcode = -1;  
   set v_errormsg = 'Failure to insert the ctp_transaction_log';  
  
   if not exists(select  1 from  CTP_Transactions_Log where pay_reference = reference_id LIMIT 1) then
 
    insert into CTP_Transactions_Log(logdate,pay_reference,country,total_amount,vat,actual_value,current_bal)
  values(v_now,reference_id,country,total_amount,vat_amount,actual_amount,v_balance);
  
      if ROW_COUNT() > 0 then
  
         set v_errcode = 0;
         set v_errormsg = 'Success to insert the ctp_transaction_log';
      end if;
   end if;   
  
   select v_errcode as errcode,v_errormsg as errmsg;  
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `paysaf_insert_merchant_ref_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `paysaf_insert_merchant_ref_details`(
sitecode VARCHAR(10),
applicationcode VARCHAR(10),
reference_id VARCHAR(150),
accountid VARCHAR(20),
email VARCHAR(50),
amount FLOAT,
vat_amount FLOAT,
vatPercentage FLOAT,
total_amount VARCHAR(20),
IPClient VARCHAR(100),
currency VARCHAR(10),
OrderNumber VARCHAR(20),
mobile VARCHAR(20),
name VARCHAR(20),
street VARCHAR(50),
city VARCHAR(50),
postCode VARCHAR(50),
country VARCHAR(50),
pnURL VARCHAR(200),
OkUrl VARCHAR(200),
NokUrl VARCHAR(200))
begin



   if not exists(select  1 from  paysaf_merchant_ref_details a where a.reference_id = reference_id LIMIT 1) then
	
		  insert into paysaf_merchant_ref_details(sitecode,applicationcode,reference_id,accountid,email,amount,vat_amount,vatPercentage,
		total_amount,IPClient,currency,OrderNumber,mobile,name,street,city,postCode,country,pnURL,OkUrl,NokUrl)
		values(sitecode,applicationcode,reference_id,accountid,email,amount,vat_amount,vatPercentage,total_amount,IPClient,currency,
		OrderNumber,mobile,name,street,city,postCode,country,pnURL,OkUrl,NokUrl);
   end if; 
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `paysaf_insert_transaction_log` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `paysaf_insert_transaction_log`(
mobileno VARCHAR(20),  
reference_id VARCHAR(100),  
processname VARCHAR(100),  
user_currency VARCHAR(5),  
card_currency  VARCHAR(5),  
user_amount FLOAT,  
converted_amount FLOAT,  
card_balance FLOAT,  
calledby VARCHAR(20),  
paysaf_errcode INT,  
paysaf_errmsg VARCHAR(250))
begin

  
  
   
  
   DECLARE v_now DATETIME(3);   
   
   set v_now = CURRENT_TIMESTAMP;  
  
   insert into paysaf_transaction_log(logdate,processname,mobileno,reference_id,user_currency,card_currency,user_amount,converted_amount,card_balance,
 process_by,errcode,errmsg)
 values(v_now,processname,mobileno,reference_id,user_currency,card_currency,user_amount,converted_amount,card_balance,calledby,paysaf_errcode,paysaf_errmsg);  
  
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `realx_threeds_payment_log_insert` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `realx_threeds_payment_log_insert`(
mobileno VARCHAR(32) ,  
REFERENCE_ID VARCHAR(64),  
Pay_step INT,  
Pay_code INT ,  
Pay_decision VARCHAR(100) ,  
Pay_description VARCHAR(500) ,  
Pay_stage VARCHAR(150))
begin


  Insert into threeDS_payment_log(mobileno,reference_id,Pay_step,Pay_code,Pay_decision,Pay_description,Pay_stage,created_date)
 Values(mobileno,REFERENCE_ID,Pay_step,Pay_code,Pay_decision,Pay_description,Pay_stage,CURRENT_TIMESTAMP);  
   
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `reasoncode_get_by_provider_reason_code` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `reasoncode_get_by_provider_reason_code`(
providercode varchar(5),
providerreasoncode varchar(30)
)
begin

SELECT General_Error_Code,Provider_Reason_Code,Provider_Message,Possible_Action,Payment_Status,Provider_Code
FROM REF_REASON_CODE a
where a.Provider_Code = providercode and Provider_Reason_Code = providerreasoncode;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `rlx_auto_renew_subscribtion_id` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `rlx_auto_renew_subscribtion_id`(
mobileno VARCHAR(30),  
payment_reference VARCHAR(50))
BEGIN

      
    
   DECLARE v_cc_no VARCHAR(10);   
   DECLARE v_account_id VARCHAR(50);  
   DECLARE v_CURRENCY VARCHAR(3);  
   DECLARE v_email_id VARCHAR(250);  
   
   DECLARE v_payment_type INT;   

   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   CC_NO, ACCOUNT_ID, currency, IFNULL(email,'') INTO v_cc_no,v_account_id,v_CURRENCY,v_email_id from TPAYMENT 
   where REFERENCE_ID = payment_reference   order by CREATED_DATE desc LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
   
 
   if payment_reference like '%RX%' then
      set v_payment_type = 1;
   end if;  
   
 
   if payment_reference like '%PPL%' then
      set v_payment_type = 2;
   end if;  
    
    
   
 
   if v_payment_type = 1 then
 
      IF mobileno in('436889478726','436889478734') then
   
         SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
         select Account_Id,CONCAT(SubscriptionID,'test'),purchasedate,expirydate,v_CURRENCY as TopupCurr,Last6digitsCC,
    IFNULL(v_email_id,'') as email,v_payment_type as payment_type from tSubscription
         where Account_Id = v_account_id and Last6digitsCC = v_cc_no;
         SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
      ELSE
         SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
         select Account_Id,SubscriptionID,purchasedate,expirydate,v_CURRENCY as TopupCurr,Last6digitsCC,
    IFNULL(v_email_id,'') as email,v_payment_type as payment_type from tSubscription
         where Account_Id = v_account_id and Last6digitsCC = v_cc_no;
         SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
      end if;
   end if;  
  
 
   if v_payment_type = 2 then
 
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select Account_Id,token AS SubscriptionID,purchasedate AS purchasedate,NULL expirydate,currency as TopupCurr,'' Last6digitsCC,
   IFNULL(v_email_id,'') as email,v_payment_type as payment_type  from tSubscription_paypal
      where  transaction_reference = payment_reference;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   end if;  
        
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `rlx_auto_renew_subscribtion_id_validate` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `rlx_auto_renew_subscribtion_id_validate`(
mobileno VARCHAR(30),
first_update DATETIME(3),
OUT payment_reference VARCHAR(50)  ,
OUT subsid_found INT     ,
purchase_pay_ref VARCHAR(50))
SWL_return:
BEGIN

  
   DECLARE v_cc_no VARCHAR(10); 
   DECLARE v_account_id VARCHAR(50);
   DECLARE v_CURRENCY VARCHAR(3);
   DECLARE v_email_id VARCHAR(250);
	
   DECLARE v_payment_type INT;
   DECLARE Swv_RowCount INT; 
	
   IF purchase_pay_ref is null then
      set purchase_pay_ref = '';
   END IF;
   set subsid_found = 0;

	
   IF purchase_pay_ref like '%PPL%' then
	
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select   1, transaction_reference INTO subsid_found,payment_reference 
      from  tSubscription_paypal where account_Id = mobileno and transaction_reference = purchase_pay_ref   order by idx desc LIMIT 1;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
      IF subsid_found = 1 then
         LEAVE SWL_return;
      end if;
   end if;
	
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   CC_NO, ACCOUNT_ID, currency, IFNULL(email,''), reference_id 
   INTO v_cc_no,v_account_id,v_CURRENCY,v_email_id,payment_reference 
   from TPAYMENT where ACCOUNT_ID = mobileno and CREATED_DATE >= first_update
   and IFNULL(CC_NO,'') <> '' and LAST_GENERAL_ERROR_CODE IN(0,100) and ThreeDFlag = 1   order by CREATED_DATE desc LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
	
	
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   1 INTO subsid_found from tSubscription where Account_Id = v_account_id and Last6digitsCC = v_cc_no;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
    
   if subsid_found = 0 and purchase_pay_ref like '%RX%' then
    
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select   CC_NO, ACCOUNT_ID, currency, IFNULL(email,''), reference_id 
      INTO v_cc_no,v_account_id,v_CURRENCY,v_email_id,payment_reference 
      from TPAYMENT where REFERENCE_ID = purchase_pay_ref   order by CREATED_DATE desc LIMIT 1;
     
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
      if found_rows() > 0 then
		
         SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
         select   1 INTO subsid_found from tSubscription where Account_Id = v_account_id and Last6digitsCC = v_cc_no;
         SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
      end if;
   end if;
    
    
   if subsid_found = 0 then
    
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select   1, transaction_reference 
      INTO subsid_found,payment_reference
      from tSubscription_paypal
      where account_Id = mobileno and purchasedate >= DATE_FORMAT(first_update,'%Y%m%d')   order by idx desc LIMIT 1;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   end if;
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `rlx_auto_topup_subscribtion_id_validate` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `rlx_auto_topup_subscribtion_id_validate`(
	msisdn VARCHAR(30),  
OUT subsid_found INT)
BEGIN      
  
   DECLARE v_idx INT;       
   DECLARE v_SubscriptionID VARCHAR(40);  
   DECLARE v_cc_no VARCHAR(20);   
   DECLARE v_aut_flag INT;     
   declare v_default_int_val int;
   
   set v_default_int_val = 0;
    
   set subsid_found = 0;  
        
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   idx INTO v_idx from tSubscription where Account_Id = msisdn   order by convert(purchasedate,DATETIME(3)) desc LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;      
       
   SET v_idx = IFNULL(v_idx,v_default_int_val);      
         
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   SubscriptionID, IFNULL(Last6digitsCC,'') INTO v_SubscriptionID,v_cc_no from tSubscription where idx = v_idx;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;         
    
  
    
 
 
 
 
  
 
   if IFNULL(v_SubscriptionID,'') = '' 
   then
  
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select   token INTO v_SubscriptionID from tSubscription_paypal where account_Id = msisdn   order by idx desc;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
      
   end if;  
   
   if IFNULL(v_SubscriptionID,'') <> '' 
   then
 
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select   1 INTO subsid_found from webPayment.tAuxAutoTopup where mobileno = msisdn    LIMIT 1;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
      
   end if;  
   
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Rxpaym_cc_payment_getsubscriptionlist_AT` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `Rxpaym_cc_payment_getsubscriptionlist_AT`(
 account_id VARCHAR(30))
BEGIN  
   
    DECLARE v_is_realx INT;   
    DECLARE v_topup_currency VARCHAR(20);  
    DECLARE v_SubscriptionID VARCHAR(100);  
    DECLARE v_email VARCHAR(150);  
    DECLARE v_iccid VARCHAR(20);  
    DECLARE v_pay_reference VARCHAR(50);  
    DECLARE v_pp_customer_id INT;  
    DECLARE v_CC_NO VARCHAR(10);  
    DECLARE v_counter INT;  
    DECLARE v_ORDER_REFERENCE VARCHAR(50);   
    DECLARE v_purchase_date DATETIME(3);  
    DECLARE v_purchase_format VARCHAR(250);     
    DECLARE v_activate_date VARCHAR(50);
    
    drop TEMPORARY table IF EXISTS  tt_paym_subscribtion_info;  
    create TEMPORARY table tt_paym_subscribtion_info
    (
       subscribtionid VARCHAR(100),
       ccdc_no VARCHAR(10),
       account_id VARCHAR(20)
    );  
   
    set v_counter = 0;  
       
    select   DATE_FORMAT(activatedate,'%Y%m%d'), pp_customer_id INTO v_activate_date,v_pp_customer_id 
    from crm.pp_customers where mobileno = account_id   order by pp_customer_id desc LIMIT 1;   
    
    if  exists(select  1 from tSubscription a where a.account_id = account_id LIMIT 1) 
    then
   
       insert into tt_paym_subscribtion_info(subscribtionid,ccdc_no,account_id)
       Select  a.SubscriptionID,a.last6digitscc,a.account_id From tSubscription a
       where a.account_id = account_id 
       and ((IFNULL(v_pp_customer_id,0) <> 0 and a.purchasedate >= v_activate_date) or (IFNULL(v_pp_customer_id,0) = 0)) 
       order by idx desc LIMIT 1;
       
    end if;        
   
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select   count(1) INTO v_counter from tt_paym_subscribtion_info;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
     
    if v_counter = 0 
    then
  
       CALL crm.freesim_with_bundle_get_order_ref(account_id,v_ORDER_REFERENCE);
       
       IF IFNULL(v_ORDER_REFERENCE,'') <> '' 
       then     
     
     
          SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
          select   CC_NO, CREATED_DATE, a.ACCOUNT_ID INTO v_CC_NO,v_purchase_date,account_id from TPAYMENT a 
          where REFERENCE_ID = v_ORDER_REFERENCE    LIMIT 1;
          SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
          
          set v_purchase_format = DATE_FORMAT(v_purchase_date,'%Y%m%d');
          
          insert into tt_paym_subscribtion_info(ACCOUNT_ID,subscribtionid,ccdc_no)
          Select  a.ACCOUNT_ID,a.SubscriptionID,v_CC_NO From tSubscription a
          where (a.last6digitscc = v_CC_NO AND a.ACCOUNT_ID = account_id AND
          a.purchasedate = v_purchase_format) 
          order by idx desc LIMIT 1;
          
       end if;
       
    end if;  
      
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select account_id,subscribtionid,ccdc_no as last6digitscc
    from tt_paym_subscribtion_info;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;   
 
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Rxpaym_cc_payment_getsubscriptionlist_crm` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `Rxpaym_cc_payment_getsubscriptionlist_crm`(
account_id varchar(30)
)
BEGIN


	declare is_realx int; 
	declare topup_currency varchar(20);
	declare SubscriptionID varchar(100);
	declare email varchar(150);
	declare iccid varchar(20);
	declare pay_reference varchar(50);
	declare pp_customer_id int;
	declare CC_NO varchar(10);
	declare counter int;
	declare ORDER_REFERENCE varchar(50);
	declare purchase_date datetime;
	declare purchase_format varchar(250);

	drop temporary table if exists paym_subscribtion_info;
	create temporary table paym_subscribtion_info
	(
		account_id varchar(50),
		subscriptionid varchar(100),
		ccdc_no varchar(10),
		expirydate varchar(150),
		purchasedate varchar(150),
		provider_code varchar(10),
		idx int,
		cvv_number varchar(5)
	);

	set counter=0;

			
			if not exists(select 1 from payment.tSubscription a where a.account_id=account_id and isnumeric(a.SubscriptionID)<>1 ) then
				select max(a.pp_customer_id) into pp_customer_id from crm.pp_customers a where a.mobileno=account_id;  
					
				select a.pay_reference into pay_reference from crm.pp_payments a
				where a.pp_customer_id=pp_customer_id and a.pay_method like '%credit%or%debit%'limit 1;
					 
				
                drop temporary table if exists temp_tpayment_detail_info;
				create temporary table temp_tpayment_detail_info as
				select * from payment.TPAYMENT a where a.REFERENCE_ID=pay_reference;
					
				select a.ACCOUNT_ID,a.CC_NO into ACCOUNT_ID,CC_NO from temp_tpayment_detail_info a where a.REFERENCE_ID = pay_reference ;
					
				insert into paym_subscribtion_info(account_id,subscriptionid,ccdc_no,expirydate,purchasedate, provider_code,idx,cvv_number)
				Select a.account_id,a.SubscriptionID,CC_NO,a.expirydate,a.purchasedate, a.provider_code,a.idx,a.cvv_number 
				From payment.tSubscription a
				where (a.last6digitscc = CC_NO or a.ACCOUNT_ID=ACCOUNT_ID) and 
				isnumeric(a.SubscriptionID)<>1  order by a.idx desc	limit 1;
		
			else
				insert into paym_subscribtion_info(account_id,subscriptionid,ccdc_no,expirydate,purchasedate,provider_code,idx,cvv_number)
				Select a.account_id,a.SubscriptionID,a.last6digitscc,a.expirydate,a.purchasedate,
				a.provider_code,a.idx,a.cvv_number From payment.tSubscription a
				where a.account_id=ACCOUNT_ID and isnumeric(a.SubscriptionID)<>1 order by idx  desc limit 1;
	
			end if;

	select count(1) into counter from paym_subscribtion_info a;
	
	if counter=0 then
	
		call crm.freesim_with_bundle_get_order_ref (account_id,ORDER_REFERENCE);
				
			IF ifnull(ORDER_REFERENCE,'')<>'' then
				
				select a.CC_NO,a.CREATED_DATE,a.ACCOUNT_ID  
				into CC_NO,purchase_date,ACCOUNT_ID  
				from payment.TPAYMENT a where a.REFERENCE_ID=ORDER_REFERENCE limit 1;
							
				set purchase_format=DATE_FORMAT(purchase_date, '%Y%m%d');
				
				insert into paym_subscribtion_info(account_id,subscriptionid,ccdc_no,expirydate,purchasedate, provider_code,idx,cvv_number)
				Select a.Account_Id,a.SubscriptionID,CC_NO,a.expirydate,a.purchasedate,a.provider_code,a.idx,a.cvv_number 
				From payment.tSubscription a
				where (a.last6digitscc = CC_NO AND a.Account_Id=ACCOUNT_ID AND a.purchasedate=purchase_format) 
				and isnumeric(a.SubscriptionID)<>1 order by a.idx desc limit 1;
			
			END if;
		
			SELECT a.account_id,a.subscriptionid,a.ccdc_no AS last6digitscc,
			a.expirydate,a.purchasedate,a.provider_code,a.idx,a.cvv_number from paym_subscribtion_info a;
	
	else
		select a.account_id,a.subscriptionid,a.ccdc_no AS last6digitscc,a.expirydate,a.purchasedate, a.provider_code,a.idx,a.cvv_number 
		from paym_subscribtion_info a;
	end if;
	
	drop temporary table  if exists paym_subscribtion_info;
			 
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Rxpaym_generate_payment_reference` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `Rxpaym_generate_payment_reference`(
sitecode VARCHAR(5), 
  applicationcode VARCHAR(20),
  productcode VARCHAR(20),
  payment_type INT)
begin
  	
  
  	
     DECLARE orderno INT;  
     DECLARE ref_id VARCHAR(50);
     
     IF payment_type is null then set payment_type = 1; END IF;
     
     if exists(select 1 from payment_sitecode_mapping a where a.sitecode = sitecode LIMIT 1) then
        select payment_sitecode INTO sitecode from payment_sitecode_mapping a where a.sitecode = sitecode;
     end if; 
  
      select payment_getCounterRefID_V2(sitecode,'CS') into orderno; 
      
  	
        
     if (applicationcode is not null) then
        set ref_id = CONCAT(applicationcode,'-',productcode,'-RX','-',cast(orderno as CHAR(10)));
     else
        set ref_id = CONCAT(sitecode,'-',productcode,'-RX','-',cast(orderno as CHAR(10)));
     end if; 
  		
  	
  	
     if payment_type = 2 then
  	
        if (applicationcode is not null) then
           set ref_id = CONCAT_WS('',applicationcode,'-',productcode,'-PPL','-',cast(orderno as CHAR(10)));
        else
           set ref_id = CONCAT_WS('',sitecode,'-',productcode,'-PPL','-',cast(orderno as CHAR(10)));
        end if;
     end if;
     
     
     if payment_type=3
 	then
 	
 		 if (applicationcode is not null)    then  
 			set ref_id = CONCAT_WS('',applicationcode,'-',productcode,'-EP','-',cast(orderno as CHAR(10)));    
 		else      
 			set ref_id = CONCAT_WS('',sitecode,'-',productcode,'-EP','-',cast(orderno as CHAR(10)));
 	
 	end if;
  		 	end if; 
  		  
  
     select ref_id as ref_id;
  
  end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `rxpaym_PaymentInsert_v1` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `rxpaym_PaymentInsert_v1`(
reference_id varchar(32),
sitecode varchar(5),
productcode varchar(25),
paymentagent varchar(12),
servicetype varchar(4),
paymentmode varchar(3),
paymentstep int,
paymentstatus int,
accountid varchar(32),
last6digitccno varchar(6),
totalamount float,
currency varchar(3),
subscriptionid varchar(40),
merchantid varchar(10),
providercode varchar(5),
csreasoncode varchar(30),
generalerrorcode int,
email varchar(150),
IPpaymentagent varchar(150),
ReplyMessage varchar(250),
srd varchar(100)
)
Begin
	declare currenttime datetime;
	declare ref_id int;
    declare errcode int;
    
    set errcode = 1;


sp_exit : begin

	if email is null 				then set email = ''; 				end if;
	if IPpaymentagent is null 		then set IPpaymentagent = ''; 		end if;
	if ReplyMessage is null 		then set ReplyMessage = ''; 		end if;
	if srd is null 					then set srd = ''; 					end if;
    
	START TRANSACTION;
    
	set currenttime = current_timestamp; 

	if generalerrorcode=7 		then set generalerrorcode=0;						end if;
	if generalerrorcode=5 		then set generalerrorcode=-1;						end if;
	if length(last6digitccno)=6 	then set last6digitccno=RIGHT(last6digitccno,4);	end if;

	INSERT INTO TPAYMENT(REFERENCE_ID,SITECODE,PAYMENT_AGENT,SERVICE_TYPE,PRODUCT_CODE,PAYMENT_MODE,ACCOUNT_ID,CC_NO,TOTALAMOUNT,CURRENCY,CREATED_DATE,
	SUBSCRIPTIONID,CURRENT_STATUS,LAST_STEP,MERCHANT_ID,PROVIDER_CODE,LAST_GENERAL_ERROR_CODE ,ReplyMessage,srd)
	VALUES(reference_id,sitecode, paymentagent, servicetype, productcode, paymentmode, accountid, last6digitccno, totalamount, currency, currenttime,
	subscriptionid, paymentstatus, paymentstep, merchantid, providercode, generalerrorcode, ReplyMessage, srd);

	set ref_id = LAST_INSERT_ID();

	if row_count() = 0 then
		set errcode = 0;
        leave sp_exit;
	end if;

	INSERT INTO TCS_PAYMENT_DETAIL(REFERENCE_ID, LAST_CS_ERROR_CODE) VALUES(reference_id, csreasoncode);
    
	if row_count() = 0 then
		set errcode = 0;
        leave sp_exit;
	end if;

	INSERT INTO TCS_TRANSACTION(REFERENCE_ID,CS_ERROR_CODE,EXECUTION_DATE,PAYMENT_STEP,PAYMENT_STATUS,GENERAL_ERROR_CODE)
	VALUES(reference_id, csreasoncode, currenttime, paymentstep, paymentstatus, generalerrorcode);

	if row_count() = 0 then
		set errcode = 0;
        leave sp_exit;
	end if;
    
	COMMIT WORK;
   
end sp_exit;
		select errcode;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `RXReceipitInInsert` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `RXReceipitInInsert`( 
 sitecode varchar(5),
 productcode varchar(20),
 applicationcode varchar(12),
 paymentagent varchar(12),
 servicetype varchar(4),
 paymentmode varchar(3),
 paymentstep int,
 paymentstatus int,
 accountid varchar(32),
 totalamount float,
 currency varchar(3),
 subscriptionid varchar(40),
 merchantid varchar(10),
 providercode varchar(5),
 csreasoncode varchar(30), 
 generalerrorcode int, 
 out returnerror int, 
 sendToProduction varchar(5), 
 IPpaymentagent varchar(20), 
 IPClient varchar(20),
 ref_id varchar (32)
 )
Begin
 	declare currenttime datetime; 
 	declare orderno int ;
 	declare errorreturn int;
     declare ref_id_val varchar(32);
     
 	set returnerror = 0;
 	set currenttime = now(3);
 	
  sp_exit : begin
     
      if productcode = null 		then set productcode = 'AUTOTOPUP'; 	end if;
      if applicationcode = '' 	then set applicationcode = null; 		end if;
      if sendToProduction = '' 	then set sendToProduction = null; 		end if;
      if IPpaymentagent = '' 	then set IPpaymentagent = null; 		end if;
      if IPClient = '' 			then set IPClient = null; 				end if;
      if ref_id = '' 			then set ref_id = null; 				end if;
      
      set ref_id_val = ref_id;
 
 	START TRANSACTION;
  
  select * from RX_RECEIPTIN_PAYMENT limit 10;
  
 	INSERT INTO RX_RECEIPTIN_PAYMENT( REFERENCE_ID ,SITECODE ,PAYMENT_AGENT ,SERVICE_TYPE ,PRODUCT_CODE ,PAYMENT_MODE ,ACCOUNT_ID ,CC_NO ,TOTALAMOUNT 
 	,CURRENCY ,CREATED_DATE ,SUBSCRIPTIONID ,CURRENT_STATUS ,LAST_STEP ,MERCHANT_ID ,PROVIDER_CODE ,LAST_GENERAL_ERROR_CODE ,sendToProduction ,email  
 	,IPpaymentagent ,IPClient ) 
 	VALUES( ref_id ,sitecode ,paymentagent ,servicetype ,productcode ,paymentmode ,accountid ,'',totalamount ,currency ,currenttime ,subscriptionid 
 	,paymentstatus ,paymentstep ,merchantid ,providercode ,generalerrorcode ,sendToProduction ,'',IPpaymentagent ,IPClient ); 
 	 
  	if row_count() = 0 then
  		set ref_id_val = '0';
          leave sp_exit;
  	end if;
  
 	INSERT INTO RX_RECEIPTIN_DETAIL(REFERENCE_ID, LAST_CS_ERROR_CODE) VALUES( ref_id , csreasoncode);
  
  	if row_count() = 0 then
  		set ref_id_val = '0';
          leave sp_exit;
  	end if;
  
 	INSERT INTO RX_RECEIPTIN_TRANSACTION( REFERENCE_ID ,CS_ERROR_CODE ,EXECUTION_DATE ,PAYMENT_STEP ,PAYMENT_STATUS ,GENERAL_ERROR_CODE) 
 	VALUES( ref_id ,csreasoncode ,currenttime ,paymentstep ,paymentstatus ,generalerrorcode);
 	 
  	if row_count() = 0 then
  		set ref_id_val = '0';
          leave sp_exit;
  	end if;
     
     	COMMIT WORK;
         
 	end sp_exit;
  		select ref_id_val as ref_id;
  end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Rx_cc_payment_getsubscriptionlist` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `Rx_cc_payment_getsubscriptionlist`(
account_id VARCHAR(30))
BEGIN 
   
   DECLARE v_is_realx INT;   
   DECLARE v_topup_currency VARCHAR(20);  
   DECLARE v_SubscriptionID VARCHAR(100);  
   DECLARE v_email VARCHAR(150);  
   DECLARE v_iccid VARCHAR(20);  
   DECLARE v_pay_reference VARCHAR(50);  
   DECLARE v_pp_customer_id INT;  
   DECLARE v_CC_NO VARCHAR(10);
  
  
  insert into tbl_test_logu (account_id) values(account_id);  
  
   drop TEMPORARY table IF EXISTS tt_rx_subscribtion_info;  
   create TEMPORARY table tt_rx_subscribtion_info
   (
      subscribtionid VARCHAR(100),
      ccdc_no VARCHAR(10)
   );      
  
   if not exists(select  1 from tSubscription a where a.account_id = account_id LIMIT 1) 
   then
     
     
     
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select   a.ACCOUNT_ID, CC_NO INTO account_id,v_CC_NO from TPAYMENT a where a.account_id = account_id;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
      
      insert into tt_rx_subscribtion_info(subscribtionid,ccdc_no)
      Select  SubscriptionID,v_CC_NO From tSubscription a
      where (last6digitscc = v_CC_NO or a.ACCOUNT_ID = account_id) order by idx desc LIMIT 1;
      
   else
   
     insert into tt_rx_subscribtion_info(subscribtionid,ccdc_no)
      Select  SubscriptionID,last6digitscc From tSubscription a
      where a.account_id = account_id order by idx desc LIMIT 1;
      
   end if;        
           
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select subscribtionid,ccdc_no AS last6digitscc from tt_rx_subscribtion_info;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;            
      
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Rx_insert_mvno_payment_transaction` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `Rx_insert_mvno_payment_transaction`(
mobileno VARCHAR(20),    
merchant_reference  VARCHAR(150),    
topup_amount FLOAT,    
current_bal FLOAT,    
topup_status INT)
begin 
   
   DECLARE v_errcode INT;   
   DECLARE v_errormsg VARCHAR(100);  
  
   set v_errcode = -1;  
   set v_errormsg = 'failure to insert the payment transaction';  
    
   if not exists(select  1 from mvno_transaction_log a where a.mobileno = mobileno and reference_id = merchant_reference LIMIT 1) 

   then
   
   insert into mvno_transaction_log(mobileno,reference_id,current_bal,topup_amount,topup_status)
   values(mobileno,merchant_reference,current_bal,topup_amount,topup_status);
        
    
      if ROW_COUNT() > 0 
      then    
         set v_errcode = 0;
         set v_errormsg = 'success to insert the payment transaction';
      end if;
      
   end if;    
   
   select v_errcode as errcode,v_errormsg as errmsg;  
    
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SENDSMS_THREED_TRANSACTION_FAILURE_DAEMON` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `SENDSMS_THREED_TRANSACTION_FAILURE_DAEMON`()
BEGIN

  
   
      drop TEMPORARY table IF EXISTS tt_temp_order;  
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   CREATE TEMPORARY TABLE tt_temp_order AS select ACCOUNT_ID,REFERENCE_ID,CREATED_DATE,email  from TPAYMENT
      where DATE_FORMAT(CREATED_DATE,'%d/%m/%Y') = DATE_FORMAT(TIMESTAMPADD(day,-1,CURRENT_TIMESTAMP),'%d/%m/%Y')
      and LAST_GENERAL_ERROR_CODE = 475 AND ACCOUNT_ID REGEXP('^[+-.$.]?[[0-9,]+...]?$')
      AND CC_NO <> '989186' AND  CHAR_LENGTH(ACCOUNT_ID) >= 9;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
    
    drop TEMPORARY table IF EXISTS tt_temp;  
   CREATE TEMPORARY TABLE tt_temp AS select ACCOUNT_ID,max(CREATED_DATE) as CREATED_DATE,max(email) email  from tt_temp_order
      group by ACCOUNT_ID;  
  
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   delete a from tt_temp a
   join TPAYMENT b  on a.ACCOUNT_ID = b.ACCOUNT_ID
   and b.CREATED_DATE > a.CREATED_DATE
   and b.LAST_GENERAL_ERROR_CODE in(0,100) 
   and a.ACCOUNT_ID REGEXP('^[+-.$.]?[[0-9,]+...]?$');
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;   
   
   
   DELETE FROM THREED_TRANSACTION_FAILURE_DAEMON   where DATE_FORMAT(INSERT_DATE,'%d/%m/%Y') = DATE_FORMAT(CURRENT_TIMESTAMP,'%d/%m/%Y');  
   
   DROP TEMPORARY TABLE IF EXISTS tt_temp_sms_url;  
   
   CREATE TEMPORARY TABLE tt_temp_sms_url AS select distinct msisdn_Prefix,b.sitecode,sms_url  from crm3.sms_iwmsc_url a
      join crm3.Product_by_mobileno b on a.sitecode = b.sitecode;  
  
  
   INSERT INTO THREED_TRANSACTION_FAILURE_DAEMON(ACCOUNT_ID,email,sitecode,INSERT_DATE,sms_url)
   select ACCOUNT_ID,email,b.sitecode,CURRENT_TIMESTAMP,b.sms_url  from tt_temp a
   join tt_temp_sms_url b on b.msisdn_Prefix = left(ACCOUNT_ID, CHAR_LENGTH(b.msisdn_Prefix));  
   
   
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select DISTINCT ID,ACCOUNT_ID,sms_url,message_text,email from THREED_TRANSACTION_FAILURE_DAEMON A
   JOIN NOTIFY_SMS_CONFIG B ON A.SITECODE = B.SITECODE where DATE_FORMAT(INSERT_DATE,'%d/%m/%Y') = DATE_FORMAT(CURRENT_TIMESTAMP,'%d/%m/%Y');
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SENDSMS_THREED_TRANSACTION_FAILURE_DAEMON_REPORT` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `SENDSMS_THREED_TRANSACTION_FAILURE_DAEMON_REPORT`()
BEGIN

	select a.account_id as AccountId,
	case a.sms_id when 0  then 'Success' else 'Failure' end as SMSSent,
	case a.email_sent_flag when 0 then 'Sent' 
						 when 1 then 'Queued'
						 when 2 then 'Rejected' 
						 when 3 then 'Invalid'
						 when 4 then 'Scheduled' 
						 else 'Failure' end as  EmailSent 
FROM THREED_TRANSACTION_FAILURE_DAEMON a where DATE_FORMAT(a.insert_date,'%d/%m/%Y') = DATE_FORMAT(CURRENT_TIMESTAMP,'%d/%m/%Y');

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SENDSMS_THREED_TRANSACTION_UPDATE_FAILURE` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `SENDSMS_THREED_TRANSACTION_UPDATE_FAILURE`(
ID INT,  
email_sent_flag INT,
sms_id INT 
)
BEGIN

  
   UPDATE THREED_TRANSACTION_FAILURE_DAEMON a SET a.sms_id = sms_id,a.email_sent_flag = email_sent_flag
   WHERE a.ID = ID;   
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_autotupup_report` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ALLOW_INVALID_DATES' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sp_autotupup_report`(`date` VARCHAR(30))
BEGIN
 
   

    Set `date` = DATE_FORMAT(STR_TO_DATE(`date`,'%d/%m/%Y'),'%Y-%m-%d');    
   
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    SELECT ref_code,reg_date,mobileno,subscription_id,currency,threshold_amount,amount,decision,request_id,authorization_code,request_time,payment_status,payment_description,topup_status,topup_description,sorderid,reconciliation_id,srd 
    FROM  webPayment.tCybS_RegisteredPayment  WHERE DATE_FORMAT(reg_date,'%Y-%m-%d') = `date`;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;    
    
    
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_payment_log_by_ref` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sp_payment_log_by_ref`(payment_ref VARCHAR(150))
begin


   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select count(*) as result from  threeDS_payment_log where REFERENCE_ID = payment_ref and Pay_step = 4 and Pay_code = 100;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_Tpayment_NStatus_Report` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `SP_Tpayment_NStatus_Report`()
BEGIN

   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select REFERENCE_ID `Reference Id`,ACCOUNT_ID `Account Id` ,CC_NO `Card No`,3DStatus,CREATED_DATE `Date`,
 TotalAmount Amount,Currency,LAST_GENERAL_ERROR_CODE `Error Code`,'Reject' Status  from TPAYMENT 
 where cast(CREATED_DATE as DATE) = cast(TIMESTAMPADD(day,-1,CURRENT_TIMESTAMP) as DATE) and 3DStatus = 'N' 
 and IFNULL(CC_NO,'') not in('989186','038927')
   order by created_date asc;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_validate_3ds_enrolled` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sp_validate_3ds_enrolled`(
account_id VARCHAR(32),
 cc_no CHAR(6),
 sitecode	VARCHAR(5),
 payment_agent VARCHAR(12),
 service_type CHAR(4),
 amount FLOAT)
begin


   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select DISTINCT a.REFERENCE_ID from TPAYMENT a
   where EXTRACT(DAY FROM CREATED_DATE) = EXTRACT(DAY FROM CURRENT_TIMESTAMP) AND
   EXTRACT(MONTH FROM CREATED_DATE) = EXTRACT(MONTH FROM CURRENT_TIMESTAMP) AND
   EXTRACT(YEAR FROM CREATED_DATE) = EXTRACT(YEAR FROM CURRENT_TIMESTAMP)
   AND a.REFERENCE_ID LIKE '%-RX-%' AND a.ACCOUNT_ID = account_id AND a.CC_NO = cc_no AND a.TOTALAMOUNT = amount
   AND a.SITECODE = sitecode AND a.PAYMENT_AGENT = payment_agent AND a.SERVICE_TYPE = service_type 
   AND (a.ReplyMessage = '3ds enrolled' OR a.LAST_GENERAL_ERROR_CODE = 475 OR a.LAST_GENERAL_ERROR_CODE = 509 OR a.LAST_GENERAL_ERROR_CODE = 507);
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `subscriptionGetData` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `subscriptionGetData`(
        account_id VARCHAR(30),
	last6digitscc VARCHAR(6),
	provider_code VARCHAR(5))
BEGIN

   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select b.account_id, b.last6digitscc, b.subscriptionid, b.expirydate, b.purchasedate, b.provider_code, b.cvv_number
   from tSubscription b
   where b.account_id = account_id and b.last6digitscc = last6digitscc
   and b.provider_code = provider_code and subscriptionid is not null;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `subscriptionGetDatalast4digit` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `subscriptionGetDatalast4digit`(account_id VARCHAR(30),
last6digitscc VARCHAR(6),
provider_code VARCHAR(5))
BEGIN
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select a.Account_Id, a.Last6digitsCC, a.SubscriptionID, a.expirydate, a.purchasedate, a.provider_code, a.cvv_number
   from tSubscription a 
   where a.Account_Id = account_id and a.Last6digitsCC like CONCAT_WS('','%',last6digitscc,'%')
   and a.provider_code = provider_code and a.SubscriptionID is not null;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `subscriptionGetData_by_account` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `subscriptionGetData_by_account`(account_id VARCHAR(30),
	provider_code VARCHAR(5))
BEGIN
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select a.Account_Id, a.Last6digitsCC, a.SubscriptionID, a.expirydate, a.purchasedate, a.provider_code, a.cvv_number
   from tSubscription a
   where a.Account_Id = account_id
   and a.provider_code = provider_code;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `subscriptionGetData_by_cvv` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `subscriptionGetData_by_cvv`(
  account_id VARCHAR(30),  
  provider_code VARCHAR(5),  
  cvv_number VARCHAR(5))
BEGIN
 
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select a.account_id, a.last6digitscc, a.subscriptionid, a.expirydate, a.purchasedate, a.provider_code, IFNULL(a.cvv_number,cvv_number) as cvv_number
    from tSubscription a
    where a.account_id = account_id
    and a.provider_code = provider_code
    and (a.cvv_number = cvv_number or IFNULL(a.cvv_number,'') = '');
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SubscriptionNew` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `SubscriptionNew`(Account_Id VARCHAR(50),
Last6digitsCC VARCHAR(6),
SubscriptionID VARCHAR(50),
expirydate VARCHAR(6),
purchasedate VARCHAR(8),
provider_code VARCHAR(5))
begin

   DECLARE OldSubscriptionID VARCHAR(50);
   DECLARE Oldexpirydate VARCHAR(6);   
   DECLARE Oldpurchasedate VARCHAR(8);   
   DECLARE actiondate DATETIME(3);
  
   DECLARE errcode INT;  
   DECLARE errmsg VARCHAR(125);  
  
   set OldSubscriptionID = '';  
   set Oldexpirydate = '';  
   set Oldpurchasedate = '';  
   set actiondate = CURRENT_TIMESTAMP;
  
   if exists(select 1 from tSubscription a where a.Account_Id = Account_Id and a.Last6digitsCC = Last6digitsCC LIMIT 1) then
	  
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select a.SubscriptionID, a.expirydate, a.purchasedate INTO OldSubscriptionID,Oldexpirydate,Oldpurchasedate 
      from tSubscription a where a.Account_Id = Account_Id and a.Last6digitsCC = Last6digitsCC;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
      update tSubscription a
      set a.SubscriptionID = SubscriptionID,a.expirydate = expirydate,a.purchasedate = purchasedate
      where a.Account_Id = Account_Id and a.Last6digitsCC = Last6digitsCC;
      
		insert into tSubscriptionLog(Account_Id, Last6digitsCC, SubscriptionID, expirydate, purchasedate, actiondate, provider_code, `Description`)
		values(Account_Id, Last6digitsCC, OldSubscriptionID, Oldexpirydate, Oldpurchasedate, actiondate, provider_code, 'Deleting subscription');
   else
		insert into tSubscription(Account_Id, Last6digitsCC, SubscriptionID, expirydate, purchasedate, provider_code)
		values(Account_Id, Last6digitsCC, SubscriptionID, expirydate, purchasedate, provider_code);
				
		insert into tSubscriptionLog(Account_Id, Last6digitsCC, SubscriptionID, expirydate, purchasedate, actiondate, provider_code, `Description`)
		values(Account_Id, Last6digitsCC, SubscriptionID, expirydate, purchasedate, actiondate, provider_code, 'Inserting new subscription');
   end if;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SubscriptionNew_ecom_pay` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `SubscriptionNew_ecom_pay`(
  Account_Id varchar(50),
  Last6digitsCC varchar(6),
  SubscriptionID varchar(50),
  expirydate varchar(6),
  purchasedate varchar(8),
  provider_code varchar(5),
  referenceid varchar(100),
  cardholder_name varchar(100),
  card_type varchar(100)
  )
begin 
  	 declare OldSubscriptionID varchar(50);
  	 declare Oldexpirydate varchar(6);
  	 declare Oldpurchasedate varchar(8); 
  	 declare actiondate datetime;
  	
  	 declare errcode int;
  	 declare errmsg varchar(125);
  	
  		set OldSubscriptionID = '';
  		set Oldexpirydate = '';
  		set Oldpurchasedate = '';
  		set actiondate = CURRENT_TIMESTAMP;
  		
  	set Last6digitsCC = right(Last6digitsCC,4);
  
  	IF EXISTS (select 1 from tSubscription a where a.Account_Id = Account_Id and a.Last6digitsCC = Last6digitsCC and a.status=1 limit 1) then
      
  		select SubscriptionID, expirydate, purchasedate into OldSubscriptionID, Oldexpirydate, Oldpurchasedate
  		from tSubscription a where a.Account_Id = Account_Id and a.Last6digitsCC = Last6digitsCC and a.status=1;
  			 
  		update tSubscription a set a.SubscriptionID = SubscriptionID, a.expirydate = expirydate, a.purchasedate = purchasedate,a.card_type = card_type,a.is_ecom = 1
  		where a.Account_Id = Account_Id and a.Last6digitsCC = Last6digitsCC and a.status=1;
  			 
  		IF Account_Id='FREESIM' then
  			INSERT INTO tsubs_paid_sim_log(account_id,last4digitscc,SubscriptionID, create_date,oldsubs_id)
  			VALUES(Account_Id,Last6digitsCC,SubscriptionID,GETDATE(),OldSubscriptionID);
  		END if;
  			 
  		insert into tSubscriptionLog (Account_Id, Last6digitsCC, SubscriptionID, expirydate, purchasedate, actiondate, provider_code, `Description`)
  		values (Account_Id, Last6digitsCC, OldSubscriptionID, Oldexpirydate, Oldpurchasedate, actiondate, provider_code, 'updating subscription');
  	 
  	ELSE
  		insert into tSubscription (Account_Id, Last6digitsCC, SubscriptionID, expirydate, purchasedate, provider_code,card_type,is_ecom)
  		values (Account_Id, Last6digitsCC, SubscriptionID, expirydate, purchasedate, provider_code,card_type,1);
  				
  		insert into tSubscriptionLog (Account_Id, Last6digitsCC, SubscriptionID, expirydate, purchasedate, actiondate, provider_code, `Description`)
  		values (Account_Id, Last6digitsCC, SubscriptionID, expirydate, purchasedate, actiondate, provider_code, 'Inserting new subscription');
  			 
  	END if;
  	
  	
  	IF ifnull(referenceid,'')<>'' then
  			update TPAYMENT a SET a.SUBSCRIPTIONID=SubscriptionID, a.cardholder_name = cardholder_name
  			WHERE a.REFERENCE_ID = referenceid;
  	END if;
  
  end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SubscriptionNew_v2` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `SubscriptionNew_v2`(
Account_Id varchar(50),
Last6digitsCC varchar(6),
SubscriptionID varchar(50),
expirydate varchar(6),
purchasedate varchar(8),
provider_code varchar(5),
cvv_number varchar(5)
)
begin 
	 declare OldSubscriptionID varchar(50);
	 declare Oldexpirydate varchar(6);
	 declare Oldpurchasedate varchar(8); 
     declare Oldcvv_number varchar(5);
	 declare actiondate datetime;
	
	 declare errcode int;
	 declare errmsg varchar(125);
	
		set OldSubscriptionID = '';
		set Oldexpirydate = '';
		set Oldpurchasedate = '';
		set actiondate = CURRENT_TIMESTAMP;


	IF EXISTS (select 1 from tSubscription a where a.Account_Id = Account_Id and a.Last6digitsCC = Last6digitsCC limit 1) then
    
		select SubscriptionID, expirydate, purchasedate,cvv_number into OldSubscriptionID, Oldexpirydate, Oldpurchasedate,Oldcvv_number
		from tSubscription a where a.Account_Id = Account_Id and a.Last6digitsCC = Last6digitsCC;
			 
		update tSubscription a set a.SubscriptionID = SubscriptionID, a.expirydate = expirydate, a.purchasedate = purchasedate,
        cvv_number = Oldcvv_number
		where a.Account_Id = Account_Id and a.Last6digitsCC = Last6digitsCC ;
			 
		insert into tSubscriptionLog (Account_Id, Last6digitsCC, SubscriptionID, expirydate, purchasedate, actiondate, provider_code, `Description`,cvv_number)
		values (Account_Id, Last6digitsCC, OldSubscriptionID, Oldexpirydate, Oldpurchasedate, actiondate, provider_code, 'Deleting subscription',Oldcvv_number);
	 
	ELSE
		insert into tSubscription (Account_Id, Last6digitsCC, SubscriptionID, expirydate, purchasedate, provider_code,cvv_number)
		values (Account_Id, Last6digitsCC, SubscriptionID, expirydate, purchasedate, provider_code,Oldcvv_number);
				
		insert into tSubscriptionLog (Account_Id, Last6digitsCC, SubscriptionID, expirydate, purchasedate, actiondate, provider_code, `Description`,cvv_number)
		values (Account_Id, Last6digitsCC, SubscriptionID, expirydate, purchasedate, actiondate, provider_code, 'Inserting new subscription',Oldcvv_number);
			 
	END if;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SubscriptionNew_v3` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `SubscriptionNew_v3`(
  Account_Id VARCHAR(50)
 , Last6digitsCC VARCHAR(6)
 , SubscriptionID VARCHAR(50)
 , expirydate VARCHAR(6)
 , purchasedate VARCHAR(8)
 , provider_code VARCHAR(5)
 , cvv_number VARCHAR(5))
begin

   DECLARE v_OldSubscriptionID VARCHAR(50);
   DECLARE v_Oldexpirydate VARCHAR(6);
   DECLARE v_Oldpurchasedate VARCHAR(8);
   DECLARE v_Oldcvv_number VARCHAR(5);
   DECLARE v_actiondate DATETIME(3);

   DECLARE v_errcode INT;
   DECLARE v_errmsg VARCHAR(125);

   set v_OldSubscriptionID = '';
   set v_Oldexpirydate = '';
   set v_Oldpurchasedate = '';
   set v_actiondate = CURRENT_TIMESTAMP;
 
   set Last6digitsCC = RIGHT(Last6digitsCC,4);     


   if exists(select  1 from tSubscription  a where a.account_id = Account_Id and a.last6digitscc = Last6digitsCC LIMIT 1) then
  
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select   b.SubscriptionID, b.expirydate, b.purchasedate, b.cvv_number INTO v_OldSubscriptionID,v_Oldexpirydate,v_Oldpurchasedate,v_Oldcvv_number from tSubscription  b where b.account_id = Account_Id and b.last6digitscc = Last6digitsCC;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
      update tSubscription c
      set c.SubscriptionID = SubscriptionID,c.expirydate = expirydate,c.purchasedate = purchasedate,
      c.cvv_number = cvv_number
      where c.account_id = Account_Id and c.last6digitscc = Last6digitsCC;
      insert into tSubscriptionLog(Account_Id, Last6digitsCC, SubscriptionID, expirydate, purchasedate, actiondate, provider_code, description, cvv_number)
   values(Account_Id, Last6digitsCC, v_OldSubscriptionID, v_Oldexpirydate, v_Oldpurchasedate, v_actiondate, provider_code, 'Deleting subscription', v_Oldcvv_number);
   else
    insert into tSubscription(account_id, last6digitscc, SubscriptionID, expirydate, purchasedate, provider_code, cvv_number)
   values(Account_Id, Last6digitsCC, SubscriptionID, expirydate, purchasedate, provider_code, cvv_number);
   end if;


   insert into tSubscriptionLog(Account_Id, Last6digitsCC, SubscriptionID, expirydate, purchasedate, actiondate, provider_code, description, cvv_number)
   values(Account_Id, Last6digitsCC, v_OldSubscriptionID, v_Oldexpirydate, v_Oldpurchasedate, v_actiondate, provider_code, 'Inserting new subscription', cvv_number);


end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SubscriptionNew_v4` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `SubscriptionNew_v4`(Account_Id VARCHAR(50)    
 , Last6digitsCC VARCHAR(6)  
 , SubscriptionID VARCHAR(50)    
 , expirydate VARCHAR(6)    
 , purchasedate VARCHAR(8)
 , provider_code VARCHAR(5))
begin

   DECLARE v_OldSubscriptionID VARCHAR(50);    
   DECLARE v_Oldexpirydate VARCHAR(6);   
   DECLARE v_Oldpurchasedate VARCHAR(8);   
   DECLARE v_actiondate DATETIME(3);
  
   DECLARE v_errcode INT;  
   DECLARE v_errmsg VARCHAR(125);  
      
   set v_OldSubscriptionID = '';  
   set v_Oldexpirydate = '';  
   set v_Oldpurchasedate = '';  
   set v_actiondate = CURRENT_TIMESTAMP;
	
	
   set Last6digitsCC = right(Last6digitsCC,4);
      
   if exists(select  1 from tSubscription  a where a.account_id = Account_Id and a.last6digitscc = Last6digitsCC LIMIT 1) then
	  
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select   b.SubscriptionID, b.expirydate, b.purchasedate INTO v_OldSubscriptionID,v_Oldexpirydate,v_Oldpurchasedate 
      from tSubscription b where b.account_id = Account_Id and b.last6digitscc = Last6digitsCC;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
      update tSubscription c
      set c.SubscriptionID = SubscriptionID,c.expirydate = expirydate,c.purchasedate = purchasedate
      where c.account_id = Account_Id and c.last6digitscc = Last6digitsCC;
      insert into tSubscriptionLog(Account_Id, Last6digitsCC, SubscriptionID, expirydate, purchasedate, actiondate, provider_code, description)
			   values(Account_Id, Last6digitsCC, v_OldSubscriptionID, v_Oldexpirydate, v_Oldpurchasedate, v_actiondate, provider_code, 'updating subscription');
   else
			    insert into tSubscription(account_id, last6digitscc, SubscriptionID, expirydate, purchasedate, provider_code)
			   values(Account_Id, Last6digitsCC, SubscriptionID, expirydate, purchasedate, provider_code);
				
      insert into tSubscriptionLog(Account_Id, Last6digitsCC, SubscriptionID, expirydate, purchasedate, actiondate, provider_code, description)
			   values(Account_Id, Last6digitsCC, SubscriptionID, expirydate, purchasedate, v_actiondate, provider_code, 'Inserting new subscription');
   end if;
   
         
    
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SubscriptionNew_v5` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `SubscriptionNew_v5`(
 Account_Id varchar(50),
 Last6digitsCC varchar(6),
 SubscriptionID varchar(50),
 expirydate varchar(6),
 purchasedate varchar(8),
 provider_code varchar(5),
 referenceid varchar(100),
 cardholder_name varchar(100)

 )
begin 
 	 declare OldSubscriptionID varchar(50);
 	 declare Oldexpirydate varchar(6);
 	 declare Oldpurchasedate varchar(8); 
 	 declare actiondate datetime;
 	
 	 declare errcode int;
 	 declare errmsg varchar(125);
 	
 		set OldSubscriptionID = '';
 		set Oldexpirydate = '';
 		set Oldpurchasedate = '';
 		set actiondate = CURRENT_TIMESTAMP;
 		
 	set Last6digitsCC = right(Last6digitsCC,4);
 
 	IF EXISTS (select 1 from tSubscription a where a.Account_Id = Account_Id and a.Last6digitsCC = Last6digitsCC limit 1) then
     
 		select SubscriptionID, expirydate, purchasedate into OldSubscriptionID, Oldexpirydate, Oldpurchasedate
 		from tSubscription a where a.Account_Id = Account_Id and a.Last6digitsCC = Last6digitsCC;
 			 
 		update tSubscription a set a.SubscriptionID = SubscriptionID, a.expirydate = expirydate, a.purchasedate = purchasedate
 		where a.Account_Id = Account_Id and a.Last6digitsCC = Last6digitsCC ;
 			 
 		IF Account_Id='FREESIM' then
 			INSERT INTO tsubs_paid_sim_log(account_id,last4digitscc,SubscriptionID, create_date,oldsubs_id)
 			VALUES(Account_Id,Last6digitsCC,SubscriptionID,GETDATE(),OldSubscriptionID);
 		END if;
 			 
 		insert into tSubscriptionLog (Account_Id, Last6digitsCC, SubscriptionID, expirydate, purchasedate, actiondate, provider_code, `Description`)
 		values (Account_Id, Last6digitsCC, OldSubscriptionID, Oldexpirydate, Oldpurchasedate, actiondate, provider_code, 'updating subscription');
 	 
 	ELSE
 		insert into tSubscription (Account_Id, Last6digitsCC, SubscriptionID, expirydate, purchasedate, provider_code)
 		values (Account_Id, Last6digitsCC, SubscriptionID, expirydate, purchasedate, provider_code);
 				
 		insert into tSubscriptionLog (Account_Id, Last6digitsCC, SubscriptionID, expirydate, purchasedate, actiondate, provider_code, `Description`)
 		values (Account_Id, Last6digitsCC, SubscriptionID, expirydate, purchasedate, actiondate, provider_code, 'Inserting new subscription');
 			 
 	END if;
 	
 	
 	IF ifnull(referenceid,'')<>'' then
 			update TPAYMENT a SET a.SUBSCRIPTIONID=SubscriptionID, a.cardholder_name = cardholder_name
 			WHERE a.REFERENCE_ID = referenceid;
 	END if;
 
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SubscriptionRemove` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `SubscriptionRemove`(SubscriptionID VARCHAR(50))
begin
 
    DECLARE actiondate DATETIME(3);  
    set actiondate = CURRENT_TIMESTAMP;
       
    if exists(select 1 from tSubscription a where a.SubscriptionID = SubscriptionID) then
 	  
       insert into  tSubscriptionLog(Account_Id,Last6digitsCC,SubscriptionID,expirydate,purchasedate,actiondate,provider_code,Description,cvv_number)
       select account_id, last6digitsCC, subscriptionid, expirydate, purchasedate,actiondate,provider_code, 
       'Subscription is reject, Deleting subscription' ,cvv_number
       from   tSubscription a where a.SubscriptionID = SubscriptionID;
       
       delete a from tSubscription a where a.SubscriptionID = SubscriptionID;
       
    end if;  
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SubscriptionValidate` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `SubscriptionValidate`(
  Account_Id VARCHAR(50)      
 , Last6digitsCC VARCHAR(6)    
 , SubscriptionID VARCHAR(50)      
 , expirydate VARCHAR(6)      
 , purchasedate VARCHAR(8)  
 , provider_code VARCHAR(5)
 , payerefError INT
 , cardrefError INT)
begin
 
   DECLARE v_OldSubscriptionID VARCHAR(50);      
   DECLARE v_Oldexpirydate VARCHAR(6);     
   DECLARE v_Oldpurchasedate VARCHAR(8);     
   DECLARE v_actiondate DATETIME(3);  
    
   DECLARE v_errcode INT;    
   DECLARE v_errmsg VARCHAR(125);    
        
   set v_OldSubscriptionID = '';    
   set v_Oldexpirydate = '';    
   set v_Oldpurchasedate = '';    
   set v_actiondate = CURRENT_TIMESTAMP;  
        
   if exists(select  1 from tSubscription a  where a.account_id = Account_Id and a.last6digitscc = Last6digitsCC LIMIT 1) then
   
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select   b.SubscriptionID, b.expirydate, b.purchasedate INTO v_OldSubscriptionID,v_Oldexpirydate,v_Oldpurchasedate from tSubscription b where b.account_id = Account_Id and b.last6digitscc = Last6digitsCC;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
      update tSubscription c
      set c.SubscriptionID = SubscriptionID,c.expirydate = expirydate,c.purchasedate = purchasedate
      where c.account_id = Account_Id and c.last6digitscc = Last6digitsCC;
      insert into tSubscriptionUpdateLog(Account_Id, Last6digitsCC, SubscriptionID, expirydate, purchasedate, actiondate, provider_code, description,payerefError,cardrefError)
		values(Account_Id, Last6digitsCC, v_OldSubscriptionID, v_Oldexpirydate, v_Oldpurchasedate, v_actiondate, provider_code, 'update',payerefError,cardrefError);
   else
		 insert into tSubscription(account_id, last6digitscc, SubscriptionID, expirydate, purchasedate, provider_code)
		values(Account_Id, Last6digitsCC, SubscriptionID, expirydate, purchasedate, provider_code);
		
      insert into tSubscriptionUpdateLog(Account_Id, Last6digitsCC, SubscriptionID, expirydate, purchasedate, actiondate, provider_code, description,payerefError,cardrefError)
		values(Account_Id, Last6digitsCC, SubscriptionID, expirydate, purchasedate, v_actiondate, provider_code, 'insert',payerefError,cardrefError);
   end if;  
     
           
      
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `tcs_eci_insert` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `tcs_eci_insert`(reference_id VARCHAR(32),
eci INT,
card_name VARCHAR(60))
begin

   DECLARE errcode INT;
   DECLARE errmsg VARCHAR(30);

	insert into tcs_eci (reference_id,eci,card_name,update_date) 
    values(reference_id,eci,card_name,CURRENT_TIMESTAMP);

	   if ROW_COUNT() > 0 then
		  set errcode = 0;
		  set errmsg = 'Insert Successfully';
	   else
		  set errcode = -1;
		  set errmsg = 'Insertion Failed';
	   end if;

   select errcode as ErrCode,errmsg as ErrMsg;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `THREED_TRANSACTION_FAILURE_report` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `THREED_TRANSACTION_FAILURE_report`()
SWL_return:
BEGIN


	
	
	
   DROP TEMPORARY TABLE IF EXISTS tt_temp;
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   CREATE TEMPORARY TABLE tt_temp AS select   ACCOUNT_ID,REFERENCE_ID,max(CREATED_DATE) as CREATED_DATE,CONCAT(ReplyMessage,'(Failed)') as ReplyMessage,
     IFNULL(3Dstatus,'') as 3Dstatus,'No ' as succ_later  from TPAYMENT
      where DATE_FORMAT(CREATED_DATE,'%d/%m/%Y') = DATE_FORMAT(TIMESTAMPADD(day,-1,CURRENT_TIMESTAMP),'%d/%m/%Y')
      and LAST_GENERAL_ERROR_CODE = 475 
      AND CC_NO <> '989186'
      GROUP BY ACCOUNT_ID,REFERENCE_ID,ReplyMessage,IFNULL(3Dstatus,'');
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
     
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   UPDATE tt_temp a
   join TPAYMENT b  on a.ACCOUNT_ID = b.ACCOUNT_ID
   and b.CREATED_DATE > a.CREATED_DATE
   and b.LAST_GENERAL_ERROR_CODE in(0,100) 
  
   set  a.succ_later = 'Yes';
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ; 
      
   select * from tt_temp WHERE  CHAR_LENGTH(ACCOUNT_ID) >= 9;
      
   LEAVE SWL_return;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ur_auto_topup_exe_get_subscribtion_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ur_auto_topup_exe_get_subscribtion_info`(
company_id INT  ,
customerid VARCHAR(50))
BEGIN

   
   
   DECLARE v_SubscriptionID VARCHAR(40);
   DECLARE v_cc_no VARCHAR(20); 
   DECLARE v_account_id VARCHAR(50); 
   DECLARE v_expdate VARCHAR(10);  


	      
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   SubscriptionID, IFNULL(Last6digitsCC,''), Account_Id, expirydate INTO v_SubscriptionID,v_cc_no,v_account_id,v_expdate from tSubscription where Account_Id = CONCAT('UR-',CAST(customerid as CHAR(30)))  order by idx desc limit 1 ;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
	
	  
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select  v_account_id as account_id,v_SubscriptionID SubscriptionID,TopupAmount,TopupCurr,
	 v_cc_no as cc_no,v_expdate as exp_date
   from webPayment.tAuxAutoTopup where mobileno = CONCAT('UR-',CAST(customerid AS CHAR(30)))
   and status = 1 LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;


END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ur_check_subscribtion_by_card` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ur_check_subscribtion_by_card`(account_id VARCHAR(20),  
last4digit_cc VARCHAR(20),  
OUT subs_check INT)
BEGIN

   set subs_check = 0;  
   
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   1 INTO subs_check from tSubscription a where a.Account_Id = account_id
   and a.Last6digitsCC = last4digit_cc    LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
   
   
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UR_create_subscribtion_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `UR_create_subscribtion_info`(Account_Id VARCHAR(50)      
    , Last4digitsCC VARCHAR(6)    
    , SubscriptionID VARCHAR(50)      
    , expirydate VARCHAR(6)      
    , purchasedate varchar(8))
begin
         
      DECLARE v_OldSubscriptionID VARCHAR(50);      
      DECLARE v_Oldexpirydate VARCHAR(6);     
      DECLARE v_Oldpurchasedate VARCHAR(8);     
      DECLARE v_actiondate DATETIME(3);  
       
      DECLARE v_errcode INT;    
      DECLARE v_errmsg VARCHAR(125);    
      DECLARE v_provider_code VARCHAR(5);  
           
      set v_OldSubscriptionID = '';    
      set v_Oldexpirydate = '';    
      set v_Oldpurchasedate = '';    
      set v_actiondate = CURRENT_TIMESTAMP;  
      set v_provider_code = 'CS';  
      
      Set v_errcode = -1;  
      set v_errmsg = 'Failure to create Token';  
      
    
           
      if exists(select  1 from tSubscription a  where a.account_id = Account_Id and a.last6digitscc = Last4digitsCC LIMIT 1) then
      
         SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
         select   a.SubscriptionID, a.expirydate, a.purchasedate INTO v_OldSubscriptionID,v_Oldexpirydate,v_Oldpurchasedate 
         from  tSubscription a where a.account_id = Account_Id and a.last6digitscc = Last4digitsCC;
         SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
         
         update tSubscription a
         set a.SubscriptionID = SubscriptionID,a.expirydate = expirydate,a.purchasedate = purchasedate
         where a.account_id = Account_Id and a.last6digitscc = Last4digitsCC;
         
         if found_rows() > 0 
         then      
            SET v_errcode = 0;
            SET v_errmsg = 'Success to create Token';
         end if;
         
         insert into tSubscriptionLog(Account_Id, Last6digitsCC, SubscriptionID, expirydate, purchasedate, actiondate, provider_code, description)
         values(Account_Id, Last4digitsCC, v_OldSubscriptionID, v_Oldexpirydate, v_Oldpurchasedate, v_actiondate, v_provider_code, 'Deleting subscription');
      else
          insert into tSubscription(account_id, last6digitscc, SubscriptionID, expirydate, purchasedate, provider_code)
         values(Account_Id, Last4digitsCC, SubscriptionID, expirydate, purchasedate, v_provider_code);
        
         if found_rows() > 0 
         then	
            SET v_errcode = 0;
            SET v_errmsg = 'Success to create Token';
         end if;
         
         insert into tSubscriptionLog(Account_Id, Last6digitsCC, SubscriptionID, expirydate, purchasedate, actiondate, provider_code, description)
         values(Account_Id, Last4digitsCC, SubscriptionID, expirydate, purchasedate, v_actiondate, v_provider_code, 'Inserting new subscription');
      end if;  
        
      select v_errcode as errcode,v_errmsg as errmsg;  
              
         
   end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ur_ecom_create_sc_subscribtion` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ur_ecom_create_sc_subscribtion`(
    Account_Id varchar(50)    
  , Last4digitsCC varchar(6)  
  , SubscriptionID varchar(50)    
  , expirydate varchar(6)    
  , purchasedate varchar(8)
  , provider_code varchar(5),
  referenceid varchar(100),
  cardholder_name  varchar(100)
  )
begin     
 	 declare OldSubscriptionID varchar(50) ;   
 	 declare Oldexpirydate varchar(6)   ;
 	 declare Oldpurchasedate varchar(8)  ; 
 	 declare actiondate datetime;
 	  
 	 declare errcode int  ;
 	 declare errmsg varchar(125)  ;
      
      set errcode=-1;
 	set errmsg='failure to insert';
           
 		set OldSubscriptionID = ''  ;
 		set Oldexpirydate = ''  ;
 		set Oldpurchasedate = ''  ;
 		set actiondate = current_timestamp();
 		
 	
 	  
       
 	  IF EXISTS (select *  from tSubscription a where a.account_id = Account_Id 
 	  and a.last6digitscc = Last4digitsCC limit 1)  
 	  then  
 			   select  a.SubscriptionID,   a.expirydate,
 			     a.purchasedate  into OldSubscriptionID ,Oldexpirydate,Oldpurchasedate
 			   from tSubscription a where a.account_id = Account_Id 
 			   and a.last6digitscc = Last4digitsCC  ;  
 			     
 			   update tSubscription a set a.sc_SubscriptionID  = SubscriptionID,  
 			  a.expirydate = expirydate,  
 				 a.purchasedate = purchasedate  
 			   where a.account_id = Account_Id and a.last6digitscc = Last4digitsCC  ;
 			   
 			
 			     
 			   insert into tSubscriptionLog  
 				(Account_Id, Last6digitsCC, SubscriptionID, expirydate, purchasedate, actiondate, provider_code, description)
 			   values  
 				(Account_Id, Last4digitsCC, OldSubscriptionID, Oldexpirydate, Oldpurchasedate, actiondate, provider_code, 'updating subscription');
 	     
 
 	  ELSE  
 
 			   insert into tSubscription  
 				(account_id, last6digitscc, sc_SubscriptionID , expirydate, purchasedate, provider_code)    
 			   values  
 				(Account_Id, Last4digitsCC, SubscriptionID, expirydate, purchasedate, provider_code);
 				
 				insert into tSubscriptionLog  
 				(Account_Id, Last6digitsCC, SubscriptionID, expirydate, purchasedate, actiondate, provider_code, description)
 			   values  
 				(Account_Id, Last4digitsCC, SubscriptionID, expirydate, purchasedate, actiondate, provider_code, 'Inserting new subscription');
 			       
 	  END if;
       
       if row_count()>0
       then
       set errcode=0;
       set errmsg='inserted success';
       
       end if;
 	  
 	  
 	  
 	 
     
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ur_ecom_create_subscribtion` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ur_ecom_create_subscribtion`(
      Account_Id VARCHAR(50)    
    , Last4digitsCC VARCHAR(6)  
    , SubscriptionID VARCHAR(50)    
    , expirydate VARCHAR(6)    
    , purchasedate VARCHAR(8)
    , provider_code VARCHAR(5),
    referenceid VARCHAR(100),
    cardholder_name  VARCHAR(100))
begin
   
      DECLARE v_OldSubscriptionID VARCHAR(50);    
      DECLARE v_Oldexpirydate VARCHAR(6);   
      DECLARE v_Oldpurchasedate VARCHAR(8);   
      DECLARE v_actiondate DATETIME(3);
   	  
      DECLARE v_errcode INT;  
      DECLARE v_errmsg VARCHAR(125);  
   	      
      set v_OldSubscriptionID = '';  
      set v_Oldexpirydate = '';  
      set v_Oldpurchasedate = '';  
      set v_actiondate = CURRENT_TIMESTAMP;
   		
   	
   	  
         
      IF EXISTS(select  1 from  tSubscription a  where a.account_id = Account_Id
      and a.last6digitscc = Last4digitsCC and a.status=1 LIMIT 1) then
   	  
         SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
         select   SubscriptionID, expirydate, purchasedate INTO v_OldSubscriptionID,v_Oldexpirydate,v_Oldpurchasedate
         from tSubscription  a where a.account_id = Account_Id
         and a.last6digitscc = Last4digitsCC and a.status=1;
         SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
         update tSubscription b set b.SubscriptionID = SubscriptionID,b.expirydate = expirydate,b.purchasedate = purchasedate,
         b.is_ecom = 1
         where b.account_id = Account_Id and b.last6digitscc = Last4digitsCC;
         IF Account_Id = 'FREESIM' then
   			   
   				      INSERT INTO tsubs_paid_sim_log(account_id,last4digitscc,SubscriptionID,
   				    create_date,oldsubs_id)
   				    VALUES(Account_Id,Last4digitsCC,SubscriptionID,CURRENT_TIMESTAMP,v_OldSubscriptionID);
         end if;
         insert into tSubscriptionLog(Account_Id, Last6digitsCC, SubscriptionID, expirydate, purchasedate, actiondate, provider_code, description)
   			   values(Account_Id, Last4digitsCC, v_OldSubscriptionID, v_Oldexpirydate, v_Oldpurchasedate, v_actiondate, provider_code, 'updating subscription');
      ELSE
   			    insert into tSubscription(account_id, last6digitscc, SubscriptionID, expirydate, purchasedate, provider_code,is_ecom)
   			   values(Account_Id, Last4digitsCC, SubscriptionID, expirydate, purchasedate, provider_code,1);
   				
         insert into tSubscriptionLog(Account_Id, Last6digitsCC, SubscriptionID, expirydate, purchasedate, actiondate, provider_code, description)
   			   values(Account_Id, Last4digitsCC, SubscriptionID, expirydate, purchasedate, v_actiondate, provider_code, 'Inserting new subscription');
      end if;
   	  
   	  
   	  
      IF IFNULL(referenceid,'') <> '' then
   	  
         UPDATE TPAYMENT a SET a.SUBSCRIPTIONID = SubscriptionID,a.cardholder_name = cardholder_name
         WHERE a.REFERENCE_ID = referenceid;
      end if;
      
            
       
   end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ur_failed_transaction_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ur_failed_transaction_info`(v_company_id INT,  
v_account_id VARCHAR(20))
BEGIN

   select v_company_id,REFERENCE_ID,TOTALAMOUNT,CREATED_DATE from TPAYMENT
   where ACCOUNT_ID = v_account_id
   and LAST_GENERAL_ERROR_CODE NOT IN(0,100)
   and replymessage not in('Payment Reference Created');
   
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ur_failed_transaction_info_v2` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ur_failed_transaction_info_v2`(company_id INT,
 account_id VARCHAR(20))
BEGIN
 
 	
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select company_id,a.REFERENCE_ID,a.TOTALAMOUNT,a.CREATED_DATE ,a.CC_NO from  TPAYMENT a
    where a.ACCOUNT_ID = account_id
    and a.LAST_GENERAL_ERROR_CODE NOT IN(0,100)
    and a.replymessage not in ('Payment Reference Created');
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 	
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ur_renewal_exe_get_subscribtion_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ur_renewal_exe_get_subscribtion_info`(payment_Ref VARCHAR(50))
SWL_return:
BEGIN

	
   DECLARE v_account_id VARCHAR(50);
   DECLARE v_cc_no VARCHAR(10);
	
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   account_id, CC_NO INTO v_account_id,v_cc_no from  TPAYMENT where reference_id = payment_Ref;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

	
   IF v_cc_no IN('7583','4024','4024','9969','7514','7976') then
	
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select  '' Account_Id,v_cc_no as last6digitscc,'' SubscriptionID,expirydate from  tSubscription
      where ACCOUNT_ID = v_account_id
      and Last6digitsCC = v_cc_no LIMIT 10;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
      LEAVE SWL_return;
   end if;
	
   IF payment_Ref in('UFGBP-DSKBILL-UR-RX-12447','UFGBP-DSKBILL-UR-RX-12552') then
	
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select  Account_Id,v_cc_no as last6digitscc,CONCAT('test',SubscriptionID) as SubscriptionID,expirydate
      from tSubscription
      where ACCOUNT_ID = v_account_id
      and Last6digitsCC = v_cc_no LIMIT 10;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
      LEAVE SWL_return;
   end if;
	

	
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select  Account_Id,v_cc_no as last6digitscc,SubscriptionID,expirydate from tSubscription
   where ACCOUNT_ID = v_account_id
   and Last6digitsCC = v_cc_no LIMIT 10;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
	


	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Ur_savedcard_insert_payment` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `Ur_savedcard_insert_payment`(
	reference_id VARCHAR(32)      
	,sitecode VARCHAR(5)  
	, productcode VARCHAR(25)      
   ,paymentagent VARCHAR(12)      
   , servicetype VARCHAR(4)      
   , paymentmode VARCHAR(3)      
   , paymentstep INT      
   , paymentstatus INT      
   , accountid VARCHAR(32)      
   , last6digitccno VARCHAR(6)      
   , totalamount FLOAT      
   , currency VARCHAR(3)      
   , subscriptionid VARCHAR(40)      
   , merchantid VARCHAR(10)      
   , providercode VARCHAR(5)      
   , csreasoncode VARCHAR(30)      
   , generalerrorcode INT,
     email VARCHAR(150),
   IPpaymentagent  VARCHAR(150),  
   ReplyMessage VARCHAR(250),
   srd VARCHAR(100))
SWL_return:
  BEGIN
  
     DECLARE v_currenttime DATETIME(3);      
     DECLARE v_ref_id VARCHAR(250);
     DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
     BEGIN
        SET @SWV_Error = 1;
     END;
     IF email is null then
        set email = '';
     END IF;
     IF IPpaymentagent is null then
        set IPpaymentagent = '';
     END IF;
     IF ReplyMessage is null then
        set ReplyMessage = '';
     END IF;
     IF srd is null then
        set srd = '';
     END IF;
     
     START TRANSACTION;      
        
     set v_currenttime = CURRENT_TIMESTAMP; 
  
     if generalerrorcode = 7 then
        set generalerrorcode = 0;
     end if; 
  	
     if generalerrorcode = 5 then
        set generalerrorcode = -1;
     end if; 
  	
  	
     IF  CHAR_LENGTH(last6digitccno) = 6 then
        SET last6digitccno = RIGHT(last6digitccno,4);
     end if;
  	
        
     INSERT INTO TPAYMENT(
     REFERENCE_ID
  ,SITECODE
  , PAYMENT_AGENT
  , SERVICE_TYPE
  , PRODUCT_CODE
  , PAYMENT_MODE
  , ACCOUNT_ID
  , CC_NO
  , TOTALAMOUNT
  , CURRENCY
  , CREATED_DATE
  , SUBSCRIPTIONID
  , CURRENT_STATUS
  , LAST_STEP
  , MERCHANT_ID
  , PROVIDER_CODE
  , LAST_GENERAL_ERROR_CODE
  ,ReplyMessage
  ,srd)
  VALUES(reference_id
  ,sitecode
  ,paymentagent
  , servicetype
  , productcode
  , paymentmode
  , accountid
  , last6digitccno
  , totalamount
  , currency
  , v_currenttime
  ,subscriptionid
  , paymentstatus
  , paymentstep
  , merchantid
  , providercode
  , generalerrorcode
  ,ReplyMessage
  ,srd);      
      
      
  
     SET v_ref_id = reference_id;    
    
        
     if @@error_count <> 0 then
  
  
        ROLLBACK to savepoint Payment;
        select 0;
      
        LEAVE SWL_return;
     end if;      
        
    
     INSERT INTO TCS_PAYMENT_DETAIL(REFERENCE_ID
  , LAST_CS_ERROR_CODE)
  VALUES(reference_id
  , csreasoncode);      
        
  
     if @@error_count <> 0 then
  
  
        ROLLBACK to savepoint Payment;
        select 0;
       
        LEAVE SWL_return;
     end if;      
        
    
     INSERT INTO TCS_TRANSACTION(REFERENCE_ID
  , CS_ERROR_CODE
  , EXECUTION_DATE
  , PAYMENT_STEP
  , PAYMENT_STATUS
  , GENERAL_ERROR_CODE)
  VALUES(reference_id
  , csreasoncode
  , v_currenttime
  , paymentstep
  , paymentstatus
  , generalerrorcode);      
        
  
     if @@error_count <> 0 then
  
  
        ROLLBACK to savepoint Payment;
        select 0;
      
        LEAVE SWL_return;
     end if;      
        
  
     COMMIT;      
     select 1,v_ref_id as ref_id;      
     
     LEAVE SWL_return;      
        
  
     ROLLBACK to savepoint Payment;      
     select 0;      
    
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ur_saved_card_get_subscribtion_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ur_saved_card_get_subscribtion_info`(
account_id VARCHAR(20),
cc_no VARCHAR(4))
BEGIN


	
	

   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select  a.Account_Id,cc_no as cc_no,
	a.SubscriptionID,a.expirydate from tSubscription a where a.ACCOUNT_ID = account_id
   and a.Last6digitsCC = cc_no LIMIT 10;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ur_sc_get_subscribtion_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ur_sc_get_subscribtion_info`(
  account_id varchar(50),
  cc_no  varchar(4))
BEGIN

  	
  
  	select a.Account_Id,a.last6digitscc as last6digitscc,
  	ifnull(a.sc_SubscriptionID,'') as SubscriptionID,a.expirydate 
  	from tSubscription a 
  	where a.ACCOUNT_ID=account_id
  	and a.Last6digitsCC=cc_no;
  	
  
  
  	
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `vectoneapp_get_subscribtion_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `vectoneapp_get_subscribtion_info`(
account_id VARCHAR(20),
last6digit VARCHAR(10),
OUT subscribtion_id VARCHAR(100) ,
OUT errcode INT ,
OUT errmsg VARCHAR(250)
)
SWL_return:BEGIN

	
   DECLARE card_found INT; 
	
   set card_found = 0;
   set subscribtion_id = '';
	
   set errcode = -1;
   set errmsg = 'card subscribtion info not found.';
	
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select a.SubscriptionID INTO subscribtion_id from tSubscription a where a.Account_Id = account_id
   and  ((a.Last6digitsCC = last6digit OR RIGHT(a.Last6digitsCC,4) = last6digit)) order by a.idx desc LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ; 
	
	
   if IFNULL(subscribtion_id,'') = '' then
	
      set errcode = -1;
      set errmsg = 'card subscribtion info not found.';
      LEAVE SWL_return;
   end if;
	
   set errcode = 0;
   set errmsg = 'Success to get the subscribtion info.';
	
end SWL_return ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `website_delete_temp_transaction_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `website_delete_temp_transaction_info`(reference_id VARCHAR(100))
BEGIN
  
    DECLARE v_errcode INT;   
    DECLARE v_errmsg VARCHAR(160);  
    
    set v_errcode = -1;  
    set v_errmsg = 'Failure to delete the transaction';  
    
 delete  from web_transaction_Tmp a
    where a.reference_id = reference_id ;  
    
    if ROW_COUNT() > 0 
    then
       set v_errcode = 0;
       set v_errmsg = 'Succss to delete the transaction';
    end if;  
 select v_errcode as errcode,v_errmsg as errmsg;  
    
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `website_get_temp_transaction_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `website_get_temp_transaction_info`(sitecode VARCHAR(5),
 reference_id VARCHAR(100),
 step_no INT)
BEGIN
     
     
 	
    IF step_no is null then
       set step_no = 0;
    END IF;
    
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    
    select   a.payment_info,a.step_no  from web_transaction_Tmp a
    where a.reference_id = reference_id
    and a.step_no = step_no
    order by a.id desc LIMIT 1;
    
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 	
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `website_insert_temp_transaction_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `website_insert_temp_transaction_info`(reference_id VARCHAR(100),  
payment_info LONGTEXT,  
stepno INT)
BEGIN

  
   
   
   DECLARE v_errcode INT;   
   DECLARE v_errmsg VARCHAR(160);  
   
   set v_errcode = -1;  
   set v_errmsg = 'Failure to insert the details';  
   
   INSERT INTO web_transaction_Tmp(reference_id,payment_info,step_no,create_date)
 VALUES(reference_id,payment_info,stepno,CURRENT_TIMESTAMP);  

   if ROW_COUNT() > 0 then
 
      set v_errcode = 0;
      set v_errmsg = 'Succss to insert the details';
   end if;  
   

   select v_errcode as errcode,v_errmsg as errmsg;  
   
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `website_myaccount_get_payment_transaction` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `website_myaccount_get_payment_transaction`(
mobileno VARCHAR(20),
startdate DATE,
enddate DATE)
BEGIN

	
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select CREATED_DATE as createdate,TOTALAMOUNT as amount,REFERENCE_ID as paymentref,
	CASE WHEN REFERENCE_ID like '%RX%' then 'credit card'
   WHEN REFERENCE_ID like '%PPL%' THEN 'Paypal'
   WHEN REFERENCE_ID like '%PSC%' THEN 'Paysafe' else 'Others' end as pay_type ,
	case WHEN ReplyMessage LIKE '%Succ%' and LAST_GENERAL_ERROR_CODE in(0,100) THEN 'Success' else 'Failure' end as payment_status,
	'Online' as Payment
   from TPAYMENT where ACCOUNT_ID = mobileno
   and CAST(CREATED_DATE AS DATE) BETWEEN startdate AND enddate
   UNION
   select  reg_date AS createdate,amount,sorderid as paymentref,
	CASE WHEN sorderid like '%RX%' then 'credit card'
   WHEN sorderid like '%PPL%' THEN 'Paypal'  end as pay_type,
	case when decision = 'ACCEPT' THEN 'Success' else 'Failure' end AS payment_status,
	'Online' as Payment
   from  webPayment.tCybS_RegisteredPayment a
   where a.mobileno = mobileno
   and CAST(reg_date AS DATE) BETWEEN startdate AND enddate LIMIT 10;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `web_paysaf_currency_update` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `web_paysaf_currency_update`(
reference_id VARCHAR(50),  
currency VARCHAR(10))
begin
  
   if exists(select  1 from TPAYMENT a where a.reference_id = reference_id LIMIT 1) 
   then

      update TPAYMENT a set a.CURRENCY = currency
      where a.reference_id = reference_id;
   end if;     
  
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Worktual_remove_subscription_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `Worktual_remove_subscription_details`(
 Account_Id varchar(30),
 SubscriptionID varchar(40)
 )
begin
 
 declare v_errcode int;
 declare v_errmsg varchar(125);
 
 set v_errcode=-1;
 set v_errmsg ='Failure';
 
 if exists (select * from tSubscription a where a.SubscriptionID=SubscriptionID and a.Account_Id=Account_Id and a.status=1 limit 1)
 then
 
 update  tSubscription a set a.status=0  where a.SubscriptionID=SubscriptionID and a.Account_Id=Account_Id ;
 
 end if;
 
 if row_count()>0
 then 
 set v_errcode=0;
 set v_errmsg ='Seccess to remove subscription';
 end if;
 
 select  v_errcode as errcode,v_errmsg as errmsg;
 
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-21  9:52:24
