-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: API
-- ------------------------------------------------------
-- Server version	8.0.44-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `API`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `API` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `API`;

--
-- Table structure for table `APIKey_details`
--

DROP TABLE IF EXISTS `APIKey_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `APIKey_details` (
  `API_Id` int NOT NULL AUTO_INCREMENT,
  `PROJ_Id` int NOT NULL,
  `User_Id` varchar(500) NOT NULL,
  `Pwd` varchar(600) DEFAULT NULL,
  `APIKey` varchar(500) NOT NULL,
  `Status` varchar(20) DEFAULT NULL,
  `Created_On` datetime(3) NOT NULL,
  `Createdby` varchar(50) DEFAULT NULL,
  `Modified_On` datetime(3) DEFAULT NULL,
  `ModifiedBy` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`API_Id`,`PROJ_Id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=92 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `API_Proj_Token_Master`
--

DROP TABLE IF EXISTS `API_Proj_Token_Master`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `API_Proj_Token_Master` (
  `PTM_Seq_ID` int NOT NULL AUTO_INCREMENT,
  `PTM_Proj_ID` int DEFAULT NULL,
  `PTM_Token_ID` varchar(250) DEFAULT NULL,
  `PTM_Token_Start_date` datetime(3) DEFAULT NULL,
  `PTM_Token_End_Time` datetime(3) DEFAULT NULL,
  `PTM_Refresh_Token_ID` varchar(250) DEFAULT NULL,
  `PTM_Refresh_Token_SDate` datetime(3) DEFAULT NULL,
  `PTM_Refresh_Token_EDate` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`PTM_Seq_ID`),
  KEY `IDX1_API_Proj_Token_Master` (`PTM_Token_ID`),
  KEY `IDX2_API_Proj_Token_Master` (`PTM_Proj_ID`,`PTM_Token_ID`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=90111378 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Project_details`
--

DROP TABLE IF EXISTS `Project_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Project_details` (
  `PROJ_Id` int NOT NULL AUTO_INCREMENT,
  `ProjectName` varchar(100) NOT NULL,
  `Created_On` datetime(3) NOT NULL,
  `Createdby` varchar(50) DEFAULT NULL,
  `Modified_On` datetime(3) DEFAULT NULL,
  `ModifiedBy` varchar(50) DEFAULT NULL,
  `Port_id` int DEFAULT NULL,
  `Proj_Key` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`PROJ_Id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=98 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping events for database 'API'
--

--
-- Dumping routines for database 'API'
--
/*!50003 DROP PROCEDURE IF EXISTS `USP_API_Get_API_Details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `USP_API_Get_API_Details`(User_Id VARCHAR(200),        
Pwd     VARCHAR(200),    
Proj_Id    INT)
Begin

   DECLARE v_errcode INT;        
   DECLARE v_errmsg VARCHAR(20);      
        
   If Exists(Select  1 from APIKey_details a
   join Project_details b on a.PROJ_Id = b.PROJ_Id where a.User_Id = User_Id and a.pwd = Pwd and a.proj_id = Proj_Id LIMIT 1) then
 
      Set v_errcode = 1;
      Set v_errmsg  = 'Success';
   Else
      Set v_errcode = 0;
      Set v_errmsg  = 'Failure';
   end if;        
      
   Select v_errcode as errcode ,v_errmsg as errmsg;      
      
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Usp_API_Insert_Token_Master` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `Usp_API_Insert_Token_Master`(Proj_ID INT,      
AToken_ID VARCHAR(250),      
AToken_Min INT,      
RToken_ID VARCHAR(250),      
RToken_Min INT)
Begin     
  
   DECLARE v_Current DATETIME(3);      
   DECLARE v_errcode INT;        
   DECLARE v_errmsg VARCHAR(250);       
       
   Set v_errcode = 0;        
   Set v_errmsg = 'Success';        
        
     
   Set v_Current = CURRENT_TIMESTAMP;    
  
   Insert into API_Proj_Token_Master(PTM_Proj_ID,PTM_Token_ID,PTM_Token_Start_date,PTM_Token_End_Time,
  PTM_Refresh_Token_ID,PTM_Refresh_Token_SDate,PTM_Refresh_Token_EDate)
     Values(Proj_ID,AToken_ID,v_Current,TIMESTAMPADD(MINUTE,AToken_Min,v_Current) ,
     RToken_ID,TIMESTAMPADD(MINUTE,AToken_Min+1,v_Current),TIMESTAMPADD(MINUTE,AToken_Min+RToken_Min,v_Current));     

   Select v_errcode errcode,v_errmsg errmsg;     

ENd ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Usp_API_Return_Token_Status` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `Usp_API_Return_Token_Status`(
Proj_Name VARCHAR(250),
Token_ID VARCHAR(150)
)
SWL_return:
 Begin

    DECLARE v_start_Date DATETIME(3);
    DECLARE v_End_time INT;
    DECLARE v_End_Date DATETIME(3);
    DECLARE v_Current DATETIME(3);
    DECLARE v_Proj_ID INT;
    DECLARE v_Status VARCHAR(1);
 
 
 
  
 
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select   IFNULL(PROJ_Id,0) INTO v_Proj_ID from Project_details  where ProjectName = Proj_Name limit 1;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 
    
 if v_Proj_ID is null  or v_Proj_ID = 0 then
       Select 'Enter valid Project Name'   Status;
       LEAVE SWL_return;
    end if; 
 
    if Exists(Select 1 from API_Proj_Token_Master  Where PTM_Proj_ID = v_Proj_ID and PTM_Token_ID =  Token_ID limit 1) then
   
       
 SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
       select   PTM_Token_Start_date, PTM_Token_End_Time INTO v_start_Date,v_End_Date from API_Proj_Token_Master  Where PTM_Proj_ID = v_Proj_ID and PTM_Token_ID =  Token_ID limit 1;
       SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
    Else
       If Exists(Select 1 from API_Proj_Token_Master  Where PTM_Proj_ID = v_Proj_ID and PTM_Refresh_Token_ID =  Token_ID limit 1) then
   
          
 SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
          select   PTM_Refresh_Token_SDate, PTM_Refresh_Token_EDate INTO v_start_Date,v_End_Date from API_Proj_Token_Master  Where PTM_Proj_ID = v_Proj_ID and PTM_Refresh_Token_ID =  Token_ID limit 1;
          SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
       end if;
    end if;
 
 
 
    Set v_Current = CURRENT_TIMESTAMP;
	If  (v_Current >= v_start_Date) and (v_Current <= v_End_Date) then
       Select 'OK'  Status;
    Else
       Select 'Token Expired'  Status;
    end if;

 
 ENd ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-21  9:49:51
