-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: reporting
-- ------------------------------------------------------
-- Server version	8.0.44-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `reporting`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `reporting` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `reporting`;

--
-- Table structure for table `TEMP_CALL_from_245_last_active_check`
--

DROP TABLE IF EXISTS `TEMP_CALL_from_245_last_active_check`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TEMP_CALL_from_245_last_active_check` (
  `ani` varchar(20) DEFAULT NULL,
  `calldate` datetime(3) DEFAULT NULL,
  `balance` float DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping events for database 'reporting'
--

--
-- Dumping routines for database 'reporting'
--
/*!50003 DROP PROCEDURE IF EXISTS `VOTG_virtual_numbers_for_recycle` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `VOTG_virtual_numbers_for_recycle`()
Begin
 
    DECLARE v_year VARCHAR(5);
    DECLARE v_curr_month VARCHAR(5);
    DECLARE v_prev_month VARCHAR(5);
    DECLARE v_month2 VARCHAR(5);
    DECLARE v_month3 VARCHAR(5);
 
    DECLARE v_sql1 LONGTEXT; 
    DECLARE v_sql2 LONGTEXT; 
    DECLARE v_sql3 LONGTEXT; 
    DECLARE v_sql4 LONGTEXT; 
    DECLARE v_sql5 LONGTEXT;
    DECLARE v_sql6 LONGTEXT; 
    DECLARE v_sql7 LONGTEXT; 
    DECLARE v_sql8 LONGTEXT; 
    DECLARE v_sql9 LONGTEXT; 
    DECLARE v_sql10 LONGTEXT;
    DECLARE v_sql11 LONGTEXT; 
    DECLARE v_sql12 LONGTEXT; 
    DECLARE v_sql13 LONGTEXT; 
    DECLARE v_sql14 LONGTEXT; 
    DECLARE v_sql15 LONGTEXT;
    DECLARE v_sql16 LONGTEXT; 
    DECLARE v_sql17 LONGTEXT; 
    DECLARE v_sql18 LONGTEXT; 
    DECLARE v_sql19 LONGTEXT; 
    DECLARE v_sql20 LONGTEXT;
    DECLARE v_sql21 LONGTEXT; 
    DECLARE v_sql22 LONGTEXT; 
    DECLARE v_sql23 LONGTEXT;
    set v_curr_month = case when (month(CURRENT_TIMESTAMP) < 10) then  CONCAT('0',cast(month(CURRENT_TIMESTAMP) as CHAR(30))) else  cast(month(CURRENT_TIMESTAMP) as CHAR(30)) end;
    set v_prev_month = case when(v_curr_month -1) < 10 then  CONCAT('0',cast(v_curr_month -1 as CHAR(30))) else  cast(v_curr_month -1 as CHAR(30)) end;
    set v_month2 = case when(v_curr_month -2) < 10 then  CONCAT('0',cast(v_curr_month -2 as CHAR(30))) else  cast(v_curr_month -2 as CHAR(30)) end;
    set v_month3 = case when(v_curr_month -3) < 10 then  CONCAT('0',cast(v_curr_month -3 as CHAR(30))) else  cast(v_curr_month -3 as CHAR(30)) end;
    set v_year = EXTRACT(YEAR FROM TIMESTAMPADD(DAY,-1,CURRENT_TIMESTAMP));
 	 
 	drop TEMPORARY table if exists tt_temp_vxtra_clis;
    create TEMPORARY table tt_temp_vxtra_clis
    (	
       MUNDIO_NUMBER VARCHAR(30),
       Calldate DATETIME(3),
       BALANCE VARCHAR(10)
    );
 	 
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    insert into tt_temp_vxtra_clis(MUNDIO_NUMBER)
    select Distinct MUNDIO_NUMBER
    from votg_pbx.VOTG_VIRTUAL_NUMBER_POOL  where reg_msisdn is not null;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 
 
    SET v_sql1 =CONCAT( 'UPDATE tt_temp_vxtra_clis t1
 INNER JOIN(select ani, max(calldate) as calldate
    from month_bcp_', v_curr_month,  '.xcdr
   group by ani) as t2
 on t2.ani = t1.mundio_number  
 and (t1.calldate < t2.calldate or t1.calldate is null)
 SET t1.calldate = t2.calldate
 ');
    SET @SWV_Stmt =CONCAT(  'insert into tt_temp_vxtra_clis ',  v_sql1);
    PREPARE SWT_Stmt FROM @SWV_Stmt;
    EXECUTE SWT_Stmt;
    DEALLOCATE PREPARE SWT_Stmt;
 
 
    SET v_sql2 = 'update t1
 SET t1.calldate = t2.calldate
 FROM temp_vxtra_clis t1
 INNER JOIN (select ani, max(calldate) as calldate
    from month_bcp_' || v_prev_month || '_' || v_year || '.xcdr
    group by ani) as t2
 on t2.ani = t1.mundio_number  
 and (t1.calldate < t2.calldate or t1.calldate is null)';
    SET @SWV_Stmt =CONCAT(  'insert into tt_temp_vxtra_clis ',  v_sql2);
    PREPARE SWT_Stmt FROM @SWV_Stmt;
    EXECUTE SWT_Stmt;
    DEALLOCATE PREPARE SWT_Stmt;
 
    SET v_sql3 = 'update t1
 SET t1.calldate = t2.calldate
 FROM temp_vxtra_clis t1
 INNER JOIN (select ani, max(calldate) as calldate
    from month_bcp_' || v_month2 || '_' || v_year || '.xcdr
    group by ani) as t2
 on t2.ani = t1.mundio_number  
 and (t1.calldate < t2.calldate or t1.calldate is null)';
    SET @SWV_Stmt =CONCAT(  'insert into tt_temp_vxtra_clis ',  v_sql3);
    PREPARE SWT_Stmt FROM @SWV_Stmt;
    EXECUTE SWT_Stmt;
    DEALLOCATE PREPARE SWT_Stmt;
 
 
    SET v_sql4 =CONCAT( 'UPDATE tt_temp_vxtra_clis t1
 INNER JOIN(select msisdn, max(calldate) as calldate
    from month_bcp_', v_curr_month,  '.xgms
   group by msisdn) as t2
 on t2.msisdn = t1.mundio_number  
 and (t1.calldate < t2.calldate or t1.calldate is null)
 SET t1.calldate = t2.calldate
 ');
    SET @SWV_Stmt =CONCAT(  'insert into tt_temp_vxtra_clis ',  v_sql4);
    PREPARE SWT_Stmt FROM @SWV_Stmt;
    EXECUTE SWT_Stmt;
    DEALLOCATE PREPARE SWT_Stmt;
 
    SET v_sql5 = 'update t1
 SET t1.calldate = t2.calldate
 FROM temp_vxtra_clis t1
 INNER JOIN (select msisdn, max(calldate) as calldate
    from month_bcp_' || v_prev_month || '_' || v_year || '.xgms
    group by msisdn) as t2
 on t2.msisdn = t1.mundio_number  
 and (t1.calldate < t2.calldate or t1.calldate is null)';
    SET @SWV_Stmt =CONCAT(  'insert into tt_temp_vxtra_clis ',  v_sql5);
    PREPARE SWT_Stmt FROM @SWV_Stmt;
    EXECUTE SWT_Stmt;
    DEALLOCATE PREPARE SWT_Stmt;
 
    SET v_sql6 = 'update t1
 SET t1.calldate = t2.calldate
 FROM temp_vxtra_clis t1
 INNER JOIN (select msisdn, max(calldate) as calldate
    from month_bcp_' || v_month2 || '_' || v_year || '.xgms
    group by msisdn) as t2
 on t2.msisdn = t1.mundio_number  
 and (t1.calldate < t2.calldate or t1.calldate is null)';
    SET @SWV_Stmt =CONCAT(  'insert into tt_temp_vxtra_clis ',  v_sql6);
    PREPARE SWT_Stmt FROM @SWV_Stmt;
    EXECUTE SWT_Stmt;
    DEALLOCATE PREPARE SWT_Stmt;
 
 
    SET v_sql7 = 'update t1
 SET t1.calldate = t2.calldate
 FROM temp_vxtra_clis t1
 INNER JOIN (select cli, max(cnxdate) as calldate
    from mvncdr.smscdr_' || v_year || v_curr_month || ' --UK
   group by cli) as t2
 on t2.cli = t1.mundio_number  
 and (t1.calldate < t2.calldate or t1.calldate is null)';
    SET @SWV_Stmt =CONCAT(  'insert into tt_temp_vxtra_clis ',  v_sql7);
    PREPARE SWT_Stmt FROM @SWV_Stmt;
    EXECUTE SWT_Stmt;
    DEALLOCATE PREPARE SWT_Stmt;
 
    SET v_sql8 = 'update t1
 SET t1.calldate = t2.calldate
 FROM temp_vxtra_clis t1
 INNER JOIN (select cli, max(cnxdate) as calldate
    from mvncdr.smscdr_' || v_year || v_prev_month || '
    group by cli) as t2
 on t2.cli = t1.mundio_number  
 and (t1.calldate < t2.calldate or t1.calldate is null)';
    SET @SWV_Stmt =CONCAT(  'insert into tt_temp_vxtra_clis ',  v_sql8);
    PREPARE SWT_Stmt FROM @SWV_Stmt;
    EXECUTE SWT_Stmt;
    DEALLOCATE PREPARE SWT_Stmt;
 
    SET v_sql9 = 'update t1
 SET t1.calldate = t2.calldate
 FROM temp_vxtra_clis t1
 INNER JOIN (select cli, max(cnxdate) as calldate
    from mvncdr.smscdr_' || v_year || v_month2 || '
    group by cli) as t2
 on t2.cli = t1.mundio_number  
 and (t1.calldate < t2.calldate or t1.calldate is null)';
    SET @SWV_Stmt =CONCAT(  'insert into tt_temp_vxtra_clis ',  v_sql9);
    PREPARE SWT_Stmt FROM @SWV_Stmt;
    EXECUTE SWT_Stmt;
    DEALLOCATE PREPARE SWT_Stmt;
 
    SET v_sql10 = 'update t1
 SET t1.calldate = t2.calldate
 FROM temp_vxtra_clis t1
 INNER JOIN (select cli, max(cnxdate) as calldate
    from mvncdr.smscdr_mbe' || v_year || v_curr_month || ' --UK
   group by cli) as t2
 on t2.cli = t1.mundio_number  
 and (t1.calldate < t2.calldate or t1.calldate is null)';
    SET @SWV_Stmt =CONCAT(  'insert into tt_temp_vxtra_clis ',  v_sql10);
    PREPARE SWT_Stmt FROM @SWV_Stmt;
    EXECUTE SWT_Stmt;
    DEALLOCATE PREPARE SWT_Stmt;
 
    SET v_sql11 = 'update t1
 SET t1.calldate = t2.calldate
 FROM temp_vxtra_clis t1
 INNER JOIN (select cli, max(cnxdate) as calldate
    from mvncdr.smscdr_mbe' || v_year || v_prev_month || '
    group by cli) as t2
 on t2.cli = t1.mundio_number  
 and (t1.calldate < t2.calldate or t1.calldate is null)';
    SET @SWV_Stmt =CONCAT(  'insert into tt_temp_vxtra_clis ',  v_sql11);
    PREPARE SWT_Stmt FROM @SWV_Stmt;
    EXECUTE SWT_Stmt;
    DEALLOCATE PREPARE SWT_Stmt;
 
    SET v_sql12 = 'update t1
 SET t1.calldate = t2.calldate
 FROM temp_vxtra_clis t1
 INNER JOIN (select cli, max(cnxdate) as calldate
    from mvncdr.smscdr_mbe' || v_year || v_month2 || '
    group by cli) as t2
 on t2.cli = t1.mundio_number  
 and (t1.calldate < t2.calldate or t1.calldate is null)';
    SET @SWV_Stmt =CONCAT(  'insert into tt_temp_vxtra_clis ',  v_sql12);
    PREPARE SWT_Stmt FROM @SWV_Stmt;
    EXECUTE SWT_Stmt;
    DEALLOCATE PREPARE SWT_Stmt;
 
    SET v_sql13 = 'update t1
 SET t1.calldate = t2.calldate
 FROM temp_vxtra_clis t1
 INNER JOIN (select cli, max(cnxdate) as calldate
    from mvncdr.smscdr_mfr' || v_year || v_curr_month || ' --UK
   group by cli) as t2
 on t2.cli = t1.mundio_number  
 and (t1.calldate < t2.calldate or t1.calldate is null)';
    SET @SWV_Stmt =CONCAT(  'insert into tt_temp_vxtra_clis ',  v_sql13);
    PREPARE SWT_Stmt FROM @SWV_Stmt;
    EXECUTE SWT_Stmt;
    DEALLOCATE PREPARE SWT_Stmt;
 
    SET v_sql14 = 'update t1
 SET t1.calldate = t2.calldate
 FROM temp_vxtra_clis t1
 INNER JOIN (select cli, max(cnxdate) as calldate
    from mvncdr.smscdr_mfr' || v_year || v_prev_month || '
    group by cli) as t2
 on t2.cli = t1.mundio_number  
 and (t1.calldate < t2.calldate or t1.calldate is null)';
    SET @SWV_Stmt =CONCAT(  'insert into tt_temp_vxtra_clis ',  v_sql14);
    PREPARE SWT_Stmt FROM @SWV_Stmt;
    EXECUTE SWT_Stmt;
    DEALLOCATE PREPARE SWT_Stmt;
 
    SET v_sql15 = 'update t1
 SET t1.calldate = t2.calldate
 FROM temp_vxtra_clis t1
 INNER JOIN (select cli, max(cnxdate) as calldate
    from mvncdr.smscdr_mfr' || v_year || v_month2 || '
    group by cli) as t2
 on t2.cli = t1.mundio_number  
 and (t1.calldate < t2.calldate or t1.calldate is null)';
    SET @SWV_Stmt =CONCAT(  'insert into tt_temp_vxtra_clis ',  v_sql15);
    PREPARE SWT_Stmt FROM @SWV_Stmt;
    EXECUTE SWT_Stmt;
    DEALLOCATE PREPARE SWT_Stmt;
 
    SET v_sql15 = 'update t1
 SET t1.calldate = t2.calldate
 FROM temp_vxtra_clis t1
 INNER JOIN (select cli, max(cnxdate) as calldate
    from mvncdr.smscdr_bau' || v_year || v_curr_month || ' --UK
   group by cli) as t2
 on t2.cli = t1.mundio_number  
 and (t1.calldate < t2.calldate or t1.calldate is null)';
    SET @SWV_Stmt =CONCAT(  'insert into tt_temp_vxtra_clis ',  v_sql15);
    PREPARE SWT_Stmt FROM @SWV_Stmt;
    EXECUTE SWT_Stmt;
    DEALLOCATE PREPARE SWT_Stmt;
 
    SET v_sql16 = 'update t1
 SET t1.calldate = t2.calldate
 FROM temp_vxtra_clis t1
 INNER JOIN (select cli, max(cnxdate) as calldate
    from mvncdr.smscdr_bau' || v_year || v_prev_month || '
    group by cli) as t2
 on t2.cli = t1.mundio_number  
 and (t1.calldate < t2.calldate or t1.calldate is null)';
    SET @SWV_Stmt =CONCAT(  'insert into tt_temp_vxtra_clis ',  v_sql16);
    PREPARE SWT_Stmt FROM @SWV_Stmt;
    EXECUTE SWT_Stmt;
    DEALLOCATE PREPARE SWT_Stmt;
 
    SET v_sql17 = 'update t1
 SET t1.calldate = t2.calldate
 FROM temp_vxtra_clis t1
 INNER JOIN (select cli, max(cnxdate) as calldate
    from mvncdr.smscdr_bau' || v_year || v_month2 || '
    group by cli) as t2
 on t2.cli = t1.mundio_number  
 and (t1.calldate < t2.calldate or t1.calldate is null)';
    SET @SWV_Stmt =CONCAT(  'insert into tt_temp_vxtra_clis ',  v_sql17);
    PREPARE SWT_Stmt FROM @SWV_Stmt;
    EXECUTE SWT_Stmt;
    DEALLOCATE PREPARE SWT_Stmt;
 
 
 
 
    SET v_sql18 = 'update a
 set a.BALANCE = b.balance
 from temp_vxtra_clis a 
 inner join SRV84.month_bcp_' || v_curr_month || '.xcdr b
 on a.mundio_number = b.ani
 and a.calldate = b.calldate
 where (a.balance is null or a.balance<b.balance)';
    SET @SWV_Stmt =CONCAT(  'insert into tt_temp_vxtra_clis ',  v_sql18);
    PREPARE SWT_Stmt FROM @SWV_Stmt;
    EXECUTE SWT_Stmt;
    DEALLOCATE PREPARE SWT_Stmt;
 
 
    SET v_sql19 = 'update a
 set a.BALANCE = b.balance
 from temp_vxtra_clis a 
 inner join month_bcp_' || v_prev_month || '_' || v_year || '.xcdr b
 on a.mundio_number = b.ani
 and a.calldate = b.calldate
 where (a.balance is null or a.balance<b.balance)';
    SET @SWV_Stmt =CONCAT(  'insert into tt_temp_vxtra_clis ',  v_sql19);
    PREPARE SWT_Stmt FROM @SWV_Stmt;
    EXECUTE SWT_Stmt;
    DEALLOCATE PREPARE SWT_Stmt;
 
    SET v_sql20 = 'update a
 set a.BALANCE = b.balance
 from temp_vxtra_clis a 
 inner join month_bcp_' || v_month2 || '_' || v_year || '.xcdr b
 on a.mundio_number = b.ani
 and a.calldate = b.calldate
 where (a.balance is null or a.balance<b.balance)';
    SET @SWV_Stmt =CONCAT(  'insert into tt_temp_vxtra_clis ',  v_sql20);
    PREPARE SWT_Stmt FROM @SWV_Stmt;
    EXECUTE SWT_Stmt;
    DEALLOCATE PREPARE SWT_Stmt;
 
    SET v_sql21 = 'update a
 set a.BALANCE = b.legadur
 from temp_vxtra_clis a 
 inner join SRV84.month_bcp_' || v_curr_month || '.xgms b
 on a.mundio_number = b.msisdn
 and a.calldate = b.calldate
 where (a.balance is null or a.balance<b.legadur)';
    SET @SWV_Stmt =CONCAT(  'insert into tt_temp_vxtra_clis ',  v_sql21);
    PREPARE SWT_Stmt FROM @SWV_Stmt;
    EXECUTE SWT_Stmt;
    DEALLOCATE PREPARE SWT_Stmt;
 
 
    SET v_sql22 = 'update a
 set a.BALANCE = b.legadur
 from temp_vxtra_clis a 
 inner join month_bcp_' || v_prev_month || '_' || v_year || '.xgms b
 on a.mundio_number = b.msisdn
 and a.calldate = b.calldate
 where (a.balance is null or a.balance<b.legadur)';
    SET @SWV_Stmt =CONCAT(  'insert into tt_temp_vxtra_clis ',  v_sql22);
    PREPARE SWT_Stmt FROM @SWV_Stmt;
    EXECUTE SWT_Stmt;
    DEALLOCATE PREPARE SWT_Stmt;
 
    SET v_sql23 = 'update a
 set a.BALANCE = b.legadur
 from temp_vxtra_clis a 
 inner join month_bcp_' || v_month2 || '_' || v_year || '.xgms b
 on a.mundio_number = b.msisdn
 and a.calldate = b.calldate
 where (a.balance is null or a.balance<b.legadur)';
    SET @SWV_Stmt =CONCAT(  'insert into tt_temp_vxtra_clis ',  v_sql23);
    PREPARE SWT_Stmt FROM @SWV_Stmt;
    EXECUTE SWT_Stmt;
    DEALLOCATE PREPARE SWT_Stmt;
 
    If exists(select  1 from tt_temp_vxtra_clis where Calldate is null LIMIT 1) then
 		
       UPDATE tt_temp_vxtra_clis
       set calldate = null,balance = '0'
       where calldate is null;
    end if;
 
    If not exists(select  1 from TEMP_CALL_from_245_last_active_check LIMIT 1) then
 		
 		insert into TEMP_CALL_from_245_last_active_check(ani,calldate,balance)
 		select Distinct MUNDIO_NUMBER,calldate,balance
 		from tt_temp_vxtra_clis;
    end if;
 	
 	   insert into TEMP_CALL_from_245_last_active_check(ani,calldate,balance)
 	   select Distinct MUNDIO_NUMBER,calldate,balance
 	   from tt_temp_vxtra_clis
 	   where MUNDIO_NUMBER not in(select distinct ani from TEMP_CALL_from_245_last_active_check);
       
       
       drop temporary table if exists temp_recycle_log;
		create temporary table temp_recycle_log
				(
					mobileno varchar(10),
					recycle_start_date datetime,
					recycle_end_date datetime,
					recycle_status varchar(10),
					reassigned_to_mainpool_date varchar(10)
				);
				
				insert into temp_recycle_log (mobileno)
                select Distinct ani from TEMP_CALL_from_245_last_active_check;
 			
 			
    drop TEMPORARY table IF EXISTS tt_temp_vxtra_clis;
 
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-21  9:52:29
