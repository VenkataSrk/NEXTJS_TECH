-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: npopr_fr
-- ------------------------------------------------------
-- Server version	8.0.44-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `npopr_fr`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `npopr_fr` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `npopr_fr`;

--
-- Table structure for table `HOMENBRANGE`
--

DROP TABLE IF EXISTS `HOMENBRANGE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `HOMENBRANGE` (
  `IDX` int NOT NULL AUTO_INCREMENT,
  `FIRSTNB` varchar(30) NOT NULL,
  `LASTNB` varchar(30) NOT NULL,
  `rcid` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`FIRSTNB`,`LASTNB`),
  UNIQUE KEY `IDX` (`IDX`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `mnp_operatorRouting`
--

DROP TABLE IF EXISTS `mnp_operatorRouting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mnp_operatorRouting` (
  `MCode` varchar(2) NOT NULL,
  `OperatorName` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `MRouting` varchar(4) DEFAULT NULL,
  PRIMARY KEY (`MCode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `npcountry`
--

DROP TABLE IF EXISTS `npcountry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `npcountry` (
  `prefix` varchar(15) NOT NULL,
  `country` varchar(64) NOT NULL,
  `homeOperatorRcid` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`prefix`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `porting`
--

DROP TABLE IF EXISTS `porting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `porting` (
  `idx` int NOT NULL AUTO_INCREMENT,
  `firstnb` varchar(20) NOT NULL,
  `lastnb` varchar(20) NOT NULL,
  `portedflag` int NOT NULL,
  `rcid` char(10) DEFAULT NULL,
  `flag` int DEFAULT NULL,
  PRIMARY KEY (`firstnb`,`lastnb`,`portedflag`),
  UNIQUE KEY `idx` (`idx`),
  KEY `idx1` (`portedflag`,`firstnb`,`lastnb`,`rcid`),
  KEY `idx2` (`firstnb`,`lastnb`,`portedflag`,`rcid`),
  KEY `idx3` (`rcid`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=16294087 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping events for database 'npopr_fr'
--

--
-- Dumping routines for database 'npopr_fr'
--
/*!50003 DROP PROCEDURE IF EXISTS `MNP_GET_NUMBER` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `MNP_GET_NUMBER`(
 	nb VARCHAR(30),
   OUT mnp_number VARCHAR(30) ,
   OUT portedflag INT ,
   OUT rcid VARCHAR(30) ,
   OUT isOnward INT
 )
BEGIN
 
    DECLARE nbnocc VARCHAR(30);
    DECLARE home_rcid VARCHAR(20);
    DECLARE msisdn VARCHAR(30);
    DECLARE area VARCHAR(30);
    DECLARE rCode VARCHAR(4);
 
    DECLARE Swv_RowCount INT;
 
    SET portedflag = 0;
    SET isOnward = 0;
 
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select right(nb,CHAR_LENGTH(RTRIM(nb)) -CHAR_LENGTH(RTRIM(a.prefix))), rtrim(ltrim(a.homeOperatorRcid)) 
    INTO nbnocc,home_rcid 
    FROM npcountry a WHERE nb like CONCAT(a.prefix,'%');
    SET Swv_RowCount = ROW_COUNT();
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 
    IF Swv_RowCount > 0 then
 
     
     
       IF CHAR_LENGTH(RTRIM(nb)) > 12 then
     
          SET area = substring(nb,3,2);
          SET msisdn = CONCAT(substring(nb,1,2),substring(nb,5,9));
       ELSE
          SET area = '08';
          SET msisdn = nb;
       end if;
 
     
       SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
       select   ltrim(RTRIM(a.rcid)), 1 INTO rcid,portedflag FROM porting a WHERE a.portedflag = 1 AND a.firstnb = msisdn LIMIT 1;
       SET Swv_RowCount = ROW_COUNT();
       SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 
      
     
 
       IF Swv_RowCount = 0 then
          SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
          select   ltrim(RTRIM(a.rcid)), 0 INTO rcid,portedflag FROM porting a 
 		 WHERE a.portedflag = 0 AND msisdn BETWEEN a.firstnb AND a.lastnb   
 		 ORDER BY a.FIRSTNB desc,a.LASTNB asc LIMIT 1;
          SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
       end if;
  
     
       IF portedflag = 1 AND  rcid <> home_rcid AND EXISTS(SELECT * FROM HOMENBRANGE a WHERE msisdn between a.FIRSTNB and a.LASTNB limit 1) then
          SET isOnward = 1;
       end if;
       select a.MRouting INTO rCode from mnp_operatorRouting a Where a.MCode = right(rcid,2)    LIMIT 1;
       if rCode is null then
          Set rCode = '0000';
       end if;
       SET mnp_number = CONCAT(rcid,IFNULL((CONCAT(area,cast(portedflag as CHAR(1)),rCode,substring(msisdn,3,9))),msisdn));
    ELSE
       SET mnp_number = nb;
    end if;
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-21  9:52:06
