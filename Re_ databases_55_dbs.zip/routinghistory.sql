-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: routinghistory
-- ------------------------------------------------------
-- Server version	8.0.44-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `routinghistory`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `routinghistory` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `routinghistory`;

--
-- Table structure for table `r_XLATNbChg_log`
--

DROP TABLE IF EXISTS `r_XLATNbChg_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `r_XLATNbChg_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sitecode` varchar(10) DEFAULT NULL,
  `prefixcode` varchar(20) DEFAULT NULL,
  `xlatpfx` varchar(20) DEFAULT NULL,
  `userID` varchar(40) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `oprtype` int DEFAULT NULL,
  `status` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `r_XLATNbChglog`
--

DROP TABLE IF EXISTS `r_XLATNbChglog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `r_XLATNbChglog` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sitecode` varchar(10) DEFAULT NULL,
  `prefixcode` varchar(15) DEFAULT NULL,
  `xlatpfx` varchar(15) DEFAULT NULL,
  `userid` varchar(40) DEFAULT NULL,
  `oprtype` int DEFAULT NULL,
  `status` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `routingtransaction`
--

DROP TABLE IF EXISTS `routingtransaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `routingtransaction` (
  `id` int NOT NULL AUTO_INCREMENT,
  `operator` varchar(50) DEFAULT NULL,
  `prefixcode` varchar(50) DEFAULT NULL,
  `timeclass` varchar(4) DEFAULT NULL,
  `cost` float DEFAULT NULL,
  `access` int DEFAULT NULL,
  `thedate` datetime DEFAULT NULL,
  `login` varchar(50) DEFAULT NULL,
  `isactive` int DEFAULT NULL,
  `comment` varchar(150) DEFAULT NULL,
  `rset` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_routing_tran_1` (`operator`,`prefixcode`,`timeclass`,`access`,`thedate`),
  KEY `idx_routing_tran_2` (`thedate`),
  KEY `idx_routing_tran_3` (`operator`,`prefixcode`,`thedate`),
  KEY `idx_routing_tran_4` (`login`),
  KEY `idx_routing_tran_5` (`timeclass`),
  KEY `idx_routing_tran_7` (`login`,`timeclass`,`thedate`),
  KEY `idx_rt_1` (`isactive`)
) ENGINE=InnoDB AUTO_INCREMENT=175 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `update_currency_exchange_log_per_oper`
--

DROP TABLE IF EXISTS `update_currency_exchange_log_per_oper`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `update_currency_exchange_log_per_oper` (
  `idx` int NOT NULL AUTO_INCREMENT,
  `id` int DEFAULT NULL,
  `username` varchar(32) DEFAULT NULL,
  `oprid` int DEFAULT NULL,
  `newcostorgcurr` varchar(4) DEFAULT NULL,
  `newcostorg` float DEFAULT NULL,
  `totalupdated` int DEFAULT NULL,
  `activeupdated` int DEFAULT NULL,
  `blockedupdated` int DEFAULT NULL,
  `forbiddenupdated` int DEFAULT NULL,
  `logdate` datetime DEFAULT NULL,
  PRIMARY KEY (`idx`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping events for database 'routinghistory'
--

--
-- Dumping routines for database 'routinghistory'
--
/*!50003 DROP PROCEDURE IF EXISTS `rh_insert` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `rh_insert`(
  operator varchar(50),  
  prefixcode varchar(50),  
  timeclass varchar(4),  
  cost float,  
  access int,  
  login varchar(50),  
  isactive int,
  Rset varchar(100),
  comment varchar(150) 
 )
begin  
 
 	if isactive is null then
 		set isactive = 1;
 	End if;
 
 	insert into routinghistory.routingtransaction ( operator, prefixcode , timeclass , cost ,access, thedate, login ,isactive,comment,rset)  
 	values ( operator, prefixcode , timeclass , cost , access, current_timestamp(), login ,isactive,comment,Rset)  ;
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r_operator_insert` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `r_operator_insert`(
 operator varchar(50),
 prefixcode varchar(50),
 timeclass varchar(4),
 cost float,
 access int,
 thedate datetime,
 login varchar(50),
 isactive int,
 comment varchar(150)
)
begin

	if isactive is null then
		set isactive = 1;
    End if;

	insert into routinghistory.routingtransaction ( operator, prefixcode , timeclass , cost ,access, thedate, login ,isactive,comment)
	values ( operator, prefixcode , timeclass , cost , access,thedate, login ,isactive,comment);
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r_XLATNbChglog` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `r_XLATNbChglog`(
sitecode varchar(10),  
prefixcode varchar(15),  
xlatpfx varchar(15),  
userid varchar(40),  
oprtype int,  
status int  
)
begin   
 
 insert into routinghistory.r_XLATNbChg_log (sitecode , prefixcode ,xlatpfx, userid , `date`,oprtype,status)  
 values (sitecode,prefixcode,xlatpfx,userid,CURRENT_TIMESTAMP(),oprtype,status);  

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-21  9:52:48
