-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: chatServer2023
-- ------------------------------------------------------
-- Server version	8.0.44-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `all_chat_users`
--

DROP TABLE IF EXISTS `all_chat_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `all_chat_users` (
  `cid` int NOT NULL AUTO_INCREMENT,
  `sipid` varchar(16) NOT NULL,
  PRIMARY KEY (`cid`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=705 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `appinfo`
--

DROP TABLE IF EXISTS `appinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `appinfo` (
  `id` int NOT NULL AUTO_INCREMENT,
  `accessType` varchar(255) DEFAULT NULL,
  `appId` varchar(45) DEFAULT NULL,
  `appSecret` varchar(45) DEFAULT NULL,
  `domain` varchar(255) DEFAULT NULL,
  `createdBy` varchar(45) DEFAULT '373',
  `createdOn` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `chatmessage`
--

DROP TABLE IF EXISTS `chatmessage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chatmessage` (
  `indexId` int NOT NULL AUTO_INCREMENT,
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `sourceTimeStamp` bigint DEFAULT NULL,
  `timestamp` bigint NOT NULL,
  `from` varchar(16) NOT NULL,
  `to` text NOT NULL,
  `chatId` varchar(120) DEFAULT NULL,
  `type` smallint DEFAULT '2',
  `domainId` int DEFAULT '0',
  `message` json DEFAULT NULL,
  `deliveryreport` json DEFAULT NULL,
  `readreport` json DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `deliveryreport_parsed` json GENERATED ALWAYS AS (json_unquote(json_extract(`deliveryreport`,_utf8mb4'$.parsed'))) VIRTUAL,
  `deliveryreport_msgparsed` json GENERATED ALWAYS AS (json_unquote(json_extract(`deliveryreport`,_utf8mb4'$.parsed'))) VIRTUAL,
  `readreport_user1` tinyint(1) GENERATED ALWAYS AS (json_extract(`readreport`,_utf8mb4'$.user1')) VIRTUAL,
  PRIMARY KEY (`indexId`,`timestamp`,`from`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  KEY `indexId_idx` (`indexId`) /*!80000 INVISIBLE */,
  KEY `domainId_idx` (`domainId`) /*!80000 INVISIBLE */,
  KEY `chatmessage_chatId_idx` (`chatId`),
  KEY `chatmessage_from` (`from`),
  KEY `idx_chatId_from_to` (`chatId`,`from`,`to`(255))
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=957649 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `chatmessage6617`
--

DROP TABLE IF EXISTS `chatmessage6617`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chatmessage6617` (
  `indexId` int NOT NULL DEFAULT '0',
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `sourceTimeStamp` bigint DEFAULT NULL,
  `timestamp` bigint NOT NULL,
  `from` varchar(16) NOT NULL,
  `to` text NOT NULL,
  `chatId` varchar(120) DEFAULT NULL,
  `type` smallint DEFAULT '2',
  `message` json DEFAULT NULL,
  `deliveryreport` json DEFAULT NULL,
  `readreport` json DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`indexId`,`timestamp`,`from`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `chatmessage_backup_20230828`
--

DROP TABLE IF EXISTS `chatmessage_backup_20230828`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chatmessage_backup_20230828` (
  `indexId` int NOT NULL AUTO_INCREMENT,
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `sourceTimestamp` bigint DEFAULT NULL,
  `timestamp` bigint NOT NULL,
  `from` varchar(16) NOT NULL,
  `to` text NOT NULL,
  `chatId` varchar(120) DEFAULT NULL,
  `type` smallint DEFAULT '2',
  `domainId` int DEFAULT '0',
  `message` json DEFAULT NULL,
  `deliveryreport` json DEFAULT NULL,
  `readreport` json DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `deliveryreport_parsed` json GENERATED ALWAYS AS (json_unquote(json_extract(`deliveryreport`,_utf8mb4'$.parsed'))) VIRTUAL,
  `deliveryreport_msgparsed` json GENERATED ALWAYS AS (json_unquote(json_extract(`deliveryreport`,_utf8mb4'$.parsed'))) VIRTUAL,
  `readreport_user1` tinyint(1) GENERATED ALWAYS AS (json_extract(`readreport`,_utf8mb4'$.user1')) VIRTUAL,
  PRIMARY KEY (`indexId`,`timestamp`,`from`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  KEY `indexId_idx` (`indexId`) /*!80000 INVISIBLE */,
  KEY `domainId_idx` (`domainId`) /*!80000 INVISIBLE */,
  KEY `chatmessage_chatId_idx` (`chatId`),
  KEY `chatmessage_from` (`from`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=675192 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `chatmessage_backup_20250711`
--

DROP TABLE IF EXISTS `chatmessage_backup_20250711`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chatmessage_backup_20250711` (
  `indexId` int NOT NULL AUTO_INCREMENT,
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `sourceTimeStamp` bigint DEFAULT NULL,
  `timestamp` bigint NOT NULL,
  `from` varchar(16) NOT NULL,
  `to` text NOT NULL,
  `chatId` varchar(120) DEFAULT NULL,
  `type` smallint DEFAULT '2',
  `domainId` int DEFAULT '0',
  `message` json DEFAULT NULL,
  `deliveryreport` json DEFAULT NULL,
  `readreport` json DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `deliveryreport_parsed` json GENERATED ALWAYS AS (json_unquote(json_extract(`deliveryreport`,_utf8mb4'$.parsed'))) VIRTUAL,
  `deliveryreport_msgparsed` json GENERATED ALWAYS AS (json_unquote(json_extract(`deliveryreport`,_utf8mb4'$.parsed'))) VIRTUAL,
  `readreport_user1` tinyint(1) GENERATED ALWAYS AS (json_extract(`readreport`,_utf8mb4'$.user1')) VIRTUAL,
  PRIMARY KEY (`indexId`,`timestamp`,`from`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  KEY `indexId_idx` (`indexId`) /*!80000 INVISIBLE */,
  KEY `domainId_idx` (`domainId`) /*!80000 INVISIBLE */,
  KEY `chatmessage_chatId_idx` (`chatId`),
  KEY `chatmessage_from` (`from`),
  KEY `idx_chatId_from_to` (`chatId`,`from`,`to`(255))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `connection`
--

DROP TABLE IF EXISTS `connection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `connection` (
  `userId` varchar(128) NOT NULL,
  `socketId` varchar(128) DEFAULT NULL,
  `deviceId` varchar(128) DEFAULT NULL,
  `domainId` int DEFAULT '0',
  `name` varchar(250) DEFAULT NULL,
  `extension` int DEFAULT '0',
  `deviceType` varchar(128) NOT NULL,
  `connectionStatus` varchar(128) DEFAULT NULL,
  `pushNotificationId` text,
  `availableStatus` smallint DEFAULT '1',
  `callId` varchar(128) DEFAULT '1',
  `userPresenceStatus` smallint DEFAULT '1',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`userId`,`deviceType`),
  KEY `idx_conn_` (`userPresenceStatus`) /*!80000 INVISIBLE */,
  KEY `domainId_idx` (`domainId`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `generalSettings`
--

DROP TABLE IF EXISTS `generalSettings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `generalSettings` (
  `gsid` int NOT NULL AUTO_INCREMENT,
  `category` varchar(250) DEFAULT NULL,
  `dateType` int DEFAULT NULL,
  `dateTypeText` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`gsid`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `notificationhistory`
--

DROP TABLE IF EXISTS `notificationhistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notificationhistory` (
  `userId` varchar(10) NOT NULL,
  `timestamp` bigint DEFAULT NULL,
  PRIMARY KEY (`userId`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pn_logger`
--

DROP TABLE IF EXISTS `pn_logger`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pn_logger` (
  `push_uuid` varchar(255) DEFAULT NULL,
  `notification_data` longtext,
  `sender` varchar(255) DEFAULT NULL,
  `receiver` varchar(255) DEFAULT NULL,
  `pbxserver_push_notification_send_status` varchar(255) DEFAULT NULL,
  `urapp_push_notification_received_status` int DEFAULT NULL,
  `typeNotification` varchar(255) DEFAULT NULL,
  `createdDate` date DEFAULT NULL,
  `updatedDate` date DEFAULT NULL,
  `recurringNotifyResult` longtext,
  `domainId` varchar(255) DEFAULT NULL,
  `clientRegStatus` int DEFAULT NULL,
  `ClientRegResult` longtext,
  `pid` int NOT NULL AUTO_INCREMENT,
  `pn_loggercol` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`pid`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=436168 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `recentChat`
--

DROP TABLE IF EXISTS `recentChat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recentChat` (
  `chatId` varchar(255) NOT NULL,
  `users` json DEFAULT NULL,
  `type` smallint(5) unsigned zerofill DEFAULT NULL,
  `lastmsgIndex` bigint(20) unsigned zerofill DEFAULT NULL,
  `readIndex` json DEFAULT NULL,
  `fromIndex` json DEFAULT NULL,
  `savedChat` json DEFAULT NULL,
  `settings` json DEFAULT NULL,
  `delete` int DEFAULT '0',
  `block` int DEFAULT '0',
  `domainId` int DEFAULT '0',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`chatId`),
  KEY `recentchat_chatId` (`chatId`) /*!80000 INVISIBLE */,
  KEY `recentchat_lastmsgIndex` (`lastmsgIndex`) /*!80000 INVISIBLE */,
  KEY `domainId` (`domainId`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `recentHistory`
--

DROP TABLE IF EXISTS `recentHistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recentHistory` (
  `userId` varchar(255) NOT NULL,
  `domainId` int DEFAULT '0',
  `deviceType` varchar(255) NOT NULL,
  `chatId` varchar(255) NOT NULL,
  `timestamp` bigint DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`userId`,`deviceType`,`chatId`),
  KEY `recenthistory_userId` (`userId`) /*!80000 INVISIBLE */,
  KEY `recenthistory_deviceType` (`deviceType`) /*!80000 INVISIBLE */,
  KEY `domainId_idx` (`domainId`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_ChatClearedTime`
--

DROP TABLE IF EXISTS `tb_ChatClearedTime`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_ChatClearedTime` (
  `chatId` varchar(120) NOT NULL,
  `userId` int NOT NULL,
  `clearedTime` bigint DEFAULT NULL,
  `domainId` int DEFAULT NULL,
  `createdDate` datetime DEFAULT NULL,
  `updatedDate` datetime DEFAULT NULL,
  PRIMARY KEY (`chatId`,`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping routines for database 'chatServer2023'
--
/*!50003 DROP PROCEDURE IF EXISTS `up_chat_unread_messages` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`javateam`@`%` PROCEDURE `up_chat_unread_messages`(
		p_chatId  		VARCHAR(120)
        ,p_userID		INT	
        ,p_offset 		INT
)
begin
 

    SELECT * FROM chatmessage 
    WHERE chatId = p_chatId 
    AND `from` NOT LIKE concat('%',p_userID,'%') 
    AND (JSON_EXTRACT(readreport, CONCAT('$.s', p_userID)) IS NULL)
    
	AND JSON_EXTRACT(message, CONCAT('$.persistDelete.s',p_userID)) IS NULL
    ORDER BY indexId DESC LIMIT p_offset;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `up_GetChatClearedTime` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`javateam`@`%` PROCEDURE `up_GetChatClearedTime`(	p_chatId			VARCHAR(120)		
 	,p_userId			INT		
 )
BEGIN
 	SELECT 	chatId
 		,	userId
 		,	clearedTime
 		,	1	isCleared
     FROM 	tb_ChatClearedTime
     WHERE 	chatId 	= p_chatId
     AND 	userId	= p_userId;   
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `up_GetChatHistory_dynamic` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`javateam`@`%` PROCEDURE `up_GetChatHistory_dynamic`(	
  	p_prefix				varchar(4)
   	,p_ChatId				varchar(120)
   	,p_id					char(36)	
	,p_LastReadTimestamp	BIGINT
  	,p_orderType			varchar(4)
  	,p_offset 				int
    ,p_fromId				int    
   )
SP_LEAVE:BEGIN
	DECLARE v_indexId			int;
	DECLARE v_LastReadDatetime	Datetime;        
	DECLARE v_ChatMessageTable	VARCHAR(30);
    DECLARE v_id				char(36);
    
    SET v_id = IF(p_id = '',NULL,p_id);
       
       SET v_LastReadDatetime = FROM_UNIXTIME(p_LastReadTimestamp/1000);
       
       
       SET v_ChatMessageTable = 'chatmessage';
          
       IF v_id IS NOT NULL THEN        
   		SET @t = CONCAT("SELECT indexId into @indexId FROM ",v_ChatMessageTable," WHERE id = '",v_id,"' and domainId = '",p_prefix,"' ORDER BY indexId DESC LIMIT 1");
           
   		PREPARE DQuery FROM @t;
           SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED ;
   		EXECUTE DQuery;
           SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ ;        
   		DEALLOCATE PREPARE DQuery;        
           
           SET v_indexId = IFNULL(@indexId,0);
           
           
           SET @t = CONCAT("SELECT indexId,id,sourceTimestamp,timestamp,`from`,`to`,chatId,type,domainId,message,deliveryreport,readreport,createdAt,updatedAt, case when JSON_LENGTH(deliveryreport) = 0 then 4 else 8 end deliveryStatus, case when JSON_LENGTH(readreport) = 0 then 0 else 1 end readStatus FROM ",v_ChatMessageTable," ch  WHERE domainId = '",p_prefix,"' and indexId < ",v_indexId," AND chatId = '",p_ChatId,"' AND updatedAt >= '",v_LastReadDatetime,"' and JSON_EXTRACT(message, '$.persistDelete.s", p_fromId," ') IS NULL ORDER BY indexId ", p_orderType," LIMIT ",p_offset);
          
           PREPARE DQuery FROM @t;
           SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED ;
   		EXECUTE DQuery;
   		SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ ;
   		DEALLOCATE PREPARE DQuery;
   	ELSE
   		
   		SET @t = CONCAT("SELECT indexId,id,sourceTimestamp,timestamp,`from`,`to`,chatId,type,domainId,message,deliveryreport,readreport,createdAt,updatedAt, case when  JSON_LENGTH(deliveryreport) = 0 then 4 else 8 end deliveryStatus, case when JSON_LENGTH(readreport) = 0 then 0 else 1 end readStatus FROM ",v_ChatMessageTable," ch  WHERE domainId = '",p_prefix,"' and chatId = '",p_ChatId,"' AND updatedAt >= '",v_LastReadDatetime,"' and JSON_EXTRACT(message, '$.persistDelete.s", p_fromId," ') IS NULL ORDER BY indexId ", p_orderType," LIMIT ",p_offset);
           PREPARE DQuery FROM @t;
           SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED ;
   		EXECUTE DQuery;
           SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ ;
   		DEALLOCATE PREPARE DQuery;
       END IF;
   END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `up_GetChatHistory_dynamic_group` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`javateam`@`%` PROCEDURE `up_GetChatHistory_dynamic_group`(	
  	p_prefix				varchar(4)
   	,p_ChatId				varchar(120)
   	,p_id					char(36)	
	,p_LastReadTimestamp	BIGINT
  	,p_orderType			varchar(4)
  	,p_offset 				int
    ,p_fromId				int    
   )
SP_LEAVE:BEGIN
	DECLARE v_indexId			int;
	DECLARE v_LastReadDatetime	Datetime;        
	DECLARE v_ChatMessageTable	VARCHAR(30);
    DECLARE v_id				char(36);
    
    SET v_id = IF(p_id = '',NULL,p_id);
       
       SET v_LastReadDatetime = FROM_UNIXTIME(p_LastReadTimestamp/1000);
       
       
       SET v_ChatMessageTable = 'chatmessage';
          
       IF v_id IS NOT NULL THEN        
   		SET @t = CONCAT("SELECT indexId into @indexId FROM ",v_ChatMessageTable," WHERE domainId = '",p_prefix,"' and id = '",v_id,"' ORDER BY indexId DESC LIMIT 1");
           
   		PREPARE DQuery FROM @t;
           SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED ;
   		EXECUTE DQuery;
           SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ ;        
   		DEALLOCATE PREPARE DQuery;        
           
           SET v_indexId = IFNULL(@indexId,0);
           
           
           SET @t = CONCAT("SELECT indexId,id,sourceTimestamp,timestamp,`from`,`to`,chatId,type,domainId,message,deliveryreport,readreport,createdAt,updatedAt, case when (JSON_LENGTH(deliveryreport)-1)>= (LENGTH(`to`) - LENGTH(REPLACE(`to`, ',', ''))) / LENGTH(',') then 8 else 4 end deliveryStatus, case when (JSON_LENGTH(readreport)-1)>= (LENGTH(`to`) - LENGTH(REPLACE(`to`, ',', ''))) / LENGTH(',') then 1 else 0 end readStatus FROM ",v_ChatMessageTable," ch  WHERE domainId = '",p_prefix,"' and indexId < ",v_indexId," AND chatId = '",p_ChatId,"' AND updatedAt >= '",v_LastReadDatetime,"' and JSON_EXTRACT(message, '$.persistDelete.s", p_fromId," ') IS NULL ORDER BY indexId ", p_orderType," LIMIT ",p_offset);
          
           PREPARE DQuery FROM @t;
           SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED ;
   		EXECUTE DQuery;
   		SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ ;
   		DEALLOCATE PREPARE DQuery;
   	ELSE
   		
   		SET @t = CONCAT("SELECT indexId,id,sourceTimestamp,timestamp,`from`,`to`,chatId,type,domainId,message,deliveryreport,readreport,createdAt,updatedAt, case when  (JSON_LENGTH(deliveryreport)-1)>= (LENGTH(`to`) - LENGTH(REPLACE(`to`, ',', ''))) / LENGTH(',') then 8 else 4 end deliveryStatus, case when (JSON_LENGTH(readreport)-1)>= (LENGTH(`to`) - LENGTH(REPLACE(`to`, ',', ''))) / LENGTH(',') then 1 else 0 end readStatus FROM ",v_ChatMessageTable," ch  WHERE domainId = '",p_prefix,"' and chatId = '",p_ChatId,"' AND updatedAt >= '",v_LastReadDatetime,"' and JSON_EXTRACT(message, '$.persistDelete.s", p_fromId," ') IS NULL ORDER BY indexId ", p_orderType," LIMIT ",p_offset);
           PREPARE DQuery FROM @t;
           SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED ;
   		EXECUTE DQuery;
           SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ ;
   		DEALLOCATE PREPARE DQuery;
       END IF;
   END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `up_GetChatHistory_dynamic_test` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`javateam`@`%` PROCEDURE `up_GetChatHistory_dynamic_test`(	
  p_prefix				varchar(4)
  ,p_ChatId				varchar(120)
  ,p_id					char(36)	
  ,p_LastReadTimestamp	BIGINT
  ,p_orderType			varchar(4)
  ,p_offset 				int
  ,p_fromId				int    
       )
SP_LEAVE:BEGIN
    	DECLARE v_indexId			int;
    	DECLARE v_LastReadDatetime	Datetime;        
    	DECLARE v_ChatMessageTable	VARCHAR(30);
        DECLARE v_id				char(36);
        
        SET v_id = IF(p_id = '',NULL,p_id);
           
           SET v_LastReadDatetime = FROM_UNIXTIME(p_LastReadTimestamp/1000);
           
           
           SET v_ChatMessageTable = 'chatmessage';
              
           IF v_id IS NOT NULL THEN        
       		 SET @t = CONCAT("SELECT indexId into @indexId FROM ",v_ChatMessageTable," WHERE domainId = '",p_prefix,"' and id = '",v_id,"' ORDER BY indexId DESC LIMIT 1");
               
       		PREPARE DQuery FROM @t;
               SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED ;
       		EXECUTE DQuery;
               SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ ;        
       		DEALLOCATE PREPARE DQuery;        
               
               SET v_indexId = IFNULL(@indexId,0);
               
               
               SET @t = CONCAT("SELECT indexId,id,sourceTimeStamp,timestamp,`from`,`to`,chatId,type,domainId,message,deliveryreport,readreport,createdAt,updatedAt, case when JSON_LENGTH(deliveryreport) = 0 then 4 else 8 end deliveryStatus, case when JSON_LENGTH(readreport) = 0 then 0 else 1 end readStatus FROM ",v_ChatMessageTable,"   WHERE domainId = '",p_prefix,"' and indexId < ",v_indexId," AND chatId = '",p_ChatId,"' AND updatedAt >= '",v_LastReadDatetime,"' and JSON_EXTRACT(message, '$.persistDelete.s", p_fromId," ') IS NULL ORDER BY indexId ", p_orderType," LIMIT ",p_offset);
              
               PREPARE DQuery FROM @t;
               SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED ;
       		EXECUTE DQuery;
       		SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ ;
       		DEALLOCATE PREPARE DQuery;
       	ELSE
       		
              SET @t = CONCAT("SELECT indexId,id,sourceTimeStamp,timestamp,`from`,`to`,chatId,type,domainId,message,deliveryreport,readreport,createdAt,updatedAt, case when  JSON_LENGTH(deliveryreport) = 0 then 4 else 8 end deliveryStatus, case when JSON_LENGTH(readreport) = 0 then 0 else 1 end readStatus FROM ",v_ChatMessageTable,"   WHERE domainId = '",p_prefix,"' and chatId = '",p_ChatId,"' AND updatedAt >= '",v_LastReadDatetime,"' and JSON_EXTRACT(message, '$.persistDelete.s", p_fromId," ') IS NULL ORDER BY indexId ", p_orderType," LIMIT ",p_offset);
               PREPARE DQuery FROM @t;
               SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED ;
       		EXECUTE DQuery;
               SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ ;
       		DEALLOCATE PREPARE DQuery;
           END IF;
       END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `up_GetDevicepushNotificationId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `up_GetDevicepushNotificationId`(
pdomainId int,
pdeviceId varchar(128)
)
Begin
	SELECT * FROM connection where domainId = pdomainId and (deviceId = pdeviceId or ifnull(pdeviceId,'')='');
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Up_history_chat` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`javateam`@`%` PROCEDURE `Up_history_chat`(
		p_chatId  		VARCHAR(120)
        ,p_userID		INT	
        ,p_offset 		INT
)
begin
 
	SELECT * FROM (
    SELECT * FROM chatmessage 
    WHERE chatId = p_chatId 
    
	
    ORDER BY indexId DESC LIMIT p_offset) AS A 
    ORDER BY A.indexId ASC;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `up_InsertUpdateChatClearedTime` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`javateam`@`%` PROCEDURE `up_InsertUpdateChatClearedTime`(	p_chatId			VARCHAR(120)		
 	,p_userId			INT	
 	,p_clearedTime    	BIGINT
     ,p_domainId			INT
 )
BEGIN
 	DECLARE v_CurDate		DATETIME;
     
     SET v_CurDate = NOW();
     
 	IF EXISTS (	SELECT 	1
 				FROM 	tb_ChatClearedTime
 				WHERE 	chatId	= p_chatId 
 				AND 	userId	= p_userId )
 	THEN
 		UPDATE 	tb_ChatClearedTime
 		SET 	clearedTime = p_clearedTime
 		
             ,	updatedDate	= v_CurDate
         WHERE 	chatId	= p_chatId 
 		AND 	userId	= p_userId;
 	ELSE
 		INSERT INTO tb_ChatClearedTime
         (	chatId
 			,userId
 			,clearedTime
             ,domainId
 
 			,createdDate
 			,updatedDate
         )
         VALUES
         (	p_chatId
 			,p_userId
             ,p_clearedTime
             ,p_domainId
 	
             ,v_CurDate
             ,v_CurDate
         );
     END IF;
     
     SELECT p_clearedTime AS 'clearedTime', 1  AS 'isCleared';    
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-21  9:38:38
