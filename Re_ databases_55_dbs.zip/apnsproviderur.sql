-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: apnsproviderur
-- ------------------------------------------------------
-- Server version	8.0.44-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `apnsproviderur`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `apnsproviderur` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `apnsproviderur`;

--
-- Table structure for table `CAMPAIGN_NOTIFY_SMS_LOG`
--

DROP TABLE IF EXISTS `CAMPAIGN_NOTIFY_SMS_LOG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CAMPAIGN_NOTIFY_SMS_LOG` (
  `id` int NOT NULL AUTO_INCREMENT,
  `campaign_id` int DEFAULT NULL,
  `device_type` varchar(150) DEFAULT NULL,
  `cli` varchar(20) DEFAULT NULL,
  `msg_content` varchar(250) DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `sent_flag` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `campaign_id` (`campaign_id`),
  CONSTRAINT `CAMPAIGN_NOTIFY_SMS_LOG_ibfk_1` FOREIGN KEY (`campaign_id`) REFERENCES `campaign` (`campaign_id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `SMS_MESSAGE_CONFIG`
--

DROP TABLE IF EXISTS `SMS_MESSAGE_CONFIG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SMS_MESSAGE_CONFIG` (
  `Sms_id` int NOT NULL AUTO_INCREMENT,
  `product_name` varchar(100) DEFAULT NULL,
  `Scenerio` varchar(160) DEFAULT NULL,
  `push_msg_content` varchar(320) DEFAULT NULL,
  `Create_date` datetime DEFAULT NULL,
  `Status` int DEFAULT NULL,
  `last_update` datetime DEFAULT NULL,
  PRIMARY KEY (`Sms_id`),
  UNIQUE KEY `IDXSMS_MESSAGE_CONFIG_product_name_Scenerio` (`product_name`,`Scenerio`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `androidsubscriptions`
--

DROP TABLE IF EXISTS `androidsubscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `androidsubscriptions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `AccountID` varchar(250) DEFAULT NULL,
  `DeviceID` varchar(250) DEFAULT NULL,
  `Application` varchar(250) DEFAULT NULL,
  `AddedOn` datetime DEFAULT NULL,
  `Active` bit(1) DEFAULT NULL,
  `UpdatedOn` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `campaign`
--

DROP TABLE IF EXISTS `campaign`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `campaign` (
  `campaign_id` int NOT NULL AUTO_INCREMENT,
  `product_name` varchar(250) DEFAULT NULL,
  `campaign_name` varchar(250) DEFAULT NULL,
  `campaign_type` varchar(100) DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  PRIMARY KEY (`campaign_id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `subscriptions`
--

DROP TABLE IF EXISTS `subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subscriptions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `MessageToken` varchar(250) DEFAULT NULL,
  `VOIPToken` varchar(250) DEFAULT NULL,
  `DeviceID` varchar(250) DEFAULT NULL,
  `Application` varchar(250) DEFAULT NULL,
  `AddedOn` datetime DEFAULT NULL,
  `Active` bit(1) DEFAULT NULL,
  `UpdatedOn` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `DeviceType` int DEFAULT NULL,
  `DeviceIdenty` varchar(250) DEFAULT NULL,
  `device_type_id` varchar(250) DEFAULT NULL,
  `signin_flg` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=269569 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `usp_insert_subscription_log`
--

DROP TABLE IF EXISTS `usp_insert_subscription_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usp_insert_subscription_log` (
  `DeviceID` varchar(250) DEFAULT NULL,
  `MessageToken` varchar(250) DEFAULT NULL,
  `VOIPToken` varchar(250) DEFAULT NULL,
  `Application` varchar(250) DEFAULT NULL,
  `DeviceType` int DEFAULT NULL,
  `dev_identy` varchar(250) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=468418 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping events for database 'apnsproviderur'
--

--
-- Dumping routines for database 'apnsproviderur'
--
/*!50003 DROP FUNCTION IF EXISTS `fc_get_Device_token_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` FUNCTION `fc_get_Device_token_info`(DeviceID VARCHAR(250),  
type INT) RETURNS longtext CHARSET utf8mb4
    DETERMINISTIC
BEGIN

  
   DECLARE v_subs_info LONGTEXT;  
   
   if type = 1 then
 
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select   IFNULL(a.MessageToken,'') INTO v_subs_info from subscriptions  a where a.DeviceID = DeviceID  and a.Active = 1 and
      IFNULL(a.MessageToken,'') <> ''   order by a.UpdatedOn desc LIMIT 1;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   end if;  
   
   if type = 2 then
 
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select   IFNULL(a.VOIPToken,'') INTO v_subs_info from subscriptions  a where a.DeviceID = DeviceID  and a.Active = 1 and
      IFNULL(a.MessageToken,'') <> ''   order by a.UpdatedOn desc LIMIT 1;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   end if;  
   
   if type = 3 then
 
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select   IFNULL(a.DeviceType,0) INTO v_subs_info from subscriptions  a where a.DeviceID = DeviceID  and a.Active = 1 and
      IFNULL(a.MessageToken,'') <> ''   order by a.UpdatedOn desc LIMIT 1;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   end if;  
   
 
   if type = 4 then
 
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select   IFNULL(a.DeviceIdenty,'') INTO v_subs_info from subscriptions  a where a.DeviceID = DeviceID  and a.Active = 1 and
      IFNULL(a.MessageToken,'') <> ''   order by a.UpdatedOn desc LIMIT 1;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   end if;  
   
   return v_subs_info;  
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `push_notification_get_device_token_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `push_notification_get_device_token_info`(v_product_code VARCHAR(10),
v_device_type INT,
v_device_info LONGTEXT)
SWL_return:
BEGIN
	
	
   DROP TEMPORARY TABLE IF EXISTS tt_temp_notification_no;
   create TEMPORARY table tt_temp_notification_no
   (
      number VARCHAR(20)
   );
		
   IF v_device_info = 'ALL' then
	
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select distinct  MessageToken, VOIPToken,DeviceID,UpdatedOn,DeviceType
      from subscriptions
      where IFNULL(MessageToken,'') <> '' and DeviceID is not null AND
		((v_device_type = 0) or (DeviceType = v_device_type))
      order by UpdatedOn desc;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
      LEAVE SWL_return;
   end if;


call split(v_device_info);

   insert into tt_temp_notification_no(number)
   select item from tt_split_temptable;

   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select distinct  MessageToken, VOIPToken,DeviceID,UpdatedOn,DeviceType
   from subscriptions
   where IFNULL(MessageToken,'') <> '' and DeviceID is not null AND
	((v_device_type = 0) or (DeviceType = v_device_type)) and
   DeviceID in(select number from tt_temp_notification_no);
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
	
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `push_ntfy_camp_content_create_update_text` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `push_ntfy_camp_content_create_update_text`(v_sms_text NVARCHAR(160),
v_status INT,
v_process_flag INT,
v_sms_id INT,
v_Scenerio  VARCHAR(100),
v_product_name VARCHAR(5))
BEGIN

	
	
   DECLARE v_now DATETIME(3); 
   DECLARE v_errcode INT; 
   DECLARE v_errmsg VARCHAR(160);
	
   IF v_process_flag is null then
      set v_process_flag = 1;
   END IF;
   sp_exit:
   BEGIN
      IF v_process_flag is null then
         set v_process_flag = 1;
      END IF;
      set v_now = CURRENT_TIMESTAMP;
	
	
      IF v_process_flag = 1 then
	
         IF EXISTS(SELECT  1  FROM SMS_MESSAGE_CONFIG WHERE Scenerio = v_Scenerio and product_name = v_product_name LIMIT 1) then
		
            set v_errcode = -1;
            set v_errmsg = 'Entered Scenerio already exists.';
            LEAVE sp_exit;
         end if;
         INSERT INTO SMS_MESSAGE_CONFIG(product_name,Scenerio,push_msg_content,Create_date,Status)
		VALUES(v_product_name,v_Scenerio,v_sms_text,v_now,v_status);
		
         if ROW_COUNT() > 0 then
		
            set v_errcode = 0;
            set v_errmsg = 'Success to create Push notification content';
         end if;
         SET v_sms_id = LAST_INSERT_ID();
      end if;
      IF v_process_flag = 2 then
	
         IF NOT EXISTS(SELECT  1 FROM SMS_MESSAGE_CONFIG WHERE Sms_id = v_sms_id LIMIT 1) then
		
            SET v_errcode = -1;
            SET v_errmsg = 'Message configuration not found.';
            LEAVE sp_exit;
         end if;
         IF EXISTS(SELECT  1  FROM SMS_MESSAGE_CONFIG WHERE Scenerio = v_Scenerio and Sms_id <> v_sms_id
         and product_name = v_product_name LIMIT 1) then
		
            set v_errcode = -1;
            set v_errmsg = 'Entered Scenerio already exists.';
            LEAVE sp_exit;
         end if;
         UPDATE SMS_MESSAGE_CONFIG SET push_msg_content = v_sms_text,last_update = v_now,Scenerio = v_Scenerio,product_name = v_product_name
         Where Sms_id = v_sms_id;
         if ROW_COUNT() > 0 then
		
            set v_errcode = 0;
            set v_errmsg = 'Success to update push notification content';
         end if;
      end if;
   END;
   select v_errcode as errcode,v_errmsg as errmsg,v_sms_id as message_id;
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `push_ntfy_camp_content_get_text` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `push_ntfy_camp_content_get_text`(v_sms_id INT,
v_scenerio VARCHAR(100),
v_product_name VARCHAR(5))
BEGIN

	

   IF v_sms_id is null then
      set v_sms_id = 0;
   END IF;
   IF v_scenerio is null then
      set v_scenerio = '';
   END IF;
   IF v_product_name is null then
      set v_product_name = 'ALL';
   END IF;
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   SELECT Sms_id,
	Scenerio,
	push_msg_content,
	Create_date,
	case when  Status = 1 then 'Active' else 'Inactive' end as Status FROM SMS_MESSAGE_CONFIG
   WHERE ((Sms_id = v_sms_id) OR (v_sms_id = 0)) AND
	   ((Scenerio = v_scenerio) or (v_scenerio = '')) AND
	   ((v_product_name = 'ALL') OR (product_name = v_product_name));
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ur_getdevicetoken_by_deviceid` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ur_getdevicetoken_by_deviceid`(DeviceID VARCHAR(100))
Begin
 
 	
    
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    Select  MessageToken message_token,VOIPToken as voip_token,DeviceType,DeviceIdenty as dev_identy
    from subscriptions a
    where a.DeviceID = DeviceID  and Active = 1
    order by UpdatedOn desc;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ; 
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ur_getdevicetoken_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ur_getdevicetoken_info`(extension INT,
 domain_id INT)
Begin
 
 	
 
    DECLARE v_DeviceID VARCHAR(100);
 	
    set v_DeviceID = CONCAT(cast(domain_id as CHAR(30)),'_',cast(extension as CHAR(30))); 
 	   
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    Select  MessageToken message_token,VOIPToken as voip_token,DeviceType
    from subscriptions 
    where DeviceID = v_DeviceID  and Active = 1
    order by UpdatedOn desc;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ; 
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ur_get_receiver_sip_userdetails_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ur_get_receiver_sip_userdetails_info`(
  from_sip_login_id INT,  
  to_sip_login_id INT,  
  domain_name VARCHAR(50))
Begin
    
     DECLARE v_errcode INT; 
     DECLARE v_errmsg VARCHAR(50);  
     DECLARE v_from_app_log_id INT; 
     DECLARE v_to_app_log_id INT; 
     DECLARE v_DeviceID VARCHAR(100); 
     DECLARE v_to_DeviceID VARCHAR(100);  
     DECLARE v_from_extension INT;
     DECLARE v_to_extension INT;  
     DECLARE v_from_company_id INT; 
     DECLARE v_to_company_id INT;  
     DECLARE v_from_dir_user_id INT; 
     DECLARE v_to_dir_user_id INT;  
     DECLARE v_from_domain_id INT; 
     DECLARE v_to_domain_id INT; 
     DECLARE v_domain_name_id INT;  
     DECLARE v_Firstname VARCHAR(100); 
     DECLARE v_surname VARCHAR(100); 
     DECLARE v_is_phone_notif_enabled INT;  
    
     sp_exit:BEGIN
     
        Set v_errcode = -1;
        Set v_errmsg = 'Failure';  
    
   
        if not exists(select  1 from unifiedring.ur_sip_credential where sip_login_id = from_sip_login_id LIMIT 1) 
        then
   
           Set v_errcode = -1;
           Set v_errmsg = 'Sip id not found';
           LEAVE sp_exit;
        end if;  
    
   
        if not exists(select  1 from unifiedring.ur_sip_credential where sip_login_id = to_sip_login_id LIMIT 1) 
        then
   
           Set v_errcode = -1;
           Set v_errmsg = 'Sip id not found';
           LEAVE sp_exit;
        end if;
        
        if not exists(select  1 from unifiedring.dir_domains a where left(a.domain_name,4) = left(domain_name,4) LIMIT 1) 
        then
   
           Set v_errcode = -1;
           Set v_errmsg = 'domain name not found';
           LEAVE sp_exit;
        end if;
        
        select   id INTO v_domain_name_id from unifiedring.dir_domains a where left(a.domain_name,4) = left(domain_name,4) limit 1;
        
        select   app_log_id INTO v_from_app_log_id from unifiedring.ur_sip_credential where sip_login_id = from_sip_login_id  limit 1;
        
        
        select   app_log_id INTO v_to_app_log_id from unifiedring.ur_sip_credential where sip_login_id = to_sip_login_id  limit 1;
        
        select   company_id, dir_user_id INTO v_from_company_id,v_from_dir_user_id from unifiedring.ur_app_login_details where app_log_id = v_from_app_log_id  limit 1;
        
        select   company_id, dir_user_id INTO v_to_company_id,v_to_dir_user_id from unifiedring.ur_app_login_details where app_log_id = v_to_app_log_id  limit 1;
        
        select   domain_id, user_id INTO v_from_domain_id,v_from_extension from unifiedring.dir_users where id = v_from_dir_user_id  limit 1;
        
        select   domain_id, user_id INTO v_to_domain_id,v_to_extension from unifiedring.dir_users where id = v_to_dir_user_id  limit 1;
        
        select   Firstname, surname INTO v_Firstname,v_surname from unifiedring.UR_ECom_User_Extension_Dtl  where Extension_Number = v_from_extension and company_id = v_from_company_id  limit 1;
        
        set v_to_DeviceID = CONCAT(cast(v_to_domain_id as CHAR(30)),'_',cast(v_to_extension as CHAR(30)));
        set v_is_phone_notif_enabled = 0;
        
        if not exists(select  1 from unifiedring.ur_app_phone_notif_contact
        where app_log_id = v_from_app_log_id and mobileno = cast(v_to_extension as CHAR(30)) LIMIT 1) 
        then
   
           set v_is_phone_notif_enabled = 1;
        end if;
        
        if v_is_phone_notif_enabled = 0 
        then
   
			Select null to_message_token,
			null as to_voip_token,
			null to_DeviceType,
			null as to_DeviceID,
			v_Firstname as from_firstname,
			v_surname as from_lastname,
			null as to_DeviceIdent;
      
        Else
        
  	if exists(select  1 from unifiedring.ur_app_mute_contact where app_log_id = v_to_app_log_id and mobileno = cast(v_from_extension as CHAR(30))
           and (expiry_at > CURRENT_TIMESTAMP or till not in(0,1,12)) LIMIT 1) 
           then
    
			Select null to_message_token,
			null as to_voip_token,
			null to_DeviceType,
			null as to_DeviceID,
			v_Firstname as from_firstname,
			v_surname as from_lastname,
			null as to_DeviceIdent;
           Else 
              if exists(select  1 from unifiedring.ur_app_mute_contact where app_log_id = v_to_app_log_id and mobileno = cast(v_from_extension as CHAR(30))
              and (expiry_at < CURRENT_TIMESTAMP or till not in(0,1,12)) LIMIT 1) 
              then  
                 
                 Select  MessageToken to_message_token,VOIPToken as to_voip_token,DeviceType to_DeviceType,DeviceID as to_DeviceID,v_Firstname as from_firstname,v_surname as from_lastname,DeviceIdenty as to_DeviceIdenty
                 from subscriptions 
                 where DeviceID = v_to_DeviceID  and Active = 1  and signin_flg = 1
                 order by UpdatedOn desc;
                 
              Else
                 
                 Select  MessageToken to_message_token,VOIPToken as to_voip_token,DeviceType to_DeviceType,DeviceID as to_DeviceID,v_Firstname as from_firstname,v_surname as from_lastname,DeviceIdenty as to_DeviceIdenty
                 from subscriptions 
                 where DeviceID = v_to_DeviceID  and Active = 1  and signin_flg = 1
                 order by UpdatedOn desc;
                 
              end if;
           end if;
        end if;
        
        if found_rows() > 0 
        then
   
           Set v_errcode = 0;
           Set v_errmsg = 'Success';
           LEAVE sp_exit;
        end if;
     END;
     select v_errcode as errcode,v_errmsg as errmsg;  
     
  End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ur_get_sip_userdetails_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ur_get_sip_userdetails_info`(sip_login_id INT,  
 domain_name VARCHAR(50))
Begin
   
    DECLARE v_errcode INT; 
    DECLARE v_errmsg VARCHAR(50);  
    DECLARE v_app_log_id INT; 
    DECLARE v_DeviceID VARCHAR(100); 
    DECLARE v_extension INT;
    DECLARE v_company_id INT;
    DECLARE v_dir_user_id INT;
    DECLARE v_domain_id INT; 
    DECLARE v_domain_name_id INT;  
    DECLARE v_Firstname VARCHAR(100); 
    DECLARE v_surname VARCHAR(100);
    DECLARE Swv_RowCount INT;  
   
 
    
       Set v_errcode = -1;
       Set v_errmsg = 'Failure';
sp_exit : BEGIN
    if not exists(select  1 from unifiedring.ur_sip_credential a where a.sip_login_id = sip_login_id LIMIT 1) 
    then 
          Set v_errcode = -1;
          Set v_errmsg = 'Sip id not found';
          LEAVE sp_exit;
       end if;
       
       if not exists(select  1 from unifiedring.dir_domains b where left(b.domain_name,4) = left(domain_name,4) LIMIT 1) 
       then 
          Set v_errcode = -1;
          Set v_errmsg = 'domain name not found';
          LEAVE sp_exit;
       end if;
       
       select   id INTO v_domain_name_id from unifiedring.dir_domains b where left(b.domain_name,4) = left(domain_name,4);
       SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
       select   app_log_id INTO v_app_log_id from unifiedring.ur_sip_credential a where a.sip_login_id = sip_login_id;
       SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
       SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
       select   company_id, dir_user_id INTO v_company_id,v_dir_user_id from unifiedring.ur_app_login_details 
       where app_log_id = v_app_log_id;
       SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
       SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
       select   domain_id, user_id INTO v_domain_id,v_extension from unifiedring.dir_users where id = v_dir_user_id;
       SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
       SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
       select   Firstname, surname INTO v_Firstname,v_surname from unifiedring.UR_ECom_User_Extension_Dtl  
       where Extension_Number = v_extension and company_id = v_company_id;
       SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
       set v_DeviceID = CONCAT(cast(v_domain_id as CHAR(30)),'_',cast(v_extension as CHAR(30)));
       SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
       Select  MessageToken message_token,VOIPToken as voip_token,DeviceType,DeviceID ,v_Firstname as Firstname,
       v_surname as lastname,DeviceIdenty
       from subscriptions 
       where DeviceID = v_DeviceID  and Active = 1  and signin_flg = 1
       order by UpdatedOn desc;
       SET Swv_RowCount = found_rows();
       SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
       
       if found_rows() > 0 
       then 
          Set v_errcode = 0;
          Set v_errmsg = 'Success';
          LEAVE sp_exit;
       end if;
       
    END;
    select v_errcode as errcode,v_errmsg as errmsg;  
    
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ur_get_sip_userdetails_info_test` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ur_get_sip_userdetails_info_test`(v_sip_login_id INT,
v_domain_name VARCHAR(50))
Begin


   DECLARE v_errcode INT; 
   DECLARE v_errmsg VARCHAR(50);
   DECLARE v_app_log_id INT; 
   DECLARE v_DeviceID VARCHAR(100); 
   DECLARE v_extension INT;
   DECLARE v_company_id INT;
   DECLARE v_dir_user_id INT;
   DECLARE v_domain_id INT; 
   DECLARE v_domain_name_id INT;
   DECLARE v_Firstname VARCHAR(100); 
   DECLARE v_surname VARCHAR(100);
   DECLARE Swv_RowCount INT;

   sp_exit:
   BEGIN
      Set v_errcode = -1;
      Set v_errmsg = 'Failure';
      if not exists(select  1 from unifiedring.ur_sip_credential where sip_login_id = v_sip_login_id LIMIT 1) then
	
         Set v_errcode = -1;
         Set v_errmsg = 'Sip id not found';
         LEAVE sp_exit;
      end if;
      if not exists(select  1 from unifiedring.dir_domains where left(domain_name,4) = left(v_domain_name,4) LIMIT 1) then
	
         Set v_errcode = -1;
         Set v_errmsg = 'domain name not found';
         LEAVE sp_exit;
      end if;
      select   id INTO v_domain_name_id from unifiedring.dir_domains where left(domain_name,4) = left(v_domain_name,4);
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select   app_log_id INTO v_app_log_id from unifiedring.ur_sip_credential where sip_login_id = v_sip_login_id;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select   company_id, dir_user_id INTO v_company_id,v_dir_user_id from unifiedring.ur_app_login_details where app_log_id = v_app_log_id;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select   domain_id, user_id INTO v_domain_id,v_extension from unifiedring.dir_users where id = v_dir_user_id;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select   Firstname, surname INTO v_Firstname,v_surname from unifiedring.UR_ECom_User_Extension_Dtl  where Extension_Number = v_extension and company_id = v_company_id;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
      set v_DeviceID = CONCAT(cast(v_domain_id as CHAR(30)),'_',cast(v_extension as CHAR(30)));
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      Select  MessageToken message_token,VOIPToken as voip_token,DeviceType,DeviceID ,v_Firstname as Firstname,v_surname as lastname,DeviceIdenty
      from subscriptions where DeviceID = v_DeviceID  and Active = 1  and signin_flg = 1 order by UpdatedOn desc;
      SET Swv_RowCount = ROW_COUNT();
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
      if Swv_RowCount > 0 then
	
         Set v_errcode = 0;
         Set v_errmsg = 'Success';
         LEAVE sp_exit;
      end if;
   END;
   select v_errcode as errcode,v_errmsg as errmsg;
	
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ur_get_sip_userdetails_info_test1` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ur_get_sip_userdetails_info_test1`(v_sip_login_id INT,
 v_domain_name VARCHAR(50))
Begin
 
 
    DECLARE v_errcode INT; 
    DECLARE v_errmsg VARCHAR(50);
    DECLARE v_app_log_id INT; 
    DECLARE v_DeviceID VARCHAR(100); 
    DECLARE v_extension INT;
    DECLARE v_company_id INT;
    DECLARE v_dir_user_id INT;
    DECLARE v_domain_id INT; 
    DECLARE v_domain_name_id INT;
    DECLARE v_Firstname VARCHAR(100); 
    DECLARE v_surname VARCHAR(100);
    DECLARE Swv_RowCount INT;
 
    sp_exit:
    BEGIN
       Set v_errcode = -1;
       Set v_errmsg = 'Failure';
       if not exists(select  1 from unifiedring.ur_sip_credential where sip_login_id = v_sip_login_id LIMIT 1) then
 	
          Set v_errcode = -1;
          Set v_errmsg = 'Sip id not found';
          LEAVE sp_exit;
       end if;
       if not exists(select  1 from unifiedring.dir_domains where left(domain_name,4) = left(v_domain_name,4) LIMIT 1) then
 	
          Set v_errcode = -1;
          Set v_errmsg = 'domain name not found';
          LEAVE sp_exit;
       end if;
       select   id INTO v_domain_name_id from unifiedring.dir_domains where left(domain_name,4) = left(v_domain_name,4);
       SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
       select   app_log_id INTO v_app_log_id from unifiedring.ur_sip_credential where sip_login_id = v_sip_login_id;
       SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
       SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
       select   company_id, dir_user_id INTO v_company_id,v_dir_user_id from unifiedring.ur_app_login_details where app_log_id = v_app_log_id;
       SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
       SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
       select   domain_id, user_id INTO v_domain_id,v_extension from unifiedring.dir_users where id = v_dir_user_id;
       SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
       SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
       select   Firstname, surname INTO v_Firstname,v_surname from unifiedring.UR_ECom_User_Extension_Dtl  where Extension_Number = v_extension and company_id = v_company_id;
       SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
       set v_DeviceID = CONCAT(cast(v_domain_id as CHAR(30)),'_',cast(v_extension as CHAR(30)));
       SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
       Select  MessageToken message_token,VOIPToken as voip_token,DeviceType,DeviceID ,v_Firstname as Firstname,v_surname as lastname,DeviceIdenty
       from subscriptions where DeviceID = v_DeviceID  and Active = 1  and signin_flg = 1 order by UpdatedOn desc;
      select row_count();
       SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
       if found_rows() > 0 then
 	
          Set v_errcode = 0;
          Set v_errmsg = 'Success';
          LEAVE sp_exit;
       end if;
    END;
    select v_errcode as errcode,v_errmsg as errmsg;
 	
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `usp_deactivate_devicetoken` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `usp_deactivate_devicetoken`(MessageToken VARCHAR(250),
VOIPToken VARCHAR(250))
BEGIN

		
					
   DECLARE v_errcode INT; 
   DECLARE v_errmsg VARCHAR(250);
		
   set v_errcode = -1;
   set v_errmsg = 'Failure to deactivate';
					
   if (IFNULL(VOIPToken,'') <> '') or IFNULL(MessageToken,'') <> '' then
		
      update subscriptions a  SET Active = 0
      WHERE ((a.MessageToken = MessageToken and IFNULL(MessageToken,'') <> '') or  (a.VOIPToken = VOIPToken and IFNULL(VOIPToken,'') <> ''));
      if ROW_COUNT() > 0 then
			
         set v_errcode = 0;
         set v_errmsg = 'Success to deactivate Token';
      end if;
   end if;
   Select v_errcode as errcode,v_errmsg as errmsg;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `usp_getandroiddeviceid` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `usp_getandroiddeviceid`(v_AccountID VARCHAR(250))
Begin
	   
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   
   Select DeviceID from androidsubscriptions  where AccountID = v_AccountID and Active = 1;
   
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `usp_getdevicetoken` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `usp_getdevicetoken`(DeviceID VARCHAR(250),
device_type INT)
Begin


	

   DECLARE v_domain_out VARCHAR(100);
	
   IF device_type is null then
      set device_type = 0;
   END IF;
   
   CALL unifiedring.uf_get_enterpriseid_detail(DeviceID,v_domain_out);
	
	   
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   Select   MessageToken message_token,VOIPToken as voip_token ,DeviceIdenty
   from subscriptions s
   where (s.DeviceID = DeviceID or DeviceID = v_domain_out) and Active = 1 and
	( (device_type = 0) or   (s.DeviceType = device_type))
   order by UpdatedOn desc LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ; 
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `usp_getdevicetoken_logu` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `usp_getdevicetoken_logu`(v_DeviceID VARCHAR(250))
Begin

	

   DECLARE v_domain_out VARCHAR(100);
	
   CALL unifiedring.uf_get_enterpriseid_detail(v_DeviceID,v_domain_out);
	   
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   Select MessageToken message_token,VOIPToken voip_token from subscriptions 
   where (DeviceID = v_DeviceID or DeviceID = v_domain_out) and Active = 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `usp_getsubscription` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `usp_getsubscription`(v_DeviceID VARCHAR(250))
Begin
	   
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   Select MessageToken as message_token,VOIPToken as voip_token,Application as application,
   DeviceType as devicetype, DeviceID as device_id 
   from subscriptions  where DeviceID = v_DeviceID and Active = 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `usp_insert_androidsubscription` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `usp_insert_androidsubscription`(v_DeviceID VARCHAR(250) ,    
    v_AccountID VARCHAR(250) ,    
    v_Application VARCHAR(250))
Begin
  
   DECLARE v_errcode INT;
   DECLARE v_errmsg VARCHAR(100);    
    
   DELETE FROM androidsubscriptions WHERE DeviceID = v_DeviceID;
   DELETE FROM androidsubscriptions WHERE AccountID = v_AccountID;

   BEGIN
		 INSERT  INTO androidsubscriptions(AccountID ,DeviceID ,Application ,AddedOn ,Active)
		VALUES(v_AccountID , v_DeviceID , v_Application , CURRENT_TIMESTAMP , 1);

      Set v_errcode = 0;
      Set v_errmsg  = 'Inserted Successfully';
   END;    
   Select v_errcode errcode,v_errmsg errmsg;    
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `usp_insert_subscription` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `usp_insert_subscription`(DeviceID VARCHAR(250) ,      
     MessageToken VARCHAR(250) ,      
     VOIPToken VARCHAR(250) ,      
     Application VARCHAR(250),  
     DeviceType INT,
     dev_identy VARCHAR(250),
 	device_type_id VARCHAR(250), 
 	signin_flg INT 
 )
Begin
     
    DECLARE v_errcode INT;
    DECLARE v_errmsg VARCHAR(100);
    DECLARE v_Active INT;      
 
     
    IF dev_identy is null 
    then
       set dev_identy = '';
    END IF;
    
    sp_exit:BEGIN
    
       IF dev_identy is null 
       then
          set dev_identy = '';
       END IF;
       
       insert into usp_insert_subscription_log  (DeviceID,MessageToken,VOIPToken,Application,DeviceType,dev_identy)
       values(DeviceID,MessageToken,VOIPToken,Application,DeviceType,dev_identy);
       
       IF IFNULL(MessageToken,'') <> '' 
       then       
          if exists(select  * from subscriptions a where a.device_type_id = device_type_id and a.DeviceID = DeviceID LIMIT 1) then
 	  
             UPDATE subscriptions a set a.signin_flg = signin_flg,a.AddedOn = CURRENT_TIMESTAMP,
             a.Active = signin_flg,
             a.UpdatedOn = CURRENT_TIMESTAMP
             where  a.device_type_id = device_type_id and a.DeviceID = DeviceID;
             
             if found_rows() > 0 
             then			
                Set v_errcode = 0;
                Set v_errmsg  = 'Updated Successfully';
                LEAVE sp_exit;
             end if;
          end if;
 
 	  
          if IFNULL(VOIPToken,'') <> '' 
          then 	  
             UPDATE subscriptions a
             set a.Active = 0,a.signin_flg = 0
             where a.VOIPToken = VOIPToken;
          end if;
 	  
 
     
          INSERT  INTO subscriptions(MessageToken,VOIPToken ,DeviceID ,Application ,AddedOn ,Active,DeviceType,deviceidenty,device_type_id,signin_flg)
 		  VALUES(MessageToken ,VOIPToken , DeviceID , Application , CURRENT_TIMESTAMP , 1  ,DeviceType,dev_identy,device_type_id,signin_flg);
 		  
          if found_rows() > 0 
          then 		  
             Set v_errcode = 0;
             Set v_errmsg  = 'Inserted Successfully';
             LEAVE sp_exit;
          end if;
       end if;
    END;
    Select v_errcode errcode,v_errmsg errmsg;      
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `usp_update_subscription_signout` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `usp_update_subscription_signout`(DeviceID VARCHAR(250) ,      
     MessageToken VARCHAR(250) ,      
     VOIPToken VARCHAR(250) ,      
     Application VARCHAR(250),  
     DeviceType INT,
     dev_identy VARCHAR(250),
 	device_type_id VARCHAR(250), 
 	signin_flg INT 
 )
Begin
 
    DECLARE v_errcode INT;
    DECLARE v_errmsg VARCHAR(100);   
   
    IF dev_identy is null 
    then
       set dev_identy = '';
    END IF;
    
    set v_errcode = -1; 
    set v_errmsg = 'No records found';
 
 
    insert into usp_insert_subscription_log (DeviceID,MessageToken,VOIPToken,Application,DeviceType,dev_identy) 
    values(DeviceID,MessageToken,VOIPToken,Application,DeviceType,dev_identy);
 
 
 	
    if exists(select  1 from subscriptions a where a.MessageToken = MessageToken and a.VOIPToken = VOIPToken 
    and a.device_type_id = device_type_id LIMIT 1) 
    then 	
       UPDATE subscriptions a set a.signin_flg = 0,a.AddedOn = CURRENT_TIMESTAMP
       where a.MessageToken = MessageToken and a.VOIPToken = VOIPToken and a.device_type_id = device_type_id;
    end if;
 
 	 
    if row_count() > 0 
    then 	
       Set v_errcode = 0;
       Set v_errmsg  = 'Inserted Successfully';
    end if;    
 
 
    select v_errcode as errcode,v_errmsg as errmsg;
 
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-21  9:49:57
