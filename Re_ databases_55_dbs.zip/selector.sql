-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: selector
-- ------------------------------------------------------
-- Server version	8.0.44-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `selector`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `selector` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `selector`;

--
-- Table structure for table `NPCOUNTRY`
--

DROP TABLE IF EXISTS `NPCOUNTRY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `NPCOUNTRY` (
  `PREFIX` varchar(30) NOT NULL,
  `SITECODE` char(3) NOT NULL,
  `HOMEOPERATORID` varchar(5) DEFAULT NULL,
  `COUNTRY` varchar(32) DEFAULT NULL,
  `HOMEOPERATORRCID` varchar(20) DEFAULT NULL,
  UNIQUE KEY `PK_NPCOUNTRY` (`PREFIX`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `call_selector`
--

DROP TABLE IF EXISTS `call_selector`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `call_selector` (
  `sitecode` varchar(3) NOT NULL,
  `switchcode` varchar(3) NOT NULL,
  `trunk_in` varchar(8) NOT NULL,
  `port_in` varchar(20) NOT NULL,
  `prefix_did` varchar(25) NOT NULL,
  `pfxdid_len` int NOT NULL,
  `trunk_out` varchar(15) DEFAULT NULL,
  `port_out` varchar(20) NOT NULL,
  `prefix_cli` varchar(30) NOT NULL,
  `pinfo_flag` int DEFAULT NULL,
  PRIMARY KEY (`sitecode`,`switchcode`,`trunk_in`,`port_in`,`prefix_did`,`prefix_cli`),
  KEY `idx0` (`sitecode`,`switchcode`,`trunk_in`,`port_in`,`prefix_did`),
  KEY `idx1` (`sitecode`,`switchcode`,`trunk_in`,`port_in`,`prefix_did`,`pfxdid_len`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `call_selector_1401`
--

DROP TABLE IF EXISTS `call_selector_1401`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `call_selector_1401` (
  `sitecode` varchar(3) NOT NULL,
  `switchcode` varchar(3) NOT NULL,
  `trunk_in` varchar(8) NOT NULL,
  `port_in` varchar(20) NOT NULL,
  `prefix_did` varchar(25) NOT NULL,
  `pfxdid_len` int NOT NULL,
  `trunk_out` varchar(15) DEFAULT NULL,
  `port_out` varchar(20) NOT NULL,
  `prefix_cli` varchar(30) NOT NULL,
  `pinfo_flag` int DEFAULT NULL,
  PRIMARY KEY (`sitecode`,`switchcode`,`trunk_in`,`port_in`,`prefix_did`,`prefix_cli`),
  KEY `idx0` (`sitecode`,`switchcode`,`trunk_in`,`port_in`,`prefix_did`),
  KEY `idx1` (`sitecode`,`switchcode`,`trunk_in`,`port_in`,`prefix_did`,`pfxdid_len`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `call_selector_bt`
--

DROP TABLE IF EXISTS `call_selector_bt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `call_selector_bt` (
  `sitecode` varchar(3) NOT NULL,
  `switchcode` varchar(3) NOT NULL,
  `trunk_in` varchar(8) NOT NULL,
  `port_in` varchar(20) NOT NULL,
  `prefix_did` varchar(25) NOT NULL,
  `pfxdid_len` int NOT NULL,
  `trunk_out` varchar(8) NOT NULL,
  `port_out` varchar(20) NOT NULL,
  `prefix_cli` varchar(30) NOT NULL,
  `pinfo_flag` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `call_selector_final`
--

DROP TABLE IF EXISTS `call_selector_final`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `call_selector_final` (
  `sitecode` varchar(3) NOT NULL,
  `switchcode` varchar(3) NOT NULL,
  `trunk_in` varchar(8) NOT NULL,
  `port_in` varchar(20) NOT NULL,
  `prefix_did` varchar(25) NOT NULL,
  `prefix_cli` varchar(30) NOT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=12075 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `call_selector_working`
--

DROP TABLE IF EXISTS `call_selector_working`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `call_selector_working` (
  `sitecode` varchar(3) NOT NULL,
  `switchcode` varchar(3) NOT NULL,
  `port_in` varchar(20) NOT NULL,
  `prefix_did` varchar(25) NOT NULL,
  `pfxdid_len` int NOT NULL,
  `trunk_out` varchar(8) NOT NULL,
  `port_out` varchar(20) NOT NULL,
  `prefix_cli` varchar(30) NOT NULL,
  `pinfo_flag` int DEFAULT NULL,
  `trunk_in` varchar(8) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=5086 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `call_selector_working2`
--

DROP TABLE IF EXISTS `call_selector_working2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `call_selector_working2` (
  `sitecode` varchar(3) NOT NULL,
  `switchcode` varchar(3) NOT NULL,
  `port_in` varchar(20) NOT NULL,
  `prefix_did` varchar(25) NOT NULL,
  `pfxdid_len` int NOT NULL,
  `trunk_out` varchar(8) NOT NULL,
  `port_out` varchar(20) NOT NULL,
  `prefix_cli` varchar(30) NOT NULL,
  `pinfo_flag` int DEFAULT NULL,
  `trunk_in` varchar(8) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=5093 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `callbackup`
--

DROP TABLE IF EXISTS `callbackup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `callbackup` (
  `sitecode` varchar(3) NOT NULL,
  `switchcode` varchar(3) NOT NULL,
  `trunk_in` varchar(8) NOT NULL,
  `port_in` varchar(20) NOT NULL,
  `prefix_did` varchar(25) NOT NULL,
  `pfxdid_len` int NOT NULL,
  `trunk_out` varchar(8) NOT NULL,
  `port_out` varchar(20) NOT NULL,
  `prefix_cli` varchar(30) NOT NULL,
  `pinfo_flag` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `callbackup_se`
--

DROP TABLE IF EXISTS `callbackup_se`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `callbackup_se` (
  `sitecode` varchar(3) NOT NULL,
  `switchcode` varchar(3) NOT NULL,
  `trunk_in` varchar(8) NOT NULL,
  `port_in` varchar(20) NOT NULL,
  `prefix_did` varchar(25) NOT NULL,
  `pfxdid_len` int NOT NULL,
  `trunk_out` varchar(8) NOT NULL,
  `port_out` varchar(20) NOT NULL,
  `prefix_cli` varchar(30) NOT NULL,
  `pinfo_flag` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `multi_number_register_number`
--

DROP TABLE IF EXISTS `multi_number_register_number`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `multi_number_register_number` (
  `reg_number` varchar(20) NOT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=333 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `others`
--

DROP TABLE IF EXISTS `others`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `others` (
  `pfxdid_len` int NOT NULL,
  `trunk_out` varchar(8) NOT NULL,
  `port_out` varchar(20) NOT NULL,
  `pinfo_flag` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=209 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `selector_domain`
--

DROP TABLE IF EXISTS `selector_domain`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `selector_domain` (
  `id` int NOT NULL AUTO_INCREMENT,
  `domain_name` varchar(500) NOT NULL,
  `prefix` varchar(10) DEFAULT NULL,
  UNIQUE KEY `id` (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `selector_xlat`
--

DROP TABLE IF EXISTS `selector_xlat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `selector_xlat` (
  `did` varchar(20) NOT NULL,
  `domain_name` varchar(100) NOT NULL,
  `prefix` varchar(25) NOT NULL,
  `xlat_pfx` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`did`,`domain_name`,`prefix`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tmp_table_size`
--

DROP TABLE IF EXISTS `tmp_table_size`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmp_table_size` (
  `TableName` varchar(256) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `records` bigint NOT NULL,
  `TotalSpaceKB` bigint DEFAULT NULL,
  `UsedSpaceKB` bigint DEFAULT NULL,
  `UnsedSpaceKB` bigint DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping events for database 'selector'
--

--
-- Dumping routines for database 'selector'
--
/*!50003 DROP PROCEDURE IF EXISTS `slt_get_selector_domain_prefix` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `slt_get_selector_domain_prefix`(domain_name VARCHAR(500))
begin
 	
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select a.prefix from selector_domain a
    where a.domain_name = domain_name;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 	
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `slt_get_selector_v2` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `slt_get_selector_v2`(site VARCHAR(3),
     switch VARCHAR(3),
     did VARCHAR(50),
     cli VARCHAR(30),
     trunk VARCHAR(8),
     port VARCHAR(20)
     )
begin
  
  
     if trunk = 'lyctakap' and left(did,3) = 'URD' then
      SET did = INSERT(did,1,3,'LYA');
   end if;
     
 		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        select a.trunk_in,a.port_in,case when left(did,5)='URD00' THEN concat(a.prefix_did,'00') ELSE a.prefix_did END  prefix_did,
 			case when left(did,5)='URD00' then concat(a.pfxdid_len,2) else a.pfxdid_len end as pfxdid_len ,a.trunk_out,a.port_out,a.prefix_cli,a.pinfo_flag 
 		from call_selector a where
     	(a.sitecode = site or a.sitecode = '*')	and
     	(a.switchcode = switch or a.switchcode = '*') and
     	(a.trunk_in = trunk) and
     	(a.port_in = port or a.port_in = '*') and
     	(a.prefix_did = left(did,a.pfxdid_len) or a.prefix_did = '*') and
     	(a.prefix_cli = left(cli,CHAR_LENGTH(RTRIM(a.prefix_cli))) or a.prefix_cli = '*')
        order by a.prefix_did desc ,a.prefix_cli desc,a.trunk_in desc,a.port_in desc,a.sitecode desc,a.switchcode desc LIMIT 1;
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
     end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `slt_get_selector_v2_1` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `slt_get_selector_v2_1`(
v_site VARCHAR(3),
v_switch VARCHAR(3),
v_did VARCHAR(20),
v_cli VARCHAR(30),
v_trunk VARCHAR(8),
v_port VARCHAR(20))
begin
	
   if v_trunk = 'lyctakap' and left(v_did,3) = 'URD' then
      SET v_did = insert(v_did,1,3,'LYA');
   end if;
	
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select  trunk_in,port_in,case when left(v_did,5) = 'URD00' THEN CONCAT(prefix_did,'00') ELSE prefix_did END  prefix_did,
	case when left(v_did,5) = 'URD00' then pfxdid_len+2 else pfxdid_len end as pfxdid_len ,trunk_out,
	port_out,prefix_cli,pinfo_flag from call_selector  where
	(sitecode = v_site or sitecode = '*')	and
	(switchcode = v_switch or switchcode = '*') and
	(trunk_in = v_trunk) and
	(port_in = v_port or port_in = '*') and
	(prefix_did = left(v_did,pfxdid_len) or prefix_did = '*') and
	(prefix_cli = left(v_cli,CHAR_LENGTH(RTRIM(prefix_cli))) or prefix_cli = '*')
   order by prefix_did desc,prefix_cli desc,trunk_in desc,port_in desc,sitecode desc, 
   switchcode desc LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `slt_get_selector_xlat_pfx` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `slt_get_selector_xlat_pfx`(did VARCHAR(50),
  domain_name VARCHAR(150))
SWL_return:
  BEGIN
  
  	
     DECLARE v_internal_no INT; 
     DECLARE v_cc_prefix VARCHAR(20);
     
     
     IF LEFT(did,2) = '00' then
        select insert(did,1,2,'') as xlat_did;
        LEAVE SWL_return;
     end if;
  	
     if LEFT(did,1) = '0' then
  	
        CALL unifiedring.sip_pbx_get_didnumber_counry_prefix(did,v_internal_no,v_cc_prefix);
        if v_internal_no = 1 and IFNULL(v_cc_prefix,'') <> '' then
  		
           select insert(did,1,1,v_cc_prefix) as xlat_did;
           LEAVE SWL_return;
        end if;
     end if;
     
     if LEFT(did,20) = 'CX_UNIRING4420378200' then

        select a.xlat_pfx as xlat_did 
     from selector_xlat a
     where prefix = LEFT(did,20)
     order by CHAR_LENGTH(RTRIM(a.did)) desc; 
         LEAVE SWL_return;
     End if;
     
      if LEFT(did,20) = 'CX_URINGSAL442034440' then

 		select a.xlat_pfx as xlat_did 
 		from selector_xlat a
 		where prefix = LEFT(did,20)
 		order by CHAR_LENGTH(RTRIM(a.did)) desc;
         LEAVE SWL_return;
     End if;
     
		 if LEFT(did,20) = 'CX_UNIRING442037823000' then

		select a.xlat_pfx as xlat_did 
		from selector_xlat a
		where prefix = LEFT(did,20)
		order by CHAR_LENGTH(RTRIM(a.did)) desc; 
		LEAVE SWL_return;
	End if;
	if LEFT(did,20) = 'CX_UNIRING442037824000' then

		select a.xlat_pfx as xlat_did 
		from selector_xlat a
		where prefix = LEFT(did,20)
		order by CHAR_LENGTH(RTRIM(a.did)) desc; 
		LEAVE SWL_return;
	End if;
	if LEFT(did,20) = 'CX_UNIRING448000500000' then

		select a.xlat_pfx as xlat_did 
		from selector_xlat a
		where prefix = LEFT(did,20)
		order by CHAR_LENGTH(RTRIM(a.did)) desc; 
		LEAVE SWL_return;
	End if;
	if LEFT(did,20) = 'CX_URINGSAL442034440000' then

		select a.xlat_pfx as xlat_did 
		from selector_xlat a
		where prefix = LEFT(did,20)
		order by CHAR_LENGTH(RTRIM(a.did)) desc; 
		LEAVE SWL_return;
	End if;
	if LEFT(did,20) = 'CX_UNIRING442037820000' then

		select a.xlat_pfx as xlat_did 
		from selector_xlat a
		where prefix = LEFT(did,20)
		order by CHAR_LENGTH(RTRIM(a.did)) desc; 
		LEAVE SWL_return;
	End if;

  
  	
     SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
     select insert(did,1,CHAR_LENGTH(RTRIM(a.prefix)),a.xlat_pfx) as xlat_did 
     from selector_xlat a
     where ((replace(a.domain_name,'xxxx',left(domain_name,4)) = domain_name) or  (a.domain_name = '*')) and
     a.prefix = left(did,CHAR_LENGTH(RTRIM(a.prefix)))  and
  		   ((a.did = '*') or (a.did = did))
     order by CHAR_LENGTH(RTRIM(a.did)) desc;
     SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
  		   
  
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `slt_get_selector_xlat_pfx1` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `slt_get_selector_xlat_pfx1`(did VARCHAR(50),
 domain_name VARCHAR(150))
SWL_return:
 BEGIN
 
 	
    DECLARE v_internal_no INT; 
    DECLARE v_cc_prefix VARCHAR(20);
    
    
    IF LEFT(did,2) = '00' then
       select insert(did,1,2,'') as xlat_did;
       LEAVE SWL_return;
    end if;
 	
    if LEFT(did,1) = '0' then
 	
       CALL unifiedring.sip_pbx_get_didnumber_counry_prefix(did,v_internal_no,v_cc_prefix);
       if v_internal_no = 1 and IFNULL(v_cc_prefix,'') <> '' then
 		
          select insert(did,1,1,v_cc_prefix) as xlat_did;
          LEAVE SWL_return;
       end if;
    end if;
    
    if LEFT(did,20) = 'CX_UNIRING4420378200' then
		
       select a.xlat_pfx as xlat_did 
    from selector_xlat a
    where prefix = LEFT(did,20)
    order by CHAR_LENGTH(RTRIM(a.did)) desc;
        
        
        LEAVE SWL_return;
    End if;
    
     if LEFT(did,20) = 'CX_URINGSAL442034440' then
		
		select a.xlat_pfx as xlat_did 
		from selector_xlat a
		where prefix = LEFT(did,20)
		order by CHAR_LENGTH(RTRIM(a.did)) desc;
        LEAVE SWL_return;
    End if;
 
 	
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select insert(did,1,CHAR_LENGTH(RTRIM(a.prefix)),a.xlat_pfx) as xlat_did 
    from selector_xlat a
    where ((replace(a.domain_name,'xxxx',left(domain_name,4)) = domain_name) or  (a.domain_name = '*')) and
    a.prefix = left(did,CHAR_LENGTH(RTRIM(a.prefix)))  and
 		   ((a.did = '*') or (a.did = did))
    order by CHAR_LENGTH(RTRIM(a.did)) desc;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 		   
 
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-21  9:53:09
