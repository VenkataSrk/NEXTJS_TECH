-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: CVM
-- ------------------------------------------------------
-- Server version	8.0.44-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tb_CVMBundlePurchase`
--

DROP TABLE IF EXISTS `tb_CVMBundlePurchase`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_CVMBundlePurchase` (
  `BundlePurchaseId` bigint NOT NULL AUTO_INCREMENT,
  `CustomerId` bigint DEFAULT NULL,
  `MobileNo` varchar(30) DEFAULT NULL,
  `CompanyId` int DEFAULT NULL,
  `IccId` bigint DEFAULT NULL,
  `BundleId` int DEFAULT NULL,
  `PurchaseDate` datetime DEFAULT NULL,
  `PurchaseYear` smallint DEFAULT NULL,
  `PurchaseMonth` tinyint DEFAULT NULL,
  `PurchaseDay` tinyint DEFAULT NULL,
  `PurchaseHour` tinyint DEFAULT NULL,
  `Price` decimal(15,2) DEFAULT NULL,
  `PaymentMode` varchar(150) DEFAULT NULL,
  `CreatedDate` datetime DEFAULT NULL,
  `UpdatedDate` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`BundlePurchaseId`),
  KEY `fk_CVMBundlePurchase_CustomerId` (`CustomerId`),
  KEY `ix_CVMBundlePurchase_MobileNo` (`CompanyId`,`MobileNo`),
  CONSTRAINT `fk_CVMBundlePurchase_CustomerId` FOREIGN KEY (`CustomerId`) REFERENCES `tb_CVMCustomer` (`CustomerId`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=395676 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_CVMChurnHistoryDtl`
--

DROP TABLE IF EXISTS `tb_CVMChurnHistoryDtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_CVMChurnHistoryDtl` (
  `RecordedDate` datetime NOT NULL,
  `companyId` int DEFAULT NULL,
  `segement` varchar(500) DEFAULT NULL,
  `customerCount` int DEFAULT NULL,
  `revenue` int DEFAULT NULL,
  `APRU` int DEFAULT NULL,
  `updatedOn` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`RecordedDate`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_CVMCustomer`
--

DROP TABLE IF EXISTS `tb_CVMCustomer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_CVMCustomer` (
  `CustomerId` bigint NOT NULL AUTO_INCREMENT,
  `MobileNo` varchar(30) DEFAULT NULL,
  `CompanyId` int DEFAULT NULL,
  `IsActive` tinyint DEFAULT '1',
  `FirstName` varchar(150) DEFAULT NULL,
  `LastName` varchar(150) DEFAULT NULL,
  `Email` varchar(150) DEFAULT NULL,
  `City` varchar(150) DEFAULT NULL,
  `Postcode` varchar(10) DEFAULT NULL,
  `CountryCode` varchar(10) DEFAULT NULL,
  `TenureDays` smallint DEFAULT NULL,
  `RollInDate` datetime DEFAULT NULL,
  `RollOutDate` datetime DEFAULT NULL,
  `NPSCategory` varchar(200) DEFAULT NULL,
  `ARPUCategory` varchar(200) DEFAULT NULL,
  `CLVCategory` varchar(200) DEFAULT NULL,
  `RFMcategory` varchar(200) DEFAULT NULL,
  `NBOSegment` varchar(200) DEFAULT NULL,
  `NBAAction` varchar(200) DEFAULT NULL,
  `ChannelType` varchar(25) DEFAULT NULL,
  `Churn` tinyint DEFAULT NULL,
  `CreatedDate` datetime DEFAULT NULL,
  `UpdatedDate` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`CustomerId`),
  UNIQUE KEY `uk_CVMCustomer_MobileNo` (`CompanyId`,`MobileNo`),
  KEY `ix_tb_CVMCustomer_CompanyIdRollInDate` (`CompanyId`,`RollInDate`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=993778 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_CVMCustomerComplaint`
--

DROP TABLE IF EXISTS `tb_CVMCustomerComplaint`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_CVMCustomerComplaint` (
  `CustomerId` bigint DEFAULT NULL,
  `MobileNo` varchar(30) NOT NULL,
  `CompanyId` int NOT NULL,
  `FunctionName` varchar(250) DEFAULT NULL,
  `IssueName` varchar(250) DEFAULT NULL,
  `ComplaintName` varchar(250) NOT NULL,
  `ComplaintDate` datetime NOT NULL,
  `CreatedDate` datetime NOT NULL,
  PRIMARY KEY (`MobileNo`,`CompanyId`,`ComplaintName`,`ComplaintDate`),
  KEY `fk_CVMCustomerComplaint_CustomerId` (`CustomerId`),
  CONSTRAINT `fk_CVMCustomerComplaint_CustomerId` FOREIGN KEY (`CustomerId`) REFERENCES `tb_CVMCustomer` (`CustomerId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_CVMCustomerTelecomDetail`
--

DROP TABLE IF EXISTS `tb_CVMCustomerTelecomDetail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_CVMCustomerTelecomDetail` (
  `CustomerId` bigint NOT NULL,
  `CompanyId` int DEFAULT NULL,
  `TopupCount` smallint DEFAULT NULL,
  `TopupSum` int DEFAULT NULL,
  `TopupMean` decimal(20,2) DEFAULT NULL,
  `TopupMax` smallint DEFAULT NULL,
  `FirstTopupDate` datetime DEFAULT NULL,
  `LastTopupDate` datetime DEFAULT NULL,
  `TopupPeakHour` tinyint DEFAULT NULL,
  `AvgTopupIntervalDays` decimal(10,2) DEFAULT NULL,
  `BundleCount` smallint DEFAULT NULL,
  `BundleSumSpend` decimal(20,2) DEFAULT NULL,
  `BundleMeanSpend` decimal(20,2) DEFAULT NULL,
  `FirstBundleDate` datetime DEFAULT NULL,
  `LastBundleDate` datetime DEFAULT NULL,
  `FirstBundleId` smallint DEFAULT NULL,
  `LastBundleId` smallint DEFAULT NULL,
  `FavoriteBundleIds` varchar(100) DEFAULT NULL,
  `BundlePeakHour` tinyint DEFAULT NULL,
  `OverallSentimentWithCount` varchar(15) DEFAULT NULL,
  `CountComplain` smallint DEFAULT NULL,
  `CountInquiry` smallint DEFAULT NULL,
  `CountRequest` smallint DEFAULT NULL,
  `DominantIssueTypeId` varchar(100) DEFAULT NULL,
  `TotalSpendAmount` int DEFAULT NULL,
  `TopupPeakDayNum` tinyint DEFAULT NULL,
  `BundlePeakDayNum` tinyint DEFAULT NULL,
  `AvgBundleIntervalDays` decimal(10,2) DEFAULT NULL,
  `BundleIdCount` text,
  `TenureMonths` decimal(10,2) DEFAULT NULL,
  `ARPUPerDays` decimal(10,2) DEFAULT NULL,
  `ARPUPerMonth` decimal(10,2) DEFAULT NULL,
  `CLVSimple` decimal(10,2) DEFAULT NULL,
  `LastActivityDate` datetime DEFAULT NULL,
  `Recency` smallint DEFAULT NULL,
  `Frequency` smallint DEFAULT NULL,
  `Monetary` decimal(10,2) DEFAULT NULL,
  `R` tinyint DEFAULT NULL,
  `F` tinyint DEFAULT NULL,
  `M` tinyint DEFAULT NULL,
  `RFMScore` smallint DEFAULT NULL,
  `PosSent` tinyint DEFAULT NULL,
  `NegSent` tinyint DEFAULT NULL,
  `NeuSent` tinyint DEFAULT NULL,
  `NPSScoreProxy` tinyint DEFAULT NULL,
  `UniqueBundles` varchar(1000) DEFAULT NULL,
  `CreatedDate` datetime DEFAULT NULL,
  `UpdatedDate` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`CustomerId`),
  CONSTRAINT `fk_CVMCustomerTelecomDetail_CustomerId` FOREIGN KEY (`CustomerId`) REFERENCES `tb_CVMCustomer` (`CustomerId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_CVMRecommendationDtl`
--

DROP TABLE IF EXISTS `tb_CVMRecommendationDtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_CVMRecommendationDtl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `companyId` int DEFAULT NULL,
  `customerName` varchar(500) DEFAULT NULL,
  `emailId` varchar(250) DEFAULT NULL,
  `MobileNo` varchar(30) DEFAULT NULL,
  `channelType` varchar(100) DEFAULT NULL,
  `ARPU` float DEFAULT NULL,
  `bundleName` varchar(500) DEFAULT NULL,
  `createdOn` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedOn` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=133 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_CVMTopUpPurchase`
--

DROP TABLE IF EXISTS `tb_CVMTopUpPurchase`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_CVMTopUpPurchase` (
  `TopUpPurchaseId` bigint NOT NULL AUTO_INCREMENT,
  `CustomerId` bigint DEFAULT NULL,
  `MobileNo` varchar(30) DEFAULT NULL,
  `CompanyId` int DEFAULT NULL,
  `PaymentType` varchar(100) DEFAULT NULL,
  `Amount` decimal(15,2) DEFAULT NULL,
  `PurchaseDate` datetime DEFAULT NULL,
  `PurchaseYear` smallint DEFAULT NULL,
  `PurchaseMonth` tinyint DEFAULT NULL,
  `PurchaseDay` tinyint DEFAULT NULL,
  `PurchaseHour` tinyint DEFAULT NULL,
  `PreviousBalance` decimal(15,2) DEFAULT NULL,
  `AfterBalance` decimal(15,2) DEFAULT NULL,
  `CreatedDate` datetime DEFAULT NULL,
  `UpdatedDate` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`TopUpPurchaseId`),
  KEY `ix_CVMTopUpPurchase_MobileNo` (`CompanyId`,`MobileNo`),
  KEY `ix_CVMTopUpPurchase_CustomerIdPurchaseDate` (`CustomerId`,`PurchaseDate`),
  KEY `ix_CVMTopUpPurchase_CompanyIdPurchaseDate` (`CompanyId`,`PurchaseDate`),
  CONSTRAINT `fk_CVMTopUpPurchase_CustomerId` FOREIGN KEY (`CustomerId`) REFERENCES `tb_CVMCustomer` (`CustomerId`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=1107252 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_CVM_CustomerMonthlyDetails`
--

DROP TABLE IF EXISTS `tb_CVM_CustomerMonthlyDetails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_CVM_CustomerMonthlyDetails` (
  `CustomerId` bigint NOT NULL,
  `CompanyId` int NOT NULL,
  `StartDate` datetime NOT NULL,
  `EndDate` datetime DEFAULT NULL,
  `Month` tinyint DEFAULT NULL,
  `IsActive` tinyint DEFAULT '0',
  PRIMARY KEY (`CompanyId`,`CustomerId`,`StartDate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_CVM_email_login_config_dtl`
--

DROP TABLE IF EXISTS `tb_CVM_email_login_config_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_CVM_email_login_config_dtl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `email_id` varchar(150) NOT NULL,
  `is_login` tinyint DEFAULT '0',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_lyca_churn_revenue_APRU`
--

DROP TABLE IF EXISTS `tb_lyca_churn_revenue_APRU`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_lyca_churn_revenue_APRU` (
  `segement` varchar(500) DEFAULT NULL,
  `customerCount` int DEFAULT NULL,
  `revenue` int DEFAULT NULL,
  `APRU` decimal(20,2) DEFAULT NULL,
  `created_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=138 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_lyca_cluster_definition_details`
--

DROP TABLE IF EXISTS `tb_lyca_cluster_definition_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_lyca_cluster_definition_details` (
  `id` int NOT NULL AUTO_INCREMENT,
  `cluster_id` int NOT NULL,
  `cluster_name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_lyca_customer_profile_360_module`
--

DROP TABLE IF EXISTS `tb_lyca_customer_profile_360_module`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_lyca_customer_profile_360_module` (
  `id` int NOT NULL AUTO_INCREMENT,
  `Sub_Acct_Id` int DEFAULT NULL,
  `SIM_TYPE` varchar(20) DEFAULT NULL,
  `CHANNEL_CATEGORY` varchar(20) DEFAULT NULL,
  `voice_Total_Call_Duration` decimal(20,2) DEFAULT NULL,
  `GPRS_Total_Used_Bytes` decimal(20,2) DEFAULT NULL,
  `total_number_of_sms` int DEFAULT NULL,
  `Account_validity_date` date DEFAULT NULL,
  `summary` varchar(2000) DEFAULT NULL,
  `network_usage` varchar(20) DEFAULT NULL,
  `location` varchar(50) DEFAULT NULL,
  `monthwise_revenue_2025_01` decimal(20,2) DEFAULT NULL,
  `monthwise_revenue_2025_02` decimal(20,2) DEFAULT NULL,
  `monthwise_revenue_2025_03` decimal(20,2) DEFAULT NULL,
  `monthwise_revenue_2025_04` decimal(20,2) DEFAULT NULL,
  `monthwise_revenue_2025_05` decimal(20,2) DEFAULT NULL,
  `monthwise_revenue_2025_06` decimal(20,2) DEFAULT NULL,
  `Average_revenue` decimal(20,2) DEFAULT NULL,
  `purchased_bundles` varchar(130) DEFAULT NULL,
  `monthly_bundle_count2025_01` decimal(20,2) DEFAULT NULL,
  `monthly_bundle_count2025_02` decimal(20,2) DEFAULT NULL,
  `monthly_bundle_count2025_03` decimal(20,2) DEFAULT NULL,
  `monthly_bundle_count2025_04` decimal(20,2) DEFAULT NULL,
  `monthly_bundle_count2025_05` decimal(20,2) DEFAULT NULL,
  `monthly_bundle_count2025_06` decimal(20,2) DEFAULT NULL,
  `churn_risk_score` decimal(20,2) DEFAULT NULL,
  `clv_score` decimal(20,2) DEFAULT NULL,
  `Engagement_Score` decimal(20,2) DEFAULT NULL,
  `subscriber_type` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `Sub_Acct_Id` (`Sub_Acct_Id`),
  CONSTRAINT `tb_lyca_customer_profile_360_module_ibfk_1` FOREIGN KEY (`Sub_Acct_Id`) REFERENCES `tb_lyca_unified_details` (`sub_Acct_Id`)
) ENGINE=InnoDB AUTO_INCREMENT=96 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_lyca_recharge_definition_details`
--

DROP TABLE IF EXISTS `tb_lyca_recharge_definition_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_lyca_recharge_definition_details` (
  `id` int NOT NULL AUTO_INCREMENT,
  `recharge_id` int NOT NULL,
  `recharge_name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_lyca_recommendation_details`
--

DROP TABLE IF EXISTS `tb_lyca_recommendation_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_lyca_recommendation_details` (
  `rec_id` int NOT NULL AUTO_INCREMENT,
  `sub_Acct_Id` int DEFAULT NULL,
  `recommendations` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`rec_id`),
  KEY `sub_Acct_Id` (`sub_Acct_Id`),
  CONSTRAINT `tb_lyca_recommendation_details_ibfk_1` FOREIGN KEY (`sub_Acct_Id`) REFERENCES `tb_lyca_unified_details` (`sub_Acct_Id`)
) ENGINE=InnoDB AUTO_INCREMENT=173573 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_lyca_topup_details`
--

DROP TABLE IF EXISTS `tb_lyca_topup_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_lyca_topup_details` (
  `id` int NOT NULL AUTO_INCREMENT,
  `Sub_Acct_Id` int DEFAULT NULL,
  `Actual_Bundle_Cost` decimal(20,2) DEFAULT NULL,
  `SIM_TYPE` varchar(50) DEFAULT NULL,
  `recharge_type` int DEFAULT NULL,
  `CHANNEL_CATEGORY` varchar(50) DEFAULT NULL,
  `Bundle_Purchase_Date` datetime DEFAULT NULL,
  `Month` smallint DEFAULT NULL,
  `year` smallint DEFAULT NULL,
  `createdAt` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `Sub_Acct_Id` (`Sub_Acct_Id`),
  KEY `ix_topup_details_SIM_TYPE` (`SIM_TYPE`,`Actual_Bundle_Cost`),
  KEY `index_SIM_TYPE_and_Month` (`SIM_TYPE`,`Month`),
  CONSTRAINT `tb_lyca_topup_details_ibfk_1` FOREIGN KEY (`Sub_Acct_Id`) REFERENCES `tb_lyca_unified_details` (`sub_Acct_Id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=812635 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_lyca_unified_details`
--

DROP TABLE IF EXISTS `tb_lyca_unified_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_lyca_unified_details` (
  `sub_Acct_Id` int NOT NULL,
  `Total_amount` decimal(20,2) DEFAULT NULL,
  `CHANNEL_CATEGORY` varchar(30) DEFAULT NULL,
  `SIM_TYPE` varchar(50) DEFAULT NULL,
  `total_msg_cost` decimal(20,2) DEFAULT NULL,
  `voice_Total_Talk_charge` decimal(20,2) DEFAULT NULL,
  `GPRS_Total_Data_Charge_Used` decimal(24,6) DEFAULT NULL,
  `CLV_Segment` varchar(50) DEFAULT NULL,
  `NBO_Segment` varchar(30) DEFAULT NULL,
  `RFM_Category` varchar(30) DEFAULT NULL,
  `Cluster` tinyint DEFAULT NULL,
  `created_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `isActive` tinyint DEFAULT NULL,
  PRIMARY KEY (`sub_Acct_Id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping routines for database 'CVM'
--
/*!50003 DROP PROCEDURE IF EXISTS `cvm_bundlePurchaseBasedOnHours` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`javateam`@`%` PROCEDURE `cvm_bundlePurchaseBasedOnHours`(
p_domainId  	INT,
P_fromYear   	DATETIME,
P_toYear     	DATETIME,
p_NBOSegment	VARCHAR(20)
)
BEGIN	
        DECLARE v_fromYear DATETIME;
        DECLARE v_toYear  DATETIME;
        DECLARE v_minYear  DATETIME;
        DECLARE v_maxYear  DATETIME;
        DECLARE v_companyId		INT;
    
		SET v_companyId = IFNULL(p_domainId,0);
        
		SELECT MIN(PurchaseDate), MAX(PurchaseDate) INTO v_minYear, v_maxYear  FROM tb_CVMBundlePurchase
         WHERE  CompanyId = v_companyId;
        
        SET P_toYear = CONCAT(DATE(P_toYear)," 23:59:59");
        
        SET v_fromYear = IFNULL(P_fromYear, v_minYear);
        SET v_toYear  = IFNULL(P_toYear, v_maxYear);
        
		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;        
        SELECT 	PurchaseYear as YEAR,
				SUM(CASE WHEN PurchaseHour = 0 THEN 1 ELSE 0 END) AS "0",
				SUM(CASE WHEN PurchaseHour = 1 THEN 1 ELSE 0 END) AS "1",
                SUM(CASE WHEN PurchaseHour = 2 THEN 1 ELSE 0 END) AS "2",
				SUM(CASE WHEN PurchaseHour = 3 THEN 1 ELSE 0 END) AS "3",
				SUM(CASE WHEN PurchaseHour = 4 THEN 1 ELSE 0 END) AS "4",
                SUM(CASE WHEN PurchaseHour = 5 THEN 1 ELSE 0 END) AS "5",
                SUM(CASE WHEN PurchaseHour = 6 THEN 1 ELSE 0 END) AS "6",
                SUM(CASE WHEN PurchaseHour = 7 THEN 1 ELSE 0 END) AS "7",
                SUM(CASE WHEN PurchaseHour = 8 THEN 1 ELSE 0 END) AS "8",
                SUM(CASE WHEN PurchaseHour = 9 THEN 1 ELSE 0 END) AS "9",
                SUM(CASE WHEN PurchaseHour = 10 THEN 1 ELSE 0 END) AS "10",
                SUM(CASE WHEN PurchaseHour = 11 THEN 1 ELSE 0 END) AS "11",
				SUM(CASE WHEN PurchaseHour = 12 THEN 1 ELSE 0 END) AS "12",
				SUM(CASE WHEN PurchaseHour = 13 THEN 1 ELSE 0 END) AS "13",
				SUM(CASE WHEN PurchaseHour = 14 THEN 1 ELSE 0 END) AS "14",
				SUM(CASE WHEN PurchaseHour = 15 THEN 1 ELSE 0 END) AS "15",
				SUM(CASE WHEN PurchaseHour = 16 THEN 1 ELSE 0 END) AS "16",
				SUM(CASE WHEN PurchaseHour = 17 THEN 1 ELSE 0 END) AS "17",
				SUM(CASE WHEN PurchaseHour = 18 THEN 1 ELSE 0 END) AS "18",
				SUM(CASE WHEN PurchaseHour = 19 THEN 1 ELSE 0 END) AS "19",
				SUM(CASE WHEN PurchaseHour = 20 THEN 1 ELSE 0 END) AS "20",
				SUM(CASE WHEN PurchaseHour = 21 THEN 1 ELSE 0 END) AS "21",
				SUM(CASE WHEN PurchaseHour = 22 THEN 1 ELSE 0 END) AS "22",
				SUM(CASE WHEN PurchaseHour = 23 THEN 1 ELSE 0 END) AS "23"
		FROM 	tb_CVMBundlePurchase	BP
        JOIN 	tb_CVMCustomer			C	ON 	BP.CustomerId	= C.CustomerId	
											AND (p_NBOSegment IS NULL OR C.NBOSegment = p_NBOSegment)	
        WHERE 	 C.CompanyId = v_companyId 
        AND		 BP.PurchaseDate BETWEEN v_fromYear  AND v_toYear
        GROUP BY BP.PurchaseYear
        ORDER BY YEAR DESC;
        
         SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;      
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `cvm_bundlePurchaseBasedOnMonth` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`javateam`@`%` PROCEDURE `cvm_bundlePurchaseBasedOnMonth`(
	p_domainId  	INT,
	P_fromYear   	DATETIME,
	P_toYear     	DATETIME,
	p_NBOSegment	VARCHAR(20)
)
BEGIN	DECLARE v_fromYear 		DATETIME;
        DECLARE v_toYear  		DATETIME;
        DECLARE v_minYear  		DATETIME;
        DECLARE v_maxYear  		DATETIME;
        DECLARE v_companyId		INT;
    
		SET v_companyId = IFNULL(p_domainId,0);
        
        SELECT MIN(PurchaseDate), MAX(PurchaseDate) INTO v_minYear, v_maxYear  FROM tb_CVMBundlePurchase
		WHERE CompanyId = v_companyId;
        
        SET P_toYear = CONCAT(DATE(P_toYear)," 23:59:59");
        
        SET v_fromYear = IFNULL(P_fromYear, v_minYear);
        SET v_toYear  = IFNULL(P_toYear, v_maxYear);
        
        SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        
        SELECT PurchaseYear as YEAR,
				SUM(CASE WHEN PurchaseMonth = 1 THEN 1 ELSE 0 END) AS JAN,
				SUM(CASE WHEN PurchaseMonth = 2 THEN 1 ELSE 0 END) AS FEB,
                SUM(CASE WHEN PurchaseMonth = 3 THEN 1 ELSE 0 END) AS MAR,
				SUM(CASE WHEN PurchaseMonth = 4 THEN 1 ELSE 0 END) AS APR,
				SUM(CASE WHEN PurchaseMonth = 5 THEN 1 ELSE 0 END) AS MAY,
                SUM(CASE WHEN PurchaseMonth = 6 THEN 1 ELSE 0 END) AS JUN,
                SUM(CASE WHEN PurchaseMonth = 7 THEN 1 ELSE 0 END) AS JUL,
                SUM(CASE WHEN PurchaseMonth = 8 THEN 1 ELSE 0 END) AS AUG,
                SUM(CASE WHEN PurchaseMonth = 9 THEN 1 ELSE 0 END) AS SEP,
                SUM(CASE WHEN PurchaseMonth = 10 THEN 1 ELSE 0 END) AS "OCT",
                SUM(CASE WHEN PurchaseMonth = 11 THEN 1 ELSE 0 END) AS NOV,
                SUM(CASE WHEN PurchaseMonth = 12 THEN 1 ELSE 0 END) AS "DEC"
		FROM 	tb_CVMBundlePurchase	BP
        JOIN 	tb_CVMCustomer			C	ON 	BP.CustomerId	= C.CustomerId	
											AND (p_NBOSegment IS NULL OR C.NBOSegment = p_NBOSegment)	
        WHERE  C.CompanyId = v_companyId 
        AND	   BP.PurchaseDate BETWEEN v_fromYear  AND v_toYear
        GROUP BY BP.PurchaseYear
		ORDER BY YEAR DESC;        
		SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;      
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `cvm_dashboardCustomerAnalysisDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`javateam`@`%` PROCEDURE `cvm_dashboardCustomerAnalysisDtl`(
    p_domainId		INT,
    p_startDate	DATE,
    p_endDate		DATE
  )
BEGIN
  	DECLARE v_totalCustomer			INT;
  	DECLARE v_totalNewCustomer		INT;
  	DECLARE v_totalChurnCustomer	INT;
  	DECLARE v_endDate				DATETIME;
  	DECLARE v_companyId				INT; 
  	DECLARE v_TotalChurn			INT; 
  	  
  	SET v_endDate = CONCAT(p_endDate," 23:59:59");
  	SET v_companyId = IFNULL(p_domainId,0);
  	  
	SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;         
	DROP TEMPORARY TABLE IF EXISTS tt_ChurnCustomers;
	CREATE TEMPORARY TABLE tt_ChurnCustomers
	SELECT 	CustomerId    
	FROM 	tb_CVMCustomer
	WHERE 	CompanyId 	=  v_companyId
	AND 	RollOutDate	BETWEEN p_startDate AND v_endDate
	AND 	Churn		= 1; 
     
  	SELECT 	SUM(1)
  	INTO 	v_TotalChurn
  	FROM 	tt_ChurnCustomers; 
      
 	DROP TEMPORARY TABLE IF EXISTS tt_Customers;
 	CREATE TEMPORARY TABLE tt_Customers(CustomerId	BIGINT, isNewCustomer TINYINT, isActive	TINYINT DEFAULT 0,PurchaseCount SMALLINT DEFAULT 0);
 
 	INSERT INTO tt_Customers(CustomerId,isNewCustomer)
 	SELECT 	C.CustomerId
 		,	CASE WHEN C.RollInDate BETWEEN p_endDate AND v_endDate THEN 1 ELSE 0 END	AS isNewCustomer        
  	FROM 	tb_CVMCustomer		C	
	LEFT JOIN tt_ChurnCustomers	CC ON CC.CustomerId = C.CustomerId
  	WHERE 	C.CompanyId 	= v_companyId
  	AND 	C.RollInDate 	BETWEEN p_startDate AND v_endDate
	AND 	CC.CustomerId	IS NULL;
      
 	DROP TEMPORARY TABLE IF EXISTS tt_Customers1;
 	CREATE TEMPORARY TABLE tt_Customers1 SELECT * FROM tt_Customers;
      
 	WITH CTE_Customer AS (
  		SELECT 	C.CustomerId
  			,	MAX(TP.PurchaseDate)	AS PurchaseDate
            ,	COUNT(1) 				AS PurchaseCount
  		FROM 	tt_Customers1		C
  		JOIN 	tb_CVMTopUpPurchase TP	ON TP.CustomerId = C.CustomerId
		GROUP BY C.CustomerId
  	)
 	UPDATE 	tt_Customers	t_C
 	JOIN 	CTE_Customer	C_C	ON C_C.CustomerId = t_C.CustomerId
 	SET 	t_C.isActive		= 1
		,	t_C.PurchaseCount	= C_C.PurchaseCount
 	WHERE 	DATEDIFF(PurchaseDate,p_endDate) <= 120;	
  
	WITH CTE_Customer AS (
  		SELECT 	C.CustomerId
  			,	MAX(BP.PurchaseDate)	AS PurchaseDate
            ,	COUNT(1) 				AS PurchaseCount
  		FROM 	tt_Customers1			C
  		JOIN 	tb_CVMBundlePurchase 	BP	ON BP.CustomerId = C.CustomerId
        GROUP BY C.CustomerId
  	)
 	UPDATE 	tt_Customers	t_C
 	JOIN 	CTE_Customer	C_C	ON C_C.CustomerId = t_C.CustomerId
 	SET 	t_C.isActive		= 1
		,	t_C.PurchaseCount	= C_C.PurchaseCount
 	WHERE 	DATEDIFF(PurchaseDate,p_endDate) <= 120;	    
  	
  	SELECT 	COUNT(1) 					AS totalCustomer
  		,	SUM(isNewCustomer) 			AS totalNewCustomer	
  		,	IFNULL(v_TotalChurn,0) 		AS totalChurnCustomer
 		,	SUM(isActive)				AS totalActiveCustomer
		,	COUNT(1) - SUM(isActive) 	AS totalInActiveCustomer
        ,	SUM(CASE WHEN PurchaseCount > 1 THEN 1 ELSE 0 END ) AS totalRepeatedCustomer
  	FROM 	tt_Customers;
  	SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
      
      DROP TEMPORARY TABLE IF EXISTS tt_Customers;
      DROP TEMPORARY TABLE IF EXISTS tt_Customers1;
      DROP TEMPORARY TABLE IF EXISTS tt_ChurnCustomers; 
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `cvm_dashboard_count` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`javateam`@`%` PROCEDURE `cvm_dashboard_count`(
P_domainId 		INT,
p_fromDate		DATETIME,
p_toDate		DATETIME,
p_NBOSegment	VARCHAR(20)
)
BEGIN
	
    DECLARE v_customerCount	 INT;
    DECLARE v_BundleCount	INT;
	DECLARE v_TopupCount	INT;
    DECLARE v_cusfromDate	DATETIME;
    DECLARE v_custoDate		DATETIME;
    DECLARE v_bunfromDate	DATETIME;
    DECLARE v_buntoDate		DATETIME;
    DECLARE v_topfromDate	DATETIME;
    DECLARE v_toptoDate		DATETIME;
    DECLARE v_companyId		INT;
    
   	SET v_companyId = IFNULL(P_domainId,0);

    
    
   	SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;          
    DROP TEMPORARY TABLE IF EXISTS tt_Customers;
    CREATE temporary TABLE tt_Customers 
    SELECT 	C.CustomerId FROM tb_CVMCustomer C
	WHERE 	C.CompanyId 	= v_companyId 
    AND		C.RollInDate 	BETWEEN p_fromDate AND p_toDate
    AND 	(p_NBOSegment IS NULL OR C.NBOSegment = p_NBOSegment);    
    
    SELECT COUNT(1) INTO v_customerCount FROM tt_Customers;
    
    SELECT 	COUNT(1) INTO v_BundleCount 
    FROM 	tb_CVMBundlePurchase 	BP
    JOIN 	tt_Customers			C	ON C.CustomerId	= BP.CustomerId
	WHERE 	BP.CompanyId = v_companyId
    AND 	BP.PurchaseDate between p_fromDate AND p_toDate;
        
    SELECT 	COUNT(1) INTO v_TopupCount 
    FROM 	tb_CVMTopUpPurchase		TP
    JOIN 	tt_Customers			C	ON C.CustomerId	= TP.CustomerId
	WHERE 	TP.CompanyId = p_domainId 
    AND 	TP.PurchaseDate between p_fromDate AND p_toDate;
    
	SELECT v_customerCount, v_BundleCount, v_TopupCount;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `cvm_deleteAllCusDtlTb` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `cvm_deleteAllCusDtlTb`()
BEGIN	

		DECLARE  v_errMsg	VARCHAR(50)	DEFAULT "Failed";
		DECLARE  v_count	INT;
        
		
		IF EXISTS (SELECT 1 FROM tb_CVMCustomer) THEN
			
            DELETE FROM  tb_CVMCustomer;
             
             SET v_count = (SELECT COUNT(1) FROM tb_CVMCustomer);
			
            IF v_count = 0 THEN 
				SET v_errMsg = "Deleted Successfully";
			END IF; 
            
		ELSE
				SET v_errMsg = "Records not available to delete";
        END IF;
        
        
        SELECT v_errMsg AS "Message";
        
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `cvm_deleteAllCusDtlTb1` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `cvm_deleteAllCusDtlTb1`()
BEGIN	

		DECLARE  v_errMsg	VARCHAR(50)	DEFAULT "Failed";
		DECLARE  v_count	INT;
        
		
		IF EXISTS (SELECT 1 FROM sample1) THEN
			
            DELETE FROM  sample1;
             
             SET v_count = (SELECT COUNT(1) FROM sample1);
			
            IF v_count = 0 THEN 
				SET v_errMsg = "Deleted Successfully";
			END IF; 
            
		ELSE
				SET v_errMsg = "Records not available to delete";
        END IF;
        
        
        SELECT v_errMsg AS "Message";
        
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `cvm_deleteAllCusTelecomDtlTb` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `cvm_deleteAllCusTelecomDtlTb`()
BEGIN	

		DECLARE  v_errMsg	VARCHAR(50)	DEFAULT "Failed";
		DECLARE  v_count	INT;
        
		
		IF EXISTS (SELECT 1 FROM tb_CVMCustomerTelecomDetail) THEN
			
            DELETE FROM  tb_CVMCustomerTelecomDetail;
             
             SET v_count = (SELECT COUNT(1) FROM tb_CVMCustomerTelecomDetail);
			
            IF v_count = 0 THEN 
				SET v_errMsg = "Deleted Successfully";
			END IF; 
            
		ELSE
				SET v_errMsg = "Records not available to delete";
        END IF;
        
        
        SELECT v_errMsg AS "Message";
        
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `cvm_deleteAllRecommendationDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `cvm_deleteAllRecommendationDtl`()
begin
		
        declare v_errMsg  varchar(50) default "failed/No data found in table";
        declare v_errCode  int default -1;
        declare flag	  tinyint  default 0;
        
        
        if exists(SELECT 1 from tb_CVMRecommendationDtl) THEN
				
                truncate tb_CVMRecommendationDtl;
				set flag = 1;
        END IF;
		
        if flag = 1 THEN 
				SET v_errMsg = "Deleted Successfully";
                set v_errCode = 1;
				
		end if;	

		SELECT v_errCode as errCode, v_errMsg as errMsg;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `cvm_delete_lyca_topup_details_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `cvm_delete_lyca_topup_details_details`()
begin
			truncate tb_lyca_topup_details;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `cvm_getAllCustomerRevenueDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`javateam`@`%` PROCEDURE `cvm_getAllCustomerRevenueDtl`(
 p_companyId	INT,
 p_fromDate		DATETIME,
 p_toDate		DATETIME,
 p_NBOSegment	VARCHAR(20)
 )
BEGIN	
    DECLARE v_topUpAmount		INT;
 	DECLARE v_bundleAmount		INT;
    DECLARE v_companyId			INT;
    DECLARE v_toDate			DATETIME;
    DECLARE v_NBOSegment		VARCHAR(50);
     
     SET v_companyId = IFNULL(p_companyId, 0);
     SET v_toDate = CONCAT(DATE(p_toDate)," 23:59:59");     
         
 	SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    DROP TEMPORARY TABLE IF EXISTS tt_Customers;
    CREATE TEMPORARY TABLE tt_Customers 
    SELECT 	CustomerId FROM tb_CVMCustomer
	WHERE 	CompanyId = v_companyId 
    AND		RollInDate BETWEEN p_fromDate AND v_toDate
    AND 	(p_NBOSegment IS NULL OR NBOSegment = p_NBOSegment);
    
	SELECT 	SUM(t1.Amount) 
    INTO 	v_topUpAmount
	FROM 	tt_Customers	 	t2
	JOIN 	tb_CVMTopUpPurchase t1 ON t1.CustomerId = t2.CustomerId 
	WHERE 	t1.PurchaseDate BETWEEN p_fromDate AND v_toDate;
    
	SELECT 	SUM(t1.Price) 
    INTO 	v_bundleAmount
	FROM 	tt_Customers	 	t2
	JOIN 	tb_CVMBundlePurchase t1 ON t1.CustomerId = t2.CustomerId 
	WHERE 	t1.PurchaseDate BETWEEN p_fromDate AND v_toDate;
    
    SELECT 	ROUND((v_topUpAmount + v_bundleAmount),2) 			AS totalRevenue 
		,	COUNT(1)											AS totalUsers
        ,	ROUND((v_topUpAmount + v_bundleAmount)/COUNT(1),2) 	AS averageRevenuePerUser
    FROM 	tt_Customers;         
 	SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `cvm_getAPRUCategoryDist` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `cvm_getAPRUCategoryDist`(
p_domain 			INT,
p_startDate 		DATETIME,
p_endDate 			DATETIME,
p_NBOSegment		VARCHAR(20)
)
BEGIN
        
        SET p_endDate = CONCAT(DATE(p_endDate)," 23:59:59");
        
		
	SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED; 
		
        SELECT 
				SUM( CASE WHEN ARPUCategory = "Low ARPU" THEN 1 ELSE 0 END) AS "Low ARPU",
                SUM( CASE WHEN ARPUCategory = "High ARPU" THEN 1 ELSE 0 END) AS "High ARPU",
                SUM( CASE WHEN ARPUCategory = "Medium ARPU" THEN 1 ELSE 0 END) AS "Medium ARPU"
		FROM tb_CVMCustomer
        WHERE 
         CompanyId = IFNULL(p_domain, 0) AND
        (RollInDate BETWEEN p_startDate AND p_endDate) AND
        (IFNULL(p_NBOSegment, '') = '' OR NBOSegment = p_NBOSegment);
			
	SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
        
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `cvm_getChurnPredictionOverallResult` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `cvm_getChurnPredictionOverallResult`(
		p_domainId		INT,
        p_startDate		DATETIME,
        p_endDate		DATETIME		
)
begin
	
		DECLARE v_startDate		DATETIME;
        DECLARE v_endDate		DATETIME;
        
        SET v_startDate 	= 	DATE_FORMAT(p_startDate, "%Y-%m-%d 00:00:00");
        SET v_endDate 		= 	DATE_FORMAT(p_endDate, "%Y-%m-%d 23:59:59");
       
       
        SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        
         SELECT segement, SUM(customerCount) as customerCount
        FROM tb_CVMChurnHistoryDtl
        WHERE (RecordedDate >= v_startDate and RecordedDate <= v_endDate )
				AND (companyId = p_domainId OR IFNULL(p_domainId, '')= '')
		GROUP BY segement;

		SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `cvm_getChurnPredictionProbability` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `cvm_getChurnPredictionProbability`(
		p_domainId		INT,
        p_startDate		DATETIME,
        p_endDate		DATETIME		
)
begin
	
		DECLARE v_startDate		DATETIME;
        DECLARE v_endDate		DATETIME;
        declare v_totalCustomerCount	INT;
        
        SET v_startDate 	= 	DATE_FORMAT(p_startDate, "%Y-%m-%d 00:00:00");
        SET v_endDate 		= 	DATE_FORMAT(p_endDate, "%Y-%m-%d 23:59:59");
        
        SELECT sum(customerCount) INTO v_totalCustomerCount
        FROM tb_CVMChurnHistoryDtl
        WHERE (RecordedDate >= v_startDate and RecordedDate <= v_endDate )
				AND (companyId = p_domainId OR IFNULL(p_domainId, '')= '');
       
       
       
        SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        
        SELECT segement, 
			case when v_totalCustomerCount IS NOT NULL THEN (sum(customerCount)/v_totalCustomerCount)*100 ELSE 0 END as percentage
        FROM tb_CVMChurnHistoryDtl
        WHERE (RecordedDate >= v_startDate and RecordedDate <= v_endDate )
				AND (companyId = p_domainId OR IFNULL(p_domainId, '')= '')
		GROUP BY segement;
        
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
        
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `cvm_getChurnPredictionSegementDtlResult` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `cvm_getChurnPredictionSegementDtlResult`(
		p_domainId		INT,
        p_startDate		DATETIME,
        p_endDate		DATETIME		
)
BEGIN
		DECLARE v_startDate		DATETIME;
        DECLARE v_endDate		DATETIME;
        
        SET v_startDate 	= 	DATE_FORMAT(p_startDate, "%Y-%m-%d 00:00:00");
        SET v_endDate 		= 	DATE_FORMAT(p_endDate, "%Y-%m-%d 23:59:59");
       

       
        SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        
        SELECT segement, SUM(customerCount) as customerCount, SUM(revenue) as revenue, SUM(APRU) as APRU
        FROM tb_CVMChurnHistoryDtl
        WHERE (RecordedDate >= v_startDate and RecordedDate <= v_endDate )
				AND (companyId = p_domainId OR IFNULL(p_domainId, '')= '')
		GROUP BY segement;
        
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;        
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `cvm_getCLVAnalysis_BundleAmountByHours` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `cvm_getCLVAnalysis_BundleAmountByHours`(
	p_domainId		INT,
	p_fromYear		DATE,
	p_toYear		DATE
)
BEGIN

	
		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        
			
			select PurchaseHour AS Hours, PurchaseYear as years ,   sum(Price) as totalAmount FROM 
            tb_CVMBundlePurchase 
            WHERE (CompanyId = p_domainId or IFNULL(p_domainId, '') = '') 
            AND PurchaseDate between p_fromYear AND p_toYear
			group by PurchaseHour, PurchaseYear
            order by 2,  1
			;
        
        
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
        
        
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `cvm_getCLVAnalysis_BundleCountsByHours` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `cvm_getCLVAnalysis_BundleCountsByHours`(
	p_domainId		INT,
	p_fromYear		DATE,
	p_toYear		DATE
)
BEGIN

	
		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        
			
			select PurchaseHour AS Hours, PurchaseYear as years,  COUNT(1) as totalCount FROM 
            tb_CVMBundlePurchase 
            WHERE (CompanyId = p_domainId OR IFNULL(p_domainId, '') = '') 
            AND date(PurchaseDate) between  p_fromYear AND p_toYear
			group by PurchaseHour, PurchaseYear
            order by 2, 1
			;
        
        
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
        
        
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `cvm_getCLVAnalysis_BundleCountsByWeekday` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `cvm_getCLVAnalysis_BundleCountsByWeekday`(p_domainId		INT,
 p_fromYear		DATE,
 p_toYear		DATE
)
BEGIN

	
		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        
			
			select WEEKDAY(PurchaseDate) AS WeekDays,  COUNT(1) as TotalCount FROM 
            tb_CVMBundlePurchase 
            WHERE (CompanyId = p_domainId OR IFNULL(p_domainId, '')= '' )
				AND (PurchaseDate >=  p_fromYear AND PurchaseDate <=  p_toYear)
			group by WEEKDAY(PurchaseDate)
            order by 1
			;
        
        
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
        
        
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `cvm_getCLVAnalysis_HighestRevenueByBundle` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `cvm_getCLVAnalysis_HighestRevenueByBundle`(p_domainId		INT,
 p_fromYear		DATE,
 p_toYear		DATE
)
BEGIN

		declare v_fromYear			smallint;
        declare v_toYear			smallint;
        declare v_minYear			smallint;
        declare v_maxYear			smallint;
        
     
       set v_fromYear = YEAR(p_fromYear);
       set v_toYear = YEAR(p_toYear);
      
		
    
		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        
			
			select PurchaseYear,  SUM(Price) as amount FROM 
            tb_CVMBundlePurchase 
            WHERE (CompanyId = p_domainId OR IFNULL(p_domainId, '') =  '')
            AND PurchaseYear between v_fromYear and v_toYear 
			group by PurchaseYear
			;
        
        
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
        
        
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `cvm_getCLVAnalysis_HighestRevenueByTopUps` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `cvm_getCLVAnalysis_HighestRevenueByTopUps`(p_domainId		INT,
 p_fromYear		DATE,
 p_toYear		DATE
)
BEGIN

		declare v_fromYear			smallint;
        declare v_toYear			smallint;
        declare v_minYear			smallint;
        declare v_maxYear			smallint;
        
     
       set v_fromYear = YEAR(p_fromYear);
       set v_toYear = YEAR(p_toYear);
        

		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        
			
			select PurchaseYear,  SUM(Amount) as amount FROM 
            tb_CVMTopUpPurchase 
            WHERE (CompanyId = p_domainId OR IFNULL(p_domainId, '') =  '')AND
            (PurchaseYear >= v_fromYear AND PurchaseYear <= v_toYear)
			group by PurchaseYear
			;
        
        
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
        
        
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `cvm_getCLVAnalysis_TopUpAmountByHours` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `cvm_getCLVAnalysis_TopUpAmountByHours`(
	p_domainId		INT,
	p_fromYear		DATE,
	p_toYear		DATE
)
BEGIN

	
		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        
			
			select PurchaseHour AS Hours, year(PurchaseDate) years,  sum(Amount) as totalAmount FROM 
            tb_CVMTopUpPurchase 
            WHERE (CompanyId = p_domainId or IFNULL(p_domainId, '') = '') 
            AND (PurchaseDate >=  p_fromYear AND PurchaseDate <=  p_toYear)
			group by PurchaseHour,  year(PurchaseDate)
            order by 2, 1
			;
        
        
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
        
        
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `cvm_getCLVAnalysis_TopUpCountsByHours` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `cvm_getCLVAnalysis_TopUpCountsByHours`(
	p_domainId		INT,
	p_fromYear		DATE,
	p_toYear		DATE
)
BEGIN

	
		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        
			
			select PurchaseHour AS Hours, year(PurchaseDate) as Years,  COUNT(1) as totalCount FROM 
            tb_CVMTopUpPurchase 
            WHERE (CompanyId = p_domainId OR IFNULL(p_domainId, '') = '') AND
            PurchaseDate  between p_fromYear AND p_toYear
			group by PurchaseHour ,year(PurchaseDate) 
            order by 2, 1
			;
        
        
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
        
        
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `cvm_getCLVAnalysis_TopUpCountsByWeekday` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `cvm_getCLVAnalysis_TopUpCountsByWeekday`(p_domainId		INT,
 p_fromYear		DATE,
 p_toYear		DATE
)
BEGIN

	
		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        
			
			select WEEKDAY(PurchaseDate) AS WeekDays,  COUNT(1) as TotalCount FROM 
            tb_CVMTopUpPurchase 
            WHERE (CompanyId = p_domainId OR IFNULL(p_domainId, '')= '' )AND (PurchaseDate >=  p_fromYear AND PurchaseDate <=  p_toYear)
			group by WEEKDAY(PurchaseDate)
            order by 1
			;
        
        
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
        
        
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `cvm_getContactsDashboard` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `cvm_getContactsDashboard`(
p_domainId	INT,
p_search	VARCHAR(50),
p_limit		INT,
p_offset	INT
)
BEGIN
		DECLARE v_offset int ;
        
        SET v_offset = p_limit * p_offset;
        
        
        
		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        
		SELECT 
			CASE 
            WHEN FirstName IS NOT NULL OR LastName IS NOT NULL THEN CONCAT(FirstName," ", LastName) 
										ELSE CONCAT("Customer","_",CustomerId) END AS "name",
			CustomerId	AS "contactID",
            "CSV File" as "source",
            Email AS "emailAddress",
            DATE(RollInDate)	AS "signupDate"
        FROM 
        tb_CVMCustomer WHERE (IFNULL(p_domainId, '')= '' OR CompanyId = p_domainId)
        AND(
			IFNULL(p_search,'') = '' OR CustomerId LIKE CONCAT("%",p_search,"%") 
			OR IFNULL(CONCAT(FirstName," ", LastName),CONCAT("Customer","_",CustomerId)) LIKE CONCAT("%",p_search,"%")
            OR Email LIKE CONCAT("%",p_search,"%")
            OR RollInDate LIKE CONCAT("%",p_search,"%")
            )
        ORDER BY contactID
        LIMIT v_offset , p_limit;
        
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `cvm_getCountofCusTelecomDetailTb` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `cvm_getCountofCusTelecomDetailTb`()
BEGIN
		SELECT COUNT(1) AS TotalInserted FROM tb_CVMCustomerTelecomDetail;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `cvm_getCountofCustomerTb` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `cvm_getCountofCustomerTb`()
BEGIN
		SELECT COUNT(1) AS TotalInserted FROM tb_CVMCustomer;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `cvm_getCustomerChurnDist` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `cvm_getCustomerChurnDist`(
p_domainId		INT,
p_fromDate		DATETIME,
p_toDate		DATETIME,
p_NBOSegment	VARCHAR(20)
)
BEGIN
        DECLARE	v_toDate		DATETIME;
        
    
        SET v_toDate = CONCAT(date(p_toDate)," 23:59:59");
        
        SET p_domainId = IFNULL(p_domainId, 0);
        
        SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED; 
        
        SELECT 
				SUM(CASE WHEN Churn = 0 THEN 1 ELSE 0 END) AS "Not Churn",
                SUM(Churn) AS "Churn"
        FROM tb_CVMCustomer
        WHERE CompanyId =  p_domainId
			AND (IFNULL(p_NBOSegment, '')= '' OR p_NBOSegment = NBOSegment)
			AND (RollOutDate >= p_fromDate AND RollOutDate <= v_toDate);

		SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ; 
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `cvm_getCustomerValueSegment` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `cvm_getCustomerValueSegment`(
	p_domainId		INT,
	p_startDate		DATETIME,
	p_endDate		DATETIME
)
BEGIN

		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        
		SELECT 
			t1.NBOSegment AS segmentName,
			COUNT(t1.CustomerId) AS customerCount,
			AVG(t2.ARPUPerMonth) AS averageRevenue,
			SUM(t2.CLVSimple) AS clv
		
		FROM tb_CVMCustomer t1 
			JOIN tb_CVMCustomerTelecomDetail t2 ON t1.CustomerId = t2.CustomerId AND t1.CompanyId = t2.CompanyId
		WHERE (IFNULL(p_domainId, '') = '' OR t1.CompanyId = p_domainId)
		GROUP BY t1.NBOSegment
        ORDER BY averageRevenue DESC;
				
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `cvm_getDashboardMonthlyRevenue` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`javateam`@`%` PROCEDURE `cvm_getDashboardMonthlyRevenue`(
 	p_domainId		INT,
 	p_startDate		DATE,
     p_endDate		DATE
 )
BEGIN
		DECLARE v_startDate		DATETIME;
		DECLARE v_endDate		DATETIME;

		SET v_startDate = p_startDate;
		SET v_endDate 	= CONCAT(p_endDate," 23:59:59");         
         
        SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;         
		DROP TEMPORARY TABLE IF EXISTS tt_Months;
		CREATE TEMPORARY TABLE tt_Months(`Month`	TINYINT);    
		INSERT INTO tt_Months(`Month`)
		VALUES(1),(2),(3),(4),(5),(6),(7),(8),(9),(10),(11),(12);            
         
		DROP TEMPORARY TABLE IF EXISTS tt_DashboardMonthlyRevenue;
		CREATE TEMPORARY TABLE tt_DashboardMonthlyRevenue         
		SELECT MobileNo, CompanyId, "bundle" as `type`, BundlePurchaseId AS PurchaseId, PurchaseDate, Price, PurchaseMonth FROM tb_CVMBundlePurchase
		WHERE (IFNULL(p_domainId, '')= '' OR CompanyId = p_domainId)
		AND (DATE(PurchaseDate) >= v_startDate AND DATE(PurchaseDate) <= v_endDate )
		UNION ALL
		SELECT MobileNo, CompanyId, "topup" as `type`, TopUpPurchaseId AS PurchaseId, PurchaseDate, Amount AS Price, PurchaseMonth FROM tb_CVMTopUpPurchase
		WHERE (IFNULL(p_domainId, '')= '' OR CompanyId = p_domainId)
		AND (DATE(PurchaseDate) >= v_startDate AND DATE(PurchaseDate) <= v_endDate);         
         
		SELECT IFNULL(SUM(Price),0) AS Revenue, M.`Month`			
		FROM tt_Months	M
        LEFT JOIN tt_DashboardMonthlyRevenue MR ON MR.`PurchaseMonth` = M.`Month`	
		GROUP BY M.`Month`
		ORDER BY M.`Month`;        
		SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;         
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `cvm_getIndividualCustomerDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `cvm_getIndividualCustomerDtl`(
	p_domainId			INT,
    p_customerId		INT
)
BEGIN
		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
				
			SELECT CONCAT(FirstName,"", LastName) AS `Name`, 
					City,
                    CustomerId,
                    "" AS  gender,
                    MobileNo AS contactNumber,
                    Email	AS emailAddress,
                    ARPUCategory AS Segment
            FROM tb_CVMCustomer
            WHERE (IFNULL(p_domainId , '') = '' OR CompanyId = p_domainId)
            AND CustomerId = p_customerId;
        
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `cvm_getNBOSegment` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `cvm_getNBOSegment`()
BEGIN
		SELECT DISTINCT	NBOSegment FROM tb_CVMCustomer;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `cvm_getNPSAnalyticsScore` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `cvm_getNPSAnalyticsScore`(
	p_domainId		INT,
    p_fromDate		DATETIME,
    p_toDate		DATETIME,
    p_NBOSegment	VARCHAR(20)
)
BEGIN
		DECLARE v_NPSScoreProxy		INT;
		DECLARE v_requst			INT;
        DECLARE v_toDate			DATETIME;
        
        SET v_toDate = CONCAT(DATE(p_toDate)," 23:59:59");
        
        SELECT SUM(t1.NPSScoreProxy) INTO v_NPSScoreProxy FROM 
					tb_CVMCustomerTelecomDetail t1
                    JOIN tb_CVMCustomer	t2		ON t1.CustomerId = t2.CustomerId AND t1.CompanyId = t2. CompanyId
			where t1.CompanyId = IFNULL(p_domainId, 0) 
            AND (t2.RollOutDate BETWEEN p_fromDate AND v_toDate) 
            AND (IFNULL(p_NBOSegment, '')= '' OR  t2.NBOSegment = p_NBOSegment );
        
        SELECT SUM(CASE WHEN t1.DominantIssueTypeId = "inquiry" THEN 1 ELSE 0 END)  INTO v_requst 
						FROM tb_CVMCustomerTelecomDetail t1
                        JOIN tb_CVMCustomer	t2		ON t1.CustomerId = t2.CustomerId AND t1.CompanyId = t2.CompanyId
			where t1.CompanyId = IFNULL(p_domainId, 0)
             AND ( t2.RollOutDate BETWEEN p_fromDate AND v_toDate)
              AND (IFNULL(p_NBOSegment, '')= '' OR  t2.NBOSegment = p_NBOSegment );
        
        
        SELECT v_NPSScoreProxy AS "Net Promoter Score", v_requst AS "Response Recieved";
        
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `cvm_getNpsBuckets` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `cvm_getNpsBuckets`(
	p_domainID		INT,
	p_fromDate		DATETIME,
    P_toDate		DATETIME,
    p_NBOSegment	VARCHAR(20)
)
BEGIN
		DECLARE v_fromDate			DATETIME;
		DECLARE v_toDate			DATETIME;
        DECLARE v_minFromDate		DATETIME;
        DECLARE v_maxtoDate			DATETIME;
        
        SET v_toDate = CONCAT(DATE(P_toDate)," 23:59:59");
                 
		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        
					SELECT 
					SUM(CASE WHEN NPSCategory = "Detractor" THEN 1 ELSE 0 END) AS "Detractor",
					SUM(CASE WHEN NPSCategory = "Passive" THEN 1 ELSE 0 END) AS "Passive",
					SUM(CASE WHEN NPSCategory = "Promotor" THEN 1 ELSE 0 END) AS "Promotor"
					FROM tb_CVMCustomer
                    WHERE CompanyId = IFNULL(p_domainID, 0) 
                    AND (RollOutDate BETWEEN p_fromDate AND v_toDate)
                    AND (IFNULL(p_NBOSegment, '')= '' OR NBOSegment = p_NBOSegment)
                    ;

		SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
        
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `cvm_getNPSScoreTrends` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `cvm_getNPSScoreTrends`(
	p_domainId		INT,
    p_startDate		DATETIME,
    p_endDate		DATETIME,
    p_NBOSegment	VARCHAR(20)
   
)
BEGIN
			DECLARE v_endDate  datetime;
            
            SET v_endDate = CONCAT(DATE(p_endDate)," 23:59:59");
            
		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        
        SELECT 	
        SUM(CASE WHEN  DATE_FORMAT(t2.RollOutDate, "%m") = 01 THEN NPSScoreProxy ELSE 0 END) AS JAN,
		SUM(CASE WHEN  DATE_FORMAT(t2.RollOutDate, "%m") = 02 THEN NPSScoreProxy ELSE 0 END) AS FEB,
		SUM(CASE WHEN  DATE_FORMAT(t2.RollOutDate, "%m") = 03 THEN NPSScoreProxy ELSE 0 END) AS MAR,
        SUM(CASE WHEN  DATE_FORMAT(t2.RollOutDate, "%m") = 04 THEN NPSScoreProxy ELSE 0 END) AS APR,
        SUM(CASE WHEN  DATE_FORMAT(t2.RollOutDate, "%m") = 05 THEN NPSScoreProxy ELSE 0 END) AS MAY,
		SUM(CASE WHEN  DATE_FORMAT(t2.RollOutDate, "%m") = 06 THEN NPSScoreProxy ELSE 0 END) AS JUN,
		SUM(CASE WHEN  DATE_FORMAT(t2.RollOutDate, "%m") = 07 THEN NPSScoreProxy ELSE 0 END) AS JUL,
		SUM(CASE WHEN  DATE_FORMAT(t2.RollOutDate, "%m") = 08 THEN NPSScoreProxy ELSE 0 END) AS AUG,
		SUM(CASE WHEN  DATE_FORMAT(t2.RollOutDate, "%m") = 09 THEN NPSScoreProxy ELSE 0 END) AS SEP,
		SUM(CASE WHEN  DATE_FORMAT(t2.RollOutDate, "%m") = 10 THEN NPSScoreProxy ELSE 0 END) AS OCT,
		SUM(CASE WHEN  DATE_FORMAT(t2.RollOutDate, "%m") = 11 THEN NPSScoreProxy ELSE 0 END) AS NOV,
		SUM(CASE WHEN  DATE_FORMAT(t2.RollOutDate, "%m") = 12 THEN NPSScoreProxy ELSE 0 END) AS `DEC`
        FROM tb_CVMCustomerTelecomDetail t1
        JOIN tb_CVMCustomer t2		ON t1.CustomerId = t2.CustomerId AND t1.CompanyId = t2.CompanyId
        WHERE  t2.CompanyId = IFNULL(p_domainId, 0)
        AND (t2.RollOutDate BETWEEN p_startDate AND v_endDate)
     
        AND(IFNULL(p_NBOSegment, '')= '' OR NBOSegment = p_NBOSegment);
        

        
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `cvm_getPredictedRiskMetricTrends` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `cvm_getPredictedRiskMetricTrends`(
	p_companyId		INT,
 p_startDate		DATETIME,
 p_endDate			DATETIME,
 p_NBOSegment		VARCHAR(20)
)
BEGIN

		DECLARE v_endDate datetime;
        
        SET v_endDate = CONCAT(DATE(p_endDate)," 23:59:59");
        
		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        
        SELECT 
        SUM(CASE WHEN date_format(RollOutDate, "%m") = 01 THEN 1 ELSE 0 END) AS JAN,	
		SUM(CASE WHEN date_format(RollOutDate, "%m") = 02 THEN 1 ELSE 0 END) AS FEB,
        SUM(CASE WHEN date_format(RollOutDate, "%m") = 03 THEN 1 ELSE 0 END) AS MAR,
        SUM(CASE WHEN date_format(RollOutDate, "%m") = 04 THEN 1 ELSE 0 END) AS APR,
        SUM(CASE WHEN date_format(RollOutDate, "%m") = 05 THEN 1 ELSE 0 END) AS MAY,
        SUM(CASE WHEN date_format(RollOutDate, "%m") = 06 THEN 1 ELSE 0 END) AS JUN,
        SUM(CASE WHEN date_format(RollOutDate, "%m") = 07 THEN 1 ELSE 0 END) AS JUL,
        SUM(CASE WHEN date_format(RollOutDate, "%m") = 08 THEN 1 ELSE 0 END) AS AUG,
        SUM(CASE WHEN date_format(RollOutDate, "%m") = 09 THEN 1 ELSE 0 END) AS SEP,
        SUM(CASE WHEN date_format(RollOutDate, "%m") = 10 THEN 1 ELSE 0 END) AS `OCT`,
        SUM(CASE WHEN date_format(RollOutDate, "%m") = 11 THEN 1 ELSE 0 END) AS NOV,
        SUM(CASE WHEN date_format(RollOutDate, "%m") = 12 THEN 1 ELSE 0 END) AS `DEC`
		FROM tb_CVMCustomer	WHERE Churn = 0 AND
         CompanyId = IFNULL(p_companyId,0) AND
        (RollOutDate BETWEEN p_startDate AND v_endDate) AND
        (IFNULL(p_NBOSegment,'') = '' OR NBOSegment = p_NBOSegment);
        
        SET SESSION TRANSACTION ISOLATION LEVEL repeatable read;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `cvm_getRecommendationDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `cvm_getRecommendationDtl`(p_domainId			INT)
BEGIN
		
        SET session transaction isolation level read uncommitted;
        
        SELECT bundleName, count(customerName) as Users, ROUND(AVG(ARPU),4) as ARPU, channelType, "Benefits" as Benefits  
        FROM tb_CVMRecommendationDtl
        WHERE (companyId =  p_domainId OR IFNULL(p_domainId, '') = '' )
        GROUP BY bundleName, channelType;
        
        SET session transaction isolation level repeatable read;
        
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `cvm_getSegementation_BasedOnCustomers` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `cvm_getSegementation_BasedOnCustomers`(p_domainId   INT)
begin
			
            set session transaction isolation level read uncommitted;
            SELECT  t1.NBOSegment as Category, count(t1.CustomerId) AS totalCustomer , AVG(TotalSpendAmount) as averageRevenue
            ,sum(t2.CLVSimple) as CLV
            FROM  tb_CVMCustomer t1
            join tb_CVMCustomerTelecomDetail  t2  ON t1.CustomerId = t2.CustomerId
            where (t1.CompanyId = p_domainId or IFNULL(p_domainId, '') = '')
            group by NBOSegment;
            
            set session transaction isolation level repeatable read;
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `cvm_getSegementation_DistributionChart` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `cvm_getSegementation_DistributionChart`(p_domainId			INT)
BEGIN
		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        
        select t1.NBOSegment as Category, sum(t2.TotalSpendAmount) as TotalRevenue  FROM  tb_CVMCustomer t1
            join tb_CVMCustomerTelecomDetail  t2  ON t1.CustomerId = t2.CustomerId
            where (t1.CompanyId = p_domainId or IFNULL(p_domainId, '') = '')
            group by NBOSegment
            ;
            
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `cvm_getSegementation_TargetedExperience` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `cvm_getSegementation_TargetedExperience`(p_domainId  INT)
begin
		DECLARE v_activeCustomer    	int default 0;
        DECLARE v_segments    			int default 0;
        DECLARE v_inactiveCustomer    	int default 0;
        DECLARE v_complaints    		int default 0;
        
        DECLARE v_currentDate			date default now();
        
      
        
				
			DROP TEMPORARY TABLE IF EXISTS tt_activeCustomer;
            CREATE TEMPORARY TABLE tt_activeCustomer
				SELECT t1.CustomerId, t1.CompanyId 
					FROM tb_CVMCustomer t1
					JOIN tb_CVMCustomerTelecomDetail t2 ON t1.CustomerId = t2.CustomerId
					WHERE  
							((t1.RollOutDate IS NULL OR date(t1.RollOutDate) > v_currentDate) 
                            OR DATEDIFF(v_currentDate, GREATEST(t2.LastTopupDate, t2.LastBundleDate) ) <= 120)
                    AND (t1.CompanyId = p_domainId OR IFNULL(p_domainId, '') ='');
                    
                
                
		SELECT COUNT(CustomerId) INTO v_activeCustomer 
			FROM tt_activeCustomer;																	
            
		
		SELECT COUNT(1) - v_activeCustomer INTO v_inactiveCustomer										
           FROM tb_CVMCustomer
			WHERE (CompanyId = p_domainId OR IFNULL(p_domainId, '') ='');
            
          
        
        SELECT COUNT(DISTINCT NBOSegment) INTO v_segments  
			FROM  tb_CVMCustomer 
			WHERE (CompanyId = p_domainId OR IFNULL(p_domainId,'') = '');		
        
        

        SELECT COUNT(t2.CustomerId) INTO v_complaints 									
			FROM tt_activeCustomer t1
			JOIN tb_CVMCustomerComplaint t2  ON t1.CustomerId = t2.CustomerId AND t1.CompanyId = t2.CompanyId
			WHERE  (t1.CompanyId = p_domainId OR IFNULL(p_domainId,'') = '');
        
        SELECT v_activeCustomer as activeCustomer, 
				v_segments as segments, 
                v_inactiveCustomer as inactiveCustomer , 
                v_complaints as complaints;
        
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `cvm_getSentimentAnalysis` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `cvm_getSentimentAnalysis`(
	p_domainID		INT,
	p_fromDate		DATETIME,
    P_toDate		DATETIME,
    p_NBOSegment	VARCHAR(20)
)
BEGIN

		DECLARE v_total INT;
        DECLARE v_Positive INT;
        DECLARE v_Negative INT;
        DECLARE v_Neutal INT;
        DECLARE v_toDate	DATETIME;
        
        
        SET v_toDate = CONCAT(DATE(P_toDate)," 23:59:59");
        
        SET p_domainID = IFNULL(p_domainID, 0);
        
        SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        

        SELECT 
			SUM(t1.PosSent) ,
            SUM(t1.NegSent),
            SUM(t1.NeuSent)
            INTO  v_Positive, v_Negative, v_Neutal
        FROM tb_CVMCustomerTelecomDetail 	t1 
			JOIN tb_CVMCustomer				t2
			ON t1.CustomerId = t2.CustomerId AND t1.CompanyId = t2.CompanyId
        WHERE t1.CompanyId = p_domainID
			AND(LastActivityDate BETWEEN p_fromDate AND v_toDate)
			AND(IFNULL(p_NBOSegment, '') = '' OR t2.NBOSegment = p_NBOSegment);
            
		SET v_total = v_Positive+v_Negative+v_Neutal;
        
            
		SELECT 	
				ROUND((v_Positive/v_total)*100,1) AS Positive,
				ROUND((v_Negative/v_total)*100,1) AS Negative,
				ROUND((v_Neutal/v_total)*100,1) AS Neutral;
        
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
        
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `cvm_getTop10BundlePurchase` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `cvm_getTop10BundlePurchase`(
	p_domainId	INT,
    p_startDate	DATETIME,
    p_endDate	DATETIME,
    p_NBOSegment VARCHAR(20)
 )
BEGIN
			DECLARE v_endDate DATETIME;
            
            SET v_endDate =  CONCAT(DATE(p_endDate)," 23:59:59");
			
			 SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        
        
        
			with cte1 AS(
				SELECT t2.MobileNo,	COUNT(t2.BundlePurchaseId) AS topPrice
					FROM tb_CVMCustomer t1
					JOIN tb_CVMBundlePurchase t2 ON  t1.CustomerId = t2.CustomerId AND t1.CompanyId = t2.CompanyId
					WHERE  t1.CompanyId = IFNULL(p_domainId, 0) 
						AND (t2.PurchaseDate >= p_startDate and t2.PurchaseDate <=v_endDate) 
                        AND(IFNULL(p_NBOSegment,'') = ''  OR  t1.NBOSegment = p_NBOSegment)
					GROUP BY t2.MobileNo order by topPrice DESC
           ),
            cte2 AS(
              SELECT *, dense_rank() OVER(ORDER BY topPrice desc) as Rk 
              FROM cte1
              )
              SELECT Rk as `Rank`,MobileNo, topPrice as TotalBundleCount  FROM cte2 WHERE Rk <= 10;
              
				SET	SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `cvm_getTop10TopUpCount` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `cvm_getTop10TopUpCount`(
	p_domainId		INT,
	p_startDate		DATETIME,
    p_endDate		DATETIME,
    p_NBOSegment	VARCHAR(20)
)
BEGIN
		 
        DECLARE v_endDate DATETIME;
        
        SET v_endDate = CONCAT(DATE(p_endDate)," 23:59:59");
        
        SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        

			with cte1 AS(
				SELECT t2.MobileNo,	COUNT(t2.TopUpPurchaseId) AS topPrice
					FROM tb_CVMCustomer t1
					JOIN tb_CVMTopUpPurchase t2 ON  t1.CustomerId = t2.CustomerId AND t1.CompanyId = t2.CompanyId
					WHERE  t1.CompanyId = IFNULL(p_domainId, 0) 
						AND (t2.PurchaseDate >= p_startDate and t2.PurchaseDate <=v_endDate) 
                        AND(IFNULL(p_NBOSegment,'') = ''  OR  t1.NBOSegment = p_NBOSegment)
					GROUP BY t2.MobileNo order by topPrice DESC
           ),
            cte2 AS(
              SELECT *, dense_rank() OVER(ORDER BY topPrice desc) as Rk 
              FROM cte1
              )
              SELECT Rk as `Rank`,MobileNo, topPrice as TotalTopupCount  FROM cte2 WHERE Rk <= 10;
		
		SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `cvm_get_email_login_config_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `cvm_get_email_login_config_dtl`(p_email 		varchar(150))
BEGIN
			
         
            
            
			
         
            
            DECLARE v_login		int; 
        
        IF NOT EXISTS(SELECT 1 FROM tb_CVM_email_login_config_dtl WHERE email_id =  p_email) THEN
						
				INSERT INTO tb_CVM_email_login_config_dtl(email_id, is_login) values(p_email, 1);
                
                  IF ROW_COUNT() > 0 THEN 
					
                    SET v_login = 1;
                    
				   END IF;
		
			ELSE 
				 UPDATE tb_CVM_email_login_config_dtl 
					SET is_login = 0,
						updated_at = now()
				WHERE email_id = p_email;
                
                 IF row_count() > 0 THEN 
					SET v_login = 0;
				END IF;
        
        END IF;
		
        
        SELECT v_login as login;

 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `cvm_get_lyca_topup_details_count_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `cvm_get_lyca_topup_details_count_details`()
begin
			SELECT count(1) AS Total_Inserted_data FROM tb_lyca_topup_details;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `cvm_insertCVMChurnHistoryDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `cvm_insertCVMChurnHistoryDtl`(	p_RecordedDate			DATETIME ,
	p_companyId				INT,
	p_segement    			VARCHAR(500),
    p_customerCount			INT,
    p_revenue				INT,
    p_APRU					INT
)
SP :BEGIN
				DECLARE v_errMsg   varchar(50)  default "Failed to insert";
                DECLARE v_errCode	smallint	default -1;		


		IF (p_RecordedDate IS NULL OR p_segement IS NULL OR  p_customerCount IS NULL OR p_revenue IS  NULL OR p_APRU IS  NULL) THEN
				
					SELECT v_errCode, "some column in Null values" as errMsg;
                    
					LEAVE SP;
					
		END IF;
            
		INSERT INTO tb_CVMChurnHistoryDtl(RecordedDate, companyId , segement , customerCount	, revenue, APRU)
        values( p_RecordedDate ,p_companyId,  p_segement , p_customerCount	, p_revenue, p_APRU	);
        
        IF ROW_COUNT() > 0 THEN 
			set v_errMsg = "Inserted Successfully";
			set v_errCode = 0;
		END IF;
        
        select v_errCode as errCode, v_errMsg AS errMsg; 
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `cvm_insertRecommendationDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `cvm_insertRecommendationDtl`(	p_companyId		INT,
	p_name			VARCHAR(500),
    p_email			VARCHAR(500),
    p_channel		varchar(200),
    p_APRU			float,
    p_bundleName	VARCHAR(500),
    p_MobileNo		varchar(30)
)
begin
				DECLARE v_errCode	int default -1;
                DECLARE v_errMsg	varchar(50) default "Failed";

				INSERT INTO tb_CVMRecommendationDtl(companyId, `customerName`, `emailId`, channelType, ARPU, bundleName, MobileNo)
                VALUES(p_companyId,p_name, p_email, p_channel, p_APRU, p_bundleName, p_MobileNo );
                
                IF row_count() > 0 THEN 
						set v_errMsg = "Inserted Successfully";
                        set v_errCode = 0;
                END IF;
                
			SELECT v_errCode as errCode , v_errMsg as errMsg;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `cvm_insert_email_login_config_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `cvm_insert_email_login_config_dtl`( 
	p_email_id			VARCHAR(150),
    p_is_login			TINYINT
 )
BEGIN
			DECLARE v_errCode SMALLINT	DEFAULT -1;
            DECLARE v_errMsg VARCHAR(50) DEFAULT "Failed";
            
            IF NOT EXISTS( SELECT 1 FROM tb_CVM_email_login_config_dtl WHERE email_id =  p_email_id) THEN

			INSERT INTO tb_CVM_email_login_config_dtl
            (email_id, is_login) values(p_email_id, 0);
            
            IF row_count() > 0 THEN 
				SET v_errMsg	= "Inserted Successfully";
                SET v_errCode	= 0;
			END IF;
            ELSE
            
				UPDATE tb_CVM_email_login_config_dtl 
					SET is_login = IFNULL(p_is_login,0),
						updated_at = now()
				WHERE email_id = p_email_id;
                
                 IF row_count() > 0 THEN 
				SET v_errMsg	= "Updated Successfully";
                SET v_errCode	= 1;
			END IF;
            
		END IF;
            SELECT v_errCode as errCode, v_errMsg as errMsg;
            
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `cvm_insert_lyca_topup_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `cvm_insert_lyca_topup_details`(
	p_Sub_Acct_Id                     	INT,
	p_Actual_Bundle_Cost             	DECIMAL(20, 2),
	p_SIM_TYPE                        	VARCHAR(50),
	p_recharge_type                   	INT,
	p_CHANNEL_CATEGORY                	VARCHAR(50),
	p_Bundle_Purchase_Date    			DATETIME,
    p_Month                        		SMALLINT,
	p_year								SMALLINT
)
BEGIN
			DECLARE v_errMsg	varchar(50) default "failed";
            DECLARE v_errCode	smallInt 	default -1;

			INSERT INTO tb_lyca_topup_details (Sub_Acct_Id, Actual_Bundle_Cost, SIM_TYPE, recharge_type ,CHANNEL_CATEGORY , Bundle_Purchase_Date, `Month`, `year`)
            VALUES(p_Sub_Acct_Id, p_Actual_Bundle_Cost, p_SIM_TYPE, p_recharge_type ,p_CHANNEL_CATEGORY , p_Bundle_Purchase_Date, p_Month, p_year);
            
            IF ROW_COUNT() > 0 THEN 
					SET v_errCode = 0;
                    SET v_errMsg = "inserted Successfully";
			END IF;
            
            select v_errCode as errCode, v_errMsg as errMsg;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `cvm_lyca_add_update_churn_revenue_APRU` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `cvm_lyca_add_update_churn_revenue_APRU`(
  p_segement 		varchar(500),
  p_customerCount 	INT,
  p_revenue 		INT,
  p_APRU 			decimal(20,2)
)
BEGIN
	DECLARE v_now		DATETIME DEFAULT NOW();
    
    INSERT INTO tb_lyca_churn_revenue_APRU(
	segement
	,customerCount
	,revenue
	,APRU 	
    ,created_date		
    )
    VALUES(
    p_segement 		
    ,p_customerCount 	
    ,p_revenue 		
    ,p_APRU 			    				
    ,v_now
    );
    
    SELECT 1 AS errCode, 'Added churn prediction successfully'	AS errMsg;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `cvm_lyca_add_update_unified_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `cvm_lyca_add_update_unified_details`(
p_sub_Acct_Id					int
,p_Total_amount					decimal(20,2)
,p_CHANNEL_CATEGORY				varchar(30)
,p_SIM_TYPE						varchar(50)
,p_total_msg_cost				decimal(20,2)
,p_voice_Total_Talk_charge		decimal(20,2)
,p_GPRS_Total_Data_Charge_Used	decimal(24,6)
,p_CLV_Segment					varchar(50)
,p_NBO_Segment					varchar(30)
,p_RFM_Category					varchar(30)
,p_Cluster						tinyint
,p_isActive						tinyint	
)
BEGIN
	DECLARE v_now		DATETIME DEFAULT NOW();
    
    INSERT INTO tb_lyca_unified_details(
    `sub_Acct_Id` 				
    ,`Total_amount` 				
    ,`CHANNEL_CATEGORY` 			
    ,`SIM_TYPE` 					
    ,`total_msg_cost` 				
    ,`voice_Total_Talk_charge` 	
    ,`GPRS_Total_Data_Charge_Used` 
    ,`CLV_Segment` 				
    ,`NBO_Segment` 				
    ,`RFM_Category` 				
    ,`Cluster` 					
    ,`created_date`
    ,`isActive`
    )
    VALUES(
    p_sub_Acct_Id					
    ,p_Total_amount					
    ,p_CHANNEL_CATEGORY				
    ,p_SIM_TYPE						
    ,p_total_msg_cost				
    ,p_voice_Total_Talk_charge		
    ,p_GPRS_Total_Data_Charge_Used	
    ,p_CLV_Segment					
    ,p_NBO_Segment					
    ,p_RFM_Category					
    ,p_Cluster						
    ,v_now
    ,p_isActive
    );
    
    SELECT 1 AS errCode, 'Added unified_details successfully'	AS errMsg;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `cvm_lyca_count_churn_revenue_APRU` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `cvm_lyca_count_churn_revenue_APRU`()
BEGIN
	SELECT COUNT(1) FROM tb_lyca_churn_revenue_APRU;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `cvm_lyca_count_of_unified_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `cvm_lyca_count_of_unified_details`()
BEGIN
	SELECT COUNT(1) total_count	FROM tb_lyca_unified_details;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `cvm_lyca_delete_churn_revenue_APRU` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `cvm_lyca_delete_churn_revenue_APRU`()
BEGIN
DELETE FROM tb_lyca_churn_revenue_APRU;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `cvm_lyca_delete_unified_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `cvm_lyca_delete_unified_details`()
BEGIN
	DELETE FROM tb_lyca_unified_details;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `cvm_topUpPurchaseBasedOnHours` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`javateam`@`%` PROCEDURE `cvm_topUpPurchaseBasedOnHours`(
p_domainId  	INT,
P_fromYear  	DATETIME,
P_toYear     	DATETIME,
p_NBOSegment	VARCHAR(20)
 )
BEGIN	
		DECLARE v_fromYear 	DATETIME;
		DECLARE v_toYear  	DATETIME;
		DECLARE v_minYear  	smallint;
		DECLARE v_maxYear  	smallint;
         

          
		SET v_fromYear 	= P_fromYear;
		SET v_toYear  	= CONCAT(DATE(P_toYear)," 23:59:59");
         
		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
		SELECT 	TP.PurchaseYear
			,	TP.PurchaseHour
            ,	COUNT(1)	NoOfPurchase
		FROM 	tb_CVMTopUpPurchase	TP	
        JOIN 	tb_CVMCustomer		C	ON 	TP.CustomerId			= C.CustomerId										
        WHERE 	TP.CompanyId = IFNULL(p_domainId, 0)         
		AND		TP.PurchaseDate BETWEEN v_fromYear AND v_toYear
        AND 	(p_NBOSegment IS NULL OR C.NBOSegment = p_NBOSegment)	
        GROUP BY TP.PurchaseYear, TP.PurchaseHour
        ORDER BY TP.PurchaseYear, TP.PurchaseHour;        
		SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;      
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `cvm_topUpPurchaseBasedOnMonth` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`javateam`@`%` PROCEDURE `cvm_topUpPurchaseBasedOnMonth`(
	p_domainId  	INT,
	P_fromYear     	DATETIME,
	P_toYear     	DATETIME,
	p_NBOSegment	VARCHAR(20)
)
BEGIN	
        DECLARE v_fromYear 	DATETIME;
        DECLARE v_toYear  	DATETIME;
        DECLARE v_minYear  	DATETIME;
        DECLARE v_maxYear  	DATETIME;
        DECLARE v_companyId		INT;
    
		SET v_companyId = IFNULL(P_domainId,0);
        
        SELECT MIN(PurchaseDate), MAX(PurchaseDate) INTO v_minYear, v_maxYear  FROM tb_CVMTopUpPurchase 
         WHERE CompanyId = IFNULL(p_domainId, 0);
        
        SET P_toYear = CONCAT(DATE(P_toYear)," 23:59:59");
        
        SET v_fromYear = IFNULL(P_fromYear, v_minYear);
        SET v_toYear  = IFNULL(P_toYear, v_maxYear);
        
        SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;        
        SELECT PurchaseYear as YEAR,
				SUM(CASE WHEN PurchaseMonth = 1 THEN 1 ELSE 0 END) AS JAN,
				SUM(CASE WHEN PurchaseMonth = 2 THEN 1 ELSE 0 END) AS FEB,
                SUM(CASE WHEN PurchaseMonth = 3 THEN 1 ELSE 0 END) AS MAR,
				SUM(CASE WHEN PurchaseMonth = 4 THEN 1 ELSE 0 END) AS APR,
				SUM(CASE WHEN PurchaseMonth = 5 THEN 1 ELSE 0 END) AS MAY,
                SUM(CASE WHEN PurchaseMonth = 6 THEN 1 ELSE 0 END) AS JUN,
                SUM(CASE WHEN PurchaseMonth = 7 THEN 1 ELSE 0 END) AS JUL,
                SUM(CASE WHEN PurchaseMonth = 8 THEN 1 ELSE 0 END) AS AUG,
                SUM(CASE WHEN PurchaseMonth = 9 THEN 1 ELSE 0 END) AS SEP,
                SUM(CASE WHEN PurchaseMonth = 10 THEN 1 ELSE 0 END) AS "OCT",
                SUM(CASE WHEN PurchaseMonth = 11 THEN 1 ELSE 0 END) AS NOV,
                SUM(CASE WHEN PurchaseMonth = 12 THEN 1 ELSE 0 END) AS "DEC"
		FROM 	tb_CVMTopUpPurchase TP
        JOIN 	tb_CVMCustomer		C	ON 	TP.CustomerId	= C.CustomerId	
										AND (p_NBOSegment IS NULL OR C.NBOSegment = p_NBOSegment)	
        WHERE	TP.CompanyId 	= v_companyId
        AND		TP.PurchaseDate BETWEEN v_fromYear  AND v_toYear
        GROUP BY PurchaseYear
        ORDER BY YEAR DESC;
		SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;      
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `lyca_customer_cluster_count` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `lyca_customer_cluster_count`()
begin
		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

		select t2.cluster_name, count(t1.sub_Acct_Id) as totalCount FROM tb_lyca_unified_details t1
        JOIN tb_lyca_cluster_definition_details t2 ON t1.Cluster = t2.cluster_id
        group by t2.cluster_name;

				SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `lyca_delete_customer_profile_360_module` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `lyca_delete_customer_profile_360_module`()
begin
		truncate tb_lyca_customer_profile_360_module;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `lyca_delete_recommendation_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `lyca_delete_recommendation_details`(
)
begin
		
       truncate tb_lyca_recommendation_details;
      
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `lyca_get_churn_churn_Probability` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `lyca_get_churn_churn_Probability`(
 	
 )
BEGIN
 		
         DECLARE v_totalCustomerCount	INT;
         
      
         SELECT SUM(IFNULL(customerCount, 0)) INTO v_totalCustomerCount
         FROM tb_lyca_churn_revenue_APRU 
         where segement in('Fairly likely to churn','Most likely to churn','Less likely to churn');
         
        
        
        
         SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
         
 		 SELECT segement,
         CASE WHEN IFNULL(v_totalCustomerCount, 0) != 0 THEN ROUND((SUM(IFNULL(customerCount, 0))/v_totalCustomerCount)*100,2) ELSE 0 END as percentage
         FROM tb_lyca_churn_revenue_APRU
 			WHERE segement NOT IN ("overall likely to churn","Active", "Inactive")
         GROUP BY segement; 

         SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
         
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `lyca_get_churn_customer_using_predictive_analysis` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `lyca_get_churn_customer_using_predictive_analysis`(
 			
 )
BEGIN
 			DECLARE v_totalCount			INT;
        
         SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
         
         
          SELECT  segement, customerCount AS customerCount
         FROM tb_lyca_churn_revenue_APRU where segement not in('Active', 'Inactive', 'Overall likely to churn');
 		
 
 		SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
         
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `lyca_get_churn_prediction_segement_dtl_result` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `lyca_get_churn_prediction_segement_dtl_result`()
BEGIN
 		
        
         SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
         
         SELECT segement, 
 				SUM(IFNULL(customerCount, 0)) as customerCount, 
                 SUM(IFNULL(revenue, 0)) as revenue, 
                 SUM(IFNULL(APRU, 0)) as APRU
         FROM tb_lyca_churn_revenue_APRU
         WHERE segement NOT IN('Active', 'Inactive', 'Overall likely to churn')
 		GROUP BY segement;
         
         SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;        
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `lyca_get_count_customer_profile_360_module` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `lyca_get_count_customer_profile_360_module`()
begin
		
        set session transaction isolation level read uncommitted;

		SELECT COUNT(1) as Total FROM tb_lyca_customer_profile_360_module;

		set session transaction isolation level repeatable read;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `lyca_get_count_of_each_channel_category` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `lyca_get_count_of_each_channel_category`()
BEGIN

		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
		
        SELECT CHANNEL_CATEGORY, count(1) as TotalCount FROM 
         tb_lyca_unified_details t1 
         group by CHANNEL_CATEGORY;
			
        
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `lyca_get_count_recommendation_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `lyca_get_count_recommendation_details`(
)
begin
		set session transaction isolation level read uncommitted;
        SELECT count(1) from tb_lyca_recommendation_details;
        set session transaction isolation level repeatable read;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `lyca_get_customer_profile_average_spending` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `lyca_get_customer_profile_average_spending`(
	p_Sub_Acct_Id			INT
)
BEGIN

		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    
		SELECT monthwise_revenue_2025_01 as Jan, monthwise_revenue_2025_02 as Feb, monthwise_revenue_2025_03 as Mar
			, monthwise_revenue_2025_04 as Apr ,monthwise_revenue_2025_05 as May, monthwise_revenue_2025_06 as Jun
        FROM tb_lyca_customer_profile_360_module
        WHERE Sub_Acct_Id = p_Sub_Acct_Id;
    
    	SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
        
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `lyca_get_customer_profile_average_visits` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `lyca_get_customer_profile_average_visits`(
	p_Sub_Acct_Id			INT
)
BEGIN
		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        
			SELECT 	monthly_bundle_count2025_01,
					monthly_bundle_count2025_02,
                    monthly_bundle_count2025_03,
                    monthly_bundle_count2025_04,
                    monthly_bundle_count2025_05,
                    monthly_bundle_count2025_06
                    
            FROM tb_lyca_customer_profile_360_module
			WHERE Sub_Acct_Id = p_Sub_Acct_Id;
        
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `lyca_get_customer_profile_churn_risk` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `lyca_get_customer_profile_churn_risk`(
	p_Sub_Acct_Id			INT
)
BEGIN
		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        
			SELECT churn_risk_score FROM tb_lyca_customer_profile_360_module
			WHERE Sub_Acct_Id = p_Sub_Acct_Id;
        
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `lyca_get_customer_profile_CLV` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `lyca_get_customer_profile_CLV`(
	p_Sub_Acct_Id			INT
)
BEGIN

		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

		SELECT clv_score as ExpectedCLV, Average_revenue as Actual_CLV FROM tb_lyca_customer_profile_360_module
        WHERE Sub_Acct_Id = p_Sub_Acct_Id;

		SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `lyca_get_customer_profile_engagement_score` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `lyca_get_customer_profile_engagement_score`(
	p_Sub_Acct_Id			INT
)
BEGIN
		
        SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        
        SELECT Engagement_Score FROM tb_lyca_customer_profile_360_module
        WHERE Sub_Acct_Id = p_Sub_Acct_Id;
        
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
        
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `lyca_get_customer_profile_search_customer_id` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `lyca_get_customer_profile_search_customer_id`()
BEGIN

		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
			
          SELECT Sub_Acct_Id FROM tb_lyca_customer_profile_360_module;  
            
		SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `lyca_get_customer_profile_summary_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `lyca_get_customer_profile_summary_dtl`(p_Sub_Acct_Id  int)
BEGIN

		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
			
          SELECT t1.Sub_Acct_Id, t3.cluster_name, t1.location,  t1.summary, t1.SIM_TYPE,  t1.subscriber_type, t1.Account_validity_date,
					t1.voice_Total_Call_Duration,  t1.GPRS_Total_Used_Bytes , t1.total_number_of_sms , t1.network_usage ,
					t1.purchased_bundles
          FROM tb_lyca_customer_profile_360_module t1 
			JOIN tb_lyca_unified_details	t2  ON t1.Sub_Acct_Id = t2.sub_Acct_Id
            JOIN tb_lyca_cluster_definition_details	t3 ON t2.Cluster = t3.cluster_id 
          where t1.Sub_Acct_Id = p_Sub_Acct_Id;  
            
		SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `lyca_get_distribution_of_cvl_segements` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `lyca_get_distribution_of_cvl_segements`()
begin
		set session transaction isolation level read uncommitted;
        
        
        select CLV_Segment, count(1) as totalCount
			FROM tb_lyca_unified_details
        group by CLV_Segment;
        
        set session transaction isolation level repeatable read;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `lyca_get_distribution_of_NBO_segment` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `lyca_get_distribution_of_NBO_segment`()
BEGIN
		SELECT NBO_Segment, count(1) as totalCount 
        FROM tb_lyca_unified_details
        group by NBO_Segment;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `lyca_get_distribution_of_RFM_category` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `lyca_get_distribution_of_RFM_category`()
BEGIN
		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
			
            SELECT RFM_Category, count(1) as totalCount FROM 
				tb_lyca_unified_details
                GROUP BY RFM_Category;
                
          SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;      
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `lyca_get_monthwise_total_actual_bundle_cost_by_sim_type` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `lyca_get_monthwise_total_actual_bundle_cost_by_sim_type`(p_year		INT)
BEGIN

			SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
            
			SELECT SIM_TYPE, `Month` , SUM(Actual_Bundle_Cost) AS Actual_Bundle_Cost 
				FROM tb_lyca_topup_details 
				WHERE (`year` = p_year OR  `year`= 2025)
				GROUP BY SIM_TYPE, `Month` 
                ORDER BY SIM_TYPE , `Month`;
                
			SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
            
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `lyca_get_percentage_contribution_of_charges` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `lyca_get_percentage_contribution_of_charges`()
BEGIN		
			DECLARE v_totalMessageRev		FLOAT;
            DECLARE v_totalVoiceRev			FLOAT;
            DECLARE v_totalDateRev			FLOAT;
            DECLARE v_total					FLOAT;

		SELECT SUM(total_msg_cost), SUM(voice_Total_Talk_charge), SUM(GPRS_Total_Data_Charge_Used) 
				INTO  v_totalMessageRev, v_totalVoiceRev,v_totalDateRev
        FROM tb_lyca_unified_details;
        
        SET v_total = v_totalMessageRev + v_totalVoiceRev+ v_totalDateRev;
        
        SELECT 
			CASE WHEN IFNULL(v_total, 0) !=0  THEN ROUND((v_totalMessageRev/v_total)*100,2) ELSE 0 END AS message_charges,
            CASE WHEN IFNULL(v_total, 0) !=0  THEN ROUND((v_totalVoiceRev/v_total)*100,2) ELSE 0 END AS voice_charges,
            CASE WHEN IFNULL(v_total, 0) !=0  THEN ROUND((v_totalDateRev/v_total)*100,2) ELSE 0 END AS data_charges;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `lyca_get_recommendations_All_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `lyca_get_recommendations_All_details`(
		p_limit  int,
        p_offset int
)
BEGIN
		DECLARE v_offset  INT;
      
        
        SET v_offset = p_limit * p_offset;
        
        SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        
        SELECT COUNT(distinct recommendations) as TotalCount FROM tb_lyca_recommendation_details;
        
        SELECT recommendations, COUNT(sub_Acct_Id) as total_customer  
			FROM tb_lyca_recommendation_details 
            GROUP  BY recommendations 
            LIMIT v_offset, p_limit;
        
       SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `lyca_get_segmentation_based_on_customers` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `lyca_get_segmentation_based_on_customers`()
begin

		set session transaction isolation level read uncommitted;
		
        SELECT Cluster, count(sub_Acct_Id) as TotalCustomers, AVG(Total_amount) AS avgerage_revenue
			FROM tb_lyca_unified_details 
			group by Cluster order by 1;
        
        set session transaction isolation level repeatable read;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `lyca_get_segmentation_distribution_chart` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `lyca_get_segmentation_distribution_chart`()
begin

		set session transaction isolation level read uncommitted;
        
        select t2.cluster_name as Segments, SUM(t1.Total_amount) as TotalRevenue from tb_lyca_unified_details t1
        JOIN tb_lyca_cluster_definition_details t2 ON t1.Cluster = t2.cluster_id
        group by t2.cluster_name
        order by 1 
        ;
        
        set session transaction isolation level repeatable read;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `lyca_get_segmentation_targeted_experiences` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `lyca_get_segmentation_targeted_experiences`()
begin
			DECLARE v_activeCustomers		INT DEFAULT 0;
            DECLARE v_inactiveCustomers		INT DEFAULT 0;
			DECLARE v_totalCluster			INT DEFAULT 0;
            DECLARE v_totalComplaint		INT DEFAULT 0;		

			


            
            SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
            
           
            SELECT COUNT(distinct Cluster) INTO v_totalCluster FROM tb_lyca_unified_details;
            
            SELECT customerCount INTO v_activeCustomers FROM tb_lyca_churn_revenue_APRU WHERE segement = "Active";
            
             SELECT customerCount INTO v_inactiveCustomers FROM tb_lyca_churn_revenue_APRU WHERE segement = "Inactive";
            
            SELECT 0 INTO v_totalComplaint;
            
            
            SELECT  v_activeCustomers 				as Customers, 
					v_inactiveCustomers 			as inactiveCustomers, 
					v_totalCluster 					as Segment, 
					v_totalComplaint 				as Complaints;
            
            
           
            
            
            
            SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `lyca_get_total_revenue_per_customer_segement` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `lyca_get_total_revenue_per_customer_segement`()
BEGIN

			SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

			SELECT  cd.cluster_name, SUM(ud.Total_amount) as TotalRevenue 
            FROM tb_lyca_unified_details ud JOIN tb_lyca_cluster_definition_details cd ON ud.Cluster = cd.cluster_id 
             GROUP BY cd.cluster_name order by cd.cluster_name;
             
             SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
            
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `lyca_get_total_revenue_per_recharge_type` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `lyca_get_total_revenue_per_recharge_type`()
BEGIN
			SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
            
            SELECT rdd.recharge_name,  SUM(td.Actual_Bundle_Cost) AS revenue 
            FROM tb_lyca_topup_details td JOIN tb_lyca_recharge_definition_details rdd ON td.recharge_type = rdd.recharge_id
            GROUP BY rdd.recharge_name;
            
            SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `lyca_insert_customer_profile_360_module` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `lyca_insert_customer_profile_360_module`(

p_Sub_Acct_Id							int
,p_SIM_TYPE								varchar(20)
,p_CHANNEL_CATEGORY						varchar(20)
,p_voice_Total_Call_Duration			decimal(20,2)
,p_GPRS_Total_Used_Bytes				decimal(20,2)
,p_total_number_of_sms					int
,p_Account_validity_date				date
,p_summary								varchar(2000)
,p_network_usage						varchar(20)
,p_location								varchar(50)
,p_monthwise_revenue_2025_01			decimal(20,2)
,p_monthwise_revenue_2025_02			decimal(20,2)
,p_monthwise_revenue_2025_03			decimal(20,2)
,p_monthwise_revenue_2025_04			decimal(20,2)
,p_monthwise_revenue_2025_05			decimal(20,2)
,p_monthwise_revenue_2025_06			decimal(20,2)
,p_Average_revenue						decimal(20,2)
,p_purchased_bundles					varchar(130)
,p_monthly_bundle_count2025_01			decimal(20,2)
,p_monthly_bundle_count2025_02			decimal(20,2)
,p_monthly_bundle_count2025_03			decimal(20,2)
,p_monthly_bundle_count2025_04			decimal(20,2)
,p_monthly_bundle_count2025_05			decimal(20,2)
,p_monthly_bundle_count2025_06			decimal(20,2)
,p_churn_risk_score						decimal(20,2)
,p_clv_score							decimal(20,2)
,p_Engagement_Score						decimal(20,2)
,p_subscriber_type						varchar(20)
)
BEGIN

			declare v_errCode	int default 0;
            declare v_errMsg	varchar(50) default "failed";

		INSERT INTO tb_lyca_customer_profile_360_module(Sub_Acct_Id	,SIM_TYPE,CHANNEL_CATEGORY ,voice_Total_Call_Duration			
,GPRS_Total_Used_Bytes	,total_number_of_sms	,Account_validity_date	,summary ,network_usage	,location								
,monthwise_revenue_2025_01		,monthwise_revenue_2025_02		,monthwise_revenue_2025_03		,monthwise_revenue_2025_04			
,monthwise_revenue_2025_05		,monthwise_revenue_2025_06		,Average_revenue				,purchased_bundles					
,monthly_bundle_count2025_01	,monthly_bundle_count2025_02	,monthly_bundle_count2025_03	,monthly_bundle_count2025_04			
,monthly_bundle_count2025_05	,monthly_bundle_count2025_06	,churn_risk_score				,clv_score							
,Engagement_Score				,subscriber_type)	
values(p_Sub_Acct_Id	,p_SIM_TYPE			,p_CHANNEL_CATEGORY		,p_voice_Total_Call_Duration	,p_GPRS_Total_Used_Bytes				
		,p_total_number_of_sms		,p_Account_validity_date	,p_summary	,p_network_usage ,p_location								
		,p_monthwise_revenue_2025_01	,p_monthwise_revenue_2025_02 ,p_monthwise_revenue_2025_03	,p_monthwise_revenue_2025_04			
		,p_monthwise_revenue_2025_05	,p_monthwise_revenue_2025_06	,p_Average_revenue	,p_purchased_bundles					
		,p_monthly_bundle_count2025_01	,p_monthly_bundle_count2025_02	,p_monthly_bundle_count2025_03	,p_monthly_bundle_count2025_04			
		,p_monthly_bundle_count2025_05	,p_monthly_bundle_count2025_06	,p_churn_risk_score						
		,p_clv_score	,p_Engagement_Score	,p_subscriber_type);
        
        
        IF row_count() > 0 THEN 
				
                SET v_errCode = 0;
                SET v_errMsg = "Inserted Successfully";
        
		END IF;
        
        SELECT v_errCode as errCode, v_errMsg as errMsg;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `lyca_insert_recommendation_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `lyca_insert_recommendation_details`(p_sub_Acct_Id		INT,
p_recommendations		VARCHAR(150)
)
begin
		
        declare v_errMsg		VARCHAR(50) default "failed";
        declare v_errCode		int default -1;
        
        INSERT INTO tb_lyca_recommendation_details(sub_Acct_Id, recommendations)
		values(p_sub_Acct_Id, p_recommendations);
        
        IF row_count() > 0 THEN 
			set v_errMsg = "Inserted Successfully";
            set v_errCode = 0;
		END IF;
			
		SELECT v_errCode AS errCode, v_errMsg as errMsg;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `lyca_revenue_cost_sim_type` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `lyca_revenue_cost_sim_type`()
BEGIN
	SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;   
	SELECT 	SIM_TYPE
		,	SUM(Actual_Bundle_Cost)	 AS	user_count
	FROM 	tb_lyca_topup_details
    GROUP BY SIM_TYPE;
   	SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;          
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `lyca_user_count_sim_type` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `lyca_user_count_sim_type`()
BEGIN
	SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;   
	SELECT 	SIM_TYPE
		,	COUNT(1)		user_count
	FROM 	tb_lyca_unified_details
    GROUP BY SIM_TYPE;
   	SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;          
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `up_CVM_ClearBundlePurchase` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`javateam`@`%` PROCEDURE `up_CVM_ClearBundlePurchase`(p_CompanyId 	INT)
BEGIN
	DELETE 	FROM tb_CVMBundlePurchase
    WHERE 	CompanyId = p_CompanyId;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `up_CVM_ClearCustomer` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`javateam`@`%` PROCEDURE `up_CVM_ClearCustomer`(p_CompanyId 	INT)
BEGIN
	SET foreign_key_checks = 0;
    
    DELETE FROM tb_CVMCustomerTelecomDetail WHERE CompanyId = p_CompanyId;
    DELETE FROM tb_CVMCustomer WHERE CompanyId = p_CompanyId;
    
	SET foreign_key_checks = 1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `up_CVM_ClearTopUpPurchase` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`javateam`@`%` PROCEDURE `up_CVM_ClearTopUpPurchase`(p_CompanyId 	INT)
BEGIN
	DELETE 	FROM tb_CVMTopUpPurchase
    WHERE 	CompanyId = p_CompanyId;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `up_CVM_CountBundlePurchase` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`javateam`@`%` PROCEDURE `up_CVM_CountBundlePurchase`(p_CompanyId 	INT)
BEGIN
	SELECT COUNT(1)	FROM tb_CVMBundlePurchase WHERE CompanyId = p_CompanyId;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `up_CVM_CountTopUpPurchase` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`javateam`@`%` PROCEDURE `up_CVM_CountTopUpPurchase`(p_CompanyId 	INT)
BEGIN
	SELECT COUNT(1)	FROM tb_CVMTopUpPurchase WHERE CompanyId = p_CompanyId;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `up_CVM_dashboardCustomerRevenueMonthWise` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`javateam`@`%` PROCEDURE `up_CVM_dashboardCustomerRevenueMonthWise`(
    p_companyId		INT,
    p_CustomerId		BIGINT
  )
BEGIN
 	SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;  
 	DROP TEMPORARY TABLE IF EXISTS tt_Months;
 	CREATE TEMPORARY TABLE tt_Months(`Month`	TINYINT);    
 	INSERT INTO tt_Months(`Month`)
 	VALUES(1),(2),(3),(4),(5),(6),(7),(8),(9),(10),(11),(12); 
    
    DROP TEMPORARY TABLE IF EXISTS tt_AmountMonthWise;
 	CREATE TEMPORARY TABLE tt_AmountMonthWise(PurchaseMonth	TINYINT,Revenue	DECIMAL(15,2),NoOfTransaction SMALLINT);    
    
    INSERT INTO tt_AmountMonthWise(PurchaseMonth,Revenue,NoOfTransaction)
 	WITH CTE_TopUpPurchase AS (
  		SELECT	TP.PurchaseMonth	
  			,	SUM(TP.Amount)		AS Amount
            ,	COUNT(TP.Amount)			AS NoOfTransaction
  		FROM 	tb_CVMTopUpPurchase TP	
		WHERE 	TP.CustomerId = p_CustomerId         
        GROUP BY TP.PurchaseMonth	
  	),    
	CTE_BundlePurchase AS (
  		SELECT	BP.PurchaseMonth	
  			,	SUM(BP.Price)		AS Amount
            ,	COUNT(BP.Price)		AS NoOfTransaction
  		FROM  	tb_CVMBundlePurchase BP	
         WHERE 	BP.CustomerId = p_CustomerId 
         GROUP BY BP.PurchaseMonth	
  	)
     SELECT M.`Month`
 		,	IFNULL(TP.Amount,0) + IFNULL(BP.Amount,0) 	AS Revenue
        ,	IFNULL(TP.NoOfTransaction,0) + IFNULL(BP.NoOfTransaction,0)		AS NoOfTransaction
     FROM 	tt_Months				M
     LEFT JOIN CTE_TopUpPurchase	TP	ON TP.PurchaseMonth = M.`Month`
     LEFT JOIN CTE_BundlePurchase	BP	ON BP.PurchaseMonth = M.`Month`;       
     
     SELECT PurchaseMonth	AS `Month`
		,	Revenue
     FROM 	tt_AmountMonthWise;
     
     SELECT CASE WHEN SUM(NoOfTransaction) = 0 THEN 0 ELSE ROUND(SUM(Revenue)/SUM(NoOfTransaction),2) END AS AverageSpending 
     FROM 	tt_AmountMonthWise;
     
   	DROP TEMPORARY TABLE IF EXISTS tt_Months;
    DROP TEMPORARY TABLE IF EXISTS tt_AmountMonthWise;
 	SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ; 
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `up_CVM_dashboardNoOfPurchaseMonthWise` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`javateam`@`%` PROCEDURE `up_CVM_dashboardNoOfPurchaseMonthWise`(
    p_companyId		INT,
    p_CustomerId		BIGINT
  )
BEGIN
	DECLARE v_TotalTransaction		SMALLINT;
    DECLARE v_TotalMonths			SMALLINT;
    
 	SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;  
 	DROP TEMPORARY TABLE IF EXISTS tt_Months;
 	CREATE TEMPORARY TABLE tt_Months(`Month`	TINYINT);    
 	INSERT INTO tt_Months(`Month`)
 	VALUES(1),(2),(3),(4),(5),(6),(7),(8),(9),(10),(11),(12);
    
    DROP TEMPORARY TABLE IF EXISTS tt_NoOfPurchaseMonthWise;
 	CREATE TEMPORARY TABLE tt_NoOfPurchaseMonthWise(PurchaseMonth TINYINT,NoOfTransaction SMALLINT);    
    
	INSERT INTO tt_NoOfPurchaseMonthWise(PurchaseMonth,NoOfTransaction)
 	WITH CTE_TopUpPurchase AS (
  		SELECT	TP.PurchaseMonth	  			
            ,	COUNT(TP.Amount)	AS NoOfTransaction            
  		FROM 	tb_CVMTopUpPurchase TP	
		WHERE 	TP.CustomerId = p_CustomerId         
        GROUP BY TP.PurchaseMonth	
  	),    
	CTE_BundlePurchase AS (
  		SELECT	BP.PurchaseMonth	  			
            ,	COUNT(BP.Price)		AS NoOfTransaction
  		FROM  	tb_CVMBundlePurchase BP	
         WHERE 	BP.CustomerId = p_CustomerId 
         GROUP BY BP.PurchaseMonth	
  	)
     SELECT M.`Month` 		
        ,	IFNULL(TP.NoOfTransaction,0) + IFNULL(BP.NoOfTransaction,0)		AS NoOfTransaction        
     FROM 	tt_Months				M
     LEFT JOIN CTE_TopUpPurchase	TP	ON TP.PurchaseMonth = M.`Month`
     LEFT JOIN CTE_BundlePurchase	BP	ON BP.PurchaseMonth = M.`Month`; 
    
    SELECT 	PurchaseMonth	AS `Month` 
		,	NoOfTransaction
    FROM 	tt_NoOfPurchaseMonthWise;
    
    SELECT 	SUM(NoOfTransaction)
    INTO 	v_TotalTransaction
    FROM 	tt_NoOfPurchaseMonthWise;
    
    WITH CTE_DateRange AS (
		SELECT	MIN(PurchaseDate)	AS StartDate
			,	MAX(PurchaseDate)	AS EndDate
		FROM 	tb_CVMTopUpPurchase TP	
		WHERE 	TP.CustomerId = p_CustomerId 
        UNION
		SELECT	MIN(PurchaseDate) 	AS StartDate
			,	MAX(PurchaseDate)	AS EndDate
		FROM 	tb_CVMTopUpPurchase TP	
		WHERE 	TP.CustomerId = p_CustomerId  
    )
    SELECT 	TIMESTAMPDIFF(MONTH, MIN(StartDate), MAX(EndDate))
    INTO 	v_TotalMonths
    FROM 	CTE_DateRange;    
    
    SET v_TotalMonths = CASE WHEN v_TotalMonths = 0 THEN 1 ELSE v_TotalMonths END;
    
    SELECT ROUND(v_TotalTransaction/v_TotalMonths,2) AS AveragePurchase ;
        
 	DROP TEMPORARY TABLE IF EXISTS tt_Months;
    DROP TEMPORARY TABLE IF EXISTS tt_NoOfPurchaseMonthWise;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `up_CVM_dashboardTotalCLVForCustomer` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`javateam`@`%` PROCEDURE `up_CVM_dashboardTotalCLVForCustomer`(
   p_companyId		INT,
   p_CustomerId		BIGINT
 )
BEGIN
	DECLARE v_companyId			INT; 
    DECLARE v_expectedCLV		DECIMAL(10,2);
    DECLARE v_actualTopUpCLV	DECIMAL(15,2);
    DECLARE v_actualBundleCLV	DECIMAL(15,2);
    
	SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;      
	SELECT 	CLVSimple
    INTO 	v_expectedCLV
    FROM 	tb_CVMCustomerTelecomDetail 
    WHERE 	CustomerId 	= v_companyId
    AND 	companyId	= p_companyId;
    
    SELECT 	SUM(Price)
    INTO 	v_actualBundleCLV
    FROM 	tb_CVMBundlePurchase BP
    WHERE 	BP.CustomerId = p_CustomerId;
    
    SELECT 	SUM(Amount)
    INTO 	v_actualTopUpCLV
    FROM 	tb_CVMTopUpPurchase TP
    WHERE 	TP.CustomerId = p_CustomerId;    
    
    SELECT 	IFNULL(v_expectedCLV,0)										AS expectedCLV
		,	IFNULL(v_actualBundleCLV,0) + IFNULL(v_actualTopUpCLV,0)	AS actualCLV;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ; 
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `up_CVM_DeleteCustomerComplaintCount` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`javateam`@`%` PROCEDURE `up_CVM_DeleteCustomerComplaintCount`(
	p_CompanyId		INT	
  )
BEGIN
	DELETE FROM tb_CVMCustomerComplaint WHERE CompanyId = p_CompanyId;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `up_CVM_GetCustomerBasedOnChurn` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`javateam`@`%` PROCEDURE `up_CVM_GetCustomerBasedOnChurn`(
p_CompanyId			INT
,p_offset			SMALLINT	
,p_limit			INT 		
)
BEGIN
	DROP TEMPORARY TABLE IF EXISTS tt_CustomerIds;	
    CREATE TEMPORARY TABLE tt_CustomerIds(CustomerId	BIGINT);	

	INSERT INTO tt_CustomerIds
    SELECT 	CustomerId
    FROM 	tb_CVMCustomer	
    WHERE 	CompanyId 	= p_CompanyId
    AND 	Churn		= 1
    LIMIT p_offset, p_limit;

	INSERT INTO tt_CustomerIds
    SELECT 	CustomerId
    FROM 	tb_CVMCustomer	
    WHERE 	CompanyId 	= p_CompanyId
    AND 	Churn		= 0
    LIMIT p_offset, p_limit;    

	SELECT 	C.*,CT.* 
    FROM 	tt_CustomerIds				Cs	
    JOIN  	tb_CVMCustomer				C	ON Cs.CustomerId	= C.CustomerId
    JOIN 	tb_CVMCustomerTelecomDetail	CT	ON CT.CustomerId	= C.CustomerId;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `up_CVM_GetCustomerBasedOnNBOSegment` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`javateam`@`%` PROCEDURE `up_CVM_GetCustomerBasedOnNBOSegment`(
p_CompanyId			INT
,p_limit			INT
)
BEGIN
	WITH CTE_CustomerIds AS (
		SELECT 	CustomerId	
			,	row_number() over(PARTITION BY NBOSegment order by CustomerId) SlNo
		FROM 	tb_CVMCustomer	
		WHERE 	CompanyId 	= 0
	)
	SELECT 	C.*,CT.*
	FROM 	CTE_CustomerIds				NS
    JOIN  	tb_CVMCustomer				C	ON Cs.CustomerId	= C.CustomerId
    JOIN 	tb_CVMCustomerTelecomDetail	CT	ON CT.CustomerId	= C.CustomerId
	WHERE 	SlNo <= p_limit;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `up_CVM_GetCustomerComplaintCount` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`javateam`@`%` PROCEDURE `up_CVM_GetCustomerComplaintCount`(
	p_CompanyId		INT	
  )
BEGIN
	SELECT COUNT(1) AS TotalComplaint FROM tb_CVMCustomerComplaint WHERE CompanyId = p_CompanyId;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `up_CVM_GetCustomerComplaints` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `up_CVM_GetCustomerComplaints`(
 	p_CompanyId		INT,	
     p_offset		SMALLINT,
     p_limit			INT
   )
BEGIN
 	DECLARE v_offset		INT;
     
     SET v_offset = p_offset * p_limit;
     
 	DROP TEMPORARY TABLE IF EXISTS tt_CustomerComplaint;
	CREATE TEMPORARY TABLE tt_CustomerComplaint(
 		CustomerId		BIGINT,
 		CreatedDate		DATETIME,
		ComplaintCount	SMALLINT,
		LatestComplaint	VARCHAR(500)
     );
     
     INSERT INTO tt_CustomerComplaint(CustomerId,CreatedDate,ComplaintCount)
     SELECT CustomerId, MAX(CreatedDate), COUNT(1) 
     FROM 	tb_CVMCustomerComplaint
     WHERE 	CompanyId 	= p_CompanyId
     AND 	CustomerId	> 0
     GROUP BY CustomerId
     ORDER BY CustomerId 
     LIMIT v_offset, p_limit;
     
     UPDATE tt_CustomerComplaint	t_CC
     JOIN 	tb_CVMCustomerComplaint	CC	ON 	CC.CustomerId 	= t_CC.CustomerId
 										AND	CC.CreatedDate	= t_CC.CreatedDate
	 SET 	t_CC.LatestComplaint = CC.ComplaintName;    
     
     SELECT CONCAT(IFNULL(CONCAT(C.FirstName,' '),''),IFNULL(C.LastName,'')) AS CustomerName
 		,	t_CC.LatestComplaint
        ,	ComplaintCount
     FROM 	tt_CustomerComplaint	t_CC
     JOIN 	tb_CVMCustomer			C		ON C.CustomerId = t_CC.CustomerId
     WHERE 	ComplaintCount > 0;
     
     SELECT COUNT(DISTINCT CustomerId) 
     FROM 	tb_CVMCustomerComplaint
     WHERE 	CompanyId 	= p_CompanyId
     AND 	CustomerId	> 0;
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `up_CVM_GetLifeCycleTrendOverTime` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`javateam`@`%` PROCEDURE `up_CVM_GetLifeCycleTrendOverTime`(
   p_companyId	INT,
   p_startDate	DATE,
   p_endDate	DATE,
   p_NBOSegment	VARCHAR(20)
  )
BEGIN
  	DECLARE v_companyId		INT;
    DECLARE v_endDate		DATETIME;
      
 	SET v_companyId = IFNULL(p_companyId,0);
    SET v_endDate 	= CONCAT(p_endDate," 23:59:59");
      
  	SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;          
  	CALL up_CVM_MonthInterval(p_startDate,p_endDate);
     
	DROP TEMPORARY TABLE IF EXISTS tt_Months;
	CREATE TEMPORARY TABLE tt_Months(`Month`	TINYINT);    
	INSERT INTO tt_Months(`Month`)
	VALUES(1),(2),(3),(4),(5),(6),(7),(8),(9),(10),(11),(12);
    
    DROP TEMPORARY TABLE IF EXISTS tt_Customers;
    CREATE temporary TABLE tt_Customers 
    SELECT 	C.CustomerId FROM tb_CVMCustomer C
	WHERE 	C.CompanyId 	= v_companyId 
    AND		C.RollInDate 	BETWEEN p_startDate AND v_endDate
    AND 	(p_NBOSegment IS NULL OR C.NBOSegment = p_NBOSegment);
  
    WITH CTE_ActiveCustomer AS (
		SELECT 	`Month`
			,	SUM(isActive)	AS TotalActive
            ,	SUM(CASE WHEN isActive = 0 THEN 1 ELSE 0 END) AS TotalInActive
        FROM 	tb_CVM_CustomerMonthlyDetails	MD
        JOIN 	tt_Customers					t_C	ON t_C.CustomerId = MD.CustomerId
        WHERE 	MD.CompanyId = v_companyId
        GROUP BY `Month`
    ),      
    CTE_Churn AS (
		SELECT 	D.`Month`
			,	IFNULL(SUM(C.Churn),0)	AS TotalChurn			
		FROM 	tt_Date				D 	
		LEFT JOIN tb_CVMCustomer	C 	ON 	C.RollOutDate BETWEEN D.StartDate AND D.EndDate
										AND C.CompanyId	= v_companyId	
                                        AND (p_NBOSegment IS NULL OR C.NBOSegment = p_NBOSegment)	
		GROUP BY D.`Month`
    )
    SELECT 	M.`Month`
  		,	IFNULL(C.TotalChurn,0)		AS TotalChurn
        ,	IFNULL(AC.TotalActive,0)	AS TotalActive
        ,	IFNULL(AC.TotalInActive,0)	AS TotalInActive
    FROM 	tt_Months				M
    LEFT JOIN CTE_Churn				C	ON C.`Month` = M.`Month`
    LEFT JOIN CTE_ActiveCustomer	AC	ON AC.`Month` = M.`Month`    
 	ORDER BY M.`Month`; 
      
	DROP TEMPORARY TABLE IF EXISTS tt_Months;
	DROP TEMPORARY TABLE IF EXISTS tt_Date;
  	SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `up_CVM_GetRevenueDistributionByPaymentMode` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`javateam`@`%` PROCEDURE `up_CVM_GetRevenueDistributionByPaymentMode`(
 p_companyId	INT,
 p_fromDate		DATETIME,
 p_toDate		DATETIME,
 p_NBOSegment	VARCHAR(20)
)
BEGIN
	DECLARE v_companyId		INT;
	DECLARE v_toDate		DATETIME;
    DECLARE v_totalDays		SMALLINT;    

    SET v_companyId = IFNULL(p_companyId, 0);
	SET v_toDate 	= CONCAT(DATE(p_toDate)," 23:59:59");
    SET v_totalDays	= DATEDIFF(p_toDate,p_fromDate) + 1;
    
 	SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    DROP TEMPORARY TABLE IF EXISTS tt_Customers;
    CREATE temporary TABLE tt_Customers 
    SELECT 	CustomerId FROM tb_CVMCustomer
	WHERE 	CompanyId 	= v_companyId 
    AND		RollInDate 	BETWEEN p_fromDate AND v_toDate
    AND 	(p_NBOSegment IS NULL OR NBOSegment = p_NBOSegment);
    
	DROP TEMPORARY TABLE IF EXISTS tt_CustomersPayment;
    CREATE TEMPORARY TABLE tt_CustomersPayment(
		CustomerId		BIGINT	
		,PaymentMode	VARCHAR(100)
		,Amount			DECIMAL(15,2)
    );
    
    INSERT INTO tt_CustomersPayment(CustomerId,PaymentMode,Amount)
    SELECT 	C.CustomerId
		,	TP.PaymentType
		,	SUM(TP.Amount)     
	FROM 	tt_Customers	 	C
	JOIN 	tb_CVMTopUpPurchase TP ON TP.CustomerId = C.CustomerId 
	WHERE 	TP.PurchaseDate BETWEEN p_fromDate AND v_toDate
    GROUP BY C.CustomerId, TP.PaymentType;
    
    INSERT INTO tt_CustomersPayment(CustomerId,PaymentMode,Amount)
	SELECT 	C.CustomerId
		,	BP.PaymentMode
		,	SUM(BP.Price)     
	FROM 	tt_Customers	 		C
	JOIN 	tb_CVMBundlePurchase 	BP ON BP.CustomerId = C.CustomerId 
	WHERE 	BP.PurchaseDate BETWEEN p_fromDate AND v_toDate
    GROUP BY C.CustomerId, BP.PaymentMode;    
    
    SELECT 	CP.PaymentMode					 
		,	SUM(CP.Amount)					AS TotalRevenue
        ,	SUM(CP.Amount) / v_totalDays	AS AvgRevenuePerDay        
        ,	COUNT(DISTINCT CustomerId)		AS TotalUser        
        ,	SUM(CP.Amount) / COUNT(DISTINCT CustomerId)	AS AvgRevenuePerUser
    FROM 	tt_CustomersPayment CP
    GROUP BY CP.PaymentMode;
    
    DROP TEMPORARY TABLE IF EXISTS tt_Customers;
    DROP TEMPORARY TABLE IF EXISTS tt_CustomersPayment;    
   	SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `up_CVM_GetTotalCustomerMonthWise` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`javateam`@`%` PROCEDURE `up_CVM_GetTotalCustomerMonthWise`(
  p_companyId	INT,
  p_startDate	DATE,
  p_endDate		DATE
 )
BEGIN
 	DECLARE v_companyId		INT;
     
     SET v_companyId = IFNULL(p_companyId,0);
     
 	SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;          
 	CALL up_CVM_MonthInterval(p_startDate,p_endDate);
    
    DROP TEMPORARY TABLE IF EXISTS tt_Months;
    CREATE TEMPORARY TABLE tt_Months(`Month`	TINYINT);    
    INSERT INTO tt_Months(`Month`)
    VALUES(1),(2),(3),(4),(5),(6),(7),(8),(9),(10),(11),(12);      
     
 	SELECT 	M.`Month`
 		,	COUNT(C.CustomerId)		AS TotalCustomer
 	FROM 	tt_Months			M
    LEFT JOIN tt_Date			D 	ON D.`Month` = M.`Month`		
 	LEFT JOIN tb_CVMCustomer	C 	ON (D.StartDate BETWEEN C.RollInDate AND C.RollOutDate OR C.RollInDate BETWEEN D.StartDate AND D.EndDate)
									AND C.CompanyId	= v_companyId
    GROUP BY M.`Month`
    ORDER BY M.`Month`; 
     
	DROP TEMPORARY TABLE IF EXISTS tt_Months;
	DROP TEMPORARY TABLE IF EXISTS tt_Date;
	SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `up_CVM_InsertBundlePurchase` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`javateam`@`%` PROCEDURE `up_CVM_InsertBundlePurchase`(
  p_CompanyId			INT,
  p_MobileNo			VARCHAR(30),
  p_IccId				BIGINT,
  p_BundleId			INT,
  p_PurchaseDate		DATETIME,
  p_PurchaseYear		SMALLINT,
  p_PurchaseMonth		TINYINT,
  p_PurchaseDay			TINYINT,
  p_PurchaseHour		TINYINT,
  p_Price				DECIMAL(15,2),
  p_PaymentMode			VARCHAR(150)
  )
BEGIN
 	DECLARE v_CustomerId		BIGINT;
 	DECLARE v_BundlePurchaseId	BIGINT;
 	DECLARE v_Now				DATETIME DEFAULT NOW();
  	
 	SELECT 	CustomerId INTO v_CustomerId    
 	FROM 	tb_CVMCustomer
 	WHERE 	CompanyId	= p_CompanyId
 	AND 	MobileNo	= p_MobileNo;  

	INSERT INTO tb_CVMBundlePurchase(
		 CustomerId		
		  ,MobileNo
		  ,CompanyId			
		  ,IccId				
		  ,BundleId			
		  ,PurchaseDate		
		  ,PurchaseYear		
		  ,PurchaseMonth		
		  ,PurchaseDay			
		  ,PurchaseHour		
		  ,Price	
          ,PaymentMode
		  ,CreatedDate			
		  ,UpdatedDate
	)
	VALUES(
		v_CustomerId,
		p_MobileNo,
		p_CompanyId,
		p_IccId,			
		p_BundleId,		
		p_PurchaseDate,	
		p_PurchaseYear,
		p_PurchaseMonth,	
		p_PurchaseDay,	
		p_PurchaseHour,	
		p_Price,
        P_PaymentMode,
		v_Now,
		v_Now
	);  	
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `up_CVM_InsertCustomerComplaint` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`javateam`@`%` PROCEDURE `up_CVM_InsertCustomerComplaint`(
p_MobileNo			VARCHAR(30)
,p_CompanyId		INT
,p_FunctionName		VARCHAR(250)
,p_IssueName		VARCHAR(250)
,p_ComplaintName	VARCHAR(250)
,p_ComplaintDate	DATETIME 
)
BEGIN
 	DECLARE v_CustomerId		BIGINT; 	
 	DECLARE v_Now				DATETIME DEFAULT NOW();
  	
 	SELECT 	CustomerId INTO v_CustomerId    
 	FROM 	tb_CVMCustomer
 	WHERE 	CompanyId	= p_CompanyId
 	AND 	MobileNo	= p_MobileNo;
  
	INSERT INTO tb_CVMCustomerComplaint(
		CustomerId
		,MobileNo
		,CompanyId
		,FunctionName
		,IssueName
		,ComplaintName
		,ComplaintDate
		,CreatedDate	    
	)
	VALUES(
		v_CustomerId
		,p_MobileNo
		,p_CompanyId
		,p_FunctionName
		,p_IssueName
		,p_ComplaintName
		,p_ComplaintDate		
		,v_Now
	);  	

  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `up_CVM_InsertTopUpPurchase` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`javateam`@`%` PROCEDURE `up_CVM_InsertTopUpPurchase`(
 	 p_CompanyId			INT,
 	 p_MobileNo				VARCHAR(30),
 	 p_PaymentType			VARCHAR(100),
 	 p_Amount				DECIMAL(15,2),
 	 p_PurchaseDate			DATETIME,
 	 p_PurchaseYear			SMALLINT,
 	 p_PurchaseMonth		TINYINT,
 	 p_PurchaseDay			TINYINT,
 	 p_PurchaseHour			TINYINT,
 	 p_PreviousBalance		DECIMAL(15,2),
 	 p_AfterBalance			DECIMAL(15,2)
  )
BEGIN
 	DECLARE v_CustomerId		BIGINT; 	
 	DECLARE v_Now				DATETIME DEFAULT NOW();
  	
 	SELECT 	CustomerId INTO v_CustomerId    
 	FROM 	tb_CVMCustomer
 	WHERE 	CompanyId	= p_CompanyId
 	AND 	MobileNo	= p_MobileNo;
  
	INSERT INTO tb_CVMTopUpPurchase(
		CustomerId,	
		MobileNo,
		CompanyId,	             
		PaymentType,			
		Amount,				
		PurchaseDate,		
		PurchaseYear,		
		PurchaseMonth,		
		PurchaseDay,			
		PurchaseHour,		
		PreviousBalance,		
		AfterBalance,		
		CreatedDate,			
		UpdatedDate	
	)
	VALUES(
		v_CustomerId,
		p_MobileNo,
		p_CompanyId,
		p_PaymentType,			
		p_Amount,				
		p_PurchaseDate,		
		p_PurchaseYear,		
		p_PurchaseMonth,		
		p_PurchaseDay,			
		p_PurchaseHour,		
		p_PreviousBalance,		
		p_AfterBalance,	
		v_Now,
		v_Now
	);  	

  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `up_CVM_InsertUpdateCustomer` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `up_CVM_InsertUpdateCustomer`(
  p_MobileNo						VARCHAR(30),
  p_CompanyId						INT,
  p_IsActive						TINYINT,
  p_FirstName						VARCHAR(150),
  p_LastName						VARCHAR(150),	
  p_Email							VARCHAR(150),		
  p_City							VARCHAR(150),		
  p_Postcode						VARCHAR(10),		
  p_CountryCode						VARCHAR(10),		
  p_TenureDays						SMALLINT,
  p_RollInDate						DATETIME,
  p_RollOutDate						DATETIME,
  p_TopupCount						SMALLINT,
  p_TopupSum						INT,	
  p_TopupMean						DECIMAL(20,2),
  p_TopupMax						SMALLINT,
  p_FirstTopupDate					DATETIME,
  p_LastTopupDate					DATETIME,	
  p_TopupPeakHour					TINYINT,
  p_AvgTopupIntervalDays			DECIMAL(10,2),
  p_BundleCount						SMALLINT,
  p_BundleSumSpend					DECIMAL(20,2),
  p_BundleMeanSpend					DECIMAL(20,2),
  p_FirstBundleDate					DATETIME,
  p_LastBundleDate					DATETIME,
  p_FirstBundleId					SMALLINT,
  p_LastBundleId					SMALLINT,		
  p_FavoriteBundleIds				VARCHAR(100),
  p_BundlePeakHour					TINYINT,
  p_OverallSentimentWithCount		VARCHAR(15),
  p_CountComplain					SMALLINT,
  p_CountInquiry					SMALLINT,
  p_CountRequest					SMALLINT,
  p_DominantIssueTypeId				varchar(200),				
  p_TotalSpendAmount				INT,
  p_TopupPeakDayNum					TINYINT,
  p_BundlePeakDayNum				TINYINT,
  p_AvgBundleIntervalDays			DECIMAL(10,2),
  p_BundleIdCount					varchar(5000),						
  p_TenureMonths					DECIMAL(10,2),
  p_ARPUPerDays						DECIMAL(10,2),
  p_ARPUPerMonth						DECIMAL(10,2),
  p_CLVSimple						DECIMAL(10,2),
  p_LastActivityDate					DATETIME,	
  p_Recency							smallint,
  p_Frequency						smallint,
  p_Monetary							DECIMAL(10,2),
  p_R								tinyint,
  p_F								tinyint,
  p_M								tinyint,
  p_RFMScore						SMALLINT,
  p_PosSent							TINYINT,
  p_NegSent							TINYINT,
  p_NeuSent							TINYINT,
  p_NPSScoreProxy					TINYINT, 
  p_NPSCategory						VARCHAR(200),
  p_ARPUCategory					VARCHAR(200),					
  p_CLVCategory						VARCHAR(200),					
  p_RFMcategory						VARCHAR(200),	
  p_NBOSegment						VARCHAR(200),	
  p_NBAAction						VARCHAR(200),
  p_Churn							VARCHAR(100),
  p_UniqueBundles					VARCHAR(1000),
  p_ChannelType 					VARCHAR(25) 
  )
BEGIN
  	DECLARE v_CustomerId	BIGINT;
     DECLARE v_Now			DATETIME DEFAULT NOW();
     DECLARE v_Churn			TINYINT;     
 	DECLARE errno INT;
     
     DECLARE EXIT HANDLER FOR SQLEXCEPTION
     BEGIN
     GET CURRENT DIAGNOSTICS CONDITION 1 errno = MYSQL_ERRNO;
     SELECT errno AS MYSQL_ERROR;
     ROLLBACK;
     END;     
      
      SELECT CustomerId INTO v_CustomerId    
      FROM 	tb_CVMCustomer
      WHERE CompanyId	= p_CompanyId
      AND 	MobileNo	= p_MobileNo;
      
      SET v_Churn = CASE WHEN p_Churn = 'Churn' THEN 1 ELSE 0 END;
      
     START TRANSACTION;
  	IF v_CustomerId IS NULL
      THEN	
  		INSERT INTO tb_CVMCustomer(
  			MobileNo		
  			,CompanyId		
  			,IsActive		
  			,FirstName		
  			,LastName			
  			,Email					
  			,City					
  			,Postcode				
  			,CountryCode				
  			,TenureDays		
  			,RollInDate		
  			,RollOutDate		
  			,NPSCategory		
  			,ARPUCategory						
  			,CLVCategory							
  			,RFMcategory			
  			,NBOSegment			
  			,NBAAction	
            ,ChannelType
  			,Churn	
  			,CreatedDate
  			,UpdatedDate
  		)
          VALUES(
  			p_MobileNo		
              ,p_CompanyId		
              ,p_IsActive		
              ,p_FirstName		
              ,p_LastName		
              ,p_Email			
              ,p_City			
              ,p_Postcode		
              ,p_CountryCode	
              ,p_TenureDays		
              ,p_RollInDate		
              ,p_RollOutDate	
              ,p_NPSCategory	
              ,p_ARPUCategory	
              ,p_CLVCategory	
              ,p_RFMcategory	
              ,p_NBOSegment		
              ,p_NBAAction	
              ,p_ChannelType
              ,v_Churn	
			  ,v_Now
              ,v_Now
          );
          
          SET v_CustomerId = last_insert_id();
          
          INSERT INTO tb_CVMCustomerTelecomDetail(
  			CustomerId					
              ,CompanyId					
              ,TopupCount					
              ,TopupSum					
              ,TopupMean					
              ,TopupMax					
              ,FirstTopupDate				
              ,LastTopupDate				
              ,TopupPeakHour				
              ,AvgTopupIntervalDays		
              ,BundleCount					
              ,BundleSumSpend				
              ,BundleMeanSpend				
              ,FirstBundleDate				
              ,LastBundleDate				
              ,FirstBundleId				
              ,LastBundleId				
              ,FavoriteBundleIds			
              ,BundlePeakHour				
              ,OverallSentimentWithCount	
              ,CountComplain				
              ,CountInquiry				
              ,CountRequest				
              ,DominantIssueTypeId			
              ,TotalSpendAmount			
              ,TopupPeakDayNum				
              ,BundlePeakDayNum			
              ,AvgBundleIntervalDays		
              ,BundleIdCount					
              ,TenureMonths				
              ,ARPUPerDays					
              ,ARPUPerMonth				
              ,CLVSimple					
              ,LastActivityDate			
              ,Recency						
              ,Frequency					
              ,Monetary					
              ,R							
              ,F							
              ,M							
              ,RFMScore					
              ,PosSent						
              ,NegSent						
              ,NeuSent						
              ,NPSScoreProxy				
              ,UniqueBundles				
              ,CreatedDate					
              ,UpdatedDate					
          )
          VALUES(
  			v_CustomerId					
              ,p_CompanyId					
              ,p_TopupCount					
              ,p_TopupSum					
              ,p_TopupMean					
              ,p_TopupMax					
              ,p_FirstTopupDate				
              ,p_LastTopupDate				
              ,p_TopupPeakHour				
              ,p_AvgTopupIntervalDays		
              ,p_BundleCount					
              ,p_BundleSumSpend				
              ,p_BundleMeanSpend				
              ,p_FirstBundleDate				
              ,p_LastBundleDate				
              ,p_FirstBundleId				
              ,p_LastBundleId				
              ,p_FavoriteBundleIds			
              ,p_BundlePeakHour				
              ,p_OverallSentimentWithCount	
              ,p_CountComplain				
              ,p_CountInquiry				
              ,p_CountRequest				
              ,p_DominantIssueTypeId			
              ,p_TotalSpendAmount			
              ,p_TopupPeakDayNum				
              ,p_BundlePeakDayNum			
              ,p_AvgBundleIntervalDays		
              ,p_BundleIdCount					
              ,p_TenureMonths				
              ,p_ARPUPerDays					
              ,p_ARPUPerMonth				
              ,p_CLVSimple					
              ,p_LastActivityDate			
              ,p_Recency						
              ,p_Frequency					
              ,p_Monetary					
              ,p_R							
              ,p_F							
              ,p_M							
              ,p_RFMScore					
              ,p_PosSent						
              ,p_NegSent						
              ,p_NeuSent						
              ,p_NPSScoreProxy				
              ,p_UniqueBundles    
              ,v_Now
              ,v_Now
              );
 
      END IF;
      COMMIT;     
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `up_CVM_MonthInterval` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`javateam`@`%` PROCEDURE `up_CVM_MonthInterval`(
 p_startDate	DATE,
 p_endDate		DATE
)
BEGIN
	DECLARE v_SlNo		SMALLINT;
    DECLARE v_endDate	DATETIME DEFAULT CONCAT(p_endDate,' 23:59:59');
    
	DROP TEMPORARY TABLE IF EXISTS tt_Date;
    CREATE TEMPORARY TABLE tt_Date(
		SlNo			SMALLINT AUTO_INCREMENT PRIMARY KEY,
		StartDate		DATE,
        EndDate			DATETIME,
        `MonthName`		VARCHAR(20),
        `Month`			TINYINT
    );
    
    INSERT INTO tt_Date(StartDate,EndDate,`MonthName`,`Month`)
	WITH RECURSIVE CTE_DATE AS (
		SELECT p_startDate StartDate, CONCAT(LAST_DAY(p_startDate),' 23:59:59') EndDate, MONTHNAME(p_startDate) `MonthName`, Month(p_startDate)  AS 'Month'
		UNION ALL
		SELECT 	DATE_ADD(StartDate,INTERVAL 1 MONTH) StartDate, CONCAT(LAST_DAY(DATE_ADD(StartDate,INTERVAL 1 MONTH)),' 23:59:59') EndDate,
				MONTHNAME(DATE_ADD(StartDate,INTERVAL 1 MONTH)) `MonthName`, Month(DATE_ADD(StartDate,INTERVAL 1 MONTH)) AS 'Month'
		FROM 	CTE_DATE
		WHERE 	EndDate <=p_endDate
	)
    SELECT 	*
    FROM 	CTE_DATE;
    
    SELECT 	MAX(SlNo) INTO v_SlNo
    FROM 	tt_Date;
    
    UPDATE 	tt_Date
    SET 	EndDate = v_endDate
    WHERE 	SlNo 	= v_SlNo;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `up_CVM_SyncCustomerId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `up_CVM_SyncCustomerId`(p_CompanyId 	INT)
BEGIN
	UPDATE 	tb_CVMBundlePurchase	BP
    JOIN 	tb_CVMCustomer			C	ON 	C.MobileNo 	= BP.MobileNo
										AND C.CompanyId	= BP.CompanyId
	SET 	BP.CustomerId	= C.CustomerId
    WHERE 	C.CompanyId		= p_CompanyId;
    
	UPDATE 	tb_CVMTopUpPurchase	TP
    JOIN 	tb_CVMCustomer		C	ON 	C.MobileNo 	= TP.MobileNo
									AND C.CompanyId	= TP.CompanyId
	SET 	TP.CustomerId	= C.CustomerId
    WHERE 	C.CompanyId		= p_CompanyId;    
    
	UPDATE 	tb_CVMCustomerComplaint	CC
    JOIN 	tb_CVMCustomer			C	ON 	C.MobileNo 	= CC.MobileNo
										AND C.CompanyId	= CC.CompanyId
	SET 	CC.CustomerId	= C.CustomerId
    WHERE 	C.CompanyId		= p_CompanyId;        
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `up_CVM_UpdateCustomerMonthlyDetails` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`javateam`@`%` PROCEDURE `up_CVM_UpdateCustomerMonthlyDetails`(p_companyId	INT, p_startDate	DATE,p_endDate	DATE)
SP: BEGIN	   		
    DECLARE v_endDateTime	DATETIME DEFAULT CONCAT(p_endDate,' 23:59:59');       
       
   	SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;          
   	CALL up_CVM_MonthInterval(p_startDate,p_endDate);

	DROP TEMPORARY TABLE IF EXISTS tt_Customers;
    CREATE TEMPORARY TABLE tt_Customers(CustomerId	BIGINT, startDate	DATETIME,endDate DATETIME,`Month` TINYINT, isActive	TINYINT DEFAULT 0);
     
 	INSERT INTO tt_Customers(CustomerId,startDate,endDate,`Month`)	
    SELECT 	C.CustomerId
		,	D.StartDate       
        ,	D.EndDate        
        ,	D.`Month`
	FROM 	tb_CVMCustomer	C
    JOIN 	tt_Date			D
    LEFT JOIN tb_CVM_CustomerMonthlyDetails	CM 	ON 	CM.CustomerId	= C.CustomerId
												AND CM.CompanyId	= C.CompanyId	
												AND	CM.StartDate	= D.StartDate
	WHERE 	C.CompanyId 	= p_companyId
	AND 	C.RollInDate 	BETWEEN p_startDate AND v_endDateTime
    AND 	CM.CustomerId IS NULL;
    
    INSERT INTO tb_CVM_CustomerMonthlyDetails(CustomerId,CompanyId,startDate,endDate,`Month`)
    SELECT CustomerId,p_companyId,startDate,endDate,`Month` FROM tt_Customers;
    
     WITH CTE_Customer AS (
 		SELECT 	C.CustomerId
 			,	C.startDate
 			,	C.`Month`
 			,	MAX(TP.PurchaseDate)	AS PurchaseDate
 		FROM 	tt_Customers		C
 		JOIN 	tb_CVMTopUpPurchase TP	ON 	TP.CustomerId 	= C.CustomerId
 										AND	TP.PurchaseDate	<= C.startDate	
         GROUP BY C.CustomerId,	C.startDate, C.`Month`
 	)
     UPDATE tb_CVM_CustomerMonthlyDetails	t_C
     JOIN 	CTE_Customer	C_C	ON 	C_C.CustomerId 	= t_C.CustomerId
 								AND	C_C.`Month`		= t_C.`Month`
                                AND C_C.startDate	= t_C.startDate
     SET 	isActive		= 1
     WHERE 	DATEDIFF(PurchaseDate,C_C.startDate) <= 120;	
     
     WITH CTE_Customer AS (
 		SELECT 	C.CustomerId
 			,	C.startDate
 			,	C.`Month`
 			,	MAX(BP.PurchaseDate)	AS PurchaseDate
 		FROM 	tt_Customers1			C
 		JOIN 	tb_CVMBundlePurchase 	BP	ON 	BP.CustomerId 	= C.CustomerId
 											AND	BP.PurchaseDate	<= C.startDate	
         GROUP BY C.CustomerId,	C.startDate, C.`Month`
 	)
     UPDATE tb_CVM_CustomerMonthlyDetails	t_C
     JOIN 	CTE_Customer	C_C	ON 	C_C.CustomerId 	= t_C.CustomerId
 								AND	C_C.`Month`		= t_C.`Month`
 								AND C_C.startDate	= t_C.startDate
     SET 	isActive		= 1
     WHERE 	isActive		= 0
     AND 	DATEDIFF(PurchaseDate,C_C.startDate) <= 120;     
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-21  9:31:26
