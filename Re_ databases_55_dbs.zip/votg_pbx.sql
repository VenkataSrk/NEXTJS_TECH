-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: votg_pbx
-- ------------------------------------------------------
-- Server version	8.0.44-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `votg_pbx`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `votg_pbx` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `votg_pbx`;

--
-- Table structure for table `VOTG_DID_NUMBER_POOL`
--

DROP TABLE IF EXISTS `VOTG_DID_NUMBER_POOL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `VOTG_DID_NUMBER_POOL` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `COUNTRY` varchar(150) DEFAULT NULL,
  `CITY` varchar(150) DEFAULT NULL,
  `DID_NUMBER` varchar(20) NOT NULL,
  `AMOUNT` float DEFAULT NULL,
  `STATUS` int DEFAULT NULL,
  `DIR_USER_ID` int DEFAULT NULL,
  `REG_SITECODE` varchar(5) DEFAULT NULL,
  `REG_MSISDN` varchar(20) DEFAULT NULL,
  `REG_BY` varchar(20) DEFAULT NULL,
  `REG_DATE` datetime(3) DEFAULT NULL,
  `COUNTRY_CODE` varchar(5) DEFAULT NULL,
  `operator_id` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`DID_NUMBER`),
  UNIQUE KEY `ID` (`ID`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=1212 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `VOTG_DID_NUMBER_REGISTER`
--

DROP TABLE IF EXISTS `VOTG_DID_NUMBER_REGISTER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `VOTG_DID_NUMBER_REGISTER` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `reg_mobileno` varchar(20) NOT NULL,
  `account_info` varchar(20) DEFAULT NULL,
  `reg_sitecode` varchar(3) DEFAULT NULL,
  `dir_user_id` int DEFAULT NULL,
  `amount` float DEFAULT NULL,
  `paymode` int DEFAULT NULL,
  `reg_date` datetime(3) DEFAULT NULL,
  `reg_by` varchar(50) DEFAULT NULL,
  `exp_date` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`reg_mobileno`),
  UNIQUE KEY `ID` (`ID`),
  KEY `IDX1_VOTG_DID_NUMBER_REGISTER` (`account_info`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=1133 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `VOTG_VIRTUAL_NUMBER_POOL`
--

DROP TABLE IF EXISTS `VOTG_VIRTUAL_NUMBER_POOL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `VOTG_VIRTUAL_NUMBER_POOL` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `MUNDIO_COUNTRY` varchar(150) DEFAULT NULL,
  `MUNDIO_SITECODE` varchar(5) DEFAULT NULL,
  `COUNTRY_PREFIX` varchar(10) DEFAULT NULL,
  `MUNDIO_NUMBER` varchar(20) NOT NULL,
  `AMOUNT` float DEFAULT NULL,
  `STATUS` int DEFAULT NULL,
  `DIR_USER_ID` int DEFAULT NULL,
  `REG_SITECODE` varchar(5) DEFAULT NULL,
  `REG_MSISDN` varchar(20) DEFAULT NULL,
  `REG_BY` varchar(20) DEFAULT NULL,
  `REG_DATE` datetime(3) DEFAULT NULL,
  `COUNTRY_CODE` varchar(5) DEFAULT NULL,
  `VEC_USER` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`MUNDIO_NUMBER`),
  UNIQUE KEY `ID` (`ID`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=63695 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `VOTG_VIRTUAL_NUMBER_POOL_remove_num_log`
--

DROP TABLE IF EXISTS `VOTG_VIRTUAL_NUMBER_POOL_remove_num_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `VOTG_VIRTUAL_NUMBER_POOL_remove_num_log` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `MUNDIO_COUNTRY` varchar(150) DEFAULT NULL,
  `MUNDIO_SITECODE` varchar(5) DEFAULT NULL,
  `COUNTRY_PREFIX` varchar(10) DEFAULT NULL,
  `MUNDIO_NUMBER` varchar(20) DEFAULT NULL,
  `AMOUNT` float DEFAULT NULL,
  `STATUS` int DEFAULT NULL,
  `DIR_USER_ID` int DEFAULT NULL,
  `REG_SITECODE` varchar(5) DEFAULT NULL,
  `REG_MSISDN` varchar(20) DEFAULT NULL,
  `REG_BY` varchar(20) DEFAULT NULL,
  `REG_DATE` datetime(3) DEFAULT NULL,
  `COUNTRY_CODE` varchar(5) DEFAULT NULL,
  `VEC_USER` int DEFAULT NULL,
  `removeddate` datetime(3) DEFAULT NULL,
  `REG_MSISDN_from` varchar(50) DEFAULT NULL,
  `REG_MSISDN_to` varchar(50) DEFAULT NULL,
  UNIQUE KEY `ID` (`ID`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `VOTG_VIRTUAL_NUMBER_REGISTER`
--

DROP TABLE IF EXISTS `VOTG_VIRTUAL_NUMBER_REGISTER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `VOTG_VIRTUAL_NUMBER_REGISTER` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `reg_mobileno` varchar(20) NOT NULL,
  `account_info` varchar(20) DEFAULT NULL,
  `reg_sitecode` varchar(3) DEFAULT NULL,
  `dir_user_id` int DEFAULT NULL,
  `amount` float DEFAULT NULL,
  `paymode` int DEFAULT NULL,
  `reg_date` datetime(3) DEFAULT NULL,
  `reg_by` varchar(50) DEFAULT NULL,
  `default_map_cli` int DEFAULT NULL,
  `is_free` int NOT NULL DEFAULT '0',
  `exp_date` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`reg_mobileno`),
  UNIQUE KEY `ID` (`ID`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=42981 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `didportal_vectoneapp_recycle_master_log_table`
--

DROP TABLE IF EXISTS `didportal_vectoneapp_recycle_master_log_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `didportal_vectoneapp_recycle_master_log_table` (
  `uid` int NOT NULL AUTO_INCREMENT,
  `ani` varchar(50) DEFAULT NULL,
  `sitecode` varchar(10) DEFAULT NULL,
  `countryid` varchar(10) DEFAULT NULL,
  `lastCalldate` datetime(3) DEFAULT NULL,
  `currentdate` datetime(3) DEFAULT NULL,
  `lastactive_duration` int DEFAULT NULL,
  `balance` varchar(10) DEFAULT NULL,
  `recycle_startdate` datetime(3) DEFAULT NULL,
  `recycle_enddate` datetime(3) DEFAULT NULL,
  `recycle_status` varchar(30) DEFAULT NULL,
  `reassign_to_mainpooldate` datetime(3) DEFAULT NULL,
  `lastactive_from_main_pool` int DEFAULT NULL,
  UNIQUE KEY `uid` (`uid`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=38814 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `votg_linkedservers`
--

DROP TABLE IF EXISTS `votg_linkedservers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `votg_linkedservers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sitecode` varchar(3) DEFAULT NULL,
  `db_type` varchar(5) DEFAULT NULL,
  `linkedserver` varchar(30) DEFAULT NULL,
  `route_fwd_prefix` varchar(25) DEFAULT NULL,
  `route_call_prefix` varchar(25) DEFAULT NULL,
  `routing_id` int DEFAULT NULL,
  `aut_minlevel_id` int DEFAULT NULL,
  `sms_relay` varchar(20) DEFAULT NULL,
  `did_price` float DEFAULT NULL,
  UNIQUE KEY `id` (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping events for database 'votg_pbx'
--

--
-- Dumping routines for database 'votg_pbx'
--
/*!50003 DROP PROCEDURE IF EXISTS `didportal_vectoneapp_get_remove_number_list` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `didportal_vectoneapp_get_remove_number_list`(country_id INT,  
mobilenofrom VARCHAR(50) ,  
mobilenoto VARCHAR(50))
BEGIN
 
   DECLARE v_sitecode VARCHAR(20);  
   DECLARE v_errcode INT;   
   DECLARE v_errmsg VARCHAR(250);
   DECLARE Swv_RowCount INT;  
   
   sp_exit : BEGIN
   
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select   sitecode INTO v_sitecode FROM crm3.country_code  WHERE COUNTRY_NUMBER = country_id    LIMIT 1;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
      
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select ID as Reg_no,MUNDIO_NUMBER as xtra_number,'VECTONE' as operator,MUNDIO_COUNTRY as country,status
      from VOTG_VIRTUAL_NUMBER_POOL where mundio_sitecode = v_sitecode and country_prefix = country_id
      and (MUNDIO_NUMBER between mobilenofrom and mobilenoto or ((IFNULL(mobilenofrom,'') = '') or IFNULL(mobilenoto,'') = ''));
      
      SET Swv_RowCount = found_rows();
      
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
      
      IF Swv_RowCount > 0 
      then 
         set v_errcode = 0;
         set v_errmsg = 'Numbers found.';
         LEAVE sp_exit;
      end if;
      
   END;
   select v_errcode as errcode,v_errmsg as errmsg;  
   
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `didportal_vectoneapp_remove_numbers_pool_list_from_to` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `didportal_vectoneapp_remove_numbers_pool_list_from_to`(country_id INT,  
mobilenofrom VARCHAR(50),  
mobilenoto VARCHAR(50))
BEGIN

   DECLARE v_sitecode VARCHAR(20);  
   DECLARE v_errcode INT;   
   DECLARE v_errmsg VARCHAR(250);  
   
   sp_exit:BEGIN
   
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select   sitecode INTO v_sitecode FROM crm3.country_code WHERE COUNTRY_NUMBER = country_id    LIMIT 1;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   
   if not exists(select  1 from VOTG_VIRTUAL_NUMBER_POOL where MUNDIO_NUMBER between mobilenofrom and mobilenoto
      and mundio_sitecode = v_sitecode and country_prefix = country_id LIMIT 1) 
      then 
         set v_errcode = -1;
         set v_errmsg = 'No numbers found.';
         LEAVE sp_exit;
      end if;
     
     if exists(select  1 from VOTG_VIRTUAL_NUMBER_POOL where MUNDIO_NUMBER between mobilenofrom and mobilenoto
      and mundio_sitecode = v_sitecode and country_prefix = country_id and REG_MSISDN is not null LIMIT 1) 
      then 
         set v_errcode = -1;
         set v_errmsg = 'Number already mapped to other user. unable to delete.';
         LEAVE sp_exit;
         
      ELSE
      
         SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
         insert into VOTG_VIRTUAL_NUMBER_POOL_remove_num_log(MUNDIO_COUNTRY,MUNDIO_SITECODE, COUNTRY_PREFIX,MUNDIO_NUMBER,AMOUNT,
         STATUS,DIR_USER_ID,REG_SITECODE,REG_MSISDN,REG_BY,REG_DATE,COUNTRY_CODE,VEC_USER,removeddate)
         
         select MUNDIO_COUNTRY,MUNDIO_SITECODE, COUNTRY_PREFIX,MUNDIO_NUMBER,AMOUNT,STATUS,DIR_USER_ID,REG_SITECODE,REG_MSISDN,
		 REG_BY,REG_DATE,COUNTRY_CODE,VEC_USER,CURRENT_TIMESTAMP from VOTG_VIRTUAL_NUMBER_POOL
         where MUNDIO_NUMBER between mobilenofrom and mobilenoto and reg_msisdn is null and status in(0,1)
         and mundio_sitecode = v_sitecode;
         SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
         
         delete from VOTG_VIRTUAL_NUMBER_POOL  where mundio_number between mobilenofrom and mobilenoto and status in(0,1) 
         and REG_MSISDN is null limit 10 ;
         
         IF found_rows() > 0 
         then  
            set v_errcode = 0;
            set v_errmsg = 'Numbers range deleted.';
            LEAVE sp_exit;
         end if;
         
      end if;
   END;
   select v_errcode as errcode,v_errmsg as errmsg;  
   
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `didportal_vectoneapp_remove_number_list` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `didportal_vectoneapp_remove_number_list`(country_id INT,  
mobilenofrom VARCHAR(50),  
mobilenoto VARCHAR(50),  
processtype INT 
)
SWL_return : BEGIN
  
   DECLARE v_errcode INT;   
   DECLARE v_errmsg VARCHAR(250);  
    
   IF IFNULL(country_id,'') = '' or country_id is null 
   then  
      set v_errcode = -1;
      set v_errmsg = 'Mandatory country id.';
      LEAVE SWL_return;
   end if;  
  
    
   IF IFNULL(mobilenofrom,'') = '' or mobilenofrom is null 
   then   
      set v_errcode = -1;
      set v_errmsg = 'mobilenofrom is mandatory.';
      LEAVE SWL_return;
   end if;  
     
   IF IFNULL(mobilenoto,'') = '' or mobilenoto is null 
   then   
      set v_errcode = -1;
      set v_errmsg = 'Mandatory country id.';
      LEAVE SWL_return;
   end if;  
  
   IF processtype = 1 
   then  
      CALL didportal_vectoneapp_get_remove_number_list(country_id,mobilenofrom,mobilenoto);
   ELSE 
      
      IF processtype = 2 
      then  
         CALL didportal_vectoneapp_remove_number_pool(country_id,mobilenofrom);
         
      ELSE 
      
         IF processtype = 3 
         then  
            CALL didportal_vectoneapp_remove_numbers_pool_list_from_to(country_id,mobilenofrom,mobilenoto);
         end if;
      end if;
   end if;  
  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `didportal_vectoneapp_remove_number_pool` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `didportal_vectoneapp_remove_number_pool`(country_id INT,  
 mobileno VARCHAR(50))
BEGIN
 
    DECLARE v_sitecode VARCHAR(20);  
    DECLARE v_errcode INT;   
    DECLARE v_errmsg VARCHAR(250);  
    
    sp_exit : BEGIN
    
       SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
       select   sitecode INTO v_sitecode FROM crm3.country_code  WHERE COUNTRY_NUMBER = country_id    LIMIT 1;
       SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
       
       if not exists(select  1 from VOTG_VIRTUAL_NUMBER_POOL where mundio_number = mobileno LIMIT 1) 
       then 
          set v_errcode = -1;
          set v_errmsg = 'No numbers found.';
          LEAVE sp_exit;
       end if;
       
       IF exists(select  1 from VOTG_VIRTUAL_NUMBER_POOL where mundio_number = mobileno
       and status in(0,1) and mundio_sitecode = v_sitecode and REG_MSISDN is not null LIMIT 1) 
       then 
          set v_errcode = -1;
          set v_errmsg = 'Number already mapped to other user. unable to delete.';
          LEAVE sp_exit;
          
       ELSE
       
          SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
          insert into VOTG_VIRTUAL_NUMBER_POOL_remove_num_log(MUNDIO_COUNTRY,MUNDIO_SITECODE, COUNTRY_PREFIX,MUNDIO_NUMBER,
          AMOUNT,STATUS,DIR_USER_ID,REG_SITECODE,REG_MSISDN,REG_BY,REG_DATE,COUNTRY_CODE,VEC_USER,removeddate)
          
          select MUNDIO_COUNTRY,MUNDIO_SITECODE, COUNTRY_PREFIX,MUNDIO_NUMBER,AMOUNT,STATUS,DIR_USER_ID,REG_SITECODE,REG_MSISDN,
 		 REG_BY,REG_DATE,COUNTRY_CODE,VEC_USER,CURRENT_TIMESTAMP from VOTG_VIRTUAL_NUMBER_POOL where mundio_number = mobileno
          and REG_MSISDN is  null and status in(0,1) and mundio_sitecode = v_sitecode;
          SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
          
          delete from VOTG_VIRTUAL_NUMBER_POOL  where mundio_number = `mobileno` and status in(0,1) and REG_MSISDN is  null;
          
          IF found_rows() > 0 
          then  
             set v_errcode = 0;
             set v_errmsg = 'Numbers deleted successfully.';
             LEAVE sp_exit;
          end if;
       end if;
    END;
    select v_errcode as errcode,v_errmsg as errmsg;  
    
    
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `vectoneapp_dashboard_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `vectoneapp_dashboard_details`(country_id VARCHAR(5),  
Date_range_from VARCHAR(50),  
Date_range_to VARCHAR(50))
BEGIN 
  
   DECLARE v_Sitecode VARCHAR(50);  
   DECLARE v_COUNTRY_NAME VARCHAR(50);     
   DECLARE v_Tot_nos INT DEFAULT 0;  
   DECLARE v_Used INT DEFAULT 0;  
   DECLARE v_Recycle INT DEFAULT 0;  
   DECLARE v_Unused INT DEFAULT 0;   
   
  
   IF Date_range_from is null 
   then
      set Date_range_from = '';
   END IF;
   
   IF Date_range_to is null 
   then
      set Date_range_to = '';
   END IF;
   
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   sitecode, COUNTRY_NAME INTO v_Sitecode,v_COUNTRY_NAME from crm3.country_code where COUNTRY_NUMBER = country_id;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
    
 
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   COUNT(*) INTO v_Tot_nos from VOTG_VIRTUAL_NUMBER_POOL where status in(0,1)
   and MUNDIO_SITECODE = v_Sitecode
   and COUNTRY_PREFIX = country_id
   and ((Date_range_from = '') or (REG_DATE >= Date_range_from) or (Date_range_from is null))
   and ((Date_range_to = '') or (REG_DATE <= Date_range_to) or (Date_range_to is null));
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
      
 
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   COUNT(*) INTO v_Used from VOTG_VIRTUAL_NUMBER_POOL a 
   join didportal_vectoneapp_recycle_master_log_table b 
   on a.mundio_number = b.ani
   and a.MUNDIO_SITECODE = b.sitecode where a.MUNDIO_SITECODE = v_Sitecode
   and a.COUNTRY_PREFIX = country_id
   and b.lastactive_duration  >= 30;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
    
 
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select count(*) INTO v_Recycle from VOTG_VIRTUAL_NUMBER_POOL a 
   join didportal_vectoneapp_recycle_master_log_table b 
   on a.mundio_number = b.ani
   and a.MUNDIO_SITECODE = b.sitecode where a.MUNDIO_SITECODE = v_Sitecode
   and a.COUNTRY_PREFIX = country_id
   and ((Date_range_from = '') or (recycle_startdate >= Date_range_from) or (Date_range_from is null))
   and ((Date_range_to = '') or (recycle_enddate <= Date_range_to) or (Date_range_to is null));
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;   
    
 
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   COUNT(*) INTO v_Unused from VOTG_VIRTUAL_NUMBER_POOL  where status in(0)
   and MUNDIO_SITECODE = v_Sitecode
   and COUNTRY_PREFIX = country_id
   and ((Date_range_from = '') or (REG_DATE >= Date_range_from) or (Date_range_from is null))
   and ((Date_range_to = '') or (REG_DATE <= Date_range_to) or (Date_range_to is null));
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;   
   
   
   select v_Tot_nos as Total_purchased_numbers,v_Used as Total_inactive_Used_numbers,
   v_Recycle as Total_numbers_in_Recycling,v_Unused as Total_Unused_numbers;  
   
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `vectoneapp_get_stock_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `vectoneapp_get_stock_details`(
 	operator_id INT,  
 	country_id VARCHAR(5)
 )
BEGIN
    
     DECLARE v_Sitecode VARCHAR(50);  
     DECLARE v_COUNTRY_NAME VARCHAR(50);     
     DECLARE v_Tot_nos INT DEFAULT 0;  
     DECLARE v_Used INT DEFAULT 0;  
     DECLARE v_Recycle INT DEFAULT 0;  
     DECLARE v_Unused INT DEFAULT 0;   
     
     if (operator_id is null or operator_id = '') then set operator_id = 0; end if;
           
    
     SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
     select a.sitecode, a.COUNTRY_NAME INTO v_Sitecode,v_COUNTRY_NAME from crm3.country_code a where a.COUNTRY_NUMBER = country_id limit 1;
     SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
          
   
     SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
     select COUNT(*) INTO v_Tot_nos from VOTG_VIRTUAL_NUMBER_POOL a where a.status in(0,1)
     and a.MUNDIO_SITECODE = v_Sitecode
     and a.COUNTRY_PREFIX = country_id;
     SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
    
   
     SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
     select COUNT(*) INTO v_Used from VOTG_VIRTUAL_NUMBER_POOL a where a.status = 1
     and a.MUNDIO_SITECODE = v_Sitecode
     and a.COUNTRY_PREFIX = country_id;
     SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
     
   
     SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
     select count(*) INTO v_Recycle from didportal_vectoneapp_recycle_master_log_table a 
     join VOTG_VIRTUAL_NUMBER_POOL b 
     on a.ani = b.mundio_number where a.recycle_status in('in progress','active')
     and b.MUNDIO_SITECODE = v_Sitecode
     and b.COUNTRY_PREFIX = country_id;
     SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
          
   
     SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
     select COUNT(*) INTO v_Unused from VOTG_VIRTUAL_NUMBER_POOL a where a.status in(0)
     and a.MUNDIO_SITECODE = v_Sitecode
     and a.COUNTRY_PREFIX = country_id;
     SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
     
     
     select 'Vectone' as Operator_name,v_COUNTRY_NAME as COUNTRY_NAME,v_Tot_nos as Tot_nos,
     v_Used as Used,v_Recycle as Recycle,v_Unused as Unused;  
     
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `vectoneapp_get_stock_details_result_to_file` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `vectoneapp_get_stock_details_result_to_file`(
 operator_id int,
 country_id varchar(5)
 )
sp_return : BEGIN
 
 	Declare Sitecode varchar(50);
 	Declare COUNTRY_NAME varchar(50);
 	
 	Declare Tot_nos int;
 	Declare Used int;
 	Declare Recycle int;
 	Declare Unused int;
 
 	set Tot_nos = 0;
 	set Used = 0;
 	set Recycle = 0;
 	set Unused = 0;
 	
 		
 		select a.SITECODE,a.COUNTRY_NAME into sitecode, COUNTRY_NAME 
 		from crm3.country_code a
 		where a.COUNTRY_NUMBER = country_id;
 		
 		drop temporary TABLE if exists NUMBER_POOL_TEMP;
 		CREATE temporary TABLE NUMBER_POOL_TEMP
 		(
 			MUNDIO_COUNTRY varchar(150),
 			MUNDIO_SITECODE varchar(5),
 			COUNTRY_PREFIX varchar(10),
 			MUNDIO_NUMBER varchar(20),
 			AMOUNT float,
 			STATUS Varchar(10),
 			REG_MSISDN varchar(20),
 			REG_SITECODE varchar(5),
 			COUNTRY_CODE varchar(5)
 		);
 		
 		
 		
                
 			
 			call reporting.VOTG_virtual_numbers_for_recycle;
 				
 			if exists(select * from reporting.temp_recycle_log limit 1) then
 				update reporting.temp_recycle_log a set a.recycle_start_date = current_timestamp, a.recycle_end_date = DATE_ADD(current_timestamp, INTERVAL 30 day);
 			else
 				leave sp_return;
 			end if;
 				
 			drop temporary TABLE if exists temp2;
 			create temporary table temp2
 			(
 				mobileno varchar(10)
 			);
 
 				insert into temp2(mobileno)
 				select a.mobileno 
 				from reporting.temp_recycle_log a  
 				join VOTG_VIRTUAL_NUMBER_POOL b  
 				on a.mobileno = b.MUNDIO_NUMBER
 				where a.MUNDIO_SITECODE = sitecode
 				and a.COUNTRY_PREFIX = country_id;
 
 		
 		
 		Insert into NUMBER_POOL_TEMP (MUNDIO_COUNTRY,MUNDIO_SITECODE,COUNTRY_PREFIX,MUNDIO_NUMBER,AMOUNT,STATUS,REG_MSISDN,REG_SITECODE,COUNTRY_CODE)
 		select a.MUNDIO_COUNTRY,a.MUNDIO_SITECODE,a.COUNTRY_PREFIX,a.MUNDIO_NUMBER,a.AMOUNT,
 				CASE WHEN a.STATUS = 1 THEN 'USED' 
 					 WHEN a.STATUS = 0 THEN 'UNUSED' END STATUS,ifnull(a.REG_MSISDN,''),sitecode REG_SITECODE,a.COUNTRY_CODE
 		from VOTG_VIRTUAL_NUMBER_POOL a
 		where a.status in (0,1)
 		and a.MUNDIO_SITECODE = sitecode
 		and a.COUNTRY_PREFIX = country_id; 
 		
 		update NUMBER_POOL_TEMP a
 		left join temp2 b
 		on a.MUNDIO_NUMBER = b.mobileno
 		set a.status = 'RECYCLE'
 		where a.MUNDIO_SITECODE = sitecode
 		and a.COUNTRY_PREFIX = country_id; 
 		
 		select * from NUMBER_POOL_TEMP;
 		
 		drop temporary table if exists temp2;
 	
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `vectoneapp_inactive_used_nos_details_reports` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `vectoneapp_inactive_used_nos_details_reports`(country_id VARCHAR(5),  
Date_range_from VARCHAR(50),  
Date_range_to VARCHAR(50))
BEGIN

   DECLARE v_errcode INT;   
   DECLARE v_errmsg VARCHAR(250);  
   DECLARE v_order_id VARCHAR(20) DEFAULT null;
   DECLARE v_COUNTRY_NAME VARCHAR(65);  
   DECLARE v_Sitecode VARCHAR(50);  
   DECLARE v_linkedserver VARCHAR(1000);  
   DECLARE v_linksrv VARCHAR(1000);  
   DECLARE v_sql_qry LONGTEXT;  
    
  
   sp_exit:BEGIN
   
      IF Date_range_from is null 
      then
         set Date_range_from = '';
      END IF;
      
      IF Date_range_to is null 
      then
         set Date_range_to = '';
      END IF;
      
      set v_errcode = -1;
      set v_errmsg = 'Failure to get details.';
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select   sitecode, COUNTRY_NAME INTO v_Sitecode,v_COUNTRY_NAME FROM crm3.country_code  
      WHERE COUNTRY_NUMBER = country_id    LIMIT 1;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
      
      IF v_Sitecode IS NULL 
      then   
         SET v_errcode = -1;
         SET v_errmsg  = 'Unable to fetch sitecode';
         LEAVE sp_exit;
      end if;  
      
 
      
      IF (v_order_id IS NOT NULL) and (v_order_id <> '') 
      then 
         set v_order_id = replace(v_order_id,'vt_ext_','');
      end if;
      
      Drop TEMPORARY table IF EXISTS tt_temp_sms_xtrapp_imsi_mapping;
      create TEMPORARY table tt_temp_sms_xtrapp_imsi_mapping
      (
         id INT,
         msisdn VARCHAR(20),
         imsi VARCHAR(20),
         sms_relay VARCHAR(25),
         status INT,
         create_date DATETIME(3),
         main_msisdn VARCHAR(20),
         exp_date DATETIME(3)
      );
      
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select   linkedserver INTO v_linksrv from votg_linkedservers where sitecode = v_Sitecode and db_type = 'MVNO'    LIMIT 1;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
      
      set v_linkedserver = CONCAT_WS('','hlrdb.','sms_xtrapp_imsi_mapping');
      
      if v_linkedserver is null 
      then 
         set v_errcode = -1;
         set v_errmsg = 'internal configuration error.';
         LEAVE sp_exit;
      end if;
      
      set v_sql_qry =CONCAT( 'select * from ',  v_linkedserver);
      SET @SWV_Stmt = CONCAT_WS('','insert into tt_temp_sms_xtrapp_imsi_mapping ',v_sql_qry);
      PREPARE SWT_Stmt FROM @SWV_Stmt;
      EXECUTE SWT_Stmt;
      DEALLOCATE PREPARE SWT_Stmt;
      
      DROP TEMPORARY TABLE IF EXISTS tt_temp5;      
      CREATE TEMPORARY TABLE tt_temp5 AS select a.ani as Xtra_Number,IFNULL(c.account_info,'') as reg_mobileno,a.recycle_startdate,
  a.recycle_enddate,a.reassign_to_mainpooldate,CONCAT('vt_ext_',c.id) AS order_id,
  b.create_date as Purchased_Date,a.lastactive_duration as inactive_duration
 
         from didportal_vectoneapp_recycle_master_log_table a
         join tt_temp_sms_xtrapp_imsi_mapping b  
         on a.ani = b.msisdn
         join VOTG_VIRTUAL_NUMBER_REGISTER c 
         on c.reg_mobileno = b.msisdn
         where a.countryid = left(a.ani,2)
         and countryid = country_id
         and a.lastactive_duration > 20;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
      
      IF v_Sitecode = 'MBE' 
      then 
         SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
         select(CONCAT(IFNULL(d.firstname,''),' ',IFNULL(d.lastname,'')))  as Customername,
    a.reg_mobileno,a.order_id, a.Xtra_Number,'FREE' Number_type,a.Purchased_Date,'VECTONE' as Operator_name,
    v_COUNTRY_NAME as Country,a.inactive_duration
         from tt_temp5 a
         left join esp.mvno_account b 
         on a.Xtra_Number = b.mobileno
         left join crm.freesim c 
         on b.iccid = c.iccid
         left join crm.subscriber d 
         on c.subscriberid = d.subscriberid
         where b.mobileno is not null;
         SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;   
  
    
         set v_errcode = 0;
         set v_errmsg = 'Success to get the sitecode info.';
         LEAVE sp_exit;
         
      ELSE 
      
         IF v_Sitecode = 'MCM' 
         then 
            SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
            select(CONCAT(IFNULL(d.firstname,''),' ',IFNULL(d.lastname,'')))  as Customername,
    a.reg_mobileno,a.order_id, a.Xtra_Number,'FREE' Number_type,a.Purchased_Date,'VECTONE' as Operator_name,
    v_COUNTRY_NAME as Country,a.inactive_duration
            from tt_temp5 a
            left join esp.mvno_account b 
            on a.Xtra_Number = b.mobileno
            left join crm.freesim c 
            on b.iccid = c.iccid
            left join crm.subscriber d 
            on c.subscriberid = d.subscriberid
            where b.mobileno is not null;
            SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;   
  
    
            set v_errcode = 0;
            set v_errmsg = 'Success to get the sitecode info.';
            LEAVE sp_exit;
            
         ELSE 
         
            IF v_Sitecode = 'BAU' 
            then 
               SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
               select(CONCAT(IFNULL(d.firstname,''),' ',IFNULL(d.lastname,'')))  as Customername,
    a.reg_mobileno,a.order_id, a.Xtra_Number,'FREE' Number_type,a.Purchased_Date,'VECTONE' as Operator_name,
    v_COUNTRY_NAME as Country,a.inactive_duration
               from tt_temp5 a
               left join esp.mvno_account b 
               on a.Xtra_Number = b.mobileno
               left join crm.freesim c 
               on b.iccid = c.iccid
               left join crm.subscriber d 
               on c.subscriberid = d.subscriberid
               where b.mobileno is not null;
               SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;   
  
    
               set v_errcode = 0;
               set v_errmsg = 'Success to get the sitecode info.';
               LEAVE sp_exit;
               
            ELSE 
            
               IF v_Sitecode = 'MFR' 
               then 
                  SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
                  select(CONCAT(IFNULL(d.firstname,''),' ',IFNULL(d.lastname,'')))  as Customername,
    a.reg_mobileno,a.order_id, a.Xtra_Number,'FREE' Number_type,a.Purchased_Date,'VECTONE' as Operator_name,
    v_COUNTRY_NAME as Country,a.inactive_duration
                  from tt_temp5 a
                  left join esp.mvno_account b 
                  on a.Xtra_Number = b.mobileno
                  left join crm.freesim c 
                  on b.iccid = c.iccid
                  left join crm.subscriber d 
                  on c.subscriberid = d.subscriberid
                  where b.mobileno is not null;
                  SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;   
  
    
                  set v_errcode = 0;
                  set v_errmsg = 'Success to get the sitecode info.';
                  LEAVE sp_exit;
                  
               ELSE
               
                  set v_errcode = -1;
                  set v_errmsg = 'Failure to get sitecode details.';
                  LEAVE sp_exit;
               end if;
               
            end if;
         end if;
      end if;            
      
   END;
   select v_errcode as errcode,v_errmsg as errmsg;  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `vectoneapp_orders_history_search` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `vectoneapp_orders_history_search`(
       order_id VARCHAR(20),  
       country_id VARCHAR(5),  
       Date_range_from VARCHAR(50),  
       Date_range_to VARCHAR(50))
BEGIN
         
          DECLARE v_COUNTRY_NAME VARCHAR(65);  
          DECLARE v_Sitecode VARCHAR(50);  
          DECLARE v_linkedserver longtext;  
          DECLARE v_linksrv longtext;  
          DECLARE v_sql_qry LONGTEXT;  
          DECLARE v_errcode INT;  
          DECLARE v_errmsg VARCHAR(250);  
          declare v_out_varchar_handle varchar(125) default '';
          declare v_Number_type_handle varchar(125) default  'FREE';
          declare v_Operator_name_handle varchar(125) default  'Vectone';
             
          sp_exit:BEGIN
          
             if order_id = ''
             then
             set order_id = null;
             end if;
             
             IF Date_range_from is null 
             then
                set Date_range_from = '';
             END IF;
             
             IF Date_range_to is null 
             then
                set Date_range_to = '';
             END IF;
             
             set v_errcode = -1;
             set v_errmsg = 'Failure to get details.';
    
             
             SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
             select   sitecode, COUNTRY_NAME INTO v_Sitecode,v_COUNTRY_NAME FROM 
             crm3.country_code WHERE COUNTRY_NUMBER = country_id    LIMIT 1;
             SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
             
             IF v_Sitecode IS NULL 
             then   
                SET v_errcode = -1;
                SET v_errmsg  = 'Unable to fetch sitecode';
                LEAVE sp_exit;
             end if;
             
             Drop TEMPORARY table IF EXISTS tt_temp_sms_xtrapp_imsi_mapping;
             create TEMPORARY table tt_temp_sms_xtrapp_imsi_mapping
             (
                id INT,
                msisdn VARCHAR(20),
                imsi VARCHAR(20),
                sms_relay VARCHAR(25),
                status INT,
                create_date DATETIME(3),
                main_msisdn VARCHAR(20),
                exp_date DATETIME(3)
             );
             
             SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
            
            
             SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
             
             set v_linkedserver = CONCAT_WS('hlrdb.','sms_xtrapp_imsi_mapping');
             
             if v_linkedserver is null 
             then 
                set v_errcode = -1;
                set v_errmsg = 'internal configuration error.';
                LEAVE sp_exit;
             end if;
             
             insert into tt_temp_sms_xtrapp_imsi_mapping
             select id ,msisdn ,imsi ,sms_relay ,status ,create_date ,main_msisdn ,exp_date from hlrdb.sms_xtrapp_imsi_mapping;
    
             IF (order_id IS NOT NULL) and (order_id <> '') 
             then 
                set order_id = replace(order_id,'vt_ext_','');
             end if;  
    
    	SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
          
          DROP TEMPORARY TABLE IF EXISTS tt_temp2;
          
          CREATE TEMPORARY TABLE tt_temp2 AS 
          select IFNULL(account_info,v_out_varchar_handle) as reg_mobileno,   
          cast(a.ID as CHAR(10)) as order_id,
          IFNULL(reg_mobileno,v_out_varchar_handle) as Xtra_Number,
          b.create_date as Purchased_Date,
          v_Operator_name_handle as Operator_name,v_COUNTRY_NAME as COUNTRY_NAME 
                from VOTG_VIRTUAL_NUMBER_REGISTER a 
                join tt_temp_sms_xtrapp_imsi_mapping b  
                on a.reg_mobileno = b.msisdn
                and ((Date_range_from = '') or (b.create_date >= Date_range_from) 
                or (Date_range_from is null))
                and ((Date_range_to = '') or (b.create_date <= Date_range_to) 
                or (Date_range_to is null))
                and ((IFNULL(order_id,v_out_varchar_handle) = '') or (a.ID = order_id));
             SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;            
 
             IF v_Sitecode = 'MBE' 
             then
        
                SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
                select(CONCAT(IFNULL(d.firstname,v_out_varchar_handle),' ',IFNULL(d.lastname,v_out_varchar_handle)))  
                as Customername,
    		   a.reg_mobileno,
    		   CONCAT('vt_ext_',order_id) AS order_id,
    		   IFNULL(a.Xtra_Number,v_out_varchar_handle) as Xtra_Number,
    		   v_Number_type_handle Number_type,
    		   a.Purchased_Date,
    		   IFNULL(a.Operator_name,v_out_varchar_handle) as Operator_name,
    		   a.COUNTRY_NAME as Country
                from tt_temp2 a
                left join esp.mvno_account b 
                on a.reg_mobileno = b.mobileno
                left join crm.freesim c 
                on b.iccid = c.iccid
                left join crm.subscriber d 
                on c.subscriberid = d.subscriberid
                where b.mobileno is not null
                and d.subscriberid is not null;
                SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
                
                
                set v_errcode = 0;
                set v_errmsg = 'Success to get the sitecode info.';
                LEAVE sp_exit;
          
             ELSE 
        
                IF v_Sitecode = 'MCM' 
                then
        
                   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
                   select(CONCAT(IFNULL(d.firstname,v_out_varchar_handle),' ',IFNULL(d.lastname,v_out_varchar_handle)))  
                   as Customername,
    			   a.reg_mobileno,
    			   CONCAT('vt_ext_',order_id) AS order_id,
    			   IFNULL(a.Xtra_Number,v_out_varchar_handle) as Xtra_Number,
    			   v_Number_type_handle as Number_type,
    			   a.Purchased_Date,
    			   IFNULL(a.Operator_name,'') as Operator_name,
    			   a.COUNTRY_NAME as Country
                   from tt_temp2 a
                   left join esp.mvno_account b 
                   on a.reg_mobileno = b.mobileno
                   left join crm.freesim c 
                   on b.iccid = c.iccid
                   left join crm.subscriber d 
                   on c.subscriberid = d.subscriberid;
                  
                  
                   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
    
                   set v_errcode = 0;
                   set v_errmsg = 'Success to get the sitecode info.';
                   LEAVE sp_exit;
              
                ELSE 
                
                   IF v_Sitecode = 'BAU' 
                   then
        
                      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
                      select(CONCAT(IFNULL(d.firstname,v_out_varchar_handle),' ',IFNULL(d.lastname,v_out_varchar_handle)))  
                      as Customername,
    				   a.reg_mobileno,
    				   CONCAT('vt_ext_',order_id) AS order_id,
    				   IFNULL(a.Xtra_Number,v_out_varchar_handle) as Xtra_Number,
    				   v_Number_type_handle as Number_type,
    				   a.Purchased_Date,
    				   IFNULL(a.Operator_name,v_out_varchar_handle) as Operator_name,
    				   a.COUNTRY_NAME as Country
                      from tt_temp2 a
                      left join esp.mvno_account b 
                      on a.reg_mobileno = b.mobileno
                      left join crm.freesim c 
                      on b.iccid = c.iccid
                      left join crm.subscriber d 
                      on c.subscriberid = d.subscriberid
                      where b.mobileno is not null
                      and d.subscriberid is not null;
                      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
                      
                      
                      set v_errcode = 0;
                      set v_errmsg = 'Success to get the sitecode info.';
                      LEAVE sp_exit;
                      
                   ELSE 
                   
                      IF v_Sitecode = 'MFR' 
                      then
        
                         SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
                         select(CONCAT(IFNULL(d.firstname,v_out_varchar_handle),' ',IFNULL(d.lastname,v_out_varchar_handle)))  
                         as Customername,
    				   a.reg_mobileno,
    				   CONCAT('vt_ext_',order_id) AS order_id,
    				   IFNULL(a.Xtra_Number,v_out_varchar_handle) as Xtra_Number,
    				   v_Number_type_handle as Number_type,
    				   a.Purchased_Date,
    				   IFNULL(a.Operator_name,v_out_varchar_handle) as Operator_name,
    				   a.COUNTRY_NAME as Country
                         from tt_temp2 a
                         left join esp.mvno_account b 
                         on a.reg_mobileno = b.mobileno
                         left join crm.freesim c 
                         on b.iccid = c.iccid
                         left join crm.subscriber d 
                         on c.subscriberid = d.subscriberid
                         where b.mobileno is not null
                         and d.subscriberid is not null;
                         SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
                         
                         
                         set v_errcode = 0;
                         set v_errmsg = 'Success to get the sitecode info.';
                         LEAVE sp_exit;
                         
                      ELSE
                      
                         set v_errcode = -1;
                         set v_errmsg = 'Failure to get sitecode details.';
                         LEAVE sp_exit;
                      end if;
                   end if;
                end if;
             end if;
                   
          END;
          select v_errcode as errcode,v_errmsg as errmsg;  
       END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `vectoneapp_orders_history_search_1` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `vectoneapp_orders_history_search_1`(
   order_id VARCHAR(20),  
   country_id VARCHAR(5),  
   Date_range_from VARCHAR(50),  
   Date_range_to VARCHAR(50))
BEGIN
     
      DECLARE v_COUNTRY_NAME VARCHAR(65);  
      DECLARE v_Sitecode VARCHAR(50);  
      DECLARE v_linkedserver longtext;  
      DECLARE v_linksrv longtext;  
      DECLARE v_sql_qry LONGTEXT;  
      DECLARE v_errcode INT;  
      DECLARE v_errmsg VARCHAR(250);  
         
      sp_exit:BEGIN
      
         if order_id = ''
         then
         set order_id = null;
         end if;
         
         IF Date_range_from is null 
         then
            set Date_range_from = '';
         END IF;
         
         IF Date_range_to is null 
         then
            set Date_range_to = '';
         END IF;
         
         set v_errcode = -1;
         set v_errmsg = 'Failure to get details.';
         
         SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
         select   sitecode, COUNTRY_NAME INTO v_Sitecode,v_COUNTRY_NAME FROM 
         crm3.country_code WHERE COUNTRY_NUMBER = country_id    LIMIT 1;
         SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
         
         IF v_Sitecode IS NULL 
         then   
            SET v_errcode = -1;
            SET v_errmsg  = 'Unable to fetch sitecode';
            LEAVE sp_exit;
         end if;
         
         Drop TEMPORARY table IF EXISTS tt_temp_sms_xtrapp_imsi_mapping;
         create TEMPORARY table tt_temp_sms_xtrapp_imsi_mapping
         (
            id INT,
            msisdn VARCHAR(20),
            imsi VARCHAR(20),
            sms_relay VARCHAR(25),
            status INT,
            create_date DATETIME(3),
            main_msisdn VARCHAR(20),
            exp_date DATETIME(3)
         );
         
         SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
         select linkedserver INTO v_linksrv from votg_linkedservers  
         where sitecode = v_Sitecode and db_type = 'MVNO'LIMIT 1;
         SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;			
         
         set v_linkedserver = CONCAT_WS('','hlrdb.','sms_xtrapp_imsi_mapping');
         
         if v_linkedserver is null 
         then 
            set v_errcode = -1;
            set v_errmsg = 'internal configuration error.';
            LEAVE sp_exit;
         end if;
         
 		 set v_sql_qry =CONCAT( 'select * from ',  v_linkedserver);
         SET @SWV_Stmt = CONCAT_WS('insert into tt_temp_sms_xtrapp_imsi_mapping ',v_sql_qry);
         PREPARE SWT_Stmt FROM @SWV_Stmt;
         EXECUTE SWT_Stmt;
         DEALLOCATE PREPARE SWT_Stmt;  
      
      
    
         
         IF (order_id IS NOT NULL) and (order_id <> '') 
         then 
            set order_id = replace(order_id,'vt_ext_','');
         end if;  
      
    
              
         SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      
      DROP TEMPORARY TABLE IF EXISTS tt_temp2;
      CREATE TEMPORARY TABLE tt_temp2 AS 
      select IFNULL(account_info,'') as reg_mobileno,   
      cast(a.ID as CHAR(10)) as order_id,
      IFNULL(reg_mobileno,'') as Xtra_Number,
      b.create_date as Purchased_Date,
      'Vectone' as Operator_name,v_COUNTRY_NAME as COUNTRY_NAME 
            from VOTG_VIRTUAL_NUMBER_REGISTER a 
            join tt_temp_sms_xtrapp_imsi_mapping b  
            on a.reg_mobileno = b.msisdn
            and ((Date_range_from = '') or (b.create_date >= Date_range_from) 
            or (Date_range_from is null))
            and ((Date_range_to = '') or (b.create_date <= Date_range_to) 
            or (Date_range_to is null))
            and ((IFNULL(order_id,'') = '') or (a.ID = order_id));
            
         SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
         
         IF v_Sitecode = 'MBE' 
         then
    
            SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
            select(CONCAT(IFNULL(d.firstname,''),' ',IFNULL(d.lastname,'')))  
            as Customername,
       a.reg_mobileno,
       CONCAT('vt_ext_',order_id) AS order_id,
       IFNULL(a.Xtra_Number,'') as Xtra_Number,
       'FREE' Number_type,
       a.Purchased_Date,
       IFNULL(a.Operator_name,'') as Operator_name,
       a.COUNTRY_NAME as Country
            from tt_temp2 a
            left join esp.mvno_account b 
            on a.reg_mobileno = b.mobileno
            left join crm.freesim c 
            on b.iccid = c.iccid
            left join crm.subscriber d 
            on c.subscriberid = d.subscriberid
            where b.mobileno is not null
            and d.subscriberid is not null;
            SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
            
            
            set v_errcode = 0;
            set v_errmsg = 'Success to get the sitecode info.';
            LEAVE sp_exit;
            
         ELSE 
         
            IF v_Sitecode = 'MCM' 
            then
    
               SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
               select(CONCAT(IFNULL(d.firstname,''),' ',IFNULL(d.lastname,'')))  
               as Customername,
       a.reg_mobileno,
       CONCAT('vt_ext_',order_id) AS order_id,
       IFNULL(a.Xtra_Number,'') as Xtra_Number,
       'FREE' Number_type,
       a.Purchased_Date,
       IFNULL(a.Operator_name,'') as Operator_name,
       a.COUNTRY_NAME as Country
               from tt_temp2 a
               left join esp.mvno_account b 
               on a.reg_mobileno = b.mobileno
               left join crm.freesim c 
               on b.iccid = c.iccid
               left join crm.subscriber d 
               on c.subscriberid = d.subscriberid
               where b.mobileno is not null
               and d.subscriberid is not null;
               SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
               
               
               set v_errcode = 0;
               set v_errmsg = 'Success to get the sitecode info.';
               LEAVE sp_exit;
               
            ELSE 
            
               IF v_Sitecode = 'BAU' 
               then
    
                  SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
                  select(CONCAT(IFNULL(d.firstname,''),' ',IFNULL(d.lastname,'')))  
                  as Customername,
       a.reg_mobileno,
       CONCAT('vt_ext_',order_id) AS order_id,
       IFNULL(a.Xtra_Number,'') as Xtra_Number,
       'FREE' Number_type,
       a.Purchased_Date,
       IFNULL(a.Operator_name,'') as Operator_name,
       a.COUNTRY_NAME as Country
                  from tt_temp2 a
                  left join esp.mvno_account b 
                  on a.reg_mobileno = b.mobileno
                  left join crm.freesim c 
                  on b.iccid = c.iccid
                  left join crm.subscriber d 
                  on c.subscriberid = d.subscriberid
                  where b.mobileno is not null
                  and d.subscriberid is not null;
                  SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
                  
                  
                  set v_errcode = 0;
                  set v_errmsg = 'Success to get the sitecode info.';
                  LEAVE sp_exit;
                  
               ELSE 
               
                  IF v_Sitecode = 'MFR' 
                  then
    
                     SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
                     select(CONCAT(IFNULL(d.firstname,''),' ',IFNULL(d.lastname,'')))  
                     as Customername,
       a.reg_mobileno,
       CONCAT('vt_ext_',order_id) AS order_id,
       IFNULL(a.Xtra_Number,'') as Xtra_Number,
       'FREE' Number_type,
       a.Purchased_Date,
       IFNULL(a.Operator_name,'') as Operator_name,
       a.COUNTRY_NAME as Country
                     from tt_temp2 a
                     left join esp.mvno_account b 
                     on a.reg_mobileno = b.mobileno
                     left join crm.freesim c 
                     on b.iccid = c.iccid
                     left join crm.subscriber d 
                     on c.subscriberid = d.subscriberid
                     where b.mobileno is not null
                     and d.subscriberid is not null;
                     SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
                     
                     
                     set v_errcode = 0;
                     set v_errmsg = 'Success to get the sitecode info.';
                     LEAVE sp_exit;
                     
                  ELSE
                  
                     set v_errcode = -1;
                     set v_errmsg = 'Failure to get sitecode details.';
                     LEAVE sp_exit;
                  end if;
               end if;
            end if;
         end if;
               
      END;
      select v_errcode as errcode,v_errmsg as errmsg;  
   END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `vectoneapp_orders_history_search_2` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `vectoneapp_orders_history_search_2`(order_id VARCHAR(20),  
    country_id VARCHAR(5),  
    Date_range_from VARCHAR(50),  
    Date_range_to VARCHAR(50))
BEGIN
      
       DECLARE v_COUNTRY_NAME VARCHAR(65);  
       DECLARE v_Sitecode VARCHAR(50);  
       DECLARE v_linkedserver longtext;  
       DECLARE v_linksrv longtext;  
       DECLARE v_sql_qry LONGTEXT;  
       DECLARE v_errcode INT;  
       DECLARE v_errmsg VARCHAR(250);  
          
       sp_exit:BEGIN
       
          if order_id = ''
          then
          set order_id = null;
          end if;
          
          IF Date_range_from is null 
          then
             set Date_range_from = '';
          END IF;
          
          IF Date_range_to is null 
          then
             set Date_range_to = '';
          END IF;
          
          set v_errcode = -1;
          set v_errmsg = 'Failure to get details.';
 
          
          SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
          select   sitecode, COUNTRY_NAME INTO v_Sitecode,v_COUNTRY_NAME FROM 
          crm3.country_code WHERE COUNTRY_NUMBER = country_id    LIMIT 1;
          SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
          
          IF v_Sitecode IS NULL 
          then   
             SET v_errcode = -1;
             SET v_errmsg  = 'Unable to fetch sitecode';
             LEAVE sp_exit;
          end if;
          
          Drop TEMPORARY table IF EXISTS tt_temp_sms_xtrapp_imsi_mapping;
          create TEMPORARY table tt_temp_sms_xtrapp_imsi_mapping
          (
             id INT,
             msisdn VARCHAR(20),
             imsi VARCHAR(20),
             sms_relay VARCHAR(25),
             status INT,
             create_date DATETIME(3),
             main_msisdn VARCHAR(20),
             exp_date DATETIME(3)
          );
          
          SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
         
         
          SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
          
          set v_linkedserver = CONCAT_WS('hlrdb.','sms_xtrapp_imsi_mapping');
          
          if v_linkedserver is null 
          then 
             set v_errcode = -1;
             set v_errmsg = 'internal configuration error.';
             LEAVE sp_exit;
          end if;
          
          insert into tt_temp_sms_xtrapp_imsi_mapping
          select id ,msisdn ,imsi ,sms_relay ,status ,create_date ,main_msisdn ,exp_date from hlrdb.sms_xtrapp_imsi_mapping;
 
          IF (order_id IS NOT NULL) and (order_id <> '') 
          then 
             set order_id = replace(order_id,'vt_ext_','');
          end if;  
 
 	SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
       
       DROP TEMPORARY TABLE IF EXISTS tt_temp2;
       
       CREATE TEMPORARY TABLE tt_temp2 AS 
       select IFNULL(account_info,'') as reg_mobileno,   
       cast(a.ID as CHAR(10)) as order_id,
       IFNULL(reg_mobileno,'') as Xtra_Number,
       b.create_date as Purchased_Date,
       'Vectone' as Operator_name,v_COUNTRY_NAME as COUNTRY_NAME 
             from VOTG_VIRTUAL_NUMBER_REGISTER a 
             join tt_temp_sms_xtrapp_imsi_mapping b  
             on a.reg_mobileno = b.msisdn
             and ((Date_range_from = '') or (b.create_date >= Date_range_from) 
             or (Date_range_from is null))
             and ((Date_range_to = '') or (b.create_date <= Date_range_to) 
             or (Date_range_to is null))
             and ((IFNULL(order_id,'') = '') or (a.ID = order_id));
          SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
          
 
          IF v_Sitecode = 'MBE' 
          then
     
             SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
             select(CONCAT(IFNULL(d.firstname,''),' ',IFNULL(d.lastname,'')))  
             as Customername,
 		   a.reg_mobileno,
 		   CONCAT('vt_ext_',order_id) AS order_id,
 		   IFNULL(a.Xtra_Number,'') as Xtra_Number,
 		   'FREE' Number_type,
 		   a.Purchased_Date,
 		   IFNULL(a.Operator_name,'') as Operator_name,
 		   a.COUNTRY_NAME as Country
             from tt_temp2 a
             left join esp.mvno_account b 
             on a.reg_mobileno = b.mobileno
             left join crm.freesim c 
             on b.iccid = c.iccid
             left join crm.subscriber d 
             on c.subscriberid = d.subscriberid
             where b.mobileno is not null
             and d.subscriberid is not null;
             SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
             
             
             set v_errcode = 0;
             set v_errmsg = 'Success to get the sitecode info.';
             LEAVE sp_exit;
             
          ELSE 
          
             IF v_Sitecode = 'MCM' 
             then
     
                SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
                select(CONCAT(IFNULL(d.firstname,''),' ',IFNULL(d.lastname,'')))  
                as Customername,
 			   a.reg_mobileno,
 			   CONCAT('vt_ext_',order_id) AS order_id,
 			   IFNULL(a.Xtra_Number,'') as Xtra_Number,
 			   'FREE' Number_type,
 			   a.Purchased_Date,
 			   IFNULL(a.Operator_name,'') as Operator_name,
 			   a.COUNTRY_NAME as Country
                from tt_temp2 a
                left join esp.mvno_account b 
                on a.reg_mobileno = b.mobileno
                left join crm.freesim c 
                on b.iccid = c.iccid
                left join crm.subscriber d 
                on c.subscriberid = d.subscriberid
                where b.mobileno is not null
                and d.subscriberid is not null;
                SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 
                set v_errcode = 0;
                set v_errmsg = 'Success to get the sitecode info.';
                LEAVE sp_exit;
                
             ELSE 
             
                IF v_Sitecode = 'BAU' 
                then
     
                   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
                   select(CONCAT(IFNULL(d.firstname,''),' ',IFNULL(d.lastname,'')))  
                   as Customername,
 				   a.reg_mobileno,
 				   CONCAT('vt_ext_',order_id) AS order_id,
 				   IFNULL(a.Xtra_Number,'') as Xtra_Number,
 				   'FREE' Number_type,
 				   a.Purchased_Date,
 				   IFNULL(a.Operator_name,'') as Operator_name,
 				   a.COUNTRY_NAME as Country
                   from tt_temp2 a
                   left join esp.mvno_account b 
                   on a.reg_mobileno = b.mobileno
                   left join crm.freesim c 
                   on b.iccid = c.iccid
                   left join crm.subscriber d 
                   on c.subscriberid = d.subscriberid
                   where b.mobileno is not null
                   and d.subscriberid is not null;
                   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
                   
                   
                   set v_errcode = 0;
                   set v_errmsg = 'Success to get the sitecode info.';
                   LEAVE sp_exit;
                   
                ELSE 
                
                   IF v_Sitecode = 'MFR' 
                   then
     
                      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
                      select(CONCAT(IFNULL(d.firstname,''),' ',IFNULL(d.lastname,'')))  
                      as Customername,
 				   a.reg_mobileno,
 				   CONCAT('vt_ext_',order_id) AS order_id,
 				   IFNULL(a.Xtra_Number,'') as Xtra_Number,
 				   'FREE' Number_type,
 				   a.Purchased_Date,
 				   IFNULL(a.Operator_name,'') as Operator_name,
 				   a.COUNTRY_NAME as Country
                      from tt_temp2 a
                      left join esp.mvno_account b 
                      on a.reg_mobileno = b.mobileno
                      left join crm.freesim c 
                      on b.iccid = c.iccid
                      left join crm.subscriber d 
                      on c.subscriberid = d.subscriberid
                      where b.mobileno is not null
                      and d.subscriberid is not null;
                      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
                      
                      
                      set v_errcode = 0;
                      set v_errmsg = 'Success to get the sitecode info.';
                      LEAVE sp_exit;
                      
                   ELSE
                   
                      set v_errcode = -1;
                      set v_errmsg = 'Failure to get sitecode details.';
                      LEAVE sp_exit;
                   end if;
                end if;
             end if;
          end if;
                
       END;
       select v_errcode as errcode,v_errmsg as errmsg;  
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `vectoneapp_purchased_nos_details_reports` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `vectoneapp_purchased_nos_details_reports`(country_id VARCHAR(5),  
  Date_range_from VARCHAR(50),  
  Date_range_to VARCHAR(50))
Begin
   
     DECLARE v_COUNTRY_NAME VARCHAR(65);  
     DECLARE v_Sitecode VARCHAR(50);  
     DECLARE v_linkedserver longtext;  
     DECLARE v_linksrv longtext;  
     DECLARE v_sql_qry LONGTEXT;  
     DECLARE v_errcode INT;  
     DECLARE v_errmsg VARCHAR(250);  
     
     sp_exit:BEGIN
     
        IF Date_range_from is null 
        then
           set Date_range_from = '';
        END IF;
        
        IF Date_range_to is null 
        then
           set Date_range_to = '';
        END IF;
        
        set v_errcode = -1;
        set v_errmsg = 'Failure to get details.';
        
        SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        select   sitecode, COUNTRY_NAME INTO v_Sitecode,v_COUNTRY_NAME FROM crm3.country_code  
        WHERE COUNTRY_NUMBER = country_id    LIMIT 1;
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
        
        IF v_Sitecode IS NULL 
        then   
           SET v_errcode = -1;
           SET v_errmsg  = 'Unable to fetch sitecode';
           LEAVE sp_exit;
        end if;
        
        Drop TEMPORARY table IF EXISTS tt_temp_sms_xtrapp_imsi_mapping;
        create TEMPORARY table tt_temp_sms_xtrapp_imsi_mapping
        (
           id int not null auto_increment primary key,
           msisdn VARCHAR(20),
           imsi VARCHAR(20),
           sms_relay VARCHAR(25),
           status INT,
           create_date DATETIME(3),
           main_msisdn VARCHAR(20),
           exp_date DATETIME(3),
           index(id,msisdn,imsi)
        );
        
        
        SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        select   linkedserver INTO v_linksrv from votg_linkedservers where sitecode = v_Sitecode and db_type = 'MVNO'    LIMIT 1;
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
        
        set v_linkedserver = CONCAT_WS('','hlrdb.','sms_xtrapp_imsi_mapping');
        
        if v_linkedserver is null 
        then 
           set v_errcode = -1;
           set v_errmsg = 'internal configuration error.';
           LEAVE sp_exit;
        end if;
        
        set v_sql_qry =CONCAT( 'select * from ',  v_linkedserver);
        SET @SWV_Stmt = CONCAT_WS('','insert into tt_temp_sms_xtrapp_imsi_mapping ',v_sql_qry);
        PREPARE SWT_Stmt FROM @SWV_Stmt;
        EXECUTE SWT_Stmt;
        DEALLOCATE PREPARE SWT_Stmt;
        
    
        SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        
        DROP TEMPORARY TABLE IF EXISTS tt_temp3;      
        CREATE TEMPORARY TABLE tt_temp3 AS select mundio_country,mundio_sitecode,mundio_number,status,REG_MSISDN 
           from VOTG_VIRTUAL_NUMBER_POOL 
           where status in(0,1)
           and MUNDIO_SITECODE = v_Sitecode
           and COUNTRY_PREFIX = country_id
           and ((Date_range_from = '') or (REG_DATE >= Date_range_from) or (Date_range_from is null))
           and ((Date_range_to = '') or (REG_DATE <= Date_range_to) or (Date_range_to is null));
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
              

              
        SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        
        DROP TEMPORARY TABLE IF EXISTS tt_temp2;      
        CREATE TEMPORARY TABLE tt_temp2 AS select IFNULL(account_info,'') as reg_mobileno,
     cast(CONCAT('vt_ext_',a.id) as CHAR(20)) as order_id,
     IFNULL(reg_mobileno,'') as Xtra_Number,
     b.create_date as Purchased_Date,
     'Vectone' as Operator_name,
     v_COUNTRY_NAME as COUNTRY_NAME
   
           from VOTG_VIRTUAL_NUMBER_REGISTER a 
           join tt_temp_sms_xtrapp_imsi_mapping b  
           on a.reg_mobileno = b.msisdn
           join tt_temp3 c
           on a.account_info = c.REG_MSISDN
           where mundio_sitecode = reg_sitecode;
           
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
        
        IF v_Sitecode = 'MBE' 
        then 
           SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
           select(CONCAT(IFNULL(d.firstname,''),' ',IFNULL(d.lastname,'')))  as Customername,
      a.reg_mobileno,
      a.order_id,
      IFNULL(a.Xtra_Number,'') as Xtra_Number,
      'FREE' Number_type,
      a.Purchased_Date ,
      IFNULL(a.Operator_name,'') as Operator_name,
      a.COUNTRY_NAME as Country
           from tt_temp2 a
           left join esp.mvno_account b 
           on a.reg_mobileno = b.mobileno
           left join crm.freesim c 
           on b.iccid = c.iccid
           left join crm.subscriber d 
           on c.subscriberid = d.subscriberid
           where b.mobileno is not null
           and d.subscriberid is not null;
           
           SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
           
           set v_errcode = 0;
           set v_errmsg = 'Success to get the sitecode info.';
           LEAVE sp_exit;
           
        ELSE 
        
           IF v_Sitecode = 'MCM' 
           then 
              SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
              select(CONCAT(IFNULL(d.firstname,''),' ',IFNULL(d.lastname,'')))  as Customername,
      a.reg_mobileno,
      a.order_id,
      IFNULL(a.Xtra_Number,'') as Xtra_Number,
      'FREE' Number_type,
      a.Purchased_Date ,
      IFNULL(a.Operator_name,'') as Operator_name,
      a.COUNTRY_NAME as Country
              from tt_temp2 a
              left join esp.mvno_account b 
              on a.reg_mobileno = b.mobileno
              left join crm.freesim c 
              on b.iccid = c.iccid
              left join crm.subscriber d 
              on c.subscriberid = d.subscriberid
              where b.mobileno is not null
              and d.subscriberid is not null;
              
              SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
              
              set v_errcode = 0;
              set v_errmsg = 'Success to get the sitecode info.';
              LEAVE sp_exit;
              
           ELSE 
           
              IF v_Sitecode = 'BAU' 
              then 
                 SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
                 select(CONCAT(IFNULL(d.firstname,''),' ',IFNULL(d.lastname,'')))  as Customername,
      a.reg_mobileno,
      a.order_id,
      IFNULL(a.Xtra_Number,'') as Xtra_Number,
      'FREE' Number_type,
      a.Purchased_Date ,
      IFNULL(a.Operator_name,'') as Operator_name,
      a.COUNTRY_NAME as Country
                 from tt_temp2 a
                 left join esp.mvno_account b 
                 on a.reg_mobileno = b.mobileno
                 left join crm.freesim c 
                 on b.iccid = c.iccid
                 left join crm.subscriber d 
                 on c.subscriberid = d.subscriberid
                 where b.mobileno is not null
                 and d.subscriberid is not null;
                 
                 SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
                 
                 set v_errcode = 0;
                 set v_errmsg = 'Success to get the sitecode info.';
                 LEAVE sp_exit;
                 
              ELSE 
              
                 IF v_Sitecode = 'MFR' 
                 then
                    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
                    select(CONCAT(IFNULL(d.firstname,''),' ',IFNULL(d.lastname,'')))  as Customername,
      a.reg_mobileno,
      a.order_id,
      IFNULL(a.Xtra_Number,'') as Xtra_Number,
      'FREE' Number_type,
      a.Purchased_Date ,
      IFNULL(a.Operator_name,'') as Operator_name,
      a.COUNTRY_NAME as Country
                    from tt_temp2 a
                    left join esp.mvno_account b 
                    on a.reg_mobileno = b.mobileno
                    left join crm.freesim c 
                    on b.iccid = c.iccid
                    left join crm.subscriber d 
                    on c.subscriberid = d.subscriberid
                    where b.mobileno is not null
                    and d.subscriberid is not null;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          
                    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
                    
                    set v_errcode = 0;
                    set v_errmsg = 'Success to get the sitecode info.';
                    LEAVE sp_exit;
                    
                 ELSE
                 
                    set v_errcode = -1;
                    set v_errmsg = 'Failure to get sitecode details.';
                    LEAVE sp_exit;
                    
                 end if;
                 
              end if;
           end if;
        end if;      
        
     END;
     select v_errcode as errcode,v_errmsg as errmsg;  
    
  End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `vectoneapp_recycle_log_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `vectoneapp_recycle_log_details`(v_country_id INT)
BEGIN
       
        DECLARE v_COUNTRY_NAME VARCHAR(65);  
        DECLARE v_Sitecode VARCHAR(50);  
        DECLARE v_linkedserver VARCHAR(1000);  
        DECLARE v_linksrv VARCHAR(1000);  
        DECLARE v_sql_qry LONGTEXT;  
        DECLARE v_errcode INT;  
        DECLARE v_errmsg VARCHAR(250);  
        
        sp_exit:BEGIN
        
           set v_errcode = -1;
           set v_errmsg = 'Failure to get details.';  
        
      
           SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
           select   sitecode, COUNTRY_NAME INTO v_Sitecode,v_COUNTRY_NAME from crm3.country_code  
           where  COUNTRY_NUMBER = v_country_id;
           SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
           
           IF v_Sitecode IS NULL 
           then 
              SET v_errcode = -1;
              SET v_errmsg  = 'Unable to fetch sitecode';
              LEAVE sp_exit;
           end if;  
        
      
      
           SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
           select   linkedserver INTO v_linksrv from votg_linkedservers  where sitecode = v_Sitecode and db_type = 'MVNO' LIMIT 1;
           SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;	        
   	
           
           set v_linkedserver = CONCAT_WS('','hlrdb.','sms_xtrapp_imsi_mapping');
           
           if v_linkedserver is null 
           then 
              set v_errcode = -1;
              set v_errmsg = 'internal configuration error.';
              LEAVE sp_exit;
           end if;
           
           set v_sql_qry =CONCAT( 'select * from ',  v_linkedserver);
           
    
           DROP TEMPORARY TABLE IF EXISTS tt_temp_sms_xtrapp_imsi_mapping;
           create TEMPORARY table tt_temp_sms_xtrapp_imsi_mapping
           (
              id INT,
              msisdn VARCHAR(20),
              imsi VARCHAR(20),
              sms_relay VARCHAR(25),
              status INT,
             create_date DATETIME(3),
              main_msisdn VARCHAR(20),
              exp_date DATETIME(3)
        
           );
           create index idx_msisdn on tt_temp_sms_xtrapp_imsi_mapping (msisdn);
           
           SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
       insert into tt_temp_sms_xtrapp_imsi_mapping  (id,msisdn,imsi,sms_relay,status,create_date,main_msisdn,exp_date)    
       select id,msisdn,imsi,sms_relay,status,create_date,main_msisdn,exp_date from hlrdb.sms_xtrapp_imsi_mapping;
          SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
     
       
       
       
       
     
         SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
           If not exists(select  1 from didportal_vectoneapp_recycle_master_log_table LIMIT 1) 
           then      
     			insert into didportal_vectoneapp_recycle_master_log_table(ani,lastCalldate,balance)
     			select ani,calldate,balance from reporting.TEMP_CALL_from_245_last_active_check;
           end if;  
          SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
     
     
       SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
           insert into didportal_vectoneapp_recycle_master_log_table(ani,lastCalldate,balance)
           select Distinct ani,calldate,balance from reporting.TEMP_CALL_from_245_last_active_check
           where ani not in(select Distinct ani from didportal_vectoneapp_recycle_master_log_table);  
         SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
  
     
     
           UPDATE didportal_vectoneapp_recycle_master_log_table
           set currentdate = CURRENT_TIMESTAMP,countryid = v_country_id,lastCalldate = case when lastCalldate is null 
           then TIMESTAMPADD(day,-30,CURRENT_TIMESTAMP) else lastCalldate end
           where ani in(SELECT * FROM(select Distinct ani from didportal_vectoneapp_recycle_master_log_table) SWA_TabAl);  
         
     
     
           update didportal_vectoneapp_recycle_master_log_table
           set lastactive_duration = TIMESTAMPDIFF(day,lastCalldate,CURRENT_TIMESTAMP),
           countryid = v_country_id,sitecode = case when LEFT(ani,2) = '32' then 'mbe'
           when LEFT(ani,2) = '33' then 'mfr'
           when LEFT(ani,2) = '43' then 'bau'
           when LEFT(ani,2) = '44' then 'mcm' end
           where lastCalldate is not null;   
  
     
           
           UPDATE didportal_vectoneapp_recycle_master_log_table
           set lastCalldate = TIMESTAMPADD(day,-30,CURRENT_TIMESTAMP),countryid = v_country_id,
           lastactive_duration = TIMESTAMPDIFF(day,lastCalldate,CURRENT_TIMESTAMP),sitecode = case when LEFT(ani,2) = '32' then 'mbe'
           when LEFT(ani,2) = '33' then 'mfr'
           when LEFT(ani,2) = '43' then 'bau'
           when LEFT(ani,2) = '44' then 'mcm' end
           where lastCalldate is null;  
  
     
        
           UPDATE didportal_vectoneapp_recycle_master_log_table
           set recycle_startdate = DATE_ADD(lastcalldate, INTERVAL 61 DAY) 
           where balance is not null;  
    
     
           
           UPDATE didportal_vectoneapp_recycle_master_log_table
           set recycle_startdate = DATE_ADD(lastcalldate, INTERVAL 31 DAY) 
           where balance is null;  
         
  
     
        
           UPDATE didportal_vectoneapp_recycle_master_log_table
           set recycle_enddate = DATE_ADD(recycle_startdate, INTERVAL 30 DAY),recycle_status =  case when (recycle_startdate < CURRENT_TIMESTAMP 
           or recycle_enddate > CURRENT_TIMESTAMP) then 'in progress'
           when (recycle_startdate < CURRENT_TIMESTAMP or recycle_enddate < CURRENT_TIMESTAMP) then 'active'
           when recycle_startdate > CURRENT_TIMESTAMP then 'inactive' end;  
  
     
           
           UPDATE didportal_vectoneapp_recycle_master_log_table
           set reassign_to_mainpooldate = DATE_ADD(recycle_enddate, INTERVAL 1 DAY);  
           
     
           
           UPDATE didportal_vectoneapp_recycle_master_log_table
           set lastactive_from_main_pool = 30;
         
  
     
           
           SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
           select a.ani as Xtra_Number,IFNULL(c.account_info,'') as reg_mobileno,a.recycle_startdate,
       a.recycle_enddate,a.recycle_status,a.reassign_to_mainpooldate,
       b.create_date as Purchased_Date from didportal_vectoneapp_recycle_master_log_table a
           join tt_temp_sms_xtrapp_imsi_mapping b  
           on a.ani = b.msisdn
           join VOTG_VIRTUAL_NUMBER_REGISTER c 
           on c.reg_mobileno = b.msisdn
           where a.countryid = left(a.ani,2)
           and countryid = v_country_id
           and a.lastactive_duration > 30;
           SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
        END;
        
        if found_rows()> 0 then
 		set v_errcode = 0;
 		set v_errmsg = 'Success to get details.'; 
        end if;
        
        
        select v_errcode errcode,v_errmsg errmsg;  
         
     END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `vectoneapp_recycling_nos_details_reports` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `vectoneapp_recycling_nos_details_reports`(country_id VARCHAR(5),  
Date_range_from VARCHAR(50),  
Date_range_to VARCHAR(50))
BEGIN
  
   DECLARE v_errcode INT;   
   DECLARE v_errmsg VARCHAR(250);
   DECLARE v_COUNTRY_NAME VARCHAR(65);  
   DECLARE v_Sitecode VARCHAR(50);  
   DECLARE v_linkedserver VARCHAR(1000);  
   DECLARE v_linksrv VARCHAR(1000);  
   DECLARE v_sql_qry LONGTEXT;  
  
   
   sp_exit:BEGIN
   
      IF Date_range_from is null 
      then
         set Date_range_from = '';
      END IF;
      
      IF Date_range_to is null 
      then
         set Date_range_to = '';
      END IF;

      set v_errcode = -1;
      set v_errmsg = 'Failure to get details.';
      
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select   sitecode, COUNTRY_NAME INTO v_Sitecode,v_COUNTRY_NAME FROM crm3.country_code  
      WHERE COUNTRY_NUMBER = country_id    LIMIT 1;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
      
      IF v_Sitecode IS NULL 
      then   
         SET v_errcode = -1;
         SET v_errmsg  = 'Unable to fetch sitecode';
         LEAVE sp_exit;
      end if;  
      
      Drop TEMPORARY table IF EXISTS tt_temp_sms_xtrapp_imsi_mapping;
      create TEMPORARY table tt_temp_sms_xtrapp_imsi_mapping
      (
         id INT,
         msisdn VARCHAR(20),
         imsi VARCHAR(20),
         sms_relay VARCHAR(25),
         status INT,
         create_date DATETIME(3),
         main_msisdn VARCHAR(20),
         exp_date DATETIME(3)
      );
      
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select   linkedserver INTO v_linksrv from votg_linkedservers where sitecode = v_Sitecode and db_type = 'MVNO'    LIMIT 1;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
      
      set v_linkedserver = CONCAT_WS('','hlrdb.','sms_xtrapp_imsi_mapping');
      
      if v_linkedserver is null 
      then 
         set v_errcode = -1;
         set v_errmsg = 'internal configuration error.';
         LEAVE sp_exit;
      end if;
      
      set v_sql_qry =CONCAT( 'select * from ',  v_linkedserver);
      SET @SWV_Stmt = CONCAT_WS('','insert into tt_temp_sms_xtrapp_imsi_mapping ',v_sql_qry);
      PREPARE SWT_Stmt FROM @SWV_Stmt;
      EXECUTE SWT_Stmt;
      DEALLOCATE PREPARE SWT_Stmt;
      
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      
      DROP TEMPORARY TABLE IF EXISTS tt_temp5;      
      CREATE TEMPORARY TABLE tt_temp5 AS select a.ani as Xtra_Number,IFNULL(c.account_info,'') as reg_mobileno,a.recycle_startdate,
  a.recycle_enddate,a.reassign_to_mainpooldate,CONCAT('vt_ext_',c.id) AS order_id,
  b.create_date as Purchased_Date
 
         from didportal_vectoneapp_recycle_master_log_table a
         join tt_temp_sms_xtrapp_imsi_mapping b  
         on a.ani = b.msisdn
         join VOTG_VIRTUAL_NUMBER_REGISTER c 
         on c.reg_mobileno = b.msisdn
         where a.countryid = left(a.ani,2)
         and countryid = country_id
         and a.lastactive_duration > 30;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
      
      IF v_Sitecode = 'MBE' 
      then 
         SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
         select(CONCAT(IFNULL(d.firstname,''),' ',IFNULL(d.lastname,'')))  as Customername,
    a.reg_mobileno,a.order_id, a.Xtra_Number,'FREE' Number_type,a.Purchased_Date,'VECTONE' as Operator_name,
    v_COUNTRY_NAME as Country,a.recycle_startdate,
    a.recycle_enddate,a.reassign_to_mainpooldate
         from tt_temp5 a
         left join esp.mvno_account b 
         on a.Xtra_Number = b.mobileno
         left join crm.freesim c 
         on b.iccid = c.iccid
         left join crm.subscriber d 
         on c.subscriberid = d.subscriberid
         where b.mobileno is not null;
         SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;   
  
    
         set v_errcode = 0;
         set v_errmsg = 'Success to get the sitecode info.';
         LEAVE sp_exit;
         
      ELSE 
      
         IF v_Sitecode = 'MCM' 
         then 
            SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
            select(CONCAT(IFNULL(d.firstname,''),' ',IFNULL(d.lastname,'')))  as Customername,
    a.reg_mobileno,a.order_id, a.Xtra_Number,'FREE' Number_type,a.Purchased_Date,'VECTONE' as Operator_name,
    v_COUNTRY_NAME as Country,a.recycle_startdate,
    a.recycle_enddate,a.reassign_to_mainpooldate
            from tt_temp5 a
            left join esp.mvno_account b 
            on a.Xtra_Number = b.mobileno
            left join crm.freesim c 
            on b.iccid = c.iccid
            left join crm.subscriber d 
            on c.subscriberid = d.subscriberid
            where b.mobileno is not null;
            SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;   
  
    
            set v_errcode = 0;
            set v_errmsg = 'Success to get the sitecode info.';
            LEAVE sp_exit;
            
         ELSE 
         
            IF v_Sitecode = 'BAU' 
            then 
               SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
               select(CONCAT(IFNULL(d.firstname,''),' ',IFNULL(d.lastname,'')))  as Customername,
    a.reg_mobileno,a.order_id, a.Xtra_Number,'FREE' Number_type,a.Purchased_Date,'VECTONE' as Operator_name,
    v_COUNTRY_NAME as Country,a.recycle_startdate,
    a.recycle_enddate,a.reassign_to_mainpooldate
               from tt_temp5 a
               left join esp.mvno_account b 
               on a.Xtra_Number = b.mobileno
               left join crm.freesim c 
               on b.iccid = c.iccid
               left join crm.subscriber d 
               on c.subscriberid = d.subscriberid
               where b.mobileno is not null;
               SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;   
  
    
               set v_errcode = 0;
               set v_errmsg = 'Success to get the sitecode info.';
               LEAVE sp_exit;
               
            ELSE 
            
               IF v_Sitecode = 'MFR' 
               then 
                  SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
                  select(CONCAT(IFNULL(d.firstname,''),' ',IFNULL(d.lastname,'')))  as Customername,
    a.reg_mobileno,a.order_id, a.Xtra_Number,'FREE' Number_type,a.Purchased_Date,'VECTONE' as Operator_name,
    v_COUNTRY_NAME as Country,a.recycle_startdate,
    a.recycle_enddate,a.reassign_to_mainpooldate
                  from tt_temp5 a
                  left join esp.mvno_account b 
                  on a.Xtra_Number = b.mobileno
                  left join crm.freesim c 
                  on b.iccid = c.iccid
                  left join crm.subscriber d 
                  on c.subscriberid = d.subscriberid
                  where b.mobileno is not null;
                  SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;   
  
    
                  set v_errcode = 0;
                  set v_errmsg = 'Success to get the sitecode info.';
                  LEAVE sp_exit;
                  
               ELSE
               
                  set v_errcode = -1;
                  set v_errmsg = 'Failure to get sitecode details.';
                  LEAVE sp_exit;                  
               end if;
               
            end if;
         end if;
      end if;      
      
   END;
   select v_errcode as errcode,v_errmsg as errmsg;  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `vectoneapp_Reports_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `vectoneapp_Reports_details`(nos_Type VARCHAR(20),  
 country_id VARCHAR(5),  
 Date_range_from VARCHAR(50),  
 Date_range_to VARCHAR(50))
Begin  
   
    DECLARE v_errcode INT;   
    DECLARE v_errmsg VARCHAR(250);  
       
    sp_exit:BEGIN
    
       IF Date_range_from is null 
       then
          set Date_range_from = '';
       END IF;
       
       IF Date_range_to is null 
       then
          set Date_range_to = '';
       END IF;
       
       IF nos_Type = 1 
       then
   
          CALL vectoneapp_inactive_used_nos_details_reports(country_id,Date_range_from,Date_range_to);
         
         
          LEAVE sp_exit;
          
       ELSE 
       
          IF nos_Type = 2 
          then  
             CALL vectoneapp_recycling_nos_details_reports(country_id,Date_range_from,Date_range_to);
            
            
             LEAVE sp_exit;
             
          ELSE 
          
             IF nos_Type = 3 
             then  
                CALL vectoneapp_purchased_nos_details_reports(country_id,Date_range_from,Date_range_to);
              
              
                LEAVE sp_exit;
                
             ELSE 
             
                IF nos_Type = 4 
                then  
                   CALL vectoneapp_unused_nos_details_reports(country_id,Date_range_from,Date_range_to);
                 
                 
                   LEAVE sp_exit;
                   
                ELSE 
                
                   IF nos_Type = 5 
                   then  
                      CALL vectoneapp_used_nos_details_reports(country_id,Date_range_from,Date_range_to);
                    
                    
                      LEAVE sp_exit;
                      
                   ELSE
                   
                      set v_errcode = -1;
                      set v_errmsg = 'Failure - unable to fetch nos type details.';
                      LEAVE sp_exit;
                      
                   end if;
                   
                end if;
             end if;
          end if;
       end if;
       
    END;
    
    
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `vectoneapp_unused_nos_details_reports` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `vectoneapp_unused_nos_details_reports`(country_id VARCHAR(5),  
Date_range_from VARCHAR(50),  
Date_range_to VARCHAR(50))
Begin
   
   DECLARE v_COUNTRY_NAME VARCHAR(65);  
   DECLARE v_Sitecode VARCHAR(50);  
   DECLARE v_linkedserver VARCHAR(1000);  
   DECLARE v_linksrv VARCHAR(1000);  
   DECLARE v_sql_qry LONGTEXT;  
   DECLARE v_errcode INT;  
   DECLARE v_errmsg VARCHAR(250);  
   
   sp_exit:BEGIN
   
      IF Date_range_from is null 
      then
         set Date_range_from = '';
      END IF;
      
      IF Date_range_to is null 
      then
         set Date_range_to = '';
      END IF;
      
      set v_errcode = -1;
      set v_errmsg = 'Failure to get details.';
      
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select   sitecode, COUNTRY_NAME INTO v_Sitecode,v_COUNTRY_NAME FROM crm3.country_code  
      WHERE COUNTRY_NUMBER = country_id    LIMIT 1;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
      
      IF v_Sitecode IS NULL 
      then   
         SET v_errcode = -1;
         SET v_errmsg  = 'Unable to fetch sitecode';
         LEAVE sp_exit;
      end if;
      
      Drop TEMPORARY table IF EXISTS tt_temp_sms_xtrapp_imsi_mapping;
      create TEMPORARY table tt_temp_sms_xtrapp_imsi_mapping
      (
         id INT,
         msisdn VARCHAR(20),
         imsi VARCHAR(20),
         sms_relay VARCHAR(25),
         status INT,
         create_date DATETIME(3),
         main_msisdn VARCHAR(20),
         exp_date DATETIME(3)
      );
      
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select   linkedserver INTO v_linksrv from votg_linkedservers  where sitecode = v_Sitecode and db_type = 'MVNO'    LIMIT 1;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
      
      set v_linkedserver = CONCAT_WS('','hlrdb.','sms_xtrapp_imsi_mapping');
      
      if v_linkedserver is null then
 
         set v_errcode = -1;
         set v_errmsg = 'internal configuration error.';
         LEAVE sp_exit;
      end if;
      
      set v_sql_qry =CONCAT( 'select * from ',  v_linkedserver);
      SET @SWV_Stmt = CONCAT_WS('','insert into tt_temp_sms_xtrapp_imsi_mapping ',v_sql_qry);
      PREPARE SWT_Stmt FROM @SWV_Stmt;
      EXECUTE SWT_Stmt;
      DEALLOCATE PREPARE SWT_Stmt;
      
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      
      DROP TEMPORARY TABLE IF EXISTS tt_temp3;      
      CREATE TEMPORARY TABLE tt_temp3 AS select mundio_country,mundio_sitecode,mundio_number,status,REG_MSISDN 
         from VOTG_VIRTUAL_NUMBER_POOL 
         where status in(0)
         and MUNDIO_SITECODE = v_Sitecode
         and COUNTRY_PREFIX = country_id
         and ((Date_range_from = '') or (REG_DATE >= Date_range_from) or (Date_range_from is null))
         and ((Date_range_to = '') or (REG_DATE <= Date_range_to) or (Date_range_to is null));
         
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
      
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      
      DROP TEMPORARY TABLE IF EXISTS tt_temp2;
      CREATE TEMPORARY TABLE tt_temp2 AS select IFNULL(account_info,'') as reg_mobileno,
   cast(a.ID as CHAR(10)) as order_id,
   IFNULL(reg_mobileno,'') as Xtra_Number,
   b.create_date as Purchased_Date,
   'Vectone' as Operator_name,
   v_COUNTRY_NAME as COUNTRY_NAME,
   NULL as Reassigned_date
 
         from VOTG_VIRTUAL_NUMBER_REGISTER a 
         join tt_temp_sms_xtrapp_imsi_mapping b  
         on a.reg_mobileno = b.msisdn
         join tt_temp3 c
         on a.account_info = c.REG_MSISDN
         where mundio_sitecode = reg_sitecode;
         
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
      
      IF v_Sitecode = 'MBE' 
      then 
         SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
         select IFNULL(a.Xtra_Number,'') as Xtra_Number,
    a.Reassigned_date ,
    IFNULL(a.Operator_name,'') as Operator_name,
    a.COUNTRY_NAME as Country
         from tt_temp2 a
         left join esp.mvno_account b 
         on a.reg_mobileno = b.mobileno
         left join crm.freesim c 
         on b.iccid = c.iccid
         left join crm.subscriber d 
         on c.subscriberid = d.subscriberid
         where b.mobileno is not null
         and d.subscriberid is not null;
         
         SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
         
         set v_errcode = 0;
         set v_errmsg = 'Success to get the sitecode info.';
         LEAVE sp_exit;
         
      ELSE 
      
         IF v_Sitecode = 'MCM' 
         then 
            SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
            select IFNULL(a.Xtra_Number,'') as Xtra_Number,
    a.Reassigned_date ,
    IFNULL(a.Operator_name,'') as Operator_name,
    a.COUNTRY_NAME as Country
            from tt_temp2 a
            left join esp.mvno_account b 
            on a.reg_mobileno = b.mobileno
            left join crm.freesim c 
            on b.iccid = c.iccid
            left join crm.subscriber d 
            on c.subscriberid = d.subscriberid
            where b.mobileno is not null
            and d.subscriberid is not null;
            
            SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
            
            set v_errcode = 0;
            set v_errmsg = 'Success to get the sitecode info.';
            LEAVE sp_exit;
            
         ELSE 
         
            IF v_Sitecode = 'BAU' 
            then 
               SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
               select IFNULL(a.Xtra_Number,'') as Xtra_Number,
    a.Reassigned_date ,
    IFNULL(a.Operator_name,'') as Operator_name,
    a.COUNTRY_NAME as Country
               from tt_temp2 a
               left join esp.mvno_account b 
               on a.reg_mobileno = b.mobileno
               left join crm.freesim c 
               on b.iccid = c.iccid
               left join crm.subscriber d 
               on c.subscriberid = d.subscriberid
               where b.mobileno is not null
               and d.subscriberid is not null;
               
               SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
               
               set v_errcode = 0;
               set v_errmsg = 'Success to get the sitecode info.';
               LEAVE sp_exit;
               
            ELSE 
            
               IF v_Sitecode = 'MFR' 
               then 
                  SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
                  select IFNULL(a.Xtra_Number,'') as Xtra_Number,
    a.Reassigned_date ,
    IFNULL(a.Operator_name,'') as Operator_name,
    a.COUNTRY_NAME as Country
                  from tt_temp2 a
                  left join esp.mvno_account b 
                  on a.reg_mobileno = b.mobileno
                  left join crm.freesim c 
                  on b.iccid = c.iccid
                  left join crm.subscriber d 
                  on c.subscriberid = d.subscriberid
                  where b.mobileno is not null
                  and d.subscriberid is not null;
                  
                  SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
                  
                  set v_errcode = 0;
                  set v_errmsg = 'Success to get the sitecode info.';
                  LEAVE sp_exit;
                  
               ELSE
               
                  set v_errcode = -1;
                  set v_errmsg = 'Failure to get sitecode details.';
                  LEAVE sp_exit;
                  
               end if;
               
            end if;
         end if;
      end if;      
      
   END;
   select v_errcode as errcode,v_errmsg as errmsg;  
  
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `vectoneapp_upload_numbers` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `vectoneapp_upload_numbers`(
country_id INT,  
in_xml_data LONGTEXT,
in_user_name VARCHAR(50))
begin

   DECLARE v_error_code INT;   
   DECLARE v_error_msg VARCHAR(250);   
   DECLARE v_hDoc INT;             
   DECLARE v_country_code VARCHAR(10);  
   DECLARE v_dup_num INT;  
   DECLARE v_sitecode VARCHAR(5);  
   DECLARE v_country_name VARCHAR(50);  
   DECLARE v_COUNTRY_SHORT_CODE VARCHAR(5);  
   DECLARE v_COUNTRY_NUMBER VARCHAR(5);
   
   DECLARE v_did VARCHAR(100);
          
   sp_exit:BEGIN
   
      SET v_error_code = -1;
      SET v_error_msg = 'NUMBER ALREADY UPLOADED';
   
   
   drop TEMPORARY table IF EXISTS tt_bulk_upload;
   CREATE TEMPORARY TABLE tt_bulk_upload
      (
         idx INT   AUTO_INCREMENT PRIMARY KEY,
         country_id INT,
         did VARCHAR(20),
         country_name VARCHAR(50),
         COUNTRY_SHORT_CODE VARCHAR(5),
         COUNTRY_NUMBER INT
      )  AUTO_INCREMENT = 1;     
     
     
     

      
      
      
      
      
      
      Drop temporary table IF EXISTS xml_did_tbl; create temporary table xml_did_tbl(id int auto_increment primary key, did varchar(100));

	  SELECT replace(ExtractValue(in_xml_data, '//did[1]'),' ',',') into v_did; 

	  call unifiedring.Split(v_did,',');  insert into xml_did_tbl (did) select Items from unifiedring.tt_Split_temptable;

	  INSERT INTO tt_bulk_upload(did)
	  select a.did from xml_did_tbl a; 

      select   sitecode, Country_name, COUNTRY_SHORT_CODE, COUNTRY_NUMBER INTO 
      v_sitecode,v_country_name,v_COUNTRY_SHORT_CODE,v_COUNTRY_NUMBER FROM crm3.country_code  
      WHERE COUNTRY_NUMBER = country_id    LIMIT 1;
      
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
      
      UPDATE tt_bulk_upload a
      set a.country_id = country_id,Country_name = v_country_name,COUNTRY_SHORT_CODE = v_COUNTRY_SHORT_CODE,
      COUNTRY_NUMBER = v_COUNTRY_NUMBER;
      
      if exists(select did,count(1) as cnt from tt_bulk_upload
      group by did having count(1) > 1) 
      
      then
 
         DROP TEMPORARY TABLE IF EXISTS tt_temp1;
         create TEMPORARY table tt_temp1
         (
            did VARCHAR(25),
            `count` INT
         );
      
         insert into tt_temp1
         select did,count(1)
         from tt_bulk_upload
         group by did having count(1) > 1;
         
         select   count(*) INTO v_dup_num from tt_temp1 where `count` > 1;
         
         set v_error_code = -1;
         set v_error_msg = 'Duplicate number found in file.Please check';
         LEAVE sp_exit;
      end if;
      
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      INSERT INTO VOTG_VIRTUAL_NUMBER_POOL(MUNDIO_COUNTRY,MUNDIO_SITECODE,COUNTRY_PREFIX,MUNDIO_NUMBER,AMOUNT,
      STATUS,DIR_USER_ID,REG_SITECODE,REG_MSISDN,REG_BY,REG_DATE,COUNTRY_CODE,VEC_USER)
      
      SELECT Country_name,v_sitecode,v_COUNTRY_NUMBER,did,null,1,null,v_sitecode,NULL,in_user_name,
      CURRENT_TIMESTAMP,v_COUNTRY_SHORT_CODE,0
      from tt_bulk_upload where did not in(select mundio_number from VOTG_VIRTUAL_NUMBER_POOL);
      
      
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
      
      if found_rows() > 0 
      then   
         set v_error_code = 0;
         set v_error_msg = 'DID Number uploaded successfully.';
      end if;
            
   END;
   
   select v_error_code as errcode,v_error_msg as errmsg,v_dup_num as dup_num;  
      
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `vectoneapp_used_nos_details_reports` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `vectoneapp_used_nos_details_reports`(country_id VARCHAR(5),  
 Date_range_from VARCHAR(50),  
 Date_range_to VARCHAR(50))
Begin
 
 
    DECLARE v_COUNTRY_NAME VARCHAR(65);  
    DECLARE v_Sitecode VARCHAR(50);  
    DECLARE v_linkedserver VARCHAR(1000);  
    DECLARE v_linksrv VARCHAR(1000);  
    DECLARE v_sql_qry LONGTEXT;  
    DECLARE v_errcode INT;  
    DECLARE v_errmsg VARCHAR(250);  
    
 
    sp_exit:BEGIN
    
       IF Date_range_from is null 
       then
          set Date_range_from = '';
       END IF;
 
       IF Date_range_to is null 
       then
          set Date_range_to = '';
       END IF;
       
       set v_errcode = -1;
       set v_errmsg = 'Failure to get details.';
       
       if Date_range_from > Date_range_to 
       then 
          SET v_errcode = -1;
          SET v_errmsg  = 'purchase from date should not be greater than the to date';
          LEAVE sp_exit;
       end if;
       
       SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
       select   sitecode, COUNTRY_NAME INTO v_Sitecode,v_COUNTRY_NAME FROM crm3.country_code  
       WHERE COUNTRY_NUMBER = country_id    LIMIT 1;
       SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
       
       IF v_Sitecode IS NULL 
       then   
          SET v_errcode = -1;
          SET v_errmsg  = 'Unable to fetch sitecode';
          LEAVE sp_exit;
       end if;
 	  
       Drop TEMPORARY table IF EXISTS tt_temp_sms_xtrapp_imsi_mapping;
       create TEMPORARY table tt_temp_sms_xtrapp_imsi_mapping
       (
          id INT not null primary key auto_increment,
          msisdn VARCHAR(20),
          imsi VARCHAR(20),
          sms_relay VARCHAR(25),
          status INT,
          create_date DATETIME(3),
          main_msisdn VARCHAR(20),
          exp_date DATETIME(3),
          index(id,msisdn,imsi)
       );
       
       SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
       select   linkedserver INTO v_linksrv from votg_linkedservers where sitecode = v_Sitecode and db_type = 'MVNO'    LIMIT 1;
       SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
       
       set v_linkedserver = CONCAT_WS('','hlrdb.','sms_xtrapp_imsi_mapping');
       
       if v_linkedserver is null 
       then 
          set v_errcode = -1;
          set v_errmsg = 'internal configuration error.';
          LEAVE sp_exit;
       end if;
       
       set v_sql_qry =CONCAT( 'select * from ',  v_linkedserver);
       SET @SWV_Stmt = CONCAT_WS('','insert into tt_temp_sms_xtrapp_imsi_mapping ',v_sql_qry);
       PREPARE SWT_Stmt FROM @SWV_Stmt;
       EXECUTE SWT_Stmt;
       DEALLOCATE PREPARE SWT_Stmt;
       
       SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
       
       DROP TEMPORARY TABLE IF EXISTS tt_temp3;      
       CREATE TEMPORARY TABLE tt_temp3 AS select mundio_country,mundio_sitecode,mundio_number,status,REG_MSISDN 
          from VOTG_VIRTUAL_NUMBER_POOL 
          where status in(1)
          and MUNDIO_SITECODE = v_Sitecode
          and COUNTRY_PREFIX = country_id
          and ((Date_range_from = '') or (REG_DATE >= Date_range_from) or (Date_range_from is null))
          and ((Date_range_to = '') or (REG_DATE <= Date_range_to) or (Date_range_to is null));
          
       SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
       
       SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
       
       DROP TEMPORARY TABLE IF EXISTS tt_temp2;      
       CREATE TEMPORARY TABLE tt_temp2 AS select IFNULL(account_info,'') as reg_mobileno,
    cast(CONCAT('vt_ext_',a.id) as CHAR(20)) as order_id,
    IFNULL(reg_mobileno,'') as Xtra_Number,
    b.create_date as Purchased_Date,
    'Vectone' as Operator_name,
    v_COUNTRY_NAME as COUNTRY_NAME 
          from VOTG_VIRTUAL_NUMBER_REGISTER a 
          join tt_temp_sms_xtrapp_imsi_mapping b  
          on a.reg_mobileno = b.msisdn
          join tt_temp3 c
          on a.account_info = c.REG_MSISDN
          where mundio_sitecode = reg_sitecode;
          
       SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
       
       IF v_Sitecode = 'MBE' 
       then 
          SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
          select(CONCAT(IFNULL(d.firstname,''),' ',IFNULL(d.lastname,'')))  as Customername,
     a.reg_mobileno,
     a.order_id,
     IFNULL(a.Xtra_Number,'') as Xtra_Number,
     'FREE' Number_type,
     a.Purchased_Date ,
     IFNULL(a.Operator_name,'') as Operator_name,
     a.COUNTRY_NAME as Country
          from tt_temp2 a
          left join esp.mvno_account b 
          on a.reg_mobileno = b.mobileno
          left join crm.freesim c 
          on b.iccid = c.iccid
          left join crm.subscriber d 
          on c.subscriberid = d.subscriberid
          where b.mobileno is not null
          and d.subscriberid is not null and b.iccid is not null and c.iccid is not null;
          
          SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
          
          set v_errcode = 0;
          set v_errmsg = 'Success to get the sitecode info.';
          LEAVE sp_exit;
          
       ELSE 
       
          IF v_Sitecode = 'MCM' 
          then 
             SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
             select(CONCAT(IFNULL(d.firstname,''),' ',IFNULL(d.lastname,'')))  as Customername,
     a.reg_mobileno,
     a.order_id,
     IFNULL(a.Xtra_Number,'') as Xtra_Number,
     'FREE' Number_type,
     a.Purchased_Date ,
     IFNULL(a.Operator_name,'') as Operator_name,
     a.COUNTRY_NAME as Country
             from tt_temp2 a
             left join esp.mvno_account b 
             on a.reg_mobileno = b.mobileno
             left join crm.freesim c 
             on b.iccid = c.iccid
             left join crm.subscriber d 
             on c.subscriberid = d.subscriberid
             where b.mobileno is not null
             and d.subscriberid is not null and b.iccid is not null and c.iccid is not null;
             
             SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
             
             set v_errcode = 0;
             set v_errmsg = 'Success to get the sitecode info.';
             LEAVE sp_exit;
             
          ELSE 
          
             IF v_Sitecode = 'BAU' 
             then 
                SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
                select(CONCAT(IFNULL(d.firstname,''),' ',IFNULL(d.lastname,'')))  as Customername,
     a.reg_mobileno,
     a.order_id,
     IFNULL(a.Xtra_Number,'') as Xtra_Number,
     'FREE' Number_type,
     a.Purchased_Date ,
     IFNULL(a.Operator_name,'') as Operator_name,
     a.COUNTRY_NAME as Country
                from tt_temp2 a
                left join esp.mvno_account b 
                on a.reg_mobileno = b.mobileno
                left join crm.freesim c 
                on b.iccid = c.iccid
                left join crm.subscriber d 
                on c.subscriberid = d.subscriberid
                where b.mobileno is not null
                and d.subscriberid is not null and b.iccid is not null and c.iccid is not null;
                
                SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
                
                set v_errcode = 0;
                set v_errmsg = 'Success to get the sitecode info.';
                LEAVE sp_exit;
                
             ELSE 
             
                IF v_Sitecode = 'MFR' 
                then 
                   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
                   select(CONCAT(IFNULL(d.firstname,''),' ',IFNULL(d.lastname,'')))  as Customername,
     a.reg_mobileno,
     a.order_id,
     IFNULL(a.Xtra_Number,'') as Xtra_Number,
     'FREE' Number_type,
     a.Purchased_Date ,
     IFNULL(a.Operator_name,'') as Operator_name,
     a.COUNTRY_NAME as Country
                   from tt_temp2 a
                   left join esp.mvno_account b 
                   on a.reg_mobileno = b.mobileno
                   left join crm.freesim c 
                   on b.iccid = c.iccid
                   left join crm.subscriber d 
                   on c.subscriberid = d.subscriberid
                   where b.mobileno is not null
                   and d.subscriberid is not null and b.iccid is not null and c.iccid is not null;
                   
                   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
                   
                   set v_errcode = 0;
                   set v_errmsg = 'Success to get the sitecode info.';
                   LEAVE sp_exit;
                   
                ELSE
                
                   set v_errcode = -1;
                   set v_errmsg = 'Failure to get sitecode details.';
                   LEAVE sp_exit;
                   
                end if;
                
             end if;
          end if;
       end if;      
       
    END;
    select v_errcode as errcode,v_errmsg as errmsg;  
   
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `votg_number_lookup_search` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `votg_number_lookup_search`(mobileno VARCHAR(20) ,  
    operator_id INT,  
    country_id VARCHAR(5))
BEGIN
    
      
       DECLARE v_COUNTRY_NAME VARCHAR(65);  
     
       DECLARE v_Sitecode VARCHAR(50);  
       DECLARE v_linkedserver VARCHAR(1000);  
       DECLARE v_linksrv VARCHAR(1000);  
       DECLARE v_sql_qry LONGTEXT;  
       DECLARE v_errcode INT;  
       DECLARE v_errmsg VARCHAR(250);  
       DECLARE v_out_handle_varchar varchar(150) default '';
       DECLARE v_Number_type varchar(150) default 'FREE';
       
       sp_exit:BEGIN
       
          set v_errcode = -1;
          set v_errmsg = 'Failure to get details.';
          
          IF (mobileno is null) or(mobileno = '') 
          then  
          
             SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
             select   sitecode, COUNTRY_NAME INTO v_Sitecode,v_COUNTRY_NAME FROM crm3.country_code  
             WHERE COUNTRY_NUMBER = country_id    LIMIT 1;
             SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
             
          ELSE 
          
             if mobileno is not null and country_id is not null 
             then  
                SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
                select   sitecode, COUNTRY_NUMBER, COUNTRY_NAME INTO v_Sitecode,country_id,v_COUNTRY_NAME FROM crm3.country_code  
                WHERE COUNTRY_NUMBER = left(mobileno, CHAR_LENGTH(COUNTRY_NUMBER))
                and COUNTRY_NUMBER = country_id    LIMIT 1;
                SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
                
                IF v_Sitecode IS NULL 
                then   
                   SET v_errcode = -1;
                   SET v_errmsg  = 'Unable to fetch sitecode';
                   LEAVE sp_exit;
                end if;
                
             end if;
             
          end if;
          
          Drop TEMPORARY table IF EXISTS tt_temp_sms_xtrapp_imsi_mapping;      
          create TEMPORARY table tt_temp_sms_xtrapp_imsi_mapping
          (
             id INT,
             msisdn VARCHAR(20),
             imsi VARCHAR(20),
             sms_relay VARCHAR(25),
             status INT,
             create_date DATETIME(3),
             main_msisdn VARCHAR(20),
             exp_date DATETIME(3)
          );
          
          
          SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
          select   linkedserver INTO v_linksrv from votg_linkedservers where sitecode = v_Sitecode and db_type = 'MVNO'    LIMIT 1;
          SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
          
          set v_linkedserver = CONCAT_WS('','hlrdb.','sms_xtrapp_imsi_mapping');
          
          if v_linkedserver is null 
          then 
             set v_errcode = -1;
             set v_errmsg = 'internal configuration error.';
             LEAVE sp_exit;
          end if;
          
          set v_sql_qry =CONCAT( 'select * from ',  v_linkedserver);
          SET @SWV_Stmt = CONCAT_WS('','insert into tt_temp_sms_xtrapp_imsi_mapping ',v_sql_qry);
          PREPARE SWT_Stmt FROM @SWV_Stmt;
          EXECUTE SWT_Stmt;
          DEALLOCATE PREPARE SWT_Stmt;
          
          SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
          
          DROP TEMPORARY TABLE IF EXISTS tt_temp2;      
          CREATE TEMPORARY TABLE tt_temp2 AS select IFNULL(account_info,v_out_handle_varchar) as reg_mobileno,'Vectone' as Operator_name,
          v_COUNTRY_NAME as COUNTRY_NAME,IFNULL(reg_mobileno,v_out_handle_varchar) as Xtra_Number,b.imsi as imsi_number,b.create_date as Purchased_Date,
       case when R.lastactive_duration < 15 then 'Active'
             when R.lastactive_duration >= 15 then 'Inactive for 15 days'
             when R.lastactive_duration = 0 then 'Unused'
             when R.lastactive_duration >= 30  then 'Recycling'
             end as status ,R.lastactive_duration 
             from VOTG_VIRTUAL_NUMBER_REGISTER a 
             join tt_temp_sms_xtrapp_imsi_mapping b  
             on a.reg_mobileno = b.msisdn
             join didportal_vectoneapp_recycle_master_log_table R
             on a.reg_mobileno = R.ani
             and ((a.account_info = mobileno) or IFNULL(mobileno,v_out_handle_varchar) = '');
          SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
          
  
          
          IF v_Sitecode = 'MBE' 
          then 
             SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
             select(CONCAT(IFNULL(d.firstname,v_out_handle_varchar),' ',IFNULL(d.lastname,v_out_handle_varchar)))  as Customername,
        a.reg_mobileno,
        IFNULL(a.Operator_name,v_out_handle_varchar) as Operator_name,
        a.COUNTRY_NAME as Country,
        IFNULL(a.Xtra_Number,v_out_handle_varchar) as Xtra_Number,
        IFNULL(a.imsi_number,v_out_handle_varchar) as imsi_number,
        v_Number_type as Number_type,
        a.Purchased_Date,
        status
             from tt_temp2 a
             left join esp.mvno_account b 
             on a.reg_mobileno = b.mobileno
             left join crm.freesim c 
             on b.iccid = c.iccid
             left join crm.subscriber d 
             on c.subscriberid = d.subscriberid
             where b.mobileno is not null
             and d.subscriberid is not null;
             SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
             
             if found_rows()> 0 then
             set v_errcode = 0;
             set v_errmsg = 'Success to get the sitecode info.';
             LEAVE sp_exit;
             end if;
             
          ELSE 
          
             IF v_Sitecode = 'MCM' 
             then
     
                SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
                select(CONCAT(IFNULL(d.firstname,v_out_handle_varchar),' ',IFNULL(d.lastname,v_out_handle_varchar)))  as Customername,
        a.reg_mobileno,
        IFNULL(a.Operator_name,v_out_handle_varchar) as Operator_name,
        a.COUNTRY_NAME as Country,
        IFNULL(a.Xtra_Number,v_out_handle_varchar) as Xtra_Number,
        IFNULL(a.imsi_number,v_out_handle_varchar) as imsi_number,
        v_Number_type as Number_type,
        a.Purchased_Date,
        status
                from tt_temp2 a
                left join esp.mvno_account b 
                on a.reg_mobileno = b.mobileno
                left join crm.freesim c 
                on b.iccid = c.iccid
                left join crm.subscriber d 
                on c.subscriberid = d.subscriberid
                where b.mobileno is not null
                and d.subscriberid is not null;
                SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
                if found_rows()> 0 then
                set v_errcode = 0;
                set v_errmsg = 'Success to get the sitecode info.';
                LEAVE sp_exit;
                end if;
                
             ELSE 
             
                IF v_Sitecode = 'BAU' 
                then 
                   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
                   select(CONCAT(IFNULL(d.firstname,v_out_handle_varchar),' ',IFNULL(d.lastname,v_out_handle_varchar)))  as Customername,
        a.reg_mobileno,
        IFNULL(a.Operator_name,v_out_handle_varchar) as Operator_name,
        a.COUNTRY_NAME as Country,
        IFNULL(a.Xtra_Number,v_out_handle_varchar) as Xtra_Number,
        IFNULL(a.imsi_number,v_out_handle_varchar) as imsi_number,
        v_Number_type as Number_type,
        a.Purchased_Date,
        status
                   from tt_temp2 a
                   left join esp.mvno_account b 
                   on a.reg_mobileno = b.mobileno
                   left join crm.freesim c 
                   on b.iccid = c.iccid
                   left join crm.subscriber d 
                   on c.subscriberid = d.subscriberid
                   where b.mobileno is not null
                   and d.subscriberid is not null;
                   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
                   if found_rows()> 0 then
                   set v_errcode = 0;
                   set v_errmsg = 'Success to get the sitecode info.';
                   LEAVE sp_exit;
                   end if;
                ELSE 
                
                   IF v_Sitecode = 'MFR' 
                   then
     
                      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
                      select(CONCAT(IFNULL(d.firstname,v_out_handle_varchar),' ',IFNULL(d.lastname,v_out_handle_varchar)))  as Customername,
        a.reg_mobileno,
        IFNULL(a.Operator_name,v_out_handle_varchar) as Operator_name,
        a.COUNTRY_NAME as Country,
        IFNULL(a.Xtra_Number,v_out_handle_varchar) as Xtra_Number,
        IFNULL(a.imsi_number,v_out_handle_varchar) as imsi_number,
        v_Number_type as Number_type,
        a.Purchased_Date,
        status
                      from tt_temp2 a
                      left join esp.mvno_account b 
                      on a.reg_mobileno = b.mobileno
                      left join crm.freesim c 
                      on b.iccid = c.iccid
                      left join crm.subscriber d 
                      on c.subscriberid = d.subscriberid
                      where b.mobileno is not null
                      and d.subscriberid is not null;
                      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
                      
                      if found_rows()> 0 then
                      set v_errcode = 0;
                      set v_errmsg = 'Success to get the sitecode info.';
                      LEAVE sp_exit;
                      end if;
                   ELSE
                   
                      set v_errcode = -1;
                      set v_errmsg = 'Failure to get sitecode details.';
                      LEAVE sp_exit;
                   end if;
                   
                end if;
             end if;
          end if;            
          
       END;
       
       select v_errcode as errcode,v_errmsg as errmsg;  
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-21  9:53:46
