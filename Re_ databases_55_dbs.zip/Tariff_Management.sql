-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: Tariff_Management
-- ------------------------------------------------------
-- Server version	8.0.44-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `Tariff_Management`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `Tariff_Management` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `Tariff_Management`;

--
-- Table structure for table `ref_bundle_min_category`
--

DROP TABLE IF EXISTS `ref_bundle_min_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ref_bundle_min_category` (
  `id` int NOT NULL AUTO_INCREMENT,
  `category_name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tm_upload_bundle_min_info_LOG`
--

DROP TABLE IF EXISTS `tm_upload_bundle_min_info_LOG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tm_upload_bundle_min_info_LOG` (
  `config_id` int DEFAULT NULL,
  `in_xml_data` text,
  `in_user_name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tm_web_bundle_category`
--

DROP TABLE IF EXISTS `tm_web_bundle_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tm_web_bundle_category` (
  `category_id` int NOT NULL AUTO_INCREMENT,
  `product_name` varchar(32) DEFAULT NULL,
  `category_name` varchar(100) DEFAULT NULL,
  `status` int DEFAULT NULL,
  `create_date` datetime(3) DEFAULT NULL,
  `create_by` varchar(10) DEFAULT NULL,
  `last_update` datetime(3) DEFAULT NULL,
  `APP_ENABLE` int NOT NULL DEFAULT '1',
  `VRP_ENABLE` int NOT NULL DEFAULT '1',
  `vec_user` int NOT NULL DEFAULT '0',
  `image_name` varchar(40) DEFAULT '',
  `crm_enable` int NOT NULL DEFAULT '0',
  `ussd_balance_check` varchar(10) DEFAULT NULL,
  `is_paym` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`category_id`),
  UNIQUE KEY `UX_bundle_category` (`product_name`,`category_name`),
  KEY `FK__tm_web_bu__produ__4A8310C6Idx` (`product_name`),
  KEY `FK__tm_web_bu__categ__4E53A1AAIdx2` (`category_id`),
  CONSTRAINT `FK__tm_web_bu__produ__4A8310C6` FOREIGN KEY (`product_name`) REFERENCES `tmunio_products` (`mundio_product`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=263 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tm_web_bundle_config`
--

DROP TABLE IF EXISTS `tm_web_bundle_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tm_web_bundle_config` (
  `config_id` int NOT NULL AUTO_INCREMENT,
  `category_id` int DEFAULT NULL,
  `product_name` varchar(32) DEFAULT NULL,
  `bundle_name` varchar(150) DEFAULT NULL,
  `bundle_price` varchar(100) DEFAULT NULL,
  `vec_ussd_prefix` varchar(150) DEFAULT NULL,
  `online_ussd_prefix` varchar(10) DEFAULT NULL,
  `bundle_call` varchar(500) DEFAULT NULL,
  `bundle_sms` varchar(50) DEFAULT NULL,
  `bundle_data` varchar(500) DEFAULT NULL,
  `v2v_call` varchar(50) DEFAULT NULL,
  `v2v_text` varchar(50) DEFAULT NULL,
  `discount_price_flag` int DEFAULT NULL,
  `discount_price` varchar(250) DEFAULT NULL,
  `speed_restriction_flag` int DEFAULT NULL,
  `speed_restriction_data` varchar(500) DEFAULT NULL,
  `special_country_flag` int DEFAULT NULL,
  `speical_call_min` varchar(50) DEFAULT NULL,
  `special_sms_text` varchar(50) DEFAULT NULL,
  `status` int DEFAULT NULL,
  `create_date` datetime(3) DEFAULT NULL,
  `created_by` varchar(50) DEFAULT NULL,
  `is_approve` varchar(10) DEFAULT NULL,
  `approve_date` datetime(3) DEFAULT NULL,
  `approve_by` varchar(50) DEFAULT NULL,
  `bundle_type_id` int DEFAULT NULL,
  `days_valid` int DEFAULT NULL,
  `auto_renewal` int DEFAULT NULL,
  `bundle_id` int DEFAULT NULL,
  `spc_bundle_flag` int DEFAULT NULL,
  `addon_bundle_id` int DEFAULT NULL,
  `addon_bundle_flag` int DEFAULT NULL,
  `lang_code` varchar(3) NOT NULL DEFAULT 'EN',
  `online_bundle` int DEFAULT NULL,
  `best_sale_flag` int DEFAULT NULL,
  `discount_percentage` float DEFAULT NULL,
  `discount_percentage_flag` int NOT NULL DEFAULT '0',
  `offline_bundle_call` varchar(500) DEFAULT NULL,
  `offline_bundle_sms` varchar(50) DEFAULT NULL,
  `offline_bundle_data` varchar(500) DEFAULT NULL,
  `offline_bundleid` int DEFAULT NULL,
  `is_top_dest_flag` int NOT NULL DEFAULT '0',
  `is_unlimited` int NOT NULL DEFAULT '0',
  `bundle_type` int NOT NULL DEFAULT '0',
  `is_live` int NOT NULL DEFAULT '0',
  `disc_price_numeric` float NOT NULL DEFAULT '0',
  `is_limited_min_flag` int DEFAULT NULL,
  `country_display` int NOT NULL DEFAULT '0',
  `roam_data_text` varchar(100) DEFAULT NULL,
  `roam_incom_text` varchar(250) DEFAULT NULL,
  `roam_allow` int NOT NULL DEFAULT '0',
  `app_enable` int NOT NULL DEFAULT '0',
  `is_email_mark_plan` int NOT NULL DEFAULT '0',
  `bundle_inter_call` varchar(250) DEFAULT NULL,
  `bundle_nat_inter_call` varchar(250) DEFAULT NULL,
  `v2v_value` varchar(250) DEFAULT NULL,
  `bundle_nat_call` varchar(250) DEFAULT NULL,
  `pricetype_text` varchar(100) DEFAULT NULL,
  `offline_price` varchar(100) DEFAULT NULL,
  `paym_bundeleid` int DEFAULT NULL,
  `sim_act_promo` int NOT NULL DEFAULT '0',
  `is_fav_bundle` int DEFAULT NULL,
  `image_url` varchar(1000) DEFAULT NULL,
  `simonly_status` int DEFAULT NULL,
  `simonly_discount` float DEFAULT NULL,
  `double_data_text` varchar(100) DEFAULT NULL,
  `data_rollover` int DEFAULT NULL,
  `data_rollover_maxvalue` varchar(100) DEFAULT NULL,
  `online_exclusive_offer` int DEFAULT NULL,
  `contract_len` varchar(50) DEFAULT NULL,
  `upfront_const` varchar(50) DEFAULT NULL,
  `Is_fiveg_deal` int DEFAULT NULL,
  `Is_EU_Roaming` int DEFAULT NULL,
  `Call_EU_Roaming` varchar(100) DEFAULT NULL,
  `SMS_EU_Roaming` varchar(100) DEFAULT NULL,
  `Data_EU_Roaming` varchar(100) DEFAULT NULL,
  `Inapp_apple_product_id` varchar(150) DEFAULT NULL,
  `Is_popular_bundle` int DEFAULT NULL,
  `First_purchase_data_usage` varchar(150) DEFAULT NULL,
  `app_home_display` int DEFAULT NULL,
  PRIMARY KEY (`config_id`),
  KEY `FK__tm_web_bu__categ__4E53A1AAIdx` (`category_id`),
  KEY `FK__tm_web_bu__produ__4F47C5E3Idx` (`product_name`),
  KEY `idx1_tm_web_bundle_config` (`product_name`,`category_id`),
  KEY `idx2_tm_web_bundle_config` (`config_id`),
  KEY `idx3_tm_web_bundle_config` (`bundle_id`),
  CONSTRAINT `FK__tm_web_bu__categ__4E53A1AA` FOREIGN KEY (`category_id`) REFERENCES `tm_web_bundle_category` (`category_id`),
  CONSTRAINT `FK__tm_web_bu__produ__4F47C5E3` FOREIGN KEY (`product_name`) REFERENCES `tmunio_products` (`mundio_product`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=1997 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tm_web_bundle_config_text`
--

DROP TABLE IF EXISTS `tm_web_bundle_config_text`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tm_web_bundle_config_text` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_name` varchar(32) DEFAULT NULL,
  `lang_code` varchar(20) DEFAULT NULL,
  `config_id` int DEFAULT NULL,
  `category_id` int DEFAULT NULL,
  `bundle_name` varchar(800) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `bundle_call` varchar(250) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `bundle_sms` varchar(250) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `bundle_data` varchar(250) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `v2v_call` varchar(250) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `v2v_text` varchar(250) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `create_date` datetime(3) DEFAULT NULL,
  `create_by` varchar(50) DEFAULT NULL,
  `bundle_price` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `offline_bundle_call` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `offline_bundle_sms` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `offline_bundle_data` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `do_data_text` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK__tm_web_bu__categ__467D75B8Idx` (`category_id`),
  KEY `FK__tm_web_bu__confi__4589517FIdx` (`config_id`),
  KEY `FK__tm_web_bu__lang___44952D46Idx` (`lang_code`),
  KEY `FK__tm_web_bu__produ__43A1090DIdx` (`product_name`),
  CONSTRAINT `FK__tm_web_bu__categ__467D75B8` FOREIGN KEY (`category_id`) REFERENCES `tm_web_bundle_category` (`category_id`),
  CONSTRAINT `FK__tm_web_bu__confi__4589517F` FOREIGN KEY (`config_id`) REFERENCES `tm_web_bundle_config` (`config_id`),
  CONSTRAINT `FK__tm_web_bu__lang___44952D46` FOREIGN KEY (`lang_code`) REFERENCES `tm_web_bundle_lang_config` (`lang_code`),
  CONSTRAINT `FK__tm_web_bu__produ__43A1090D` FOREIGN KEY (`product_name`) REFERENCES `tmunio_products` (`mundio_product`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tm_web_bundle_lang_config`
--

DROP TABLE IF EXISTS `tm_web_bundle_lang_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tm_web_bundle_lang_config` (
  `lang_id` int DEFAULT NULL,
  `lang_code` varchar(20) NOT NULL,
  `language_name` varchar(250) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  PRIMARY KEY (`lang_code`),
  KEY `FK__tm_web_bu__lang___44952D46Idx2` (`lang_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tm_web_bundle_min_info`
--

DROP TABLE IF EXISTS `tm_web_bundle_min_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tm_web_bundle_min_info` (
  `fk_config_id` int NOT NULL,
  `country_code` varchar(4) NOT NULL,
  `bundle_min_category` int DEFAULT NULL,
  `fixed` varchar(50) DEFAULT NULL,
  `mobile` varchar(50) DEFAULT NULL,
  `create_date` datetime(3) DEFAULT NULL,
  `create_by` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`fk_config_id`,`country_code`),
  CONSTRAINT `tm_web_bundle_min_info_ibfk_1` FOREIGN KEY (`fk_config_id`) REFERENCES `tm_web_bundle_config` (`config_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tmunio_products`
--

DROP TABLE IF EXISTS `tmunio_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmunio_products` (
  `mundio_product` varchar(32) NOT NULL,
  `sitecode` varchar(16) NOT NULL,
  `product_name` varchar(64) DEFAULT NULL,
  `is_active` int DEFAULT NULL,
  `home_country` varchar(64) DEFAULT NULL,
  `curr_symbol` varchar(10) DEFAULT NULL,
  `iso2_country_code` varchar(10) DEFAULT NULL,
  `curr_txt` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `intr_nat_curr_txt` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `decimal_convertion` int NOT NULL DEFAULT '0',
  `vectoneapp_symbol` varchar(10) DEFAULT NULL,
  `night_mode_rate` int NOT NULL DEFAULT '0',
  `vec_app_fmt_chng_flag` int DEFAULT '0',
  `nat_curr_txt` varchar(10) DEFAULT NULL,
  `nat_rate_fmt_chng_flag` int DEFAULT NULL,
  `fixed_text` varchar(50) DEFAULT NULL,
  `mobile_text` varchar(50) DEFAULT NULL,
  `sms_text` varchar(50) DEFAULT NULL,
  `data_text` varchar(10) DEFAULT NULL,
  `alt_symbol_flag` int NOT NULL DEFAULT '0',
  `need_replace` int NOT NULL DEFAULT '0',
  `std_normal_format` int NOT NULL DEFAULT '0',
  `roam_currency_format` int DEFAULT '0',
  `alt_discount_rate` int DEFAULT NULL,
  `alt_discount_name` varchar(250) DEFAULT NULL,
  `div_input` int DEFAULT NULL,
  `roam_rate_replace` int DEFAULT NULL,
  `cheaprt_dec_format` int NOT NULL DEFAULT '0',
  `roamrt_dec_format` int DEFAULT NULL,
  `vapp_rate_dec_format` int DEFAULT NULL,
  `vapp_nat_rate_dec_format` int NOT NULL DEFAULT '0',
  `multiple_std_input` int NOT NULL DEFAULT '0',
  `compititor_pidx` int NOT NULL DEFAULT '0',
  `connection_charge` varchar(20) DEFAULT NULL,
  `vec_app_rate_format` int NOT NULL DEFAULT '0',
  `push_notify` int NOT NULL DEFAULT '0',
  `app_curr_symbol` varchar(50) DEFAULT NULL,
  `app_multiple_std_input` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`mundio_product`),
  KEY `FK__tm_web_bu__produ__4A8310C6Idx2` (`mundio_product`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wtms_tm_upload_bundle_min_info_LOG`
--

DROP TABLE IF EXISTS `wtms_tm_upload_bundle_min_info_LOG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wtms_tm_upload_bundle_min_info_LOG` (
  `id` int NOT NULL AUTO_INCREMENT,
  `Tier_id` int DEFAULT NULL,
  `feature_id` int DEFAULT NULL,
  `in_xml_data` text,
  `status` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wtms_tm_web_bundle_min_info`
--

DROP TABLE IF EXISTS `wtms_tm_web_bundle_min_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wtms_tm_web_bundle_min_info` (
  `id` int NOT NULL AUTO_INCREMENT,
  `Tier_id` int DEFAULT NULL,
  `country_code` varchar(50) DEFAULT NULL,
  `feature_id` int DEFAULT NULL,
  `fixed` varchar(50) DEFAULT NULL,
  `mobile` varchar(50) DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping events for database 'Tariff_Management'
--

--
-- Dumping routines for database 'Tariff_Management'
--
/*!50003 DROP PROCEDURE IF EXISTS `tm_upload_bundle_min_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `tm_upload_bundle_min_info`(
 config_id int,
 in_xml_data text,
 in_user_name varchar(50)
 )
begin
 
 	Declare error_code INT; 
 	Declare error_msg VARCHAR(250);
 	Declare insert_list text; 
 	Declare xml_list text; 
 	Declare update_col text; 
 
 	Declare v_country text;
 	Declare v_category_id text;
 	Declare v_ll_price text; 
 	Declare v_mble_price text;
 
 	INSERT INTO tm_upload_bundle_min_info_LOG(config_id,in_xml_data,in_user_name) 
 	VALUES(config_id,in_xml_data,in_user_name);
 
 	select error_code = 0, error_msg = 'Bulk upload success'; 
 
 	drop temporary table if exists bulk_load_min;
 	CREATE temporary TABLE bulk_load_min 
 	( 
 		idx INT auto_increment primary key, 
 		country VARCHAR(50), 
 		category_id int,
 		ll_price varchar(50), 
 		mble_price varchar(50)
 	) ;
 
 
 drop temporary table if exists xml_country_tbl;			create temporary table xml_country_tbl(id int auto_increment primary key, country varchar(100)); 
 drop temporary table if exists xml_category_id_tbl;		create temporary table xml_category_id_tbl(id int auto_increment primary key, category_id varchar(100)); 
 drop temporary table if exists xml_ll_price_tbl;		create temporary table xml_ll_price_tbl(id int auto_increment primary key, ll_price varchar(100)); 
 drop temporary table if exists xml_mble_price_tbl;		create temporary table xml_mble_price_tbl(id int auto_increment primary key, mble_price varchar(100)); 
 
 
  SELECT replace(ExtractValue(in_xml_data, '//country[1]'),' ',','), replace(ExtractValue(in_xml_data, '//category_id[1]'),' ',','),
         replace(ExtractValue(in_xml_data, '//ll_price[1]'),' ',','), replace(ExtractValue(in_xml_data, '//mble_price[1]'),' ',',')
 into v_country, v_category_id, v_ll_price, v_mble_price;
 
 
 call Split(v_country,',');			insert into xml_country_tbl(country) 			select Items from tt_Split_temptable;
 call Split(v_category_id,',');		insert into xml_category_id_tbl(category_id) 	select Items from tt_Split_temptable;
 call Split(v_ll_price,',');			insert into xml_ll_price_tbl(ll_price) 			select Items from tt_Split_temptable;
 call Split(v_mble_price,',');		insert into xml_mble_price_tbl(mble_price) 		select Items from tt_Split_temptable;
 
 
 	INSERT INTO bulk_load_min (country, category_id,ll_price, mble_price) 
 	SELECT a.country,b.category_id,c.ll_price,d.mble_price
 	from xml_country_tbl a
 	left join xml_category_id_tbl b on a.id = b.id
 	left join xml_ll_price_tbl c on a.id = c.id
 	left join xml_mble_price_tbl d on a.id = d.id;
 
 					 
 	delete from tm_web_bundle_min_info where fk_config_id=config_id;
                  
 	insert into tm_web_bundle_min_info(fk_config_id,country_code,bundle_min_category,fixed,mobile,create_date,create_by)
 	select config_id,a.country,a.category_id,a.ll_price,a.mble_price,CURRENT_TIMESTAMP,in_user_name 
 	from bulk_load_min a ;
 	
 	if row_count()>0 then
 		set error_code=0;
 		set error_msg='Success';
 	end if;
 
 
 	select error_code as errcode,error_msg as errmsg;
 
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-21  9:53:22
