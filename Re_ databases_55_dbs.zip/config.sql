-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: config
-- ------------------------------------------------------
-- Server version	8.0.44-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `config`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `config` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `config`;

--
-- Table structure for table `Email_Config_Dtl`
--

DROP TABLE IF EXISTS `Email_Config_Dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Email_Config_Dtl` (
  `Idx` int NOT NULL AUTO_INCREMENT,
  `Reseller_Id` int NOT NULL,
  `Brand_Name` varchar(100) NOT NULL,
  `Brand_Logo` varchar(1000) DEFAULT NULL,
  `From_Email_Id` varchar(255) NOT NULL,
  `Email_Body_Start` varchar(2000) DEFAULT NULL,
  `Email_Body_End` varchar(2000) DEFAULT NULL,
  `Email_Signature` varchar(500) DEFAULT NULL,
  `Footer` varchar(200) DEFAULT NULL,
  `Created_Date` datetime(3) NOT NULL,
  `Modified_Date` datetime(3) NOT NULL,
  UNIQUE KEY `Idx` (`Idx`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `RMS_Master_Plans_Bundles`
--

DROP TABLE IF EXISTS `RMS_Master_Plans_Bundles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RMS_Master_Plans_Bundles` (
  `Category` varchar(30) DEFAULT NULL,
  `Product` varchar(30) DEFAULT NULL,
  `Product_Code` varchar(30) DEFAULT NULL,
  `Descript` varchar(512) DEFAULT NULL,
  `Tariff_class` varchar(20) DEFAULT NULL,
  `Price` double DEFAULT NULL,
  `IsActive` bit(1) DEFAULT NULL,
  `Bundle_Category` varchar(30) DEFAULT NULL,
  `Product_type` varchar(32) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `RMS_Reporting_By_Usage_Data_Dtl`
--

DROP TABLE IF EXISTS `RMS_Reporting_By_Usage_Data_Dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RMS_Reporting_By_Usage_Data_Dtl` (
  `IDX` int NOT NULL AUTO_INCREMENT,
  `Reseller_id` int DEFAULT NULL,
  `cnxdate` datetime(3) DEFAULT NULL,
  `Msisdn` varchar(50) DEFAULT NULL,
  `custcode` varchar(8) DEFAULT NULL,
  `batchcode` int DEFAULT NULL,
  `serialcode` int DEFAULT NULL,
  `gprs_allocation` float DEFAULT NULL,
  `gprs_charge` float DEFAULT NULL,
  `balance` float DEFAULT NULL,
  `totalcons` float DEFAULT NULL,
  `tariffclass` varchar(4) DEFAULT NULL,
  `sample_unit` float DEFAULT NULL,
  `roaming_zone` int DEFAULT NULL,
  `company_id` int DEFAULT NULL,
  `Country_Code` varchar(2) DEFAULT NULL,
  `Call_Group_No` int DEFAULT NULL,
  UNIQUE KEY `IDX` (`IDX`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `RMS_Reporting_By_Usage_SMS_Dtl`
--

DROP TABLE IF EXISTS `RMS_Reporting_By_Usage_SMS_Dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RMS_Reporting_By_Usage_SMS_Dtl` (
  `IDX` int NOT NULL AUTO_INCREMENT,
  `Reseller_id` int DEFAULT NULL,
  `cnxdate` datetime(3) DEFAULT NULL,
  `cli` varchar(32) DEFAULT NULL,
  `custcode` char(8) DEFAULT NULL,
  `batchcode` int DEFAULT NULL,
  `serialcode` int DEFAULT NULL,
  `dialednum` char(30) DEFAULT NULL,
  `destcode` varchar(64) DEFAULT NULL,
  `talktime` int DEFAULT NULL,
  `talkcharge` float DEFAULT NULL,
  `balance` float DEFAULT NULL,
  `totalcons` double DEFAULT NULL,
  `trffclass` char(4) DEFAULT NULL,
  `charge` int DEFAULT NULL,
  `company_id` int DEFAULT NULL,
  `Country_Code` varchar(2) DEFAULT NULL,
  `Call_Group_No` int DEFAULT NULL,
  UNIQUE KEY `IDX` (`IDX`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `RMS_Reporting_By_Usage_Voice_Dtl`
--

DROP TABLE IF EXISTS `RMS_Reporting_By_Usage_Voice_Dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RMS_Reporting_By_Usage_Voice_Dtl` (
  `IDX` int NOT NULL AUTO_INCREMENT,
  `Resellerid` int DEFAULT NULL,
  `calldate` datetime(3) DEFAULT NULL,
  `cnxdate` datetime(3) DEFAULT NULL,
  `telcocode` char(4) DEFAULT NULL,
  `custcode` char(8) DEFAULT NULL,
  `sitecode` varchar(3) NOT NULL,
  `ani` char(30) DEFAULT NULL,
  `dialednum` char(30) DEFAULT NULL,
  `destcode` varchar(64) DEFAULT NULL,
  `trffclass` char(4) DEFAULT NULL,
  `balance` float DEFAULT NULL,
  `talktime` int DEFAULT NULL,
  `batchcode` int DEFAULT NULL,
  `serialcode` int DEFAULT NULL,
  `charge` int DEFAULT NULL,
  `talkcharge` float DEFAULT NULL,
  `sampunit` float DEFAULT NULL,
  `totalcons` double DEFAULT NULL,
  `company_id` int DEFAULT NULL,
  `Country_Code` varchar(2) DEFAULT NULL,
  `Call_Group_No` int DEFAULT NULL,
  UNIQUE KEY `IDX` (`IDX`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `RMS_Reseller_Configuration`
--

DROP TABLE IF EXISTS `RMS_Reseller_Configuration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RMS_Reseller_Configuration` (
  `Reseller_Id` int NOT NULL,
  `Sub_Domain_Name` varchar(60) DEFAULT NULL,
  `Database_Name` varchar(60) DEFAULT NULL,
  `idx` int DEFAULT NULL,
  `Domain_Name` varchar(60) DEFAULT NULL,
  `Routing_Port` varchar(10) DEFAULT NULL,
  `Resellerid` int DEFAULT NULL,
  `Prefix_Routing` varchar(2) DEFAULT NULL,
  `Cout_Prefix` varchar(30) DEFAULT NULL,
  `Tariff_Class` varchar(5) DEFAULT NULL,
  `CRM_MRT_Temp_Path` varchar(255) DEFAULT NULL,
  `CRM_MRT_RPT_Path` varchar(255) DEFAULT NULL,
  `CRM_EMail_HTML_Path` varchar(255) DEFAULT NULL,
  `MyAC_EMail_HTML_Path` varchar(255) DEFAULT NULL,
  `CRM_To_MyAcc` varchar(500) DEFAULT NULL,
  `Company_Idx_Minus_1` varchar(60) DEFAULT NULL,
  `Company_Idx_0` varchar(60) DEFAULT NULL,
  `Company_Idx_1` varchar(60) DEFAULT NULL,
  `Company_Idx_2` varchar(60) DEFAULT NULL,
  `Company_Idx_3` varchar(60) DEFAULT NULL,
  `BrandName` varchar(60) DEFAULT NULL,
  `Bill_Ref_Prefix` varchar(6) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`),
  KEY `IDXRMS_Reseller_Configuration_Reseller_Id` (`Reseller_Id`),
  KEY `RMS_Reseller_Configuration_Ind` (`Reseller_Id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `RMS_Reseller_Details`
--

DROP TABLE IF EXISTS `RMS_Reseller_Details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RMS_Reseller_Details` (
  `Reseller_Id` int NOT NULL AUTO_INCREMENT,
  `Brand_Name` varchar(60) DEFAULT NULL,
  `Brand_Short_Code` varchar(30) DEFAULT NULL,
  `Brand_Domain` varchar(60) DEFAULT NULL,
  `Status` varchar(30) DEFAULT NULL,
  `Org_Type` varchar(10) DEFAULT NULL,
  `Org_Name` varchar(60) DEFAULT NULL,
  `Registration_No` varchar(30) DEFAULT NULL,
  `Post_Code` varchar(30) DEFAULT NULL,
  `Address_Code` varchar(30) DEFAULT NULL,
  `Building_Name` varchar(60) DEFAULT NULL,
  `Street` varchar(60) DEFAULT NULL,
  `Town_City` varchar(60) DEFAULT NULL,
  `Country` varchar(60) DEFAULT NULL,
  `Contact_Number` varchar(30) DEFAULT NULL,
  `Contact_EMail` varchar(60) DEFAULT NULL,
  `VAT_No` varchar(30) DEFAULT NULL,
  `Created_Date` datetime(3) DEFAULT NULL,
  `Created_By` varchar(60) DEFAULT NULL,
  `Modified_Date` datetime(3) DEFAULT NULL,
  `Modified_By` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`Reseller_Id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `RMS_Reseller_Master_Products`
--

DROP TABLE IF EXISTS `RMS_Reseller_Master_Products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RMS_Reseller_Master_Products` (
  `Product_Id` int NOT NULL AUTO_INCREMENT,
  `Product_Name` varchar(50) NOT NULL,
  `Product_Descript` varchar(255) NOT NULL,
  `Created_Date` datetime(3) NOT NULL,
  `Modified_Date` datetime(3) DEFAULT NULL,
  `IsActive` smallint DEFAULT NULL,
  PRIMARY KEY (`Product_Id`),
  UNIQUE KEY `UK_Product_Name` (`Product_Name`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `RMS_Reseller_Plans_Bundles`
--

DROP TABLE IF EXISTS `RMS_Reseller_Plans_Bundles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RMS_Reseller_Plans_Bundles` (
  `Reseller_Id` int NOT NULL,
  `Product_Code` varchar(30) NOT NULL,
  `IsActive` bit(1) DEFAULT NULL,
  `Created_Date` datetime DEFAULT NULL,
  `Created_By` varchar(60) DEFAULT NULL,
  `Price` double DEFAULT NULL,
  PRIMARY KEY (`Reseller_Id`,`Product_Code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `RMS_Reseller_Products`
--

DROP TABLE IF EXISTS `RMS_Reseller_Products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RMS_Reseller_Products` (
  `Reseller_Id` int NOT NULL,
  `Product_Id` int NOT NULL,
  `Created_Date` datetime(3) DEFAULT NULL,
  `Created_By` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`Reseller_Id`,`Product_Id`),
  KEY `FK__RMS_Resel__Resel__70A8B9AEIdx` (`Reseller_Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `m_crm_connections`
--

DROP TABLE IF EXISTS `m_crm_connections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `m_crm_connections` (
  `Idx` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) DEFAULT NULL,
  `Alias` varchar(155) DEFAULT NULL,
  `IP` varchar(50) DEFAULT NULL,
  `DbName` varchar(155) DEFAULT NULL,
  `Instance` varchar(155) DEFAULT NULL,
  `Username` varchar(155) DEFAULT NULL,
  `Password` varchar(155) DEFAULT NULL,
  `Provider` varchar(155) DEFAULT NULL,
  `Enable` int DEFAULT NULL,
  `Description` varchar(255) DEFAULT NULL,
  `IsProduction` varchar(4) DEFAULT NULL,
  UNIQUE KEY `Idx` (`Idx`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping events for database 'config'
--

--
-- Dumping routines for database 'config'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-21  9:50:01
