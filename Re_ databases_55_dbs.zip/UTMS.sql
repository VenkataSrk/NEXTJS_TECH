-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: UTMS
-- ------------------------------------------------------
-- Server version	8.0.44-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `UTMS`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `UTMS` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `UTMS`;

--
-- Table structure for table `Role_Menu_Mapping`
--

DROP TABLE IF EXISTS `Role_Menu_Mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Role_Menu_Mapping` (
  `Fk_Role_ID` int NOT NULL,
  `Fk_Menu_ID` int NOT NULL,
  `Last_update` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`Fk_Role_ID`,`Fk_Menu_ID`),
  KEY `FK_Menu_Role_MappingIdx` (`Fk_Menu_ID`),
  KEY `FK__Role_Menu__Fk_Ro__1CF15040Idx` (`Fk_Role_ID`),
  CONSTRAINT `FK__Role_Menu__Fk_Ro__1CF15040` FOREIGN KEY (`Fk_Role_ID`) REFERENCES `Userrole` (`Pk_role_id`),
  CONSTRAINT `FK_Menu_Role_Mapping` FOREIGN KEY (`Fk_Menu_ID`) REFERENCES `tbl_Menu` (`Pk_Menu_Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `TBL_TEST`
--

DROP TABLE IF EXISTS `TBL_TEST`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TBL_TEST` (
  `type` varchar(150) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `UTMS_WEB_RATE_CONFIG`
--

DROP TABLE IF EXISTS `UTMS_WEB_RATE_CONFIG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UTMS_WEB_RATE_CONFIG` (
  `id` int NOT NULL AUTO_INCREMENT,
  `calling_type` varchar(50) NOT NULL,
  `country` varchar(250) NOT NULL,
  `prefix` varchar(20) NOT NULL,
  `fixed_rate` varchar(150) DEFAULT NULL,
  `mobile_rate` varchar(150) DEFAULT NULL,
  `create_date` datetime(3) DEFAULT NULL,
  `create_by` varchar(150) DEFAULT NULL,
  `rate` varchar(150) DEFAULT NULL,
  `Type` varchar(250) NOT NULL,
  `filename` varchar(250) DEFAULT NULL,
  UNIQUE KEY `id` (`id`),
  KEY `idx1_UTMS_WEB_RATE_CONFIG` (`calling_type`,`country`,`Type`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=1507134 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `UTMS_WEB_RATE_CONFIG_test`
--

DROP TABLE IF EXISTS `UTMS_WEB_RATE_CONFIG_test`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UTMS_WEB_RATE_CONFIG_test` (
  `id` int NOT NULL AUTO_INCREMENT,
  `calling_type` varchar(50) NOT NULL,
  `country` varchar(250) NOT NULL,
  `prefix` varchar(20) NOT NULL,
  `fixed_rate` varchar(150) DEFAULT NULL,
  `mobile_rate` varchar(150) DEFAULT NULL,
  `create_date` datetime(3) DEFAULT NULL,
  `create_by` varchar(150) DEFAULT NULL,
  `rate` varchar(150) DEFAULT NULL,
  `Type` varchar(250) NOT NULL,
  `filename` varchar(250) DEFAULT NULL,
  UNIQUE KEY `id` (`id`),
  KEY `idx1_UTMS_WEB_RATE_CONFIG` (`calling_type`,`country`,`Type`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `UTMS_create_sme_plan_log`
--

DROP TABLE IF EXISTS `UTMS_create_sme_plan_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UTMS_create_sme_plan_log` (
  `User_Id` int DEFAULT NULL,
  `Product_Id` int DEFAULT NULL,
  `Pc_From_Users` int DEFAULT NULL,
  `Pc_To_Users` int DEFAULT NULL,
  `PC_Price` float DEFAULT NULL,
  `features` longtext,
  `Process_Type` int DEFAULT NULL,
  `National_min` int DEFAULT NULL,
  `Geo_Min` int DEFAULT NULL,
  `Plan_Name` varchar(150) DEFAULT NULL,
  `Request_ID` int DEFAULT NULL,
  `Unlimted_Intra_Call` int DEFAULT NULL,
  `is_free_trial` int DEFAULT NULL,
  `monthly_price` float DEFAULT NULL,
  `yearly_price` float DEFAULT NULL,
  `monthly_yearly_price` float DEFAULT NULL,
  `most_popular` int DEFAULT NULL,
  `created_by` varchar(50) DEFAULT NULL,
  `status` int DEFAULT NULL,
  `Audio_conf` int DEFAULT NULL,
  `Audio_conf_value` varchar(50) DEFAULT NULL,
  `Video_conf` int DEFAULT NULL,
  `Video_conf_value` varchar(50) DEFAULT NULL,
  `Calling_UK_mins` float DEFAULT NULL,
  `yearly_discount` float DEFAULT NULL,
  `monthly_yearly_discount` float DEFAULT NULL,
  `freeph_non_geo_loc_min` float DEFAULT NULL,
  `Unlimited_inbound_conf` int DEFAULT NULL,
  `Unlimited_inbound_conf_value` float DEFAULT NULL,
  `free_trial_days` int DEFAULT NULL,
  `is_reseller` int DEFAULT NULL,
  `FT_audio_conf` int DEFAULT NULL,
  `FT_audio_conf_value` int DEFAULT NULL,
  `FT_video_conf` int DEFAULT NULL,
  `FT_video_conf_value` int DEFAULT NULL,
  `FT_Unlimted_Intra_Call` int DEFAULT NULL,
  `FT_Unlimted_Intra_Call_min` int DEFAULT NULL,
  `Free_trial_min` int DEFAULT NULL,
  `reseller_discount_flag` int DEFAULT NULL,
  `reseller_discount_xml` longtext,
  `two_year_monthly_price` float DEFAULT NULL,
  `three_year_monthly_price` float DEFAULT NULL,
  `two_year_monthly_discount` float DEFAULT NULL,
  `three_year_monthly_discount` float DEFAULT NULL,
  `User_Range_xml` longtext,
  `plan_addon_price_xml` longtext,
  `Video_conf_meetings` varchar(100) DEFAULT NULL,
  `Video_conf_participants` varchar(100) DEFAULT NULL,
  `Audio_conf_participants` varchar(100) DEFAULT NULL,
  `FT_video_conf_meetings` varchar(100) DEFAULT NULL,
  `FT_video_conf_participants` varchar(100) DEFAULT NULL,
  `FT_Audio_conf_participants` varchar(100) DEFAULT NULL,
  `Feature_xml` longtext,
  `Video_conf_duration` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `UTMS_myacc_customer_calling_type_rates`
--

DROP TABLE IF EXISTS `UTMS_myacc_customer_calling_type_rates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UTMS_myacc_customer_calling_type_rates` (
  `id` int NOT NULL AUTO_INCREMENT,
  `calling_type` varchar(50) DEFAULT NULL,
  `prefix` int DEFAULT NULL,
  `fixed_rate` float DEFAULT NULL,
  `mobile_rate` float DEFAULT NULL,
  `action` int DEFAULT NULL,
  UNIQUE KEY `id` (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Userprofile`
--

DROP TABLE IF EXISTS `Userprofile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Userprofile` (
  `Userid` int NOT NULL AUTO_INCREMENT,
  `First_name` varchar(100) DEFAULT NULL,
  `Last_name` varchar(100) DEFAULT NULL,
  `Username` varchar(50) DEFAULT NULL,
  `Password` varchar(20) DEFAULT NULL,
  `Fk_role_Id` int DEFAULT NULL,
  `last_login_ip` varchar(100) DEFAULT NULL,
  `Signup_date` datetime(3) DEFAULT NULL,
  `last_login_date` datetime(3) DEFAULT NULL,
  `status` int DEFAULT NULL,
  PRIMARY KEY (`Userid`),
  UNIQUE KEY `UK_Userprofile` (`Username`),
  KEY `FK__Userprofi__Fk_ro__22AA2996Idx` (`Fk_role_Id`),
  CONSTRAINT `FK__Userprofi__Fk_ro__22AA2996` FOREIGN KEY (`Fk_role_Id`) REFERENCES `Userrole` (`Pk_role_id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Userrole`
--

DROP TABLE IF EXISTS `Userrole`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Userrole` (
  `Pk_role_id` int NOT NULL,
  `Role_name` varchar(100) DEFAULT NULL,
  `Role_created_date` datetime(3) DEFAULT NULL,
  `role_status` int DEFAULT '1',
  PRIMARY KEY (`Pk_role_id`),
  KEY `FK__Role_Menu__Fk_Ro__1CF15040Idx2` (`Pk_role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `country_config`
--

DROP TABLE IF EXISTS `country_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `country_config` (
  `country_code` varchar(5) DEFAULT NULL,
  `country_name` varchar(100) NOT NULL,
  PRIMARY KEY (`country_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tariff_upload_info`
--

DROP TABLE IF EXISTS `tariff_upload_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tariff_upload_info` (
  `trffclass` varchar(4) NOT NULL,
  `access_type` int NOT NULL,
  `upload_type` int DEFAULT NULL,
  `esp_idx` int DEFAULT NULL,
  `filename` varchar(250) DEFAULT NULL,
  `temp_filename` varchar(250) DEFAULT NULL,
  `create_by` varchar(150) DEFAULT NULL,
  `create_date` datetime(3) DEFAULT NULL,
  `last_update` datetime(3) DEFAULT NULL,
  `update_by` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`trffclass`,`access_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_Menu`
--

DROP TABLE IF EXISTS `tbl_Menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_Menu` (
  `Menu_Name` varchar(250) DEFAULT NULL,
  `Menu_link` varchar(250) DEFAULT NULL,
  `Pk_Menu_Id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`Pk_Menu_Id`),
  KEY `FK_Menu_Role_MappingIdx2` (`Pk_Menu_Id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ur_access_type_Config`
--

DROP TABLE IF EXISTS `ur_access_type_Config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ur_access_type_Config` (
  `access_type` int NOT NULL,
  `access_type_name` varchar(150) DEFAULT NULL,
  `sitecode` varchar(3) DEFAULT NULL,
  PRIMARY KEY (`access_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `utms_portal_create_bundle_plan_log`
--

DROP TABLE IF EXISTS `utms_portal_create_bundle_plan_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `utms_portal_create_bundle_plan_log` (
  `sitecode` varchar(3) DEFAULT NULL,
  `bundle_name` varchar(150) DEFAULT NULL,
  `currency` varchar(3) DEFAULT NULL,
  `price` float DEFAULT NULL,
  `tariffclass_groupid` int DEFAULT NULL,
  `renewal_delay` int DEFAULT NULL,
  `renewal_mode` int DEFAULT NULL,
  `pro_rata` int DEFAULT NULL,
  `national_min` float DEFAULT NULL,
  `international_min` float DEFAULT NULL,
  `bundle_type` int DEFAULT NULL,
  `reseller_flag` int DEFAULT NULL,
  `bundle_status` int DEFAULT NULL,
  `tariffclass` varchar(4) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping events for database 'UTMS'
--

--
-- Dumping routines for database 'UTMS'
--
/*!50003 DROP FUNCTION IF EXISTS `SWF_ErrorMsg` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` FUNCTION `SWF_ErrorMsg`() RETURNS varchar(5000) CHARSET utf8mb4
    DETERMINISTIC
BEGIN
	DECLARE errmsg VARCHAR(5000);
	GET DIAGNOSTICS CONDITION 1 errmsg = MESSAGE_TEXT;
	RETURN errmsg ;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `SWF_STUFF` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` FUNCTION `SWF_STUFF`(char_expr varchar(4000), start_ch int, end_ch int, repl_expr varchar(4000)) RETURNS varchar(4000) CHARSET utf8mb4
    DETERMINISTIC
begin
 if start_ch > CHAR_LENGTH(char_expr) or start_ch <= 0 then
 return null;
 end if;
 if repl_expr is null then 
 return concat(left(char_expr,start_ch-1),substr(char_expr,start_ch+end_ch));
 end if;
 return concat(left(char_expr,start_ch-1),repl_expr,substr(char_expr,start_ch+end_ch));
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `IsFileExist` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `IsFileExist`(v_Path   VARCHAR(128),  
v_FileName  VARCHAR(128),  
INOUT v_Result   INT)
begin

        
   DECLARE v_objFSys INT;        
   DECLARE v_i INT;        
   DECLARE v_File VARCHAR(1000);        
         
   SET v_File = CONCAT_WS('',v_Path,v_FileName);        
   CALL sp_OACreate('Scripting.FileSystemObject',v_objFSys);        
   CALL sp_OAMethod(v_objFSys,'FileExists',v_i,v_File);        
   if v_i = 1 then
      set v_Result = 1; 
   else
      set v_Result = 0;
   end if; 
   CALL sp_OADestroy(v_objFSys);         
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Reseller_create_Incentive_Scheme` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `Reseller_create_Incentive_Scheme`(
comm_info_xml LONGTEXT,  
Scheme_name  VARCHAR(160),  
processType INT ,  
processby VARCHAR(50),  
Scheme_ID INT)
BEGIN

  
   
   
   DECLARE v_hDoc INT;   
   DECLARE v_errcode INT;   
   DECLARE v_errmsg VARCHAR(160);  
 insert into SWT_OpenXml(XMLDoc) values(comm_info_xml);

   select max(HID) into v_hDoc from SWT_OpenXml;  

  DROP TEMPORARY TABLE IF EXISTS tt_temp_reseller_structure;  

   create TEMPORARY table tt_temp_reseller_structure
   (
      id INT   AUTO_INCREMENT PRIMARY KEY,
      TypeID INT,
      inc_percentage FLOAT,
      Inc_app_Month INT,
      After_Inc_apply_Month_Per FLOAT
   )  AUTO_INCREMENT = 1;  
    
   
  
    
   call SWF_OpenXml((select XMLDoc from SWT_OpenXml where HID = v_hDoc),'Reseller/commison');
   INSERT INTO tt_temp_reseller_structure(TypeID,inc_percentage,Inc_app_Month,After_Inc_apply_Month_Per)
   SELECT * FROM(select ExtractValue(node,'*/TypeID') as TypeID, ExtractValue(node,'*/inc_percentage') as inc_percentage, ExtractValue(node,'*/Inc_app_Month') as Inc_app_Month, ExtractValue(node,'*/After_Inc_apply_Month_Per') as After_Inc_apply_Month_Per from SWT_XmlNodes a) SWA_XmlAl;   
         
   delete FROM SWT_OpenXml where HID = v_hDoc;   
    
    
   IF processType = 1 then
  
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select   Is_ID INTO Scheme_ID FROM Inc_Scheme_Master WHERE status = 1   order by Is_ID desc LIMIT 1;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
      set Scheme_ID = IFNULL(Scheme_ID,0)+1;
      INSERT INTO  Inc_Scheme_Master(Is_ID,Scheme_Name,Typeid,Inc_app_Month,inc_percentage,
    After_Inc_apply_Month_Per,create_Date,create_by,status)
      SELECT Scheme_ID,Scheme_name,TypeID,Inc_app_Month,inc_percentage,After_Inc_apply_Month_Per,CURRENT_TIMESTAMP,
    processby,1
      FROM tt_temp_reseller_structure;
      IF ROW_COUNT() > 0 then
    
         SET v_errcode = 0;
         SET v_errmsg = 'Success to create the Incentive Structre';
      end if;
   end if;  
    
   IF processType = 2 AND IFNULL(Scheme_ID,0) > 0 then
  
      DELETE FROM Inc_Scheme_Master WHERE Is_ID = Scheme_ID;
      INSERT INTO  Inc_Scheme_Master(Is_ID,Scheme_Name,Typeid,Inc_app_Month,inc_percentage,
    After_Inc_apply_Month_Per,create_Date,create_by,status)
      SELECT Scheme_ID,Scheme_name,TypeID,Inc_app_Month,inc_percentage,After_Inc_apply_Month_Per,CURRENT_TIMESTAMP,
    processby,1
      FROM tt_temp_reseller_structure;
      IF ROW_COUNT() > 0 then
    
         SET v_errcode = 0;
         SET v_errmsg = 'Success to update the Incentive Structre';
      end if;
   end if;   
    
   IF processType = 3 AND IFNULL(Scheme_ID,0) > 0 then
  
      DELETE FROM Inc_Scheme_Master WHERE Is_ID = Scheme_ID;
      IF ROW_COUNT() > 0 then
   
         SET v_errcode = 0;
         SET v_errmsg = 'Success to delete the Incentive Structre';
      end if;
   end if;  
   
select v_errcode as errcode,v_errmsg as errmsg;   
  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_reseller_get_plan_info_testcheck` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_reseller_get_plan_info_testcheck`(
Reseller_id INT,  
 Product_ID INT,
 Plan_id INT ,
 is_tms_flag INT
 )
BEGIN
 
    
  
    IF Product_ID is null then
       set Product_ID = 0;
    END IF;
    IF Plan_id is null then
       set Plan_id = 0;
    END IF;
    IF is_tms_flag is null then
       set is_tms_flag = 0;
    END IF;
    CALL unifiedring.sme_reseller_get_plan_info_testcheck(0,Product_ID,Plan_id,is_tms_flag);
  
 
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `united_myaccount_Insert_Routing_switchboard` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `united_myaccount_Insert_Routing_switchboard`(v_switchboard_ID INT,              
 v_route_switchboard INT,              
 v_extension VARCHAR(5),              
 v_no INT ,            
 v_dir_user_id INT)
begin

                                
   DECLARE v_id INT;     
   DECLARE v_errcode INT;                            
   DECLARE v_errmsg VARCHAR(256);           
   DECLARE v_dir_user_id_hd INT;     
   DECLARE v_operator INT;      
   DECLARE v_ext_old VARCHAR(5);          
                            
                            
   set v_errcode = 0;                            
   set v_errmsg = '';                            
                          
   START TRANSACTION;                          
                          
   BEGIN
      DECLARE EXIT HANDLER FOR SQLEXCEPTION
      begin
         SELECT
         ERROR_NUMBER() AS errcode
        ,SWF_ErrorMsg() AS errmsg;
         set v_errcode = ERROR_NUMBER();
         set v_errmsg = SWF_ErrorMsg();
         set v_id = 0;
         select v_errcode as errcode, v_errmsg as errmsg;
         ROLLBACK;
      end;
      select   extension INTO v_ext_old from vt_route_switchboard where switchboardId = v_switchboard_ID
      and route_switchboard = v_route_switchboard;
      if(v_ext_old is null) then

         SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
         select   operator, dir_user_id INTO v_operator,v_dir_user_id_hd from vbcp_switchboard_mapping a  where a.switchboard_reg_idx = v_switchboard_ID;
         SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;             
           
 
         BEGIN
   insert into vt_route_switchboard(switchboardId, route_switchboard, extension, no,dir_user_id)
    values(v_switchboard_ID, v_route_switchboard, v_extension, v_no,v_dir_user_id);
  
            insert into sb_menu(did_id,dir_users_id,`key`)
            select did_id,v_dir_user_id,cast(v_route_switchboard as CHAR(1)) from vt_myaccount_def_ext_number_switchboard where switchboard_reg_idx = v_switchboard_ID;
         END;
      ELSE
         set v_errcode = -1;
         set v_errmsg = 'Extension for the routing number already added.';
      end if;
   END;                          
                          
   set v_errcode = 0;                            
   set v_errmsg = 'Data successful added.';                  
                   
   select v_errcode as errcode, v_errmsg as errmsg;              
   COMMIT;                             
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ur_myacc_get_web_rates_country_prefix_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ur_myacc_get_web_rates_country_prefix_info`(
callingtype VARCHAR(100),
 type VARCHAR(250),
 country VARCHAR(150))
BEGIN
 
 
 	
 	
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select id,calling_type,country,CONCAT(prefix,'|',cast(rate as CHAR(30))) as prefix
    from UTMS_WEB_RATE_CONFIG a
    where a.calling_type = callingtype
    and a.country = country
    and Type = type;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 	
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ur_tariff_get_tariff_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ur_tariff_get_tariff_details`(
id int,  
planid int)
BEGIN  
  
  if id = ''
  then
  set id = 0;
  end if;
  
  if planid = ''
  then
  set planid = 0;
  end if;
 
 call unifiedring.ur_tariff_get_tariff_details (id,planid);
   
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ur_tms_get_reseller_discount_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ur_tms_get_reseller_discount_info`(product_id INT)
BEGIN
 
 	
 	
    CALL unifiedring.unifiedring_get_reseller_discount_info(product_id);
 	
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `utms_company_bulk_upload_calling_rate_dtl_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `utms_company_bulk_upload_calling_rate_dtl_info`(processtype INT , 
 in_xml_data LONGTEXT)
Begin
 
 	   
    IF processtype is null then
       set processtype = 0;
    END IF;
    CALL unifiedring.utms_company_bulk_upload_calling_rate_dtl_info(processtype,in_xml_data);
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `utms_company_get_calling_rate_dtl_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `utms_company_get_calling_rate_dtl_info`(id INT , 
 	calling_id  INT 
 )
BEGIN
 
    
  
    IF id is null then
       set id = 0;
    END IF;
    
    CALL unifiedring.utms_company_get_calling_rate_dtl_info(id,calling_id);
  
 
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `utms_company_get_calling_type_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `utms_company_get_calling_type_info`()
BEGIN
 
    CALL unifiedring.utms_company_get_calling_type_info();
  
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `utms_company_update_delete_calling_rate_dtl_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `utms_company_update_delete_calling_rate_dtl_info`(
 	processtype INT, 
  	rate_id INT,
  	type VARCHAR(200),
  	prefix LONGTEXT,
  	calling_id INT,
  	destination VARCHAR(50),
  	call_rate VARCHAR(10),
  	status INT)
BEGIN
  
     
   
     CALL unifiedring.utms_company_update_delete_calling_rate_dtl_info(processtype,rate_id,type,prefix,calling_id,destination,call_rate,
     status);
   
  
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UTMS_create_activity_log_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `UTMS_create_activity_log_info`(created_by INT,
   module_name VARCHAR(50),
   create_date DATETIME(3),
   comments VARCHAR(200))
BEGIN
   
   	
      CALL unifiedring.UTMS_create_activity_log_info(created_by,module_name,create_date,comments);
   
   END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UTMS_create_Category_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `UTMS_create_Category_info`(
Category_Name VARCHAR(255),
 Category_id INT,
 category_position INT,
 process_type INT,
 status INT)
BEGIN
 
 	
    CALL unifiedring.UTMS_create_Category_info (Category_Name,Category_id,category_position,process_type,status);
 
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `utms_create_esp_tariff` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `utms_create_esp_tariff`(
 plan_id INT, 
 tariff VARCHAR(4),
 tariff_type INT,
 processby VARCHAR(150),
 processtype INT,
 id INT)
BEGIN
 
    IF id is null then
       set id = 0;
    END IF;
    CALL unifiedring.ur_tariff_create_tariff_details(plan_id,tariff,tariff_type,processby,processtype,id);
 	
 	
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UTMS_create_feature_detail` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `UTMS_create_feature_detail`(
 feature_name VARCHAR(255),
 feature_desc VARCHAR(255),
 code VARCHAR(100),
 Category_id INT,
 Feature_hdr INT,
 process_type INT,
 last_upd_by VARCHAR(50),
 Feature_idx INT,
 Status INT,
 is_freetrial INT,
 Feature_price FLOAT)
BEGIN
 	
 	
    IF Feature_idx is null 
    then
       set Feature_idx = 0;
    END IF;
    
    IF is_freetrial is null 
    then
       set is_freetrial = 0;
    END IF;
    
    IF Feature_price is null 
    then
       set Feature_price = 0;
    END IF;
    
    CALL unifiedring.UTMS_create_feature_master(feature_name,feature_desc,code,Category_id,
    Feature_hdr,process_type,last_upd_by,Feature_idx,Status,is_freetrial,Feature_price);
 	
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UTMS_create_feature_master` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `UTMS_create_feature_master`(
feature_name VARCHAR(255),
 feature_desc VARCHAR(255),
 code VARCHAR(100),
 
 Category_id INT,
 Feature_hdr INT,
 process_type INT,
 last_upd_by VARCHAR(50),
 Feature_idx INT,
 Status INT,
 is_freetrial INT,
 Feature_price FLOAT)
BEGIN
 
 	
 	
    DECLARE v_errcode INT;
    DECLARE v_errmsg VARCHAR(160);
    DECLARE v_PF_seq INT;
    DECLARE v_Category VARCHAR(100);
 	
 	
    IF Feature_idx is null then
       set Feature_idx = 0;
    END IF;
    IF is_freetrial is null then
       set is_freetrial = 0;
    END IF;
    IF Feature_price is null then
       set Feature_price = 0;
    END IF;
    sp_exit:
    BEGIN
       IF Feature_idx is null then
          set Feature_idx = 0;
       END IF;
       IF is_freetrial is null then
          set is_freetrial = 0;
       END IF;
       IF Feature_price is null then
          set Feature_price = 0;
       END IF;
       Set v_errcode = -1;
       set v_errmsg = 'Failure to create feature Master';
 	
 	
       select   Category_Name INTO v_Category from UR_ECom_Category a where a.Category_id = Category_id;
 
 	
 	
       IF process_type = 1 then
 	
          IF EXISTS(SELECT  1 FROM UR_ECom_Plan_Feature where PF_Name = feature_name and
          PF_category = v_Category AND PF_Hdr = Feature_hdr LIMIT 1) then
 		
             Set v_errcode = -1;
             Set v_errmsg = 'Feature Name already exists!';
             LEAVE sp_exit;
          end if;
          SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
          select   PF_Seq INTO v_PF_seq from UR_ECom_Plan_Feature    order by PF_Idx desc LIMIT 1;
          SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
          SET v_PF_seq = IFNULL(v_PF_seq,0)+1;
          INSERT INTO UR_ECom_Plan_Feature(PF_Hdr,PF_Code,PF_Name,PF_Description,PF_Seq,PF_category,Category_id,PF_status,
 		is_freetrial,Feature_price)
 		VALUES(Feature_hdr,v_PF_seq,feature_name,feature_desc,v_PF_seq,v_Category,Category_id,Status,
 		is_freetrial,Feature_price);
 		
          IF ROW_COUNT() > 0 then
 		
             Set v_errcode = 0;
             Set v_errmsg = 'New feature is created!';
             LEAVE sp_exit;
          end if;
       end if;
 	
 	
       IF process_type = 2 then
 	
          IF NOT EXISTS(SELECT  1 FROM UR_ECom_Plan_Feature where PF_Idx = Feature_idx LIMIT 1) then
 		
             Set v_errcode = -1;
             Set v_errmsg = 'Feature not found!';
             LEAVE sp_exit;
          end if;
          IF  EXISTS(SELECT  1 FROM UR_ECom_Plan_Feature where PF_Hdr = Feature_hdr
          and PF_category = v_Category and  Category_id = Category_id
          and IFNULL(PF_Name,'') = feature_name and PF_Idx <> Feature_idx LIMIT 1) then
 		
             Set v_errcode = -1;
             Set v_errmsg = 'Feature Name already exists!';
             LEAVE sp_exit;
          end if;
          UPDATE UR_ECom_Plan_Feature Set PF_Name = feature_name,PF_Description = feature_desc,PF_category = v_Category,
          last_upd_by = last_upd_by,Category_id = Category_id,PF_status = Status,
          is_freetrial = is_freetrial,Feature_price = Feature_price
          WHERE PF_Idx = Feature_idx;
          IF ROW_COUNT() > 0 then
 		
             Set v_errcode = 0;
             Set v_errmsg = CONCAT_WS('',feature_name,' details are updated!');
             LEAVE sp_exit;
          end if;
       end if;
    END;
    select v_errcode as errcode,v_errmsg as errmsg;
 	
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UTMS_create_Menu_Info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `UTMS_create_Menu_Info`(Menu_Name VARCHAR(250),
Menu_link VARCHAR(250),
process_type INT,
Menu_Id INT)
BEGIN

	
	
   DECLARE v_errcode INT; 
   DECLARE v_errmsg VARCHAR(250);
	
   IF Menu_Id is null then
      set Menu_Id = 0;
   END IF;

sp_exit:
   BEGIN

      IF process_type = 1 then
	
         IF EXISTS(SELECT 1 FROM tbl_Menu a where a.Menu_Name = Menu_Name LIMIT 1) then		
            Set v_errcode = -1;
            Set v_errmsg = 'Menu Name already exists!';
            LEAVE sp_exit;
         end if;
         
        INSERT INTO tbl_Menu(Menu_Name,Menu_link)
		VALUES(Menu_Name,Menu_link);
		
         IF ROW_COUNT() > 0 then		
            Set v_errcode = 0;
            Set v_errmsg = 'Success to create menu info.';
            LEAVE sp_exit;
         end if;
      end if;
      
      IF process_type = 2 then
	
         IF NOT EXISTS(SELECT 1 FROM tbl_Menu a where a.Pk_Menu_Id = Menu_Id LIMIT 1) then
		
            Set v_errcode = -1;
            Set v_errmsg = 'Menu Name not exists!';
            LEAVE sp_exit;
         end if;
         IF EXISTS(SELECT 1 FROM tbl_Menu a where a.Pk_Menu_Id <> Menu_Id and a.Menu_Name = Menu_Name LIMIT 1) then
		
            Set v_errcode = -1;
            Set v_errmsg = 'Menu Name alreay exists!';
            LEAVE sp_exit;
         end if;
         Update tbl_Menu a set a.Menu_Name = Menu_Name,a.Menu_link = Menu_link
         Where a.Pk_Menu_Id = Menu_Id;
         IF ROW_COUNT() > 0 then
		
            Set v_errcode = 0;
            Set v_errmsg = 'Success to create menu info.';
            LEAVE sp_exit;
         end if;
      end if;
   END;
   Select v_errcode as errcode,v_errmsg as errmsg;
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UTMS_create_Plan_addon_feature_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `UTMS_create_Plan_addon_feature_info`(addon_avail_at INT,
 addon_feature_Name VARCHAR(255),
 addon_feature_desc VARCHAR(255),
 addon_status INT,
 addon_price FLOAT,
 process_type INT,
 addon_id INT ,
 is_third_party INT,
 Company_addon_price FLOAT,
 groupname VARCHAR(150),
 no_group_allowed INT,
 group_price FLOAT,
 max_user_in_group INT,
 members_type LONGTEXT,
 group_within_plan INT,
 Feature_Type INT, 
 Feature_limit INT, 
 Tariff VARCHAR(4),
 category_id INT,
 integrate_name VARCHAR(100),
 limit_set_text VARCHAR(100),
 limit_set_value FLOAT)
BEGIN
 	
 	
 	call unifiedring.UTMS_create_Plan_addon_feature_info (addon_avail_at,addon_feature_Name,addon_feature_desc
	,addon_status,addon_price,process_type,addon_id,is_third_party,Company_addon_price,groupname,
	no_group_allowed,group_price,max_user_in_group,members_type,group_within_plan,Feature_Type,
	Feature_limit,Tariff,category_id,integrate_name,limit_set_text,limit_set_value);
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UTMS_create_plan_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `UTMS_create_plan_info`(User_Id INT,
 Product_Id INT,
 duration INT,
 Pc_From_Users INT,
 Pc_To_Users INT,
 PC_Price FLOAT,
 features LONGTEXT,
 Process_Type INT,
 Plan_ID INT,
 National_min INT,
 Geo_Min INT,
 Plan_Name VARCHAR(150),
 Unlimted_Intra_Call INT,
 is_free_trial INT)
BEGIN
 
 
    IF Plan_ID is null 
    then
       set Plan_ID = 0;
    END IF;
    
    IF is_free_trial is null 
    then
       set is_free_trial = 0;
    END IF;
    
    CALL unifiedring.sme_reseller_create_plan(0,Product_Id,duration,Pc_From_Users,Pc_To_Users,PC_Price,features,
    Process_Type,Plan_ID,National_min,Geo_Min,Plan_Name,
    0,Unlimted_Intra_Call,is_free_trial);
 	
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UTMS_create_plan_info_test_check` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `UTMS_create_plan_info_test_check`(User_Id INT,
   Product_Id INT,
   Pc_From_Users INT,
   Pc_To_Users INT,
   PC_Price FLOAT,
   features LONGTEXT,
   Process_Type INT,
   National_min INT,
   Geo_Min INT,
   Plan_Name VARCHAR(150),
   Request_ID INT,
   Unlimted_Intra_Call INT,
   is_free_trial INT,
   monthly_price FLOAT,
   yearly_price FLOAT,
   monthly_yearly_price FLOAT,
   most_popular INT,
   created_by VARCHAR(50),
   status INT,
   Audio_conf INT,
   Audio_conf_value VARCHAR(50),
   Video_conf INT,
   Video_conf_value VARCHAR(50),
   Calling_UK_mins FLOAT,
   yearly_discount FLOAT,
   monthly_yearly_discount FLOAT,
   freeph_non_geo_loc_min FLOAT,
   Unlimited_inbound_conf INT,
   Unlimited_inbound_conf_value FLOAT,
   free_trial_days INT,
   is_reseller INT,
   FT_audio_conf INT,
   FT_audio_conf_value INT,
   FT_video_conf INT,
   FT_video_conf_value INT,
   FT_Unlimted_Intra_Call INT,
   FT_Unlimted_Intra_Call_min INT,
   Free_trial_min INT,
   reseller_discount_flag INT,
   reseller_discount_xml LONGTEXT,
   two_year_monthly_price FLOAT,
   three_year_monthly_price FLOAT,
   two_year_monthly_discount FLOAT,
   three_year_monthly_discount FLOAT)
BEGIN
   
   	
   	
      IF is_free_trial is null 					then set is_free_trial = 0; 				END IF;
      IF free_trial_days is null 				then set free_trial_days = 0; 				END IF;
      IF is_reseller is null 					then set is_reseller = 0; 					END IF;
      IF FT_audio_conf is null 					then set FT_audio_conf = 0;       			END IF;
      IF FT_audio_conf_value is null 			then set FT_audio_conf_value = 0; 			END IF;
      IF FT_video_conf is null 					then set FT_video_conf = 0; 				END IF;
      IF FT_video_conf_value is null 			then set FT_video_conf_value = 0; 			END IF;
      IF FT_Unlimted_Intra_Call is null 		then set FT_Unlimted_Intra_Call = 0; 		END IF;
      IF FT_Unlimted_Intra_Call_min is null 	then set FT_Unlimted_Intra_Call_min = 0; 	END IF;
      IF Free_trial_min is null 				then set Free_trial_min = 0; 				END IF;
      IF reseller_discount_flag is null 		then set reseller_discount_flag = 0; 		END IF;
      IF reseller_discount_xml is null 			then set reseller_discount_xml = ''; 		END IF;
      IF two_year_monthly_price is null 		then set two_year_monthly_price = 0; 		END IF;
      IF three_year_monthly_price is null 		then set three_year_monthly_price = 0; 		END IF;
      IF two_year_monthly_discount is null 		then set two_year_monthly_discount = 0;		END IF;
      IF three_year_monthly_discount is null 	then set three_year_monthly_discount = 0; 	END IF;
      
      CALL unifiedring.sme_reseller_create_plan_test_check(0,Product_Id,Pc_From_Users,Pc_To_Users,PC_Price,features,Process_Type,
      National_min,Geo_Min,Plan_Name,0,Unlimted_Intra_Call,is_free_trial,monthly_price,yearly_price,monthly_yearly_price,
      most_popular,created_by,status,Audio_conf,Audio_conf_value,Video_conf,Video_conf_value,Calling_UK_mins,yearly_discount,
      monthly_yearly_discount,freeph_non_geo_loc_min,Unlimited_inbound_conf,Unlimited_inbound_conf_value,free_trial_days,is_reseller,FT_audio_conf,
      FT_audio_conf_value,FT_video_conf,FT_video_conf_value,FT_Unlimted_Intra_Call,FT_Unlimted_Intra_Call_min,Free_trial_min,reseller_discount_flag,
      reseller_discount_xml,two_year_monthly_price,three_year_monthly_price,two_year_monthly_discount,three_year_monthly_discount);
   	
   END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UTMS_create_Role_Menu_Mapping` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `UTMS_create_Role_Menu_Mapping`(Role_ID INT,
   Role_Name VARCHAR(50),
   menu_id LONGTEXT,
   process_type INT,
   status INT)
BEGIN
   
      DECLARE v_errcode INT; 
      DECLARE v_errmsg VARCHAR(250);
      
      SET v_errcode = -1;
 	 SET v_errmsg = 'Failure to do role Mapping.';
      
 Sp_exit:BEGIN
         DROP TEMPORARY TABLE IF EXISTS tt_temp_menu;
         create TEMPORARY table tt_temp_menu
         (
            menu_id VARCHAR(50)
         );
   	
         if Role_Name = '' or Role_Name is null 
         then
   	
            SET v_errcode = -1;
            SET v_errmsg = 'Role_Name should not be empty.';
            LEAVE Sp_exit;
         end if;
         
         If process_type = 1 then
         
 			SET v_errcode = -1;
 			SET v_errmsg = 'Please check Input details!';
   	
            if exists(SELECT  * FROM Userrole a where a.Role_name = Role_Name LIMIT 1) 
            then
               SET v_errcode = -1;
               SET v_errmsg = 'Role name already exist!.';
               LEAVE Sp_exit;
            end if;
            
            If not exists(SELECT  * FROM Userrole a where a.Role_name = Role_Name LIMIT 1) then
   			
               select max(a.Pk_role_id)+1  INTO Role_ID from Userrole a ORDER BY a.Pk_role_id DESC LIMIT 1;
               insert into Userrole(Pk_role_id,Role_name,Role_created_date,role_status) values(Role_ID,Role_Name,CURRENT_TIMESTAMP,status);
            end if;
            
            SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
            select   a.Pk_role_id  INTO Role_ID FROM Userrole a where a.Role_name = Role_Name  ORDER BY a.Role_name ASC,a.Pk_role_id DESC LIMIT 1;
            SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
            
               CALL unifiedring.Split(menu_id,',');
               insert into tt_temp_menu(menu_id)
               select Items from unifiedring.tt_Split_temptable;
   		 	 
   		 
               Delete from Role_Menu_Mapping where Fk_Role_ID = Role_ID
               AND Fk_Menu_ID IN (select a.menu_id from tt_temp_menu a);
   		 
   		 
               INSERT INTO Role_Menu_Mapping(Fk_Role_ID,Fk_Menu_ID,Last_update)
               Select Role_ID,a.menu_id,CURRENT_TIMESTAMP FROM  tt_temp_menu a;
               
               IF found_rows() > 0 then
                  SET v_errcode = 0;
                  SET v_errmsg = 'New role is created.';
               end if;
         end if;
         
         If process_type = 2 then
         
 			SET v_errcode = -1;
 			SET v_errmsg = 'Please check Input details!';
   	
            If exists(SELECT  * FROM Userrole a where a.Role_name = Role_Name and a.Pk_role_id <> Role_ID LIMIT 1) then
   		
               SET v_errcode = -1;
               SET v_errmsg = 'Role name already exist!.';
               LEAVE Sp_exit;
            end if;
            
            If not exists(SELECT  * FROM Userrole a where a.Pk_role_id = Role_ID LIMIT 1) then
   		
               SET v_errcode = -1;
               SET v_errmsg = 'Role ID not exist!.';
               LEAVE Sp_exit;
            end if;
            
            update Userrole a
            set a.Role_name = Role_Name,a.Role_created_date = CURRENT_TIMESTAMP,a.role_status = status
            where a.Pk_role_id = Role_ID;
   		
               CALL unifiedring.Split(menu_id,',');
               insert into tt_temp_menu(menu_id)
               select Items from unifiedring.tt_Split_temptable;
 
               Delete from Role_Menu_Mapping where Fk_Role_ID = Role_ID;
 
               INSERT INTO Role_Menu_Mapping(Fk_Role_ID,Fk_Menu_ID,Last_update)
               Select Role_ID,a.menu_id,CURRENT_TIMESTAMP FROM  tt_temp_menu a;
               
               IF found_rows() > 0 then
 				SET v_errcode = 0;
                 SET v_errmsg = CONCAT_WS('',Role_Name,' details are updated.');
               end if;
         end if;
         
 END Sp_exit;
      select v_errcode as errcode,v_errmsg as errmsg;
   	
   END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UTMS_create_screen_Module` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `UTMS_create_screen_Module`(
Module_name VARCHAR(150),
 Url VARCHAR(500),
 Status INT,
 Module_Id INT,
 processtype INT)
BEGIN
 
    IF Module_Id is null then
       set Module_Id = 0;
    END IF;
    
    CALL unifiedring.UTMS_create_Screen_Module_info(Module_name,Url,Status,Module_Id,processtype);
 	
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UTMS_create_sme_plan` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `UTMS_create_sme_plan`(User_Id INT,
   Product_Id INT,
   Pc_From_Users INT,
   Pc_To_Users INT,
   PC_Price FLOAT,
   features LONGTEXT,
   Process_Type INT,
   National_min INT,
   Geo_Min INT,
   Plan_Name VARCHAR(150),
   Request_ID INT,
   Unlimted_Intra_Call INT,
   is_free_trial INT,
   monthly_price FLOAT,
   yearly_price FLOAT,
   monthly_yearly_price FLOAT,
   most_popular INT,
   created_by VARCHAR(50),
   status INT,
   Audio_conf INT,
   Audio_conf_value VARCHAR(50),
   Video_conf INT,
   Video_conf_value VARCHAR(50),
   Calling_UK_mins FLOAT,
   yearly_discount FLOAT,
   monthly_yearly_discount FLOAT,
   freeph_non_geo_loc_min FLOAT,
   Unlimited_inbound_conf INT,
   Unlimited_inbound_conf_value FLOAT,
   free_trial_days INT,
   is_reseller INT,
   FT_audio_conf INT,
   FT_audio_conf_value INT,
   FT_video_conf INT,
   FT_video_conf_value INT,
   FT_Unlimted_Intra_Call INT,
   FT_Unlimted_Intra_Call_min INT,
   Free_trial_min INT,
   reseller_discount_flag INT,
   reseller_discount_xml LONGTEXT,
   two_year_monthly_price FLOAT,
   three_year_monthly_price FLOAT,
   two_year_monthly_discount FLOAT,
   three_year_monthly_discount FLOAT,
   User_Range_xml LONGTEXT,
   plan_addon_price_xml LONGTEXT ,
   Video_conf_meetings VARCHAR(100),
   Video_conf_participants VARCHAR(100),
   Audio_conf_participants VARCHAR(100),
   FT_video_conf_meetings VARCHAR(100),
   FT_video_conf_participants VARCHAR(100),
   FT_Audio_conf_participants VARCHAR(100),
   Feature_xml LONGTEXT,
   Video_conf_duration INT,
   Member_Type longtext, 
 show_plan longtext)
BEGIN
   
   	
   
      IF is_free_trial is null then
         set is_free_trial = 0;
      END IF;
      IF free_trial_days is null then
         set free_trial_days = 0;
      END IF;
      IF is_reseller is null then
         set is_reseller = 0;
      END IF;
      IF FT_audio_conf is null then
         set FT_audio_conf = 0;
      END IF;
      IF FT_audio_conf_value is null then
         set FT_audio_conf_value = 0;
      END IF;
      IF FT_video_conf is null then
         set FT_video_conf = 0;
      END IF;
      IF FT_video_conf_value is null then
         set FT_video_conf_value = 0;
      END IF;
      IF FT_Unlimted_Intra_Call is null then
         set FT_Unlimted_Intra_Call = 0;
      END IF;
      IF FT_Unlimted_Intra_Call_min is null then
         set FT_Unlimted_Intra_Call_min = 0;
      END IF;
      IF Free_trial_min is null then
         set Free_trial_min = 0;
      END IF;
      IF reseller_discount_flag is null then
         set reseller_discount_flag = 0;
      END IF;
      IF reseller_discount_xml is null then
         set reseller_discount_xml = '';
      END IF;
      IF two_year_monthly_price is null then
         set two_year_monthly_price = 0;
      END IF;
      IF three_year_monthly_price is null then
         set three_year_monthly_price = 0;
      END IF;
      IF two_year_monthly_discount is null then
         set two_year_monthly_discount = 0;
      END IF;
      IF three_year_monthly_discount is null then
         set three_year_monthly_discount = 0;
      END IF;
      
      IF Member_Type is null then set Member_Type = ''; END IF;
    	 IF show_plan is null then set show_plan = ''; END IF;
      
      CALL unifiedring.UTMS_create_sme_plan(0,Product_Id,Pc_From_Users,Pc_To_Users,PC_Price,features,Process_Type,
      National_min,Geo_Min,Plan_Name,0,Unlimted_Intra_Call,
      is_free_trial,monthly_price,yearly_price,monthly_yearly_price,
      most_popular,created_by,status,Audio_conf,Audio_conf_value,
      Video_conf,Video_conf_value,Calling_UK_mins,yearly_discount,
      monthly_yearly_discount,freeph_non_geo_loc_min,Unlimited_inbound_conf,
      Unlimited_inbound_conf_value,free_trial_days,is_reseller,FT_audio_conf,
      FT_audio_conf_value,FT_video_conf,FT_video_conf_value,
      FT_Unlimted_Intra_Call,FT_Unlimted_Intra_Call_min,Free_trial_min,
      reseller_discount_flag,reseller_discount_xml,two_year_monthly_price,
      three_year_monthly_price,two_year_monthly_discount,three_year_monthly_discount,
      User_Range_xml,plan_addon_price_xml,Video_conf_meetings,
      Video_conf_participants,Audio_conf_participants,FT_video_conf_meetings,
      FT_video_conf_participants,FT_Audio_conf_participants,
      Feature_xml,Video_conf_duration,Member_Type,show_plan);
   	
   END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UTMS_create_user_profile` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `UTMS_create_user_profile`(
First_name VARCHAR(100),
 Last_name VARCHAR(100),
 Username VARCHAR(50),
 Password VARCHAR(20),
 role_id INT,
 last_login_ip VARCHAR(50),
 Status INT,
 Menu_id LONGTEXT,
 process_Type INT,
 user_id INT)
BEGIN
 
 
    DECLARE v_errcode INT;
    DECLARE v_errmsg VARCHAR(250);
    DECLARE v_now DATETIME(3); 
 	
    IF user_id is null then
       set user_id = 0;
    END IF;
    SP_EXIT:
    BEGIN
       IF user_id is null then
          set user_id = 0;
       END IF;
       SET v_errcode = -1;
       SET v_errmsg = 'Failure to create User';
       SET v_now = CURRENT_TIMESTAMP;
 	
 	
       IF process_Type = 1 then
 	
          IF EXISTS(SELECT  1 FROM Userprofile a WHERE a.Username = Username LIMIT 1) then
 		
             SET v_errcode = -1;
             SET v_errmsg = 'User already Exists!';
             LEAVE sp_exit;
          end if;
          INSERT INTO Userprofile(First_name,Last_name,Username,Password,Fk_role_Id,last_login_ip,
 		Signup_date,last_login_date,status)
 		VALUES(First_name,Last_name,Username,Password,role_id,last_login_ip,v_now,v_now,Status);
 		
          IF ROW_COUNT() > 0 then
 		
             SET v_errcode = 0;
             SET v_errmsg = 'Success to create User Info.';
          end if;
       end if;
 	
 	
       IF process_Type = 2 then
 	
          IF NOT EXISTS(SELECT  1 FROM Userprofile b WHERE b.Userid = user_id LIMIT 1) then
 		
             SET v_errcode = -1;
             SET v_errmsg = 'UserID not Exists!';
             LEAVE sp_exit;
          end if;
          IF EXISTS(SELECT  1 FROM Userprofile c WHERE c.Userid <> user_id and c.Username = Username LIMIT 1) then
 		
             SET v_errcode = -1;
             SET v_errmsg = 'Username already Exists!';
             LEAVE sp_exit;
          end if;
          UPDATE Userprofile d SET d.First_name = First_name,d.Last_name = Last_name,d.Username = Username,d.Password = Password,
          d.Fk_role_Id = role_id,d.last_login_ip = last_login_ip,d.last_login_date = v_now,
          d.status = Status
          WHERE Userid = user_id;
          IF ROW_COUNT() > 0 then
 		
             SET v_errcode = 0;
             SET v_errmsg = 'Success to Update User Info.';
          end if;
       end if;
    END;
    SELECT v_errcode as errcode,v_errmsg as errmsg;
 	
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `utms_get_active_plan_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `utms_get_active_plan_info`()
BEGIN
	
   CALL unifiedring.ur_tariff_drp_active_plan();

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UTMS_get_activity_log_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `UTMS_get_activity_log_info`(From_date VARCHAR(15),
 to_date VARCHAR(15))
BEGIN
 
 	
    CALL unifiedring.UTMS_get_activity_log_info(From_date,to_date);
 
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `utms_get_bundle_rate_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `utms_get_bundle_rate_info`(bundleid INT)
BEGIN
  
   CALL unifiedring.utms_get_bundle_rate_info(bundleid);  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UTMS_get_category_feature_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `UTMS_get_category_feature_info`(
Category_id INT)
BEGIN
 
 	
    CALL unifiedring.UTMS_get_category_feature_info(Category_id);
 	
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UTMS_get_Category_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `UTMS_get_Category_info`(Category_id INT)
BEGIN
 
    IF Category_id is null 
    then
       set Category_id = 0;
    END IF;
    
    CALL unifiedring.UTMS_get_UR_ECom_Category_info(Category_id);
 
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `utms_get_country_template` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `utms_get_country_template`()
BEGIN

  
  
   
  
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select distinct name as country_name,'' as Landline,'' as Mobile
   from unifiedring.ur_country_config
   where IFNULL(iso3,'NULL') <> 'NULL'
   AND IFNULL(iso3,'') <> '';
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UTMS_get_discount_percentage_settings_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `UTMS_get_discount_percentage_settings_info`()
begin

	
   CALL unifiedring.UTMS_get_discount_percentage_settings_info(); 
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `utms_get_downloaded_file_name` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `utms_get_downloaded_file_name`(callingtype VARCHAR(100))
BEGIN
 
 	
 	
    DECLARE v_filename VARCHAR(250);
 	
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select   filename  INTO v_filename from  UTMS_WEB_RATE_CONFIG a where a.calling_type = callingtype  
    ORDER BY a.calling_type DESC,a.country DESC,a.prefix DESC LIMIT 1;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ; 
 	
    select v_filename as filename;
 	
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UTMS_get_feature_detail` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `UTMS_get_feature_detail`(Feature_hdr INT,
 Feature_idx INT)
BEGIN
 
    IF Feature_hdr is null then
       set Feature_hdr = 0;
    END IF;
    IF Feature_idx is null then
       set Feature_idx = 0;
    END IF;
    CALL unifiedring.UTMS_get_feature_master_info(Feature_hdr,Feature_idx);
 	
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `utms_get_feature_details_by_plan` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `utms_get_feature_details_by_plan`(plan_id INT)
BEGIN

 	
    CALL  unifiedring.utms_get_feature_details_by_plan(plan_id);
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UTMS_get_Free_trial_settings_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `UTMS_get_Free_trial_settings_info`()
begin

  
   
   CALL unifiedring.UTMS_get_Free_trial_settings_info();   
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UTMS_get_Menu_Info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `UTMS_get_Menu_Info`(Menu_Id INT)
BEGIN
 
 	
 	
    IF Menu_Id is null then
       set Menu_Id = 0;
    END IF;
    
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    Select a.Pk_Menu_Id as Menu_Id,a.Menu_Name,a.Menu_link from tbl_Menu a
    Where ((Menu_Id = 0) or (a.Pk_Menu_Id = Menu_Id));
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Utms_get_plan_addon_by_user` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `Utms_get_plan_addon_by_user`(pc_planid INT)
Begin
 
    CALL unifiedring.Utms_get_plan_addon_by_user(pc_planid);
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UTMS_get_Plan_addon_feature_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `UTMS_get_Plan_addon_feature_info`(pc_addon_id INT ,
pc_addon_available_level INT,
category_id INT)
Begin

   IF pc_addon_id is null then
      set pc_addon_id = '';
   END IF;
   IF pc_addon_available_level is null then
      set pc_addon_available_level = 0;
   END IF;
   IF category_id is null then
      set category_id = 0;
   END IF;
   CALL unifiedring.UTMS_get_Plan_addon_feature_info(pc_addon_id,pc_addon_available_level,category_id);
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UTMS_get_plan_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `UTMS_get_plan_info`(
Product_ID INT,
 Plan_id INT)
BEGIN
 
    IF Product_ID is null then
       set Product_ID = 0;
    END IF;
    IF Plan_id is null then
       set Plan_id = 0;
    END IF;
    
    CALL unifiedring.sme_reseller_get_plan_info(0,Product_ID,Plan_id,1);
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Utms_get_plan_price_by_user_Range` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `Utms_get_plan_price_by_user_Range`(plan_id INT)
begin
 
    CALL unifiedring.Utms_get_plan_price_by_user_Range(plan_id);
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UTMS_get_price_settings_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `UTMS_get_price_settings_info`()
begin
 
 	
    CALL unifiedring.UTMS_get_price_settings_info(); 
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `utms_get_reseller_discount_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `utms_get_reseller_discount_info`(  
pc_product int)
BEGIN  

 call unifiedring.utms_get_reseller_discount_info (pc_product);  
   
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UTMS_get_Role_Info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `UTMS_get_Role_Info`(Pk_role_id INT)
BEGIN


	
	
   IF Pk_role_id is null then
      set Pk_role_id = 0;
   END IF;
   SELECT t.Pk_role_id,Role_name,Role_created_date,role_status, insert((SELECT GROUP_CONCAT(CONCAT(',',cast(s.Fk_Menu_ID as CHAR(30))) SEPARATOR '')
      FROM Role_Menu_Mapping s WHERE
      s.Fk_Role_ID = t.Pk_role_id),1,1,'') AS menu_id FROM Userrole AS t
   where (Pk_role_id = 0) or t.Pk_role_id = Pk_role_id
   GROUP BY t.Pk_role_id,Role_name,Role_created_date,role_status;   
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UTMS_get_screen_Module_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `UTMS_get_screen_Module_info`(Module_id INT)
BEGIN
 
 	
 	
    CALL unifiedring.ur_myaccount_usermgt_get_Module(Module_id);
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `utms_get_sme_plan_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `utms_get_sme_plan_details`(Reseller_id INT,  
 Product_ID INT,
 Plan_id INT ,
 is_tms_flag INT)
BEGIN
  
    
  
    IF Product_ID is null then
       set Product_ID = 0;
    END IF;
    IF Plan_id is null then
       set Plan_id = 0;
    END IF;
    IF is_tms_flag is null then
       set is_tms_flag = 0;
    END IF;
    
    CALL unifiedring.utms_get_sme_plan_details(0,Product_ID,Plan_id,is_tms_flag);
  
 
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `utms_get_tariffclass_drp` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `utms_get_tariffclass_drp`()
BEGIN
	
	
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select distinct trffclass from plan_tariff_config;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `utms_get_tariff_rate_download` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `utms_get_tariff_rate_download`(
 trffclass VARCHAR(4),
 accesscharge INT)
BEGIN
 
 
    DECLARE v_errcode INT; 
    DECLARE v_errmsg VARCHAR(50);
 
    sp_exit:
    BEGIN
       set v_errcode = -1;
       set v_errmsg = 'Not Found';
       
       CALL espprm.BMS_portal_get_tariff_download('MCM',trffclass,accesscharge);
       if found_rows() > 0 then
 	
          set v_errcode = 0;
          set v_errmsg = 'Success';
          LEAVE sp_exit;
       end if;
    END;
    select v_errcode as errcode,v_errmsg as errmsg;
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `utms_get_tariff_upload_drp` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `utms_get_tariff_upload_drp`(type INT)
BEGIN
  	
  	
    
    declare default_int_val int;
    set default_int_val = 1;
  	
     IF type = 1 then
  	
        SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        select distinct default_int_val as id,trffclass  as `value`
        from unifiedring.plan_tariff_config;
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
     end if;
      
     IF type = 2 then
   	
        SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        SELECT access_type as id, access_type_name as `value`
        FROM ur_access_type_Config;
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
     end if;
      
  	
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `utms_get_uploaded_tariff_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `utms_get_uploaded_tariff_details`()
BEGIN
  
  drop temporary table if exists get_uploaded_tarif ;
     create temporary table get_uploaded_tarif
     (
     trffclass varchar(15),
     access_type int,
     access_type_name varchar(155),
     plan_name  varchar(155),
     addon_type int
     );
     
     	
        SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        insert into get_uploaded_tarif (trffclass,access_type,access_type_name,plan_name,addon_type)
        SELECT distinct a.trffclass,a.access_type,b.access_type_name,d.tier_name as plan_name,c.addon_type FROM tariff_upload_info a
        join ur_access_type_Config b on a.access_type = b.access_type
        join unifiedring.plan_tariff_config c on a.trffclass = c.trffclass
        join wtms.wtms_copy_of_tier_management_temp d on c.Plan_id = d.fk_tier_id 
          union all
         SELECT distinct  a.trffclass,a.access_type,b.access_type_name,CONCAT('Addon',c.bundle_name) as plan_name,0 as addon_type
       FROM tariff_upload_info a
       join ur_access_type_Config b on a.access_type = b.access_type
       join  unifiedring.utms_new_bundle_log c on a.trffclass = c.tariffclass ;
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
        
        
        select a.trffclass,a.access_type,a.access_type_name,a.plan_name,b.idx, 
        case when b.status = 1 then 'Pending'
      when b.status = 3 then 'Success'
      when b.status = 2  THEN 'inprogress'  ELSE  'Failure' end as tariff_status,b.filetariff,addon_type from get_uploaded_tarif a
        join espmgt.tariffRequest b on a.trffclass=b.NewTariffClass
      join espprm.access_charge c on b.denomination = c.charge
      left join  espmgt.cardFamily d on b.cardid = d.cardid order by idx desc LIMIT 10;
        
        
     	 drop temporary table if exists get_uploaded_tarif ;
     END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UTMS_get_user_profile_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `UTMS_get_user_profile_info`(User_ID INT)
BEGIN
 
 	
 	
    IF User_ID is null then
       set User_ID = 0;
    END IF;
    
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    SELECT Userid,First_name,Last_name,Username,Password,b.Role_name,a.Fk_role_Id,
 	last_login_ip,case when status = 1 then 'Active' else 'Inactive' end as User_status
    FROM Userprofile a 
    join Userrole b on a.Fk_role_Id = b.Pk_role_id
    Where( (User_ID = 0) OR(Userid = User_ID));
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UTMS_get_user_range_master_detail` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `UTMS_get_user_range_master_detail`(Range_typeid INT,
plan_id INT)
Begin

   IF plan_id is null then
      set plan_id = 0;
   END IF;
   CALL unifiedring.UR_ECom_get_User_Range_Master_Detail(Range_typeid,plan_id);
ENd ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `utms_get_web_rates_country_prefix_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `utms_get_web_rates_country_prefix_info`(callingtype VARCHAR(100),
 type VARCHAR(250),
 country VARCHAR(150))
BEGIN
 
 
 	
 	
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select id,calling_type,country,CONCAT(prefix,'|',cast(rate as CHAR(30))) as prefix
    from UTMS_WEB_RATE_CONFIG a
    where a.calling_type = callingtype
    and a.country = country
    and a.Type = type;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 	
 
 
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `utms_get_web_rates_country_summary_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `utms_get_web_rates_country_summary_info`(callingtype VARCHAR(100))
BEGIN
  
  	
     SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
     select a.calling_type,a.Type,a.country,count(distinct prefix)  as prefix_count
     from UTMS_WEB_RATE_CONFIG a
     WHERE a.calling_type = callingtype
     group  by a.calling_type,a.Type,a.country
     order by country asc;
     SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
  
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UTMS_get_web_rate_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `UTMS_get_web_rate_details`(callingtype VARCHAR(50))
BEGIN
 
 	
 	
 	
    IF callingtype is null then
       set callingtype = '';
    END IF;
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    SELECT id, calling_type AS calling_type,country,CAST(prefix  AS CHAR(30)) AS prefix,
 	fixed_rate,mobile_rate,Type,rate FROM UTMS_WEB_RATE_CONFIG a
    WHERE a.calling_type = callingtype;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 	
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UTMS_insert_User_Range_Master_Detail` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `UTMS_insert_User_Range_Master_Detail`(Range_typeid INT,
 From_user_Range INT,
 To_user_Range INT,
 processtype INT 
 )
Begin
 
    CALL unifiedring.UR_ECom_insert_User_Range_Master_Detail(Range_typeid,From_user_Range,To_user_Range,processtype);
 
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `utms_plan_pricing_create_notes_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `utms_plan_pricing_create_notes_info`(
 plan_id INT,
 processtype INT, 
 plan_notes LONGTEXT,
 plan_notes_status INT,
 plan_notes_id INT)
Begin
 
    CALL unifiedring.utms_plan_pricing_create_notes_info(plan_id,processtype,plan_notes,plan_notes_status,plan_notes_id);
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `utms_plan_pricing_get_notes_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `utms_plan_pricing_get_notes_info`(plan_id INT,
 plan_notes_id INT)
Begin
 
    CALL unifiedring.utms_plan_pricing_get_notes_info(plan_id,plan_notes_id);
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `utms_portal_create_bundle_plan` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `utms_portal_create_bundle_plan`(
 sitecode VARCHAR(3),
 bundle_name VARCHAR(150),
 currency VARCHAR(3),
 price	FLOAT,
 tariffclass_groupid INT,
 renewal_delay INT,
 renewal_mode INT,
 pro_rata INT,
 national_min FLOAT,
 international_min FLOAT,
 bundle_type INT,
 reseller_flag INT,
 bundle_status INT,
 tariffclass VARCHAR(4),
 Sms_Tariff VARCHAR(4),
 sms_allowance INT,
 reset_mode  INT,
 Schedule_Type INT,
 Schedule_Time DATETIME(3))
BEgin
 
 
 
    IF reseller_flag is null then
       set reseller_flag = 0;
    END IF;
    IF bundle_status is null then
       set bundle_status = 0;
    END IF;
    IF tariffclass is null then
       set tariffclass = '';
    END IF;
    IF Sms_Tariff is null then
       set Sms_Tariff = '';
    END IF;
    IF sms_allowance is null then
       set sms_allowance = 0;
    END IF;
    IF reset_mode is null then
       set reset_mode = 0;
    END IF;
    IF Schedule_Type is null then
       set Schedule_Type= 1;
    END IF;
    insert into  utms_portal_create_bundle_plan_log (sitecode,bundle_name,currency,price,tariffclass_groupid,renewal_delay,renewal_mode,
pro_rata,national_min,international_min,bundle_type,reseller_flag,bundle_status,tariffclass)  values(sitecode,bundle_name,currency,price,
 	tariffclass_groupid,renewal_delay,renewal_mode,pro_rata,national_min,international_min,
 	bundle_type,reseller_flag,bundle_status,tariffclass);
 	
 	
 
 	
    CALL unifiedring.utms_portal_create_bundle_plan(sitecode,bundle_name,currency,price,tariffclass_groupid,renewal_delay,
    renewal_mode,pro_rata,national_min,international_min,
    bundle_type,reseller_flag,bundle_status,tariffclass,Sms_Tariff,
    sms_allowance,reset_mode,Schedule_Type,Schedule_Time);
 	
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `utms_portal_get_bundle_list_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `utms_portal_get_bundle_list_info`(bundleid INT)
begin
 
    CALL unifiedring.ur_crm_portal_get_bundle_list_info(bundleid);
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `utms_portal_sme_subscribe_bundle_esp` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `utms_portal_sme_subscribe_bundle_esp`(
company_id INT,
 sitecode VARCHAR(3),
 enterpriseid INT,
 bundleid INT,
 paymode INT,
 processby VARCHAR(100))
Begin
 
 
 
    CALL unifiedring.utms_portal_sme_subscribe_bundle_esp(company_id,sitecode,enterpriseid,bundleid,paymode,processby);
 
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `utms_portal_update_bundle_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `utms_portal_update_bundle_details`(bundleid INT ,  
bundle_name VARCHAR(50),  
price FLOAT,  
national_min FLOAT,  
international_min FLOAT,  
bundke_type INT,  
bundle_status INT,  
bundle_type INT,  
Reseller_flag INT,  
days_valid INT,  
renewal_mode INT,  
tariff VARCHAR(4),  
Sms_Tariff VARCHAR(4),  
sms_allowance INT,  
reset_mode  INT,  
Schedule_Type INT,  
Schedule_Time DATETIME(3))
BEGIN

   IF Sms_Tariff is null 
   then
      set Sms_Tariff = '';
   END IF;
   
   IF sms_allowance is null 
   then
      set sms_allowance = 0;
   END IF;
   
   IF reset_mode is null 
   then
      set reset_mode = 0;
   END IF;
   
   IF Schedule_Type is null 
   then
      set Schedule_Type = 1;
   END IF;
   
   CALL unifiedring.utms_portal_update_bundle_details(bundleid,bundle_name,price,national_min,international_min,bundke_type,
   bundle_status,bundle_type,Reseller_flag,days_valid,
   renewal_mode,tariff,Sms_Tariff,sms_allowance,reset_mode,Schedule_Type,
   Schedule_Time);   
   
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `utms_portal_update_bundle_list_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `utms_portal_update_bundle_list_info`(bundleid INT ,
 bundle_name VARCHAR(50),
 price FLOAT,
 national_min FLOAT,
 international_min FLOAT,
 bundle_status INT,
 bundle_type INT,
 reseller_flag INT)
Begin
 
    IF reseller_flag is null then
       set reseller_flag = 0;
    END IF;
    
    CALL unifiedring.ur_crm_portal_update_bundle_list_info(bundleid,bundle_name,price,national_min,international_min,bundle_status,
    bundle_type,reseller_flag);
 	
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UTMS_Role_Menu_Mapping` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `UTMS_Role_Menu_Mapping`(
 Role_ID INT,
  
  menu_id LONGTEXT)
BEGIN
  
  
  	
  	
     DECLARE v_errcode INT; 
     DECLARE v_errmsg VARCHAR(250);
  	
  	
     SET v_errcode = -1;
     SET v_errmsg = 'Failure to do role Mapping.';
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  		
  	
  	
  
  	
  	
  	
  	
  	
  		
  	
  	
  	
  	
  		
  		
  		
  	
  	
     begin
      DECLARE EXIT HANDLER FOR SQLEXCEPTION
       begin
       SET v_errcode = -1;
        SET v_errmsg = 'Please check Input details!';
       end;
        DROP TEMPORARY TABLE IF EXISTS tt_temp_menu;
        create TEMPORARY table tt_temp_menu
        (
           menu_id VARCHAR(50)
        );
         
         call unifiedring.split(menu_id,',');

         insert into tt_temp_menu(menu_id)
          select Items from unifiedring.tt_Split_temptable;
  	 
   
  	 
        Delete from  Role_Menu_Mapping where Fk_Role_ID = Role_ID
        AND Fk_Menu_ID IN (select a.menu_id from tt_temp_menu a);
  	 
  	 
        INSERT INTO Role_Menu_Mapping(Fk_Role_ID,Fk_Menu_ID,Last_update)
        Select Role_ID,a.menu_id,CURRENT_TIMESTAMP FROM  tt_temp_menu a;
        
        IF row_count() > 0 then
  	
           SET v_errcode = 0;
           SET v_errmsg = 'Success to do role Mapping.';
        end if;
   
  	end;
  
     select v_errcode as errcode,v_errmsg as errmsg;
  	
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UTMS_Role_Menu_Mapping_get_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `UTMS_Role_Menu_Mapping_get_info`(Role_ID INT,
 menu_id INT)
BEGIN
 
    DECLARE v_errcode INT; 
    DECLARE v_errmsg VARCHAR(250); 	
 	
    Sp_exit:
    BEGIN
       SET v_errcode = -1;
       SET v_errmsg = 'Failure to do role Mapping.';
       if  exists(select  1  from Role_Menu_Mapping a where a.fk_role_id = Role_ID and a.Fk_Menu_ID = menu_id LIMIT 1) then
 	
          SET v_errcode = 0;
          SET v_errmsg = 'success role Mapping.';
          LEAVE sp_exit;
       else
          SET v_errcode = -1;
          SET v_errmsg = 'failed role Mapping.';
       end if;
    END;
    select v_errcode as errcode,v_errmsg as errmsg;
 	
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UTMS_update_Delete_WEB_rate_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `UTMS_update_Delete_WEB_rate_details`(
id INT,
 fixed_Rate VARCHAR(150),
 mobile_rate VARCHAR(150),
 procsstype INT 
 )
BEGIN
 
 	
 	
    DECLARE v_errcode INT; 
    DECLARE v_errmsg VARCHAR(160);
 	
    set v_errcode = -1;
    set v_errmsg = 'Failure to update the details';
 	
    IF procsstype = 1 then
 	
       UPDATE UTMS_WEB_RATE_CONFIG a SET  a.fixed_rate = fixed_Rate,a.mobile_rate = mobile_rate where a.id = id;
       IF ROW_COUNT() > 0 then
 		
          set v_errcode = 0;
          set v_errmsg = 'Success to update the rate details';
       end if;
    end if;
 	
    IF  procsstype = 2 then
 	
       DELETE FROM UTMS_WEB_RATE_CONFIG a WHERE a.id = id;
       IF ROW_COUNT() > 0 then
 		
          set v_errcode = 0;
          set v_errmsg = 'Success to update the rate details';
       end if;
    end if;
 	
    Select v_errcode as errcode,v_errmsg as errmsg;
 
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UTMS_update_discount_percentage_settings_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `UTMS_update_discount_percentage_settings_info`(discount_percentage_id INT,
 discount_percentage_status VARCHAR(10),
 discount_percentage FLOAT,
 max_no_of_user INT)
begin
 	
    CALL unifiedring.UTMS_update_discount_percentage_settings_info(discount_percentage_id,discount_percentage_status,discount_percentage,
    max_no_of_user);
 
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UTMS_update_Free_trial_settings_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `UTMS_update_Free_trial_settings_info`(
Free_trial_id	INT,
 Free_trial_status VARCHAR(10),
 Free_trial_day INT)
begin
 
 	
    CALL unifiedring.UTMS_update_Free_trial_settings_info(Free_trial_id,Free_trial_status,Free_trial_day);
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UTMS_update_price_settings_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `UTMS_update_price_settings_info`(pricing_id	INT,
 pricing_status VARCHAR(10))
begin
 
    CALL unifiedring.UTMS_update_price_settings_info(pricing_id,pricing_status);
 
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `utms_update_web_rates_country_prefix_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `utms_update_web_rates_country_prefix_info`(
prefix_id int,
prefix varchar(25),
rate float
)
begin

declare errcode int;
declare errmsg varchar(55);
set errcode=-1;
set errmsg='failure to update';

sp_exit:begin

if exists (select * from UTMS_WEB_RATE_CONFIG a where a.prefix_id=prefix_id and a.prefix=prefix)
then
update UTMS_WEB_RATE_CONFIG a set a.prefix=prefix and a.rate=rate
where a.prefix_id=prefix_id and a.prefix=prefix;
end if;

if row_count()>0
then
set errcode=0;
set errmsg='updated success fully';
leave sp_exit;
end if;




end sp_exit;

select errcode,errmsg;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `utms_uplaod_esp_tariff_rates` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `utms_uplaod_esp_tariff_rates`(
 login	VARCHAR(32),
  tariffclass	VARCHAR(4),
  access_type INT,
  effectivedate	DATETIME(3),
  filename VARCHAR(250),
  tempfilename VARCHAR(250),
  upload_type INT 
  )
BEGIN
  
  	
     DECLARE v_idx INT; 
     DECLARE v_errcode INT; 
     DECLARE v_errmsg VARCHAR(250);
  	
  	
     set v_errcode = -1;
     set v_errmsg = 'Failure to upload tariff rates';
  	
     CALL esp.UTMS_portal_upload_tariff_request(login,'MCM',null,tariffclass,1,effectivedate,access_type,filename,
     tempfilename,upload_type,v_idx,v_errcode,v_errmsg); 
  	
     IF EXISTS(SELECT  1 FROM  tariff_upload_info a WHERE a.trffclass = tariffclass
     and a.access_type = access_type LIMIT 1) then
  	
        UPDATE tariff_upload_info a SET a.esp_idx = v_idx,a.filename = filename,a.temp_filename = tempfilename,a.last_update = CURRENT_TIMESTAMP,
        a.update_by = login
        WHERE a.trffclass = tariffclass and a.access_type = access_type;
        if ROW_COUNT() > 0 then
  		
           set v_errcode = 0;
           set v_errmsg = 'OK';
        end if;
     ELSE
        INSERT INTO tariff_upload_info(trffclass,access_type,upload_type,esp_idx,filename,
  		temp_filename,create_by,create_date)
  		VALUES(tariffclass,access_type,upload_type,v_idx,filename,tempfilename,login,CURRENT_TIMESTAMP);
  		
        if ROW_COUNT() > 0 then
  		
           set v_errcode = 0;
           set v_errmsg = 'OK';
        end if;
     end if;
  
     select v_errcode as errcode,v_errmsg as errmsg; 
  	
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `utms_Upload_Excel` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `utms_Upload_Excel`(v_path   VARCHAR(100),                
v_file   VARCHAR(200),                
v_tablename VARCHAR(128),                
v_sheetname VARCHAR(64),        
v_site VARCHAR(3))
begin

 

               
   DECLARE v_Query VARCHAR(8000);                
   DECLARE v_RC INT;                
   DECLARE v_server VARCHAR(128);                
   DECLARE v_srvproduct VARCHAR(128);                
   DECLARE v_provider VARCHAR(128);                
   DECLARE v_datasrc VARCHAR(4000);                
   DECLARE v_location VARCHAR(4000);                
   DECLARE v_provstr VARCHAR(4000);                
   DECLARE v_catalog VARCHAR(128); 
   DECLARE v_sql VARCHAR(3000);                

   DECLARE v_flag INT;            
        
   DECLARE v_Counter_Copy INT;
   DECLARE v_temp_table VARCHAR(250);         


              

   DECLARE v_netusecmd VARCHAR(512);        
   DECLARE v_copycmd VARCHAR(512);        
   DECLARE v_exceldir VARCHAR(256);        
   DECLARE v_excelusr VARCHAR(32);        
   DECLARE v_excelpwd VARCHAR(32);        
   set v_Counter_Copy = 0;   
        


   set v_exceldir = null;        
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   exceldir, exceluser, excelpwd INTO v_exceldir,v_excelusr,v_excelpwd from
   tariff_fileupload_config  where UsedByTool = v_site;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;        
        
   if v_exceldir is null then
      select   exceldir, exceluser, excelpwd INTO v_exceldir,v_excelusr,v_excelpwd from tariff_fileupload_config where UsedByTool = 'utms';
   end if;        

   set v_netusecmd = 'master..xp_cmdshell ''net use ' || v_exceldir || ' ' || v_excelpwd || ' /user:BARABLU-WEB1\\' || v_excelusr || '''';        

   set v_copycmd  = 'master..xp_cmdshell ''copy ''' || v_exceldir || '\\' || v_file || ''' ' || v_path || '''';        

   

        
        
        






        
SET @SWV_Stmt = v_netusecmd;
   PREPARE SWT_Stmt FROM @SWV_Stmt;
   EXECUTE SWT_Stmt;
   DEALLOCATE PREPARE SWT_Stmt;        
   SET @SWV_Stmt = v_copycmd;
   PREPARE SWT_Stmt FROM @SWV_Stmt;
   EXECUTE SWT_Stmt;
   DEALLOCATE PREPARE SWT_Stmt;        
   set v_Counter_Copy = v_Counter_Copy+1;        
        

   set v_flag = 0;              
   CALL IsFileExist('e:\\tariff',v_file,v_flag);                

   if v_flag = 0 then

  
      while v_flag = 0 and v_Counter_Copy < 5 DO
         SET @SWV_Stmt = v_netusecmd;
         PREPARE SWT_Stmt FROM @SWV_Stmt;
         EXECUTE SWT_Stmt;
         DEALLOCATE PREPARE SWT_Stmt;
         SET @SWV_Stmt = v_copycmd;
         PREPARE SWT_Stmt FROM @SWV_Stmt;
         EXECUTE SWT_Stmt;
         DEALLOCATE PREPARE SWT_Stmt;
         set v_Counter_Copy = v_Counter_Copy+1;
         CALL IsFileExist('e:\\tariff',v_file,v_flag);
      END WHILE;
   end if;              
            

   if exists(select * from master.Sysservers where srvname = 'Excel_Tariff') then

      CALL sp_dropserver('Excel_Tariff','droplogins');
   end if;        
        

   SET v_server  = 'Excel_Tariff';                
   SET v_srvproduct = 'Excel';                
   SET v_provider  = 'Microsoft.ACE.OLEDB.12.0';                
   SET v_datasrc  = CONCAT_WS('',v_path,v_file);              

   SET v_provstr  = 'Excel 8.0';                
   SET v_RC = sp_addlinkedserver(v_server,v_srvproduct,v_provider,v_datasrc,v_location,v_provstr,v_catalog);                
  
  
              
   if exists(select * from sysobjects where xtype = 'u' and name = replace(replace(v_tablename,'[',''),']','')) then
   
      set v_sql =CONCAT( '      drop table IF EXISTS ',  v_tablename);
      SET @SWV_Stmt = v_sql;
      PREPARE SWT_Stmt FROM @SWV_Stmt;
      EXECUTE SWT_Stmt;
      DEALLOCATE PREPARE SWT_Stmt;
   end if; 
   

   set v_Query = ' 
SELECT * into ' || v_tablename || '                
FROM OPENDATASOURCE(''Microsoft.ACE.OLEDB.12.0'',''Data Source=' || v_datasrc || ';Extended Properties=Excel 8.0'')...' || v_sheetname || '$';          
      
            
   SET @SWV_Stmt = v_Query;
   PREPARE SWT_Stmt FROM @SWV_Stmt;
   EXECUTE SWT_Stmt;
   DEALLOCATE PREPARE SWT_Stmt;              
          

   set v_netusecmd = 'master..xp_cmdshell ''del ''' || v_datasrc || '''''';        
   
SET @SWV_Stmt = v_netusecmd;
   PREPARE SWT_Stmt FROM @SWV_Stmt;
   EXECUTE SWT_Stmt;
   DEALLOCATE PREPARE SWT_Stmt;        
        

   set v_netusecmd = 'master..xp_cmdshell ''del ''' || v_exceldir || '\\' || v_file || '''''';        



        
   set v_netusecmd = 'master..xp_cmdshell ''net use ' || v_exceldir || ' /delete''';        
   
SET @SWV_Stmt = v_netusecmd;
   PREPARE SWT_Stmt FROM @SWV_Stmt;
   EXECUTE SWT_Stmt;
   DEALLOCATE PREPARE SWT_Stmt;        
        

   if exists(select * from master.Sysservers where srvname = 'Excel_Tariff') then

      CALL sp_dropserver('Excel_Tariff','droplogins');
   end if;        
                   
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `utms_upload_tariff_rate` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `utms_upload_tariff_rate`(
bundleid INT,  
in_xml_data LONGTEXT ,  
in_user_name VARCHAR(50))
BEGIN

  
  
   
  
   CALL unifiedring.tm_upload_bundle_rate_info(bundleid,in_xml_data,in_user_name);  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `utms_upload_web_tariff_rates` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `utms_upload_web_tariff_rates`(callingtype INT,
filename   VARCHAR(200),
login_by VARCHAR(150))
SWL_return:
BEGIN

   DECLARE v_vTempTariff VARCHAR(250);
   DECLARE v_vPath VARCHAR(250);
   DECLARE v_vSheetName VARCHAR(250);
   DECLARE v_sql LONGTEXT;
   DECLARE v_tablename LONGTEXT;
   DECLARE v_calling_type_out VARCHAR(250);
	
   DECLARE v_errcode INT; 
   DECLARE v_errmsg VARCHAR(150);
	
   DECLARE v_count INT;
   DECLARE Swv_RowCount INT;
   DECLARE SWF_Leave BOOLEAN DEFAULT FALSE; 

   sp_exit:
   BEGIN
      set v_tablename = 'temp_tariff';
      SET v_calling_type_out = CASE WHEN  callingtype = 1 THEN 'DOMESTIC'
      WHEN callingtype = 2  then 'INTERNATIONAL' END;

      BEGIN
         DECLARE EXIT HANDLER FOR SQLEXCEPTION
         SWL_Handler:
         begin
            SET v_errcode = -1 , v_errcode = 'Failure';
            SET SWF_leave = TRUE;
            LEAVE SWL_Handler;
         end;
         IF SWF_leave IS TRUE THEN
            LEAVE SWL_return;
         END IF;
         if exists(select * from information_schema.tables a where a.table_name = tablename) then   
            set v_sql =CONCAT( 'drop table IF EXISTS ', '[', tablename,  ']');
            SET @SWV_Stmt = v_sql;
            PREPARE SWT_Stmt FROM @SWV_Stmt;
            EXECUTE SWT_Stmt;
            DEALLOCATE PREPARE SWT_Stmt;
            
         end if;
         SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
         select   dbpath, sheetname INTO v_vPath,v_vSheetName from esp.tariff_fileupload_config  where UsedByTool = 'UTMS'    LIMIT 1;
         SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ; 
   
   
    
         CALL esp.utms_Upload_Excel(v_vPath,filename,v_tablename,v_vSheetName,'MCM');
         set v_sql =CONCAT( ' select * into ', tablename, ' from ',  tablename);
         SET @SWV_Stmt = v_sql;
         PREPARE SWT_Stmt FROM @SWV_Stmt;
         EXECUTE SWT_Stmt;
         DEALLOCATE PREPARE SWT_Stmt;
         IF EXISTS(Select Country,Prefix,Type,count(1) from temp_tariff
         group by Country,Prefix,Type
         having count(1) > 1) then
   
            SET v_errcode = -1;
            SET v_errmsg = 'Same county+Prefix+Type was duplicated.Please check uploaded excel sheet';
            LEAVE sp_exit;
         end if;
         DELETE FROM UTMS_WEB_RATE_CONFIG WHERE calling_type = v_calling_type_out;
         SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
         INSERT INTO UTMS_WEB_RATE_CONFIG(calling_type,country,prefix,rate,Type,create_date,create_by,filename)
         select calling_type_out,Country,Prefix,rate,Type,CURRENT_TIMESTAMP,login_by,filename 
         from temp_tariff;
         SET Swv_RowCount = ROW_COUNT();
         SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
         if Swv_RowCount > 0 then
   
            SET v_errcode = 0;
            SET v_errmsg = 'Success to upload tariff rates';
            LEAVE sp_exit;
         end if;
      END;
   END;
   
   SELECT v_errcode as errcode,v_errmsg as errmsg; 
   
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UTMS_Validate_login_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `UTMS_Validate_login_info`(
 Username VARCHAR(50),
 Password VARCHAR(50),
 Last_login_Ip VARCHAR(250))
BEGIN

    DECLARE v_errcode INT;
    DECLARE v_errmsg VARCHAR(250);
    DECLARE v_role_id INT; 
    DECLARE v_User_ID INT; 
 	DECLARE int_default_val int;
    
    sp_exit:
    BEGIN
     
       set v_errcode = -1;
       set v_errmsg = 'User details not found@';
 	   set int_default_val  =0;
    
 	
       IF NOT  EXISTS(SELECT  1 FROM  Userprofile a WHERE a.Username = Username LIMIT 1) then
 	
          SET v_errcode = -1;
          SET v_errmsg = 'User details not found!';
          LEAVE sp_exit;
       end if;
 	
 	
       IF   EXISTS(SELECT  1 FROM Userprofile b WHERE b.Username = Username and status <> 1 LIMIT 1) then
 	
          SET v_errcode = -1;
          SET v_errmsg = 'User is not acive.Please contact Administrator!';
          LEAVE sp_exit;
       end if;
 	
 	
 	
 	
 	
       IF   EXISTS(SELECT  1 FROM   Userprofile a  join Userrole b 
       on a.fk_role_id = b.pk_role_id
       and b.role_status = 1
       WHERE a.Username = Username
       and a.Password  = Password LIMIT 1) then
 		
          SET v_errcode = 0;
          SET v_errmsg = 'User Authenticated!';
          UPDATE Userprofile a SET a.last_login_date = CURRENT_TIMESTAMP,a.last_login_ip = Last_login_Ip
          WHERE a.username = Username and a.Password  = Password;
          
          select a.Fk_role_Id,a.Userid into v_role_id,v_User_ID from Userprofile a WHERE a.username = Username 
          and a.Password  = Password;
          
          LEAVE sp_exit;
       ELSE
          SET v_errcode = -1;
          SET v_errmsg = 'Password is Invalid/Role is inactive!';
          LEAVE sp_exit;
       end if;
    END;
    Select v_errcode as errcode,v_errmsg as errmsg,IFNULL(v_role_id,int_default_val) as role_id,
 IFNULL(v_User_ID,int_default_val) as UserId;
 	
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UTMS_Validate_user_role_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `UTMS_Validate_user_role_info`(Userid INT)
Begin
 
    DECLARE v_errcode INT;
    DECLARE v_errmsg VARCHAR(250);
    DECLARE v_role_id INT; 
 
    sp_exit:
    BEGIN
       set v_errcode = -1;
       set v_errmsg = 'User details not found';
       
       IF Userid = '' or Userid = 0 then
 		
          SET v_errcode = -1;
          SET v_errmsg = 'User ID should not be empty or Zero!';
          LEAVE Sp_exit;
       end if;
       
       IF NOT EXISTS(SELECT  * FROM Userprofile a WHERE a.Userid = Userid LIMIT 1) then
 		
          SET v_errcode = -1;
          SET v_errmsg = 'User details not found!';
          LEAVE sp_exit;
       end if;
       
       IF EXISTS(SELECT  * FROM Userprofile a WHERE a.Userid = Userid and a.status = 0 LIMIT 1) then
 		
          SET v_errcode = -1;
          SET v_errmsg = 'User status is inactive!';
          LEAVE sp_exit;
       end if;
       
       SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
       select  a.Fk_role_Id INTO v_role_id FROM Userprofile a WHERE a.Userid = Userid and a.status = 1;
       SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
       
       If Exists(select  *  from Userrole b  where b.Pk_role_id = v_role_id and b.role_status = 0 LIMIT 1) then
 		
          SET v_errcode = -1;
          SET v_errmsg = 'User role status is inactive!';
          LEAVE sp_exit;
       end if;
       
       IF Exists(SELECT  * FROM Userprofile a  JOIN Userrole b ON a.Fk_role_Id = b.Pk_role_id
       WHERE a.Userid = Userid and a.status = 1 and b.role_status = 1 LIMIT 1) then
 		
          SET v_errcode = 0;
          SET v_errmsg = 'Success Active user and role found!';
          LEAVE sp_exit;
       end if;
    END;
    select v_errcode as errcode, v_errmsg as errmsg;
 
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-21  9:53:39
