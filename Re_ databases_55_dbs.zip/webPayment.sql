-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: webPayment
-- ------------------------------------------------------
-- Server version	8.0.44-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `webPayment`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `webPayment` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `webPayment`;

--
-- Table structure for table `RX_topup_log`
--

DROP TABLE IF EXISTS `RX_topup_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RX_topup_log` (
  `ref_code` int DEFAULT NULL,
  `decision` varchar(10) DEFAULT NULL,
  `request_id` varchar(30) DEFAULT NULL,
  `authorization_code` varchar(10) DEFAULT NULL,
  `request_time` varchar(50) DEFAULT NULL,
  `payment_status` int DEFAULT NULL,
  `payment_description` varchar(255) DEFAULT NULL,
  `topup_status` int DEFAULT NULL,
  `topup_description` varchar(255) DEFAULT NULL,
  `sorderid` varchar(50) DEFAULT NULL,
  `reconciliation_id` varchar(50) DEFAULT NULL,
  `createddate` datetime(3) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=403605 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `crm_link_server`
--

DROP TABLE IF EXISTS `crm_link_server`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `crm_link_server` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sitecode` varchar(3) NOT NULL,
  `link_servername` varchar(250) NOT NULL,
  PRIMARY KEY (`sitecode`,`link_servername`(191)),
  UNIQUE KEY `id` (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tAuxAutoTopup`
--

DROP TABLE IF EXISTS `tAuxAutoTopup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tAuxAutoTopup` (
  `MobileNo` varchar(30) NOT NULL,
  `SubscriptionID` varchar(40) DEFAULT NULL,
  `TopupAmount` decimal(19,4) DEFAULT NULL,
  `TopupCurr` varchar(3) DEFAULT NULL,
  `Status` int DEFAULT NULL,
  `LastUpdate` datetime(3) DEFAULT NULL,
  `LastOrderID` bigint DEFAULT NULL,
  `ProductID` int DEFAULT NULL,
  `sOrderID` varchar(20) DEFAULT NULL,
  `ReconciliationID` varchar(50) DEFAULT NULL,
  `VAT_Amount` float DEFAULT NULL,
  `country` varchar(250) DEFAULT NULL,
  `non_vectone_no` varchar(20) DEFAULT NULL,
  `enable_by` varchar(50) DEFAULT NULL,
  `payment_ref` varchar(50) DEFAULT NULL,
  `disable_by` varchar(50) DEFAULT NULL,
  `disable_date` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`MobileNo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tAuxAutoTopupLog`
--

DROP TABLE IF EXISTS `tAuxAutoTopupLog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tAuxAutoTopupLog` (
  `LogID` bigint NOT NULL AUTO_INCREMENT,
  `MobileNo` varchar(30) NOT NULL,
  `SubscriptionID` varchar(40) DEFAULT NULL,
  `MinLevelID` int DEFAULT NULL,
  `ItemID` int DEFAULT NULL,
  `OrderID` bigint DEFAULT NULL,
  `reason` varchar(250) DEFAULT NULL,
  `result` int DEFAULT NULL,
  `reasonsubs` varchar(50) DEFAULT NULL,
  `description` varchar(250) DEFAULT NULL,
  `CreatedDate` datetime(3) DEFAULT NULL,
  `submit_by` varchar(50) DEFAULT NULL,
  `ReconciliationID` varchar(50) DEFAULT NULL,
  `payment_ref` varchar(50) DEFAULT NULL,
  `disable_by` varchar(50) DEFAULT NULL,
  `disable_date` datetime(3) DEFAULT NULL,
  `topup_amount` float DEFAULT NULL,
  `enable_date` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`LogID`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=775743 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tCybS_RegisteredPayment`
--

DROP TABLE IF EXISTS `tCybS_RegisteredPayment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tCybS_RegisteredPayment` (
  `ref_code` int NOT NULL AUTO_INCREMENT,
  `reg_date` varchar(20) DEFAULT NULL,
  `mobileno` varchar(30) DEFAULT NULL,
  `subscription_id` varchar(50) DEFAULT NULL,
  `currency` varchar(5) DEFAULT NULL,
  `threshold_amount` float DEFAULT NULL,
  `amount` float DEFAULT NULL,
  `decision` varchar(10) DEFAULT NULL,
  `request_id` varchar(30) DEFAULT NULL,
  `authorization_code` varchar(10) DEFAULT NULL,
  `request_time` varchar(50) DEFAULT NULL,
  `payment_status` int DEFAULT '0',
  `payment_description` varchar(255) DEFAULT 'Waiting...',
  `topup_status` int DEFAULT '0',
  `topup_description` varchar(255) DEFAULT 'Waiting...',
  `sorderid` varchar(50) DEFAULT NULL,
  `reconciliation_id` varchar(50) DEFAULT NULL,
  `srd` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`ref_code`),
  KEY `idx_sorderid` (`sorderid`),
  KEY `idx2` (`reg_date`,`mobileno`,`topup_status`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=2448330 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tDirectDebitOrder`
--

DROP TABLE IF EXISTS `tDirectDebitOrder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tDirectDebitOrder` (
  `orderid` bigint NOT NULL,
  `ddref` varchar(32) NOT NULL,
  `originatorID` varchar(10) DEFAULT NULL,
  `buildingsociety` varchar(64) DEFAULT NULL,
  `accountname` varchar(100) DEFAULT NULL,
  `branchsortcode` varchar(10) DEFAULT NULL,
  `accountnumber` varchar(32) DEFAULT NULL,
  `orderdate` datetime(3) DEFAULT NULL,
  `amountpaid` float DEFAULT NULL,
  `custID` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`orderid`,`ddref`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tOrderDetail`
--

DROP TABLE IF EXISTS `tOrderDetail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tOrderDetail` (
  `OrderID` bigint NOT NULL AUTO_INCREMENT,
  `CustID` varchar(255) DEFAULT NULL,
  `DateCreated` datetime(3) DEFAULT NULL,
  `PayID` bigint DEFAULT NULL,
  `Status` int DEFAULT NULL,
  `AmountPaid` decimal(18,4) DEFAULT NULL,
  `AmountPaidTag` varchar(50) DEFAULT NULL,
  `OrderDescription` varchar(2000) DEFAULT NULL,
  `OrderKey` char(36) DEFAULT NULL,
  `ItemID` int DEFAULT NULL,
  `ItemAmount` decimal(18,4) DEFAULT NULL,
  `ItemCurrency` varchar(50) DEFAULT NULL,
  `ItemPriceTag` varchar(50) DEFAULT NULL,
  `VAT` decimal(18,4) DEFAULT NULL,
  `sOrderID` varchar(35) DEFAULT NULL,
  `iOrderID` bigint DEFAULT NULL,
  `ProcessDescription` varchar(2000) DEFAULT NULL,
  `AmountPaidCurrency` varchar(3) DEFAULT NULL,
  `ConversionRate` float DEFAULT NULL,
  `ReconciliationID` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`OrderID`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=3202750 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tRefItem`
--

DROP TABLE IF EXISTS `tRefItem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tRefItem` (
  `ItemID` bigint NOT NULL AUTO_INCREMENT,
  `ItemDescription` varchar(50) DEFAULT NULL,
  `ItemPrice` decimal(18,4) DEFAULT NULL,
  `ItemType` int DEFAULT NULL,
  `ItemPriceTag` varchar(50) DEFAULT NULL,
  `ItemCurrency` varchar(5) DEFAULT NULL,
  `ItemVAT` decimal(18,4) DEFAULT NULL,
  `SiteID` varchar(40) DEFAULT NULL,
  `Note` varchar(1000) DEFAULT NULL,
  `groupID` bigint DEFAULT NULL,
  `groupSort` bigint DEFAULT NULL,
  `intValue1` int DEFAULT NULL,
  `strValue1` varchar(50) DEFAULT NULL,
  `svc_id` int DEFAULT NULL,
  `ProductSKU` varchar(32) DEFAULT NULL,
  `bundleid` int DEFAULT NULL,
  `Note2` varchar(1000) DEFAULT NULL,
  `isActive` smallint DEFAULT '0',
  PRIMARY KEY (`ItemID`),
  KEY `idx0` (`ItemID`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=2838 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping events for database 'webPayment'
--

--
-- Dumping routines for database 'webPayment'
--
/*!50003 DROP PROCEDURE IF EXISTS `CRM_Monthly_Bill_Line_Rental_Detail_Get_SP` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `CRM_Monthly_Bill_Line_Rental_Detail_Get_SP`(v_Company_Id INT, v_Bill_ref VARCHAR(25))
BEGIN

          
   DECLARE v_period VARCHAR(7);          
   DECLARE v_plan_name VARCHAR(500);
   DECLARE v_total FLOAT;          
   DECLARE v_opdate DATETIME(3);          
   DECLARE v_opdate1 DATETIME(3);          
   DECLARE v_Frmdt VARCHAR(10);          
   DECLARE v_Todt VARCHAR(10);      
   DECLARE v_Customer_id INT;
   DECLARE v_order_type_idx INT;              
   DECLARE v_cnt INT;          
                
   If v_Bill_ref = '' then

      Set v_Bill_ref = NULL;
   end if;  
   select customer_id v_Customer_id from vbcp_company where company_id = v_Company_Id;      
   set v_opdate1 = CONVERT(CONCAT(RIGHT(CONCAT('00',CONVERT(month(v_opdate) -1,CHAR(30))),2),'-01',
   '-',CONVERT(Year(CURRENT_TIMESTAMP),CHAR(30))),DATETIME(3));  
   set v_Frmdt = DATE_FORMAT(v_opdate1,'%d %b %Y');  
   set v_Todt = CONCAT(CONVERT(TIMESTAMPDIFF(DAY,TIMESTAMPADD(day,-1,v_opdate1),(TIMESTAMPADD(day,-1,TIMESTAMPADD(MONTH,1,TIMESTAMPADD(day,1,(v_opdate1 -Day(v_opdate1))))))),CHAR(30)),' ',RIGHT(rtrim(ltrim(DATE_FORMAT(v_opdate1,'%d %b %Y'))),3));  
  

   drop table IF EXISTS tt_temp1;  
   CREATE TABLE tt_TEMP1 
   (
      idx INT,
      plan_name VARCHAR(500),
      total FLOAT, 
      Ot_plan FLOAT,
      st_dt VARCHAR(10),
      to_dt VARCHAR(10) 
   );  
                                                                              
   drop table IF EXISTS tt_temp;                                 
   CREATE TABLE tt_TEMP 
   (
      idx CHAR(5),
      plan_name VARCHAR(500),
      description VARCHAR(500),                                                                                
     
      `value` VARCHAR(50), 
      price VARCHAR(50),
      unit VARCHAR(500),
      item_id VARCHAR(500), 
      Adjustment_amt VARCHAR(50), 
      MobileNo VARCHAR(16),
      st_dt VARCHAR(10), 
      to_dt VARCHAR(10)
   );                                                          
                                                                            
   drop table IF EXISTS tt_temp2;                                                
   CREATE TABLE tt_temp2
   (
      Bill_ref VARCHAR(50),
      description VARCHAR(500),
      plan_name VARCHAR(500),
      `value` FLOAT,
      price FLOAT,
      unit VARCHAR(50),
      item_id VARCHAR(50),
      Adjustment_amt FLOAT,
      total FLOAT,
      Ot_plan VARCHAR(50),
      From_date VARCHAR(50),
      to_date VARCHAR(50),
      OpStartDate VARCHAR(50),
      OpEndDate VARCHAR(50)
   );                                                
                                                                 
   drop table IF EXISTS tt_Bill_Det;                                               
                                                                               
   insert into tt_TEMP(idx,plan_name,description,`value`,price,unit,Adjustment_amt,MobileNo,st_dt,to_dt)
   SELECT '3' idx ,vap.family_code as plan_name,vapb.descript description,
 CAST(vapb.price AS DECIMAL(10,2)) AS `value`,
 CAST(vapb.price AS DECIMAL(10,2)) as price,
 '£' as unit,
 Case ord.order_type_idx When 1 Then -1 Else 1 End*case when DATE_FORMAT(vapb.startdate,'%Y-%m-%d') = DATE_FORMAT(TIMESTAMPADD(day,-1,STR_TO_DATE(DATE_FORMAT(TIMESTAMPADD(day,1,CURRENT_TIMESTAMP -Day(CURRENT_TIMESTAMP)),
   '%Y-%m-%d'),'%Y-%m-%d')),
   '%Y-%m-%d') then
      cast(vapb.price/(DAY(TIMESTAMPADD(MONTH,TIMESTAMPDIFF(MONTH,TIMESTAMPADD(MONTH,-1,'1900-01-01 00:00:00'),vapb.startdate),TIMESTAMPADD(MONTH,-1,'1900-01-01 00:00:00'))))*(DAY(vapb.startdate) -1) AS DECIMAL(10,2)) else 0 end as Adjustment_amt
 ,'' As MobileNo      ,CONVERT((vapb.startdate -(Day(vapb.startdate) -1)),CHAR(7)) st_dt,  DATE_FORMAT((TIMESTAMPADD(DAY,-1,vapb.startdate)),'%Y-%m-%d') to_dt    FROM  vt_account_plan_bundle vapb
   JOIN   vt_account_plan vap ON vapb.account_plan_id = vap.account_plan_id
   JOIN vtos_option vo
   ON vo.option_code = vapb.option_code
   Left Outer Join crm_order ord  On vap.basket_id = ord.basket_id
   WHERE vapb.account_plan_id in(SELECT account_plan_id
      FROM vt_account_plan vap  where vap.company_id = v_Company_Id
      AND vap.family_code not in('mobile','ip phone'))
   UNION ALL
   SELECT '3' idx ,vap.family_code as plan_name,CONCAT(vap.descript,'/',vpv.descript) description,
 CAST(vap.price AS DECIMAL(10,2)) as `value`,
 CAST(vap.price AS DECIMAL(10,2)) as price,
 '£' AS unit   ,
 case when DATE_FORMAT(l.log_date,'%Y-%m-%d') = DATE_FORMAT(TIMESTAMPADD(day,-1,STR_TO_DATE(DATE_FORMAT(TIMESTAMPADD(day,1,CURRENT_TIMESTAMP -Day(CURRENT_TIMESTAMP)),
   '%Y-%m-%d'),'%Y-%m-%d')),
   '%Y-%m-%d') then
      cast(vap.price/(DAY(TIMESTAMPADD(MONTH,TIMESTAMPDIFF(MONTH,TIMESTAMPADD(MONTH,-1,'1900-01-01 00:00:00'),l.log_date),TIMESTAMPADD(MONTH,-1,'1900-01-01 00:00:00'))))*(DAY(l.log_date) -1) AS DECIMAL(10,2)) else 0 end as Adjustment_amt
 ,'' As MobileNo  ,
 CONVERT((l.log_date -(Day(l.log_date) -1)),CHAR(10)) st_dat,
 DATE_FORMAT((TIMESTAMPADD(DAY,-1,l.log_date)),'%Y-%m-%d') to_dt
   FROM vt_account_plan vap
   JOIN vtos_product vp
   ON vap.product_code = vp.product_code
   JOIN vtos_product_variant vpv
   ON vpv.variant_code = vp.variant_code
   Join crm_order ord  On vap.basket_id = ord.basket_id
   Join crm_customer_history_log l on l.customer_id = v_Customer_id and vap.basket_id = l.order_id
   WHERE   vap.company_id = v_Company_Id
   AND vap.family_code in('Line Rental','Line rental and Broadband')
   AND l.note like '%Linerental Status set to: Completed';  
   insert into tt_TEMP1(idx,plan_name,total,Ot_plan,st_dt,to_dt)
   select idx,plan_name, SUM(`value`) -sum(Adjustment_amt),Sum(Round(va.totalcons/100.00,2)) As Ot_plan
  ,DATE_FORMAT(TIMESTAMPADD(MONTH,-1,TIMESTAMPADD(DAY,1,CURRENT_TIMESTAMP -Day(CURRENT_TIMESTAMP))),'%d %b %Y') st_dt,DATE_FORMAT(TIMESTAMPADD(DAY,-1,TIMESTAMPADD(DAY,1,CURRENT_TIMESTAMP -Day(CURRENT_TIMESTAMP))),'%d %b %Y') to_dt
   from tt_temp t
   left outer join esp.mvno_account v on t.MobileNo = v.mobileno
   left outer join esp.account va
   on v.custcode = va.custcode and v.batchcode = va.batchcode and v.serialcode = va.serialcode and va.telcocode = 'ics'
   group by plan_name,idx;                            
                                                               
   insert into tt_temp2
   select v_Bill_ref As Bill_ref,CONCAT(cast(count(*) as CHAR(10)),' * ',a.description) description,min(a.plan_name) plan_name,sum(cast(a.`value` as DECIMAL(15,15))) `value`,min(cast(a.price as DECIMAL(15,15))) price,min(a.unit) unit,min(item_id) item_id,
 cast(sum(cast(a.Adjustment_amt as DECIMAL(15,15))) as SIGNED INTEGER) As Adjustment_amt,
 cast(min(b.total) as SIGNED INTEGER) As total, cast(Min(IFNULL(b.Ot_plan,0)) as SIGNED INTEGER) As Ot_plan 
  
  
  
 ,a.st_dt From_date,a.to_dt to_date, IFNULL(max(b.st_dt),v_Frmdt) OpStartDate,IFNULL(max(b.to_dt),v_Todt) OpEndDate
   from tt_temp a
   INNER JOIN tt_TEMP1 b ON  a.plan_name = b.plan_name
   group by  a.description,a.st_dt,a.to_dt
   order by plan_name desc;                                          
        
   SELECT order_type_idx v_order_type_idx
   FROM vt_account_plan vap
   JOIN vtos_product vp
   ON vap.product_code = vp.product_code
   JOIN vtos_product_variant vpv
   ON vpv.variant_code = vp.variant_code
   Left Outer Join crm_order ord  On vap.basket_id = ord.basket_id
   WHERE   vap.company_id = v_Company_Id
   AND vap.family_code not in('mobile','ip phone');               
               
   If  v_order_type_idx = 1 then
 
      Update tt_temp2 Set Adjustment_amt = -1*Adjustment_amt;
   end if;              
          
      
   CREATE TABLE tt_Bill_Det AS select * from tt_temp2  order by plan_name desc;                                                 
              
   select COUNT(*) v_cnt  from tt_Bill_Det;                                         
   select * from(select Bill_ref,description,plan_name,CONCAT_WS('',plan_name,'00') as plan_name1,`value`,price,unit,item_id,'pDetail' rectyp  , CONVERT(ROW_NUMBER() over(ORDER BY plan_name desc),CHAR(30)) AS rid ,'' as from_date,'' as to_date ,'UB'  distyp , DENSE_RANK() OVER(ORDER BY plan_name desc)  as i1,1 as chkval from tt_Bill_Det
      UNION ALL
      select   Bill_ref,' ' description,  plan_name, CONCAT_WS('',plan_name,'01') as plan_name1 ,Null `value`,Null price,Null unit,Null item_id
 ,'pDetail' rectyp ,COUNT(*)+1 as rid,'' as from_date,'' as to_date ,'UB'  distyp
 , DENSE_RANK() OVER(ORDER BY plan_name desc) as i1, 0 as chkval from  tt_Bill_Det group by plan_name,Bill_ref
      UNION ALL
      select  Bill_ref,CONCAT(' Out of Plan Usage ( from ',min(OpStartDate),' To ',MAX(OpEndDate),
      ')')  description
 ,plan_name,CONCAT_WS('',plan_name,'02') as plan_name1,sum(cast(Ot_plan as DECIMAL(15,15))) `value`,SUM(cast(Ot_plan as DECIMAL(15,15))) price,min(unit) unit
 ,min(item_id) item_id,'OPDetail                                          
 ' rectyp,88 rectyp ,min(OpStartDate) as from_date,MAX(OpEndDate) as to_date ,'B'  distyp , DENSE_RANK() OVER(ORDER BY plan_name desc) as i1
 , 1 as chkval from tt_Bill_Det group by plan_name,Bill_ref
      union all
      select   Bill_ref,' ' description,  plan_name, CONCAT_WS('',plan_name,'03') as plan_name1 ,Null `value`,Null price,Null unit,Null item_id,'pDetail' rectyp
 ,COUNT(*)+1 as rid,'' as from_date,'' as to_date ,'UB'  distyp , DENSE_RANK() OVER(ORDER BY plan_name desc) as i1 , 0 as chkval
      from  tt_Bill_Det group by plan_name,Bill_ref
      union all
      select   Bill_ref,'Credits & Adjustments ' description,  plan_name, CONCAT_WS('',plan_name,'04') as plan_name1 ,Null `value`,Null price,Null unit,Null item_id,'pDetail' rectyp ,COUNT(*)+1 as rid,'' as from_date,'' as to_date ,'B'  distyp ,
 DENSE_RANK() OVER(ORDER BY plan_name desc) as i1, 0 as chkval from  tt_Bill_Det
      group by plan_name,Bill_ref
      union all
      select  Bill_ref,'N/A ' as description,plan_name,CONCAT_WS('',plan_name,'05') as plan_name1,Null As `value`, Null As price,Null Asunit,Null As item_id,
 'AdjDetail' rectyp  , 99 AS rid,Null As from_date,Null As to_date,'UB'  distyp , DENSE_RANK() OVER(ORDER BY plan_name desc) as i1, 1 as chkval
      From tt_Bill_Det a Where Not Exists(Select 1 From tt_Bill_Det b Where a.plan_name = b.plan_name and a.Adjustment_amt <> 0)
      union all
      select  Bill_ref,CONCAT_WS('',description,'  (from ',DATE_FORMAT(convert(from_date,DATE),'%d %b %Y'),
      ' To ',DATE_FORMAT(convert(to_date,DATE),'%d %b %Y'),')') as description,plan_name,CONCAT_WS('',plan_name,'05') as plan_name1,Adjustment_amt `value`,
 Adjustment_amt price,unit,item_id,'AdjDetail' rectyp  , 99 AS rid,
 DATE_FORMAT(convert(from_date,DATE),'%d %b %Y') from_date,
 DATE_FORMAT(convert(to_date,DATE),'%d %b %Y') to_date,'UB'  distyp
,DENSE_RANK() OVER(ORDER BY plan_name desc) as i1, 1 as chkval
      from tt_Bill_Det  Where Adjustment_amt <> 0) a order by a.plan_name desc,a.plan_name1 asc,Bill_ref;    
                                           
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `mvno_validate_auto_topup` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `mvno_validate_auto_topup`(
mobileno VARCHAR(20),  
OUT topup_count INT)
BEGIN

  
   
   
   DECLARE v_now DATETIME(3);   
   
   set v_now = CURRENT_TIMESTAMP;   
   
   set topup_count = 0;  
   
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   count(1) INTO topup_count from tCybS_RegisteredPayment a where a.mobileno = mobileno and year(reg_date) = year(v_now) and
   month(reg_date) = month(v_now) and
   decision = 'ACCEPT';
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
  
   
   set topup_count = IFNULL(topup_count,0);  
   
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `payment_getInfoSKU` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `payment_getInfoSKU`(
 productSKU varchar(32),
 productSKU2 varchar(32)
 
 
 
 )
Begin
 
  DECLARE productSKU3 varchar(32);
 DECLARE productSKU4 varchar(32);
 DECLARE productSKU5 varchar(32);
 
 	if productSKU2 ='' then set productSKU2 = null; end if;
 	if productSKU3 ='' then set productSKU3 = null; end if;
 	if productSKU4 ='' then set productSKU4 = null; end if;
 	if productSKU5 ='' then set productSKU5 = null; end if;
 
 
 	select a.ItemID, a.ItemDescription, a.ItemPrice, a.ItemType, a.ItemPriceTag, a.ItemCurrency, a.ItemVAT, a.SiteID, a.Note, a.groupID,
 	a.groupSort, a.intValue1, a.strValue1, a.svc_id, a.ProductSKU, a.bundleid
 	from tRefItem a where a.ProductSKU = productSKU or a.ProductSKU = productSKU2 or a.ProductSKU = productSKU3 or a.ProductSKU = productSKU4 or a.ProductSKU = productSKU5
 	order by a.ItemID limit 1;
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `RlxPaymentGetTopupInfo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `RlxPaymentGetTopupInfo`(msisdn VARCHAR(30),
firstlogin VARCHAR(12))
SWL_return:
BEGIN
	
    
   DECLARE idx INT;   
   DECLARE SubscriptionID VARCHAR(40);
   DECLARE is_realx INT;
   DECLARE ip_address VARCHAR(150);

   DECLARE rx_topup_currency VARCHAR(10);
   DECLARE non_vectone_no VARCHAR(20);
	
   DECLARE aut_flag INT; 
   DECLARE cc_no VARCHAR(20);
	 
   IF firstlogin is null then
      set firstlogin = '';
   END IF;
   
   set is_realx = 0;
   set ip_address = '';
   set non_vectone_no = '';
 
   set aut_flag = 0;
   
	
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select a.non_vectone_no INTO non_vectone_no from tAuxAutoTopup a where a.MobileNo = msisdn and IFNULL(non_vectone_no,'') <> '';
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
	
	
   if IFNULL(non_vectone_no,'') <> '' then
      set msisdn = non_vectone_no;
   end if;
	
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select a.idx INTO idx from payment.tSubscription a where a.Account_Id = msisdn and ((a.purchasedate >= firstlogin) or (firstlogin = ''))  
   order by convert(purchasedate,DATETIME(3)) desc,idx desc LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
    
   SET idx = IFNULL(idx,0);  
	    
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select a.SubscriptionID, IFNULL(a.Last6digitsCC,'') INTO SubscriptionID,cc_no from payment.tSubscription a where a.idx = idx;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  

	
   CALL payment.mvno_check_realx_transaction(msisdn,is_realx);    

   if is_realx = 0 then
	  
      LEAVE SWL_return;
   end if;
	 
	
	
			
   DROP TEMPORARY TABLE IF EXISTS tt_temp_tpayment_detail_info;
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   CREATE TEMPORARY TABLE tt_temp_tpayment_detail_info AS 
   select * from payment.tpayment
      where account_id = msisdn;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
		
			
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select IFNULL(IPClient,''), IFNULL(CURRENCY,'') INTO ip_address,rx_topup_currency 
   from tt_temp_tpayment_detail_info 
   where IPClient is not null and REFERENCE_ID like '%WEB%'
   AND ReplyMessage like '%Successful%' order by CREATED_DATE desc LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
		
   set aut_flag = 1;
		
   if left(msisdn,2) <> '44' then
		
      set aut_flag = 0;
      select 1 INTO aut_flag from tt_temp_tpayment_detail_info a where a.account_id = msisdn
      and IFNULL(a.ThreeDFlag,1) = 1 and a.cc_no = cc_no LIMIT 1;
   end if;
			
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select MobileNo,SubscriptionID SubscriptionID,TopupAmount,IFNULL(TopupCurr,rx_topup_currency) as TopupCurr,Status,
   LastUpdate,LastOrderID,ProductID,sOrderID,ReconciliationID,VAT_Amount,country,ip_address as ip_address,IFNULL(non_vectone_no,'') as non_vectone_no
   from tAuxAutoTopup
   where mobileno = msisdn  and aut_flag = 1
   and SubscriptionID is not null LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
	
END SWL_return ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `RX_UpdateAutoTopupStatus` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `RX_UpdateAutoTopupStatus`(
ref_code int ,
decision varchar(10),
request_id varchar(30),
authorization_code varchar(10),
request_time varchar(50),
payment_status int,
payment_description varchar(255),
topup_status int,
topup_description varchar(255),
sorderid varchar(50),
reconciliation_id varchar(50) , 
srd varchar(100) 
)
begin   

	declare errcode int;
	declare mobileno varchar(30);
	declare subscription_id varchar(40);
	declare rejected_trax int;
	declare disbale_auto_topup_Date datetime;
	declare disable_auto_topup int;
	declare disable_by varchar(100);

	declare lat_auto_topup_attempt_date datetime; 
	declare fail_reason  varchar(250);  

	if srd = '' or srd is null then set srd = ''; end if;
	if reconciliation_id = '' or reconciliation_id is null then set reconciliation_id = null; end if;
 
	insert into RX_topup_log(ref_code, decision,request_id,authorization_code,request_time,payment_status,payment_description,topup_status,topup_description,sorderid,reconciliation_id,createddate) 
	values(ref_code, decision,request_id,authorization_code,request_time,payment_status,payment_description,topup_status,topup_description,sorderid,reconciliation_id,CURRENT_TIMESTAMP);
  
	set errcode = -1; 

	set disable_auto_topup=1;
  
	  IF payment_description LIKE '%Waiting%' then
		set payment_status=-1;
		set topup_status=-1;
	  end if;
  
sp_end : begin

	select a.subscription_id, a.mobileno into subscription_id , mobileno 
	from tCybS_RegisteredPayment a where a.ref_code = ref_code;

	update tCybS_RegisteredPayment a set a.decision = decision,a.request_id = request_id,a.authorization_code = authorization_code,
	a.request_time = request_time,a.payment_status = payment_status,a.payment_description = payment_description,a.topup_status = topup_status,
	a.topup_description = topup_description,a.sorderid = sorderid,a.reconciliation_id = reconciliation_id,a.srd=srd
	where a.ref_code = ref_code;

	if error <> 0 then
		leave sp_end;
	end if;

	
	if payment_status in (200, 201, 202, 203, 205, 207, 208, 209, 211, 220, 221, 222, 230, 231, 232, 233, 240,-1)  then
			set disbale_auto_topup_Date=current_timestamp();
			set disable_auto_topup=0;
			set disable_by='AUT-EXE';

		update tAuxAutoTopup a set a.status = 0 where a.mobileno = mobileno and a.status = 1;

		if error <> 0 and row_count() < 1 then
			leave sp_end; 
		end if;
	
	else

	
	if decision = 'REJECT'  then
		
		select  count(a.subscription_id) into rejected_trax
		from tCybS_RegisteredPayment a
		where a.decision = 'REJECT' and a.subscription_id = subscription_id and timestampdiff(day, a.reg_date, current_timestamp) = 0
		group by a.subscription_id, DATE_FORMAT(a.reg_date, '%b %d %Y %h:%i%p');

		
		if rejected_trax >= 3 then
			update tAuxAutoTopup a set a.status = 0 where a.mobileno = mobileno and status = 1 ;

			set disbale_auto_topup_Date=current_timestamp();
						set disable_auto_topup=0;
						set disable_by='AUT-EXE'; 
			if rowcount = 0 then
				leave sp_end;
			end if;
		end if;
	end if;
end if;
set errcode = 0 ;

end sp_end;  

	set lat_auto_topup_attempt_date=current_timestamp() ;

	set fail_reason = case when decision='ACCEPT' THEN NULL ELSE  payment_description END;

	 IF LEFT(mobileno,2)='44' then
	 
			call mvno.hubspot_do_auto_topup_activity_register (mobileno,disable_auto_topup,NULL,NULL,disbale_auto_topup_Date,disable_by,
			lat_auto_topup_attempt_date,fail_reason,decision);
		
	 END if;
  
select errcode errcode;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ur_myaccount_enable_tAuxAutoTopup_status` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ur_myaccount_enable_tAuxAutoTopup_status`(
MobileNo VARCHAR(50) ,   
 TopupAmount DECIMAL(19,4) ,   
 TopupCurr VARCHAR(3),    
 calledby VARCHAR(50),  
 payment_ref VARCHAR(50),  
 INOUT errcode INT,  
 INOUT errmsg VARCHAR(160),  
 s_enable INT 
 )
SWL_return:begin
 
   
    DECLARE v_card_number VARCHAR(20);  
    DECLARE v_3d_flag INT;   
    
    IF calledby is null 
    then
       set calledby = '';
    END IF;
    IF payment_ref is null 
    then
       set payment_ref = '';
    END IF;
    IF errcode is null 
    then
       set errcode = 0;
    END IF;
    IF errmsg is null 
    then
       set errmsg = '';
    END IF;
    set v_3d_flag = 0;  
    set errcode = 0;  
    set errmsg = 'OK';  
    
    IF s_enable = 0 
    then
       update tAuxAutoTopup a set a.status = 0 where a.MobileNo = MobileNo;
       LEAVE SWL_return;
    end if;  
    
    
    IF s_enable = 3 
    then
    
       IF EXISTS(SELECT  1 FROM tAuxAutoTopup a WHERE a.MobileNo = MobileNo LIMIT 1) 
       then
          update tAuxAutoTopup b set b.status = 1,b.TopupAmount = TopupAmount,b.LastUpdate = CURRENT_TIMESTAMP
          where b.MobileNo = MobileNo;
       ELSE
       insert into  tAuxAutoTopup (MobileNo, TopupAmount, TopupCurr,Status, LastUpdate,payment_ref,enable_by)
     values(MobileNo, TopupAmount, TopupCurr,1, CURRENT_TIMESTAMP,payment_ref,calledby);
       end if;
       
       LEAVE SWL_return;
    end if;  
    
     
    IF s_enable = 1 
    then
       
       if exists(select * from tAuxAutoTopup a where a.MobileNo = MobileNo) 
       then
          delete FROM tAuxAutoTopup b where b.MobileNo = MobileNo;
       end if;
       
       if  exists(select * from tAuxAutoTopup  a where a.MobileNo = MobileNo and a.status = 1) 
       then
          update tAuxAutoTopup b set b.TopupAmount = TopupAmount,b.TopupCurr = TopupCurr,b.LastUpdate = CURRENT_TIMESTAMP,
          b.payment_ref = payment_ref,b.enable_by = calledby
          where b.MobileNo = MobileNo;
       else
      insert into tAuxAutoTopup(MobileNo, TopupAmount, TopupCurr,Status, LastUpdate,payment_ref,enable_by)
    values(MobileNo, TopupAmount, TopupCurr,1, CURRENT_TIMESTAMP,payment_ref,calledby);
       end if;  
      
      
    
       insert into tAuxAutoTopupLog(mobileno,reason,description,submit_by,payment_ref,CreatedDate,enable_date)
    values(MobileNo,'Auto topup ON','Enable Auto topup',calledby,payment_ref,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP);
    end if;  
    
      
     
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `vmukCybS_RegisterPayment` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `vmukCybS_RegisterPayment`(
    mobileno VARCHAR(30),  
    subscription_id VARCHAR(40),  
    currency VARCHAR(5),  
    threshold_amount FLOAT,  
    amount FLOAT)
begin

  
   DECLARE v_ref_code INT;  
   DECLARE v_day_trax FLOAT;  
   DECLARE v_week_trax FLOAT;  
   DECLARE v_month_trax FLOAT;  
   DECLARE v_fail_count INT;  
   DECLARE v_daily_success_count INT;
    
   DECLARE v_sp_name VARCHAR(250);
   DECLARE v_link_server_name VARCHAR(160);
   DECLARE v_sitecode VARCHAR(5);
   DECLARE v_notify_message VARCHAR(160);
   DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
   BEGIN
      SET @SWV_Error = 1;
   END;
      
  
   sp_end:
   BEGIN
      SET @SWV_Error = 0;
      SET v_ref_code = -1;
      SET v_day_trax = 0.0;
      SET v_week_trax = 0.0;
      SET v_month_trax = 0.0;
      set v_fail_count = 0;  
  
    
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select   IFNULL(sum(a.amount),0) INTO v_day_trax 
      from  tCybS_RegisteredPayment a
      where a.mobileno = mobileno    and a.topup_status = 0  and a.payment_description not like '%Waiting%'
      and left(a.reg_date,10) = DATE_FORMAT(CURRENT_TIMESTAMP,'%Y-%m-%d');
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
      
      
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select   IFNULL(sum(b.amount),0) 
      INTO v_week_trax
      from tCybS_RegisteredPayment b
      where b.mobileno = mobileno    and b.topup_status = 0
      and b.payment_description not like '%Waiting%'
      and left(b.reg_date,10) > DATE_FORMAT(TIMESTAMPADD(day,-7,CURRENT_TIMESTAMP),'%Y-%m-%d');
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
      
      
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select   IFNULL(sum(c.amount),0) 
      INTO v_month_trax
      from tCybS_RegisteredPayment c
      where c.mobileno = mobileno    and c.topup_status = 0
      and c.payment_description not like '%Waiting%'
      and left(c.reg_date,10) > DATE_FORMAT(TIMESTAMPADD(day,-30,CURRENT_TIMESTAMP),'%Y-%m-%d');
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
      
    
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select   count(1) 
      INTO v_fail_count
      from tCybS_RegisteredPayment d
      where d.mobileno = mobileno
      and d.topup_status = -1 and left(d.reg_date,10) = DATE_FORMAT(CURRENT_TIMESTAMP,'%Y-%m-%d');
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
      
      if v_fail_count >= 5 then
         LEAVE sp_end;
      end if;
      
      set v_daily_success_count = 0;
      
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select   count(1) 
      INTO v_daily_success_count
      from tCybS_RegisteredPayment e
      where e.topup_status = 0  and e.payment_description not like '%Waiting%'
      and e.mobileno = mobileno and e.decision = 'ACCEPT' and e.topup_status = 0
      and e.subscription_id = subscription_id
      and TIMESTAMPDIFF(HOUR,reg_date,CURRENT_TIMESTAMP) <= 24;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
	

  
 
  
    
      if  (v_day_trax < 50.0 OR (v_day_trax < 500 and currency in('SEK','DKK')))
      and (v_week_trax < 100.0 OR (v_week_trax < 1000 and currency in('SEK','DKK')))
      and (v_month_trax < 150 OR(v_month_trax < 1500 and currency in('SEK','DKK'))) then
      
        
         SET @SWV_Error = 0;
         insert into tCybS_RegisteredPayment(reg_date,  mobileno,  subscription_id,  currency,  threshold_amount,  amount)
        values(DATE_FORMAT(CURRENT_TIMESTAMP, '%Y-%m-%d %T') ,  mobileno,  subscription_id,  currency,  threshold_amount,  amount);
        
         if @SWV_Error <> 0 then 
            LEAVE sp_end;
         end if;
         set v_ref_code = LAST_INSERT_ID(); 
      else  
 
 insert into tCybS_RegisteredPayment(reg_date,  mobileno, subscription_id, currency, threshold_amount, amount, payment_status, payment_description, topup_status, topup_description)
        values(DATE_FORMAT(CURRENT_TIMESTAMP, '%Y-%m-%d %T'), mobileno,  subscription_id,  currency,  threshold_amount,  amount, -1, 'Canceled', -2, 'Topup Overlimit');
      end if;
   END;
   select v_ref_code ref_code;  
  
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `vmukPay2_addNewOrder` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `vmukPay2_addNewOrder`(
    email VARCHAR(50),  
    itemId INT,  
    orderKey VARCHAR(36) ,  
    orderID BIGINT,  
    orderRef VARCHAR(50))
begin

  
   DECLARE v_errcode INT;  
   DECLARE v_errmsg VARCHAR(255);  
   DECLARE v_transdate DATETIME(3);  
   DECLARE v_totalAmount FLOAT;  
  
   set v_transdate = CURRENT_TIMESTAMP;  
  
    
   if IFNULL(orderKey,'') = '' then
      set orderKey = UUID();
   end if;  
  
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   insert into  tOrderDetail(CustID, DateCreated, Status, AmountPaid, AmountPaidTag,
        OrderKey, ItemID, ItemAmount, ItemCurrency, ItemPriceTag, VAT,
        sOrderID, iOrderID)
   select
   email, v_transdate, 0, ItemPrice, ItemPriceTag,
        cast(orderKey as CHAR(36)), itemId, ItemPrice, '', ItemPriceTag, 0,
        orderRef, orderID
   from  tRefItem a
   where a.itemId = itemId;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
  
    
  
 
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   ItemPriceTag INTO v_totalAmount from tRefItem a where a.itemId = itemId;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
  
   if left(orderRef,7) = 'vmuk-pp' or left(orderRef,6) = 'mcm-pp' then
    
   
      CALL crm.PP_insert_pp_payment(orderRef,v_totalAmount,v_transdate,v_errcode,v_errmsg);
   end if;  
  
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select
   OrderID, CustID, DateCreated, PayID,
  Status, AmountPaid, OrderDescription, OrderKey,
  a.ItemID, a.ItemAmount, a.ItemCurrency, a.ItemPriceTag, VAT,
  b.ItemDescription, AmountPaidTag, sOrderID, iOrderID,
  0 as ErrorCode, 'Success' as ErrorDesc
   from tOrderDetail a 
   inner join tRefItem b 
   on a.ItemId = b.ItemId
   where orderkey = orderKey;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
  
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `vmukPay2_addNewOrder_V4` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `vmukPay2_addNewOrder_V4`(
	email VARCHAR(50),      
    itemId INT,      
    orderKey VARCHAR(36) ,    
    orderID BIGINT,    
    orderRef VARCHAR(50),  
    totalAmount FLOAT,  
	mobileno VARCHAR(12) ,  
	payment_status INT
)
begin

  
   DECLARE v_errcode INT;  
   DECLARE v_errmsg VARCHAR(255);  
   DECLARE v_transdate DATETIME(3);  
   
   set v_transdate = CURRENT_TIMESTAMP;  
  
    
   
   if IFNULL(orderKey,'') = '' 
   then
      set orderKey = UUID();
   end if;      
    
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   
   insert into tOrderDetail(CustID, DateCreated, Status, AmountPaid, AmountPaidTag,
        OrderKey, ItemID, ItemAmount, ItemCurrency, ItemPriceTag, VAT,sOrderID, iOrderID)
        
   select email, v_transdate, 0, totalAmount, convert(CONVERT(totalAmount,DECIMAL(10,2)),CHAR(10)),
        cast(orderKey as CHAR(36)), itemId, totalAmount, 'GBP', convert(CONVERT(totalAmount,DECIMAL(10,2)),CHAR(10)), 0,
        orderRef, orderID from tRefItem  a where a.itemId = itemId;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;       
   
    
   
   if mobileno is not null and left(orderRef,10) = 'vmuk-ppcub' 
   then       
      CALL crm.PP_insert_pp_payment_excess_v2(orderRef,totalAmount,v_transdate,mobileno,v_errcode,v_errmsg,payment_status);
   end if;  
   
   
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select a.OrderID, a.CustID, a.DateCreated, a.PayID,a.Status, a.AmountPaid, a.OrderDescription, a.OrderKey,
  a.ItemID, a.ItemAmount, a.ItemCurrency, a.ItemPriceTag, a.VAT,b.ItemDescription, a.AmountPaidTag, a.sOrderID, a.iOrderID,
  0 as ErrorCode, '' as ErrorDesc from  tOrderDetail a inner join tRefItem b on a.ItemId = b.ItemId where a.orderkey = orderKey;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;   
  
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `vmukPay2_tAuxAutoTopupLog` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `vmukPay2_tAuxAutoTopupLog`(
MobileNo VARCHAR(30)    
 , SubscriptionID VARCHAR(40)    
 , MinLevelID INT  
 , ItemID INT  
 , OrderID BIGINT  
 , reason VARCHAR(250)  
 , result INT   
 , reasonsubs VARCHAR(50)  
 , description VARCHAR(250))
begin

  
  
   DECLARE v_payment_ref VARCHAR(50);  
   DECLARE v_topupamount FLOAT;  
   
   DECLARE v_enable_date DATETIME(3);   
   
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   LastUpdate INTO v_enable_date from tAuxAutoTopup a where a.MobileNo = MobileNo and status = 1    LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
  
   select   REFERENCE_ID, TOTALAMOUNT INTO v_payment_ref,v_topupamount from TPAYMENT where account_id = MobileNo
   and ReplyMessage like '%Succ%'   order by CREATED_DATE desc LIMIT 1;  
      
   insert into tAuxAutoTopupLog(MobileNo, SubscriptionID, MinLevelID, ItemID, OrderID, reason, result, reasonsubs, description, CreatedDate,payment_ref,topup_amount,enable_date)
    values(MobileNo, SubscriptionID, MinLevelID, ItemID, OrderID, reason, result, reasonsubs, description, CURRENT_TIMESTAMP,v_payment_ref,v_topupamount,v_enable_date);    
             Select 0 errcode, 'Success' errmsg;  
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `vmuk_ppInsertDirectDebitOrder` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `vmuk_ppInsertDirectDebitOrder`(
orderid BIGINT ,        
originatorID VARCHAR(10),        
buildingsociety VARCHAR(64),        
accountname VARCHAR(100),        
branchsortcode VARCHAR(10),        
accountnumber VARCHAR(32),      
ddref VARCHAR(32))
begin


  
        
   DECLARE v_logparams VARCHAR(2000);


insert into tDirectDebitOrder(orderid,originatorID,ddref,buildingsociety,accountname, branchsortcode,accountnumber,orderdate)
 values(orderid,originatorID,ddref, buildingsociety,accountname, branchsortcode,accountnumber,CURRENT_TIMESTAMP);        
   
 
 
   set v_logparams = CONCAT('@orderid=',CAST(orderid as CHAR(30)),',@originatorID=',originatorID,
   ',@buildingsociety=',buildingsociety,',@accountname=',accountname,
   ',@branchsortcode=',branchsortcode,',@accountnumber=',accountnumber,
   ',@ddref=',ddref);  
   CALL crm.pp_log_request('vmuk_ppInsertDirectDebitOrder',v_logparams);  
 
   
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `website_get_temp_transaction_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `website_get_temp_transaction_info`(v_sitecode VARCHAR(5),
v_reference_id VARCHAR(100),
v_step_no INT)
BEGIN
    
    
	
   IF v_step_no is null then
      set v_step_no = 0;
   END IF;
   
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   
   select   payment_info,step_no  from web_transaction_Tmp
   where reference_id = v_reference_id
   and step_no = v_step_no
   order by id desc LIMIT 1;
   
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `web_disable_tAuxAutoTopup_status` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `web_disable_tAuxAutoTopup_status`(
MobileNo VARCHAR(50) ,  
processby VARCHAR(50))
begin 
   
   DECLARE v_subscriptionid VARCHAR(250);  
   DECLARE v_LastOrderID BIGINT;  
   
   IF processby is null 
   then
      set processby = 'WEB';
   END IF;
   
   select   SubscriptionID, LastOrderID INTO v_subscriptionid,v_LastOrderID from tAuxAutoTopup a where a.mobileno = MobileNo;   
        
   update tAuxAutoTopup a set status = 0,disable_by = processby,disable_date = CURRENT_TIMESTAMP
   where a.MobileNo = MobileNo;   
          
   if ROW_COUNT() > 0 
   then     
      update  payment.payment_card_detail a set is_autotopup = 0,auto_topup_amount = 0
      where a.account_id = MobileNo;
   end if;  
    
 insert into tAuxAutoTopupLog(MobileNo, SubscriptionID, OrderID, reason, result, description, CreatedDate, submit_by,
 disable_by,disable_date)
 values(MobileNo, v_subscriptionid, v_LastOrderID,'Auto Topup setting is OFF' , 0, 'Cancled Auto topup', CURRENT_TIMESTAMP ,processby,
 processby,CURRENT_TIMESTAMP);  
   
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-21  9:53:50
