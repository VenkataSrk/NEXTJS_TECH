-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: npopr_supper
-- ------------------------------------------------------
-- Server version	8.0.44-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `npopr_supper`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `npopr_supper` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `npopr_supper`;

--
-- Table structure for table `prefix_mnpdb`
--

DROP TABLE IF EXISTS `prefix_mnpdb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prefix_mnpdb` (
  `prefix` varchar(10) NOT NULL,
  `sitecode` varchar(3) DEFAULT NULL,
  `mnp_db` varchar(50) DEFAULT NULL,
  `is_nrn` int DEFAULT NULL,
  PRIMARY KEY (`prefix`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `spcnumber`
--

DROP TABLE IF EXISTS `spcnumber`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `spcnumber` (
  `NUMBER` varchar(15) NOT NULL,
  `STATUS` int NOT NULL,
  `OPRID` varchar(5) DEFAULT NULL,
  `TRFCLSID` varchar(15) DEFAULT NULL,
  `ACCESSABROAD` int DEFAULT NULL,
  `DATEEXPIRE` varchar(20) DEFAULT NULL,
  `DATETRANS` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`NUMBER`),
  KEY `FK_SPCNUMBE_20090227_REFERENCE_REFSTATUIdx` (`STATUS`),
  KEY `FK_SPCNUMBE_20090227_REFERENCE_TRFCLSIdx` (`OPRID`,`TRFCLSID`),
  CONSTRAINT `FK_SPCNUMBE_20090227_REFERENCE_REFSTATU` FOREIGN KEY (`STATUS`) REFERENCES `REFSTATUS` (`STATUS`),
  CONSTRAINT `FK_SPCNUMBE_20090227_REFERENCE_TRFCLS` FOREIGN KEY (`OPRID`, `TRFCLSID`) REFERENCES `TRFCLS` (`OPRID`, `TRFCLSID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping events for database 'npopr_supper'
--

--
-- Dumping routines for database 'npopr_supper'
--
/*!50003 DROP PROCEDURE IF EXISTS `esp_get_tariffcode` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `esp_get_tariffcode`(xlatednum VARCHAR(30))
begin

   DECLARE v_tariffcode INT;    
   DECLARE v_isexist INT;
   DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
   BEGIN
      SET @SWV_Error = 1;
   END;     
    
   SET @SWV_Error = 0;
   set v_tariffcode =  0;     
    
   SET @SWV_Error = 0;
   CALL mnpch_check_prefix(xlatednum,v_isexist);    
   if @SWV_Error = 0 and  v_isexist = 1 then
      set v_tariffcode = 1;
   end if;    
    
   select v_tariffcode tariff_code, v_isexist ina_exist;    
    
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `MNPCH_CHECK_PREFIX` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `MNPCH_CHECK_PREFIX`(dialednb VARCHAR(30),          
OUT isexists INT)
BEGIN

   DECLARE v_nb VARCHAR(30);
   set isexists = 0;
   set v_nb = dialednb;        
 
 
 
           
   if exists(select Status from spcnumber a  where a.Number = v_nb and a.Status = 1) then
      set isexists = 1;
   end if;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `mnp_get_call_forward` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `mnp_get_call_forward`(
trunkin varchar(10),  
cli varchar(30),  
clinbtype int,  
did varchar(30),  
didnbtype int  
)
begin  

	  
   
	 declare linkedserver varchar(50);  
	 declare sp varchar(100);   
  
	 set linkedserver = '' ; 

	 select a.mnp_db into linkedserver
	 from prefix_mnpdb a
	 where a.prefix = left(cli,length(a.prefix))  
	 order by a.prefix desc  limit 1;
 
	 if linkedserver<>'' then
		set sp = concat(linkedserver,'mnp_get_call_forward') ;
	
		call sp (trunkin, cli, clinbtype, did, didnbtype);  
   
	end if;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `MNP_GET_INFO` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `MNP_GET_INFO`(nb VARCHAR(30))
BEGIN

   DECLARE v_mnp_number VARCHAR(30);     
   DECLARE v_portedflag INT;     
   DECLARE v_rcid VARCHAR(20);    
   DECLARE v_isOnward INT;  
   DECLARE v_linkedserver VARCHAR(50);
   DECLARE v_sp VARCHAR(100);
   DECLARE v_is_nrn INT; 
   DECLARE v_nrn_code VARCHAR(50);
   set v_linkedserver = '';
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   a.mnp_db, IFNULL(a.is_nrn,0)
   INTO v_linkedserver,v_is_nrn from prefix_mnpdb a
   where a.prefix = left(nb,CHAR_LENGTH(RTRIM(a.prefix)))   order by a.prefix desc LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   
   
   set v_sp = CONCAT(v_linkedserver,'mnp_get_number');

	if IFNULL(v_is_nrn,0) = 1 then
		CALL mnp_get_number (nb,v_mnp_number,v_portedflag,v_rcid,v_isOnward,v_nrn_code);
	else if (v_linkedserver='npopr_uk.dbo.') then 
		CALL npopr_uk.mnp_get_number (nb,v_mnp_number,v_portedflag,v_rcid,v_isOnward);
	else if (v_linkedserver='npopr_au.dbo.')then 
		CALL npopr_au.mnp_get_number (nb,v_mnp_number,v_portedflag,v_rcid,v_isOnward);
	else if (v_linkedserver='npopr_fr.dbo.') then 
		CALL npopr_fr.mnp_get_number (nb,v_mnp_number,v_portedflag,v_rcid,v_isOnward);
	else if (v_linkedserver='npopr_bl.dbo.') then 
		CALL npopr_bl.mnp_get_number (nb,v_mnp_number,v_portedflag,v_rcid,v_isOnward);
	else
		CALL mnp_get_number (nb,v_mnp_number,v_portedflag,v_rcid,v_isOnward);
	end if;
	end if;
    end if;
	end if;
	end if;
    
   select v_mnp_number mnp_number,  v_isOnward is_Onward, v_portedflag portedflag, v_rcid rcid,
	IFNULL(v_nrn_code,'') as nrn_code;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `MNP_GET_NUMBER` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `MNP_GET_NUMBER`(nb VARCHAR(30),          
OUT mnp_number VARCHAR(30) ,          
OUT portedflag INT ,          
OUT rcid VARCHAR(20) ,          
OUT isOnward INT)
begin
    
	
   set mnp_number = nb;
   set portedflag = 0;
   set rcid = '';
   set isOnward = 0;
 
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-21  9:52:10
