-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: om
-- ------------------------------------------------------
-- Server version	8.0.44-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `om`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `om` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `om`;

--
-- Table structure for table `tt_temp_cdr_info`
--

DROP TABLE IF EXISTS `tt_temp_cdr_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tt_temp_cdr_info` (
  `calldate` datetime(3) DEFAULT NULL,
  `ani` varchar(100) DEFAULT NULL,
  `dialednum` varchar(100) DEFAULT NULL,
  `destcode` varchar(1000) DEFAULT NULL,
  `duration` int DEFAULT NULL,
  `callcost` int DEFAULT NULL,
  `trffclass` varchar(4) DEFAULT NULL,
  `Usage_From` varchar(50) DEFAULT NULL,
  `id` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ur_hide_call_info`
--

DROP TABLE IF EXISTS `ur_hide_call_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ur_hide_call_info` (
  `session_id` varchar(250) NOT NULL,
  `delete_date` datetime(3) DEFAULT NULL,
  `delete_by` varchar(250) DEFAULT NULL,
  `enterpriseid` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping events for database 'om'
--

--
-- Dumping routines for database 'om'
--
/*!50003 DROP PROCEDURE IF EXISTS `Ur_Myaccount_call_History_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbteam`@`%` PROCEDURE `Ur_Myaccount_call_History_details`(
 enterpriseid VARCHAR(50),  
 date_from DATETIME(3),  
 data_to DATETIME(3),  
 deskphone VARCHAR(10))
BEGIN
 
    
    
    DECLARE v_spname VARCHAR(250);     
    DECLARE v_total_count INT;   
    DECLARE v_count INT;   
    DECLARE v_to_date_search DATE;
    
    
    DROP  TABLE IF EXISTS tt_temp_cdr_info;
    create  table tt_temp_cdr_info
    (
       calldate DATETIME(3),
       ani VARCHAR(100),
       dialednum VARCHAR(100),
       destcode VARCHAR(1000),
       duration INT,
       callcost INT,
       trffclass VARCHAR(4),
       Usage_From VARCHAR(50),
       id VARCHAR(250)
    );  
    
  
    
    
    set v_total_count = TIMESTAMPDIFF(MONTH,date_from,data_to);  
    set v_count = 0;  
   
    IF DATE_FORMAT(date_from,'%Y%m%d') <> DATE_FORMAT(data_to,'%Y%m%d') 
    then
  
       WHILE v_count <= v_total_count DO
       
          SET v_to_date_search = TIMESTAMPADD(DAY,-1,TIMESTAMPADD(MONTH,TIMESTAMPDIFF(MONTH,TIMESTAMPADD
 								(MONTH,0,'1900-01-01 00:00:00'),date_from)+1,TIMESTAMPADD(MONTH,0,'1900-01-01 00:00:00')));
          
          if v_to_date_search >= data_to 
          then
             set  v_to_date_search = data_to;
          end if;
          
        
        
          
        
     
          
             
           
             
             
       
          
             
             
             
           
             
             
             
             
           
             
			insert into om.tt_temp_cdr_info(calldate,ani,dialednum,destcode,duration ,callcost ,trffclass ,Usage_From ,id )
			select calldate,ani,replace(Replace(dialednum,'UKMCOM',''),'UK01-O-MCOM','') AS dialednum,destcode,talktime,talkcharge,trffclass,
			case when custcode like 'R%' THEN 'Master' else 'Bundle' end as Usage_From,sessionid_a as session_id 
			from  month07.sme_cdr a 
			where  SUBSTR(did,3,4) = enterpriseid 
			AND  charge = 78 
			and  calldate between  date_from and data_to
			ORDER BY  calldate asc;
             
             
             
        
          
          set date_from = TIMESTAMPADD(month,TIMESTAMPDIFF(month,TIMESTAMPADD(month,0,'1900-01-01 00:00:00'),date_from)+1,TIMESTAMPADD(month,0,'1900-01-01 00:00:00'));
          set v_count = v_count+1;
          
       END WHILE;
       
    end if;  
    
 select calldate,case when ani like '%Pack%' then LEFT(LTRIM(RTRIM(ani)),3) ELSE LTRIM(RTRIM(ani)) END AS extension,LTRIM(RTRIM(dialednum)) AS dialednum,  
        destcode,duration,callcost,trffclass,usage_from,'Outbound' as call_type,id,'mssql' as from_db 
 from   tt_temp_cdr_info 
 where  id NOT IN(select session_id from ur_hide_call_info a where a.enterpriseid = enterpriseid) and (deskphone = '') or (((ani = deskphone) or (lEFT(ani,3) = deskphone)));     
    
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ur_myaccount_delete_call_log` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbteam`@`%` PROCEDURE `ur_myaccount_delete_call_log`(id longtext,
 enterpriseid INT,
 delete_by VARCHAR(50))
BEGIN
 
    DECLARE v_errcode INT; 
    DECLARE v_errmsg VARCHAR(250);
    DECLARE v_ctr INT; 
    DECLARE v_tctr INT; 
    DECLARE v_session_id VARCHAR(160);
    
    DROP TEMPORARY TABLE IF EXISTS tt_temp_session;
    create TEMPORARY table tt_temp_session
    (
       id INT   AUTO_INCREMENT PRIMARY KEY,
       session_id longtext
    )  AUTO_INCREMENT = 1;
 	
   
    
    
             call unifiedring.Split(id,',');
             
       insert into tt_temp_session(session_id)
       select Items from unifiedring.tt_Split_temptable ;
 
 	
    set v_ctr = 1;
 	
    select   count(1) INTO v_tctr from tt_temp_session;
 	
    while v_ctr <= v_tctr DO
    
       begin
       
          sp_next:BEGIN
          
             select   a.session_id INTO v_session_id from tt_temp_session a where a.id = v_ctr;
             
     
             IF NOT EXISTS(SELECT  1 FROM ur_hide_call_info a  WHERE session_id = v_session_id and a.enterpriseid = enterpriseid LIMIT 1) 
             then
 		
 			  INSERT INTO ur_hide_call_info(session_id,delete_date,delete_by,enterpriseid)
 			  VALUES(v_session_id,CURRENT_TIMESTAMP,delete_by,enterpriseid);
 			
                IF row_count() > 0 
                then
 			
                   SET v_errcode = 0;
                   SET v_errmsg = 'Success to delete the call log';
                end if;
                
             ELSE
             
                SET v_errcode = -1;
                SET v_errmsg = 'Record already deleted';
                LEAVE sp_next;
             end if;
             
          END sp_next;
          
          set v_ctr = v_ctr+1;
          
       end;
       
 
    END WHILE;
 		
    select v_errcode as errcode,v_errmsg as errmsg;
 	
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-21  9:52:19
