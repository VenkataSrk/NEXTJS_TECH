-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: Routingv2
-- ------------------------------------------------------
-- Server version	8.0.44-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `XlatInterDomain`
--

DROP TABLE IF EXISTS `XlatInterDomain`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `XlatInterDomain` (
  `sitecode_in` varchar(4) NOT NULL,
  `switchcode_in` varchar(4) NOT NULL,
  `sitecode_out` varchar(4) NOT NULL,
  `operator_out` varchar(15) NOT NULL,
  `prefix` varchar(20) NOT NULL,
  `xlatpfx` varchar(20) DEFAULT NULL,
  `prefixlen` int DEFAULT NULL,
  `comment` varchar(64) DEFAULT NULL,
  UNIQUE KEY `PK_xlatinterdomain` (`sitecode_in`,`switchcode_in`,`sitecode_out`,`operator_out`,`prefix`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `blocked_ddi`
--

DROP TABLE IF EXISTS `blocked_ddi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blocked_ddi` (
  `ddi` varchar(20) NOT NULL,
  `blocker` varchar(32) DEFAULT NULL,
  `reason` varchar(32) DEFAULT NULL,
  `date` varchar(10) DEFAULT NULL,
  UNIQUE KEY `PK__blocked_ddi__7C255952` (`ddi`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `callout`
--

DROP TABLE IF EXISTS `callout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `callout` (
  `sitecode` varchar(3) DEFAULT NULL,
  `switchcode` char(3) DEFAULT NULL,
  `tgroup` varchar(15) DEFAULT NULL,
  `operator` varchar(15) DEFAULT NULL,
  `interface` varchar(50) DEFAULT NULL,
  `prefix` varchar(20) DEFAULT NULL,
  `xlatpfx` varchar(15) DEFAULT NULL,
  `numbertype` int DEFAULT NULL,
  `complaw` int DEFAULT NULL,
  `nbplan` int DEFAULT NULL,
  `signaddress` varchar(100) DEFAULT NULL,
  `callingnb` varchar(15) DEFAULT NULL,
  `callingcat` int DEFAULT NULL,
  `callingnbtype` int DEFAULT NULL,
  `isactive` int DEFAULT NULL,
  `did_len` int DEFAULT NULL,
  `callingscreening` int DEFAULT NULL,
  `presentation` int DEFAULT NULL,
  `comment` varchar(30) DEFAULT NULL,
  `mindidlen` int DEFAULT NULL,
  `conntype` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  `phonecontext` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`idpk`),
  KEY `idx3` (`sitecode`,`switchcode`,`tgroup`,`interface`,`prefix`),
  KEY `xlat_calout` (`sitecode`,`switchcode`,`prefix`,`tgroup`,`operator`,`interface`),
  KEY `xlat_calout1` (`switchcode`,`operator`,`interface`,`prefix`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=62667 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `causecode`
--

DROP TABLE IF EXISTS `causecode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `causecode` (
  `domain` varchar(8) NOT NULL,
  `operator` varchar(32) NOT NULL,
  `code` int NOT NULL,
  `name` varchar(32) DEFAULT NULL,
  `next` int DEFAULT NULL,
  `counter` int DEFAULT NULL,
  `duration` int DEFAULT NULL,
  `reserved` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cswitch_config`
--

DROP TABLE IF EXISTS `cswitch_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cswitch_config` (
  `operator` varchar(15) NOT NULL,
  `prefix` varchar(20) NOT NULL,
  `alert_timeout` int NOT NULL,
  `listen_delay` int NOT NULL,
  `connect_delay` int NOT NULL,
  `alert_delay` int NOT NULL,
  `vox_callsetup` varchar(25) NOT NULL,
  `randomcli` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `xlatout`
--

DROP TABLE IF EXISTS `xlatout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `xlatout` (
  `sitecode` varchar(3) NOT NULL,
  `switchcode` varchar(3) NOT NULL,
  `trunkcode` varchar(8) NOT NULL,
  `mode` int NOT NULL,
  `prefix` varchar(20) NOT NULL,
  `nbtype` int NOT NULL,
  `xlatpfx` varchar(30) NOT NULL,
  `xlatNBtype` int NOT NULL,
  `comment` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`sitecode`,`switchcode`,`trunkcode`,`mode`,`prefix`,`nbtype`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping events for database 'Routingv2'
--

--
-- Dumping routines for database 'Routingv2'
--
/*!50003 DROP PROCEDURE IF EXISTS `cs_get_xlatout` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `cs_get_xlatout`(
sitecode CHAR(8),  
switchcode CHAR(3),  
trunkcode CHAR(16),  
prefix CHAR(30),  
nbtype INT,  
mode INT)
begin
        
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select * from xlatout a where a.sitecode = sitecode and (a.switchcode = switchcode or a.switchcode = '*')
   and (a.trunkcode = trunkcode  or a.trunkcode = '*') and a.mode = mode 
   and SUBSTRING(prefix,1,CHAR_LENGTH(RTRIM(a.prefix))) = a.prefix and a.nbtype = nbtype
   order by a.switchcode desc,a.trunkcode desc,CHAR_LENGTH(RTRIM(a.prefix)) desc LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
   
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es5_get_config` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `es5_get_config`(opr VARCHAR(16),
pfx VARCHAR(20))
begin
   select * from cswitch_config a
   where (a.operator = opr or a.operator = '*')
   and   (left(pfx,CHAR_LENGTH(RTRIM(prefix))) = prefix  or prefix = '*')
   order by operator desc,prefix desc; 
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es5_xlat_callout` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `es5_xlat_callout`(sitecode VARCHAR(3), switchcode CHAR(3), prefix VARCHAR(30),`group` VARCHAR(10),operator VARCHAR(16),interface VARCHAR(10))
begin
    
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select * from callout a
   where a.sitecode = sitecode
   and (a.switchcode = switchcode or a.switchcode = 'ALL')
   and prefix like CONCAT(a.prefix,'%')
   and (a.tgroup = `group` or a.tgroup = '')
   and (a.operator = operator or a.operator = '')
   and (a.interface = interface or a.interface = '')
   order by a.switchcode,a.operator desc,a.interface desc,a.prefix desc;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;    
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `route_callout` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `route_callout`(prefix VARCHAR(30))
begin
     
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select * from callout a
    where a.sitecode = 'BM3'
    and (a.switchcode = 'ALL')
    and (prefix like CONCAT(a.prefix,'%') and ifnull(a.prefix,'')<>'')
    and (a.tgroup = 'did_bt')
    and (a.operator = 'did_bt')
  
    order by a.switchcode,a.operator desc,a.interface desc,a.prefix desc;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;    
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-21  9:52:53
