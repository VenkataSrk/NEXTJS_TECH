-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: SMS_Portal
-- ------------------------------------------------------
-- Server version	8.0.44-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `SMS_Portal`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `SMS_Portal` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `SMS_Portal`;

--
-- Table structure for table `SMS_MESSAGE_CONFIG`
--

DROP TABLE IF EXISTS `SMS_MESSAGE_CONFIG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SMS_MESSAGE_CONFIG` (
  `Sms_id` int NOT NULL AUTO_INCREMENT,
  `Scenerio` varchar(100) DEFAULT NULL,
  `Sms_text` varchar(520) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `Create_date` datetime(3) DEFAULT NULL,
  `Status` int DEFAULT NULL,
  `last_update` datetime(3) DEFAULT NULL,
  `sitecode` varchar(3) DEFAULT NULL,
  PRIMARY KEY (`Sms_id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=263 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping events for database 'SMS_Portal'
--

--
-- Dumping routines for database 'SMS_Portal'
--
/*!50003 DROP PROCEDURE IF EXISTS `sms_content_get_text` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sms_content_get_text`(sms_id INT,
scenerio VARCHAR(100),
sitecode VARCHAR(5))
BEGIN

	
	
   IF sms_id is null then
      set sms_id = 0;
   END IF;
   IF scenerio is null then
      set scenerio = '';
   END IF;
   IF sitecode is null then
      set sitecode = 'ALL';
   END IF;
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   SELECT a.Sms_id,
		a.Scenerio,
		a.Sms_text,
		a.Create_date,
		case when  a.Status = 1 then 'Active' else 'Inactive' end as Status 
    FROM SMS_MESSAGE_CONFIG a
	WHERE ((a.Sms_id = sms_id) OR (sms_id = 0)) AND
	   ((a.Scenerio = scenerio) or (scenerio = '')) AND
	   ((sitecode = 'ALL') OR (a.sitecode = sitecode))
   order by a.Sms_id desc;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-21  9:53:18
