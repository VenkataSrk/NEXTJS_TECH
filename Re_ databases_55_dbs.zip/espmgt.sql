-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: espmgt
-- ------------------------------------------------------
-- Server version	8.0.44-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `espmgt`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `espmgt` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `espmgt`;

--
-- Table structure for table `Sites`
--

DROP TABLE IF EXISTS `Sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Sites` (
  `Domain` varchar(3) NOT NULL,
  `SiteDesc` varchar(16) NOT NULL,
  `status` int DEFAULT NULL,
  `login` varchar(32) NOT NULL,
  `password` varchar(32) NOT NULL,
  `espserver` varchar(20) NOT NULL,
  `espdb` varchar(24) NOT NULL,
  `espwsdb` varchar(20) DEFAULT NULL,
  `espprmserver` char(20) NOT NULL,
  `espprmdb` char(24) NOT NULL,
  `esplinkserver` varchar(32) DEFAULT NULL,
  `espprmlinkserver` varchar(32) DEFAULT NULL,
  `custcode` varchar(8) DEFAULT NULL,
  `SiteType` int DEFAULT NULL,
  `siteowner` int DEFAULT NULL,
  PRIMARY KEY (`Domain`,`SiteDesc`),
  KEY `fk_sites_sitetype_accounttype_typeidIdx` (`SiteType`),
  KEY `Status_Sites_FK1Idx` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cardFamily`
--

DROP TABLE IF EXISTS `cardFamily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cardFamily` (
  `CardID` int NOT NULL,
  `Sitecode` varchar(3) DEFAULT NULL,
  `CardName` varchar(32) DEFAULT NULL,
  `Denomination` float DEFAULT NULL,
  `Description` varchar(100) DEFAULT NULL,
  `DefaultTrffclass` varchar(4) DEFAULT NULL,
  `LatestTrffclass` varchar(4) DEFAULT NULL,
  `Daysvalid` int DEFAULT NULL,
  `Langcode` varchar(8) DEFAULT NULL,
  `Currcode` varchar(3) DEFAULT NULL,
  `cardtype` int DEFAULT NULL,
  `status` int DEFAULT NULL,
  `AccountType` int DEFAULT NULL,
  `hotlineNB` varchar(32) DEFAULT NULL,
  `svcNB_topup` varchar(32) DEFAULT NULL,
  UNIQUE KEY `PK__cardFamily__6FE99F9F` (`CardID`),
  UNIQUE KEY `idx_1` (`Sitecode`,`CardName`,`Denomination`,`Currcode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tariffReqHistory`
--

DROP TABLE IF EXISTS `tariffReqHistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tariffReqHistory` (
  `idx` int NOT NULL,
  `status` int NOT NULL,
  `login` varchar(32) DEFAULT NULL,
  `Date` datetime(3) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`),
  KEY `idx_1` (`idx`,`status`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=145156 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tariffRequest`
--

DROP TABLE IF EXISTS `tariffRequest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tariffRequest` (
  `idx` int NOT NULL AUTO_INCREMENT,
  `Domain` varchar(3) DEFAULT NULL,
  `CardID` int DEFAULT NULL,
  `NewTariffClass` varchar(5) DEFAULT NULL,
  `status` int DEFAULT NULL,
  `isFullBalanceOnly` int DEFAULT NULL,
  `affectedRange` int DEFAULT NULL,
  `timeperiod` int DEFAULT NULL,
  `percentage` int DEFAULT NULL,
  `type` int DEFAULT NULL,
  `filetariff` varchar(200) DEFAULT NULL,
  `temptariff` varchar(200) DEFAULT NULL,
  `denomination` float DEFAULT NULL,
  `freesec` int DEFAULT NULL,
  `EffectiveDate` datetime(3) DEFAULT NULL,
  `ppm` int DEFAULT NULL,
  `siteowner` int DEFAULT NULL,
  `upload_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`idx`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=31686 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `toriff`
--

DROP TABLE IF EXISTS `toriff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `toriff` (
  `telcocode` varchar(4) NOT NULL,
  `sitecode` varchar(3) NOT NULL,
  `destcode` varchar(64) DEFAULT NULL,
  `trffclass` varchar(4) NOT NULL,
  `charge` int NOT NULL,
  `timeperiod` int NOT NULL,
  `cnxdelay` int DEFAULT NULL,
  `cnxunit` float NOT NULL,
  `sampdelay` int DEFAULT NULL,
  `sampunit` float NOT NULL,
  `freesec` int DEFAULT NULL,
  `premiumdest` int DEFAULT NULL,
  `cfreemin` int DEFAULT NULL,
  `routeclass` int NOT NULL,
  `percentage` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`),
  KEY `idx1` (`sitecode`,`trffclass`,`charge`,`timeperiod`),
  CONSTRAINT `sampdelay_idx` CHECK ((`sampdelay` > 0.0)),
  CONSTRAINT `sampunit_idx` CHECK ((`sampunit` >= 0.0))
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=32802 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping events for database 'espmgt'
--

--
-- Dumping routines for database 'espmgt'
--
/*!50003 DROP PROCEDURE IF EXISTS `BMS_portal_do_run_traiff_request` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `BMS_portal_do_run_traiff_request`(
sitecode VARCHAR(3),
 idx INT)
BEGIN
    DECLARE v_errcode INT; 
    DECLARE v_errmsg VARCHAR(250);
 	
    set v_errcode = 0;
    set v_errmsg = 'Success';
 	
    iF EXISTS(SELECT  * FROM tariffRequest a where a.idx = idx and status = 1 LIMIT 1) then
 	
       CALL tariffREQ_DoProcessing_BMS(idx);
    else
       set v_errcode = -1;
       set v_errmsg = 'Record alrady processed.';
    end if;
 	
 	
    select v_errcode as errcode, v_errmsg as errmsg;
 	
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `BMS_portal_get_upload_request_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `BMS_portal_get_upload_request_info`(sitecode VARCHAR(3))
BEGIN
  
    
     
     
     SELECT  idx,a.cardid,NewTariffClass as tariffclass,
   case when a.status = 1 then 'Pending'
     when a.status = 3 then 'Success'
     when a.status = 2  THEN 'inprogress'  ELSE  'Failure' end as tariff_status,filetariff,
   IFNULL(percentage,0) as percentage,
   EffectiveDate,upload_date,a.denomination as access_charge,b.name as access_charge_name
     FROM tariffRequest a
     join espprm.access_charge b on a.denomination = b.charge
     left join  cardFamily c on a.cardid = c.cardid order by idx desc LIMIT 10;  
     
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `tariffREQ_add` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `tariffREQ_add`(
login          VARCHAR(32),
 site 		VARCHAR(3),
 cardID		INT,
 newTClass	VARCHAR(5),
 status		INT,
 isFullBal      INT,
 affectedRange  INT,
 type		INT,
 timeperiod     INT,
 edate	DATETIME(3),
 ppm		INT,
 siteowner INT,
 accesscharge INT,
 filetariff VARCHAR(250),
 temptariff VARCHAR(250),
 INOUT CurrID INT)
begin
 
 
   insert into tariffRequest(`Domain`,CardId,NewTariffClass,Status,isFullBalanceOnly,affectedRange,timeperiod,type,EffectiveDate,ppm,siteowner,
  denomination,filetariff,temptariff)
  values(site,cardID,newTClass,status,isFullBal,affectedRange,timeperiod,type,edate,ppm,siteowner,accesscharge,
  filetariff,temptariff);
 	
  
    SET CurrID = LAST_INSERT_ID();
 	
    insert into tariffReqHistory(idx,status,login,`date`)
  values(CurrID,status,login,CURRENT_TIMESTAMP);
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `tariffREQ_DoProcessing_BMS` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `tariffREQ_DoProcessing_BMS`(idx INT)
finish:
 begin
 
     	           
  
    DECLARE v_site VARCHAR(3);                
    DECLARE v_cardId INT;                
    DECLARE v_trffClass VARCHAR(4);                
    DECLARE v_sql VARCHAR(3000);                
    DECLARE v_espLNK VARCHAR(32);                
    DECLARE v_espprmLNK VARCHAR(32);                
    DECLARE v_affectedRange INT;                
    DECLARE v_type INT;                
    DECLARE v_timePeriod INT;                
    DECLARE v_finalStatus INT;              
                
    DECLARE v_vFileTariff VARCHAR(200);              
    DECLARE v_vTempTariff VARCHAR(200);                
    DECLARE v_vDenomination FLOAT;              
    DECLARE v_ppm INT;              
    DECLARE v_accType INT;              
    DECLARE v_siteowner INT;
    DECLARE v_vPath VARCHAR(32);              
    DECLARE v_vSheetName VARCHAR(32);
    DECLARE v_fa INT;
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
    BEGIN
       SET @SWV_Error = 1;
    END;              
               
                 
  
    SET @SWV_Error = 0;
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    UPDATE tariffrequest, (select  idx,status from tariffRequest  where status in(1,5) and
   (effectiveDate is null or (CURRENT_TIMESTAMP > effectiveDate) AND IDX = idx) LIMIT 1)  as A
    set idx = A.idx,percentage = 5,v_site = `domain`,v_timePeriod = timePeriod,v_trffClass = NewtariffClass,
    v_type = type,v_cardId = cardId,v_affectedRange = affectedRange,
    status =(case when A.status = 1 then 2 when A.status = 5 then 6 end),
    v_vFileTariff = ltrim(rtrim(filetariff)),v_vTempTariff = rtrim(ltrim(temptariff)),
    v_vDenomination = denomination,v_ppm = ppm,v_siteowner = siteowner
    where tariffrequest.idx = A.idx AND  
    a.idx = idx;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;             
    
 if idx is not null then
  
     insert into tariffREQHistory(idx,status,login,`date`)
       select idx,2,'system',CURRENT_TIMESTAMP;
       select   AccountType INTO v_accType from cardfamily where cardid = v_cardId;              
   
       if v_type = 1 or v_type = 2 then
   
    
          SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
          select   dbpath, sheetname INTO v_vPath,v_vSheetName from tariffRequestConfig  where UsedByTool = 'Tariff'    LIMIT 1;
          SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
          if exists(select * from sysobjects where xtype = 'u' and name = v_vTempTariff) then
    
             set v_sql =CONCAT( '      drop table IF EXISTS ', '[', v_vTempTariff,  ']');
             SET @SWV_Stmt = v_sql;
             PREPARE SWT_Stmt FROM @SWV_Stmt;
             EXECUTE SWT_Stmt;
             DEALLOCATE PREPARE SWT_Stmt;
          end if;
          set v_vTempTariff = CONCAT_WS('','[',v_vTempTariff,']');
         
    
          CALL Upload_Excel(v_vPath,v_vFileTariff,v_vTempTariff,v_vSheetName,v_site);
          set v_sql =CONCAT( ' select * into ', v_vTempTariff, ' from wholesalernew_srv.esp.dbo.',  v_vTempTariff);
          SET @SWV_Stmt = v_sql;
          PREPARE SWT_Stmt FROM @SWV_Stmt;
          EXECUTE SWT_Stmt;
          DEALLOCATE PREPARE SWT_Stmt;
          update tariffRequest a set percentage = 20 where a.idx = idx;
          CALL dts_insert_tariff(idx,v_site,v_trffClass,v_timePeriod,v_vDenomination,v_vTempTariff,v_ppm,
          v_accType);
          update tariffRequest a set percentage = 40 where a.idx = idx;
          if exists(select * from sysobjects where xtype = 'u' and name = v_vTempTariff) then
    
             set v_sql =CONCAT( '      drop table IF EXISTS ',  v_vTempTariff);
             SET @SWV_Stmt = v_sql;
             PREPARE SWT_Stmt FROM @SWV_Stmt;
             EXECUTE SWT_Stmt;
             DEALLOCATE PREPARE SWT_Stmt;
          end if;
          CALL tariff_CheckDuplicateAgain(idx,v_trffClass,v_fa);
          if v_fa = 1 then 
    
             set v_finalStatus = 995;
             update tariffRequest a
             set status = v_finalStatus
             where a.idx = idx;
             insert into tariffREQHistory(idx,status,login,`date`)
             select idx,v_finalStatus,'system',CURRENT_TIMESTAMP;
             LEAVE finish;
          end if;
       end if;                           
              
   
       SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
       select   CONCAT(rtrim(espprmlinkserver),'.',rtrim(espprmdb),'.dbo.'), CONCAT(rtrim(esplinkserver),'.',rtrim(espdb),'.dbo.') INTO v_espprmLNK,v_espLNK from sites  where `domain` = v_site and siteowner = v_siteowner;
       SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;                 
              
   
       if v_type = 0 then 
   
          update tariffRequest a set percentage = 20 where a.idx = idx;
          set v_sql =CONCAT( 'CALL tariffREQ_Activate ', ltrim(idx), ',''', v_site, ''',''', v_trffClass, ''',', ltrim(v_cardId), ',',  ltrim(v_affectedRange),  ') ');                
    
          SET @SWV_Stmt = v_sql;
          PREPARE SWT_Stmt FROM @SWV_Stmt;
          EXECUTE SWT_Stmt;
          DEALLOCATE PREPARE SWT_Stmt;
          SET @SWV_Error = 0;
          if @SWV_Error > 0 then  
             set v_finalStatus = 997;
          end if;
          if @SWV_Error = 0 then  
             set v_finalStatus = 7;
          end if;
       end if;
       if v_type = 1 then 
   
          if v_site = 'DDL' then
             set v_site = 'LO2';
          end if;              
    
    
                
    
    
          update tariffRequest a set percentage = 60 where a.idx = idx;
          set v_sql = 'exec ' || v_espprmLNK || 'trff_copyTariff ''' || v_site || ''',''' || v_trffClass || ''',' || ltrim(v_timePeriod) || ',1,' || ltrim(v_ppm) || ',' || ltrim(v_accType);              
    
          SET @SWV_Stmt = v_sql;
          PREPARE SWT_Stmt FROM @SWV_Stmt;
          EXECUTE SWT_Stmt;
          DEALLOCATE PREPARE SWT_Stmt;
          SET @SWV_Error = 0;
          if @SWV_Error > 0 then  
             set v_finalStatus = 998;
          end if;
          if @SWV_Error = 0 then  
             set v_finalStatus = 3;
          end if;
          if exists(select * from toriff_verification a where a.idx = idx LIMIT 1) then
             delete FROM toriff_verification a where a.idx = idx;
          end if;
          SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
          insert into toriff_verification(idx,telcocode,sitecode,destcode,trffclass,charge,timeperiod,cnxdelay,cnxunit,sampdelay,sampunit,freesec,premiumdest,cfreemin,routeclass,percentage)
          select idx,telcocode,sitecode,destcode,trffclass,charge,timeperiod,cnxdelay,cnxunit,sampdelay,sampunit,freesec,premiumdest,cfreemin,routeclass,percentage
          from toriff  where telcocode = 'ics' and sitecode = v_site and trffclass = v_trffClass;
          SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
          delete from toriff where telcocode = 'ics' and sitecode = v_site and trffclass = v_trffClass;
       end if;
       if v_type = 2 then 
   
          if v_site = 'DDL' then
             set v_site = 'LO2';
          end if;
          set v_sql = 'exec ' || v_espprmLNK || 'trff_copyTariff ''' || v_site || ''',''' || v_trffClass || ''',' || ltrim(v_timePeriod) || ',2,' || ltrim(v_ppm) || ',' || ltrim(v_accType);              
    
          SET @SWV_Stmt = v_sql;
          PREPARE SWT_Stmt FROM @SWV_Stmt;
          EXECUTE SWT_Stmt;
          DEALLOCATE PREPARE SWT_Stmt;
          SET @SWV_Error = 0;
          update tariffRequest a set percentage = 60 where a.idx = idx;
          if @SWV_Error > 0 then  
             set v_finalStatus = 996;
          else                
     
             set v_sql = 'exec ' || v_espprmLNK || 'trff_replaceTariff_v2 ''' || v_site || ''',''' || v_trffClass || ''',' || ltrim(v_timePeriod) || ',' || LTRIM(v_vDenomination); 
             
 SET @SWV_Stmt = v_sql;
             PREPARE SWT_Stmt FROM @SWV_Stmt;
             EXECUTE SWT_Stmt;
             DEALLOCATE PREPARE SWT_Stmt;
             SET @SWV_Error = 0;
             if @SWV_Error > 0 then  
                set v_finalStatus = 999;
             end if;
             if @SWV_Error = 0 then  
                set v_finalStatus = 3;
             end if;
             if exists(select * from toriff_verification a where a.idx = idx LIMIT 1) then
                delete FROM toriff_verification a where a.idx = idx;
             end if;
             SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
             insert into toriff_verification(idx,telcocode,sitecode,destcode,trffclass,charge,timeperiod,cnxdelay,cnxunit,sampdelay,sampunit,freesec,premiumdest,cfreemin,routeclass,percentage)
             select idx,telcocode,sitecode,destcode,trffclass,charge,timeperiod,cnxdelay,cnxunit,sampdelay,sampunit,freesec,premiumdest,cfreemin,routeclass,percentage
             from toriff  where telcocode = 'ics' and sitecode = v_site and trffclass = v_trffClass;
             SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
             delete from toriff where telcocode = 'ics' and sitecode = v_site and trffclass = v_trffClass;
          end if;
       end if;
       update tariffRequest a set percentage = 80 where a.idx = idx;                
   
       update tariffRequest 
       set percentage = 100,status    = v_finalStatus                
   
   
       where idx = idx;
       insert into tariffREQHistory(idx,status,login,`date`)
       select idx,v_finalStatus,                
   
   
   'system',CURRENT_TIMESTAMP;
    end if;              
                     
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UTMS_portal_upload_tariff_request` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `UTMS_portal_upload_tariff_request`(v_login	VARCHAR(32),
v_site	VARCHAR(3),
v_cardID	INT,
v_tariffclass	VARCHAR(4),
v_timeperiod	INT,
v_effectivedate	DATETIME(3),
v_accesscharge INT,
v_filetariff VARCHAR(250),
v_temptariff VARCHAR(250),
v_upload_type INT,
INOUT v_idx INT ,
INOUT v_errcode INT ,
INOUT v_errmsg VARCHAR(250))
BEGIN
   DECLARE v_siteid INT;
	

   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   siteowner INTO v_siteid from espmgt.Sites where `Domain` = v_site    LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
	
   if IFNULL(v_cardID,0) = 0 then
	
      select   cardid INTO v_cardID from cardfamily where DefaultTrffclass = v_tariffclass;
   end if;
	
	
   IF EXISTS(SELECT* FROM espmgt.tariffRequest where NewTariffClass = v_tariffclass and status = 1
   and denomination = v_accesscharge) 
   then
	begin
      delete from  espmgt.tariffRequest where NewTariffClass = v_tariffclass and status = 1
      and denomination = v_accesscharge;
      end;
   end if;
     CALL espmgt.tariffREQ_add(v_login,v_site,v_cardID,v_tariffclass,1,null,null,2,v_timeperiod,v_effectivedate,
   1,v_siteid,v_accesscharge,v_filetariff,v_temptariff,v_idx); 
	
	
   IF IFNULL(v_idx,0) > 0 AND v_upload_type = 2 then
	
      CALL espmgt.BMS_portal_do_run_traiff_request(v_site,v_idx);
   end if;
	
	
   set v_errcode = 0;
   set v_errmsg = 'Success';
	
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-21  9:51:04
