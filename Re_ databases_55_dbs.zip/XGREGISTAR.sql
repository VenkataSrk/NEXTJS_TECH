-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: XGREGISTAR
-- ------------------------------------------------------
-- Server version	8.0.44-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `XGREGISTAR`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `XGREGISTAR` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `XGREGISTAR`;

--
-- Table structure for table `Sip_Registrar`
--

DROP TABLE IF EXISTS `Sip_Registrar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Sip_Registrar` (
  `Call_id` varchar(50) NOT NULL,
  `Domain_id` int NOT NULL,
  `Contact_address` varchar(50) NOT NULL,
  `Ipaddress` varchar(40) DEFAULT NULL,
  `IpAdrress_type` int DEFAULT NULL,
  `Username` varchar(30) NOT NULL,
  `Password` varchar(10) DEFAULT NULL,
  `AAA` int DEFAULT NULL,
  `Registered_date` datetime(3) DEFAULT NULL,
  `last_update` datetime(3) DEFAULT NULL,
  `expires` int DEFAULT NULL,
  `Request_cseq` int DEFAULT NULL,
  `status` int DEFAULT NULL,
  `proxy_username` varchar(50) DEFAULT NULL,
  `device_type` varchar(30) NOT NULL,
  `mac_address` varchar(50) DEFAULT NULL,
  `prev_proxy_username` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`Call_id`,`Username`,`Domain_id`,`Contact_address`,`device_type`),
  UNIQUE KEY `UK1_Sip_Registrar` (`Username`,`Domain_id`,`device_type`),
  KEY `FK__Sip_Regis__Domai__07F6335AIdx` (`Domain_id`),
  KEY `idx1_Sip_Registrar` (`Call_id`,`last_update`),
  KEY `idx2_Sip_Registrar` (`Username`,`Domain_id`),
  KEY `idx3_Sip_Registrar` (`Username`,`Domain_id`,`device_type`),
  CONSTRAINT `FK__Sip_Regis__Domai__07F6335A` FOREIGN KEY (`Domain_id`) REFERENCES `Sip_domain` (`domain_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Sip_domain`
--

DROP TABLE IF EXISTS `Sip_domain`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Sip_domain` (
  `domain_id` int NOT NULL,
  `domain_name` varchar(50) DEFAULT NULL,
  `active` int DEFAULT NULL,
  `is_migrate` int NOT NULL DEFAULT '0',
  `video_domain_name` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`domain_id`),
  KEY `FK__Sip_Regis__Domai__07F6335AIdx2` (`domain_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping events for database 'XGREGISTAR'
--

--
-- Dumping routines for database 'XGREGISTAR'
--
/*!50003 DROP PROCEDURE IF EXISTS `create_sip_domain` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `create_sip_domain`(
   domain_name char(250)
   )
BEGIN
    
      
 
 		DECLARE domainid INT;   
 		DECLARE video_domain_name text;
 		DECLARE v_prefix  varchar(8);
         DECLARE v_domainTypeid int;
 
 		set v_prefix = SUBSTRING_INDEX(domain_name,'.',1);
 
 		select a.domainTypeid into v_domainTypeid from unifiedring.dir_domains a where a.prefix = v_prefix limit 1;
         
           
       SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
       select a.domain_id INTO domainid from Sip_domain a order by a.domain_id desc LIMIT 1;
       SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
       
       SET domainid = IFNULL(domainid,0)+1;  
       
      
 
       if v_domainTypeid = 1 then
 		set video_domain_name=replace(domain_name,'call','urmeetth');
       else
 		set video_domain_name=replace(domain_name,'call','urmeetddcl');
       end if;
       
 		   INSERT INTO Sip_domain(domain_id,domain_name,active,video_domain_name)
 		   VALUES(domainid,domain_name,1,video_domain_name);  
       
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-21  9:54:13
