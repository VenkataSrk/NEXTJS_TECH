-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: WHL_RTL_B2C
-- ------------------------------------------------------
-- Server version	8.0.44-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tb_whl_rtl_API_Domain_details`
--

DROP TABLE IF EXISTS `tb_whl_rtl_API_Domain_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_whl_rtl_API_Domain_details` (
  `apidomainId` int NOT NULL AUTO_INCREMENT,
  `domain_id` int DEFAULT NULL,
  `domainName` varchar(150) DEFAULT NULL,
  `domainDesc` text,
  `authtype` varchar(150) DEFAULT NULL,
  `userName` varchar(150) DEFAULT NULL,
  `password` varchar(150) DEFAULT NULL,
  `token` varchar(150) DEFAULT NULL,
  `oauthId` int DEFAULT NULL,
  `domainURL` varchar(150) DEFAULT NULL,
  `endPointDetails` json DEFAULT NULL,
  `createdAt` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime DEFAULT CURRENT_TIMESTAMP,
  `header` varchar(150) DEFAULT NULL,
  `value` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`apidomainId`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_whl_rtl_Ad_manager`
--

DROP TABLE IF EXISTS `tb_whl_rtl_Ad_manager`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_whl_rtl_Ad_manager` (
  `adId` int NOT NULL AUTO_INCREMENT,
  `userId` int DEFAULT NULL,
  `adType` int DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  `adCategory` varchar(20) DEFAULT NULL,
  `adLoctoAppear` varchar(20) DEFAULT NULL,
  `format` varchar(20) DEFAULT NULL,
  `typeOfPromotion` varchar(20) DEFAULT NULL,
  `uploadBanner` text,
  `link` varchar(250) DEFAULT NULL,
  `displayTimeFrame` int DEFAULT NULL,
  `adDisplayHour` int DEFAULT NULL,
  `adDisplayPerDay` int DEFAULT NULL,
  `bannerPosition` int DEFAULT NULL,
  `status` int DEFAULT NULL,
  `createDate` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated` datetime DEFAULT NULL,
  `freeOrPaid` int DEFAULT NULL,
  `paidAmount` float DEFAULT NULL,
  `approved_date` datetime DEFAULT NULL,
  `approved_by` int DEFAULT NULL,
  `vat_amount` float DEFAULT NULL,
  `payment_status` int DEFAULT NULL,
  `fromdate` datetime DEFAULT NULL,
  `todate` datetime DEFAULT NULL,
  `approved1_By` int DEFAULT NULL,
  `approved1_at` datetime DEFAULT NULL,
  `approved1_status` int DEFAULT NULL,
  `approved2_By` int DEFAULT NULL,
  `approved2_at` datetime DEFAULT NULL,
  `approved2_status` int DEFAULT NULL,
  PRIMARY KEY (`adId`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_whl_rtl_ad_clicks_dtl`
--

DROP TABLE IF EXISTS `tb_whl_rtl_ad_clicks_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_whl_rtl_ad_clicks_dtl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `adId` int DEFAULT NULL,
  `createdDate` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_whl_rtl_browse_by_categories_ist`
--

DROP TABLE IF EXISTS `tb_whl_rtl_browse_by_categories_ist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_whl_rtl_browse_by_categories_ist` (
  `id` int NOT NULL AUTO_INCREMENT,
  `catgId` int DEFAULT NULL,
  `position` int DEFAULT NULL,
  `status` int DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_whl_rtl_category_dtl`
--

DROP TABLE IF EXISTS `tb_whl_rtl_category_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_whl_rtl_category_dtl` (
  `catgId` int NOT NULL AUTO_INCREMENT,
  `catgName` varchar(150) DEFAULT NULL,
  `catgDesc` varchar(500) DEFAULT NULL,
  `catgStatus` int DEFAULT NULL,
  `catgImgURL` varchar(500) DEFAULT NULL,
  `catgPosition` int DEFAULT NULL,
  `createDate` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`catgId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_whl_rtl_category_master_list`
--

DROP TABLE IF EXISTS `tb_whl_rtl_category_master_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_whl_rtl_category_master_list` (
  `id` int NOT NULL AUTO_INCREMENT,
  `catgId` int DEFAULT NULL,
  `catgName` varchar(100) NOT NULL,
  `parentCatgId` int NOT NULL,
  `status` int DEFAULT '1',
  `catgType` int DEFAULT NULL,
  `iconId` int DEFAULT NULL,
  PRIMARY KEY (`id`,`catgName`,`parentCatgId`)
) ENGINE=InnoDB AUTO_INCREMENT=89 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_whl_rtl_category_master_list_bck`
--

DROP TABLE IF EXISTS `tb_whl_rtl_category_master_list_bck`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_whl_rtl_category_master_list_bck` (
  `id` int NOT NULL AUTO_INCREMENT,
  `catgId` int DEFAULT NULL,
  `catgName` varchar(100) NOT NULL,
  `parentCatgId` int NOT NULL,
  `status` int DEFAULT '1',
  `catgType` int DEFAULT NULL,
  `iconId` int DEFAULT NULL,
  PRIMARY KEY (`id`,`catgName`,`parentCatgId`)
) ENGINE=InnoDB AUTO_INCREMENT=191 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_whl_rtl_chat_master_dtl`
--

DROP TABLE IF EXISTS `tb_whl_rtl_chat_master_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_whl_rtl_chat_master_dtl` (
  `chatId` int NOT NULL AUTO_INCREMENT,
  `createDate` datetime DEFAULT CURRENT_TIMESTAMP,
  `userId` int DEFAULT NULL,
  `title` varchar(200) DEFAULT NULL,
  `chatJson` json DEFAULT NULL,
  `updateddate` datetime DEFAULT NULL,
  PRIMARY KEY (`chatId`),
  KEY `idx_chatId` (`chatId`),
  KEY `idx_title` (`title`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_whl_rtl_connector_token_info`
--

DROP TABLE IF EXISTS `tb_whl_rtl_connector_token_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_whl_rtl_connector_token_info` (
  `idcol` int NOT NULL AUTO_INCREMENT,
  `userId` int DEFAULT NULL,
  `connector_name` varchar(100) DEFAULT NULL,
  `token` text,
  `contactSyncDetails` json DEFAULT NULL,
  `syncStatus` tinyint DEFAULT NULL,
  `syncTime` bigint DEFAULT NULL,
  `contactSyncType` varchar(100) DEFAULT NULL,
  `isConnected` int DEFAULT '1',
  `createAt` datetime DEFAULT CURRENT_TIMESTAMP,
  `updateAt` datetime DEFAULT NULL,
  PRIMARY KEY (`idcol`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_whl_rtl_contact_dtl_interaction`
--

DROP TABLE IF EXISTS `tb_whl_rtl_contact_dtl_interaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_whl_rtl_contact_dtl_interaction` (
  `id` int NOT NULL AUTO_INCREMENT,
  `rtluserid` int DEFAULT NULL,
  `whluserid` int DEFAULT NULL,
  `ipaddress` varchar(20) DEFAULT NULL,
  `createDatetime` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_whl_rtl_country_code`
--

DROP TABLE IF EXISTS `tb_whl_rtl_country_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_whl_rtl_country_code` (
  `id` int NOT NULL AUTO_INCREMENT,
  `isocode` varchar(5) DEFAULT NULL,
  `prefix` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=203 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_whl_rtl_crm_admin_user`
--

DROP TABLE IF EXISTS `tb_whl_rtl_crm_admin_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_whl_rtl_crm_admin_user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(60) NOT NULL,
  `password` varchar(50) DEFAULT NULL,
  `status` int DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `firstname` varchar(150) DEFAULT NULL,
  `lastname` varchar(150) DEFAULT NULL,
  `mobileno` varchar(20) DEFAULT NULL,
  `dept_id` int DEFAULT NULL,
  `createDate` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`,`username`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_whl_rtl_crm_transaction_details`
--

DROP TABLE IF EXISTS `tb_whl_rtl_crm_transaction_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_whl_rtl_crm_transaction_details` (
  `tran_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `ad_id` int DEFAULT NULL,
  `price` float DEFAULT NULL,
  `vat` float DEFAULT NULL,
  `transaction_id` varchar(50) DEFAULT NULL,
  `cardholder_name` varchar(150) DEFAULT NULL,
  `address` text,
  `card_last_number` varchar(10) DEFAULT NULL,
  `cardtype` varchar(50) DEFAULT NULL,
  `transaction_Description` varchar(150) DEFAULT NULL,
  `transaction_errcode` varchar(150) DEFAULT NULL,
  `transaction_status` varchar(20) DEFAULT NULL,
  `transation_date` datetime DEFAULT NULL,
  `createdate` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedate` datetime DEFAULT NULL,
  PRIMARY KEY (`tran_id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_whl_rtl_icon`
--

DROP TABLE IF EXISTS `tb_whl_rtl_icon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_whl_rtl_icon` (
  `iconId` smallint NOT NULL AUTO_INCREMENT,
  `icon` text,
  `createdDate` datetime DEFAULT NULL,
  PRIMARY KEY (`iconId`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_whl_rtl_import`
--

DROP TABLE IF EXISTS `tb_whl_rtl_import`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_whl_rtl_import` (
  `id` int NOT NULL AUTO_INCREMENT,
  `prodJson` json DEFAULT NULL,
  `sellerid` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_whl_rtl_list_master_info`
--

DROP TABLE IF EXISTS `tb_whl_rtl_list_master_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_whl_rtl_list_master_info` (
  `listId` int NOT NULL AUTO_INCREMENT,
  `userId` int DEFAULT NULL,
  `listName` varchar(50) DEFAULT NULL,
  `status` int DEFAULT '1',
  `createdate` datetime DEFAULT CURRENT_TIMESTAMP,
  `updateddate` datetime DEFAULT NULL,
  PRIMARY KEY (`listId`)
) ENGINE=InnoDB AUTO_INCREMENT=346 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_whl_rtl_oauthclient_details`
--

DROP TABLE IF EXISTS `tb_whl_rtl_oauthclient_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_whl_rtl_oauthclient_details` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) DEFAULT NULL,
  `oauthGrandType` int DEFAULT NULL,
  `clientId` int DEFAULT NULL,
  `clientSecret` varchar(100) DEFAULT NULL,
  `authoriseURL` varchar(250) DEFAULT NULL,
  `tokenURL` varchar(250) DEFAULT NULL,
  `redirectURL` varchar(250) DEFAULT NULL,
  `scopes` varchar(100) DEFAULT NULL,
  `createDate` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedDate` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_whl_rtl_product_by_essentials_list`
--

DROP TABLE IF EXISTS `tb_whl_rtl_product_by_essentials_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_whl_rtl_product_by_essentials_list` (
  `id` int NOT NULL AUTO_INCREMENT,
  `catgId` int DEFAULT NULL,
  `status` int DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_whl_rtl_product_category_relevant_category_dtl`
--

DROP TABLE IF EXISTS `tb_whl_rtl_product_category_relevant_category_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_whl_rtl_product_category_relevant_category_dtl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `categoryId` int NOT NULL,
  `relevantCategoryId` varchar(200) DEFAULT NULL,
  `createdate` datetime DEFAULT CURRENT_TIMESTAMP,
  `updateDate` datetime DEFAULT NULL,
  PRIMARY KEY (`id`,`categoryId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_whl_rtl_product_dtl`
--

DROP TABLE IF EXISTS `tb_whl_rtl_product_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_whl_rtl_product_dtl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uuid` varchar(60) DEFAULT NULL,
  `productName` varchar(200) DEFAULT NULL,
  `productDescription` text,
  `brandName` varchar(100) DEFAULT NULL,
  `price` varchar(20) DEFAULT NULL,
  `categoriesAndSubcategories` int DEFAULT NULL,
  `productImages` text,
  `variants` varchar(100) DEFAULT NULL,
  `specifications` text,
  `minimumOrderQuantity` varchar(100) DEFAULT NULL,
  `bulkOrderDiscounts` varchar(10) DEFAULT NULL,
  `featuresOfAProduct` varchar(500) DEFAULT NULL,
  `availabilityStockStatus` varchar(50) DEFAULT NULL,
  `sellerInformation` varchar(100) DEFAULT NULL,
  `additionalAttributes` varchar(150) DEFAULT NULL,
  `type` int DEFAULT NULL,
  `productGroupJson` json DEFAULT NULL,
  `groupId` varchar(500) DEFAULT NULL,
  `parentTopnode` int DEFAULT NULL,
  `hierarchybranch` varchar(200) DEFAULT NULL,
  `websiteURL` text,
  `perMetricPrice` varchar(20) DEFAULT NULL,
  `AlternativeIds` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_uuid` (`uuid`),
  KEY `idx_categoriesAndSubcategories` (`categoriesAndSubcategories`),
  KEY `idx_price` (`price`),
  KEY `idx_sellerInformation` (`sellerInformation`),
  KEY `idx_groupId` (`groupId`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=23922 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_whl_rtl_product_dtl_transaction_log`
--

DROP TABLE IF EXISTS `tb_whl_rtl_product_dtl_transaction_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_whl_rtl_product_dtl_transaction_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uuid` varchar(40) DEFAULT NULL,
  `price` float DEFAULT NULL,
  `logdate` date DEFAULT NULL,
  `createdate` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=200818 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_whl_rtl_product_field_config`
--

DROP TABLE IF EXISTS `tb_whl_rtl_product_field_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_whl_rtl_product_field_config` (
  `pfid` int NOT NULL AUTO_INCREMENT,
  `fieldName` varchar(150) NOT NULL,
  PRIMARY KEY (`pfid`),
  UNIQUE KEY `fieldName` (`fieldName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_whl_rtl_product_list_info`
--

DROP TABLE IF EXISTS `tb_whl_rtl_product_list_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_whl_rtl_product_list_info` (
  `id` int NOT NULL AUTO_INCREMENT,
  `listId` int NOT NULL,
  `uuid` varchar(50) NOT NULL,
  `createdate` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`listId`,`uuid`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1248 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_whl_rtl_product_threshold_limit`
--

DROP TABLE IF EXISTS `tb_whl_rtl_product_threshold_limit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_whl_rtl_product_threshold_limit` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uuid` varchar(40) DEFAULT NULL,
  `userid` int DEFAULT NULL,
  `startingPrice` float DEFAULT NULL,
  `currPrice` float DEFAULT NULL,
  `thresholdPrice` float DEFAULT NULL,
  `createdDate` datetime DEFAULT CURRENT_TIMESTAMP,
  `UpdatedDate` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_whl_rtl_searched_viewed_product_dtl`
--

DROP TABLE IF EXISTS `tb_whl_rtl_searched_viewed_product_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_whl_rtl_searched_viewed_product_dtl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uuid` varchar(40) DEFAULT NULL,
  `searchedproductName` varchar(40) DEFAULT NULL,
  `createDate` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=394 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_whl_rtl_sign_signup_user_dtl`
--

DROP TABLE IF EXISTS `tb_whl_rtl_sign_signup_user_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_whl_rtl_sign_signup_user_dtl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(250) DEFAULT NULL,
  `verify_code` varchar(10) DEFAULT NULL,
  `is_verified` int DEFAULT '0',
  `created_date` datetime(3) DEFAULT NULL,
  `deviceid` varchar(100) DEFAULT NULL,
  `ip_address` varchar(20) DEFAULT NULL,
  `expiry_time` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=184 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_whl_rtl_sim_only_product_dtl`
--

DROP TABLE IF EXISTS `tb_whl_rtl_sim_only_product_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_whl_rtl_sim_only_product_dtl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uuid` varchar(50) DEFAULT NULL,
  `groupId` varchar(150) DEFAULT NULL,
  `serviceType` varchar(50) DEFAULT NULL,
  `companyName` varchar(150) DEFAULT NULL,
  `planName` varchar(200) DEFAULT NULL,
  `contractLength` int DEFAULT NULL,
  `monthlyCost` varchar(20) DEFAULT NULL,
  `data` varchar(20) DEFAULT NULL,
  `callMinutes` varchar(50) DEFAULT NULL,
  `texts` text,
  `perks` text,
  `sellerInformation` varchar(20) DEFAULT NULL,
  `createdAt` datetime DEFAULT CURRENT_TIMESTAMP,
  `websiteURL` text,
  `critique` text,
  `offers` text,
  `dataMetric` varchar(50) DEFAULT NULL,
  `overallPrice` float DEFAULT NULL,
  PRIMARY KEY (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_whl_rtl_sub_category_dtl`
--

DROP TABLE IF EXISTS `tb_whl_rtl_sub_category_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_whl_rtl_sub_category_dtl` (
  `subCatgId` int NOT NULL AUTO_INCREMENT,
  `fkCatgId` int DEFAULT NULL,
  `subCatgName` varchar(150) NOT NULL,
  `subCatgDesc` varchar(500) DEFAULT NULL,
  `subCatgStatus` int DEFAULT NULL,
  `subCatgImgURL` varchar(500) DEFAULT NULL,
  `subCatgPosition` int DEFAULT NULL,
  `createDate` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`subCatgId`,`subCatgName`),
  KEY `tb_whl_rtl_sub_category_dtl_idfk` (`fkCatgId`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_whl_rtl_user_login_log`
--

DROP TABLE IF EXISTS `tb_whl_rtl_user_login_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_whl_rtl_user_login_log` (
  `idx` int NOT NULL AUTO_INCREMENT,
  `login_user_id` varchar(50) DEFAULT NULL,
  `login_password` varchar(50) DEFAULT NULL,
  `errcode` int DEFAULT NULL,
  `errmsg` varchar(250) DEFAULT NULL,
  `create_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `login_source` varchar(30) DEFAULT NULL,
  `login_device_id` varchar(100) DEFAULT NULL,
  `login_ipaddress` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`idx`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_whl_rtl_user_password_reset_log`
--

DROP TABLE IF EXISTS `tb_whl_rtl_user_password_reset_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_whl_rtl_user_password_reset_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(50) DEFAULT NULL,
  `link` text,
  `expiry_time` int DEFAULT NULL,
  `created_date` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_whl_rtl_users_dtl`
--

DROP TABLE IF EXISTS `tb_whl_rtl_users_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_whl_rtl_users_dtl` (
  `userid` int NOT NULL AUTO_INCREMENT,
  `userType` int DEFAULT NULL,
  `signIn_type` int DEFAULT NULL,
  `firstName` varchar(100) DEFAULT NULL,
  `lastName` varchar(100) DEFAULT NULL,
  `emailAddress` varchar(250) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `status` int DEFAULT NULL,
  `companyName` varchar(250) DEFAULT NULL,
  `businessRegistrationNumber` varchar(50) DEFAULT NULL,
  `VATNumber` varchar(50) DEFAULT NULL,
  `country` varchar(50) DEFAULT NULL,
  `postalCode` varchar(20) DEFAULT NULL,
  `companyAddress` text,
  `source` varchar(20) DEFAULT NULL,
  `ipAddress` varchar(100) DEFAULT NULL,
  `createDate` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime DEFAULT NULL,
  `approvedDate` datetime DEFAULT NULL,
  `approvedBy` int DEFAULT NULL,
  `contactNumber` varchar(40) DEFAULT NULL,
  `website` varchar(500) DEFAULT NULL,
  `businessLogo` varchar(500) DEFAULT NULL,
  `productSize` varchar(20) DEFAULT NULL,
  `category` varchar(500) DEFAULT NULL,
  `primaryCustomers` varchar(100) DEFAULT NULL,
  `minOrderValue` float DEFAULT NULL,
  `delivery` varchar(50) DEFAULT NULL,
  `proofOfIdentity` varchar(500) DEFAULT NULL,
  `secondaryCategoryGoods` json DEFAULT NULL,
  `industryType` varchar(100) DEFAULT NULL,
  `latitude` varchar(20) DEFAULT NULL,
  `longitude` varchar(20) DEFAULT NULL,
  `paymentType` int DEFAULT NULL,
  `paymentAmount` float DEFAULT NULL,
  `vat_amount` float DEFAULT NULL,
  `plan_id` int DEFAULT NULL,
  `plan_startdate` varchar(20) DEFAULT NULL,
  `plan_enddate` varchar(20) DEFAULT NULL,
  `approved1_By` int DEFAULT NULL,
  `approved1_at` datetime DEFAULT NULL,
  `approved1_status` int DEFAULT NULL,
  `approved2_By` int DEFAULT NULL,
  `approved2_at` datetime DEFAULT NULL,
  `approved2_status` int DEFAULT NULL,
  `token` text,
  `servicetype` int DEFAULT NULL,
  `countryCodeId` varchar(10) DEFAULT NULL,
  `emailalert` tinyint DEFAULT '0',
  PRIMARY KEY (`userid`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=2820 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_whl_rtl_users_process_flow_dtl`
--

DROP TABLE IF EXISTS `tb_whl_rtl_users_process_flow_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_whl_rtl_users_process_flow_dtl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(200) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `contactNumber` varchar(40) DEFAULT NULL,
  `ipaddress` varchar(30) DEFAULT NULL,
  `source` varchar(20) DEFAULT NULL,
  `userType` int DEFAULT NULL,
  `processflow` varchar(100) DEFAULT NULL,
  `createdate` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=185 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `whl_rtl_ad_click_dtl`
--

DROP TABLE IF EXISTS `whl_rtl_ad_click_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `whl_rtl_ad_click_dtl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `adid` int DEFAULT NULL,
  `ipaddress` varchar(20) DEFAULT NULL,
  `createDate` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=404 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `whl_rtl_user_card_details`
--

DROP TABLE IF EXISTS `whl_rtl_user_card_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `whl_rtl_user_card_details` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userid` int DEFAULT NULL,
  `nameoncard` varchar(150) DEFAULT NULL,
  `cardnumber` varchar(20) DEFAULT NULL,
  `expirymonth` int DEFAULT NULL,
  `expiryyear` int DEFAULT NULL,
  `cvv` char(3) DEFAULT NULL,
  `Address` text,
  `city` varchar(150) DEFAULT NULL,
  `country` varchar(150) DEFAULT NULL,
  `pincode` varchar(10) DEFAULT NULL,
  `createDate` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping routines for database 'WHL_RTL_B2C'
--
/*!50003 DROP PROCEDURE IF EXISTS `Split` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `Split`(v_String text, v_Delimiter CHAR(1))
SWL_return:
  begin
  
       
     DECLARE v_idx INT;     
     DECLARE v_slice VARCHAR(8000);     
  
     DROP TEMPORARY TABLE IF EXISTS tt_Split_temptable;
     CREATE TEMPORARY TABLE IF NOT EXISTS tt_Split_temptable
     (
        items VARCHAR(8000)
     );
     SET v_idx = 1;     
     if  CHAR_LENGTH(v_String) < 1 or v_String is null then  
        LEAVE SWL_return;
     end if;     
  
     SWL_Label:
     while v_idx != 0 DO
        set v_idx = LOCATE(v_Delimiter,v_String);
        if v_idx != 0 then
           set v_slice = left(v_String,v_idx -1);
        else
           set v_slice = v_String;
        end if;
        if( CHAR_LENGTH(v_slice) > 0) then
           insert into tt_Split_temptable(Items) values(v_slice);
        end if;
        set v_String = right(v_String, CHAR_LENGTH(v_String) -v_idx);
        if  CHAR_LENGTH(v_String) = 0 then 
           LEAVE SWL_Label;
        end if;
     END WHILE; 
     LEAVE SWL_return;     
  end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `tb_whl_rtl_delete_import` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `tb_whl_rtl_delete_import`(
p_id int
)
Begin
	delete from tb_whl_rtl_insert_import where id = p_id;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `tb_whl_rtl_get_ad_click_performance_report` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `tb_whl_rtl_get_ad_click_performance_report`(
 p_userId int,
 p_Type int
 )
Begin
 	declare p_from varchar(10);
 	declare p_to varchar(10);
     
     if p_Type = 1 then set p_from = cast(now() as date); set p_to = cast(now() as date); end if;
     if p_Type = 2 then set p_from = DATE_ADD(cast(now() as date), INTERVAL -7 DAY); set p_to = cast(now() as date); end if;
     if p_Type = 1 then set p_from = DATE_ADD(cast(now() as date), INTERVAL -30 DAY); set p_to = cast(now() as date); end if;
     
     select A.adid,B.name,count(*) as clickcount 
     from whl_rtl_ad_click_dtl A
     join tb_whl_rtl_Ad_manager B on A.adid = B.adId
     where cast(A.createDate as date) between p_from and p_to
     and B.userId = p_userId
     group by A.adid,B.name
     order by count(*) desc;
      
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `tb_whl_rtl_Get_category_master_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `tb_whl_rtl_Get_category_master_info`(
 p_Id int
 )
Begin
 	    select * from tb_whl_rtl_category_master_list where (id = p_Id or ifnull(p_Id,0)=0);
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `tb_whl_rtl_get_contact_dtl_interaction_report` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `tb_whl_rtl_get_contact_dtl_interaction_report`(
p_Type int,
p_rtluserid int
)
Begin
	declare p_from varchar(10);
	declare p_to varchar(10);
    
    if p_Type = 1 then set p_from = cast(now() as date); set p_to = cast(now() as date); end if;
    if p_Type = 2 then set p_from = DATE_ADD(cast(now() as date), INTERVAL -7 DAY); set p_to = cast(now() as date); end if;
    if p_Type = 1 then set p_from = DATE_ADD(cast(now() as date), INTERVAL -30 DAY); set p_to = cast(now() as date); end if;

	select A.rtluserid,B.companyName as retailerName,count(whluserid) as countOfContactClicks 
    from tb_whl_rtl_contact_dtl_interaction A 
    join tb_whl_rtl_users_dtl B on A.whluserid = B.userid
    where rtluserid = p_rtluserid
    and  cast(createDatetime as date) between p_from and p_to
    group by A.rtluserid, B.companyName ;

End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `tb_whl_rtl_get_import` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `tb_whl_rtl_get_import`(
p_sellerid int,
p_id int
)
Begin
	select * from tb_whl_rtl_insert_import where sellerid = p_sellerid and id= p_id;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `tb_whl_rtl_get_product_list_based_on_seller_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `tb_whl_rtl_get_product_list_based_on_seller_info`(
   p_sellerInfo int
   )
Begin
   
   
 	select 	a.id, a.uuid, a.productName, a.productDescription, a.brandName, a.price, a.categoriesAndSubcategories,c.catgName as lastparentproduct ,a.productImages, a.variants, a.specifications, a.minimumOrderQuantity, 
 			a.bulkOrderDiscounts, a.featuresOfAProduct, a.availabilityStockStatus, a.sellerInformation, a.additionalAttributes, a.type, a.productGroupJson
 	from tb_whl_rtl_product_dtl a 
 	join tb_whl_rtl_users_dtl b on (a.sellerInformation = b.companyName or a.sellerInformation = b.userid)
 	join tb_whl_rtl_category_master_list c on c.catgId = a.categoriesAndSubcategories
 	where (b.userid = p_sellerInfo or ifnull(p_sellerInfo,0)=0) ;
       
   End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `tb_whl_rtl_get_trend_analysis_report` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `tb_whl_rtl_get_trend_analysis_report`(
p_Type int
)
Begin
	declare p_from varchar(10);
	declare p_to varchar(10);
    
    if p_Type = 1 then set p_from = cast(now() as date); set p_to = cast(now() as date); end if;
    if p_Type = 2 then set p_from = DATE_ADD(cast(now() as date), INTERVAL -7 DAY); set p_to = cast(now() as date); end if;
    if p_Type = 1 then set p_from = DATE_ADD(cast(now() as date), INTERVAL -30 DAY); set p_to = cast(now() as date); end if;

	select A.uuid,B.productName, count(*) as countOfSearch
    from tb_whl_rtl_searched_viewed_product_dtl A 
    join tb_whl_rtl_product_dtl B on A.uuid = B.uuid
    where A.uuid is not null
    and cast(createDate as date) between p_from and p_to
    group by A.uuid,B.productName 
    order by count(*) desc limit 15;


End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `tb_whl_rtl_insert_contact_dtl_interaction_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `tb_whl_rtl_insert_contact_dtl_interaction_info`(
p_whluserid int,
p_rtluserid int,
p_ipaddress varchar(20)
)
Begin

		declare v_errcode int default -1;
 		declare v_errmsg varchar(50) default 'Failure';
       
 	    insert into tb_whl_rtl_contact_dtl_interaction (whluserid, rtluserid, ipaddress)
        values(p_whluserid, p_rtluserid, p_ipaddress);
         
         if row_count()>0 then
 			set v_errcode = 0;
 			set v_errmsg = 'Inserted';
         End if;
         
         select v_errcode as errcode, v_errmsg as errmsg;

End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `tb_whl_rtl_insert_import` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `tb_whl_rtl_insert_import`(
p_prodJson json,
p_sellerid int
)
Begin

	declare v_errcode int;
    declare v_errmsg varchar(50);
    declare v_id int;
	
	insert into tb_whl_rtl_insert_import (prodJson, sellerinfo) values(p_prodJson, p_sellerid);
    
    set v_id = last_insert_id();
    
    if row_count()>0 then
		set v_errcode = 0;
        set v_errmsg = 'Inserted';
    End if;
    
    select v_errcode as errcode , v_errmsg as errmsg, v_id as id;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `tb_whl_rtl_Insert_Update_category_master_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `tb_whl_rtl_Insert_Update_category_master_info`(
 p_id int,
 p_catgId int, 
 p_catgName varchar(100),
 p_parentCatgId int,
 p_status int
 )
Begin
 
 	declare v_errcode int;
     declare v_errmsg varchar(50);
     declare v_catgId int;
     
     select 1 into v_catgId from tb_whl_rtl_category_master_list where catgName = p_catgName and parentCatgId = p_parentCatgId and catgId = p_catgId;
     
     if v_catgId is null then
 		insert into tb_whl_rtl_category_master_list(catgId, catgName, parentCatgId, status)
         values(p_catgId, p_catgName, p_parentCatgId, p_status);
         
         set v_catgId = LAST_INSERT_ID();
         
         set v_errcode = 0;
         set v_errmsg = 'Inserted';
     else
     
 		update tb_whl_rtl_category_master_list a
         set a.catgName = ifnull(p_catgName,a.catgName),
 			a.parentCatgId = ifnull(p_parentCatgId,a.parentCatgId),
            a.catgId = ifnull(p_catgId,a.catgId),            
             a.status = ifnull(p_status,a.status)
 		where id = p_id;
         
 		set v_errcode = 0;
         set v_errmsg = 'Updated';
     End if;
 
 	select v_errcode as errcode, v_errmsg as errmsg,ifnull(v_catgId,0) as id,ifnull(p_catgId,0) as catgId,ifnull(p_parentCatgId,0) as parentCatgId;
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `up_homepageReportCount` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `up_homepageReportCount`()
BEGIN
  	SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED; 
  	SELECT COUNT(1) AS categoryCount FROM WHL_RTL_CRM.tb_whl_rtl_category_master_list where status = 1;
  	SELECT COUNT(1) AS productCount	FROM tb_whl_rtl_product_dtl;
	SELECT COUNT(1) AS overallwholesalerCount	FROM tb_whl_rtl_users_dtl WHERE userType IN (2,4) and status = 1; 
    SELECT COUNT(Distinct b.sellerInformation) AS wholesalerCount	FROM tb_whl_rtl_users_dtl a join tb_whl_rtl_product_dtl b on b.sellerInformation = a.userid WHERE userType IN (2,4) and status = 1; 
    
    
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `up_wholesalerList` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `up_wholesalerList`()
BEGIN
  	SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED; 
     SELECT 	U.userid		
         ,	CONCAT(IFNULL(CONCAT(U.firstName,' '),''), IFNULL(CONCAT(U.lastName,' '),'')) wholesalerName
         ,	U.businessLogo	
     FROM 	tb_whl_rtl_users_dtl U
     WHERE 	U.userType IN (2,4) and U.status =1 ; 
 	SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ur_get_sales_team_extn_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ur_get_sales_team_extn_info`()
begin
 	select * from ur_sales_team_extn_info;
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_AdId_approval_process` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_AdId_approval_process`(
 p_adId int,
 p_type int,
 p_approved_By int,
 p_approved_status int
 )
Begin
 	declare v_errcode int default -1;
 	declare v_errmsg varchar(50) default 'Not found';
     
     sp_exit : Begin
     if not exists(select 1 from tb_whl_rtl_Ad_manager where adId = p_adId limit 1) then
 		set v_errcode = -1;
 		set v_errmsg = 'Not found';
         leave sp_exit;
     End if;
     
 
     if p_type = 1 then
 		update tb_whl_rtl_Ad_manager a
 			set a.approved1_By = ifnull(p_approved_By,a.approved1_By),
 				a.approved1_status = ifnull(p_approved_status,a.approved1_status),
                 a.approved1_at = current_timestamp()
  		where a.adId = p_adId ;
     Else
 		update tb_whl_rtl_Ad_manager a
 			set a.approved2_By = ifnull(p_approved_By,a.approved2_By),
 				a.approved2_status = ifnull(p_approved_status,a.approved2_status),
                 a.approved2_at = current_timestamp()
  		where a.adId = p_adId ;
     End if;
 
   		set v_errcode = 0;
 		set v_errmsg = 'Updated';
 	End;
   	select v_errcode as errcode, v_errmsg as errmsg;
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_admin_login_validation` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_admin_login_validation`(
   	p_username VARCHAR(60)
   	,p_password  VARCHAR(50)
)
sp_return: Begin

        declare v_found int;
        
			if not exists(select 1 from tb_whl_rtl_crm_admin_user a where username = p_username limit 1)then
				select -1 as errcode, 'User not found' as errmsg;
				leave sp_return;
			end if;
		 
			if exists(select 1 from tb_whl_rtl_crm_admin_user a where username = p_username and BINARY password <> p_password) then
				select -1 as errcode, 'Incorrect Password' as errmsg;
				leave sp_return;
			end if;
			
			select 1 into v_found from tb_whl_rtl_crm_admin_user where username = p_username and BINARY password = p_password and status = 1 ;
			
			if v_found is null then
				select -1 as errcode, 'Inactive / wrong Password' as errmsg;
				leave sp_return;
			else
				select 0 as errcode, 'Login successfully' as errmsg,a.*
				from tb_whl_rtl_crm_admin_user a                     
				where a.username = p_username and BINARY a.password = p_password and status = 1 ; 
			end if;

	End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_APIDeleteDomainEndPoint_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_APIDeleteDomainEndPoint_details`(
 p_apidomainId int
 )
BEgin
 		declare v_errcode int default -1;
 		declare v_errmsg varchar(50) default 'Not found';
       
 	    delete from tb_whl_rtl_API_Domain_details where apidomainId = p_apidomainId;
         
         if row_count()>0 then
 			set v_errcode = 0;
 			set v_errmsg = 'Deleted';
         End if;
         
         select v_errcode as errcode, v_errmsg as errmsg;
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_APIGetDomainEndPoint_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_APIGetDomainEndPoint_details`(
  p_domain_id int
  )
Begin
  	select * from tb_whl_rtl_API_Domain_details a where a.domain_id = p_domain_id ;
  End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_APIInsertDomainEndPoint_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_APIInsertDomainEndPoint_details`(
	p_domain_id int,
	p_domainName varchar(150),
	p_domaindesc varchar(150),
	p_authtype varchar(150),
	p_userName varchar(150),
	p_password varchar(150),
	p_token varchar(150) ,
	p_oauthId int,
	p_domainURL varchar(150),
	p_endPointDetails json,
	p_header varchar(150),
	p_value varchar(150)
         )
Begin
         
  		declare v_errcode int default -1;
  		declare v_errmsg varchar(150) default 'Failure';
  		declare v_apidomainId int; 
             
             sp_exit:Begin
     
         			if exists (select 1 from tb_whl_rtl_API_Domain_details where domainName = p_domainName and domain_id = p_domain_id limit 1) then
         				set v_errcode = -1;
         				set v_errmsg = 'Domain Name already exists';
         				leave sp_exit;
         			End if;
      
                     insert into tb_whl_rtl_API_Domain_details(domain_id, domainName, domainDesc, authtype, userName, password, token, oauthId, domainURL, endPointDetails, createdAt, header,value)
                     values(p_domain_id, p_domainName, p_domainDesc, p_authtype, p_userName, p_password, p_token, p_oauthId, p_domainURL, p_endPointDetails, current_timestamp, p_header, p_value);
              
                     set v_apidomainId = last_insert_id();
                     
                     if row_count()>0 then
         				set v_errcode = 0;
         				set v_errmsg = 'Success : Inserted';
         				leave sp_exit;
                     End if;       
       
         	End;
             select v_errcode as errcode, v_errmsg as errmsg,ifnull(v_apidomainId,0) as apidomainId;
         End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_clear_product_records` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_clear_product_records`()
Begin
  	truncate table tb_whl_rtl_product_dtl;
      select 0 errcode, 'Product table cleared'as errmsg;
  End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_clear_sim_records` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_clear_sim_records`()
Begin
  	
  	truncate table tb_whl_rtl_sim_only_product_dtl;
      select 0 errcode, 'Sim table cleared' as errmsg;
  End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_create_forget_password_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_create_forget_password_dtl`(
	email VARCHAR(250),
    link text
)
Begin
        
           DECLARE verify_code VARCHAR(10);
           DECLARE errcode INT; 
           DECLARE errmsg VARCHAR(250);
           DECLARE now DATETIME(3);
           DECLARE v_name VARCHAR(250);
        
           sp_exit:
           BEGIN
        
              set errcode = -1;
              set errmsg = '';
              set now = CURRENT_TIMESTAMP;
              
              if not exists(select 1 from tb_whl_rtl_users_dtl a  where a.emailAddress = email LIMIT 1) then
                set errcode = -1;
                set errmsg = 'Incorrect email address';
                LEAVE sp_exit;
             end if;
        
              if exists(select * from tb_whl_rtl_user_password_reset_log a  where a.email = email limit 1) then
        		
                 UPDATE tb_whl_rtl_user_password_reset_log a 
                 set a.link = link,a.expiry_time = 10, created_date = now()
                 where a.email = email;
                 
                 if ROW_COUNT() > 0 then
        			
                    set errcode = 0;
                    set errmsg = 'success';
                    LEAVE sp_exit;
                 end if;
              end if;
              if not exists(select * from tb_whl_rtl_user_password_reset_log a where a.email = email LIMIT 1) then
        		
        			insert into tb_whl_rtl_user_password_reset_log( email, link, expiry_time)
        			values(email,link,10);
        			
                 if ROW_COUNT() > 0 then
        			
                    set errcode = 0;
                    set errmsg = 'success to generate pin';
                 end if;
              end if;
           END;
           
           select concat(firstName) into v_name from tb_whl_rtl_users_dtl a  where a.emailAddress = email limit 1; 
      
           select errcode as errcode,errmsg as errmsg,v_name as userName;
        
        End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_create_personal_sign_signup_user_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_create_personal_sign_signup_user_dtl`(
       email VARCHAR(250),
       deviceid VARCHAR(100),
       ip_address VARCHAR(20)
       )
Begin
       
          DECLARE verify_code VARCHAR(10);
          DECLARE errcode INT; 
          DECLARE errmsg VARCHAR(250);
          DECLARE now DATETIME(3);
          DECLARE default_val_0 int;
       
          sp_exit:
          BEGIN
       
             set errcode = -1;
             set errmsg = '';
             set now = CURRENT_TIMESTAMP;
             set default_val_0 = 0 ;

             if exists(select * from tb_whl_rtl_sign_signup_user_dtl a  where a.email = email and a.is_verified = 1 LIMIT 1) then
       		
                set errcode = -1;
                set errmsg = 'This email address already verified';
                LEAVE sp_exit;
             end if;
       
             SET verify_code = right(FORMAT(RAND(),7),6);
       
             if exists(select * from tb_whl_rtl_sign_signup_user_dtl a  where a.email = email and a.is_verified = 0 LIMIT 1) then
       		
                UPDATE tb_whl_rtl_sign_signup_user_dtl a set a.verify_code = verify_code,a.created_date = now,a.deviceid = deviceid,
                a.ip_address = ip_address,a.expiry_time = 10
                where a.email = email and a.is_verified = 0;
                if ROW_COUNT() > 0 then
       			
                   set errcode = 0;
                   set errmsg = 'success';
                   LEAVE sp_exit;
                end if;
             end if;
             if not exists(select * from tb_whl_rtl_sign_signup_user_dtl a where a.email = email LIMIT 1) then
       		
       			insert into tb_whl_rtl_sign_signup_user_dtl(email,verify_code,is_verified,created_date,deviceid,ip_address,expiry_time)
       			values(email,verify_code,0,now,deviceid,ip_address,10);
       			
                if ROW_COUNT() > 0 then
       			
                   set errcode = 0;
                   set errmsg = 'success to generate pin';
                end if;
             end if;
          END;
     
          select errcode as errcode,errmsg as errmsg, IFNULL(verify_code,default_val_0) as verify_code;
       
       End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_crm_get_approved_ad_list_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_crm_get_approved_ad_list_info`(
  p_adType int,
  p_adLoctoAppear int,
  p_status int
  )
Begin
	select 	B.emailAddress,B.userType,
			concat(C.firstname,' ',C.lastname) as approved1_by ,
			concat(D.firstname,' ',D.lastname) as approved2_by ,
    A.* 
	from tb_whl_rtl_Ad_manager A
	join tb_whl_rtl_users_dtl B on B.userid = A.userId
    left join tb_whl_rtl_crm_admin_user C on A.approved1_By = C.id
    left join tb_whl_rtl_crm_admin_user D on A.approved2_By = D.id
	where A.status = p_status and adType = p_adType and adLoctoAppear = p_adLoctoAppear;
    
    
  End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_crm_insert_ad_approval_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_crm_insert_ad_approval_info`(
 p_adId int,
 p_status int,
 p_approved_by int, 
 p_freeOrPaid int, 
 p_paidAmount float,
 p_vat_amount float,
 p_payment_status int
 )
Begin
 	declare v_errcode int default -1;
     declare v_errmsg varchar(50) default 'Not found';
 
 	
     if exists(select 1 from tb_whl_rtl_Ad_manager where adId = p_adId limit 1) then
		update tb_whl_rtl_Ad_manager a
		set a.status = ifnull(p_status,a.status),
			a.approved_date = now(),
			a.approved_by = p_approved_by,
			a.freeOrPaid = ifnull(p_freeOrPaid,a.freeOrPaid),
			a.paidAmount = ifnull(p_paidAmount,a.paidAmount),
            a.vat_amount = ifnull(p_vat_amount,a.vat_amount),
            a.payment_status = ifnull(p_payment_status,a.payment_status)
		where adId = p_adId ;
     End if;
 	
     if row_count() > 0 then
 		set v_errcode = 0;
         set v_errmsg = 'Updated';
     End if;
     
     
 	select v_errcode as errcode, v_errmsg as errmsg;
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_deletelist_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_deletelist_info`(
p_listId int
)
Begin
	declare v_errcode int default -1;
    declare v_errmsg varchar(50) default 'Not found';
    
	delete from tb_whl_rtl_list_master_info where listId = p_listId;
    if row_count() > 0 then
		set v_errcode = 0;
        set v_errmsg = 'Deleted'; 
    End if;
    select v_errcode as errcode, v_errmsg as errmsg;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_delete_Ad_manager_info_by_adId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_delete_Ad_manager_info_by_adId`(
 p_adId int
 )
Begin
	declare v_errcode int default -1;
    declare v_errmsg varchar(100) default 'Not found';
 
	Delete from tb_whl_rtl_Ad_manager A where A.adId = p_adId ;
    
    if row_count()>0 then
		set v_errcode = 0;
        set v_errmsg = 'Ad Deleted';
    End if;
 
 	select v_errcode as errcode, v_errmsg as errmsg;
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_delete_chat_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_delete_chat_dtl`(
p_chatId int,
p_userId int
)
Begin
	declare v_errcode int default -1;
    declare v_errmsg varchar(50) default 'Not found';
    
    sp_exit:begin
     if p_chatId is null or ifnull(p_userId,0)=0 then
		set v_errcode = -1;
		set v_errmsg = 'Title/userId should be mandatory';
		leave sp_exit;
	End if;
    
    if not exists(select 1 from tb_whl_rtl_chat_master_dtl where chatId = p_chatId limit 1) then
		set v_errcode = -1;
		set v_errmsg = 'Record not found';
		leave sp_exit;
	End if;
    
		delete from tb_whl_rtl_chat_master_dtl where chatId = p_chatId;
		
		if row_count()>0 then
			set v_errcode = 0;
			set v_errmsg = 'Deleted';
		End if;
    
	end;
    select v_errcode as errcode, v_errmsg as errmsg;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_Delete_oauthclient_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_Delete_oauthclient_details`(
 p_id int
 )
BEgin
 		declare v_errcode int default -1;
 		declare v_errmsg varchar(50) default 'Not found';
       
 	    delete from tb_whl_rtl_oauthclient_details where id = p_id;
         
         if row_count()>0 then
 			set v_errcode = 0;
 			set v_errmsg = 'Deleted';
         End if;
         select v_errcode as errcode, v_errmsg as errmsg;
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_Delete_product_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_Delete_product_info`(
   	p_id text
   )
Begin
   
   
   		declare v_errcode int default -1;
   		declare v_errmsg varchar(50) default 'Not found';
           
   		call Split(p_id,',');
               
   		drop temporary table if exists tt_deletelist;
   		create temporary table tt_deletelist
   		(
   		id varchar(40) primary key
   		);
           
           insert into tt_deletelist(id)
   		select items from tt_Split_temptable;
           
   		delete A from tb_whl_rtl_product_dtl A join tt_deletelist B on A.uuid = B.id;
         
         
   		if row_Count()>0 then
			DELETE B from tb_whl_rtl_product_list_info B join tt_deletelist C on B.uuid = C.id;
   
   			set v_errcode = 0;
               set v_errmsg = 'Deleted';
           End if;
           
           select v_errcode as errcode, v_errmsg as errmsg;
   End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_delete_product_price_alert_list` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_delete_product_price_alert_list`(
p_id int
)
Begin
	declare v_errcode int default -1;
    declare v_errmsg varchar(50) default 'Not found';
    
	delete from tb_whl_rtl_product_threshold_limit where id = p_id;
    
    if row_count()>0 then
		set v_errcode = 0;
		set v_errmsg = 'Alert Deleted';
	End if;
    
    select v_errcode as errcode, v_errmsg as errmsg;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_delete_product_to_list_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_delete_product_to_list_info`(
   p_listId int,
   p_uuid text
   )
Begin
   	
     declare v_errcode int default -1;
 	declare v_errmsg varchar(50) default 'Not found';
     
 		call Split(p_uuid,',');
 
 		drop temporary table if exists tt_deletelist;
 		create temporary table tt_deletelist
 		(
         uuid varchar(40) primary key
 		);
 
 		insert into tt_deletelist(uuid)
 		select items from tt_Split_temptable;
   
 		delete A from tb_whl_rtl_product_list_info A join tt_deletelist B on A.uuid = B.uuid where A.listId = p_listId;
       
       if row_count() > 0 then
   		set v_errcode = 0;
           set v_errmsg = 'Deleted'; 
       End if;
       select v_errcode as errcode, v_errmsg as errmsg;
   End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_delete_users_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_delete_users_dtl`(
 p_sellerInfo int
 )
Begin
 	declare v_errcode int default -1;
     declare v_errmsg varchar(50) default 'Not found';
     
     if exists(select 1 from tb_whl_rtl_users_dtl a where a.userid = p_sellerInfo limit 1) then
 		delete a from tb_whl_rtl_users_dtl a where a.userid = p_sellerInfo;
         
 		delete a from tb_whl_rtl_product_dtl a 
 		
 		
         where (a.sellerInformation = p_sellerInfo);
         
         delete from tb_whl_rtl_Ad_manager where userId = p_sellerInfo;
         
         set v_errcode = 0;
 		set v_errmsg = 'Deleted'; 
         
     End if;
 
 	select v_errcode as errcode, v_errmsg as errmsg;
 
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_getlist_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_getlist_info`(
   p_userId int
   )
Begin
 	
 		select 	A.listId,A.listName, count(C.uuid) as counfOfprod,
 				group_concat(C.uuid SEPARATOR ' | ') as uuid, 
 				group_concat(C.productImages SEPARATOR ' | ') as productImages
 		from tb_whl_rtl_list_master_info A LEFT join tb_whl_rtl_product_list_info B on A.listId = B.listId
 		left join tb_whl_rtl_product_dtl C on C.uuid = B.uuid
 		where A.userId = p_userId 
 		group by A.listId,A.listName;
   End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_GetMainPageSearchResultBasedOnUUID` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_GetMainPageSearchResultBasedOnUUID`(
       	p_uuid text
       )
begin
                     
                     	call Split(p_uuid,',');
                         
                         drop temporary table if exists tt_uuidlistinfo; create temporary table tt_uuidlistinfo (id INT auto_increment, uuid varchar(150), pid int, primary key(id,uuid));
                         
                          insert into tt_uuidlistinfo(uuid, pid) select b.uuid,a.items from tt_Split_temptable a join tb_whl_rtl_product_dtl b on a.items = b.id;
                         
                        
                         
  						drop temporary table if exists tt_grplist; 
  						create temporary table tt_grplist 
  						as 
  						select Distinct A.groupId from tb_whl_rtl_product_dtl A where A.uuid in (select Distinct B.uuid from tt_uuidlistinfo B);
  
  						drop temporary table if exists tt_grpuuidlist; 
  						create temporary table tt_grpuuidlist 
  						as 
  						select Distinct AA.uuid from tb_whl_rtl_product_dtl AA where AA.groupId in (select Distinct BB.groupId from tt_grplist BB);
                         
                         drop temporary table if exists tt_prodgrplist;
             			create temporary table tt_prodgrplist as
                         select Distinct uuid from
                         (
             				select A.uuid from tt_uuidlistinfo A
             				union all
             				select B.uuid from tt_grpuuidlist B
                         )ZZ;
             
             				drop temporary table if exists tt_cte_finalgrplist;
                             create temporary table  tt_cte_finalgrplist 
                             as         
                             with cte_tt_grplist(id,sellerName,uuid, productName, productDescription, brandName, price, categoriesAndSubcategories, productImages, variants, specifications, minimumOrderQuantity, bulkOrderDiscounts, 
                     				featuresOfAProduct, availabilityStockStatus, sellerInformation, additionalAttributes, type, productGroupJson, groupId, parentTopnode, hierarchybranch,userid,latitude,longitude,perMetricPrice,DNSRNK, businessLogo)
                             as
                             (
              				select 	a.id,c.companyName as sellerName,a.uuid, productName, productDescription, brandName, cast(price as float), categoriesAndSubcategories, productImages, variants, specifications, minimumOrderQuantity, bulkOrderDiscounts, 
              						featuresOfAProduct, availabilityStockStatus, sellerInformation, additionalAttributes, type, productGroupJson, groupId, parentTopnode, hierarchybranch,c.userid,c.latitude,c.longitude,perMetricPrice,
              						DENSE_RANK() over(PARTITION BY groupId  ORDER BY price asc, sellerInformation) as DNSRNK, c.businessLogo
              				from tb_whl_rtl_product_dtl a 
              				join tt_prodgrplist b on a.uuid = b.uuid
              				left join tb_whl_rtl_users_dtl c on c.userid = a.sellerInformation
                             )
              				select 	id,sellerName,uuid, productName, productDescription, brandName, price, categoriesAndSubcategories, productImages, variants, specifications, minimumOrderQuantity, bulkOrderDiscounts, 
              						featuresOfAProduct, availabilityStockStatus, sellerInformation, additionalAttributes, type, productGroupJson, groupId, parentTopnode, hierarchybranch,userid,latitude,longitude,perMetricPrice,DNSRNK ,businessLogo
              				from cte_tt_grplist ;
                             
                              drop temporary table if exists tt_cte_finalgrplist_A;
                              create temporary table tt_cte_finalgrplist_A as 
                              select * from tt_cte_finalgrplist;
                              
                              drop temporary table if exists tt_finalresult;
                              create temporary table tt_finalresult as 
                             select id,groupId,prodcountbygrp,uuid,sellerName,productName,minprice,maxprice,productImages,hierarchybranch,minimumOrderQuantity,bulkOrderDiscounts,perMetricPrice, businessLogo, DNSRNK
               				from (
               					select id,null as groupId,1 as prodcountbygrp,M.uuid,M.sellerName,M.productName,M.price as minprice,M.price as maxprice,M.productImages,M.hierarchybranch,M.minimumOrderQuantity,M.bulkOrderDiscounts,M.perMetricPrice, M.businessLogo, 1 DNSRNK
               					from tt_cte_finalgrplist M
               					where M.groupId is null
               
               				union all
               					select 	N.id,
										N.groupId,
										
                                        count(*) over(partition by groupId order by groupId) as prodcountbygrp ,
										REPLACE(group_concat(DISTINCT (CASE WHEN N.DNSRNK = 1 THEN N.uuid ELSE '' END)   ),',','') as uuid,
       									REPLACE(group_concat(DISTINCT (CASE WHEN N.DNSRNK = 1 THEN N.sellerName ELSE '' END)   ),',','') as sellerName,
       									REPLACE(group_concat(DISTINCT (CASE WHEN N.DNSRNK = 1 THEN N.productName ELSE '' END)   ),',','') as productName,
       									min(N.price) as minprice,
       									max(N.price) as maxprice,
       									REPLACE(group_concat(DISTINCT (CASE WHEN N.DNSRNK = 1 THEN N.productImages ELSE '' END)   SEPARATOR '|'),'|','') as productImages,
       									REPLACE(group_concat(DISTINCT (CASE WHEN N.DNSRNK = 1 THEN N.hierarchybranch ELSE '' END)   ),',','') as hierarchybranch,
       									REPLACE(group_concat(DISTINCT (CASE WHEN N.DNSRNK = 1 THEN N.minimumOrderQuantity ELSE '' END)   ),',','') as minimumOrderQuantity,
                                         N.bulkOrderDiscounts,N.perMetricPrice,N.businessLogo, N.DNSRNK
               					from tt_cte_finalgrplist_A N
               					where N.groupId is not null
               					group by N.id,
											N.groupId,N.bulkOrderDiscounts,N.perMetricPrice,N.businessLogo, N.DNSRNK
               				)ZZ;  
                         
                            select A.*
                            from tt_finalresult A  
                            join tt_prodgrplist B on A.uuid = B.uuid 
                            and A.DNSRNK = 1;
                          
             
                 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_GetMainPageSearchResultBasedOnUUID_test` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_GetMainPageSearchResultBasedOnUUID_test`(
       	p_uuid text
       )
begin
                     
                     	call Split(p_uuid,',');
                         
                         drop temporary table if exists tt_uuidlistinfo; create temporary table tt_uuidlistinfo (id INT auto_increment, uuid varchar(150), pid int, primary key(id,uuid));
                         
                          insert into tt_uuidlistinfo(uuid, pid) select b.uuid,a.items from tt_Split_temptable a join tb_whl_rtl_product_dtl b on a.items = b.id;
                         
                        
                         
  						drop temporary table if exists tt_grplist; 
  						create temporary table tt_grplist 
  						as 
  						select Distinct A.groupId from tb_whl_rtl_product_dtl A where A.uuid in (select Distinct B.uuid from tt_uuidlistinfo B);
  
  						drop temporary table if exists tt_grpuuidlist; 
  						create temporary table tt_grpuuidlist 
  						as 
  						select Distinct AA.uuid from tb_whl_rtl_product_dtl AA where AA.groupId in (select Distinct BB.groupId from tt_grplist BB);
                         
                         drop temporary table if exists tt_prodgrplist;
             			create temporary table tt_prodgrplist as
                         select Distinct uuid from
                         (
             				select A.uuid from tt_uuidlistinfo A
             				union all
             				select B.uuid from tt_grpuuidlist B
                         )ZZ;
             
             				drop temporary table if exists tt_cte_finalgrplist;
                             create temporary table  tt_cte_finalgrplist 
                             as         
                             with cte_tt_grplist(id,sellerName,uuid, productName, productDescription, brandName, price, categoriesAndSubcategories, productImages, variants, specifications, minimumOrderQuantity, bulkOrderDiscounts, 
                     				featuresOfAProduct, availabilityStockStatus, sellerInformation, additionalAttributes, type, productGroupJson, groupId, parentTopnode, hierarchybranch,userid,latitude,longitude,perMetricPrice,DNSRNK, businessLogo)
                             as
                             (
              				select 	a.id,c.companyName as sellerName,a.uuid, productName, productDescription, brandName, cast(price as float), categoriesAndSubcategories, productImages, variants, specifications, minimumOrderQuantity, bulkOrderDiscounts, 
              						featuresOfAProduct, availabilityStockStatus, sellerInformation, additionalAttributes, type, productGroupJson, groupId, parentTopnode, hierarchybranch,c.userid,c.latitude,c.longitude,perMetricPrice,
              						DENSE_RANK() over(PARTITION BY groupId ORDER BY price asc, sellerInformation) as DNSRNK, c.businessLogo
              				from tb_whl_rtl_product_dtl a 
              				join tt_prodgrplist b on a.uuid = b.uuid
              				left join tb_whl_rtl_users_dtl c on c.userid = a.sellerInformation
                             )
              				select 	id,sellerName,uuid, productName, productDescription, brandName, price, categoriesAndSubcategories, productImages, variants, specifications, minimumOrderQuantity, bulkOrderDiscounts, 
              						featuresOfAProduct, availabilityStockStatus, sellerInformation, additionalAttributes, type, productGroupJson, groupId, parentTopnode, hierarchybranch,userid,latitude,longitude,perMetricPrice,DNSRNK ,businessLogo
              				from cte_tt_grplist ;
                             
                              drop temporary table if exists tt_cte_finalgrplist_A;
                              create temporary table tt_cte_finalgrplist_A as 
                              select * from tt_cte_finalgrplist;
                              
                              drop temporary table if exists tt_finalresult;
                              create temporary table tt_finalresult as 
                             select groupId,prodcountbygrp,uuid,sellerName,productName,minprice,maxprice,productImages,hierarchybranch,minimumOrderQuantity,bulkOrderDiscounts,perMetricPrice, businessLogo, DNSRNK
               				from (
               					select id as groupId,1 as prodcountbygrp,M.uuid,M.sellerName,M.productName,M.price as minprice,M.price as maxprice,M.productImages,M.hierarchybranch,M.minimumOrderQuantity,M.bulkOrderDiscounts,M.perMetricPrice, M.businessLogo, 1 DNSRNK
               					from tt_cte_finalgrplist M
               					where M.groupId is null
               
               				union all
               					select 	N.groupId,
										
                                        count(*) over(partition by groupId order by groupId) as prodcountbygrp ,
										REPLACE(group_concat(DISTINCT (CASE WHEN N.DNSRNK = 1 THEN N.uuid ELSE '' END)  ),',','') as uuid,
       									REPLACE(group_concat(DISTINCT (CASE WHEN N.DNSRNK = 1 THEN N.sellerName ELSE '' END)  ),',','') as sellerName,
       									REPLACE(group_concat(DISTINCT (CASE WHEN N.DNSRNK = 1 THEN N.productName ELSE '' END)  ),',','') as productName,
       									min(N.price) as minprice,
       									max(N.price) as maxprice,
       									REPLACE(group_concat(DISTINCT (CASE WHEN N.DNSRNK = 1 THEN N.productImages ELSE '' END)  SEPARATOR '|'),'|','') as productImages,
       									REPLACE(group_concat(DISTINCT (CASE WHEN N.DNSRNK = 1 THEN N.hierarchybranch ELSE '' END)  ),',','') as hierarchybranch,
       									REPLACE(group_concat(DISTINCT (CASE WHEN N.DNSRNK = 1 THEN N.minimumOrderQuantity ELSE '' END)  ),',','') as minimumOrderQuantity,
                                         N.bulkOrderDiscounts,N.perMetricPrice,N.businessLogo, N.DNSRNK
               					from tt_cte_finalgrplist_A N
               					where N.groupId is not null
               					group by N.groupId,N.bulkOrderDiscounts,N.perMetricPrice,N.businessLogo, N.DNSRNK
               				)ZZ;  
                         
                            select A.* from tt_finalresult A  
                            join tt_prodgrplist B on A.uuid = B.uuid 
                            and A.DNSRNK = 1
                           ;
             
                 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_getproductdsinlist_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_getproductdsinlist_info`(
   p_userId int,
   p_listId int
   )
Begin
   
  	
  	select 	B.listId,
  			A.listName,
  			group_concat(DISTINCT productImages  ORDER BY C.price SEPARATOR '| ') as prodImg,
  			count(*) as countOfProd
      from tb_whl_rtl_list_master_info A join tb_whl_rtl_product_list_info B on A.listId = B.listId
      Join tb_whl_rtl_product_dtl C on C.uuid = B.uuid
  	where A.userId = p_userId
      group by B.listId,A.listName;
      
   	select D.companyName as sellerName,C.*,D.businessLogo from tb_whl_rtl_product_list_info A 
      join tb_whl_rtl_product_dtl C on C.uuid = A.uuid
      join tb_whl_rtl_users_dtl D on D.userid = C.sellerInformation
      where A.listId = p_listId;
   End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_gettransaction_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_gettransaction_info`(
   p_tran_id int,
   p_user_id int
   )
Begin
   	select B.adType,A.* from tb_whl_rtl_crm_transaction_details A 
     left join tb_whl_rtl_Ad_manager B on A.ad_id = B.adId and A.user_id = B.userId
     where (A.tran_id = p_tran_id or ifnull(p_tran_id,0)=0) and A.user_id = p_user_id;
   End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_Get_Admin_User` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_Get_Admin_User`(
  p_id int
  )
Begin
  	select * from tb_whl_rtl_crm_admin_user where (id = p_id or ifnull(p_id,0)=0);
  End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_get_ad_clicks_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_get_ad_clicks_dtl`(p_userId int)
Begin
	select a.adId,b.name,count(a.adId) as count from tb_whl_rtl_ad_clicks_dtl a join tb_whl_rtl_Ad_manager b on a.adId = b.adId
    where userId = p_userId
    group by a.adId,b.name;
    
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_get_ad_click_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_get_ad_click_info`(
p_adid int
)
Begin
	select cast(createDate as date) as date, adid, count(*) as clickCount 
    from whl_rtl_ad_click_dtl where adid = p_adid
    group by cast(createDate as date) , adid;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_get_Ad_manager_info_by_adId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_get_Ad_manager_info_by_adId`(
p_adId int
)
Begin
	select B.companyName as sellerInfo,A.* from tb_whl_rtl_Ad_manager A
    join tb_whl_rtl_users_dtl B on A.userId = B.userId
    where (A.adId = p_adId or ifnull(p_adId,0)=0);
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_get_Ad_manager_info_by_userId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_get_Ad_manager_info_by_userId`(
p_userId int
)
Begin
	select B.companyName as sellerInfo,A.* from tb_whl_rtl_Ad_manager A
    join tb_whl_rtl_users_dtl B on A.userId = B.userId
    where (A.userId = p_userId or ifnull(p_userId,0)=0);
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_get_alternative_product_detailed_info_by_uuid` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_get_alternative_product_detailed_info_by_uuid`(
	p_uuid varchar(40)
)
Begin
	
		declare v_AlternativeIds text;
        
        select AlternativeIds into v_AlternativeIds from tb_whl_rtl_product_dtl where uuid = p_uuid;

		call Split(v_AlternativeIds,',');

		drop temporary table if exists tt_altprodlist;
		create temporary table tt_altprodlist
		(
			uuid varchar(150) primary key
		);
        
         insert into tt_altprodlist(uuid)
         select items from tt_Split_temptable;

		select c.businessLogo,c.companyName as sellerName,c.companyAddress,a.*,concat(a.parentTopnode,' > ',a.categoriesAndSubcategories) as taxoId
		from tb_whl_rtl_product_dtl a 
        join tt_altprodlist b on a.uuid = b.uuid
		join tb_whl_rtl_users_dtl c on c.userid = a.sellerInformation;
    
    
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_get_browse_by_categories` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_get_browse_by_categories`()
Begin
	select a.catgId,b.catgName,b.iconId ,c.icon
    from tb_whl_rtl_browse_by_categories_ist a 
    join tb_whl_rtl_category_master_list b on a.catgId = b.catgId
    join tb_whl_rtl_icon c on c.iconId = b.iconId
    and a.status = 1 order by a.position;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_get_category_hierarchy_flow` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_get_category_hierarchy_flow`()
Begin

		WITH RECURSIVE  
	cteA AS (
		SELECT catgId, catgName, 0 AS ParentLevel,parentCatgId,CAST(catgId as CHAR(100))  AS TopNode ,CAST(catgId as CHAR(100))  AS hierarchy
		FROM tb_whl_rtl_category_master_list T1 
		WHERE parentCatgId = 0
		union all
		SELECT T2.catgId, T2.catgName, ParentLevel + 1,T2.parentCatgId,itms.TopNode,CONCAT(hierarchy ,' -> ', CAST(T2.catgId AS CHAR(100))) AS flow 
		FROM tb_whl_rtl_category_master_list T2  
		INNER JOIN cteA itms ON itms.catgId = T2.parentCatgId
	)
	SELECT  *
	FROM  cteA 
	ORDER BY catgId,parentCatgId;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_Get_category_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_Get_category_info`(
p_catgId int
)
begin
	select * from tb_whl_rtl_category_dtl where (catgId = p_catgId or ifnull(p_catgId, 0)=0);
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_get_chat_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_get_chat_dtl`(
p_chatId int,
p_userId int
)
Begin
	if p_chatId is null then
		select  chatId,userId, title, updateddate from tb_whl_rtl_chat_master_dtl where userId = p_userId order by updateddate desc;
    else
		select  chatId,userId, title, chatJson,  updateddate from tb_whl_rtl_chat_master_dtl where userId = p_userId and chatId = p_chatId;
    End if;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_get_connector_token` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_get_connector_token`(
p_userId INT
)
Begin
	select * from tb_whl_rtl_connector_token_info where userId = p_userId;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_get_country_code` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_get_country_code`()
Begin
select * from tb_whl_rtl_country_code;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_get_email_phonenumber_available_check` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_get_email_phonenumber_available_check`(
    p_email varchar(100),
    p_phonenumber varchar(100)
    )
sp_return:begin
  
 	declare v_errcode int;
 	declare v_errmsg varchar(50);
 	declare v_found int;
     
 	if ifnull(p_email,'')<>'' then
 
 		select 1 into v_found from tb_whl_rtl_users_dtl where emailAddress = p_email;
 		   
 		   if v_found is null then
 				select 0 as errcode, 'New Email' as errmsg;
 
 		   else
 				select 0 as errcode, 'Email already found' as errmsg,A.*
 				from tb_whl_rtl_users_dtl A where A.emailAddress = p_email;
 				
 		   End if;
 	end if;
     
     if ifnull(p_phonenumber,'')<>''  then
 
 		select 1 into v_found from tb_whl_rtl_users_dtl where (contactNumber = p_phonenumber or businessRegistrationNumber = p_phonenumber);
 		   
 		   if v_found is null then
 			   select 0 as errcode, 'New Phonenumber' as errmsg;
  
 		   else
 			   select -1 as errcode, 'Phonenumber already found' as errmsg,A.*
 			   from tb_whl_rtl_users_dtl A where (A.contactNumber = p_phonenumber or businessRegistrationNumber = p_phonenumber);
        
 		   End if;
 	end if;
      
    End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_get_least_product_based_on_grouping` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_get_least_product_based_on_grouping`(
	p_uuid text,
	p_sellerinfo int
)
begin
       
               	call Split(p_uuid,',');
                   
 				drop temporary table if exists tt_uuidlistinfo; create temporary table tt_uuidlistinfo (uuid varchar(150) primary key);
                   
 				insert into tt_uuidlistinfo(uuid) select items from tt_Split_temptable;
                   
   				drop temporary table if exists tt_grplist; 
   				create temporary table tt_grplist 
   				as 
   				select Distinct A.groupId from tb_whl_rtl_product_dtl A where A.uuid in (select Distinct B.uuid from tt_uuidlistinfo B);
   
   				drop temporary table if exists tt_grpuuidlist; 
   				create temporary table tt_grpuuidlist 
   				as 
   				select Distinct AA.uuid from tb_whl_rtl_product_dtl AA where AA.groupId in (select Distinct BB.groupId from tt_grplist BB);
       
   				drop temporary table if exists tt_prodgrplist;
   				create temporary table tt_prodgrplist as
   				select Distinct uuid from
   				(
   					select A.uuid from tt_uuidlistinfo A
   					union all
   					select B.uuid from tt_grpuuidlist B
   				)ZZ;
                                
 
                      drop temporary table if exists tt_cte_grplist;
                      create temporary table  tt_cte_grplist 
                      as         
                      with cte_tt_grplist(id,sellerName,uuid, productName, productDescription, brandName, price, categoriesAndSubcategories, productImages, variants, specifications, minimumOrderQuantity, bulkOrderDiscounts, 
              				featuresOfAProduct, availabilityStockStatus, sellerInformation, additionalAttributes, type, productGroupJson, groupId, parentTopnode, hierarchybranch,userid,latitude,longitude,DNSRNK,businessLogo,companyAddress, websiteURL)
                      as
                      (
       				select 	a.id,c.companyName as sellerName,a.uuid, productName, productDescription, brandName, cast(price as float), categoriesAndSubcategories, productImages, variants, specifications, minimumOrderQuantity, bulkOrderDiscounts, 
       						featuresOfAProduct, availabilityStockStatus, sellerInformation, additionalAttributes, type, productGroupJson, groupId, parentTopnode, hierarchybranch,c.userid,c.latitude,c.longitude,
       						DENSE_RANK() over(PARTITION BY groupId ORDER BY price asc,sellerInformation asc) as DNSRNK,c.businessLogo,c.companyAddress, a.websiteURL
       				from tb_whl_rtl_product_dtl a 
       				
                      join tt_prodgrplist b on a.uuid = b.uuid
       				left join tb_whl_rtl_users_dtl c on c.userid = a.sellerInformation
                      )
       				select 	id,sellerName,uuid, productName, productDescription, brandName, price, categoriesAndSubcategories, productImages, variants, specifications, minimumOrderQuantity, bulkOrderDiscounts, 
       						featuresOfAProduct, availabilityStockStatus, sellerInformation, additionalAttributes, type, productGroupJson, groupId, parentTopnode, hierarchybranch,userid,latitude,longitude,DNSRNK ,businessLogo,
                               companyAddress, websiteURL
       				from cte_tt_grplist ;
            
                       select uuid,productName,productDescription,productImages,hierarchybranch,groupId  from tt_cte_grplist where ((DNSRNK = 1 and groupId is not null) or groupId is null);  
                       
                       drop temporary table if exists tt_cte_grplist_A;
                       create temporary table tt_cte_grplist_A as 
                       select * from tt_cte_grplist;
                       
        				select groupId,sellerName,productName,price,minimumOrderQuantity,sellerId,bulkOrderDiscounts, websiteURL
        				from (
        					select null as groupId, M.sellerName, M.productName, M.price, M.minimumOrderQuantity, M.userid as sellerId, M.bulkOrderDiscounts as bulkOrderDiscounts, websiteURL
        					from tt_cte_grplist M
        					where M.groupId is null
        
        				union all
        					select 	N.groupId,group_concat(Distinct N.sellerName order by N.price asc SEPARATOR '| ') as sellerName,
       							group_concat(DISTINCT (CASE WHEN N.DNSRNK = 1 THEN N.productName ELSE '' END)  ORDER BY N.price SEPARATOR '| ') as productName,
       							group_concat(N.price order by N.price asc SEPARATOR '| ') as price,
       							group_concat(Distinct N.minimumOrderQuantity order by N.price asc SEPARATOR '| ') as minimumOrderQuantity,
       							group_concat(Distinct N.userid order by N.price asc SEPARATOR '| ') as sellerId,
 								group_concat(Distinct N.bulkOrderDiscounts order by N.price asc SEPARATOR '| ') as bulkOrderDiscounts,
 								group_concat(Distinct N.websiteURL order by N.price asc separator '| ') as websiteURL
        					from tt_cte_grplist_A N
        					where N.groupId is not null
        					group by N.groupId
        				)ZZ;   
                                 
                       select * from tt_cte_grplist where (sellerInformation = p_sellerinfo or ifnull(p_sellerinfo,0) = 0); 
                       
                       select Distinct sellerName,sellerInformation,count(*)  as coountOfProduct 
                       from tt_cte_grplist
                       group by sellerName,sellerInformation;
                      
               
              End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_get_oauthclient_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_get_oauthclient_details`(
p_id int
)
Begin
	select * from tb_whl_rtl_oauthclient_details where (id = p_id or ifnull(p_id,0)=0) ;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_get_productCount` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_get_productCount`()
Begin
 	select count(*) as productCount from tb_whl_rtl_product_dtl;
    select count(*) as simCount from tb_whl_rtl_sim_only_product_dtl;
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_get_products_by_essentials` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_get_products_by_essentials`()
Begin
 
 		drop temporary table if exists tt_cte_essential_list ;
 		create temporary table  tt_cte_essential_list 
 		as     
 		with ctee (businessLogo, sellerName, id, uuid, productName, productDescription, brandName,  productImages, groupId,price,DNSRNK)
 		as 
 		(
 		select 	 
 				c.businessLogo, c.companyName as sellerName, a.id, a.uuid, productName, productDescription, brandName,  productImages, groupId,a.price,
 				row_number() over(PARTITION BY groupId ORDER BY price asc) as DNSRNK
 		from tb_whl_rtl_product_dtl a 
 		left join tb_whl_rtl_users_dtl c on c.userid = a.sellerInformation
 		join tb_whl_rtl_product_by_essentials_list d on a.categoriesAndSubcategories = d.catgId
 		where a.groupId is not null 
 		)
 		select businessLogo, sellerName, id, uuid, productName, productDescription, brandName,  productImages, groupId,price,DNSRNK
 		from ctee; 
 
 		select 	N.groupId,count(*) as prodcountbygrp, 
 				REPLACE(group_concat(DISTINCT (CASE WHEN N.DNSRNK = 1 THEN N.uuid ELSE '' END)  ORDER BY N.price),',','') as uuid,
 				group_concat(DISTINCT N.sellerName ORDER BY N.price) as sellerName,
 				REPLACE(group_concat(DISTINCT (CASE WHEN N.DNSRNK = 1 THEN N.productName ELSE '' END)  ORDER BY N.price),',','') as productName,
                group_concat(DISTINCT N.price ORDER BY N.price) as price,
 				
				
 				 REPLACE(group_concat(DISTINCT (CASE WHEN N.DNSRNK = 1 THEN N.productImages ELSE '' END)  ORDER BY N.price desc SEPARATOR '|'),'|','') as productImages
 		from tt_cte_essential_list  N
 		where N.groupId is not null
 		group by N.groupId
        having count(*)>1
        limit 100;
 		
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_get_product_category_quick_link_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_get_product_category_quick_link_info`(
  	p_CatgId varchar(100)
  )
Begin
          
  		declare p_catginfo text;
  		declare v_uuid text;
  
  		drop temporary table if exists tt_catglistinfo; create temporary table tt_catglistinfo (CatgId varchar(150) primary key);
  		
  		 
  		if p_CatgId = '2' then
  		   set p_catginfo = '4,5,6,10,15,12,9,16,8,13,11,14,22,23,20,26,19,25,24,18,21';
  			call Split(p_catginfo,',');
  			insert into tt_catglistinfo(CatgId) select items from tt_Split_temptable;
  		
  		ElseIF p_CatgId = '39' then
  			set p_catginfo = '40,41,42,43,44';
  			call Split(p_catginfo,',');
  			insert into tt_catglistinfo(CatgId) select items from tt_Split_temptable;
  		 
  		ElseIF p_CatgId = '28' then
  			set p_catginfo = '29,80,82';
  			call Split(p_catginfo,',');
  			insert into tt_catglistinfo(CatgId) select items from tt_Split_temptable;
  		  
  		ElseIF p_CatgId = '46' then
  			set p_catginfo = '51, 52, 50, 48';
  			call Split(p_catginfo,',');
  			insert into tt_catglistinfo(CatgId) select items from tt_Split_temptable;
  		 
  		ElseIF p_CatgId = '74' then
  			set p_catginfo = '74';
  			call Split(p_catginfo,',');
  			insert into tt_catglistinfo(CatgId) select items from tt_Split_temptable;
  		 
  		ElseIF p_CatgId = '54' then
  				set p_catginfo = '55, 56, 57, 58';
  				call Split(p_catginfo,',');
  				insert into tt_catglistinfo(CatgId) select items from tt_Split_temptable;
  		ElseIF p_CatgId = 'Grocery & Essentials' then
  				set p_catginfo = '29, 33, 61, 65, 68, 71, 73';
  				call Split(p_catginfo,',');
  				insert into tt_catglistinfo(CatgId) select items from tt_Split_temptable;
  			 
  		ElseIF p_CatgId = '62' then
  				set p_catginfo = '62';
  				call Split(p_catginfo,',');
  				insert into tt_catglistinfo(CatgId) select items from tt_Split_temptable;
  			 
  		ElseIF p_CatgId = '79' then
  				set p_catginfo = '81, 83';
  				call Split(p_catginfo,',');
  				insert into tt_catglistinfo(CatgId) select items from tt_Split_temptable;
  		End if;
                 
                         
  				drop temporary table if exists tt_uuidlistinfo; create temporary table tt_uuidlistinfo (id INT auto_increment, uuid varchar(150), primary key(id,uuid));
  
  				insert into tt_uuidlistinfo(uuid) 
  				select Distinct uuid from tb_whl_rtl_product_dtl where categoriesAndSubcategories in (select CatgId from tt_catglistinfo);
                         
  				drop temporary table if exists tt_grplist; 
  				create temporary table tt_grplist 
  				as 
  				select Distinct A.groupId from tb_whl_rtl_product_dtl A where A.uuid in (select Distinct B.uuid from tt_uuidlistinfo B);
  					   
  				drop temporary table if exists tt_grpuuidlist; 
  				create temporary table tt_grpuuidlist 
  				as 
  				select Distinct AA.uuid from tb_whl_rtl_product_dtl AA where AA.groupId in (select Distinct BB.groupId from tt_grplist BB);
  				   
  				drop temporary table if exists tt_prodgrplist;
  				create temporary table tt_prodgrplist as
  				select Distinct uuid from
  				(
  				select A.uuid from tt_uuidlistinfo A
  				union all
  				select B.uuid from tt_grpuuidlist B
  				)ZZ;
             
  				drop temporary table if exists tt_cte_finalgrplist;
  				create temporary table  tt_cte_finalgrplist 
  				as         
  				with cte_tt_grplist(id,sellerName,uuid, productName, productDescription, brandName, price, categoriesAndSubcategories, productImages, variants, specifications, minimumOrderQuantity, bulkOrderDiscounts, 
  						featuresOfAProduct, availabilityStockStatus, sellerInformation, additionalAttributes, type, productGroupJson, groupId, parentTopnode, hierarchybranch,userid,latitude,longitude,DNSRNK)
  				as
  				(
  					select 	a.id,c.companyName as sellerName,a.uuid, productName, productDescription, brandName, cast(price as float), categoriesAndSubcategories, productImages, variants, specifications, minimumOrderQuantity, bulkOrderDiscounts, 
  					featuresOfAProduct, availabilityStockStatus, sellerInformation, additionalAttributes, type, productGroupJson, groupId, parentTopnode, hierarchybranch,c.userid,c.latitude,c.longitude,
  					DENSE_RANK() over(PARTITION BY groupId ORDER BY price asc) as DNSRNK
  					from tb_whl_rtl_product_dtl a 
  					join tt_prodgrplist b on a.uuid = b.uuid
  					left join tb_whl_rtl_users_dtl c on c.userid = a.sellerInformation
  				)
  				select 	id,sellerName,uuid, productName, productDescription, brandName, price, categoriesAndSubcategories, productImages, variants, specifications, minimumOrderQuantity, bulkOrderDiscounts, 
  						featuresOfAProduct, availabilityStockStatus, sellerInformation, additionalAttributes, type, productGroupJson, groupId, parentTopnode, hierarchybranch,userid,latitude,longitude,DNSRNK 
  				from cte_tt_grplist ;
  
  				drop temporary table if exists tt_cte_finalgrplist_A;
  				create temporary table tt_cte_finalgrplist_A as 
  				select * from tt_cte_finalgrplist;
                              
  				drop temporary table if exists tt_finalresult;
  				create temporary table tt_finalresult as 
  				select groupId,prodcountbygrp,uuid,sellerName,productName,minprice,maxprice,productImages,hierarchybranch,minimumOrderQuantity,bulkOrderDiscounts
  				from (
  					select null as groupId,1 as prodcountbygrp,M.uuid,M.sellerName,M.productName,M.price as minprice,M.price as maxprice,M.productImages,M.hierarchybranch,M.minimumOrderQuantity,M.bulkOrderDiscounts
  					from tt_cte_finalgrplist M
  					where M.groupId is null
  
  				union all
  					select 	N.groupId,count(*) as prodcountbygrp,
  							REPLACE(group_concat(DISTINCT (CASE WHEN N.DNSRNK = 1 THEN N.uuid ELSE '' END)  ORDER BY N.price),',','') as uuid,
  							REPLACE(group_concat(DISTINCT (CASE WHEN N.DNSRNK = 1 THEN N.sellerName ELSE '' END)  ORDER BY N.price),',','') as sellerName,
  							REPLACE(group_concat(DISTINCT (CASE WHEN N.DNSRNK = 1 THEN N.productName ELSE '' END)  ORDER BY N.price),',','') as productName,
  							min(N.price) as minprice,
  							max(N.price) as maxprice,
  							REPLACE(group_concat(DISTINCT (CASE WHEN N.DNSRNK = 1 THEN N.productImages ELSE '' END)  ORDER BY N.price desc SEPARATOR '|'),'|','') as productImages,
  							REPLACE(group_concat(DISTINCT (CASE WHEN N.DNSRNK = 1 THEN N.hierarchybranch ELSE '' END)  ORDER BY N.price desc),',','') as hierarchybranch,
  							REPLACE(group_concat(DISTINCT (CASE WHEN N.DNSRNK = 1 THEN N.minimumOrderQuantity ELSE '' END)  ORDER BY N.price desc),',','') as minimumOrderQuantity,
  							N.bulkOrderDiscounts
  					from tt_cte_finalgrplist_A N
  					where N.groupId is not null
  					group by N.groupId,N.bulkOrderDiscounts
  				)ZZ;  
                            
  			  select C.id,A.* from tt_finalresult A join tt_uuidlistinfo B on A.uuid = B.uuid
               join tb_whl_rtl_product_dtl C on C.uuid = A.uuid
  			  order by B.id;
                            
                 
         
          End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_get_product_category_relevant_category_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_get_product_category_relevant_category_info`(
  p_categoryId int
  )
Begin
  
  
     
     SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
 		drop temporary table if exists tt_rel_prod;
   		create temporary table tt_rel_prod as
 		with cte as (
 			select Distinct A.categoriesAndSubcategories
 							,A.uuid
                             ,A.productName
                             ,A.productImages
                             ,LTRIM(A.price) as price
                             ,A.groupId,A.hierarchybranch
             ,row_number() over(partition by A.categoriesAndSubcategories order by A.price asc) as rnk
 			from tb_whl_rtl_product_dtl A 
 			join tb_whl_rtl_product_category_relevant_category_dtl B on find_in_set(A.categoriesAndSubcategories, replace(relevantCategoryId,' ',''))  
 			where B.categoryId = p_categoryId
             )
             select * from cte where rnk<=10;
  	SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
      
   	SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
 		select  a.uuid, 
 				a.productName, 
                 a.productImages, 
                 a.groupId,
                 a.hierarchybranch,
 				case when a.groupId is null then a.price else (select min(b.price) 
 																from tb_whl_rtl_product_dtl b 
 																where b.groupId = a.groupId) end as price,
 				case when a.groupId is null then 1 else (select count(Distinct sellerInformation) 
 														from tb_whl_rtl_product_dtl b 
                                                         where b.groupId = a.groupId) end as seller_count
 		from tt_rel_prod a 
        order by price;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

  End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_get_product_detailed_info_byId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_get_product_detailed_info_byId`(
        p_id varchar(1000),
        p_countrycode varchar(10)
        )
begin
        
        	call Split(p_id,',');
            
            drop temporary table if exists tt_prodlist;
            create temporary table tt_prodlist
            (
            id int auto_increment primary key,
            uuid varchar(150) 
            );
            
            insert into tt_prodlist(uuid)
            select items from tt_Split_temptable;
        	
            select c.businessLogo,c.companyName as sellerName,c.companyAddress,a.*,concat(a.parentTopnode,' > ',a.categoriesAndSubcategories) as taxoId
            from tb_whl_rtl_product_dtl a join tt_prodlist b on a.uuid = b.uuid
            join tb_whl_rtl_users_dtl c on c.userid = a.sellerInformation
            order by b.id;
            
            if found_rows() > 0 then
   			if p_countrycode <> 'IN' then
   				insert into tb_whl_rtl_searched_viewed_product_dtl(uuid) 
   				select uuid from tt_prodlist; 
               end if;
     		end if;
        End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_get_product_field_config` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_get_product_field_config`()
begin
	SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED ;
	select * from tb_whl_rtl_product_field_config order by 1 asc;
	SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ; 
   end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_get_product_list_based_on_categoryid` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_get_product_list_based_on_categoryid`(p_catgId int)
Begin
select * from tb_whl_rtl_product_dtl where categoriesAndSubcategories = p_catgId;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_get_product_list_based_on_groupid` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_get_product_list_based_on_groupid`(
    p_groupid varchar(1000)
    )
Begin
    
    	select B.companyName as sellerName, B.companyAddress,B.businessLogo,A.* from tb_whl_rtl_product_dtl A 
       join tb_whl_rtl_users_dtl B on B.userid = A.sellerInformation 
       where A.groupId = p_groupid 
       order by cast(A.price as float) asc;
    
    End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_get_product_price_alert_list` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_get_product_price_alert_list`(
 p_userid int
 )
Begin
 	select b.productImages,b.productName as product,a.* from tb_whl_rtl_product_threshold_limit a 
    join tb_whl_rtl_product_dtl b on a.uuid = b.uuid
    where a.userid = p_userid;
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_get_product_price_trend_history` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_get_product_price_trend_history`(
p_uuid varchar(36)
)
Begin
	declare v_minPrice float;
    declare v_maxPrice float;

	select min(price) as minPrice,max(price) as maxPrice
    into v_minPrice, v_maxPrice
    from tb_whl_rtl_product_dtl_transaction_log
    where uuid = p_uuid;
    
    select v_minPrice as minPrice, v_maxPrice as maxPrice;
    
    select logdate,price
    from tb_whl_rtl_product_dtl_transaction_log
    where uuid = p_uuid
    order by createdate desc;
    
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_get_product_threshold_limit` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_get_product_threshold_limit`(
p_uuid varchar(40),
	p_userid int
	)
Begin

	drop temporary table if exists tt_emp;
    create temporary table tt_emp 
	with cte as
    (
		select b.uuid, b.logdate,price, currPrice,
		min(logdate) over(partition by uuid order by logdate asc) as startingPricedt,
		DENSE_RANK() over(partition by uuid order by logdate asc) as startingPrice,
		thresholdPrice
		from tb_whl_rtl_product_threshold_limit a 
		join tb_whl_rtl_product_dtl_transaction_log b on a.uuid  = b.uuid
		where b.uuid = p_uuid and a.userid = p_userid 
    )
    select * from cte where startingPrice = 1;
    
    select uuid, logdate, price, startingPricedt, startingPrice, thresholdPrice 
    from tt_emp
    where currPrice<thresholdPrice;
    
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_get_services_all_providers_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_get_services_all_providers_info`()
Begin
	select Distinct userid,businessLogo from tb_whl_rtl_users_dtl where servicetype = 2;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_get_sim_only_products_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_get_sim_only_products_info`(
   	p_contractLength int,
   	p_monthlyCost varchar(20),
   	p_data varchar(20),
   	p_callMinutes varchar(50),
   	p_sellerId varchar(50)
   )
Begin
      
      	call Split(p_sellerId,',');
          
          drop temporary table if exists tt_sellerlistinfo; create temporary table tt_sellerlistinfo (id INT auto_increment primary key, sellerId int);
          
          insert into tt_sellerlistinfo(sellerId) select items from tt_Split_temptable;
          
       drop temporary table if exists tt_grp_info;
       create temporary table tt_grp_info as 
      	with ctea 
       as 
          (
      		select 	groupId,a.contractLength, min(a.monthlyCost) as monthlyCost,
   				group_concat(DISTINCT uuid ORDER BY a.sellerInformation SEPARATOR ', ') as uuid,
   				
                group_concat(DISTINCT b.companyName ORDER BY a.sellerInformation SEPARATOR ', ') as sellerName,
   				group_concat(DISTINCT sellerInformation ORDER BY a.sellerInformation desc SEPARATOR ', ') as SellerID,
   				group_concat(DISTINCT businessLogo ORDER BY a.sellerInformation desc SEPARATOR ', ') as businessLogo,
   				group_concat(DISTINCT websiteURL ORDER BY a.sellerInformation desc SEPARATOR ', ') as websiteURL,
  				count(Distinct a.sellerInformation) as SellerIDcnt 
      		from tb_whl_rtl_sim_only_product_dtl a
      		join tb_whl_rtl_users_dtl b on a.sellerInformation = b.userid and b.servicetype = 2
      		where groupId is not null and 
             (a.sellerInformation in (select si.sellerId from tt_sellerlistinfo si) or ifnull(p_sellerId,'')='')
              and (a.contractLength = p_contractLength or ifnull(p_contractLength,0)=0)
      		and (a.monthlyCost = p_monthlyCost or ifnull(p_monthlyCost,'')='')
      		and (a.callMinutes = p_callMinutes or ifnull(p_callMinutes,'')='')
      		group by groupId,a.contractLength
          )
          select a.*,IF(SellerIDcnt >4,SellerIDcnt-4,0) as hiddenprovider 
          from ctea a
          order by groupId,a.contractLength asc, a.monthlyCost asc;
          
   		select groupId,contractLength,monthlyCost,uuid,sellerName,SellerID,businessLogo,websiteURL,SellerIDcnt ,hiddenprovider
           from
           (
   			select groupId,contractLength,monthlyCost,uuid,sellerName,SellerID,businessLogo,websiteURL,SellerIDcnt ,hiddenprovider
   			from tt_grp_info
               
   			union all
               
   			select groupId,contractLength,monthlyCost,uuid,b.companyName as sellerName, sellerInformation as SellerID,businessLogo,websiteURL,0 SellerIDcnt ,0 hiddenprovider
   			from tb_whl_rtl_sim_only_product_dtl a
   			join tb_whl_rtl_users_dtl b on a.sellerInformation = b.userid and b.servicetype = 2
   			where groupId is null
           )ZZ
           order by contractLength asc, monthlyCost asc;
          
      End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_get_sim_only_products_info_by_groupId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_get_sim_only_products_info_by_groupId`(
  p_groupId text,
  p_uuid text
  )
Begin
  
  	call Split(p_groupId,',');
      
      drop temporary table if exists tt_grouplistinfo; create temporary table tt_grouplistinfo (id INT auto_increment primary key, groupId varchar(50));
      
      insert into tt_grouplistinfo(groupId) select items from tt_Split_temptable;
      
      call Split(p_uuid,',');
      
      drop temporary table if exists tt_uuidlistinfo; create temporary table tt_uuidlistinfo (id INT auto_increment primary key, uuid varchar(50));
      
      insert into tt_uuidlistinfo(uuid) select items from tt_Split_temptable;
      
 	select a.*,b.businessLogo from tb_whl_rtl_sim_only_product_dtl a 
 	join tb_whl_rtl_users_dtl b on a.sellerInformation = b.userid and b.servicetype = 2
 	where (a.groupId in (select sl.groupId from tt_grouplistinfo sl) or ifnull(p_groupId,'')='')
 	and (a.uuid in (select sl.uuid from tt_uuidlistinfo sl) or ifnull(p_uuid,'')='');
      
  End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_get_sim_only_products_info_by_uuid_search` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_get_sim_only_products_info_by_uuid_search`(
     	p_uuid text,
     	p_contractLength varchar(50),
     	p_monthlyCost varchar(20),
     	p_data varchar(20),
     	p_callMinutes varchar(50),
     	p_sellerId varchar(50)
     )
Begin
              
				call Split(p_uuid,','); drop temporary table if exists tt_uuidlistinfo; create temporary table tt_uuidlistinfo (id INT auto_increment, uuid varchar(150), primary key(id,uuid));
				insert into tt_uuidlistinfo(uuid) select items from tt_Split_temptable;

				call Split(p_sellerId,','); drop temporary table if exists tt_sellerlistinfo; create temporary table tt_sellerlistinfo (id INT auto_increment primary key, sellerId int);
				insert into tt_sellerlistinfo(sellerId) select items from tt_Split_temptable;

				call Split(p_contractLength,','); drop temporary table if exists tt_contractLengthlistinfo; create temporary table tt_contractLengthlistinfo (id INT auto_increment primary key, contractLength int);
				insert into tt_contractLengthlistinfo(contractLength) select items from tt_Split_temptable;
             
				    
                    select a.*,b.companyName as sellerName, sellerInformation as SellerID,businessLogo,0 SellerIDcnt ,0 hiddenprovider
          			from tb_whl_rtl_sim_only_product_dtl a
          			join tb_whl_rtl_users_dtl b on a.sellerInformation = b.userid and b.servicetype = 2
                    join tt_uuidlistinfo pg on a.uuid = pg.uuid
          			
					where (a.sellerInformation in (select si.sellerId from tt_sellerlistinfo si) or ifnull(p_sellerId,'')='')
        			and (a.contractLength in (select cl.contractLength from tt_contractLengthlistinfo cl) or ifnull(p_contractLength,'')='')
        			and (a.monthlyCost = p_monthlyCost or ifnull(p_monthlyCost,'')='')
        			and (a.callMinutes = p_callMinutes or ifnull(p_callMinutes,'')='') 
                    order by pg.id;
                    
                    
              End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_get_sim_only_products_info_by_uuid_search_old_logic` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_get_sim_only_products_info_by_uuid_search_old_logic`(
     	p_uuid text,
     	p_contractLength varchar(50),
     	p_monthlyCost varchar(20),
     	p_data varchar(20),
     	p_callMinutes varchar(50),
     	p_sellerId varchar(50)
     )
Begin
              
				call Split(p_uuid,','); drop temporary table if exists tt_uuidlistinfo; create temporary table tt_uuidlistinfo (id INT auto_increment, uuid varchar(150), primary key(id,uuid));
				insert into tt_uuidlistinfo(uuid) select items from tt_Split_temptable;

				call Split(p_sellerId,','); drop temporary table if exists tt_sellerlistinfo; create temporary table tt_sellerlistinfo (id INT auto_increment primary key, sellerId int);
				insert into tt_sellerlistinfo(sellerId) select items from tt_Split_temptable;

				call Split(p_contractLength,','); drop temporary table if exists tt_contractLengthlistinfo; create temporary table tt_contractLengthlistinfo (id INT auto_increment primary key, contractLength int);
				insert into tt_contractLengthlistinfo(contractLength) select items from tt_Split_temptable;
             
				drop temporary table if exists tt_grplist; 
             	create temporary table tt_grplist 
             	as 
             	select Distinct A.groupId from tb_whl_rtl_sim_only_product_dtl A where A.uuid in (select Distinct B.uuid from tt_uuidlistinfo B);
             
				drop temporary table if exists tt_grpuuidlist; 
             	create temporary table tt_grpuuidlist 
             	as 
             	select Distinct AA.uuid from tb_whl_rtl_sim_only_product_dtl AA where AA.groupId in (select Distinct BB.groupId from tt_grplist BB);
                
             	 drop temporary table if exists tt_prodgrplist;
             	create temporary table tt_prodgrplist as
             	 select Distinct uuid from
             	 (
             		select A.uuid from tt_uuidlistinfo A
             		union all
             		select B.uuid from tt_grpuuidlist B
             	 )ZZ;
                  
          	drop temporary table if exists tt_grp_info;
              create temporary table tt_grp_info as 
             	with ctea 
              as 
                  (
        			select 	groupId,a.contractLength, min(a.monthlyCost) as monthlyCost,
        					group_concat(DISTINCT uuid ORDER BY a.sellerInformation desc SEPARATOR ', ') as uuid,
        					
                            group_concat(DISTINCT b.companyName ORDER BY a.sellerInformation SEPARATOR ', ') as sellerName,
        					group_concat(DISTINCT sellerInformation ORDER BY a.sellerInformation desc SEPARATOR ', ') as SellerID,
        					group_concat(DISTINCT businessLogo ORDER BY a.sellerInformation desc SEPARATOR ', ') as businessLogo,
        					group_concat(DISTINCT websiteURL ORDER BY a.sellerInformation desc SEPARATOR ', ') as websiteURL,
        					count(Distinct a.sellerInformation) as SellerIDcnt
        			from tb_whl_rtl_sim_only_product_dtl a
        			join tb_whl_rtl_users_dtl b on a.sellerInformation = b.userid and b.servicetype = 2
        			where a.groupId is not null and a.uuid in (select pg.uuid from tt_prodgrplist pg)
        			and (a.sellerInformation in (select si.sellerId from tt_sellerlistinfo si) or ifnull(p_sellerId,'')='')
        			and (a.contractLength in (select cl.contractLength from tt_contractLengthlistinfo cl) or ifnull(p_contractLength,'')='')
        			and (a.monthlyCost = p_monthlyCost or ifnull(p_monthlyCost,'')='')
        			and (a.callMinutes = p_callMinutes or ifnull(p_callMinutes,'')='')
        			group by groupId,a.contractLength 
                  )
                  select a.*,IF(SellerIDcnt >3,SellerIDcnt-3,0) as hiddenprovider 
                  from ctea a 
                  order by groupId,a.contractLength asc, a.monthlyCost asc;
                  
                  
          			select groupId,contractLength,monthlyCost,uuid,sellerName,SellerID,businessLogo,websiteURL,SellerIDcnt, hiddenprovider 
          			from tt_grp_info
                    order by contractLength asc, monthlyCost asc;
                    
                    select a.*,b.companyName as sellerName, sellerInformation as SellerID,businessLogo,0 SellerIDcnt ,0 hiddenprovider
                    
          			from tb_whl_rtl_sim_only_product_dtl a
          			join tb_whl_rtl_users_dtl b on a.sellerInformation = b.userid and b.servicetype = 2
          			where a.uuid in (select Distinct pg.uuid from tt_uuidlistinfo pg)
                      
                   and (a.sellerInformation in (select si.sellerId from tt_sellerlistinfo si) or ifnull(p_sellerId,'')='')
        			and (a.contractLength in (select cl.contractLength from tt_contractLengthlistinfo cl) or ifnull(p_contractLength,'')='')
        			and (a.monthlyCost = p_monthlyCost or ifnull(p_monthlyCost,'')='')
        			and (a.callMinutes = p_callMinutes or ifnull(p_callMinutes,'')='') 
                    order by a.contractLength asc, cast(a.monthlyCost as float) asc, cast(a.`data` as SIGNED integer) desc;
                    
                    
          		
                  
              End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_get_subcategory_by_categoryid` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_get_subcategory_by_categoryid`(
   p_catgId int
  
   )
sp_return:Begin
   	
       declare v_errcode int;
       declare v_errmsg varchar(50);
       declare p_catgType int;
       
       set p_catgType = 1;
   
   		sp_exit : begin
			if exists(select 1 from tb_whl_rtl_category_master_list where parentCatgId = p_catgId and ifnull(catgType,1) = p_catgType limit 1) then
				select catgId,catgName,parentCatgId,catgType,iconId from tb_whl_rtl_category_master_list where (parentCatgId = p_catgId or ifnull(p_catgId,0)=0) and ifnull(catgType,1)  = p_catgType;
				leave sp_return;
			end if;
			   
			if not exists(select 1 from tb_whl_rtl_category_master_list where parentCatgId = p_catgId limit 1) then
				if not exists(select 1 from tb_whl_rtl_product_dtl where categoriesAndSubcategories = p_catgId limit 1) then
					set v_errcode = -1;
					set v_errmsg = 'No result found';
					leave sp_exit;
				End if;
		
				select * from tb_whl_rtl_product_dtl where categoriesAndSubcategories = p_catgId;
				   leave sp_return;
			End if;
        end;  
        
        select v_errcode as errcode, v_errmsg as errmsg;
   End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_Get_sub_category_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_Get_sub_category_info`(
p_catgId int,
p_subCatgId int
)
begin
	select * from tb_whl_rtl_sub_category_dtl 
    where (fkCatgId = p_catgId or ifnull(p_catgId, 0)=0)
    and (subCatgId = p_subCatgId or ifnull(p_subCatgId,0)=0);
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_Get_users_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_Get_users_dtl`(
     p_userid int
     )
Begin
 	select concat(b.firstname,' ',b.lastname) as approved1_by ,
 			concat(c.firstname,' ',c.lastname) as approved2_by ,
 			a.* , d.isocode as countryisocode,d.prefix as countryprefix
 	from tb_whl_rtl_users_dtl a 
 	left join tb_whl_rtl_crm_admin_user b on a.approved1_By = b.id
 	left join tb_whl_rtl_crm_admin_user c on a.approved2_By = c.id
     LEFT join tb_whl_rtl_country_code d on d.id = a.countryCodeId
 	where (a.userid = p_userid or ifnull(p_userid,0)=0)
 	order by a.userid desc ;
     End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_get_users_process_flow_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_get_users_process_flow_info`(
p_from varchar(10),
p_to varchar(20)
)
Begin
	select * from tb_whl_rtl_users_process_flow_dtl 
    where ((cast(createdate as date) >= p_from and cast(createdate as date)<=p_to) or (ifnull(p_from,'')='') and (ifnull(p_to,'')=''));
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_get_user_card_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_get_user_card_details`(
p_userid int
)
Begin
	select * from whl_rtl_user_card_details where userid = p_userid;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_insertlist_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_insertlist_info`(
 p_listId int,
 p_userId int,
 p_listName varchar(50)
 )
Begin
 
	declare v_errcode int default -1;
	declare v_errmsg varchar(50) default 'Not found';
	declare v_listId int;
    
	select listId into v_listId from tb_whl_rtl_list_master_info where listId = p_listId;
    
    sp_exit:begin
    if v_listId is not null then
			
		if exists(select 1 from tb_whl_rtl_list_master_info where userId = p_userId and listName = p_listName and listId <> p_listId) then
			set v_errcode = -1;
			set v_errmsg = 'list name already exists';
			leave sp_exit;
		End if; 
		
		update tb_whl_rtl_list_master_info A
 			set A.listName = ifnull(p_listName,A.listName)
		where A.listId = p_listId and userId = p_userId ;
     
			set v_errcode = 0;
			set v_errmsg = 'Updated';
	Else
		insert into tb_whl_rtl_list_master_info(userId, listName, status, createdate)
         values(p_userId,p_listName,1,now());
         
         set v_listId = last_insert_id();
         
         set v_errcode = 0;
         set v_errmsg = 'Inserted';
         
    End if;

     End;
     select v_errcode as errcode, v_errmsg as errmsg,ifnull(v_listId,0) as listId;
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_inserttransaction_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_inserttransaction_info`(
 p_tran_id int ,
 p_user_id int,
 p_ad_id int,
 p_price float,
 p_vat float,
 p_transaction_id varchar(50), 
 p_cardholder_name varchar(150), 
 p_address text,
 p_card_last_number varchar(10),
 p_cardtype varchar(50), 
 p_transaction_Description varchar(150), 
 p_transaction_errcode varchar(150), 
 p_transaction_status varchar(20)
 )
Begin
 	declare v_errcode int default -1;
     declare v_errmsg varchar(50) default 'Not found';
     declare v_tranId int;
     
     select tran_id into v_tranId from tb_whl_rtl_crm_transaction_details where tran_id = p_tran_id;
     
     if v_tranId is null then
 		insert into tb_whl_rtl_crm_transaction_details(user_id,ad_id,price,vat,transaction_id,cardholder_name,address,card_last_number,cardtype,transaction_Description,
         transaction_errcode,transaction_status,transation_date)
         values(p_user_id,p_ad_id,p_price,p_vat, p_transaction_id,p_cardholder_name,p_address,p_card_last_number,p_cardtype, p_transaction_Description, p_transaction_errcode,
         p_transaction_status,now());
         
         set v_tranId = last_insert_id();
         
         set v_errcode = 0;
         set v_errmsg = 'Inserted';
         
     else
     
 		update tb_whl_rtl_crm_transaction_details A
 			set A.user_id = ifnull(p_user_id,A.user_id),
 				A.ad_id = ifnull(p_ad_id,A.ad_id),
 				A.price = ifnull(p_price,A.price),
 				A.vat = ifnull(p_vat,A.vat),
 				A.transaction_id = ifnull(p_transaction_id,A.transaction_id),
 				A.cardholder_name = ifnull(p_cardholder_name,A.cardholder_name),
                 A.address = ifnull(p_address,A.address),
                 A.card_last_number = ifnull(p_card_last_number,A.card_last_number),
                 A.cardtype = ifnull(p_cardtype,A.cardtype),
                 A.transaction_Description = ifnull(p_transaction_Description,A.transaction_Description),
                 A.transaction_errcode = ifnull(p_transaction_errcode,A.transaction_errcode),
                 A.transaction_status = ifnull(p_transaction_status,A.transaction_status),
                 A.transation_date = now(),
                 A.updatedate = now()
         where A.tran_id = p_tran_id ;
     
 		set v_errcode = 0;
         set v_errmsg = 'Updated';
     
     End if;
     
     select v_errcode as errcode, v_errmsg as errmsg,ifnull(v_tranId,0) as tranId;
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_insertupdate_connector_token` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_insertupdate_connector_token`( 
	p_userId 				INT,  
	p_connector_name 		VARCHAR(100),
	p_token 				TEXT,
	p_syncStatus			TINYint,    
	p_contactSyncDetails	JSON,
	P_syncTime				BIGINT,
	p_contactSyncType       VARCHAR(100),
	p_isConnected			TINYINT
	)
Begin   
         	DECLARE v_errcode 	INT DEFAULT 1;
         	DECLARE v_errmsg 	VARCHAR(50) DEFAULT 'Failure';
      	    DECLARE v_idcol		INT;
             
			SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED ;
				SELECT 	idcol INTO v_idcol 
				FROM 	tb_whl_rtl_connector_token_info
				WHERE 	userId = p_userId 
				AND     isConnected = 1 LIMIT 1;
			SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;    
   
         	IF v_idcol IS NULL
             THEN		
         		INSERT INTO tb_whl_rtl_connector_token_info(userId,connector_name,token,contactSyncDetails,createAt,syncStatus,contactSyncType,isConnected)
				VALUES(p_userId,p_connector_name,p_token,p_contactSyncDetails,current_timestamp,p_syncStatus,p_contactSyncType,p_isConnected);
         
         		SET v_errcode = 0;
         		SET v_errmsg = 'Inserted';
         	ELSE
         		UPDATE 	tb_whl_rtl_connector_token_info
         		SET 	token 				= IFNULL(p_token,token),
         				syncStatus 			= IFNULL(p_syncStatus,syncStatus),
   					    syncTime			= IFNULL(p_syncTime,syncTime),
         				contactSyncDetails	= IFNULL(p_contactSyncDetails,contactSyncDetails),
   					    contactSyncType     = IFNULL(p_contactSyncType,contactSyncType),
     					isConnected			= IFNULL(p_isConnected,isConnected),
         				updateAt 			= current_timestamp
         		WHERE 	idcol  = v_idcol ;
                 
         		SET v_errcode = 0;
         		SET v_errmsg = 'Updated';
         	END IF;
            	
            	SELECT v_errcode as errcode,v_errmsg as errmsg;   
         END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_insert_ad_clicks_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_insert_ad_clicks_dtl`(
p_adId int
)
Begin
	declare v_errcode int default -1;
    declare v_errmsg varchar(25) default 'Failure';
    
	insert into tb_whl_rtl_ad_clicks_dtl(adId)
    values(p_adId);
    
    if row_count()>0 then
		set v_errcode = 0;
        set v_errmsg = 'Inserted';
    End if;
    
    select v_errcode as errcode, v_errmsg as errmsg;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_insert_ad_click_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_insert_ad_click_info`(
p_adid int,
p_ipaddress varchar(20)
)
Begin

		declare v_errcode int;
        declare v_errmsg varchar(20);
        
        insert into whl_rtl_ad_click_dtl(adid,ipaddress) 
        values(p_adid,p_ipaddress);
        
        
        if row_count()>0 then
			set v_errcode = 0;
            set v_errmsg = 'Inserted';
        End if;
        
		select v_errcode as errcode, v_errmsg as errmsg;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_insert_Ad_manager_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_insert_Ad_manager_info`(
       p_adId int,
       p_userId int,
       p_adType int,
       p_name varchar(200),
       p_adCategory varchar(20),
       p_adLoctoAppear varchar(20),
       p_format varchar(20),
       p_typeOfPromotion varchar(20),
       p_uploadBanner text,
       p_link varchar(250),
       p_displayTimeFrame int,
       p_adDisplayHour int,
       p_adDisplayPerDay int,
       p_bannerPosition int,
       p_status int,
       p_freeOrPaid int,
       p_paidAmount float,
       p_vat_amount float,
       p_payment_status int,
       p_fromdate datetime,
       p_todate datetime
       )
begin
       
    		declare v_errcode int;
    		declare v_errmsg varchar(100);
    		declare v_adId int;
    
    		select adId into v_adId from tb_whl_rtl_Ad_manager where userId = p_userId and adId = p_adId limit 1;
       	
           if v_adId is null then
    		insert into tb_whl_rtl_Ad_manager(adId, userId, adType,name, adCategory, adLoctoAppear, format, typeOfPromotion, uploadBanner, link, displayTimeFrame, adDisplayHour, adDisplayPerDay, bannerPosition, status, createDate, freeOrPaid, paidAmount, vat_amount, payment_status, fromdate,todate)
    		values(p_adId, p_userId, p_adType, p_name, p_adCategory, p_adLoctoAppear, p_format, p_typeOfPromotion, p_uploadBanner, p_link, p_displayTimeFrame, p_adDisplayHour, p_adDisplayPerDay, p_bannerPosition, p_status, now(), p_freeOrPaid, p_paidAmount, p_vat_amount, p_payment_status, p_fromdate, p_todate);
    
    		set v_adId = LAST_INSERT_ID();
    
    		if row_count() > 0 then
    			set v_errcode = 0;
    			set v_errmsg = 'Inserted';
    		End if;
               
           Else
           
      		update tb_whl_rtl_Ad_manager A
      		set A.name = ifnull(p_name,A.name)
      			, A.adType = ifnull(p_adType,A.adType)
      			, A.adCategory = ifnull(p_adCategory,A.adCategory)
      			, A.adLoctoAppear = ifnull(p_adLoctoAppear,A.adLoctoAppear)
      			, A.format = ifnull(p_format,A.format)
      			, A.typeOfPromotion = ifnull(p_typeOfPromotion,A.typeOfPromotion)
      			, A.uploadBanner = ifnull(p_uploadBanner,A.uploadBanner)
      			, A.link = ifnull(p_link,A.link)
      			, A.displayTimeFrame = ifnull(p_displayTimeFrame,A.displayTimeFrame)
      			, A.adDisplayHour = ifnull(p_adDisplayHour,A.adDisplayHour)
      			, A.adDisplayPerDay = ifnull(p_adDisplayPerDay,A.adDisplayPerDay)
      			, A.bannerPosition = ifnull(p_bannerPosition,A.bannerPosition)
      			, A.status = ifnull(p_status,A.status)
      			, A.updated = now()
      			, A.freeOrPaid = ifnull(p_freeOrPaid,A.freeOrPaid)
      			, A.paidAmount = ifnull(p_paidAmount,A.paidAmount)
  				, A.vat_amount = ifnull(p_vat_amount,A.vat_amount)
  				, A.payment_status = ifnull(p_payment_status,A.payment_status)   
                  , A.fromdate = ifnull(p_fromdate,A.fromdate)
                  , A.todate = ifnull(p_todate,A.todate)
      		where A.adId = p_adId;
      
       			set v_errcode = 0;
    			set v_errmsg = 'Updated';
       		
           End if;
           
       	select v_errcode as errcode, v_errmsg as errmsg,ifnull(v_adId,0) as AdId;
       end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_Insert_oauthclient_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_Insert_oauthclient_details`(
 p_id int,
 p_name varchar(150),
 p_oauthGrandType int,
 p_clientId int,
 p_clientSecret varchar(100),
 p_authoriseURL varchar(250),
 p_tokenURL varchar(250),
 p_redirectURL varchar(250),
 p_scopes varchar(100)
 )
Begin
 	declare v_errcode int;
     declare v_errmsg varchar(50);
     declare v_id int;
     
     select id into v_id from tb_whl_rtl_oauthclient_details where id = p_id;
     
     if v_id is null then
 		insert into tb_whl_rtl_oauthclient_details(name, oauthGrandType, clientId, clientSecret, authoriseURL, tokenURL, redirectURL, scopes, createDate)
         values(p_name, p_oauthGrandType, p_clientId, p_clientSecret, p_authoriseURL, p_tokenURL, p_redirectURL, p_scopes, now());
         
         set v_id = last_insert_id();
         
         set v_errcode = 0;
         set v_errmsg = 'Inserted';
     else
 		update tb_whl_rtl_oauthclient_details A
         SET A.name = ifnull(p_name,A.name)
 			,A.oauthGrandType = ifnull(p_oauthGrandType,A.oauthGrandType)
 			,A.clientId = ifnull(p_clientId,A.clientId)
 			,A.clientSecret = ifnull(p_clientSecret,A.clientSecret)
 			,A.authoriseURL = ifnull(p_authoriseURL,A.authoriseURL)
 			,A.tokenURL = ifnull(p_tokenURL,A.tokenURL)
 			,A.redirectURL = ifnull(p_redirectURL,A.redirectURL)
 			,A.scopes = ifnull(p_scopes,A.scopes)
 			,A.updatedDate = now()
         where A.id =p_id;
         
         set v_errcode = 0;
         set v_errmsg = 'Updated';
         
     End if;
     
 
     select v_errcode as errcode, v_errmsg as errmsg,ifnull(v_id,0) as id;
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_insert_products_transaction_log` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_insert_products_transaction_log`(
p_uuid varchar(40),
p_price float,
p_logdate date
)
Begin

	declare v_errcode int;
    declare v_errmsg varchar(20);
    
	insert into tb_whl_rtl_product_dtl_transaction_log(uuid, price, logdate) 
    values(p_uuid, p_price, p_logdate);
    
    if row_count()>0 then
		set v_errcode = 0;
        set v_errmsg = 'Inserted';
    end if;
    
    select v_errcode as errcode, v_errmsg as errmsg;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_insert_product_category_relevant_category_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_insert_product_category_relevant_category_info`(
p_categoryId int,
p_relevantCategoryId varchar(200)
)
Begin
	declare v_errcode int default -1;
    declare v_errmsg varchar(50) default 'Failure';
    declare v_id int;
    
    select id into v_id from tb_whl_rtl_product_category_relevant_category_dtl where categoryId = p_categoryId;
    
    if v_id is null then
		insert into tb_whl_rtl_product_category_relevant_category_dtl(categoryId,relevantCategoryId)
        values(p_categoryId, p_relevantCategoryId);
        
        if row_count() > 0 then
			set v_errcode = 0;
            set v_errmsg = 'Inserted';
        End if;
    Else
		update tb_whl_rtl_product_category_relevant_category_dtl A
			set A.relevantCategoryId = ifnull(p_relevantCategoryId,A.relevantCategoryId)
        where A.categoryId = p_categoryId;
        
			set v_errcode = 0;
            set v_errmsg = 'Updated';
        
    End if;
    
    select v_errcode as errcode, v_errmsg as errmsg;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_insert_product_field_config` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_insert_product_field_config`(
      p_fieldName varchar(150)
  )
BEGIN
      DECLARE v_errcode INT DEFAULT -1;
      DECLARE v_errmsg VARCHAR(100) DEFAULT 'failure';
      
      INSERT INTO tb_whl_rtl_product_field_config ( fieldName)
 	  VALUES ( p_fieldName);
          
          SET v_errcode = 0;
          SET v_errmsg = 'Inserted successfully';
 
 
      SELECT v_errcode AS errcode, v_errmsg AS errmsg;
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_Insert_product_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_Insert_product_info`(
          p_productName varchar(200),
          p_productDescription text,
          p_brandName varchar(100),
          p_price varchar(20),
          p_categoriesAndSubcategories int,
          p_productImages text,
          p_variants varchar(100),
          p_specifications text,
          p_minimumOrderQuantity varchar(100),
          p_bulkOrderDiscounts varchar(10),
          p_featuresOfAProduct varchar(500),
          p_availabilityStockStatus varchar(50),
          p_sellerInformation varchar(100),
          p_additionalAttributes varchar(150),
          p_type int,
          p_uuid varchar(60),
          p_groupId varchar(500),
          p_parentTopnode int,
          p_hierarchybranch varchar(200),
          p_websiteURL TEXT,
          p_perMetricPrice varchar(20),
          p_AlternativeIds varchar(500)
          )
Begin
          	declare v_errcode int;
              declare v_errmsg varchar(50);
              declare v_id int;
              
           
              insert into tb_whl_rtl_product_dtl(uuid, productName, productDescription, brandName, price, categoriesAndSubcategories, productImages, variants, specifications, minimumOrderQuantity, bulkOrderDiscounts, 
       				featuresOfAProduct, availabilityStockStatus, sellerInformation, additionalAttributes, type, groupId, parentTopnode, hierarchybranch , websiteURL, perMetricPrice, AlternativeIds)
              values(p_uuid, p_productName, p_productDescription, p_brandName, p_price, p_categoriesAndSubcategories, p_productImages, p_variants, p_specifications, p_minimumOrderQuantity, p_bulkOrderDiscounts, 
       				p_featuresOfAProduct, p_availabilityStockStatus, p_sellerInformation, p_additionalAttributes, p_type, p_groupId, p_parentTopnode, p_hierarchybranch, p_websiteURL, p_perMetricPrice, p_AlternativeIds);
                      
      			set v_id = last_insert_id();
              
              if row_count() > 0 then
          		set v_errcode = 0;
                  set v_errmsg = 'Inserted';
              End if;
              
              select v_errcode as errcode, v_errmsg as errmsg, ifnull(v_id,0) as id;
          
          End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_Insert_product_search_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_Insert_product_search_info`(
  p_productName varchar(200)
  )
sp_return:Begin
 
	declare v_cnt int;
    declare v_tcnt int;
    declare v_productName varchar(150);

    set v_cnt = 1;
 
	call Split(replace(p_productName,' ',','),',');
    
    drop temporary table if exists tt_prodsrch; create temporary table tt_prodsrch (id int auto_increment primary key, prodsrch varchar(100));
    insert into tt_prodsrch(prodsrch) select Items from tt_Split_temptable;
    
    drop temporary table if exists temp_tb_whl_rtl_product_dtl;
    CREATE TEMPORARY TABLE temp_tb_whl_rtl_product_dtl (
	   id int NOT NULL AUTO_INCREMENT,
	   uuid varchar(40) DEFAULT NULL,
	   productName varchar(200) DEFAULT NULL,
	   productDescription text,
	   brandName varchar(100) DEFAULT NULL,
	   price varchar(10) DEFAULT NULL,
	   categoriesAndSubcategories int DEFAULT NULL,
	   productImages text,
	   variants varchar(20) DEFAULT NULL,
	   specifications varchar(20) DEFAULT NULL,
	   minimumOrderQuantity varchar(100) DEFAULT NULL,
	   bulkOrderDiscounts varchar(10) DEFAULT NULL,
	   featuresOfAProduct varchar(500) DEFAULT NULL,
	   availabilityStockStatus varchar(50) DEFAULT NULL,
	   sellerInformation varchar(100) DEFAULT NULL,
	   additionalAttributes varchar(150) DEFAULT NULL,
	   type int DEFAULT NULL,
	   productGroupJson json DEFAULT NULL,
	   groupId varchar(50) DEFAULT NULL,
	   parentTopnode int DEFAULT NULL,
	   hierarchybranch varchar(200) DEFAULT NULL,
	   PRIMARY KEY (id)
 ) ;
    

	select count(*) into v_tcnt from tt_prodsrch;
    
    while v_cnt<=v_tcnt do
    
		select prodsrch into v_productName from tt_prodsrch where id = v_cnt;
        
			insert into temp_tb_whl_rtl_product_dtl(uuid, productName, productDescription, brandName, price, categoriesAndSubcategories, productImages, variants, specifications, minimumOrderQuantity, 
								bulkOrderDiscounts, featuresOfAProduct, availabilityStockStatus, sellerInformation, additionalAttributes, type, productGroupJson, groupId, parentTopnode, hierarchybranch)
			select uuid, productName, productDescription, brandName, price, categoriesAndSubcategories, productImages, variants, specifications, minimumOrderQuantity, 
								bulkOrderDiscounts, featuresOfAProduct, availabilityStockStatus, sellerInformation, additionalAttributes, type, productGroupJson, groupId, parentTopnode, hierarchybranch
			from tb_whl_rtl_product_dtl 
			where productName like concat('%',v_productName,'%');
        
		set v_cnt = v_cnt + 1;
    end while;
	
		select * from temp_tb_whl_rtl_product_dtl;

     
     
     insert into tb_whl_rtl_searched_viewed_product_dtl(searchedproductName)
     select prodsrch from tt_prodsrch; 
 
  End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_insert_product_to_list_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_insert_product_to_list_info`(
   p_id int,
   p_listId int,
   p_uuid text
   )
Begin
   	declare v_errcode int default -1;
       declare v_errmsg varchar(50) default 'Not found';
       declare v_listId int;
       declare v_listName varchar(50);
       
       select listName into v_listName from tb_whl_rtl_list_master_info where listId = p_listId limit 1;
   		
   		call Split(p_uuid,',');
   
   		drop temporary table if exists tt_prodlist1;
   		create temporary table tt_prodlist1
   		(
   		uuid varchar(150) primary key
   		);
   
   		insert into tt_prodlist1(uuid)
   		select items from tt_Split_temptable;
           
   		insert into tb_whl_rtl_product_list_info(listId,uuid)
   		select Distinct p_listId,uuid from tt_prodlist1 b ;
  
 		set v_listId = last_insert_id();
         
         if row_count() > 0 then
 			set v_errcode = 0;
             set v_errmsg ='Inserted';
         End if;
   
       select v_errcode as errcode, v_errmsg as errmsg,ifnull(v_listId,0) as prodlistId,ifnull(v_listName,'') as listName;
   End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_Insert_Update_Admin_User` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_Insert_Update_Admin_User`(
 p_id int,
 p_username varchar(60),
 p_password varchar(50),
 p_status int,
 p_email varchar(100),
 p_firstname varchar(150),
 p_lastname varchar(150),
 p_mobileno varchar(20),
 p_dept_id int
 )
Begin

	declare v_errcode int default -1;
	declare v_errmsg varchar(50) default '';
	declare v_id int;
       
     sp_exit :Begin
     
     select id into v_id from tb_whl_rtl_crm_admin_user where id = p_id;
     
	if v_id is null then
    
 		insert into tb_whl_rtl_crm_admin_user( username, password, status, email, firstname, lastname, mobileno, dept_id, createDate)
         values( p_username, p_password, p_status, p_email, p_firstname, p_lastname, p_mobileno, p_dept_id, now());
         
         set p_id = LAST_INSERT_ID();
     
 			set v_errcode  = 0;
             set v_errmsg  = 'Inserted';
 
     else
     
		if exists(select 1 from tb_whl_rtl_crm_admin_user where email = p_email and id <> p_id limit 1) then
			set v_errcode  = -1;
             set v_errmsg  = 'Email already exists';
             leave sp_exit;
		End if;
     
     
 		update tb_whl_rtl_crm_admin_user a 
         set a.username = ifnull(p_username,a.username),
 			a.password = ifnull(p_password,a.password),
             a.status = ifnull(p_status,a.status),
             a.firstname = ifnull(p_firstname,a.firstname),
             a.lastname = ifnull(p_lastname,a.lastname),
             a.mobileno = ifnull(p_mobileno,a.mobileno),
             a.dept_id = ifnull(p_dept_id,a.dept_id),
             a.email = ifnull(p_email,a.email)
 		where a.id = p_id;
         
         set v_errcode  = 0;
 		set v_errmsg  = 'Updated';
         
     End if;
     
     end;
     
 		select v_errcode as errcode, v_errmsg as errmsg,ifnull(p_id,0) as id ;
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_Insert_Update_category_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_Insert_Update_category_info`(
  p_catgId int,
  p_catgName varchar(150),
  p_catgDesc varchar(500),
  p_catgStatus int,
  p_catgImgURL varchar(500),
  p_catgPosition int
  )
Begin
  
 		declare v_errcode int default -1;
 		declare v_errmsg varchar(150) default '';
 		declare v_catgId int;
 		
 		select catgId into v_catgId from tb_whl_rtl_category_dtl where catgName = p_catgName limit 1;
 		 
 		if v_catgId is null then
 			insert into tb_whl_rtl_category_dtl( catgName, catgDesc, catgStatus, catgImgURL, catgPosition, createDate)
 			values(p_catgName, p_catgDesc, p_catgStatus, p_catgImgURL, p_catgPosition, now());
             
 			set p_catgId = LAST_INSERT_ID();
 
 			set v_errcode = 0;
 			set v_errmsg = 'Inserted';
 	
 		else
 			update tb_whl_rtl_category_dtl a 
 				set a.catgName = ifnull(p_catgName, a.catgName),
 				 a.catgDesc = ifnull(p_catgDesc, a.catgDesc),
 				 a.catgStatus = ifnull(p_catgStatus, a.catgStatus),
                 a.catgPosition = ifnull(p_catgPosition,a.catgPosition)
 			where a.catgId = p_catgId;
 			 
 			 set v_errcode = 0;
 			 set v_errmsg = 'Updated';
 			 
 		End if;
  
  	select v_errcode as errcode, v_errmsg as errmsg, ifnull(p_catgId,0) as catgId;
  End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_insert_update_chat_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_insert_update_chat_dtl`(
p_chatId int,
p_userId int,
p_title varchar(200),
p_chatJson JSON
)
Begin
	declare v_errcode int default -1;
    declare v_errmsg varchar(50) default 'Not found';
    declare v_chatId int;
    
    sp_exit :begin
    if p_title is null or ifnull(p_userId,0)=0 then
		set v_errcode = -1;
		set v_errmsg = 'Title/userId should be mandatory';
		leave sp_exit;
	End if;
    
    select chatId into v_chatId from tb_whl_rtl_chat_master_dtl where chatId = p_chatId limit 1;
    
		if v_chatId is null then
			insert into tb_whl_rtl_chat_master_dtl(userId, title, chatJson,updateddate)
			values(p_userId, p_title, p_chatJson,current_timestamp());
			
			set v_chatId = last_insert_id();
			
			if row_count()>0 then
				set v_errcode = 0;
				set v_errmsg = 'Inserted';
			End if;
		Else
			if not exists(select 1 from tb_whl_rtl_chat_master_dtl where chatId = p_chatId limit 1) then
				set v_errcode = -1;
				set v_errmsg = 'Record not found';
				leave sp_exit;
			End if;
			
				update tb_whl_rtl_chat_master_dtl
				set chatJson =  ifnull(p_chatJson,chatJson),
					
					updateddate = current_timestamp()
				where chatId = p_chatId;

			set v_errcode = 0;
			set v_errmsg = 'Updated'; 
			
		End if;
        
    End;
    select v_errcode as errcode, v_errmsg as errmsg, ifnull(v_chatId,0) as chatId;
	
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_insert_update_product_threshold_limit` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_insert_update_product_threshold_limit`(
p_userid int,
p_uuid varchar(40),
p_startingPrice float,
p_currPrice float,
p_thresholdPrice float
)
sp_return:Begin
	declare v_errcode int;
    declare v_errmsg varchar(50);
    
    if ifnull(p_userid,'')='' or p_userid = 0 then
      select -1 as errcode, 'Incorrect UserId' as errmsg;
      leave sp_return;
    End if;
    
    if exists(select 1 from tb_whl_rtl_product_threshold_limit where uuid = p_uuid and userid = p_userid limit 1) then

		update tb_whl_rtl_product_threshold_limit a 
		set startingPrice = ifnull(p_startingPrice,startingPrice),
			currPrice = ifnull(p_currPrice,currPrice),
			thresholdPrice = ifnull(p_thresholdPrice,thresholdPrice),
            UpdatedDate = now()
		where uuid = p_uuid and userid = p_userid;
        
        if found_rows()>0 then
			set v_errcode = 0;
			set v_errmsg = 'threshold Updated';
        End if;
	Else
		insert into tb_whl_rtl_product_threshold_limit(uuid, userid, startingPrice, currPrice, thresholdPrice, createdDate)
        values(p_uuid, p_userid, p_startingPrice, p_currPrice, p_thresholdPrice, now());
        
        if row_count()>0 then
			set v_errcode = 0;
			set v_errmsg = 'threshold created';
        End if;
    End if;
    
    select v_errcode as errcode, v_errmsg as errmsg;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_Insert_Update_sub_category_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_Insert_Update_sub_category_info`(
 p_subCatgId int,
 p_fkCatgId int,
 p_subCatgName varchar(150),
 p_subCatgDesc varchar(500),
 p_subCatgStatus int,
 p_subCatgImgURL varchar(500),
 p_subCatgPosition int
 )
Begin
 	
 	declare v_errcode int default -1;
     declare v_errmsg varchar(150) default '';
     declare v_subCatgId int;
     
 	select catgId into v_subCatgId from tb_whl_rtl_category_dtl where subCatgName = p_subCatgName and fkCatgId = p_fkCatgId limit 1;
 
 	if v_subCatgId is null then
 		insert into tb_whl_rtl_sub_category_dtl( fkCatgId, subCatgName, subCatgDesc, subCatgStatus, subCatgImgURL, subCatgPosition, createDate)
         values(p_fkCatgId, p_subCatgName, p_subCatgDesc,p_subCatgStatus,p_subCatgImgURL, p_subCatgPosition, now());
         
         set p_subCatgId = LAST_INSERT_ID();
         
         set v_errcode = 0;
         set v_errmsg = 'Inserted';
         
 	Else
 		update tb_whl_rtl_sub_category_dtl a 
 		set a.fkCatgId = ifnull(p_fkCatgId,a.fkCatgId),
             a.subCatgName = ifnull(p_subCatgName,a.subCatgName),
             a.subCatgDesc = ifnull(p_subCatgDesc,a.subCatgDesc),
             a.subCatgStatus = ifnull(p_subCatgImgURL,a.subCatgStatus),
             a.subCatgPosition = ifnull(p_subCatgPosition,a.subCatgPosition)
         where subCatgId = p_subCatgId;
         
          set v_errcode = 0;
         set v_errmsg = 'Updated';
         
     End if;
 
 	select v_errcode as errcode, v_errmsg as errmsg, ifnull(p_subCatgId,0) as p_subCatgId;
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_Insert_Update_Users` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_Insert_Update_Users`(
   	 p_userid int,
   	 p_userType int,
   	 p_firstName varchar(100),
   	 p_lastName varchar(100),
   	 p_emailAddress varchar(250),
   	 p_status int,
   	 p_companyName varchar(250),
   	 p_businessRegistrationNumber varchar(50),
   	 p_VATNumber varchar(50),
   	 p_country varchar(50),
   	 p_postalCode  varchar(20),
   	 p_companyAddress JSON,
   	 p_source varchar(20),
   	 p_ipAddress varchar(100),
   	 p_contactNumber varchar(40),
   	 p_website varchar(500),
   	 p_businessLogo varchar(500),
   	 p_productSize varchar(20),
   	 p_category varchar(500),
   	 p_primaryCustomers varchar(100),
   	 p_minOrderValue float,
   	 p_delivery  varchar(50),
   	 p_proofOfIdentity  varchar(500),
   	 p_secondaryCategoryGoods json,
   	 p_industryType varchar(100),
   	 p_paymentType int, 
   	 p_paymentAmount float,
   	 p_plan_id int,
   	 p_signIn_type int,
   	 p_password varchar(50),
   	 p_token text,
   	 p_servicetype int,
   	 p_latitude varchar(200),
   	 p_longitude varchar(200),
      p_countryCodeId int
   )
Begin
            			declare v_errcode int default -1;
            			declare v_errmsg varchar(50) default 'insert/update fail';
            			declare v_userid int;
                        
            	sp_exit :Begin
            			 
                       if exists(select 1 from tb_whl_rtl_users_dtl where businessRegistrationNumber = p_businessRegistrationNumber limit 1)
          				then
          					set v_errcode = -1;
          					set v_errmsg = 'businessRegistrationNumber already exists';
          					leave sp_exit;
          				end if;
                        
          		   
      				if exists(select 1 from tb_whl_rtl_users_dtl where contactNumber like concat('%',p_contactNumber,'%') limit 1)
            			then
            				set v_errcode = -1;
            				set v_errmsg = 'contactNumber already exists';
            				leave sp_exit;
            			end if;
            
             
                     	select userid into v_userid  from tb_whl_rtl_users_dtl where emailAddress = p_emailAddress and userid=p_userid limit 1;
           
                      
                      if v_userid is not null then
             				update tb_whl_rtl_users_dtl a 
            				set  	a.userType = ifnull(p_userType,a.userType),
            						a.firstName = ifnull(p_firstName,a.firstName),
            						a.lastName = ifnull(p_lastName,a.lastName),
            						a.status = ifnull(p_status,a.status),
            						a.companyName = ifnull(p_companyName,a.companyName),
            						a.businessRegistrationNumber = ifnull(p_businessRegistrationNumber,a.businessRegistrationNumber),
            						a.VATNumber = null, 
            						a.country = ifnull(p_country,a.country),
            						a.postalCode = ifnull(p_postalCode,a.postalCode),
            						a.companyAddress = ifnull(p_companyAddress,a.companyAddress),
            						a.source = ifnull(p_source,a.source),
            						a.ipAddress = ifnull(p_ipAddress,a.ipAddress),
            						a.contactNumber = ifnull(p_contactNumber,a.contactNumber),
            						a.website = ifnull(p_website,a.website),
            						a.businessLogo = ifnull(p_businessLogo,a.businessLogo),
            						a.productSize = ifnull(p_productSize,a.productSize),
            						a.category = ifnull(p_category,a.category),
            						a.primaryCustomers = ifnull(p_primaryCustomers,a.primaryCustomers),
            						a.minOrderValue = ifnull(p_minOrderValue,a.minOrderValue),
            						a.delivery = ifnull(p_delivery,a.delivery),
            						a.proofOfIdentity  = ifnull(p_proofOfIdentity,a.proofOfIdentity),
            						a.secondaryCategoryGoods = ifnull(p_secondaryCategoryGoods,a.secondaryCategoryGoods),
            						a.industryType = ifnull(p_industryType,a.industryType),
            						a.paymentType = ifnull(p_paymentType,a.paymentType),
            						a.paymentAmount = ifnull(p_paymentAmount,a.paymentAmount),
   								a.plan_enddate = case when p_status = 1 then DATE_ADD(now(), INTERVAL 30 DAY) else null end,
   								a.signIn_type = ifnull(p_signIn_type,a.signIn_type),
   								a.password = ifnull(p_password,password),
   								a.token = ifnull(p_token,token),
                                   a.latitude = ifnull(p_latitude,latitude),
                                   a.longitude = ifnull(p_longitude,longitude),
                                   a.countryCodeId = ifnull(p_countryCodeId,countryCodeId)
             				where userid = p_userid;
                             
                             set v_errcode  = 0;
                     		set v_errmsg  = 'Updated';
                          
                         else
                    		
                    		IF exists(select 1 from tb_whl_rtl_users_dtl where emailAddress = p_emailAddress and userid <> p_userid limit 1) then
 							 set v_errcode = -1;
                  			 set v_errmsg = 'emailId already exists';
                  			 leave sp_exit;
 						ElseIf ifnull(p_userid,0) = 0 then
 							IF exists(select 1 from tb_whl_rtl_users_dtl where emailAddress = p_emailAddress limit 1) then
 							set v_errcode = -1;
                  			 set v_errmsg = 'emailId already exists';
                  			 leave sp_exit;
 							End if;
                  		end if;
                     		
 					insert into tb_whl_rtl_users_dtl( userType, firstName, lastName, emailAddress,   companyName, businessRegistrationNumber, VATNumber, country, postalCode, companyAddress, source, ipAddress, createDate, contactNumber, website, businessLogo, productSize, category, primaryCustomers, minOrderValue, delivery, proofOfIdentity, secondaryCategoryGoods, industryType, paymentType, paymentAmount,plan_id, plan_startdate, plan_enddate,signIn_type, password, token, servicetype, status, latitude, longitude, countryCodeId)
 					values( p_userType, p_firstName, p_lastName, p_emailAddress, p_companyName, p_businessRegistrationNumber, null, p_country, p_postalCode, p_companyAddress, p_source, p_ipAddress, now(), p_contactNumber, p_website, p_businessLogo, p_productSize, p_category, p_primaryCustomers, p_minOrderValue, p_delivery, p_proofOfIdentity, p_secondaryCategoryGoods, p_industryType, p_paymentType, p_paymentAmount, p_plan_id, now(), null,p_signIn_type, p_password, p_token, p_servicetype, p_status,  p_latitude, p_longitude, p_countryCodeId);
                             
                             set v_userid = LAST_INSERT_ID();
                     
                     			set v_errcode  = 0;
                   			set v_errmsg  = 'Inserted';
                             
                         End if;
                         
                         end;
                         
                     		select v_errcode as errcode, v_errmsg as errmsg,ifnull(v_userid,0) as userid ;
                     End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_Insert_users_process_flow_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_Insert_users_process_flow_info`(
p_name varchar(200),
p_email varchar(150),
p_contactNumber varchar(40),
p_ipaddress varchar(30),
p_source varchar(20),
p_userType int,
p_processflow varchar(100)
)
Begin
   	declare v_errcode int;
	declare v_errmsg varchar(50);
    
	insert into tb_whl_rtl_users_process_flow_dtl(name, email, contactNumber, ipaddress, source, userType, processflow)
	values(p_name, p_email, p_contactNumber, p_ipaddress, p_source, p_userType, p_processflow);

   if row_count() > 0 then
	set v_errcode = 0;
	   set v_errmsg = 'Inserted';
   End if;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_insert_user_card_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_insert_user_card_details`(
p_userid int,
p_nameoncard varchar(150),
p_cardnumber varchar(20),
p_expirymonth int,
p_expiryyear int,
p_cvv char(3),
p_Address text, 
p_city  varchar(150),
p_country varchar(150),
p_pincode varchar(10)
)
Begin	
	declare v_errcode int;
    declare v_errmsg varchar(50);
    declare v_id int ;
    
    select id into v_id from whl_rtl_user_card_details where userid = p_userid;

    if v_id is null then
		insert into whl_rtl_user_card_details(userid, nameoncard, cardnumber, expirymonth, expiryyear, cvv, Address, city, country, pincode, createDate)
        values(p_userid,p_nameoncard ,p_cardnumber,p_expirymonth,p_expiryyear,p_cvv,p_Address,p_city ,p_country ,p_pincode);
    else
		update whl_rtl_user_card_details a
        set a.nameoncard = ifnull(p_nameoncard,a.nameoncard),
        a.cardnumber = ifnull(p_cardnumber,a.cardnumber),
        a.expirymonth = ifnull(p_expirymonth,a.expirymonth),
        a.expiryyear = ifnull(p_expiryyear,a.expiryyear),
        a.cvv = ifnull(p_cvv,a.cvv),
        a.Address = ifnull(p_Address,a.Address),
        a.city = ifnull(p_city,a.city),
        a.country = ifnull(p_country,a.country),
        a.pincode = ifnull(p_pincode,a.pincode),
        a.updatedAt = now()
        where a.userid = p_userid;
    End if;
    
    select v_errcode as errcode, v_errmsg as errmsg;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_most_searched_viewed_product_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_most_searched_viewed_product_dtl`()
Begin
     
    	SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        
     		drop temporary table if exists ttt;
     		create temporary table ttt as
     		select b.uuid,b.productName,b.productImages,b.price, count(*) as searched_count, b.groupId,b.hierarchybranch, b.perMetricPrice
     		from 
            tb_whl_rtl_product_dtl b 
     		where b.uuid is not null 
            and b.categoriesAndSubcategories in (62, 29, 78, 58, 55, 74, 60, 68, 87, 85, 33, 51, 82, 34, 61)
     		group by b.uuid,b.productName,b.productImages,b.price ,b.groupId,b.hierarchybranch,b.perMetricPrice
     		order by count(*) desc ;
    	SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
        
     	SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   		select  a.uuid, a.productName, a.productImages, a.searched_count, a.groupId,a.hierarchybranch,
   		case when a.groupId is null then a.price else (select min(b.price) from tb_whl_rtl_product_dtl b where b.groupId = a.groupId) end as minprice,
           case when a.groupId is null then a.price else (select max(b.price) from tb_whl_rtl_product_dtl b where b.groupId = a.groupId) end as maxprice,
   		case when a.groupId is null then 1 else (select count(Distinct sellerInformation) from tb_whl_rtl_product_dtl b where b.groupId = a.groupId) end as seller_count, a.perMetricPrice
   		from ttt a order by a.searched_count desc limit 50;
        
     SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
       End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_remove_seller_product_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_remove_seller_product_details`(
p_sellerId text
)
Begin
	
		declare v_errcode int default -1;
		declare v_errmsg varchar(50) default 'Not found';
            
    		call Split(p_sellerId,',');
                
    		drop temporary table if exists tt_removesellerlist;
    		create temporary table tt_removesellerlist
    		(
    		sellerId varchar(40) primary key
    		);
            
            insert into tt_removesellerlist(sellerId)
    		select items from tt_Split_temptable;
            
    		delete A from tb_whl_rtl_product_dtl A join tt_removesellerlist B on A.sellerInformation = B.sellerId;
          
    		if row_Count()>0 then
    			set v_errcode = 0;
                set v_errmsg = 'Deleted';
            End if;
            
            select v_errcode as errcode, v_errmsg as errmsg;

End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_reset_user_login_password` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_reset_user_login_password`(
      p_login_user_id VARCHAR(50), 
      p_login_password  VARCHAR(50),   
      login_source VARCHAR(30),   
      login_device_id VARCHAR(100),   
      login_ipaddress VARCHAR(30)
      )
Begin
      
  		declare v_errcode int default -1;
  		declare v_errmsg varchar(50) default '';
  		declare v_loginusername varchar(50);
        declare v_name varchar(250);
  
  		update tb_whl_rtl_users_dtl
  		set password = p_login_password, updatedAt = now()
  		where emailAddress = p_login_user_id; 
          
  		set v_errcode = 0;
  		set v_errmsg = 'Password changed successfully';
  
  		set v_loginusername = p_login_user_id;
       
  		if p_login_user_id REGEXP '^[0-9]+$' = 0 then
 			select emailAddress into v_loginusername from tb_whl_rtl_users_dtl where emailAddress = p_login_user_id;
  		End if;
    
          insert into tb_whl_rtl_user_login_log( login_user_id, login_password, errcode, errmsg, create_date, login_source, login_device_id, login_ipaddress)
          values(v_loginusername,p_login_password,v_errcode,v_errmsg,now(),login_source,login_device_id,login_ipaddress);
          
          select concat(firstName,' ',lastName) into v_name from tb_whl_rtl_users_dtl where emailAddress = v_loginusername;
          
      	select v_errcode as errcode, v_errmsg as errmsg,v_name as name; 
      End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_Update_location_to_Users` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_Update_location_to_Users`(
  p_userid int,
  p_latitude	varchar(20),
  p_longitude	varchar(20),
  p_businessLogo varchar(500)
  )
Begin
  	declare v_errcode int default -1;
  	declare v_errmsg varchar(50) default 'insert/update fail';
      
      update tb_whl_rtl_users_dtl 
      set  latitude = ifnull(p_latitude,latitude), 
 		 longitude = ifnull(p_longitude,longitude), 
         businessLogo = ifnull(p_businessLogo,businessLogo) where userid = p_userid;
      
      if row_count() > 0 then
  		set v_errcode = 0;
          set v_errmsg = 'Updated';
      End if;
  
  	select v_errcode as errcode,  v_errmsg as errmsg;
  End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_Update_product_groupid_based_on_uuid` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_Update_product_groupid_based_on_uuid`(
p_uuid varchar(50),
p_groupId varchar(500)
)
Begin
	
    declare v_errcode int default -1;
    declare v_errmsg varchar(50) default 'not found';
    
    update tb_whl_rtl_product_dtl set groupId = p_groupId where uuid = p_uuid;
    
    if row_count()> 0 then
		set v_errcode = 0;
        set v_errmsg = 'Updated';
    End if;
    
select v_errcode as errcode, v_errmsg as errmsg;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_Update_product_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_Update_product_info`(
 	p_id int,
 	p_productName varchar(200),
 	p_productDescription text,
 	p_brandName varchar(100),
 	p_price varchar(10),
 	p_productImages text,
 	p_minimumOrderQuantity varchar(100)
 )
Begin
 		declare v_errcode int default -1;
 		declare v_errmsg varchar(50) default 'Not found';
         declare v_id int;
         
         select id into v_id from tb_whl_rtl_product_dtl where id = p_id;
         
         if v_id is not null then
 			update tb_whl_rtl_product_dtl A
             set A.productName = ifnull(p_productName ,A.productName)
 				,A.productDescription = ifnull(p_productDescription ,A.productDescription)
 				,A.brandName  = ifnull(p_brandName ,A.brandName)
 				,A.price  = ifnull(p_price ,A.price)
 				,A.productImages  = ifnull(p_productImages ,A.productImages)
 				,A.minimumOrderQuantity  = ifnull(p_minimumOrderQuantity ,A.minimumOrderQuantity)
             where A.id = p_id;
         
 			set v_errcode = 0;
             set v_errmsg = 'Updated';
         
         end if;
         
         select v_errcode as errcode, v_errmsg as errmsg;
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_Update_product_Json_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_Update_product_Json_info`(
p_uuid varchar(40),
p_productGroupJson json
)
Begin
	declare v_errcode int;
    declare v_errmsg varchar(50);

	update tb_whl_rtl_product_dtl a
    set a.productGroupJson = ifnull(p_productGroupJson,a.productGroupJson)
    where a.uuid = p_uuid;
    
      if row_count() > 0 then
 		set v_errcode = 0;
         set v_errmsg = 'Updated';
     End if;
     
     select v_errcode as errcode, v_errmsg as errmsg;

End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_update_user_approval_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_update_user_approval_info`(
  	p_userid int,
  	p_approvedBy int,
  	p_status int,
  	p_password varchar(60),
  	p_paymentType int, 
  	p_paymentAmount float,
     p_vat_amount float
    )
Begin
    
    	declare v_errcode int;
    	declare v_errmsg varchar(50);
    	declare v_id int;
    
    	select userid into v_id from tb_whl_rtl_users_dtl where userid = p_userid ;
  
  		sp_exit : Begin
  		if v_id is null then
  			set v_errcode = -1 ;
  			set v_errmsg = 'Not found';
  			leave sp_exit;
  		End if;
        
  		update tb_whl_rtl_users_dtl a 
		set a.userid 		= ifnull(p_userid,a.userid), 
			a.approvedBy 	= ifnull(p_approvedBy,a.approvedBy),
			a.status 		= ifnull(p_status, a.status),
			a.password 		= ifnull(p_password,password),
			approvedDate 	= now(),
			a.paymentType 	= ifnull(p_paymentType,a.paymentType),
			a.paymentAmount = ifnull(p_paymentAmount,a.paymentAmount),
			a.vat_amount	= ifnull(p_vat_amount,a.vat_amount),
            a.plan_enddate	 = case when p_status = 1 then DATE_ADD(now(), INTERVAL 30 DAY) else null end 
  		where a.userid = p_userid ;
        
    		if row_count()> 0 then
    			set v_errcode = 0 ;
    			set v_errmsg = 'Updated';
    		end if;
    	End;
    
    	select v_errcode as errcode, v_errmsg as errmsg;
    End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_update_user_email_alert_notification` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_update_user_email_alert_notification`(
p_userid int,
p_status tinyint
)
BEgin

	declare v_errcode int;
    declare v_errmsg varchar(50);
    
    sp_exit:begin
    if not exists(select 1 from tb_whl_rtl_users_dtl where userid = p_userid limit 1) then
		set v_errcode = -1;
        set v_errmsg = 'User Not found';
        leave sp_exit;
    End if;
    
		update tb_whl_rtl_users_dtl a 
		set emailalert = ifnull(p_status,emailalert)
		where userid = p_userid ;
        
        if row_count()>0 then
			set v_errcode = 0;
			set v_errmsg = 'Alert Updated';
        End if;
    
    End;
    select v_errcode as errcode, v_errmsg as errmsg;
	

End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_user_approval_process` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_user_approval_process`(
 p_userId int,
 p_type int,
 p_approved_By int,
 p_approved_status int
 )
Begin
 	declare v_errcode int default -1;
 	declare v_errmsg varchar(50) default 'Not found';
     
     sp_exit : Begin
     if not exists(select 1 from tb_whl_rtl_users_dtl where userid = p_userId limit 1) then
 		set v_errcode = -1;
 		set v_errmsg = 'Not found';
         leave sp_exit;
     End if;
     
 
     if p_type = 1 then
 		update tb_whl_rtl_users_dtl a
 			set a.approved1_By = ifnull(p_approved_By,a.approved1_By),
 				a.approved1_status = ifnull(p_approved_status,a.approved1_status),
                 a.approved1_at = current_timestamp()
  		where a.userid = p_userId ;
     Else
 		update tb_whl_rtl_users_dtl a
 			set a.approved2_By = ifnull(p_approved_By,a.approved2_By),
 				a.approved2_status = ifnull(p_approved_status,a.approved2_status),
                 a.approved2_at = current_timestamp()
  		where a.userid = p_userId ;
     End if;
 
   		set v_errcode = 0;
 		set v_errmsg = 'Updated';
 	End;
   	select v_errcode as errcode, v_errmsg as errmsg;
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_user_change_password_request_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_user_change_password_request_info`(
      p_login_user_id VARCHAR(50), 
      p_current_password  VARCHAR(50),
      p_new_password  VARCHAR(50),
      login_source VARCHAR(30),   
      login_device_id VARCHAR(100),   
      login_ipaddress VARCHAR(30)  
   )
Begin
   
		declare v_errcode int default -1;
		declare v_errmsg varchar(50) default '';
		declare v_loginPassword varchar(50);
		declare v_loginusername varchar(50);
       
       sp_exit:begin
              
       select password into v_loginPassword from tb_whl_rtl_users_dtl where emailAddress = p_login_user_id limit 1;
       
  		if STRCMP(BINARY p_current_password, BINARY v_loginPassword) in (1,-1) then
   			set v_errcode = -2;
               set v_errmsg = 'Insert Current password entered';
               leave sp_exit;
           end if;
           
   		if STRCMP(BINARY p_current_password,BINARY p_new_password)=0 then
   			set v_errcode = -3;
               set v_errmsg = 'Current password is matching with new password';
               leave sp_exit;
           end if;
   		
   		update tb_whl_rtl_users_dtl
   		set password = BINARY p_new_password, updatedAt = now()
   		where emailAddress = p_login_user_id; 
       
   		set v_errcode = 0;
   		set v_errmsg = 'Password changed successfully';
         
          set v_loginusername = p_login_user_id;
     
 		if p_login_user_id REGEXP '^[0-9]+$' = 1 then
 			select emailAddress into v_loginusername from tb_whl_rtl_users_dtl where emailAddress = p_login_user_id;
 		End if;
          
          insert into tb_caretake_user_login_log( login_user_id, login_password, errcode, errmsg, create_date, login_source, login_device_id, login_ipaddress)
          values(v_loginusername,p_new_password,v_errcode,v_errmsg,now(),login_source,login_device_id,login_ipaddress);

       end;
   		select v_errcode as errcode, v_errmsg as errmsg;
   End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_user_login_validation` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_user_login_validation`(
     	p_email VARCHAR(60)
     	,p_password text
         ,p_signIn_type int
  )
sp_return: Begin
  
          declare v_found int;
          
  			if not exists(select 1 from tb_whl_rtl_users_dtl a where emailAddress = p_email limit 1)then
  				select -1 as errcode, 'User not found' as errmsg;
  				leave sp_return;
  			end if;
  		 
 			if p_signIn_type = 1 then
 				if exists(select 1 from tb_whl_rtl_users_dtl a where emailAddress = p_email and BINARY password <> p_password) then
 					select -1 as errcode, 'Incorrect Password' as errmsg;
 					leave sp_return;
 				end if;
             End if;
             
  			if  p_signIn_type = 1 then
 				select 1 into v_found from tb_whl_rtl_users_dtl where emailAddress = p_email and BINARY password = p_password and status = 1 ;
 				
 				if v_found is null then
 					select -1 as errcode, 'Inactive / wrong Password' as errmsg;
 					leave sp_return;
 				else
 					select 0 as errcode, 'Login successfully' as errmsg,a.*, d.isocode as countryisocode,d.prefix as countryprefix
					from tb_whl_rtl_users_dtl a   
                    LEFT join tb_whl_rtl_country_code d on d.id = a.countryCodeId
					where a.emailAddress = p_email and BINARY a.password = p_password and status = 1 ; 
 				end if;
 			else
 				select 1 into v_found from tb_whl_rtl_users_dtl where emailAddress = p_email and BINARY token = p_password and status = 1 ;
 				
 				if v_found is null then
 					select -1 as errcode, 'Inactive / wrong Password' as errmsg;
 					leave sp_return;
 				else
 					select 0 as errcode, 'Login successfully' as errmsg,a.*, d.isocode as countryisocode,d.prefix as countryprefix
					from tb_whl_rtl_users_dtl a    
                     LEFT join tb_whl_rtl_country_code d on d.id = a.countryCodeId
					where a.emailAddress = p_email and BINARY a.token = p_password and status = 1 ; 
 				end if;
             end if;
  
  	End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_validate_password_recovery_link_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_validate_password_recovery_link_dtl`(
	email VARCHAR(250),
	link text,
	p_new_password  VARCHAR(50)
)
Begin
       
          DECLARE errcode INT; 
          DECLARE errmsg VARCHAR(250);
          DECLARE now DATETIME(3);
          Declare Timediff int; 
          Declare v_expiry_time int; 
          Declare v_create_time datetime(3);
          
          sp_exit:
          BEGIN
             set errcode = -1;
             set errmsg = '';
             set now = CURRENT_TIMESTAMP;
             
             if not exists(select 1 from tb_whl_rtl_user_password_reset_log a  where a.email = email LIMIT 1) then
       		
                set errcode = -1;
                set errmsg = 'Incorrect email address';
                LEAVE sp_exit;
             end if;
             
             if exists(select 1 from tb_whl_rtl_user_password_reset_log a  where a.email = email and a.link = link LIMIT 1) then
             
     			select a.expiry_time, a.created_date into v_expiry_time, v_create_time
     			from tb_whl_rtl_user_password_reset_log a where a.email = email and a.link = link  
     			order by id desc limit 1;
     
     			set Timediff = timestampdiff(MINUTE,v_create_time,NOW(3));  
     
     			if v_expiry_time <  Timediff Then  
     				set errcode = -1;  
     				set errmsg = 'Link has expired';  
     				leave sp_exit;
     			End if;  
                 
				update tb_whl_rtl_users_dtl set password = p_new_password where emailAddress = email;
                
                update tb_whl_rtl_user_password_reset_log a set link = null,created_date = now() where a.email = email;
                
                 
                set errcode = 0;
                set errmsg = 'Password Changed successfully';
                
                LEAVE sp_exit;
             end if;
             
          END;
          select errcode as errcode,errmsg as errmsg; 
       
       End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `whl_rtl_validate_personal_sign_signup_user_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `whl_rtl_validate_personal_sign_signup_user_dtl`(
       email VARCHAR(250),
       verify_code VARCHAR(10)
       )
Begin
       
          DECLARE errcode INT; 
          DECLARE errmsg VARCHAR(250);
          DECLARE now DATETIME(3);
          Declare Timediff int; 
          Declare v_expiry_time int; 
          Declare v_create_time datetime(3);
          
          sp_exit:
          BEGIN
             set errcode = -1;
             set errmsg = '';
             set now = CURRENT_TIMESTAMP;
             
             if not exists(select * from tb_whl_rtl_sign_signup_user_dtl a  where a.email = email LIMIT 1) then
       		
                set errcode = -1;
                set errmsg = 'Incorrect email address';
                LEAVE sp_exit;
             end if;
             
             if exists(select * from tb_whl_rtl_sign_signup_user_dtl a  where a.email = email and a.is_verified = 1 LIMIT 1) then
       		
                set errcode = -1;
                set errmsg = 'This email address already verified';
                LEAVE sp_exit;
             end if;
             
             if exists(select * from tb_whl_rtl_sign_signup_user_dtl a  where a.email = email and a.verify_code <> verify_code and a.is_verified = 0 LIMIT 1) then
       		
                set errcode = -1;
                set errmsg = 'Invalid OTP';
                LEAVE sp_exit;
             end if;
             
             if exists(select * from tb_whl_rtl_sign_signup_user_dtl a  where a.email = email and a.verify_code = verify_code and a.is_verified = 0 LIMIT 1) then
             
     			select a.expiry_time, a.created_date into v_expiry_time, v_create_time
     			from tb_whl_rtl_sign_signup_user_dtl a where a.email = email and a.verify_code = verify_code  
     			order by id desc limit 1;
     
     			set Timediff = timestampdiff(MINUTE,v_create_time,NOW(3));  
     
     			if v_expiry_time <  Timediff Then  
     				set errcode = -1;  
     				set errmsg = 'OTP has expired, please click on Resend code to continue';  
     				leave sp_exit;
     			End if;  
                 
                set errcode = 0;
                set errmsg = 'Success : Email verified';
                
                UPDATE tb_whl_rtl_sign_signup_user_dtl a set a.is_verified = 1
                where a.email = email and a.verify_code = verify_code;
                LEAVE sp_exit;
             end if;
             
          END;
          select errcode as errcode,errmsg as errmsg; 
       
       End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wh_rtl_insert_sim_only_product_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wh_rtl_insert_sim_only_product_dtl`(
    p_uuid varchar(50),
    p_groupId varchar(150),
    p_serviceType varchar(50),
    p_companyName varchar(150),
    p_planName varchar(200),
    p_contractLength int,
    p_monthlyCost varchar(20),
    p_data varchar(20),
    p_callMinutes varchar(50),
    p_texts text,
    p_perks text,
    p_sellerInformation varchar(20),
    p_websiteURL text,
    p_critique text,
    p_offers text,
    p_dataMetric varchar(50),
    p_overallPrice float
    )
Begin
    		declare v_errcode int;
    		declare v_errmsg varchar(50);
    		declare v_id int;
    
 			insert into tb_whl_rtl_sim_only_product_dtl(uuid, groupId, serviceType, companyName, planName, contractLength, monthlyCost, data, callMinutes, texts, perks, sellerInformation, websiteURL, critique, offers, dataMetric, overallPrice)
 			values(p_uuid, p_groupId, p_serviceType, p_companyName, p_planName, p_contractLength, p_monthlyCost, p_data, p_callMinutes, p_texts, p_perks, p_sellerInformation, p_websiteURL, p_critique, p_offers, p_dataMetric, p_overallPrice);
                       
 			set v_id = last_insert_id();
               
 			if row_count() > 0 then
 				set v_errcode = 0;
 				set v_errmsg = 'Inserted';
 			End if;
               
    	select v_errcode as errcode, v_errmsg as errmsg, ifnull(v_id,0) as id;
    End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-21  9:53:55
