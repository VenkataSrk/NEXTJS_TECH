-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: crm3
-- ------------------------------------------------------
-- Server version	8.0.44-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `crm3`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `crm3` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `crm3`;

--
-- Table structure for table `Product_by_mobileno`
--

DROP TABLE IF EXISTS `Product_by_mobileno`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Product_by_mobileno` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `msisdn_Prefix` varchar(3) DEFAULT NULL,
  `Product` varchar(4) DEFAULT NULL,
  `sitecode` varchar(3) DEFAULT NULL,
  `master_custcode` varchar(10) DEFAULT NULL,
  `curr_code` varchar(10) DEFAULT NULL,
  UNIQUE KEY `Id` (`Id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `SMS_request_log`
--

DROP TABLE IF EXISTS `SMS_request_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SMS_request_log` (
  `logid` int NOT NULL AUTO_INCREMENT,
  `logdate` datetime(3) DEFAULT NULL,
  `mobileno` varchar(40) DEFAULT NULL,
  `sms_url` varchar(100) DEFAULT NULL,
  `sms_id` varchar(100) DEFAULT NULL,
  `sms_sender` varchar(100) DEFAULT NULL,
  `api_request` int DEFAULT NULL,
  `map_client_request` int DEFAULT NULL,
  `called_by` varchar(50) DEFAULT NULL,
  `sms_text` longtext,
  `sitecode` varchar(5) DEFAULT NULL,
  `scenerio` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`logid`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=2518506 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `WEBSITE_CENTRAL_BUNDLE_PAYMENT_LOG`
--

DROP TABLE IF EXISTS `WEBSITE_CENTRAL_BUNDLE_PAYMENT_LOG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WEBSITE_CENTRAL_BUNDLE_PAYMENT_LOG` (
  `paylogid` int NOT NULL AUTO_INCREMENT,
  `sitecode` varchar(3) DEFAULT NULL,
  `mobileno` varchar(20) DEFAULT NULL,
  `bundle_id` int DEFAULT NULL,
  `paymode` int DEFAULT NULL,
  `payment_ref` varchar(150) DEFAULT NULL,
  `calledby` varchar(50) DEFAULT NULL,
  `pay_date` datetime(3) DEFAULT NULL,
  `BRAND` int DEFAULT NULL,
  `tigo_flag` int DEFAULT NULL,
  `errcode` int DEFAULT NULL,
  `errmsg` varchar(250) DEFAULT NULL,
  `promo_flag` int DEFAULT NULL,
  `promo_code` varchar(50) DEFAULT NULL,
  `price` float DEFAULT NULL,
  `PURCHASE_PROCESS` varchar(100) DEFAULT NULL,
  `purchased_ccno` varchar(10) DEFAULT NULL,
  `payment_desc` varchar(250) DEFAULT NULL,
  `purchase_url` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`paylogid`),
  KEY `idx1_WEBSITE_CENTRAL_BUNDLE_PAYMENT_LOG` (`mobileno`,`bundle_id`),
  KEY `idx2_WEBSITE_CENTRAL_BUNDLE_PAYMENT_LOG` (`mobileno`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=656947 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `WEB_PAYMENT_LOG`
--

DROP TABLE IF EXISTS `WEB_PAYMENT_LOG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WEB_PAYMENT_LOG` (
  `id` int NOT NULL AUTO_INCREMENT,
  `CREATE_DATE` datetime(3) DEFAULT NULL,
  `SITECODE` varchar(5) DEFAULT NULL,
  `MOBILENO` varchar(20) DEFAULT NULL,
  `UNIQ_CODE` varchar(50) DEFAULT NULL,
  `PAY_REF` varchar(50) DEFAULT NULL,
  `STEP` varchar(5) DEFAULT NULL,
  `REASON_CODE` varchar(150) DEFAULT NULL,
  `COMMENTS` varchar(150) DEFAULT NULL,
  `CC_NO` varchar(6) DEFAULT NULL,
  `IP_CLIENT` varchar(50) DEFAULT NULL,
  `product_type` int NOT NULL DEFAULT '0',
  UNIQUE KEY `id` (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=655500 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `country_code`
--

DROP TABLE IF EXISTS `country_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `country_code` (
  `SNO` int NOT NULL AUTO_INCREMENT,
  `COUNTRY_NAME` varchar(65) DEFAULT NULL,
  `COUNTRY_SHORT_CODE` varchar(3) DEFAULT NULL,
  `LANGUAGE` varchar(30) DEFAULT NULL,
  `LANGUAGE_SHORT_CODE` varchar(3) DEFAULT NULL,
  `COUNTRY_NUMBER` int DEFAULT NULL,
  `SITECODE` varchar(5) DEFAULT NULL,
  `curr_symbol` varchar(3) DEFAULT NULL,
  `currency` varchar(5) DEFAULT NULL,
  UNIQUE KEY `SNO` (`SNO`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `crm3_linked_server`
--

DROP TABLE IF EXISTS `crm3_linked_server`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `crm3_linked_server` (
  `sitecode` varchar(16) NOT NULL,
  `db_type` varchar(32) NOT NULL,
  `linked_server` varchar(32) NOT NULL DEFAULT '',
  `dcapp` int NOT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=135 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `crm3_linked_server_new`
--

DROP TABLE IF EXISTS `crm3_linked_server_new`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `crm3_linked_server_new` (
  `sitecode` varchar(16) NOT NULL,
  `db_type` varchar(32) NOT NULL,
  `linked_server` varchar(32) NOT NULL DEFAULT '',
  `dcapp` int NOT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `freesim_special_bundle_info`
--

DROP TABLE IF EXISTS `freesim_special_bundle_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `freesim_special_bundle_info` (
  `sitecode` varchar(5) NOT NULL,
  `freesimid` int NOT NULL,
  `mobileno` varchar(20) NOT NULL,
  `iccid` varchar(20) DEFAULT NULL,
  `create_date` datetime(3) DEFAULT NULL,
  `status` int DEFAULT NULL,
  `errcode` int DEFAULT NULL,
  `errmsg` varchar(200) DEFAULT NULL,
  `last_update` datetime(3) DEFAULT NULL,
  `bundle_type` int DEFAULT NULL,
  `bundle_id` int DEFAULT NULL,
  `dest_number` varchar(30) DEFAULT NULL,
  `datemdode` int DEFAULT NULL,
  `paymode` int DEFAULT NULL,
  `is_renew` int NOT NULL DEFAULT '0',
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=271 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sms_iwmsc_url`
--

DROP TABLE IF EXISTS `sms_iwmsc_url`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sms_iwmsc_url` (
  `sitecode` varchar(3) NOT NULL,
  `sms_url` varchar(250) NOT NULL,
  `creat_date` datetime(3) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping events for database 'crm3'
--

--
-- Dumping routines for database 'crm3'
--
/*!50003 DROP PROCEDURE IF EXISTS `esp_subscribe_special_bundle_request` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `esp_subscribe_special_bundle_request`(v_sitecode VARCHAR(5),
v_freesimid INT,
v_mobileno VARCHAR(20),
v_iccid VARCHAR(20),
v_bundle_type INT,
v_bundleid INT,
v_dest_number VARCHAR(30),
INOUT v_errcode INT ,
INOUT v_errmsg VARCHAR(200) ,
v_datemdode INT,
v_paymode INT)
BEGIN
   DECLARE v_now DATETIME(3); 
	
   set v_now = CURRENT_TIMESTAMP;
   set v_errcode = -1;
   set v_errmsg = 'Failure to create freesim order.';
	
   INSERT INTO freesim_special_bundle_info(sitecode,freesimid,mobileno,iccid,create_date,status,bundle_type,bundle_id,dest_number,datemdode,
	paymode)
	VALUES(v_sitecode,v_freesimid,v_mobileno,v_iccid,v_now,0,v_bundle_type,v_bundleid,v_dest_number,v_datemdode,v_paymode);
	
	
   if ROW_COUNT() > 0 then
	
      set v_errcode = 0;
      set v_errmsg = 'Success to insert freesim order process.';
   end if;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Hubspot_delete_exe_delete_contact_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `Hubspot_delete_exe_delete_contact_info`(
sitecode varchar(20),
conatctid int
)
BEGIN
	declare linkedserver varchar(250);
	declare sp_name varchar(250);
    
    set sitecode = 'mcm';
	
			call esp.hubspot_exe_delete_contact_by_contactid (conatctid);

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Hubspot_delete_exe_get_contact_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `Hubspot_delete_exe_get_contact_info`(sitecode VARCHAR(20))
BEGIN


   DECLARE v_linkedserver VARCHAR(250);
   DECLARE v_sp_name VARCHAR(250);
	
	
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   a.linked_server INTO v_linkedserver from crm3_linked_server a where a.sitecode = sitecode and a.db_type = 'CRM';
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
		
   if v_linkedserver is not null then
		
      set v_sp_name = CONCAT_WS('',v_linkedserver,'Hubspot_contact_delete_exe_get_info');
      CALL crm.Hubspot_contact_delete_exe_get_info();
   end if;

	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Hubspot_sms_get_bundle_allowances` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `Hubspot_sms_get_bundle_allowances`(sitecode VARCHAR(3),
 mobileno VARCHAR(20),
 bundleid INT)
begin
    
 	

    DECLARE v_NOW DATETIME(3);
    DECLARE v_sp_name VARCHAR(250);
    DECLARE v_enddate DATETIME(3);
 	
    DECLARE v_dbtype VARCHAR(80);
    DECLARE v_sql VARCHAR(1000);
    DECLARE v_linkedserver VARCHAR(100);
    DECLARE v_spname VARCHAR(200);
    DECLARE v_errcode INT;
    DECLARE v_errmsg VARCHAR(150);
    DECLARE v_paymode_saved INT;
 			
 	
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
 
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
 		
        if sitecode = 'mcm' then
			CALL esp.Hubspot_sms_get_bundle_allowances (mobileno,bundleid);
		end if;
        
    
    
    
    
 		 
 	
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `mb_keycheck` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `mb_keycheck`(username VARCHAR(500),              
password   VARCHAR(500))
BEGIN
   DECLARE v_errcode INT;

   if exists(select 1  from Residential.cta_appkey where appkey = username and appsecret = password LIMIT 1) then
      set v_errcode = 0;
   else
      set v_errcode = 1;
   end if;
   select v_errcode as errcode;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `renew_exe_get_renewal_message` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `renew_exe_get_renewal_message`(
sitecode CHAR(3),
mobileno VARCHAR(20),
bundleid INT,
payment_ref VARCHAR(50),
bundle_price FLOAT,
process_by VARCHAR(50),
purchased_ccno VARCHAR(25),
payment_desc VARCHAR(250))
BEGIN

   DECLARE v_linkserver VARCHAR(250);
   DECLARE v_sp_name VARCHAR(250);
   DECLARE v_errcode INT; 
   DECLARE v_errmsg VARCHAR(260);


	
   DECLARE v_product_code VARCHAR(10);
   DECLARE v_bundle_call VARCHAR(100);
   DECLARE v_bundle_sms VARCHAR(100);
   DECLARE v_bundle_data VARCHAR(100);
   DECLARE v_bundle_name VARCHAR(150);
	
   DECLARE v_bundle_message VARCHAR(160); 
   DECLARE v_NOW DATETIME(3); 
   DECLARE v_default_value int;
	
   set v_errcode = -1;
   set v_errmsg = '';
   set v_NOW = CURRENT_TIMESTAMP;
   set v_default_value=0;

	
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   a.linked_server INTO v_linkserver FROM  crm3_linked_server a where a.sitecode = sitecode and a.db_type = 'ESPDB';
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
	
   if v_linkserver is not null then
	
      set v_sp_name = CONCAT_WS('',v_linkserver,'renewexe_get_renewal_message');
      CALL esp.renewexe_get_renewal_message (mobileno,bundleid,v_bundle_message);
   end if;
	
   select   bundle_name, bundle_call, bundle_sms, IFNULL(bundle_data,'') INTO v_bundle_name,v_bundle_call,v_bundle_sms,v_bundle_data from Tariff_Management.tm_web_bundle_config where product_name = v_product_code and bundle_id = bundleid;
	
   if v_bundle_call = '0' then
      set v_bundle_call = replace(v_bundle_call,'0','');
   end if;
		
   if v_bundle_sms = '0' then
      set v_bundle_sms = replace(v_bundle_sms,'0','');
   end if;
	
   IF v_bundle_data = '0' then
      set v_bundle_data = replace(v_bundle_data,'0','');
   end if;
		
	
   set v_bundle_call = replace(v_bundle_call,'@@',',');
   SET v_bundle_sms = replace(v_bundle_sms,'@@',',');
   SET v_bundle_data = replace(v_bundle_data,'@@',',');


	
   INSERT INTO WEBSITE_CENTRAL_BUNDLE_PAYMENT_LOG(sitecode,BRAND,mobileno,bundle_id,paymode,payment_ref,calledby,pay_date,price,PURCHASE_PROCESS,
	purchased_ccno,payment_desc)
	VALUES(sitecode,1,mobileno,bundleid,2,payment_ref,process_by,v_NOW,bundle_price,'RENEWAL',purchased_ccno,payment_desc);
	
	
   select v_default_value errcode,IFNULL(v_bundle_message,'') as errmsg,IFNULL(v_bundle_call,'') as bundle_call, IFNULL(v_bundle_sms,'') as bundle_sms ,
	IFNULL(v_bundle_data,'') as bundle_data;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sms_insert_request_log` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sms_insert_request_log`(  
 mobileno varchar(40),  
 sms_url varchar(100),
 sms_id varchar(100),
 sms_sender varchar(100),
 request_type int,  
 called_by varchar(50),
 logid int,
 sms_text longtext,
 sitecode varchar(10),
 scnerio varchar(500) 
 )
Begin  
   
 declare v_errcode int default 0; 
 declare v_errmsg varchar(30) default 'success';  
   
   
   if sms_url = '' 			then set sms_url = null; 		end if;
   if sms_id = '' 			then set sms_id = null; 		end if;
   if sms_sender = '' 		then set sms_sender = null; 	end if;   
   if called_by = '' 		then set called_by = null;    	end if;
   if logid = ''    		then set logid = null; 			end if;
   if sms_text = '' 		then set sms_text = null; 		end if;
   if sitecode = '' 		then set sitecode = null; 		end if;
   if scnerio = ''    		then set scnerio = ''; 			end if;
   
  IF LEFT(mobileno,2)='00' 
  THEN  
   SET mobileno=INSERT(mobileno,1,2,'');
  END IF;  
   
  IF LEFT(mobileno,1)='0' 
  THEN  
   SET mobileno=INSERT(mobileno,1,1,'');
  END IF;  

  if request_type=1  Then  
	   insert into SMS_request_log (logdate,mobileno,sms_url,sms_id,sms_sender,api_request,called_by,sms_text,sitecode,scenerio)  
	   select now(3),mobileno,sms_url,sms_id,sms_sender,1,called_by,sms_text,sitecode,scnerio;  
	   set logid=last_insert_id();  
	   
   else 
   
	   if request_type=2  then  
		 update  SMS_request_log s set s.map_client_request=1,s.sms_url=sms_url,s.sms_id=sms_id,
		 s.sms_sender=sms_sender,s.sms_text=sms_text,s.sitecode=sitecode where s.logid=logid ;
	  end if;  
   end if;

 select v_errcode errcode,v_errmsg errmsg,logid logid;  

 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `website_central_insert_payment_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `website_central_insert_payment_info`(
sitecode VARCHAR(5),
mobileno VARCHAR(20),
unique_code VARCHAR(50),
pay_reff VARCHAR(50),
step VARCHAR(5),
reason_code VARCHAR(150),
comments VARCHAR(150),
cc_no VARCHAR(6),
ip_client VARCHAR(50),
now DATETIME(3),
product_type INT
)
BEGIN

   DECLARE v_errcode INT;
   DECLARE v_errmsg VARCHAR(250);

   IF product_type is null then
      set product_type = 0;
   END IF;
   IF now is null then
      set now = CURRENT_TIMESTAMP;
   end if;

   IF unique_code = 'DC' then
      set product_type = 1;
   end if;

   SET v_errcode = -1;

   SET v_errmsg = '';


   INSERT INTO WEB_PAYMENT_LOG(CREATE_DATE,SITECODE,MOBILENO,UNIQ_CODE,PAY_REF,STEP,REASON_CODE,COMMENTS,CC_NO,IP_CLIENT,product_type)
	VALUES(now,sitecode,mobileno,unique_code,pay_reff,step,reason_code,comments,cc_no,ip_client,product_type);

	
   IF found_rows() > 0 then
	
      SET v_errcode = 0;
      SET v_errmsg = 'SUCESS TO WRITE LOG';
   end if;

   select v_errcode as errcode,v_errmsg as errmsg;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `web_topup_process_byCredidCard_myacount` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `web_topup_process_byCredidCard_myacount`(
mobileno VARCHAR(16),             
paymentid INT,             
paymentref VARCHAR(64),             
productid INT,            
amount FLOAT,             
ccdc_curr VARCHAR(3),             
calledby VARCHAR(15),        
sitecode VARCHAR(3),          
brand INT)
Begin

  

	        
          
   DECLARE v_linkedserver VARCHAR(50);          
   DECLARE v_sp VARCHAR(155);          
   DECLARE v_spname VARCHAR(500);               
   DECLARE v_errcode INT;             
   DECLARE v_errmsg VARCHAR(64);             
   DECLARE v_incentif_data VARCHAR(10);         
   DECLARE v_total_notif VARCHAR(255);
	
	
   DECLARE v_topuplogid INT;
   DECLARE v_bundle_notify INT; 
	         
	      
          
   IF paymentid is null then
      set paymentid = 0;
   END IF;
   IF calledby is null then
      set calledby = 'WEB';
   END IF;
 
      

	
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   IFNULL(brand_code,'') INTO calledby from brandcodewise_country where sitecode = sitecode and brand_type = brand;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ; 

   if calledby = '' then
      set calledby = 'WEB';
   end if;

	
   if paymentref like '%PPL%' then
      SET calledby = CONCAT_WS('',calledby,'-PPL');
   end if;

	
   if paymentref like '%AMZ%' then
      SET calledby = CONCAT_WS('',calledby,'-AMZ');
   end if;
		
	
   if paymentref like '%PSC%' then
      SET calledby = CONCAT_WS('',calledby,'-PSC');
   end if;
	          
   CALL esp.tp_do_topup_process_byccdc_v2 (mobileno,paymentid,paymentref,productid,amount,ccdc_curr,calledby,
   v_errcode,v_errmsg,v_incentif_data,v_total_notif,v_bundle_notify,
   '',v_topuplogid,'My Vectone');
       
	      
      
   Select v_errcode as errcode,v_errmsg as errmsg,v_incentif_data as  incentif_data,v_total_notif as total_notif; 
        
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-21  9:50:12
