-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: Residential
-- ------------------------------------------------------
-- Server version	8.0.44-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `Residential`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `Residential` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `Residential`;

--
-- Table structure for table `cta_appkey`
--

DROP TABLE IF EXISTS `cta_appkey`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cta_appkey` (
  `appkey` varchar(128) NOT NULL,
  `appcred` varchar(256) NOT NULL,
  `isvalid` tinyint(1) NOT NULL,
  `create_date` datetime(3) NOT NULL,
  `descr` varchar(256) NOT NULL,
  `appsecret` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`appkey`),
  UNIQUE KEY `cta_appkey_idx` (`appkey`,`appcred`(255)),
  KEY `cta_appkey_idx1` (`appkey`,`appcred`(255),`isvalid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `res_psnldetails`
--

DROP TABLE IF EXISTS `res_psnldetails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `res_psnldetails` (
  `login` varchar(20) DEFAULT NULL,
  `title` varchar(5) DEFAULT NULL,
  `firstname` varchar(20) DEFAULT NULL,
  `lastname` varchar(20) DEFAULT NULL,
  `dayphoneno` varchar(20) DEFAULT NULL,
  `homephoneno` varchar(20) DEFAULT NULL,
  `mobileno` varchar(20) DEFAULT NULL,
  `faxno` varchar(30) DEFAULT NULL,
  `email` varchar(40) DEFAULT NULL,
  `address1` varchar(30) DEFAULT NULL,
  `address2` varchar(30) DEFAULT NULL,
  `city` varchar(20) DEFAULT NULL,
  `state` varchar(20) DEFAULT NULL,
  `postcode` varchar(8) DEFAULT NULL,
  `country` varchar(20) DEFAULT NULL,
  `mailing` varchar(1) DEFAULT NULL,
  `gender` varchar(1) DEFAULT NULL,
  `contactmethod` varchar(50) DEFAULT NULL,
  `birthdate` varchar(12) DEFAULT NULL,
  `hearFrom` varchar(100) DEFAULT NULL,
  `customer_id` int NOT NULL AUTO_INCREMENT,
  `password` varchar(30) DEFAULT NULL,
  `status` int DEFAULT NULL,
  `created_date` datetime(3) DEFAULT NULL,
  `customer_type` int DEFAULT NULL,
  `language` varchar(32) DEFAULT NULL,
  `isgdlisted` int DEFAULT NULL,
  `lastlogin` datetime(3) DEFAULT NULL,
  `has_avatar` tinyint(1) DEFAULT NULL,
  `avatar_last_update` datetime(3) DEFAULT NULL,
  `image_path` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`customer_id`),
  KEY `language_fkIdx` (`language`),
  KEY `idx_emai` (`email`),
  KEY `res_psnldetails_idx2` (`postcode`,`lastname`,`firstname`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=160134 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping events for database 'Residential'
--

--
-- Dumping routines for database 'Residential'
--
/*!50003 DROP PROCEDURE IF EXISTS `ctp_get_mobileno` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ctp_get_mobileno`(accountid VARCHAR(20))
begin



   DECLARE v_mobileno VARCHAR(100);


   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   mobileno INTO v_mobileno from res_psnldetails  where login = accountid    LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 

   select v_mobileno as mobileno;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-21  9:52:34
