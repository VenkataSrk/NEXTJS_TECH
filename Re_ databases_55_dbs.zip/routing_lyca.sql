-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: routing_lyca
-- ------------------------------------------------------
-- Server version	8.0.44-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `routing_lyca`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `routing_lyca` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `routing_lyca`;

--
-- Table structure for table `r20_route12`
--

DROP TABLE IF EXISTS `r20_route12`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `r20_route12` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parentId` int DEFAULT NULL,
  `state` int DEFAULT NULL,
  `reason` int DEFAULT NULL,
  `routeCls` int DEFAULT NULL,
  `oprId` int DEFAULT NULL,
  `pc` varchar(2) DEFAULT NULL,
  `prefixCode` varchar(16) DEFAULT NULL,
  `prefixLen` int DEFAULT NULL,
  `destCode` varchar(32) DEFAULT NULL,
  `clsOrg` varchar(2) DEFAULT NULL,
  `cls` varchar(2) DEFAULT NULL,
  `costOrgCurr` varchar(4) DEFAULT NULL,
  `costOrg` float DEFAULT NULL,
  `cost` float DEFAULT NULL,
  `priority` float DEFAULT NULL,
  `access` int DEFAULT NULL,
  `quality` float DEFAULT NULL,
  `rating` int DEFAULT NULL,
  `flag` int DEFAULT NULL,
  `ext` int DEFAULT NULL,
  `lastUpd` datetime DEFAULT NULL,
  `lastUpdBy` varchar(16) DEFAULT NULL,
  `exception` int DEFAULT NULL,
  `exceptionCls` int DEFAULT NULL,
  `lastLock` datetime DEFAULT NULL,
  `lastLockBy` varchar(50) DEFAULT NULL,
  `uploadDate` datetime DEFAULT NULL,
  `uploadBy` varchar(100) DEFAULT NULL,
  `approveBy` varchar(16) DEFAULT NULL,
  `approveTime` datetime DEFAULT NULL,
  `inQueue` int DEFAULT NULL,
  `updateFlag` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `routeCls` (`routeCls`,`oprId`,`pc`,`prefixCode`,`cls`),
  KEY `idx2` (`prefixCode`),
  KEY `idx1` (`routeCls`,`oprId`,`pc`,`cls`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `r_prefix_intest`
--

DROP TABLE IF EXISTS `r_prefix_intest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `r_prefix_intest` (
  `id` int NOT NULL AUTO_INCREMENT,
  `state` varchar(1) NOT NULL,
  `prefixcode` varchar(17) NOT NULL,
  `destcode` varchar(32) NOT NULL,
  `userinfo` varchar(64) DEFAULT NULL,
  `tgroup` varchar(32) DEFAULT NULL,
  `tdomain` varchar(8) DEFAULT NULL,
  `tuniverse` varchar(8) DEFAULT NULL,
  `owner` varchar(16) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping events for database 'routing_lyca'
--

--
-- Dumping routines for database 'routing_lyca'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-21  9:52:39
