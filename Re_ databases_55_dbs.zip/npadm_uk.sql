-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: npadm_uk
-- ------------------------------------------------------
-- Server version	8.0.44-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `npadm_uk`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `npadm_uk` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `npadm_uk`;

--
-- Table structure for table `ENTRY`
--

DROP TABLE IF EXISTS `ENTRY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ENTRY` (
  `ENTRY_ID` int NOT NULL AUTO_INCREMENT,
  `PAC` varchar(32) NOT NULL,
  `MSISDN` varchar(24) NOT NULL,
  `LAST_UPDATE` datetime(3) NOT NULL,
  `IS_TAGGED` int DEFAULT NULL,
  `ENTRY_COUNT` int DEFAULT NULL,
  `CREATION_DATE` datetime(3) DEFAULT NULL,
  `EXPIRY_DATE` datetime(3) DEFAULT NULL,
  `ACC_NO` varchar(32) DEFAULT NULL,
  `REF` varchar(64) DEFAULT NULL,
  `SP_ID` varchar(32) DEFAULT NULL,
  `CONTACT_NAME` varchar(64) DEFAULT NULL,
  `CONTACT_DETAILS` varchar(256) DEFAULT NULL,
  `ERROR_CODE` int DEFAULT NULL,
  `REQUEST_SOURCE` int DEFAULT NULL,
  `VALIDATION_DETAILS` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`ENTRY_ID`),
  UNIQUE KEY `IDX_PAC_MSISDN` (`PAC`,`MSISDN`),
  KEY `FK_ENTRY_REF_REQUEST_SOURCEIdx` (`REQUEST_SOURCE`),
  KEY `FK_MSISDN_O_REFERENCE_ENTRYIdx2` (`ENTRY_ID`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=89223 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `MSISDN_IN`
--

DROP TABLE IF EXISTS `MSISDN_IN`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MSISDN_IN` (
  `REQUEST_ID` int NOT NULL,
  `MSISDN` varchar(24) NOT NULL,
  `STATUS` int DEFAULT NULL,
  `SYNIVERSE_STATUS` int DEFAULT NULL,
  `ERROR_CODE` int DEFAULT NULL,
  `DNO` char(2) DEFAULT NULL,
  `RNO` char(2) DEFAULT NULL,
  `ONO` char(2) DEFAULT NULL,
  `BB_MSISDN` varchar(24) DEFAULT NULL,
  `PORT_DATE` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`REQUEST_ID`,`MSISDN`),
  KEY `FK_MSISDN_I_REFERENCE_REF_STATIdx` (`STATUS`),
  CONSTRAINT `FK_MSISDN_I_REFERENCE_REF_STAT` FOREIGN KEY (`STATUS`) REFERENCES `REF_STATUS` (`STATUS`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `MSISDN_OUT`
--

DROP TABLE IF EXISTS `MSISDN_OUT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MSISDN_OUT` (
  `ENTRY_ID` int NOT NULL,
  `PRIMARY_MSISDN` varchar(24) NOT NULL,
  `SECONDARY_MSISDN` varchar(24) NOT NULL,
  `STATUS` int DEFAULT NULL,
  `SYNIVERSE_STATUS` int DEFAULT NULL,
  `ERROR_CODE` int DEFAULT NULL,
  `DNO` char(2) DEFAULT NULL,
  `RNO` char(2) DEFAULT NULL,
  `ONO` char(2) DEFAULT NULL,
  `PORT_DATE` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`ENTRY_ID`,`PRIMARY_MSISDN`,`SECONDARY_MSISDN`),
  KEY `FK_MSISDN_O_REFERENCE_ENTRYIdx` (`ENTRY_ID`),
  KEY `FK_MSISDN_O_REFERENCE_REF_STATIdx` (`STATUS`),
  CONSTRAINT `FK_MSISDN_O_REFERENCE_ENTRY` FOREIGN KEY (`ENTRY_ID`) REFERENCES `ENTRY` (`ENTRY_ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_MSISDN_O_REFERENCE_REF_STAT` FOREIGN KEY (`STATUS`) REFERENCES `REF_STATUS` (`STATUS`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `REF_OPR`
--

DROP TABLE IF EXISTS `REF_OPR`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `REF_OPR` (
  `CODE` char(2) NOT NULL,
  `MRC` int NOT NULL,
  `NAME` varchar(64) DEFAULT NULL,
  `SYNIVERSE_CODE` char(2) DEFAULT NULL,
  PRIMARY KEY (`CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `REF_REQUEST_SOURCE`
--

DROP TABLE IF EXISTS `REF_REQUEST_SOURCE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `REF_REQUEST_SOURCE` (
  `source_id` int NOT NULL,
  `source` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`source_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `REF_SERVICE_PROVIDER`
--

DROP TABLE IF EXISTS `REF_SERVICE_PROVIDER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `REF_SERVICE_PROVIDER` (
  `code` char(3) NOT NULL,
  `name` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `REF_STATUS`
--

DROP TABLE IF EXISTS `REF_STATUS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `REF_STATUS` (
  `STATUS` int NOT NULL,
  `NAME` varchar(100) NOT NULL,
  `DESCRIPTION` varchar(256) NOT NULL,
  PRIMARY KEY (`STATUS`),
  KEY `FK_MSISDN_I_REFERENCE_REF_STATIdx2` (`STATUS`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `REQUEST`
--

DROP TABLE IF EXISTS `REQUEST`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `REQUEST` (
  `REQUEST_ID` int NOT NULL AUTO_INCREMENT,
  `PAC` varchar(32) NOT NULL,
  `MSISDN` varchar(24) NOT NULL,
  `LAST_UPDATE` datetime(3) NOT NULL,
  `DSP_CODE` varchar(8) DEFAULT NULL,
  `RSP_CODE` varchar(8) DEFAULT NULL,
  `PORT_DATE` varchar(20) DEFAULT NULL,
  `IS_SUGGESTED_DATE` int DEFAULT NULL,
  `IS_WARNING` int DEFAULT NULL,
  `SUBMIT_DATE` datetime(3) DEFAULT NULL,
  `ACC_NO` varchar(50) DEFAULT NULL,
  `REF` varchar(120) DEFAULT NULL,
  `SP_ID` varchar(120) DEFAULT NULL,
  `CONTACT_NAME` varchar(64) DEFAULT NULL,
  `CONTACT_DETAILS` varchar(256) DEFAULT NULL,
  `ERROR_CODE` int DEFAULT NULL,
  `REQUEST_SOURCE` int DEFAULT NULL,
  `COMMENTS` varchar(256) DEFAULT NULL,
  `CrmUser` varchar(16) DEFAULT NULL,
  PRIMARY KEY (`REQUEST_ID`),
  KEY `FK_REQUEST_REF_REQUEST_SOURCEIdx` (`REQUEST_SOURCE`),
  KEY `IDX_PAC_MSISDN` (`PAC`,`MSISDN`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=57412 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping events for database 'npadm_uk'
--

--
-- Dumping routines for database 'npadm_uk'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-21  9:51:48
