-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: smereseller
-- ------------------------------------------------------
-- Server version	8.0.44-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Cust_Size_info_Master`
--

DROP TABLE IF EXISTS `Cust_Size_info_Master`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Cust_Size_info_Master` (
  `Pk_cust_Size_Id` int NOT NULL,
  `Cust_size_name` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`Pk_cust_Size_Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Employee_Size_Master`
--

DROP TABLE IF EXISTS `Employee_Size_Master`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Employee_Size_Master` (
  `Pk_Emp_Size_Id` int NOT NULL,
  `Emp_size_name` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`Pk_Emp_Size_Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Inc_Scheme_Master`
--

DROP TABLE IF EXISTS `Inc_Scheme_Master`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Inc_Scheme_Master` (
  `Is_ID` int NOT NULL,
  `Scheme_Name` varchar(150) DEFAULT NULL,
  `Typeid` int NOT NULL,
  `Inc_app_Month` int DEFAULT NULL,
  `inc_percentage` float DEFAULT NULL,
  `After_Inc_apply_Month_Per` float DEFAULT NULL,
  `status` int DEFAULT NULL,
  `create_date` datetime(3) DEFAULT NULL,
  `create_by` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`Is_ID`,`Typeid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Partner_Program_Master`
--

DROP TABLE IF EXISTS `Partner_Program_Master`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Partner_Program_Master` (
  `Pk_Program_id` int NOT NULL,
  `Partner_prog_name` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`Pk_Program_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Res_Bank_Account_Type_Master`
--

DROP TABLE IF EXISTS `Res_Bank_Account_Type_Master`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Res_Bank_Account_Type_Master` (
  `PK_Account_id` int NOT NULL AUTO_INCREMENT,
  `Account_name` varchar(15) DEFAULT NULL,
  UNIQUE KEY `PK_Account_id` (`PK_Account_id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Res_Bank_City_Master`
--

DROP TABLE IF EXISTS `Res_Bank_City_Master`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Res_Bank_City_Master` (
  `PK_City_id` int NOT NULL AUTO_INCREMENT,
  `City_name` varchar(15) DEFAULT NULL,
  UNIQUE KEY `PK_City_id` (`PK_City_id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Res_Bank_Country_Master`
--

DROP TABLE IF EXISTS `Res_Bank_Country_Master`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Res_Bank_Country_Master` (
  `PK_Cntry_id` int NOT NULL AUTO_INCREMENT,
  `Country_name` varchar(15) DEFAULT NULL,
  UNIQUE KEY `PK_Cntry_id` (`PK_Cntry_id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Res_Comp_Device_Order`
--

DROP TABLE IF EXISTS `Res_Comp_Device_Order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Res_Comp_Device_Order` (
  `Order_Id` int NOT NULL AUTO_INCREMENT,
  `Fk_Resller_Id` int DEFAULT NULL,
  `Fk_rs_cmpid` int DEFAULT NULL,
  `tot_phone_charge` float DEFAULT NULL,
  `tot_discount` float DEFAULT NULL,
  `tot_tax_fee` float DEFAULT NULL,
  `tot_charge` float DEFAULT NULL,
  `createdate` datetime(3) DEFAULT NULL,
  `Order_source` varchar(50) DEFAULT NULL,
  `Order_Status` int DEFAULT NULL,
  `plan_charge` float DEFAULT NULL,
  `Number_charge` float DEFAULT NULL,
  `product` varchar(250) DEFAULT NULL,
  `plan` varchar(60) DEFAULT NULL,
  `Duration` int DEFAULT NULL,
  `Users` int DEFAULT NULL,
  `plan_ind_amount` float DEFAULT NULL,
  `Shipping_charge` float DEFAULT NULL,
  `discount_no_of_month` int DEFAULT NULL,
  `no_of_user_purchase` int DEFAULT NULL,
  `no_of_term` int DEFAULT NULL,
  `Discount_remark` varchar(150) DEFAULT NULL,
  `plan_id` int DEFAULT NULL,
  `product_id` int DEFAULT NULL,
  `setup_price` float DEFAULT NULL,
  `setup_discount` float DEFAULT NULL,
  `platform_user_fee` float DEFAULT NULL,
  `platform_user_count` int DEFAULT NULL,
  PRIMARY KEY (`Order_Id`),
  KEY `FK__Res_Comp___Fk_Re__7C4F7684Idx` (`Fk_Resller_Id`),
  KEY `FK__Res_Comp___Fk_rs__7D439ABDIdx` (`Fk_rs_cmpid`),
  KEY `FK__Res_devic__order__0F624AF8Idx2` (`Order_Id`),
  CONSTRAINT `FK__Res_Comp___Fk_Re__7C4F7684` FOREIGN KEY (`Fk_Resller_Id`) REFERENCES `Reseller` (`Reseller_id`),
  CONSTRAINT `FK__Res_Comp___Fk_rs__7D439ABD` FOREIGN KEY (`Fk_rs_cmpid`) REFERENCES `reseller_company` (`Pk_rs_cmpid`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=1188 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Res_Comp_Device_Order_del_info`
--

DROP TABLE IF EXISTS `Res_Comp_Device_Order_del_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Res_Comp_Device_Order_del_info` (
  `Fk_Resller_Id` int DEFAULT NULL,
  `Fk_rs_cmpid` int DEFAULT NULL,
  `tot_phone_charge` float DEFAULT NULL,
  `tot_discount` float DEFAULT NULL,
  `tot_tax_fee` float DEFAULT NULL,
  `tot_charge` float DEFAULT NULL,
  `createdate` datetime(3) DEFAULT NULL,
  `Order_source` varchar(50) DEFAULT NULL,
  `Order_Status` int DEFAULT NULL,
  `plan_charge` float DEFAULT NULL,
  `Number_charge` float DEFAULT NULL,
  `product` varchar(250) DEFAULT NULL,
  `plan` varchar(60) DEFAULT NULL,
  `Duration` int DEFAULT NULL,
  `Users` int DEFAULT NULL,
  `plan_ind_amount` float DEFAULT NULL,
  `Shipping_charge` float DEFAULT NULL,
  `Order_Id` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=326 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Res_Order_delivery_address`
--

DROP TABLE IF EXISTS `Res_Order_delivery_address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Res_Order_delivery_address` (
  `sd_id` int NOT NULL AUTO_INCREMENT,
  `order_id` int DEFAULT NULL,
  `customer_name` varchar(150) DEFAULT NULL,
  `address1` varchar(150) DEFAULT NULL,
  `address2` varchar(150) DEFAULT NULL,
  `city` varchar(60) DEFAULT NULL,
  `postcode` varchar(20) DEFAULT NULL,
  `country` varchar(80) DEFAULT NULL,
  `shipping_charge` float DEFAULT NULL,
  `shipping_tax_fee` float DEFAULT NULL,
  `email` varchar(80) DEFAULT NULL,
  `mobileno` varchar(15) DEFAULT NULL,
  `billing_type` int DEFAULT NULL,
  `company_name` varchar(100) DEFAULT NULL,
  `state` varchar(80) DEFAULT NULL,
  `createdate` datetime(3) DEFAULT NULL,
  `billing_address1` varchar(250) DEFAULT NULL,
  `billing_address2` varchar(250) DEFAULT NULL,
  `billing_city` varchar(250) DEFAULT NULL,
  `billing_postcode` varchar(250) DEFAULT NULL,
  UNIQUE KEY `sd_id` (`sd_id`),
  KEY `FK__Res_Order__order__0D7A0286Idx` (`order_id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=1141 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Res_Special_bundle_req_info`
--

DROP TABLE IF EXISTS `Res_Special_bundle_req_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Res_Special_bundle_req_info` (
  `Request_id` int NOT NULL AUTO_INCREMENT,
  `Reseller_id` int DEFAULT NULL,
  `Customer_Name` varchar(30) DEFAULT NULL,
  `Customer_Email` varchar(30) DEFAULT NULL,
  `Bundle_Type` varchar(30) DEFAULT NULL,
  `Budget` varchar(30) DEFAULT NULL,
  `Customer_requirement` varchar(500) DEFAULT NULL,
  `Req_status` int DEFAULT NULL,
  `Request_date` datetime(3) DEFAULT NULL,
  `Lastupdate` datetime(3) DEFAULT NULL,
  `Admin_comment` varchar(500) DEFAULT NULL,
  UNIQUE KEY `Request_id` (`Request_id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Res_company_deal_creation`
--

DROP TABLE IF EXISTS `Res_company_deal_creation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Res_company_deal_creation` (
  `id` int NOT NULL AUTO_INCREMENT,
  `comp_user_id` int DEFAULT NULL,
  `reseller_id` int DEFAULT NULL,
  `payment_link` text,
  `hubspot_contact_id` bigint DEFAULT NULL,
  `create_date` datetime(3) DEFAULT NULL,
  `status` int DEFAULT '1',
  `approve1_user_id` int DEFAULT NULL,
  `approve1_status` int DEFAULT NULL,
  `approve1_comments` varchar(125) DEFAULT NULL,
  `approve2_user_id` int DEFAULT NULL,
  `approve2_status` int DEFAULT NULL,
  `approve2_comments` varchar(125) DEFAULT NULL,
  `approve3_user_id` int DEFAULT NULL,
  `approve3_status` int DEFAULT NULL,
  `approve3_comments` varchar(125) DEFAULT NULL,
  `approve1_created_date` datetime DEFAULT NULL,
  `approve2_created_date` datetime DEFAULT NULL,
  `approve3_created_date` datetime DEFAULT NULL,
  `tier_id` int DEFAULT NULL,
  `create_by` int DEFAULT NULL,
  `payment_method` int DEFAULT NULL,
  `payment_days` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=352 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Res_device_order_item`
--

DROP TABLE IF EXISTS `Res_device_order_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Res_device_order_item` (
  `itemid` int NOT NULL AUTO_INCREMENT,
  `order_id` int DEFAULT NULL,
  `sd_id` int DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `phone_id` varchar(100) DEFAULT NULL,
  `phone_model` varchar(100) DEFAULT NULL,
  `phone_desc` varchar(100) DEFAULT NULL,
  `price` float DEFAULT NULL,
  `weight` float DEFAULT NULL,
  `ean_no` varchar(100) DEFAULT NULL,
  `quantity` int DEFAULT NULL,
  `status` int DEFAULT NULL,
  `inventory_id` int DEFAULT NULL,
  `discount_price` float DEFAULT NULL,
  `external_number` varchar(15) DEFAULT NULL,
  `Vec_device_product_id` int DEFAULT NULL,
  UNIQUE KEY `itemid` (`itemid`),
  KEY `FK__Res_devic__order__0F624AF8Idx` (`order_id`),
  KEY `idx_order_id` (`order_id`),
  CONSTRAINT `FK__Res_devic__order__0F624AF8` FOREIGN KEY (`order_id`) REFERENCES `Res_Comp_Device_Order` (`Order_Id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=1146 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Reseller`
--

DROP TABLE IF EXISTS `Reseller`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Reseller` (
  `Reseller_id` int NOT NULL AUTO_INCREMENT,
  `Title` varchar(10) DEFAULT NULL,
  `Firstname` varchar(100) DEFAULT NULL,
  `Lastname` varchar(100) DEFAULT NULL,
  `Company_name` varchar(255) DEFAULT NULL,
  `Address1` varchar(500) DEFAULT NULL,
  `Address2` varchar(500) DEFAULT NULL,
  `City` varchar(100) DEFAULT NULL,
  `Statename` varchar(100) DEFAULT NULL,
  `Zipcode` varchar(50) DEFAULT NULL,
  `Country` varchar(100) DEFAULT NULL,
  `Phone` varchar(20) DEFAULT NULL,
  `Mobile` varchar(20) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `Fk_Reseller_Type` int DEFAULT NULL,
  `Fk_certification_Id` int DEFAULT NULL,
  `Fk_product_id` int DEFAULT NULL,
  `Fk_Vertical_id` int DEFAULT NULL,
  `Fk_Stategy_id` int DEFAULT NULL,
  `Fk_Emp_Size_id` int DEFAULT NULL,
  `Fk_Cust_Size_id` int DEFAULT NULL,
  `Fk_Comp_Size_id` int DEFAULT NULL,
  `Fk_Part_prog_id` int DEFAULT NULL,
  `Create_date` datetime(3) DEFAULT NULL,
  `Client_ip` varchar(100) DEFAULT NULL,
  `Last_Update` datetime(3) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  `Status` int DEFAULT NULL,
  `Last_login_date` datetime(3) DEFAULT NULL,
  `Last_login_ip` varchar(100) DEFAULT NULL,
  `fk_role_id` int DEFAULT NULL,
  `Fk_Reseller_Id` int DEFAULT NULL,
  `calledby` varchar(20) DEFAULT NULL,
  `fixed_inc_per` float DEFAULT NULL,
  `Inc_Tier_Type` int DEFAULT NULL,
  `var_inc_per` float DEFAULT NULL,
  `parent_rem_fixed_per` float DEFAULT NULL,
  `parent_rem_var_per` float DEFAULT NULL,
  `comments` longtext,
  `sold_to` varchar(30) DEFAULT NULL,
  `annual_gross_revenue` varchar(30) DEFAULT NULL,
  `comm_apply` int NOT NULL DEFAULT '0',
  `Hubspot_contactid` bigint DEFAULT NULL,
  `Is_Id` int DEFAULT NULL,
  `flat_no` varchar(50) DEFAULT NULL,
  `comp_reg_cert_name` varchar(100) DEFAULT NULL,
  `uq_comp_reg_cert_name` varchar(100) DEFAULT NULL,
  `Id_proof_name` text,
  `Uq_Id_proff_name` text,
  `Res_doc_status` varchar(50) DEFAULT NULL,
  `Res_pend_Rej_reason` varchar(500) DEFAULT NULL,
  `Hubspot_Owner_id` bigint DEFAULT NULL,
  `commission_status` int DEFAULT '0',
  `admin_approval` int DEFAULT '0',
  `finance_approval` int DEFAULT '0',
  `partner_type` int DEFAULT '1',
  `payment_method` int DEFAULT NULL,
  `payment_days` int DEFAULT NULL,
  PRIMARY KEY (`Reseller_id`),
  UNIQUE KEY `UK_Reseller` (`Email`),
  KEY `FK__Reseller__Fk_Cus__48CFD27EIdx` (`Fk_Cust_Size_id`),
  KEY `FK__Reseller__Fk_Emp__47DBAE45Idx` (`Fk_Emp_Size_id`),
  KEY `FK__Reseller__Fk_Par__4AB81AF0Idx` (`Fk_Part_prog_id`),
  KEY `FK__Reseller__Fk_pro__44FF419AIdx` (`Fk_product_id`),
  KEY `FK__Reseller__Fk_Res__5AEE82B9Idx` (`Fk_Reseller_Id`),
  KEY `FK__Reseller__Fk_Res__5AEE82B9Idx2` (`Reseller_id`),
  KEY `FK__Reseller__Fk_cer__440B1D61Idx` (`Fk_certification_Id`),
  KEY `FK__Reseller__fk_rol__59FA5E80Idx` (`fk_role_id`),
  KEY `FK_Reseller_status_refIdx` (`Status`),
  KEY `FK__Reseller__Fk_Res__4316F928Idx` (`Fk_Reseller_Type`),
  KEY `FK__Reseller__Fk_Sta__46E78A0CIdx` (`Fk_Stategy_id`),
  KEY `FK__Reseller__Fk_Com__49C3F6B7Idx` (`Fk_Comp_Size_id`),
  KEY `FK__Reseller__Fk_Ver__45F365D3Idx` (`Fk_Vertical_id`),
  CONSTRAINT `FK__Reseller__Fk_cer__440B1D61` FOREIGN KEY (`Fk_certification_Id`) REFERENCES `Reseller_certification_Master` (`Pk_certification_id`),
  CONSTRAINT `FK__Reseller__Fk_Com__49C3F6B7` FOREIGN KEY (`Fk_Comp_Size_id`) REFERENCES `Sell_Company_Size_Master` (`Pk_company_size_id`),
  CONSTRAINT `FK__Reseller__Fk_Cus__48CFD27E` FOREIGN KEY (`Fk_Cust_Size_id`) REFERENCES `Cust_Size_info_Master` (`Pk_cust_Size_Id`),
  CONSTRAINT `FK__Reseller__Fk_Emp__47DBAE45` FOREIGN KEY (`Fk_Emp_Size_id`) REFERENCES `Employee_Size_Master` (`Pk_Emp_Size_Id`),
  CONSTRAINT `FK__Reseller__Fk_Par__4AB81AF0` FOREIGN KEY (`Fk_Part_prog_id`) REFERENCES `Partner_Program_Master` (`Pk_Program_id`),
  CONSTRAINT `FK__Reseller__Fk_pro__44FF419A` FOREIGN KEY (`Fk_product_id`) REFERENCES `resell_product_Master` (`product_id`),
  CONSTRAINT `FK__Reseller__Fk_Res__4316F928` FOREIGN KEY (`Fk_Reseller_Type`) REFERENCES `Reseller_type_Master` (`Pk_Reseller_Type`),
  CONSTRAINT `FK__Reseller__Fk_Res__5AEE82B9` FOREIGN KEY (`Fk_Reseller_Id`) REFERENCES `Reseller` (`Reseller_id`),
  CONSTRAINT `FK__Reseller__fk_rol__59FA5E80` FOREIGN KEY (`fk_role_id`) REFERENCES `Reseller_role` (`Pk_role_id`),
  CONSTRAINT `FK__Reseller__Fk_Sta__46E78A0C` FOREIGN KEY (`Fk_Stategy_id`) REFERENCES `Sales_Stategy_Master` (`Stategy_id`),
  CONSTRAINT `FK__Reseller__Fk_Ver__45F365D3` FOREIGN KEY (`Fk_Vertical_id`) REFERENCES `Vertical_Master` (`Vertical_id`),
  CONSTRAINT `FK_Reseller_status_ref` FOREIGN KEY (`Status`) REFERENCES `Reseller_status_ref` (`status_id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=1974 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Reseller_Bank_KYC_Info`
--

DROP TABLE IF EXISTS `Reseller_Bank_KYC_Info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Reseller_Bank_KYC_Info` (
  `KYC_id` int NOT NULL AUTO_INCREMENT,
  `Reseller_Id` int DEFAULT NULL,
  `Bank_Name` varchar(50) DEFAULT NULL,
  `Branch` varchar(100) DEFAULT NULL,
  `IFSC` varchar(25) DEFAULT NULL,
  `Account_Number` varchar(50) DEFAULT NULL,
  `Acc_Holder_Name` varchar(50) DEFAULT NULL,
  `Account_Type` varchar(100) DEFAULT NULL,
  `Status` int DEFAULT NULL,
  `Create_date` datetime(3) DEFAULT NULL,
  `Last_update` datetime(3) DEFAULT NULL,
  `Country` varchar(20) DEFAULT NULL,
  `City` varchar(20) DEFAULT NULL,
  `Sort_code` varchar(20) DEFAULT NULL,
  `BIC_number` varchar(25) DEFAULT NULL,
  UNIQUE KEY `KYC_id` (`KYC_id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=627 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Reseller_Comp_Emg_info`
--

DROP TABLE IF EXISTS `Reseller_Comp_Emg_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Reseller_Comp_Emg_info` (
  `Pk_EmgId` int NOT NULL,
  `Fk_Pk_rs_cmpid` int DEFAULT NULL,
  `Contact_name` varchar(150) DEFAULT NULL,
  `Address1` varchar(250) DEFAULT NULL,
  `Address2` varchar(250) DEFAULT NULL,
  `Phone_No` varchar(20) DEFAULT NULL,
  `Email_Id` varchar(80) DEFAULT NULL,
  `Country` varchar(80) DEFAULT NULL,
  `State` varchar(80) DEFAULT NULL,
  `City` varchar(80) DEFAULT NULL,
  `postcode` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`Pk_EmgId`),
  KEY `FK__Reseller___Fk_Pk__6FE99F9FIdx` (`Fk_Pk_rs_cmpid`),
  CONSTRAINT `FK__Reseller___Fk_Pk__6FE99F9F` FOREIGN KEY (`Fk_Pk_rs_cmpid`) REFERENCES `reseller_company` (`Pk_rs_cmpid`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Reseller_Date_range`
--

DROP TABLE IF EXISTS `Reseller_Date_range`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Reseller_Date_range` (
  `date_id` int NOT NULL AUTO_INCREMENT,
  `date_range` varchar(20) DEFAULT NULL,
  UNIQUE KEY `date_id` (`date_id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Reseller_Lead_details`
--

DROP TABLE IF EXISTS `Reseller_Lead_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Reseller_Lead_details` (
  `Lead_id` int NOT NULL AUTO_INCREMENT,
  `Hubspot_contactd` bigint DEFAULT NULL,
  `Fk_Reseller_id` int DEFAULT NULL,
  `First_name` varchar(100) DEFAULT NULL,
  `Last_name` varchar(100) DEFAULT NULL,
  `Email_id` varchar(100) DEFAULT NULL,
  `Phone_number` varchar(25) DEFAULT NULL,
  `address1` varchar(500) DEFAULT NULL,
  `street_address` varchar(500) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `post_code` varchar(50) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `industry` varchar(100) DEFAULT NULL,
  `company_name` varchar(100) DEFAULT NULL,
  `company_domain` varchar(100) DEFAULT NULL,
  `contact_owner` varchar(100) DEFAULT NULL,
  `Employeee_count` int DEFAULT NULL,
  `Lead_createdate` datetime(3) DEFAULT NULL,
  `Lead_source` varchar(500) DEFAULT NULL,
  `status` int DEFAULT NULL,
  `Fk_rs_cmpid` int DEFAULT NULL,
  PRIMARY KEY (`Lead_id`),
  KEY `FK__Reseller___Fk_Re__084B3915Idx` (`Fk_Reseller_id`),
  KEY `FK__Reseller___Fk_rs__0B27A5C0Idx` (`Fk_rs_cmpid`),
  CONSTRAINT `FK__Reseller___Fk_Re__084B3915` FOREIGN KEY (`Fk_Reseller_id`) REFERENCES `Reseller` (`Reseller_id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Reseller_Payment_Info`
--

DROP TABLE IF EXISTS `Reseller_Payment_Info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Reseller_Payment_Info` (
  `Paylogid` int NOT NULL AUTO_INCREMENT,
  `Paydate` datetime(3) DEFAULT NULL,
  `Pay_Reference` varchar(80) DEFAULT NULL,
  `Pay_Status` varchar(100) DEFAULT NULL,
  `card_type` varchar(50) DEFAULT NULL,
  `Reseller_Id` int DEFAULT NULL,
  `Res_Comp_Id` int DEFAULT NULL,
  `Vpcp_Comp_Id` int DEFAULT NULL,
  `Pay_Amount` float DEFAULT NULL,
  `cc_number` varchar(10) DEFAULT NULL,
  `Plan_amunt` float DEFAULT NULL,
  `No_user` int DEFAULT NULL,
  PRIMARY KEY (`Paylogid`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=613 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Reseller_certification_Master`
--

DROP TABLE IF EXISTS `Reseller_certification_Master`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Reseller_certification_Master` (
  `Pk_certification_id` int NOT NULL,
  `certification` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`Pk_certification_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Reseller_commisson_info`
--

DROP TABLE IF EXISTS `Reseller_commisson_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Reseller_commisson_info` (
  `Reseller_Id` int NOT NULL,
  `Total_Purchase_amount` float DEFAULT NULL,
  `Comm_per` float DEFAULT NULL,
  `Company_Id` int NOT NULL,
  `Comm_amount` float DEFAULT NULL,
  `Comm_date` datetime(3) DEFAULT NULL,
  `Comm_assigned_by` varchar(50) DEFAULT NULL,
  `Status` int DEFAULT NULL,
  `Reseller_level` int DEFAULT NULL,
  `parent_Reseller_id` int DEFAULT NULL,
  `Tier_Id` int DEFAULT NULL,
  `fixed_per` int DEFAULT NULL,
  `fixed_comm_amount` float DEFAULT NULL,
  `fixed_inc_per` float DEFAULT NULL,
  `var_inc_per_assigned` float DEFAULT NULL,
  `Inc_Tier_Type` float DEFAULT NULL,
  `var_per_comm` float DEFAULT NULL,
  `my_comm` float DEFAULT NULL,
  `domain_id` int DEFAULT NULL,
  `Pay_Reference_No` varchar(80) DEFAULT NULL,
  `commison_earned` float DEFAULT NULL,
  `Master_mycomm` float DEFAULT NULL,
  `Res_mycomm` float DEFAULT NULL,
  `Master_subres_comm` float DEFAULT NULL,
  `plan_Type_ID` int DEFAULT NULL,
  `Scheme_ID` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  `remarks` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=490 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Reseller_commisson_structure`
--

DROP TABLE IF EXISTS `Reseller_commisson_structure`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Reseller_commisson_structure` (
  `id` int NOT NULL AUTO_INCREMENT,
  `commisson_structure` varchar(30) DEFAULT NULL,
  UNIQUE KEY `id` (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Reseller_incentive_Config`
--

DROP TABLE IF EXISTS `Reseller_incentive_Config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Reseller_incentive_Config` (
  `Reseller_Id` int NOT NULL,
  `Typeid` int NOT NULL,
  `Inc_app_Month` int DEFAULT NULL,
  `inc_percentage` float DEFAULT NULL,
  `After_Inc_apply_Month_Per` float DEFAULT NULL,
  `create_Date` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`Reseller_Id`,`Typeid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Reseller_incentive_Config_log`
--

DROP TABLE IF EXISTS `Reseller_incentive_Config_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Reseller_incentive_Config_log` (
  `Reseller_Id` int NOT NULL,
  `Typeid` int NOT NULL,
  `Inc_app_Month` int DEFAULT NULL,
  `inc_percentage` float DEFAULT NULL,
  `After_Inc_apply_Month_Per` float DEFAULT NULL,
  `create_Date` datetime(3) DEFAULT NULL,
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=1796 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Reseller_role`
--

DROP TABLE IF EXISTS `Reseller_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Reseller_role` (
  `Pk_role_id` int NOT NULL,
  `role_name` varchar(50) DEFAULT NULL,
  `role_status` int NOT NULL,
  PRIMARY KEY (`Pk_role_id`),
  KEY `FK__Reseller__fk_rol__59FA5E80Idx2` (`Pk_role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Reseller_status_ref`
--

DROP TABLE IF EXISTS `Reseller_status_ref`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Reseller_status_ref` (
  `status_id` int NOT NULL,
  `status` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Reseller_type_Master`
--

DROP TABLE IF EXISTS `Reseller_type_Master`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Reseller_type_Master` (
  `Pk_Reseller_Type` int NOT NULL,
  `Reseller_Type` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`Pk_Reseller_Type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Sales_Stategy_Master`
--

DROP TABLE IF EXISTS `Sales_Stategy_Master`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Sales_Stategy_Master` (
  `Stategy_id` int NOT NULL,
  `Stategy_name` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`Stategy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Sell_Company_Size_Master`
--

DROP TABLE IF EXISTS `Sell_Company_Size_Master`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Sell_Company_Size_Master` (
  `Pk_company_size_id` int NOT NULL,
  `Comp_size_name` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`Pk_company_size_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `URResellerLogs_1`
--

DROP TABLE IF EXISTS `URResellerLogs_1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `URResellerLogs_1` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Application` longtext NOT NULL,
  `Logged` datetime(3) NOT NULL,
  `Level` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `Message` longtext NOT NULL,
  `Logger` longtext NOT NULL,
  `CallSite` longtext NOT NULL,
  `Exception` longtext NOT NULL,
  PRIMARY KEY (`Id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Vertical_Master`
--

DROP TABLE IF EXISTS `Vertical_Master`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Vertical_Master` (
  `Vertical_id` int NOT NULL,
  `Vertical_name` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`Vertical_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `my_check_comm`
--

DROP TABLE IF EXISTS `my_check_comm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `my_check_comm` (
  `parent_commisson` float DEFAULT NULL,
  `var_per_comm` float DEFAULT NULL,
  `Total_revenue` float DEFAULT NULL,
  `org_Reseller_Id` int DEFAULT NULL,
  `Company_Id` int DEFAULT NULL,
  `amount` float DEFAULT NULL,
  `my_var_comm` float DEFAULT NULL,
  `tcommisson` float DEFAULT NULL,
  `Pay_Reference_No` varchar(150) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `res_comp_mobileno_info`
--

DROP TABLE IF EXISTS `res_comp_mobileno_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `res_comp_mobileno_info` (
  `id` int NOT NULL AUTO_INCREMENT,
  `msisdn` varchar(20) DEFAULT NULL,
  `reseller_id` int DEFAULT NULL,
  `fk_rs_cmpid` int DEFAULT NULL,
  `create_date` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK__res_comp___fk_rs__7DCDAAA2Idx` (`fk_rs_cmpid`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=1478 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `res_temp_id`
--

DROP TABLE IF EXISTS `res_temp_id`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `res_temp_id` (
  `id` int NOT NULL AUTO_INCREMENT,
  `Reseller_Id` int DEFAULT NULL,
  `comp_user_id` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=525 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `res_ur_ecom_pymt_dtls`
--

DROP TABLE IF EXISTS `res_ur_ecom_pymt_dtls`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `res_ur_ecom_pymt_dtls` (
  `Orderid` int NOT NULL,
  `comp_id` int DEFAULT NULL,
  `company_name` varchar(100) DEFAULT NULL,
  `reseller_id` int DEFAULT NULL,
  `Pay_Reference_No` varchar(50) DEFAULT NULL,
  `order_value` float DEFAULT NULL,
  `Pay_Status` varchar(250) DEFAULT NULL,
  `Pay_Amount` float DEFAULT NULL,
  `Product` varchar(255) DEFAULT NULL,
  `Pay_Remarks` varchar(255) DEFAULT NULL,
  `Plan` varchar(60) DEFAULT NULL,
  `Duration` int DEFAULT NULL,
  `ip_address` varchar(15) DEFAULT NULL,
  `cc_number` varchar(6) DEFAULT NULL,
  `Ord_Price_with_tax` float DEFAULT NULL,
  `Manage_Order` int DEFAULT NULL,
  `card_type` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`Orderid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `resell_product_Master`
--

DROP TABLE IF EXISTS `resell_product_Master`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `resell_product_Master` (
  `product_id` int NOT NULL,
  `product_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `reseller_addon_purchase_info`
--

DROP TABLE IF EXISTS `reseller_addon_purchase_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reseller_addon_purchase_info` (
  `id` int NOT NULL AUTO_INCREMENT,
  `comp_user_id` int DEFAULT NULL,
  `company_id` int DEFAULT NULL,
  `plan_id` int DEFAULT NULL,
  `jsonAddonInfo` json DEFAULT NULL,
  `addon_total_charge` float DEFAULT NULL,
  `addon_total_chargewithout_tax` float DEFAULT NULL,
  `addon_Pay_Reference` varchar(50) DEFAULT NULL,
  `addon_tax_per` float DEFAULT NULL,
  `addon_tax_fee` float DEFAULT NULL,
  `createAt` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=490 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `reseller_company`
--

DROP TABLE IF EXISTS `reseller_company`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reseller_company` (
  `Pk_rs_cmpid` int NOT NULL AUTO_INCREMENT,
  `Title` varchar(100) DEFAULT NULL,
  `first_name` varchar(150) DEFAULT NULL,
  `last_name` varchar(150) DEFAULT NULL,
  `company_name` varchar(255) DEFAULT NULL,
  `address_1` varchar(250) DEFAULT NULL,
  `address_2` varchar(250) DEFAULT NULL,
  `city` varchar(60) DEFAULT NULL,
  `state` varchar(60) DEFAULT NULL,
  `zip_code` varchar(20) DEFAULT NULL,
  `country` varchar(30) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `mobileno` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `create_date` datetime(3) DEFAULT NULL,
  `status` int DEFAULT NULL,
  `reseller_id` int DEFAULT NULL,
  `cnt_ref_id` int DEFAULT NULL,
  `Vpcp_Company_Id` int DEFAULT NULL,
  `domain_Id` int DEFAULT NULL,
  `paid_amount` float DEFAULT NULL,
  `paid_reference` varchar(80) DEFAULT NULL,
  `free_trail` int DEFAULT NULL,
  `plan_id` int DEFAULT NULL,
  `plan_Billing_cycle` int DEFAULT NULL,
  `plan_Type_ID` int DEFAULT NULL,
  `Myacc_Password` varchar(50) DEFAULT NULL,
  `avail_number` varchar(20) DEFAULT NULL,
  `Hubspot_companyid` bigint DEFAULT NULL,
  `Hubspot_contactid` bigint DEFAULT NULL,
  `Plan_amount` float DEFAULT NULL,
  `No_user` int DEFAULT NULL,
  `num_country` varchar(150) DEFAULT NULL,
  `num_citycode` varchar(250) DEFAULT NULL,
  `num_Type` varchar(150) DEFAULT NULL,
  `addon_price` float DEFAULT NULL,
  `addon_bundleid` int DEFAULT NULL,
  `mobileno_price` float DEFAULT NULL,
  `addon_bun_price` float DEFAULT NULL,
  `Ref_Lead_id` int DEFAULT NULL,
  `Num_city_id` int DEFAULT NULL,
  `dept_id` int DEFAULT NULL,
  `sales_id` int DEFAULT NULL,
  PRIMARY KEY (`Pk_rs_cmpid`),
  KEY `FK__reseller___resel__6A30C649Idx` (`reseller_id`),
  KEY `reseller_company_idx2` (`Vpcp_Company_Id`),
  KEY `idx_email` (`email`),
  KEY `idx_reseller_id` (`reseller_id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=1217 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `reseller_company_del_info`
--

DROP TABLE IF EXISTS `reseller_company_del_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reseller_company_del_info` (
  `Title` varchar(100) DEFAULT NULL,
  `first_name` varchar(150) DEFAULT NULL,
  `last_name` varchar(150) DEFAULT NULL,
  `company_name` varchar(100) DEFAULT NULL,
  `address_1` varchar(100) DEFAULT NULL,
  `address_2` varchar(100) DEFAULT NULL,
  `city` varchar(60) DEFAULT NULL,
  `state` varchar(60) DEFAULT NULL,
  `zip_code` varchar(20) DEFAULT NULL,
  `country` varchar(30) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `mobileno` varchar(20) DEFAULT NULL,
  `email` varchar(64) DEFAULT NULL,
  `create_date` datetime(3) DEFAULT NULL,
  `status` int DEFAULT NULL,
  `reseller_id` int DEFAULT NULL,
  `cnt_ref_id` int DEFAULT NULL,
  `Vpcp_Company_Id` int DEFAULT NULL,
  `domain_Id` int DEFAULT NULL,
  `paid_amount` float DEFAULT NULL,
  `paid_reference` varchar(80) DEFAULT NULL,
  `free_trail` int DEFAULT NULL,
  `plan_id` int DEFAULT NULL,
  `plan_Billing_cycle` int DEFAULT NULL,
  `plan_Type_ID` int DEFAULT NULL,
  `Myacc_Password` varchar(50) DEFAULT NULL,
  `avail_number` varchar(20) DEFAULT NULL,
  `Hubspot_companyid` bigint DEFAULT NULL,
  `Hubspot_contactid` bigint DEFAULT NULL,
  `Pk_rs_cmpid` int DEFAULT NULL,
  `delete_date` datetime(3) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=423 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `reseller_incentive_config_agnet`
--

DROP TABLE IF EXISTS `reseller_incentive_config_agnet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reseller_incentive_config_agnet` (
  `Reseller_Id` int NOT NULL,
  `Typeid` int NOT NULL,
  `Inc_app_Month` int DEFAULT NULL,
  `inc_percentage` float DEFAULT NULL,
  `After_Inc_apply_Month_Per` float DEFAULT NULL,
  `create_Date` datetime(3) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=148 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `reseller_incentive_config_employee`
--

DROP TABLE IF EXISTS `reseller_incentive_config_employee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reseller_incentive_config_employee` (
  `Reseller_Id` int NOT NULL,
  `Typeid` int NOT NULL,
  `Inc_app_Month` int DEFAULT NULL,
  `inc_percentage` float DEFAULT NULL,
  `After_Inc_apply_Month_Per` float DEFAULT NULL,
  `create_Date` datetime(3) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=78 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `reseller_license_based_config_dtl`
--

DROP TABLE IF EXISTS `reseller_license_based_config_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reseller_license_based_config_dtl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `reseller_id` int DEFAULT NULL,
  `plan_id` int DEFAULT NULL,
  `duration` int DEFAULT NULL,
  `user_price` float DEFAULT NULL,
  `discount_user_price` float DEFAULT NULL,
  `platform_fee` int DEFAULT NULL,
  `discount_platform_fee` float DEFAULT NULL,
  `setup_fee` int DEFAULT NULL,
  `discount_setup_fee` float DEFAULT NULL,
  `product_id` int DEFAULT NULL,
  `create_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `is_active` tinyint DEFAULT '1',
  PRIMARY KEY (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=1234 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `reseller_license_based_platform_fee_json_dtl`
--

DROP TABLE IF EXISTS `reseller_license_based_platform_fee_json_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reseller_license_based_platform_fee_json_dtl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `reseller_id` int DEFAULT NULL,
  `tier_id` int DEFAULT NULL,
  `product_id` int DEFAULT NULL,
  `platform_fee_name` varchar(150) DEFAULT NULL,
  `platform_fee_month_price` float DEFAULT NULL,
  `platform_fee_month_discount_price` float DEFAULT NULL,
  `platform_fee_yearly_price` float DEFAULT NULL,
  `platform_fee_yearly_discount_price` float DEFAULT NULL,
  `platform_fee_count` int DEFAULT NULL,
  `create_date` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=439 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `reseller_main_approveall_commission_audit`
--

DROP TABLE IF EXISTS `reseller_main_approveall_commission_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reseller_main_approveall_commission_audit` (
  `id` int NOT NULL AUTO_INCREMENT,
  `reseller_id` int DEFAULT NULL,
  `total_revenue` float DEFAULT NULL,
  `total_commision` float DEFAULT NULL,
  `from_date` varchar(10) DEFAULT NULL,
  `to_date` varchar(10) DEFAULT NULL,
  `docfileurl` text,
  `docuploaddate` datetime DEFAULT NULL,
  `docstatus` int DEFAULT NULL,
  `approveid` int DEFAULT NULL,
  `createAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  `invoice_amount` float DEFAULT NULL,
  `remarks` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `reseller_notification_details`
--

DROP TABLE IF EXISTS `reseller_notification_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reseller_notification_details` (
  `id` int NOT NULL AUTO_INCREMENT,
  `reseller_id` int DEFAULT NULL,
  `Partner_type` int DEFAULT NULL,
  `type_of_method` varchar(225) DEFAULT NULL,
  `is_read_flag` int DEFAULT (0),
  `create_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `parent_partner_id` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2705 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `reseller_partner_order_form`
--

DROP TABLE IF EXISTS `reseller_partner_order_form`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reseller_partner_order_form` (
  `id` int NOT NULL AUTO_INCREMENT,
  `reseller_id` int DEFAULT NULL,
  `title` varchar(10) DEFAULT NULL,
  `firstname` varchar(100) DEFAULT NULL,
  `lastname` varchar(100) DEFAULT NULL,
  `company_name` varchar(100) DEFAULT NULL,
  `address1` varchar(500) DEFAULT NULL,
  `address2` varchar(500) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `statename` varchar(100) DEFAULT NULL,
  `zipcode` varchar(50) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `mobile` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `plan_id` int DEFAULT NULL,
  `product_id` int DEFAULT NULL,
  `plan_Billing_cycle` int DEFAULT NULL,
  `users` int DEFAULT NULL,
  `status` int DEFAULT NULL,
  `approves_status` int DEFAULT NULL,
  `create_by` int DEFAULT NULL,
  `create_on` datetime DEFAULT NULL,
  `company_id` int DEFAULT NULL,
  `New_plan_id` int DEFAULT NULL,
  `Plan_price` float DEFAULT NULL,
  `Plan_name` varchar(100) DEFAULT NULL,
  `Plan_total_amount` float DEFAULT NULL,
  `approve1_user_id` int DEFAULT NULL,
  `approve1_comments` varchar(125) DEFAULT NULL,
  `approve2_user_id` int DEFAULT NULL,
  `approve2_comments` varchar(125) DEFAULT NULL,
  `approve3_user_id` int DEFAULT NULL,
  `approve3_comments` varchar(125) DEFAULT NULL,
  `term_conditions` longtext,
  `customer_url` text,
  `customer_update_date` datetime DEFAULT NULL,
  `director_url` text,
  `director_update_date` datetime DEFAULT NULL,
  `docusign_status` int DEFAULT NULL,
  `customer_form_url` text,
  `website_purpose` int DEFAULT NULL,
  `customer_messages` text,
  `fk_reseller_id` int DEFAULT NULL,
  `designation` varchar(150) DEFAULT NULL,
  `Campaign_id` bigint DEFAULT NULL,
  `source_url` text,
  `summary` text,
  `companyUrl` text,
  PRIMARY KEY (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=14560 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `reseller_plan_type`
--

DROP TABLE IF EXISTS `reseller_plan_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reseller_plan_type` (
  `Typeid` int NOT NULL,
  `TypeName` varchar(100) DEFAULT NULL,
  `Status` int DEFAULT NULL,
  `Is_monthly_Year` int DEFAULT NULL,
  `Inc_app_Month` int DEFAULT NULL,
  `inc_percentage` int DEFAULT NULL,
  `After_Inc_apply_Month_Per` float DEFAULT NULL,
  `Plan_duration` int DEFAULT NULL,
  `Is_paid_once` int NOT NULL,
  PRIMARY KEY (`Typeid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `reseller_submission_status`
--

DROP TABLE IF EXISTS `reseller_submission_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reseller_submission_status` (
  `subm_id` int DEFAULT NULL,
  `subm_status` varchar(20) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `reseller_to_customer_license_based_config_dtl`
--

DROP TABLE IF EXISTS `reseller_to_customer_license_based_config_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reseller_to_customer_license_based_config_dtl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `reseller_id` int DEFAULT NULL,
  `company_id` int DEFAULT NULL,
  `plan_id` int DEFAULT NULL,
  `current_plan_price` float DEFAULT NULL,
  `reseller_plan_price` float DEFAULT NULL,
  `reseller_to_customer_plan_price` float DEFAULT NULL,
  `create_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `is_active` tinyint DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sme_Reseller_Tier`
--

DROP TABLE IF EXISTS `sme_Reseller_Tier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sme_Reseller_Tier` (
  `Tier_Id` int NOT NULL AUTO_INCREMENT,
  `Tier_Name` varchar(250) DEFAULT NULL,
  `Tier_min` float NOT NULL,
  `Tier_To` float NOT NULL,
  `Commission` float DEFAULT NULL,
  `Create_By` varchar(50) DEFAULT NULL,
  `Create_date` datetime(3) DEFAULT NULL,
  `last_Update` datetime(3) DEFAULT NULL,
  `Status` int DEFAULT NULL,
  `variable_per` float DEFAULT NULL,
  `varaible_per` int DEFAULT NULL,
  `Tier_type` int DEFAULT NULL,
  PRIMARY KEY (`Tier_Id`),
  KEY `U_Idx1` (`Create_By`,`Tier_min`,`Tier_To`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=85 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sme_reseller_company_admin_user`
--

DROP TABLE IF EXISTS `sme_reseller_company_admin_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sme_reseller_company_admin_user` (
  `login_id` int NOT NULL AUTO_INCREMENT,
  `first_name` varchar(64) DEFAULT NULL,
  `last_name` varchar(64) DEFAULT NULL,
  `email_id` varchar(64) DEFAULT NULL,
  `password` varchar(15) DEFAULT NULL,
  `phone_no` varchar(15) DEFAULT NULL,
  `emp_no` varchar(8) DEFAULT NULL,
  `status` int DEFAULT NULL,
  `create_date` datetime(3) DEFAULT NULL,
  `modify_date` datetime(3) DEFAULT NULL,
  `role_id` int DEFAULT NULL,
  `Hubspot_contactid` bigint DEFAULT NULL,
  `dept_id` int DEFAULT NULL,
  UNIQUE KEY `login_id` (`login_id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sme_reseller_mycommission_calc_log`
--

DROP TABLE IF EXISTS `sme_reseller_mycommission_calc_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sme_reseller_mycommission_calc_log` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `reseller_id` int DEFAULT NULL,
  `company_id` int DEFAULT NULL,
  `paid_amount` float DEFAULT NULL,
  `Total_revenue` float DEFAULT NULL,
  `fixed_inc_per` float DEFAULT NULL,
  `var_inc_per_assigned` float DEFAULT NULL,
  `Inc_Tier_Type` int DEFAULT NULL,
  `var_per_comm` float DEFAULT NULL,
  `domain_id` int DEFAULT NULL,
  `Pay_Reference_No` varchar(80) DEFAULT NULL,
  `my_comm` float DEFAULT NULL,
  `CREATE_DATE` datetime(3) DEFAULT NULL,
  `Users` int DEFAULT NULL,
  `Price` float DEFAULT NULL,
  `new_tax` float DEFAULT NULL,
  `new_revenue` float DEFAULT NULL,
  `my_parent_total` float DEFAULT NULL,
  UNIQUE KEY `ID` (`ID`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sme_reseller_variable_percentage`
--

DROP TABLE IF EXISTS `sme_reseller_variable_percentage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sme_reseller_variable_percentage` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `reseller_id` int DEFAULT NULL,
  `between_from` int DEFAULT NULL,
  `between_to` int DEFAULT NULL,
  `apply_per` float DEFAULT NULL,
  UNIQUE KEY `ID` (`ID`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `smereseller_company_approval_management`
--

DROP TABLE IF EXISTS `smereseller_company_approval_management`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `smereseller_company_approval_management` (
  `id` int NOT NULL AUTO_INCREMENT,
  `company_id` int DEFAULT NULL,
  `approver_1_resellerid` int DEFAULT NULL,
  `approver_1_status` varchar(50) DEFAULT NULL,
  `approver_1_approved_on` datetime(3) DEFAULT NULL,
  `approver_1_remarks` varchar(250) DEFAULT NULL,
  `approver_2_resellerid` int DEFAULT NULL,
  `approver_2_status` varchar(50) DEFAULT NULL,
  `approver_2_approved_on` datetime(3) DEFAULT NULL,
  `approver_2_remarks` varchar(250) DEFAULT NULL,
  `approver_1_username` varchar(50) DEFAULT NULL,
  `approver_2_username` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=526 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `special_bun_req_status_ref`
--

DROP TABLE IF EXISTS `special_bun_req_status_ref`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `special_bun_req_status_ref` (
  `status_id` int DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_test`
--

DROP TABLE IF EXISTS `tbl_test`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_test` (
  `id` int DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `Fk_Id` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `temp_partner_form_status`
--

DROP TABLE IF EXISTS `temp_partner_form_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `temp_partner_form_status` (
  `statusName` varchar(30) NOT NULL,
  `counts` int DEFAULT '0',
  PRIMARY KEY (`statusName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `temp_reseller_form_status`
--

DROP TABLE IF EXISTS `temp_reseller_form_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `temp_reseller_form_status` (
  `statusName` varchar(50) NOT NULL,
  `counts` int DEFAULT NULL,
  PRIMARY KEY (`statusName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `test_pay`
--

DROP TABLE IF EXISTS `test_pay`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `test_pay` (
  `reseller_id` int DEFAULT NULL,
  `Pay_Amount` float DEFAULT NULL,
  `Usr_Id` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tt_new_reseller_id`
--

DROP TABLE IF EXISTS `tt_new_reseller_id`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tt_new_reseller_id` (
  `reseller_id` int NOT NULL,
  PRIMARY KEY (`reseller_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tt_reseller_cnt_id`
--

DROP TABLE IF EXISTS `tt_reseller_cnt_id`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tt_reseller_cnt_id` (
  `id` int NOT NULL AUTO_INCREMENT,
  `Cnt_ReffID` int DEFAULT NULL,
  `errcode` int DEFAULT NULL,
  `errmsg` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tt_reseller_list1`
--

DROP TABLE IF EXISTS `tt_reseller_list1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tt_reseller_list1` (
  `reseller_id` int NOT NULL,
  PRIMARY KEY (`reseller_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tt_reseller_list12`
--

DROP TABLE IF EXISTS `tt_reseller_list12`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tt_reseller_list12` (
  `reseller_id` int NOT NULL,
  PRIMARY KEY (`reseller_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tt_t6345392`
--

DROP TABLE IF EXISTS `tt_t6345392`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tt_t6345392` (
  `reseller_id` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`),
  KEY `reseller_id` (`reseller_id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tt_t6354030`
--

DROP TABLE IF EXISTS `tt_t6354030`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tt_t6354030` (
  `reseller_id` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`),
  KEY `reseller_id` (`reseller_id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tt_t6354757`
--

DROP TABLE IF EXISTS `tt_t6354757`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tt_t6354757` (
  `reseller_id` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`),
  KEY `reseller_id` (`reseller_id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tt_t6354827`
--

DROP TABLE IF EXISTS `tt_t6354827`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tt_t6354827` (
  `reseller_id` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`),
  KEY `reseller_id` (`reseller_id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tt_t6359364`
--

DROP TABLE IF EXISTS `tt_t6359364`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tt_t6359364` (
  `id` int NOT NULL AUTO_INCREMENT,
  `reseller_id` int DEFAULT NULL,
  `idpk` int NOT NULL,
  PRIMARY KEY (`idpk`),
  KEY `id` (`id`,`reseller_id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tt_t6399364`
--

DROP TABLE IF EXISTS `tt_t6399364`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tt_t6399364` (
  `reseller_id` int NOT NULL,
  PRIMARY KEY (`reseller_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tt_temp_reseller_info`
--

DROP TABLE IF EXISTS `tt_temp_reseller_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tt_temp_reseller_info` (
  `id` int NOT NULL AUTO_INCREMENT,
  `reseller_id` int DEFAULT NULL,
  `parent_reseller_id` int DEFAULT NULL,
  `reseller_role` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tt_tmycommmycomm`
--

DROP TABLE IF EXISTS `tt_tmycommmycomm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tt_tmycommmycomm` (
  `reseller_id` int NOT NULL,
  PRIMARY KEY (`reseller_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping events for database 'smereseller'
--

--
-- Dumping routines for database 'smereseller'
--
/*!50003 DROP FUNCTION IF EXISTS `fn_get_country_formated_number` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` FUNCTION `fn_get_country_formated_number`(did VARCHAR(20)) RETURNS varchar(20) CHARSET utf8mb4
    DETERMINISTIC
begin

     

   DECLARE v_country_prefix VARCHAR(4);
   DECLARE v_prefix_len INT; 
	
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   phonecode INTO v_country_prefix from unifiedring.ur_country_config where phonecode = left(did, CHAR_LENGTH(phonecode))
   and IFNULL(is_national,0) = 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
	
   if IFNULL(v_country_prefix,'') <> '' then
      set did = insert(did,1, CHAR_LENGTH(v_country_prefix),'0');
   end if;
		
		
   if did is null then
      set did = '';
   end if;

   return   did;  
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `getdealapprovalusername` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` FUNCTION `getdealapprovalusername`(userid int) RETURNS longtext CHARSET utf8mb4
    DETERMINISTIC
Begin
	DECLARE v_output LONGTEXT;
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
		select concat(a.first_name,' ',a.last_name) into v_output from smereseller.sme_reseller_company_admin_user a where login_id = userid limit 1;
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    RETURN v_output;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `parent_reseller_name` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` FUNCTION `parent_reseller_name`(parent_Reseller_id INT) RETURNS longtext CHARSET utf8mb4
    DETERMINISTIC
begin
    DECLARE v_output LONGTEXT;  
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select(CONCAT(Firstname,' ',Lastname)) INTO v_output from Reseller a where a.Reseller_id = parent_Reseller_id;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
    return v_output;  
    
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `report_mycomm` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` FUNCTION `report_mycomm`(reseller_id INT,login_reseller_id INT) RETURNS longtext CHARSET utf8mb4
    DETERMINISTIC
Begin
  
     DECLARE v_output FLOAT;  
     DECLARE v_fk_role_id INT;
     DECLARE v_login_user_purchase FLOAT;
     DECLARE v_login_role_id INT;
     DECLARE v_own_purchased_amount FLOAT;  
     DECLARE v_m_others_purchased_amount FLOAT;
     DECLARE v_r_others_purchased_amount FLOAT;
     DECLARE v_s_others_purchased_amount FLOAT;  
    
   DROP TEMPORARY TABLE IF EXISTS tt_reseller_list;
     CREATE TEMPORARY TABLE tt_reseller_list
     (
        reseller_id INT,
        role_id INT,
        own_purchased_amount FLOAT
     );
  
     DROP TEMPORARY TABLE IF EXISTS tt_reseller_list_2;
     CREATE TEMPORARY TABLE tt_reseller_list_2
     (
        reseller_id INT,
        role_id INT,
        others_purchased_amount FLOAT
     );
     
     DROP TEMPORARY TABLE IF EXISTS tt_reseller_list_3;
     CREATE TEMPORARY TABLE tt_reseller_list_3
     (
        reseller_id INT,
        role_id INT,
        own_purchased_amount FLOAT,
        others_purchased_amount FLOAT,
        my_comm FLOAT
     );
    

    
 				drop TEMPORARY table IF EXISTS tt_t12; drop TEMPORARY table IF EXISTS tt_t13; drop TEMPORARY table IF EXISTS tt_t14; drop TEMPORARY table IF EXISTS tt_t15;drop TEMPORARY table IF EXISTS tt_t16;
 				drop TEMPORARY table IF EXISTS tt_t17; drop TEMPORARY table IF EXISTS tt_t18; drop TEMPORARY table IF EXISTS tt_t19; drop TEMPORARY table IF EXISTS tt_t20;drop TEMPORARY table IF EXISTS tt_t21;
 				drop TEMPORARY table IF EXISTS tt_t22; drop TEMPORARY table IF EXISTS tt_new_reseller_id;
 
 				create TEMPORARY table tt_t12
 				(
 					reseller_id INT,
                    role_id int
 				);
                
 				insert into tt_t12(reseller_id,role_id)
 				select a.reseller_id,a.fk_role_id from Reseller a where a.reseller_id = login_reseller_id;
 
 				CREATE temporary TABLE tt_t13 as SELECT * FROM tt_t12;CREATE temporary TABLE tt_t14 as SELECT * FROM tt_t13;CREATE temporary TABLE tt_t15 as SELECT * FROM tt_t14;CREATE temporary TABLE tt_t16 as SELECT * FROM tt_t15;
 				CREATE temporary TABLE tt_t17 as SELECT * FROM tt_t16;CREATE temporary TABLE tt_t18 as SELECT * FROM tt_t17;CREATE temporary TABLE tt_t19 as SELECT * FROM tt_t18;CREATE temporary TABLE tt_t20 as SELECT * FROM tt_t19;
 				CREATE temporary TABLE tt_t21 as SELECT * FROM tt_t20;CREATE temporary TABLE tt_t22 as SELECT * FROM tt_t21;
                
 				insert into tt_t12(reseller_id,role_id)
 				select Distinct Z.reseller_id,Z.fk_role_id from Reseller Z where Z.fk_reseller_id in (select Distinct AA.reseller_id from tt_t13 AA) and Z.reseller_id not in (select Distinct BB.reseller_id from tt_t14 BB);                   
 
 				insert into tt_t12(reseller_id,role_id)
 				select Distinct Y.reseller_id,Y.fk_role_id from Reseller Y where fk_reseller_id in (select Distinct CC.reseller_id from tt_t15 CC) and Y.reseller_id not in (select Distinct DD.reseller_id from tt_t16 DD);
 
 				insert into tt_t12(reseller_id,role_id)
 				select Distinct X.reseller_id,X.fk_role_id from Reseller X where fk_reseller_id in (select Distinct EE.reseller_id from tt_t17 EE) and X.reseller_id not in (select Distinct FF.reseller_id from tt_t20 FF);
 
 				insert into tt_t12(reseller_id,role_id)
 				select Distinct W.reseller_id,W.fk_role_id from Reseller W where fk_reseller_id in (select Distinct GG.reseller_id from tt_t21 GG) and W.reseller_id not in (select Distinct HH.reseller_id from tt_t22 HH); 
        
				insert into tt_reseller_list(reseller_id,role_id)
				select Distinct II.reseller_id,II.role_id from tt_t12 II;
 

    
 
     DROP TEMPORARY TABLE IF EXISTS tt_reseller_list_t;
     CREATE TEMPORARY TABLE tt_reseller_list_t 
     AS SELECT * FROM tt_reseller_list;

		delete from tt_reseller_list;
     
		 insert into tt_reseller_list(reseller_id,role_id,own_purchased_amount)
		 select a.reseller_id,b.role_id,sum(comm_amount) as own_purchased_amount
		 from Reseller_commisson_info a Right join tt_reseller_list_t b on a.reseller_id = b.reseller_id
		 where Total_purchase_amount <> 0
		 group by a.reseller_id,b.role_id;  

     delete from tt_reseller_list where own_purchased_amount is null;  
    
     insert into tt_reseller_list_2(reseller_id,role_id,others_purchased_amount)
     select a.reseller_id,xx.role_id,sum(comm_amount) as others_purchased_amount
     from Reseller_commisson_info a Right join tt_reseller_list xx on a.reseller_id = xx.reseller_id
     where Total_purchase_amount = 0
     group by a.reseller_id,xx.role_id;  
    
 	insert into tt_reseller_list_3(reseller_id,role_id,own_purchased_amount,others_purchased_amount)
 	select a.reseller_id,a.role_id,IFNULL(a.own_purchased_amount,0) as own_purchased_amount,
 	IFNULL(b.others_purchased_amount,0) as others_purchased_amount
 	from tt_reseller_list a left join tt_reseller_list_2 b on a.reseller_id = b.reseller_id;  
       
     select IFNULL(others_purchased_amount,0) INTO v_m_others_purchased_amount from tt_reseller_list_3 where role_id = 2;  
     select IFNULL(others_purchased_amount,0) INTO v_r_others_purchased_amount from tt_reseller_list_3 where role_id = 3;  
     select IFNULL(others_purchased_amount,0) INTO v_s_others_purchased_amount from tt_reseller_list_3 where role_id = 4;  

     select  ss.fk_role_id INTO v_login_role_id from Reseller ss where ss.reseller_id = login_reseller_id;  
     
     select  own_purchased_amount INTO v_own_purchased_amount from tt_reseller_list_3 where role_id = 4;  
  
     if v_login_role_id = 2 
     then
  
        UPDATE tt_reseller_list_3 AA
        set AA.my_comm =(v_m_others_purchased_amount - v_r_others_purchased_amount)
        where AA.role_id = 2;
     
        UPDATE tt_reseller_list_3 BB
        set BB.my_comm =(v_m_others_purchased_amount - v_r_others_purchased_amount)
        where BB.role_id = 3;
        
        UPDATE tt_reseller_list_3 CC
        set CC.my_comm =(v_m_others_purchased_amount - v_r_others_purchased_amount)
        where CC.role_id = 4;
     end if;  
    
     if v_login_role_id = 3 
     then
  
        UPDATE tt_reseller_list_3 DD
        set DD.my_comm =(v_r_others_purchased_amount - v_own_purchased_amount)
        where DD.role_id = 3;
  	  
        UPDATE tt_reseller_list_3 EE
        set EE.my_comm = IFNULL(own_purchased_amount,0)
        where EE.role_id = 4;
     end if;  
    
 
     if login_reseller_id = reseller_id 
     then
  
        UPDATE tt_reseller_list_3 FF
        set FF.my_comm =(my_comm+own_purchased_amount)
        where FF.reseller_id = login_reseller_id;
        
     Else
     
        UPDATE tt_reseller_list_3 GG
        set GG.my_comm = my_comm
        where GG.reseller_id = login_reseller_id;
     end if;  
 
     SET v_output =(select HH.my_comm from tt_reseller_list_3 HH
     where HH.reseller_id = reseller_id);  
 
 	return v_output;
 
  End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `sme_reseller_admin_performance_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` FUNCTION `sme_reseller_admin_performance_info`(v_reseller_id INT,v_Type INT,v_fromdate varchar(10), v_todate varchar(10)) RETURNS longtext CHARSET utf8mb4
    DETERMINISTIC
BEGIN
         
            DECLARE v_Total_company INT;
            DECLARE v_freetrail INT;
            DECLARE v_paid_subs INT;
            DECLARE v_Total_revenue FLOAT;
            DECLARE v_Total_commision FLOAT;
            DECLARE v_Inc_Tier_Type INT;
            DECLARE v_Fixed_inc_per FLOAT;
            DECLARE v_var_inc_per FLOAT;
            DECLARE v_paid_amount FLOAT;
         	
            DECLARE v_output LONGTEXT;
         	
         
            DROP TEMPORARY TABLE IF EXISTS tt_reseller_list;
            CREATE TEMPORARY TABLE tt_reseller_list
            (
               reseller_id INT
            );
            
         
         	 drop temporary table if exists tt_reseller_parentMT; create temporary table tt_reseller_parentMT(Reseller_id int); 
             
             drop temporary table if exists tt_reseller_parentMT_Dumy1; create temporary table tt_reseller_parentMT_Dumy1(Reseller_id int); 
             drop temporary table if exists tt_reseller_parentMT_Dumy2; create temporary table tt_reseller_parentMT_Dumy2(Reseller_id int);
             drop temporary table if exists tt_reseller_parentMT_Dumy3; create temporary table tt_reseller_parentMT_Dumy3(Reseller_id int);
             drop temporary table if exists tt_reseller_parentMT_Dumy4; create temporary table tt_reseller_parentMT_Dumy4(Reseller_id int);
             drop temporary table if exists tt_reseller_parentMT_Dumy5; create temporary table tt_reseller_parentMT_Dumy5(Reseller_id int);
             drop temporary table if exists tt_reseller_parentMT_Dumy6; create temporary table tt_reseller_parentMT_Dumy6(Reseller_id int);
             
             drop temporary table if exists tt_reseller_parent1; create temporary table tt_reseller_parent1(Reseller_id int);
             drop temporary table if exists tt_reseller_parent2; create temporary table tt_reseller_parent2(Reseller_id int);
              
              
              insert into tt_reseller_parentMT (Reseller_id) select a.Reseller_id from Reseller a where a.Reseller_id = v_reseller_id;
              insert into tt_reseller_parent1 (Reseller_id) select a.Reseller_id from Reseller a where a.Reseller_id = v_reseller_id;
              insert into tt_reseller_parent2 (Reseller_id) select a.Reseller_id from Reseller a where a.Reseller_id = v_reseller_id;
              
         	 
         		insert into  tt_reseller_parentMT
         		select Distinct reseller_id from Reseller where fk_reseller_id in (select Distinct reseller_id from tt_reseller_parent1)
         		and reseller_id not in ( select Distinct reseller_id from tt_reseller_parent2);
              
         			insert into tt_reseller_parentMT_Dumy1 (Reseller_id) select a.Reseller_id from tt_reseller_parentMT a;
                     insert into tt_reseller_parentMT_Dumy2 (Reseller_id) select a.Reseller_id from tt_reseller_parentMT a;
              
               
         		insert into  tt_reseller_parentMT
         		select Distinct reseller_id from Reseller where fk_reseller_id in (select Distinct reseller_id from tt_reseller_parentMT_Dumy1)
         		and reseller_id not in ( select Distinct reseller_id from tt_reseller_parentMT_Dumy2);
              
         			insert into tt_reseller_parentMT_Dumy3 (Reseller_id) select a.Reseller_id from tt_reseller_parentMT a;
                     insert into tt_reseller_parentMT_Dumy4 (Reseller_id) select a.Reseller_id from tt_reseller_parentMT a;
              
               
         		insert into  tt_reseller_parentMT
         		select Distinct reseller_id from Reseller where fk_reseller_id in (select Distinct reseller_id from tt_reseller_parentMT_Dumy3)
         		and reseller_id not in ( select Distinct reseller_id from tt_reseller_parentMT_Dumy4);
              
         			insert into tt_reseller_parentMT_Dumy5 (Reseller_id) select a.Reseller_id from tt_reseller_parentMT a;
                     insert into tt_reseller_parentMT_Dumy6 (Reseller_id) select a.Reseller_id from tt_reseller_parentMT a;
              
         	  
              
         		insert into  tt_reseller_parentMT
         		select Distinct reseller_id from Reseller where fk_reseller_id in (select Distinct reseller_id from tt_reseller_parentMT_Dumy5)
         		and reseller_id not in ( select Distinct reseller_id from tt_reseller_parentMT_Dumy6);
         
         		insert into tt_reseller_list
         		select a.Reseller_id from tt_reseller_parentMT a;
                 
         	
             
            if v_Type = 1 then 
            
         	
               SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
               select   sum(total_purchase_amount) INTO v_output 
               from Reseller_commisson_info a where a.reseller_id in(select b.reseller_id from tt_reseller_list b) and a.comm_amount <> 0 and Comm_assigned_by = 'COMP-PURCHASE' and a.Reseller_id not in (1366,1005) 
               and cast(a.Comm_date as date) between v_fromdate and v_todate;
               SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
            end if;
         	
            if v_Type = 2 then 
         	
               SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
               select   sum(comm_amount) INTO v_output from Reseller_commisson_info a where a.Reseller_id  = v_reseller_id and a.comm_amount <> 0 and Comm_assigned_by = 'COMP-PURCHASE' and a.Reseller_id not in (1366,1005)
               and cast(a.Comm_date as date) between v_fromdate and v_todate;
               SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
            end if;
         	
            if v_Type = 3 then 
         	
               SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
               select   sum(my_comm) INTO v_output from Reseller_commisson_info a where a.Reseller_id = v_reseller_id and a.comm_amount <> 0 and Comm_assigned_by = 'COMP-PURCHASE' and a.Reseller_id not in (1366,1005)
               and cast(a.Comm_date as date) between v_fromdate and v_todate;
               SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
            end if;
         	
            if v_Type = 4 then 
         	
               SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
               select   sum(my_comm) INTO v_output from Reseller_commisson_info a where a.Reseller_id  = v_reseller_id and Total_Purchase_amount <> 0 and a.comm_amount <> 0 and Comm_assigned_by = 'COMP-PURCHASE' 
               and a.Reseller_id not in (1366,1005) and cast(a.Comm_date as date) between v_fromdate and v_todate;
               SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
            end if;		
         
         
            if v_Type = 5 then
         	
               SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
               select sum(total_purchase_amount) INTO v_output from Reseller_commisson_info a 
               inner join Reseller b on a.Reseller_id = b.reseller_id 
               and a.Reseller_id = v_reseller_id  and b.Reseller_id not in (1366,1005) and a.Comm_assigned_by = 'COMP-PURCHASE' 
               and cast(a.Comm_date as date) between v_fromdate and v_todate
               GROUP BY a.Reseller_id;
               SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
            end if;
         	
            return v_output;
         
         END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `sme_reseller_performance_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` FUNCTION `sme_reseller_performance_info`(v_reseller_id INT,v_Type INT) RETURNS longtext CHARSET utf8mb4
    DETERMINISTIC
BEGIN
       
          DECLARE v_Total_company INT;
          DECLARE v_freetrail INT;
          DECLARE v_paid_subs INT;
          DECLARE v_Total_revenue FLOAT;
          DECLARE v_Total_commision FLOAT;
          DECLARE v_Inc_Tier_Type INT;
          DECLARE v_Fixed_inc_per FLOAT;
          DECLARE v_var_inc_per FLOAT;
          DECLARE v_paid_amount FLOAT;
       	
          DECLARE v_output LONGTEXT;
       	
       
          DROP TEMPORARY TABLE IF EXISTS tt_reseller_list;
          CREATE TEMPORARY TABLE tt_reseller_list
          (
             reseller_id INT
          );
          
       
       	 drop temporary table if exists tt_reseller_parentMT; create temporary table tt_reseller_parentMT(Reseller_id int); 
           
           drop temporary table if exists tt_reseller_parentMT_Dumy1; create temporary table tt_reseller_parentMT_Dumy1(Reseller_id int); 
           drop temporary table if exists tt_reseller_parentMT_Dumy2; create temporary table tt_reseller_parentMT_Dumy2(Reseller_id int);
           drop temporary table if exists tt_reseller_parentMT_Dumy3; create temporary table tt_reseller_parentMT_Dumy3(Reseller_id int);
           drop temporary table if exists tt_reseller_parentMT_Dumy4; create temporary table tt_reseller_parentMT_Dumy4(Reseller_id int);
           drop temporary table if exists tt_reseller_parentMT_Dumy5; create temporary table tt_reseller_parentMT_Dumy5(Reseller_id int);
           drop temporary table if exists tt_reseller_parentMT_Dumy6; create temporary table tt_reseller_parentMT_Dumy6(Reseller_id int);
           
           drop temporary table if exists tt_reseller_parent1; create temporary table tt_reseller_parent1(Reseller_id int);
           drop temporary table if exists tt_reseller_parent2; create temporary table tt_reseller_parent2(Reseller_id int);
            
            
            insert into tt_reseller_parentMT (Reseller_id) select a.Reseller_id from Reseller a where a.Reseller_id = v_reseller_id;
            insert into tt_reseller_parent1 (Reseller_id) select a.Reseller_id from Reseller a where a.Reseller_id = v_reseller_id;
            insert into tt_reseller_parent2 (Reseller_id) select a.Reseller_id from Reseller a where a.Reseller_id = v_reseller_id;
            
       	 
       		insert into  tt_reseller_parentMT
       		select Distinct reseller_id from Reseller where fk_reseller_id in (select Distinct reseller_id from tt_reseller_parent1)
       		and reseller_id not in ( select Distinct reseller_id from tt_reseller_parent2);
            
       			insert into tt_reseller_parentMT_Dumy1 (Reseller_id) select a.Reseller_id from tt_reseller_parentMT a;
                   insert into tt_reseller_parentMT_Dumy2 (Reseller_id) select a.Reseller_id from tt_reseller_parentMT a;
            
             
       		insert into  tt_reseller_parentMT
       		select Distinct reseller_id from Reseller where fk_reseller_id in (select Distinct reseller_id from tt_reseller_parentMT_Dumy1)
       		and reseller_id not in ( select Distinct reseller_id from tt_reseller_parentMT_Dumy2);
            
       			insert into tt_reseller_parentMT_Dumy3 (Reseller_id) select a.Reseller_id from tt_reseller_parentMT a;
                   insert into tt_reseller_parentMT_Dumy4 (Reseller_id) select a.Reseller_id from tt_reseller_parentMT a;
            
             
       		insert into  tt_reseller_parentMT
       		select Distinct reseller_id from Reseller where fk_reseller_id in (select Distinct reseller_id from tt_reseller_parentMT_Dumy3)
       		and reseller_id not in ( select Distinct reseller_id from tt_reseller_parentMT_Dumy4);
            
       			insert into tt_reseller_parentMT_Dumy5 (Reseller_id) select a.Reseller_id from tt_reseller_parentMT a;
                   insert into tt_reseller_parentMT_Dumy6 (Reseller_id) select a.Reseller_id from tt_reseller_parentMT a;
            
       	  
            
       		insert into  tt_reseller_parentMT
       		select Distinct reseller_id from Reseller where fk_reseller_id in (select Distinct reseller_id from tt_reseller_parentMT_Dumy5)
       		and reseller_id not in ( select Distinct reseller_id from tt_reseller_parentMT_Dumy6);
       
       		insert into tt_reseller_list
       		select a.Reseller_id from tt_reseller_parentMT a;
               
       	
           
          if v_Type = 1 then 
       	
             SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
             select   sum(total_purchase_amount) INTO v_output 
             from Reseller_commisson_info a where a.reseller_id in(select b.reseller_id from tt_reseller_list b) and a.comm_amount <> 0 and Comm_assigned_by = 'COMP-PURCHASE' and a.Reseller_id not in (1366,1005) ;
             SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
          end if;
       	
          if v_Type = 2 then 
       	
             SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
             select   sum(comm_amount) INTO v_output from Reseller_commisson_info a where a.Reseller_id  = v_reseller_id and a.comm_amount <> 0 and Comm_assigned_by = 'COMP-PURCHASE' and a.Reseller_id not in (1366,1005);
             SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
          end if;
       	
          if v_Type = 3 then 
       	
             SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
             select   sum(my_comm) INTO v_output from Reseller_commisson_info a where a.Reseller_id = v_reseller_id and a.comm_amount <> 0 and Comm_assigned_by = 'COMP-PURCHASE' and a.Reseller_id not in (1366,1005);
             SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
          end if;
       	
          if v_Type = 4 then 
       	
             SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
             select   sum(my_comm) INTO v_output from Reseller_commisson_info a where a.Reseller_id  = v_reseller_id and Total_Purchase_amount <> 0 and a.comm_amount <> 0 and Comm_assigned_by = 'COMP-PURCHASE' and a.Reseller_id not in (1366,1005);
             SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
          end if;		
       
       
          if v_Type = 5 then
       	
             SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
             select sum(total_purchase_amount) INTO v_output from Reseller_commisson_info a 
             inner join Reseller b on a.Reseller_id = b.reseller_id 
             and a.Reseller_id = v_reseller_id  and b.Reseller_id not in (1366,1005) GROUP BY a.Reseller_id;
             SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
          end if;
       	
          return v_output;
       
       END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `sme_reseller_performance_info_1` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` FUNCTION `sme_reseller_performance_info_1`(v_reseller_id INT) RETURNS longtext CHARSET utf8mb4
    DETERMINISTIC
BEGIN

   DECLARE v_output LONGTEXT;
	

   DROP TEMPORARY TABLE IF EXISTS tt_reseller_list;
   CREATE TEMPORARY TABLE tt_reseller_list
   (
      Reseller_id INT
   );
   insert into tt_reseller_list
   select Reseller_id from Reseller where Reseller_id = v_reseller_id;

   insert into tt_reseller_list
   select Distinct Reseller_id from Reseller where fk_reseller_id in(select Distinct Reseller_id from tt_reseller_list)
   and Reseller_id not in(select Distinct Reseller_id from tt_reseller_list);

   insert into tt_reseller_list
   select Distinct Reseller_id from Reseller where fk_reseller_id in(select Distinct Reseller_id from tt_reseller_list)
   and Reseller_id not in(select Distinct Reseller_id from tt_reseller_list);

   insert into tt_reseller_list
   select Distinct Reseller_id from Reseller where fk_reseller_id in(select Distinct Reseller_id from tt_reseller_list)
   and Reseller_id not in(select Distinct Reseller_id from tt_reseller_list);

   insert into tt_reseller_list
   select Distinct Reseller_id from Reseller where fk_reseller_id in(select Distinct Reseller_id from tt_reseller_list)
   and Reseller_id not in(select Distinct Reseller_id from tt_reseller_list);


    
   return v_output;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `subsreseller_get_tier_Id` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` FUNCTION `subsreseller_get_tier_Id`(
reseller_id INT,
Tier_min FLOAT,
Tier_to FLOAT) RETURNS int
    DETERMINISTIC
begin


	

   DECLARE v_Tier_Id INT;

	

   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   Tier_Id INTO v_Tier_Id from sme_Reseller_Tier c where c.Tier_min = Tier_min and c.Tier_To = Tier_to and c.Create_By = reseller_id    LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

   set v_Tier_Id = IFNULL(v_Tier_Id,0);

   return v_Tier_Id;


end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `subsreseller_tier_commisson` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` FUNCTION `subsreseller_tier_commisson`(
reseller_id INT,
Tier_min FLOAT,
Tier_to FLOAT) RETURNS float
    DETERMINISTIC
begin


	

   DECLARE v_Fk_Reseller_Id INT; 
   DECLARE v_sub_commisson FLOAT;

	

   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   Commission INTO v_sub_commisson from  sme_Reseller_Tier a where a.Tier_min = Tier_min and a.Tier_To = Tier_to and a.Create_By = reseller_id    LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

   set v_sub_commisson = IFNULL(v_sub_commisson,0);

   return v_sub_commisson;


end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `ur_get_reseller_commission` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` FUNCTION `ur_get_reseller_commission`(
  reseller_id VARCHAR(20),
  type INT) RETURNS longtext CHARSET utf8mb4
    READS SQL DATA
    DETERMINISTIC
begin
  
    
    
     DECLARE v_output LONGTEXT;  
     DECLARE v_Inc_Tier_Type FLOAT;  
     DECLARE v_Fixed_inc_per FLOAT;
     DECLARE v_var_inc_per FLOAT;
     DECLARE v_Total_revenue FLOAT;  
     
     if type = 1 then 
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        SET v_output =(select IFNULL(sum(Total_Purchase_amount),0) from Reseller_commisson_info a
        where a.reseller_id = reseller_id and a.Comm_assigned_by='COMP-PURCHASE'
        group by a.reseller_id);
                     SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
     end if;  
     if type = 2 then 
     SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        SET v_output =(select IFNULL(sum(Distinct fixed_inc_per),0)+IFNULL(sum(Distinct var_inc_per),0) from Reseller a
        where a.reseller_id = reseller_id
        group by a.reseller_id);
              SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
     end if;  
     if type = 3 then 
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        SET v_output =(select IFNULL(sum(my_comm),0) from  Reseller_commisson_info a
        where a.reseller_id = reseller_id and Total_Purchase_amount is not null and a.Comm_assigned_by='COMP-PURCHASE'
        group by a.reseller_id);
         SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
     end if;  
     
     if type = 4 then 
   
        SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        SET v_output =(select sum(rc.Master_mycomm)+sum(rc.Res_mycomm)+sum(Master_subres_comm) as Commissions
        from Reseller b 
        join Reseller_commisson_info rc  on b.reseller_id = rc.reseller_id
        WHERE rc.total_purchase_amount is not null  and b.reseller_id  = reseller_id and rc.Comm_assigned_by='COMP-PURCHASE'
        group by b.reseller_id);
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
     end if;  
     return v_output;  
     
  end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `ur_get_reseller_count` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` FUNCTION `ur_get_reseller_count`(reseller_id VARCHAR(20),type INT) RETURNS longtext CHARSET utf8mb4
    DETERMINISTIC
begin
 
 
 
    DECLARE v_output LONGTEXT;
 	
    if type = 1 then
 	
       SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
       SET v_output =(select COUNT(1)
       from reseller_company a
       where a.Reseller_Id = reseller_id );
       SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
    end if;
    if type = 2 then
 	
       SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
       SET v_output =(select COUNT(1)
       from reseller_company b
       where b.Reseller_Id = reseller_id and  b.free_trail = 1 and b.vpcp_company_id is not null);
       SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
    end if;
    if type = 3 then
 	
       SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
       SET v_output =(select COUNT(1)
       from reseller_company c
       where c.Reseller_Id = reseller_id and  (c.free_trail <> 1 or c.free_trail is null) and c.vpcp_company_id is not null);
       SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
    end if;
    if type = 4 then
 	
       SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
       SET v_output =(select COUNT(1)
       from reseller_company d
       where d.Reseller_Id = reseller_id and d.status = 1 and d.vpcp_company_id is not null);
       SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
    end if;
    if type = 5 then
 	
       SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
       SET v_output =(select COUNT(1)
       from reseller_company e
       where e.Reseller_Id = reseller_id and e.status = 0 );
       SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
    end if;
    if type = 6 then
 	
       SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
       SET v_output =(select COUNT(1)
       from reseller_company f
       where f.Reseller_Id = reseller_id and f.status = 1 and (f.free_trail <> 1 or f.free_trail is null) and f.vpcp_company_id is not null);
       SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
    end if;
    if type = 7 then
 	
       SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
       SET v_output =(select COUNT(1)
       from reseller_company g
       where g.Reseller_Id = reseller_id and g.status = 1 and (g.free_trail = 1) and g.vpcp_company_id is not null);
       SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
    end if;
 	
    return v_output;
 	
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Hubspot_create_reseller_Lead_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `Hubspot_create_reseller_Lead_details`(
Hubspot_contactid	BIGINT,
First_name			VARCHAR(100),
Last_name			VARCHAR(100),
Email_id			VARCHAR(100),
Phone_number		VARCHAR(100),
address1		    VARCHAR(500),
street_address	    VARCHAR(500),
city				VARCHAR(100),
post_code			VARCHAR(50),
country			VARCHAR(100),
industry			VARCHAR(100),
company_name       VARCHAR(100),
company_domain     VARCHAR(100),
contact_owner      VARCHAR(100),
Employeee_count     INT,
Lead_source VARCHAR(100))
BEGIN

   DECLARE v_reseller_id INT;
	
   DECLARE v_errcode INT; 
   DECLARE v_errmsg VARCHAR(160);
	
   sp_exit:
   BEGIN
      set v_errcode = -1;
      set v_errmsg = '';
      if IFNULL(contact_owner,'') = '' then
	
         set v_errcode = -1;
         set v_errmsg = 'Invalid Hubspot contact id';
         LEAVE sp_exit;
      end if;
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select   a.Reseller_id INTO v_reseller_id from Reseller a where a.Hubspot_Owner_id = contact_owner;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
      if v_reseller_id is null then
	
         set v_errcode = -1;
         set v_errmsg = 'Employee details not found.';
         LEAVE sp_exit;
      end if;
      insert into Reseller_Lead_details(Hubspot_contactd,Fk_Reseller_id,First_name,Last_name,
	Email_id,Phone_number,address1,street_address,city,post_code,country,industry,company_name,
	company_domain,contact_owner,Employeee_count,Lead_createdate,Lead_source,status)
	values(Hubspot_contactid,v_reseller_id,First_name,Last_name,Email_id,Phone_number,
	address1,street_address,city,post_code,country,industry,company_name,company_domain,
	contact_owner,Employeee_count,CURRENT_TIMESTAMP,Lead_source,0);
	
      IF found_rows() > 0 then
	
         set v_errcode = 0;
         set v_errmsg = 'Success to create Leads';
         LEAVE sp_exit;
      end if;
   END;
   select v_errcode as errcode,v_errmsg as errmsg;
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `partner_portal_exe_get_pend_partner_list` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `partner_portal_exe_get_pend_partner_list`()
BEGIN

   select Reseller_id,CONCAT(firstname,' ',lastname) as Partner_name,company_name,email,
	CAST(Create_date AS DATE) AS `Submitted Date`,
	DATE_FORMAT(Create_date,'%b %d %Y %h:%i%p') AS `Submitted Time`,client_ip,Zipcode
   from Reseller where status = 4 and
	((firstname not like '%Test%') and (lastname not like '%test%'))
   and client_ip not like '%192.168%'
   and IFNULL(client_ip,'') <> '::1'
   and email not like '%test%';


END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `partner_portal_exe_get_pend_partner_list_report` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `partner_portal_exe_get_pend_partner_list_report`()
BEGIN



   select Reseller_id,CONCAT(firstname,' ',lastname) as Partner_name,company_name,email,Create_date as `Submitted Date`
   from Reseller where status = 4;


END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `reseller_approveall_commission_breakup_audit` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `reseller_approveall_commission_breakup_audit`(
p_reseller_id int,
p_fromdate varchar(10),
p_todate varchar(10),
p_approveid int
)
Begin

        declare v_Total_amount float;
        declare v_commission_amount float;
        declare v_errcode int default -1;
        declare v_errmsg varchar(50) default '';

		Drop TEMPORARY table IF EXISTS tt_getresellerid_list; 
        create TEMPORARY table tt_getresellerid_list ( reseller_id INT );
        
		Drop TEMPORARY table IF EXISTS tt_get_list; 
        create TEMPORARY table tt_get_list
		(
			id int auto_increment primary key,
			reseller_id INT,
            Total_revenue float,
            Total_commision float,
            from_date varchar(10),
            to_date varchar(10)
		);
        
		call smereseller.sme_reseller_get_subordinates_list_new(p_reseller_id);
		insert into tt_getresellerid_list select a.reseller_id from tt_new_reseller_id a;
 
        insert into tt_get_list(reseller_id) values(p_reseller_id);

        select sum(Total_Purchase_amount) as Total_amount,sum(Comm_amount) as commission_amount 
        into v_Total_amount,v_commission_amount
        from smereseller.Reseller_commisson_info rc
        join tt_getresellerid_list gr on rc.reseller_id  = gr.reseller_id
        where Comm_assigned_by = 'COMP-PURCHASE'
        and cast(Comm_date as date) between p_fromdate and p_todate;
        
        update tt_get_list
        set Total_revenue = v_Total_amount,Total_commision = v_commission_amount,from_date = p_fromdate,to_date = p_todate ;
        
        
        if exists(select * from smereseller.reseller_main_approveall_commission_audit a where a.reseller_id = p_reseller_id and from_date = p_fromdate and to_date = p_todate limit 1) then
			delete from smereseller.reseller_main_approveall_commission_audit a where a.reseller_id = p_reseller_id and from_date = p_fromdate and to_date = p_todate;
        End if;
        
        insert into smereseller.reseller_main_approveall_commission_audit(reseller_id,total_revenue,total_commision,from_date,to_date,docstatus,approveid,createAt)
        select reseller_id,total_revenue,total_commision,from_date,to_date,1,p_approveid,current_timestamp 
        from tt_get_list;
        
        if row_count() > 0 then
			set v_errcode = 0;
            set v_errmsg = 'Success';
        End if;

	select v_errcode as errcode, v_errmsg as errmsg;

End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Reseller_assign_Incenctive_Scheme` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `Reseller_assign_Incenctive_Scheme`(Reseller_ID INT,  
 Scheme_ID INT)
BEGIN
 
    DECLARE v_errcode INT;   
    DECLARE v_errmsg VARCHAR(160);  
    
    DROP TEMPORARY TABLE IF EXISTS tt_temp_reseller_structure;
    create TEMPORARY table tt_temp_reseller_structure
    (
       id INT   AUTO_INCREMENT PRIMARY KEY,
       TypeID INT,
       inc_percentage FLOAT,
       Inc_app_Month INT,
       After_Inc_apply_Month_Per FLOAT
    )  AUTO_INCREMENT = 1;  
     
    
    
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    INSERT INTO tt_temp_reseller_structure(TypeID,inc_percentage,Inc_app_Month,After_Inc_apply_Month_Per)
    SELECT a.Typeid,a.inc_percentage,a.Inc_app_Month,a.After_Inc_apply_Month_Per  from Inc_Scheme_Master a
    WHERE a.STATUS = 1
    and a.Is_ID = Scheme_ID;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
    
    IF EXISTS(SELECT  * FROM Reseller_incentive_Config b WHERE  b.Reseller_Id = Reseller_ID LIMIT 1) 
    then 
       DELETE FROM Reseller_incentive_Config a WHERE  a.Reseller_Id = Reseller_ID;
    end if;  
    
    INSERT INTO  Reseller_incentive_Config(Reseller_Id,Typeid,Inc_app_Month,inc_percentage,
  After_Inc_apply_Month_Per,create_Date)
    SELECT Reseller_ID,TypeID,Inc_app_Month,inc_percentage,After_Inc_apply_Month_Per,CURRENT_TIMESTAMP
    FROM tt_temp_reseller_structure;  
    
    IF row_count() > 0 
    then 
       SET v_errcode = 0;
       SET v_errmsg = 'Success to create the Incentive Structre';
    end if;  
    
     UPDATE Reseller c set c.Is_Id = Scheme_ID,c.fixed_inc_per = 0 WHERE c.Reseller_id = Reseller_ID;  
   
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `reseller_commison_apply_incentive` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `reseller_commison_apply_incentive`(
reseller_id int,
purchase_cost float,
plan_Type_id int,
company_id int,
payment_reference varchar(50),
processby varchar(50)
)
sp_return : BEGIN

	
	declare sub_reseller_id int;
	declare inc_percentage float; 
	declare inc_price float;
	
	IF NOT EXISTS(SELECT 1 FROM Reseller_incentive_Config a WHERE a.Reseller_Id=reseller_id  AND a.Typeid=plan_Type_id limit 1) then
		
		SELECT ifnull(a.Fk_Reseller_Id,0) into sub_reseller_id
		FROM Reseller a 
		join Reseller b on a.Fk_Reseller_Id=b.Reseller_Id
		WHERE a.Reseller_id=reseller_id and ifnull(b.comm_apply,0)=1 
		and a.fk_role_id=2 limit 1;
		
		IF ifnull(sub_reseller_id,0)=0 then
			leave sp_return;
		end if;		
		
		SELECT ifnull(a.inc_percentage,0) into inc_percentage
		FROM Reseller_incentive_Config a WHERE a.Reseller_id=reseller_id 
		AND a.Typeid=plan_Type_id limit 1;

		IF ifnull(inc_percentage,0)<=0 then
			leave sp_return;
		end if;
			
		SET inc_price=	purchase_cost *(inc_percentage/100); 
        
		Insert into Reseller_commisson_info(Reseller_Id,Total_Purchase_amount,Comm_per,Company_Id,Comm_amount,Comm_date,Comm_assigned_by,Status,Pay_Reference_No,plan_Type_ID)
		values(sub_reseller_id,purchase_cost,inc_percentage,company_id,inc_price,current_timestamp,processby,1,payment_reference,plan_Type_id);
		
	END if;
	
	
	
	IF  EXISTS(SELECT 1 FROM Reseller_incentive_Config a WHERE a.Reseller_Id=reseller_id AND a.Typeid=plan_Type_id limit 1) then
    
		SELECT ifnull(a.inc_percentage,0) into inc_percentage
		FROM Reseller_incentive_Config a WHERE a.Reseller_Id=reseller_id 
		AND a.Typeid=plan_Type_id limit 1;
        

		IF ifnull(inc_percentage,0)<=0 then
			leave sp_return;
		end if;
			
		SET inc_price=	purchase_cost *(inc_percentage/100) ;
		

		Insert into Reseller_commisson_info(Reseller_Id,Total_Purchase_amount,Comm_per,Company_Id,Comm_amount,Comm_date,Comm_assigned_by,Status,Pay_Reference_No,plan_Type_ID)
		values(reseller_id,purchase_cost,inc_percentage,company_id,inc_price,current_timestamp,processby,1,payment_reference,plan_Type_id);
		
	END if;

	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `reseller_comm_get_incnentive_percentage` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `reseller_comm_get_incnentive_percentage`(
reseller_id INT,
company_id INT,
Type_ID INT,
OUT inc_percentage FLOAT)
BEGIN

	
	
   DECLARE v_purchase_count INT;
   DECLARE v_incnentive_price FLOAT;  
	
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   count(1) INTO v_purchase_count from  Reseller_Payment_Info  a where 
   a.Vpcp_Comp_Id = company_id
   and a.pay_status = 'Success';
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
	
	
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   IFNULL(a.inc_percentage,0) INTO inc_percentage from  Reseller_incentive_Config a where a.Reseller_Id = reseller_id and a.Typeid = Type_ID
   and v_purchase_count <= Inc_app_Month    LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
	
	
   IF IFNULL(inc_percentage,0) = 0 AND v_purchase_count > 1 then
	
	
		
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select   IFNULL(b.After_Inc_apply_Month_Per,0) INTO inc_percentage from Reseller_incentive_Config b where b.Reseller_Id = reseller_id and b.Typeid = Type_ID
      and v_purchase_count >= Inc_app_Month    LIMIT 1;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   end if;
	

	
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Reseller_company_delivery_order_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `Reseller_company_delivery_order_info`(comp_user_id INT,
order_id INT)
BEGIN

	

   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select customer_name,IFNULL(address1,'') as address1,IFNULL(address2,'') as address2,
	IFNULL(city,'') as city,IFNULL(postcode,'') as postcode,IFNULL(country,'') as country,
	shipping_charge,shipping_tax_fee,IFNULL(email,'') as email,IFNULL(mobileno,'') as mobileno,
	billing_type,company_name,state,createdate from Res_Order_delivery_address a
   where a.order_id = order_id;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Reseller_company_order_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `Reseller_company_order_info`(comp_user_id INT)
SWL_return:
           BEGIN
           
           	
       		DECLARE v_resller_company_id INT; 
       		DECLARE v_errcode INT; 
       		DECLARE v_errmsg VARCHAR(250);
       
       		DECLARE v_comp_order_id INT; 
       		DECLARE v_company_id INT; 
       		DECLARE v_bundleid INT; 
           	
       		DECLARE v_bundle_name VARCHAR(250);
       		DECLARE v_bundle_price FLOAT;
       		DECLARE v_days_valid INT; 
       		DECLARE v_bundle_minutes FLOAT;
       		DECLARE v_msisdn_info LONGTEXT; 
       		DECLARE default_int_val_0 int;
       		DECLARE default_int_val_1 int;
       		DECLARE v_tier_id int;
       		declare v_pro_user_count int;
       		declare v_platform_fee	float;
             declare v_platform_fee_year float;
                
                set default_int_val_0 = 0 ;
                set default_int_val_1 = 1 ;
           	
              SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
              select   a.Pk_rs_cmpid, IFNULL(a.addon_bundleid,0),a.plan_id  INTO v_resller_company_id,v_bundleid ,v_tier_id
              from reseller_company a where  a.cnt_ref_id = comp_user_id LIMIT 1;
              SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
       
       		select a.pro_user_count,a.platform_fee,a.platform_fee_year into v_pro_user_count,v_platform_fee,v_platform_fee_year from wtms.wtms_copy_of_tier_management_temp a
       		where fk_tier_id=v_tier_id limit 1;
             
              if v_resller_company_id is null then
           	
                 set v_errcode = -1;
                 set v_errmsg = 'Failure to get the details';
                 select v_errcode errcode,v_errmsg errmsg;
                 LEAVE SWL_return;
              end if;
           	
              IF IFNULL(v_bundleid,0) > 0 then
           	
                 select bundle_name, renewal_delay, case when bundle_type = 1 then  IFNULL(national_min,0) else IFNULL(international_min,0) end, price 
                 INTO v_bundle_name,v_days_valid,v_bundle_minutes,v_bundle_price from unifiedring.utms_new_bundle_log where bundleid = v_bundleid LIMIT 1;
              end if;
           	
              set v_msisdn_info = '';
           
              select CONCAT(COALESCE(v_msisdn_info,''),',',fn_get_country_formated_number(msisdn)) 
              INTO v_msisdn_info FROM res_comp_mobileno_info where fk_rs_cmpid = v_resller_company_id limit 1;
           	
              IF LEFT(v_msisdn_info,1) = ',' then
                 SET v_msisdn_info = insert(v_msisdn_info,1,1,'');
              end if;
           
           	
              SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
       		select a.first_name,a.last_name,a.company_name,b.tot_phone_charge,b.tot_discount,b.tot_tax_fee,
       				b.tot_charge,c.sd_id,c.category,c.phone_id,IFNULL(c.phone_model,'') as phone_model,c.phone_desc,c.price,c.weight,
       				c.ean_no,c.quantity,IFNULL(c.inventory_id,default_int_val_0) as inventory_id,IFNULL(c.discount_price,0) as discount_price,c.external_number,
       				b.Order_Id as Order_Id,IFNULL(b.plan_charge,0) as plan_charge,IFNULL(Number_charge,0) as Number_charge,
       				IFNULL(product,'') as product,IFNULL(b.plan,'') as plan,b.Duration,b.Users,b.plan_ind_amount,
       				a.email,a.mobileno,IFNULL(a.Hubspot_companyid,default_int_val_0) as Hubspot_companyid ,
       				IFNULL(Hubspot_contactid,default_int_val_0) as Hubspot_contactid,
       				case when IFNULL(a.paid_reference,'') <> '' then default_int_val_1 else default_int_val_0 end as paid_status,
       				IFNULL(a.paid_reference,'') as reference_id,
       				CASE WHEN IFNULL(num_Type,'') LIKE '%local%' then default_int_val_1
       				else default_int_val_0 end AS Number_type,
       				IFNULL(addon_price,0) as addon_price,
       				IFNULL(mobileno_price,0) as mobileno_price,
       				IFNULL(v_msisdn_info,'') as msisdn_info,
       				IFNULL(a.avail_number,'') as avail_number,
       				IFNULL(num_citycode,'') as city,
       				fn_get_country_formated_number(a.avail_number) as avail_number_display,
       				IFNULL(v_bundle_name,'') as bundle_name,
       				IFNULL(v_days_valid,default_int_val_0) as days_valid,
       				IFNULL(v_bundle_minutes,0) as bundle_minutes,
       				IFNULL(v_bundle_price,0) as bundle_price,
       				IFNULL(v_bundleid,default_int_val_0) as bundleid,
       				IFNULL(d.shipping_charge,0) as Shipping_charge,
       				IFNULL(d.shipping_tax_fee,0) as shipping_tax_fee,
       				ifnull(v_pro_user_count,0) as pro_user_count ,
       				ifnull(b.plan_id,0) as plan_id,ifnull(b.product_id,0) as product_id,
       				ifnull(b.setup_price,0) as setup_price,
    				case when b.Duration = 1 then v_platform_fee else v_platform_fee_year end as platform_fee,
                    b.setup_discount,e.Installation_cost as plan_setup_fees,
   				b.platform_user_fee, b.platform_user_count,
                 a.Vpcp_Company_Id
       		from reseller_company  a 
       		LEFT JOIN Res_Comp_Device_Order b on a.Pk_rs_cmpid = b.Fk_rs_cmpid
       		LEFT JOIN Res_device_order_item c on b.order_id = c.order_id
       		LEFT JOIN Res_Order_delivery_address d on b.Order_Id = d.order_id
            LEFT JOIN smereseller.Res_company_deal_creation dc on dc.reseller_id = b.Fk_Resller_Id  and a.cnt_ref_id = dc.comp_user_id
            left join wtms.wtms_copy_of_tier_management_temp e on a.plan_id = e.fk_tier_id
       		where Fk_rs_cmpid = v_resller_company_id;
              SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
           	
           END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Reseller_company_order_info_1` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `Reseller_company_order_info_1`(comp_user_id INT)
SWL_return:
BEGIN

	
   DECLARE v_resller_company_id INT; 
   DECLARE v_errcode INT; 
   DECLARE v_errmsg VARCHAR(250);
	
   DECLARE v_comp_order_id INT; 
   DECLARE v_company_id INT; 
   DECLARE v_bundleid INT; 
	
   DECLARE v_bundle_name VARCHAR(250);
   DECLARE v_bundle_price FLOAT;
   DECLARE v_days_valid INT; 
   DECLARE v_bundle_minutes FLOAT;
   DECLARE v_msisdn_info LONGTEXT; 
      DECLARE default_int_val_0 int;
     DECLARE default_int_val_1 int;
     
     set default_int_val_0 = 0 ;
     set default_int_val_1 = 1 ;
	
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   a.Pk_rs_cmpid, IFNULL(a.addon_bundleid,0) INTO v_resller_company_id,v_bundleid from reseller_company a where  a.cnt_ref_id = comp_user_id    LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
	
   if v_resller_company_id is null then
	
      set v_errcode = -1;
      set v_errmsg = 'Failure to get the details';
      select v_errcode errcode,v_errmsg errmsg;
      LEAVE SWL_return;
   end if;
	
   IF IFNULL(v_bundleid,0) > 0 then
	
      select   bundle_name, renewal_delay, case when bundle_type = 1 then  IFNULL(national_min,0) else IFNULL(international_min,0) end, price INTO v_bundle_name,v_days_valid,v_bundle_minutes,v_bundle_price from unifiedring.utms_new_bundle_log where bundleid = v_bundleid    LIMIT 1;
   end if;
	
   set v_msisdn_info = '';

   select   CONCAT(COALESCE(v_msisdn_info,''),',',fn_get_country_formated_number(msisdn)) INTO v_msisdn_info FROM res_comp_mobileno_info where fk_rs_cmpid = v_resller_company_id;
	
   IF LEFT(v_msisdn_info,1) = ',' then
      SET v_msisdn_info = insert(v_msisdn_info,1,1,'');
   end if;

	
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select a.first_name,a.last_name,a.company_name,b.tot_phone_charge,b.tot_discount,b.tot_tax_fee,
	b.tot_charge,c.sd_id,c.category,c.phone_id,IFNULL(c.phone_model,'') as phone_model,c.phone_desc,c.price,c.weight,
	c.ean_no,c.quantity,IFNULL(c.inventory_id,default_int_val_0) as inventory_id,IFNULL(c.discount_price,0) as discount_price,c.external_number,
	b.Order_Id as Order_Id,IFNULL(b.plan_charge,0) as plan_charge,IFNULL(Number_charge,0) as Number_charge,
	IFNULL(product,'') as product,IFNULL(b.plan,'') as plan,b.Duration,b.Users,b.plan_ind_amount,
	a.email,a.mobileno,IFNULL(a.Hubspot_companyid,default_int_val_0) as Hubspot_companyid ,
	IFNULL(Hubspot_contactid,default_int_val_0) as Hubspot_contactid,
	case when IFNULL(a.paid_reference,'') <> '' then default_int_val_1 else default_int_val_0 end as paid_status,
	IFNULL(a.paid_reference,'') as reference_id,
	CASE WHEN IFNULL(num_Type,'') LIKE '%local%' then default_int_val_1
   else default_int_val_0 end AS Number_type,
   IFNULL(addon_price,0) as addon_price,
	IFNULL(mobileno_price,0) as mobileno_price,
	IFNULL(v_msisdn_info,'') as msisdn_info,
	IFNULL(a.avail_number,'') as avail_number,
	IFNULL(num_citycode,'') as city,
	fn_get_country_formated_number(a.avail_number) as avail_number_display,
	IFNULL(v_bundle_name,'') as bundle_name,
	IFNULL(v_days_valid,0) as days_valid,
	IFNULL(v_bundle_minutes,0) as bundle_minutes,
	IFNULL(v_bundle_price,0) as bundle_price,
	IFNULL(v_bundleid,0) as bundleid,
	IFNULL(d.shipping_charge,0) as Shipping_charge,
	IFNULL(d.shipping_tax_fee,0) as shipping_tax_fee
   from reseller_company  a 
   LEFT join Res_Comp_Device_Order b on a.Pk_rs_cmpid = b.Fk_rs_cmpid
   LEFT join Res_device_order_item c on b.order_id = c.order_id
   LEFT JOIN  Res_Order_delivery_address d on b.Order_Id = d.order_id
   where Fk_rs_cmpid = v_resller_company_id;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Reseller_create_comm_incentive_structure` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbteam`@`%` PROCEDURE `Reseller_create_comm_incentive_structure`(
    Reseller_ID INT,
    comm_apply INT,
    comm_info_xml LONGTEXT)
BEGIN
    	
        DECLARE v_hDoc INT; 
        DECLARE v_errcode INT; 
        DECLARE v_errmsg VARCHAR(160);       
        DECLARE v_TypeID text ;
        DECLARE v_inc_percentage text;
        DECLARE v_Inc_app_Month text ;
        DECLARE v_After_Inc_apply_Month_Per text;
    	
    	
       sp_exit:BEGIN
       
          IF IFNULL(comm_apply,0) = 0 
          then
    	
             UPDATE Reseller a set a.comm_apply = comm_apply WHERE a.Reseller_id = Reseller_ID;
             
             IF ROW_COUNT() > 0 
             then
    		
                IF EXISTS(SELECT  1 FROM Reseller_incentive_Config b WHERE  b.Reseller_Id = Reseller_ID LIMIT 1) 
                then
    			
                   DELETE FROM Reseller_incentive_Config c WHERE  c.Reseller_Id = Reseller_ID;
                end if;
                
                SET v_errcode = 0;
                SET v_errmsg = 'Success to create the Incentive Structre';
                LEAVE sp_exit;
                
             end if;
             
          end if;
    	
          DROP TEMPORARY TABLE IF EXISTS tt_temp_reseller_structure;          
          create TEMPORARY table tt_temp_reseller_structure
          (
             id INT   AUTO_INCREMENT PRIMARY KEY,
             TypeID text,
             inc_percentage text,
             Inc_app_Month text,
             After_Inc_apply_Month_Per text
          )  AUTO_INCREMENT = 1;
          
         
         
         
        
          
          
      drop temporary table if exists xml_TypeID_tbl; create temporary table xml_TypeID_tbl( id int auto_increment primary key,TypeID text);
      drop temporary table if exists xml_inc_percentage_tbl; create temporary table xml_inc_percentage_tbl( id int auto_increment primary key,inc_percentage text);
      drop temporary table if exists xml_Inc_app_Month_tbl; create temporary table xml_Inc_app_Month_tbl( id int auto_increment primary key,Inc_app_Month text);
      drop temporary table if exists xml_After_Inc_apply_Month_Per_tbl; create temporary table xml_After_Inc_apply_Month_Per_tbl( id int auto_increment primary key,After_Inc_apply_Month_Per text);
      
     SELECT 
         REPLACE(EXTRACTVALUE(comm_info_xml, '//TypeID[1]'),' ',','),
         REPLACE(EXTRACTVALUE(comm_info_xml, '//inc_percentage[1]'),' ',','),
         REPLACE(EXTRACTVALUE(comm_info_xml, '//Inc_app_Month[1]'),' ',','),
         REPLACE(EXTRACTVALUE(comm_info_xml,'//After_Inc_apply_Month_Per[1]'),' ',',')
     	INTO v_TypeID , v_inc_percentage , v_Inc_app_Month , v_After_Inc_apply_Month_Per;	
  	
 
        call unifiedring.Split(v_TypeID,','); insert into xml_TypeID_tbl(TypeID) select Items from unifiedring.tt_Split_temptable;
        call unifiedring.Split(v_inc_percentage,','); insert into xml_inc_percentage_tbl(inc_percentage) select Items from unifiedring.tt_Split_temptable;
        call unifiedring.Split(v_Inc_app_Month,','); insert into xml_Inc_app_Month_tbl(Inc_app_Month) select Items from unifiedring.tt_Split_temptable;
        call unifiedring.Split(v_After_Inc_apply_Month_Per,','); insert into xml_After_Inc_apply_Month_Per_tbl(After_Inc_apply_Month_Per) select Items from unifiedring.tt_Split_temptable;     
             
 
        insert into tt_temp_reseller_structure(TypeID,inc_percentage,Inc_app_Month,After_Inc_apply_Month_Per)
        select TypeID,inc_percentage,Inc_app_Month,After_Inc_apply_Month_Per
        from xml_TypeID_tbl a 
        left join xml_inc_percentage_tbl b on a.id = b.id
        left join xml_Inc_app_Month_tbl c on a.id = c.id
        left join xml_After_Inc_apply_Month_Per_tbl d on a.id = d.id;
             
 
          IF EXISTS(SELECT  1 FROM Reseller_incentive_Config d WHERE  d.Reseller_Id = Reseller_ID LIMIT 1) 
          then
          
		  

			insert into Reseller_incentive_Config_log(Reseller_Id,Typeid,Inc_app_Month,inc_percentage,After_Inc_apply_Month_Per,create_Date)
			select e.Reseller_Id,e.Typeid,e.Inc_app_Month,e.inc_percentage,e.After_Inc_apply_Month_Per,current_timestamp  
			from Reseller_incentive_Config e WHERE  e.Reseller_Id = Reseller_ID;
            
			DELETE FROM Reseller_incentive_Config e WHERE  e.Reseller_Id = Reseller_ID;
          end if;
          
          INSERT INTO  Reseller_incentive_Config(Reseller_Id,Typeid,Inc_app_Month,inc_percentage, After_Inc_apply_Month_Per,create_Date)
          SELECT Reseller_ID,TypeID,Inc_app_Month,inc_percentage,After_Inc_apply_Month_Per,CURRENT_TIMESTAMP FROM tt_temp_reseller_structure;
          
          IF ROW_COUNT() > 0 then
             SET v_errcode = 0;
             SET v_errmsg = 'Success to create the Incentive Structre';
          end if;
          UPDATE Reseller a set a.comm_apply = comm_apply WHERE a.Reseller_id = Reseller_ID;
       END;
       select v_errcode as errcode,v_errmsg as errmsg; 
    
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Reseller_create_comm_incentive_structure_1` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `Reseller_create_comm_incentive_structure_1`(
 Reseller_ID INT,
 comm_apply INT,
 comm_info_xml LONGTEXT)
BEGIN
 
 
 	
 	
    DECLARE v_hDoc INT; 
    DECLARE v_errcode INT; 
    DECLARE v_errmsg VARCHAR(160);    
     DECLARE v_TypeID INT ;
     DECLARE v_inc_percentage FLOAT;
     DECLARE v_Inc_app_Month INT ;
     DECLARE v_After_Inc_apply_Month_Per varchar(100);
 	
 	
    sp_exit:
    BEGIN
       IF IFNULL(comm_apply,0) = 0 then
 	
          UPDATE Reseller a set a.comm_apply = comm_apply WHERE a.Reseller_id = Reseller_ID;
          IF ROW_COUNT() > 0 then
 		
             IF EXISTS(SELECT  1 FROM Reseller_incentive_Config b WHERE  b.Reseller_Id = Reseller_ID LIMIT 1) then
 			
                DELETE FROM Reseller_incentive_Config c WHERE  c.Reseller_Id = Reseller_ID;
             end if;
             SET v_errcode = 0;
             SET v_errmsg = 'Success to create the Incentive Structre';
             LEAVE sp_exit;
          end if;
       end if;
 	
       DROP TEMPORARY TABLE IF EXISTS tt_temp_reseller_structure;
       
       create TEMPORARY table tt_temp_reseller_structure
       (
          id INT   AUTO_INCREMENT PRIMARY KEY,
          TypeID INT,
          inc_percentage FLOAT,
          Inc_app_Month INT,
          After_Inc_apply_Month_Per FLOAT
       )  AUTO_INCREMENT = 1;
       
      
      
      
     
       
       
   drop temporary table if exists xml_TypeID_tbl; create temporary table xml_TypeID_tbl( id int auto_increment primary key,TypeID int);
   drop temporary table if exists xml_inc_percentage_tbl; create temporary table xml_inc_percentage_tbl( id int auto_increment primary key,inc_percentage float);
   drop temporary table if exists xml_Inc_app_Month_tbl; create temporary table xml_Inc_app_Month_tbl( id int auto_increment primary key,Inc_app_Month int);
   drop temporary table if exists xml_After_Inc_apply_Month_Per_tbl; create temporary table xml_After_Inc_apply_Month_Per_tbl( id int auto_increment primary key,After_Inc_apply_Month_Per float);
   
  SELECT 
      REPLACE(EXTRACTVALUE(comm_info_xml, '//TypeID[1]'),' ',','),REPLACE(EXTRACTVALUE(comm_info_xml, '//inc_percentage[1]'),' ',','),
      REPLACE(EXTRACTVALUE(comm_info_xml, '//Inc_app_Month[1]'),' ',','),REPLACE(EXTRACTVALUE(comm_info_xml,'//xml_After_Inc_apply_Month_Per_tbl[1]'),' ',',')
  	INTO v_TypeID , v_inc_percentage , v_Inc_app_Month , v_After_Inc_apply_Month_Per;		
  		
     call unifiedring.Split(v_TypeID,','); insert into xml_TypeID_tbl(TypeID) select Items from unifiedring.tt_Split_temptable;
     call unifiedring.Split(v_inc_percentage,','); insert into xml_inc_percentage_tbl(inc_percentage) select Items from unifiedring.tt_Split_temptable;
     call unifiedring.Split(v_Inc_app_Month,','); insert into xml_Inc_app_Month_tbl(Inc_app_Month) select Items from unifiedring.tt_Split_temptable;
     call unifiedring.Split(v_After_Inc_apply_Month_Per,','); insert into xml_After_Inc_apply_Month_Per_tbl(After_Inc_apply_Month_Per) select Items from unifiedring.tt_Split_temptable;     
          
     insert into tt_temp_reseller_structure(TypeID,inc_percentage,Inc_app_Month,After_Inc_apply_Month_Per)
     select TypeID,inc_percentage,Inc_app_Month,After_Inc_apply_Month_Per
     from xml_TypeID_tbl a 
     join xml_inc_percentage_tbl b on a.id = b.id
     join xml_Inc_app_Month_tbl c on c.id = b.id
     join xml_After_Inc_apply_Month_Per_tbl d on d.id = c.id;
          
   
       
       
       IF EXISTS(SELECT  1 FROM Reseller_incentive_Config d WHERE  d.Reseller_Id = Reseller_ID LIMIT 1) then
          DELETE FROM Reseller_incentive_Config e WHERE  e.Reseller_Id = Reseller_ID;
       end if;
       INSERT INTO  Reseller_incentive_Config(Reseller_Id,Typeid,Inc_app_Month,inc_percentage,
 	After_Inc_apply_Month_Per,create_Date)
       SELECT Reseller_ID,TypeID,Inc_app_Month,inc_percentage,After_Inc_apply_Month_Per,CURRENT_TIMESTAMP
       FROM tt_temp_reseller_structure;
       
       IF ROW_COUNT() > 0 then
          SET v_errcode = 0;
          SET v_errmsg = 'Success to create the Incentive Structre';
       end if;
       UPDATE Reseller a set a.comm_apply = comm_apply WHERE a.Reseller_id = Reseller_ID;
    END;
    select v_errcode as errcode,v_errmsg as errmsg; 
 
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Reseller_create_Incentive_Scheme` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `Reseller_create_Incentive_Scheme`(
  comm_info_xml LONGTEXT,
  Scheme_name  VARCHAR(160),
  processType INT ,
  processby VARCHAR(50),
  Scheme_ID INT)
BEGIN
  
  	

     DECLARE v_hDoc INT; 
     DECLARE v_errcode INT; 
     DECLARE v_errmsg VARCHAR(160);
     
     DECLARE v_TypeID varchar(100) ;
     DECLARE v_inc_percentage varchar(100);
     DECLARE v_Inc_app_Month varchar(100) ;
     DECLARE v_After_Inc_apply_Month_Per varchar(100);
     
     declare SWF_count int;
  	
      set v_errcode =-1;
      set v_errmsg = 'Failure';
      
    
     
  	
     DROP TEMPORARY TABLE IF EXISTS tt_temp_reseller_structure;
     create TEMPORARY table tt_temp_reseller_structure
     (
        id INT   AUTO_INCREMENT PRIMARY KEY,
        TypeID INT,
        inc_percentage FLOAT,
        Inc_app_Month INT,
        After_Inc_apply_Month_Per FLOAT
     )  AUTO_INCREMENT = 1;
  	
     
     
     
     
   
   drop temporary table if exists xml_TypeID_tbl; create temporary table xml_TypeID_tbl( id int auto_increment primary key,TypeID int);
   drop temporary table if exists xml_inc_percentage_tbl; create temporary table xml_inc_percentage_tbl( id int auto_increment primary key,inc_percentage float);
   drop temporary table if exists xml_Inc_app_Month_tbl; create temporary table xml_Inc_app_Month_tbl( id int auto_increment primary key,Inc_app_Month int);
   drop temporary table if exists xml_After_Inc_apply_Month_Per_tbl; create temporary table xml_After_Inc_apply_Month_Per_tbl( id int auto_increment primary key,After_Inc_apply_Month_Per float);
 
  SELECT REPLACE(EXTRACTVALUE(comm_info_xml, '//TypeID[1]'),' ',','),
		REPLACE(EXTRACTVALUE(comm_info_xml, '//inc_percentage[1]'),' ',','),
		REPLACE(EXTRACTVALUE(comm_info_xml, '//Inc_app_Month[1]'),' ',','),
		REPLACE(EXTRACTVALUE(comm_info_xml,'//After_Inc_apply_Month_Per[1]'),' ',',')
  	INTO v_TypeID , v_inc_percentage , v_Inc_app_Month , v_After_Inc_apply_Month_Per;		
        
     call unifiedring.Split(v_TypeID,','); insert into xml_TypeID_tbl(TypeID) select Items from unifiedring.tt_Split_temptable;
     call unifiedring.Split(v_inc_percentage,','); insert into xml_inc_percentage_tbl(inc_percentage) select Items from unifiedring.tt_Split_temptable;
     call unifiedring.Split(v_Inc_app_Month,','); insert into xml_Inc_app_Month_tbl(Inc_app_Month) select Items from unifiedring.tt_Split_temptable;
     call unifiedring.Split(v_After_Inc_apply_Month_Per,','); insert into xml_After_Inc_apply_Month_Per_tbl(After_Inc_apply_Month_Per) select Items from unifiedring.tt_Split_temptable;     
     
     insert into tt_temp_reseller_structure(TypeID,inc_percentage,Inc_app_Month,After_Inc_apply_Month_Per)
     select TypeID,inc_percentage,Inc_app_Month,After_Inc_apply_Month_Per
     from xml_TypeID_tbl a 
     join xml_inc_percentage_tbl b on a.id = b.id
     join xml_Inc_app_Month_tbl c on c.id = b.id
     join xml_After_Inc_apply_Month_Per_tbl d on d.id = c.id;
          
          
     IF processType = 1 then
  		
  	SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
  		SELECT s.Is_ID INTO Scheme_ID 
        FROM Inc_Scheme_Master s 
        WHERE s.status = 1
  		ORDER BY s.Is_ID DESC LIMIT 1;
        
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
  		  set Scheme_ID = IFNULL(Scheme_ID,0) + 1;
        
  		  INSERT INTO Inc_Scheme_Master(Is_ID,Scheme_Name,Typeid,Inc_app_Month,inc_percentage,After_Inc_apply_Month_Per,create_Date,create_by,status)
  		  SELECT Scheme_ID,Scheme_name,TypeID,Inc_app_Month,inc_percentage,After_Inc_apply_Month_Per,CURRENT_TIMESTAMP,processby,1
  		  FROM tt_temp_reseller_structure;
		
        IF ROW_COUNT() > 0 then
           SET v_errcode = 0;
           SET v_errmsg = 'Success to create the Incentive Structre';
  
        end if;
     end if;
  		
     IF processType = 2 AND IFNULL(Scheme_ID,0) > 0 then
  		
        DELETE FROM Inc_Scheme_Master a WHERE a.Is_ID = Scheme_ID;
        INSERT INTO  Inc_Scheme_Master(Is_ID,Scheme_Name,Typeid,Inc_app_Month,inc_percentage,
  				After_Inc_apply_Month_Per,create_Date,create_by,status)
        SELECT Scheme_ID,Scheme_name,TypeID,Inc_app_Month,inc_percentage,After_Inc_apply_Month_Per,CURRENT_TIMESTAMP,
  				processby,1
        FROM tt_temp_reseller_structure;
        
      
        
        IF ROW_COUNT() > 0 then
           SET v_errcode = 0;
           SET v_errmsg = 'Success to update the Incentive Structre';
        end if;
     end if; 
  		
     IF processType = 3 AND IFNULL(Scheme_ID,0) > 0 then
  		
        DELETE FROM Inc_Scheme_Master c WHERE c.Is_ID = Scheme_ID;
        
     
        
        IF ROW_COUNT() > 0 then
           SET v_errcode = 0;
           SET v_errmsg = 'Success to delete the Incentive Structre';
        end if;
     end if;
  
  SELECT v_errcode AS errcode, v_errmsg AS errmsg; 
  
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Reseller_device_insert_stock_order` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `Reseller_device_insert_stock_order`(
	Reseller_Id INT
	,comp_user_id INT
	,phone_charge FLOAT
	,discount FLOAT
	,tax_fee FLOAT
	,charge FLOAT
	,stock_item LONGTEXT
	,plan_total_charge FLOAT
	,Number_charge FLOAT
	,Product LONGTEXT
	,Plan VARCHAR(60)
	,Duration INT
	,Users INT
	,plan_ind_amount FLOAT
	,discount_no_of_month int
	,no_of_user_purchase int
	,no_of_term int
	,Discount_remark varchar(150)
	,plan_id int
	,product_id int
	,jsonAddonInfo json
	,addon_total_charge FLOAT
	,addon_total_chargewithout_tax FLOAT
	,addon_Pay_Reference VARCHAR(50)
	,addon_tax_per FLOAT
	,addon_tax_fee FLOAT
	,setup_price float
	,setup_discount float
    ,p_platform_user_fee float
	,p_platform_user_count int
      )
begin
             
             
             
                DECLARE v_errcode INT DEFAULT -1;
                DECLARE v_errmsg VARCHAR(50) DEFAULT 'failure';
                DECLARE v_order_id INT;
                DECLARE v_extn_order_id INT;
                DECLARE v_assign_type INT;
                DECLARE v_hdoc INT;
                DECLARE v_external_number VARCHAR(15);
       		
                DECLARE v_i INT DEFAULT 0;
                DECLARE v_tot_item INT;
                DECLARE v_id INT;
                DECLARE v_item_qty INT DEFAULT 0;
                DECLARE v_order_itemid INT;
                DECLARE v_j INT DEFAULT 0;
                DECLARE v_delivery_group INT;
                DECLARE v_k INT DEFAULT 0;
                DECLARE v_sd_id INT;
                DECLARE v_domain_id INT;
                DECLARE v_domain_name VARCHAR(30);
                DECLARE v_extn_pwd VARCHAR(30);
                DECLARE v_pk_company_Id INT;
                DECLARE v_total_shipping_charge FLOAT;
                DECLARE v_vec_device_qty INT; 
                DECLARE v_vec_device_product_id INT;
         
         		DECLARE v_category VARCHAR(50);
         		DECLARE v_customer_name VARCHAR(150);
         		DECLARE v_address1 VARCHAR(150);
         		DECLARE v_address2 VARCHAR(150);
         		DECLARE v_city VARCHAR(50);
         		DECLARE v_postcode VARCHAR(20);
         		DECLARE v_country VARCHAR(80);
         		DECLARE v_phone_model VARCHAR(100);
         		DECLARE v_phone_id  VARCHAR(100);
         		DECLARE v_phone_desc  VARCHAR(100);
         		DECLARE v_price VARCHAR(100);
         		DECLARE v_phone_weight VARCHAR(100);
         		DECLARE v_ean_no VARCHAR(100);
         		DECLARE v_quantity VARCHAR(100);
         		DECLARE v_delivery_group_id VARCHAR(100);
         		DECLARE v_shipping_charge VARCHAR(100);
         		DECLARE v_shipping_tax_fee VARCHAR(100);
         		DECLARE v_external_number_xml VARCHAR(100);
         		DECLARE v_email VARCHAR(150);
         		DECLARE v_Vec_device_product_id_xml VARCHAR(100);
         		DECLARE v_billing_address1 text;
         		DECLARE v_billing_address2 text;
         		DECLARE v_billing_city text;
         		DECLARE v_billing_postcode text;
       
         
                Sp_exit:
                BEGIN
                   set v_assign_type = 8;
                   
					drop TEMPORARY table IF EXISTS tt_device_order;          
					create TEMPORARY table tt_device_order
                   (
                      id INT   AUTO_INCREMENT PRIMARY KEY,
                      category VARCHAR(50),
                      customer_name VARCHAR(150),
                      address1 VARCHAR(150),
                      address2 VARCHAR(150),
                      city VARCHAR(50),
                      postcode VARCHAR(20),
                      country VARCHAR(80),
                      phone_id VARCHAR(100),
                      phone_desc VARCHAR(100),
                      price FLOAT,
                      phone_weight FLOAT,
                      ean_no VARCHAR(100),
                      quantity INT,
                      status INT,
                      delivery_group INT,
                      shipping_charge FLOAT,
                      shipping_tax_fee FLOAT,
                      phone_model VARCHAR(100),
                      external_number VARCHAR(15),
                      email VARCHAR(150),
                      Vec_device_product_id INT,
                      billing_address1 varchar(250),
                      billing_address2 varchar(250),
                      billing_city varchar(250),
                      billing_postcode varchar(250)
                   );     
                   
           	
              
              drop temporary table if exists xml_category_tbl; create temporary table xml_category_tbl( id int auto_increment primary key,category varchar(50));
              drop temporary table if exists xml_customer_name_tbl; create temporary table xml_customer_name_tbl( id int auto_increment primary key,customer_name varchar(150));
              drop temporary table if exists xml_address1_tbl; create temporary table xml_address1_tbl( id int auto_increment primary key,address1 varchar(150));
              drop temporary table if exists xml_address2_tbl; create temporary table xml_address2_tbl( id int auto_increment primary key,address2 varchar(150));
              drop temporary table if exists xml_city_tbl; create temporary table xml_city_tbl( id int auto_increment primary key,city varchar(50));
              drop temporary table if exists xml_postcode_tbl; create temporary table xml_postcode_tbl( id int auto_increment primary key,postcode varchar(50));
              drop temporary table if exists xml_country_tbl; create temporary table xml_country_tbl( id int auto_increment primary key,country varchar(50));
              drop temporary table if exists xml_phone_model_tbl; create temporary table xml_phone_model_tbl( id int auto_increment primary key,phone_model VARCHAR(100));
              drop temporary table if exists xml_phone_id_tbl; create temporary table xml_phone_id_tbl( id int auto_increment primary key,phone_id VARCHAR(100));
              drop temporary table if exists xml_phone_desc_tbl; create temporary table xml_phone_desc_tbl( id int auto_increment primary key,phone_desc VARCHAR(100));
              drop temporary table if exists xml_price_tbl; create temporary table xml_price_tbl( id int auto_increment primary key,price float);
              drop temporary table if exists xml_phone_weight_tbl; create temporary table xml_phone_weight_tbl( id int auto_increment primary key,phone_weight float);     
              drop temporary table if exists xml_ean_no_tbl; create temporary table xml_ean_no_tbl( id int auto_increment primary key,ean_no VARCHAR(100));
              drop temporary table if exists xml_quantity_tbl; create temporary table xml_quantity_tbl( id int auto_increment primary key,quantity int);
              drop temporary table if exists xml_delivery_group_tbl; create temporary table xml_delivery_group_tbl( id int auto_increment primary key,delivery_group int);
              drop temporary table if exists xml_shipping_charge_tbl; create temporary table xml_shipping_charge_tbl( id int auto_increment primary key,shipping_charge float);
               drop temporary table if exists xml_shipping_tax_fee_tbl; create temporary table xml_shipping_tax_fee_tbl( id int auto_increment primary key,shipping_tax_fee float);
              drop temporary table if exists xml_external_number_tbl; create temporary table xml_external_number_tbl( id int auto_increment primary key,external_number VARCHAR(15));
              drop temporary table if exists xml_email_tbl; create temporary table xml_email_tbl( id int auto_increment primary key,email VARCHAR(150));
              drop temporary table if exists xml_Vec_device_product_id_tbl; create temporary table xml_Vec_device_product_id_tbl( id int auto_increment primary key,Vec_device_product_id int);
              
              drop temporary table if exists xml_billing_address1_tbl; create temporary table xml_billing_address1_tbl( id int auto_increment primary key,billing_address1 varchar(250));
              drop temporary table if exists xml_billing_address2_tbl; create temporary table xml_billing_address2_tbl( id int auto_increment primary key,billing_address2 varchar(250));
              drop temporary table if exists xml_billing_city_tbl; create temporary table xml_billing_city_tbl( id int auto_increment primary key,billing_city varchar(250));
              drop temporary table if exists xml_billing_postcode_tbl; create temporary table xml_billing_postcode_tbl( id int auto_increment primary key,billing_postcode varchar(250));
                        
          		SELECT 	replace(ExtractValue(stock_item, '//category[1]'),' ',','), 		replace(ExtractValue(stock_item, '//customer_name[1]'),' ',','), 
          				replace(ExtractValue(stock_item, '//address1[1]'),' ',','),			replace(ExtractValue(stock_item, '//address2[1]'),' ',','),
          				replace(ExtractValue(stock_item, '//city[1]'),' ',','), 			replace(ExtractValue(stock_item, '//postcode[1]'),' ',','), 
          				replace(ExtractValue(stock_item, '//country[1]'),' ',','),			replace(ExtractValue(stock_item, '//phone_model[1]'),' ',','),
          				replace(ExtractValue(stock_item, '//phone_id[1]'),' ',','), 		replace(ExtractValue(stock_item, '//phone_desc[1]'),' ',','), 
          				replace(ExtractValue(stock_item, '//price[1]'),' ',','),			replace(ExtractValue(stock_item, '//phone_weight[1]'),' ',','),
          				replace(ExtractValue(stock_item, '//ean_no[1]'),' ',','), 			replace(ExtractValue(stock_item, '//quantity[1]'),' ',','), 
          				replace(ExtractValue(stock_item, '//delivery_group[1]'),' ',','),	replace(ExtractValue(stock_item, '//shipping_charge[1]'),' ',','),
          				replace(ExtractValue(stock_item, '//shipping_tax_fee[1]'),' ',','),	replace(ExtractValue(stock_item, '//external_number[1]'),' ',','), 
          				replace(ExtractValue(stock_item, '//email[1]'),' ',','),			replace(ExtractValue(stock_item, '//Vec_device_product_id[1]'),' ',','),          
                         replace(ExtractValue(stock_item, '//billing_address1[1]'),' ',','),	replace(ExtractValue(stock_item, '//billing_address2[1]'),' ',','),
                         replace(ExtractValue(stock_item, '//billing_city[1]'),' ',','),		replace(ExtractValue(stock_item, '//billing_postcode[1]'),' ',',')   
         	   into v_category,v_customer_name,v_address1,v_address2,v_city,v_postcode,v_country,v_phone_model,v_phone_id,v_phone_desc,v_price,v_phone_weight,
         	   v_ean_no,v_quantity,v_delivery_group_id,v_shipping_charge,v_shipping_tax_fee,v_external_number_xml,v_email,v_Vec_device_product_id_xml,v_billing_address1,v_billing_address2,v_billing_city,v_billing_postcode;  
         	   
                 
          			call unifiedring.Split(v_category,','); insert into xml_category_tbl(category) select Items from unifiedring.tt_Split_temptable;
          			call unifiedring.Split(v_customer_name,','); insert into xml_customer_name_tbl(customer_name) select Items from unifiedring.tt_Split_temptable;
          			call unifiedring.Split(v_address1,','); insert into xml_address1_tbl(address1) select Items from unifiedring.tt_Split_temptable;
          			call unifiedring.Split(v_address2,','); insert into xml_address2_tbl(address2) select Items from unifiedring.tt_Split_temptable;
          			call unifiedring.Split(v_city,','); insert into xml_city_tbl(city) select Items from unifiedring.tt_Split_temptable;
          			call unifiedring.Split(v_postcode,','); insert into xml_postcode_tbl(postcode) select Items from unifiedring.tt_Split_temptable;
          			call unifiedring.Split(v_country,','); insert into xml_country_tbl(country) select Items from unifiedring.tt_Split_temptable;
          			call unifiedring.Split(v_phone_model,','); insert into xml_phone_model_tbl(phone_model) select Items from unifiedring.tt_Split_temptable;
          			call unifiedring.Split(v_phone_id,','); insert into xml_phone_id_tbl(phone_id) select Items from unifiedring.tt_Split_temptable;
          			call unifiedring.Split(v_phone_desc,','); insert into xml_phone_desc_tbl(phone_desc) select Items from unifiedring.tt_Split_temptable;
          			call unifiedring.Split(v_price,','); insert into xml_price_tbl(price) select Items from unifiedring.tt_Split_temptable;
          			call unifiedring.Split(v_phone_weight,','); insert into xml_phone_weight_tbl(phone_weight) select Items from unifiedring.tt_Split_temptable;
          			call unifiedring.Split(v_ean_no,','); insert into xml_ean_no_tbl(ean_no) select Items from unifiedring.tt_Split_temptable;
          			call unifiedring.Split(v_quantity,','); insert into xml_quantity_tbl(quantity) select Items from unifiedring.tt_Split_temptable;
          			call unifiedring.Split(v_delivery_group_id,','); insert into xml_delivery_group_tbl(delivery_group) select Items from unifiedring.tt_Split_temptable;
          			call unifiedring.Split(v_shipping_charge,','); insert into xml_shipping_charge_tbl(shipping_charge) select Items from unifiedring.tt_Split_temptable;
          			call unifiedring.Split(v_shipping_tax_fee,','); insert into xml_shipping_tax_fee_tbl(shipping_tax_fee) select Items from unifiedring.tt_Split_temptable;
          			call unifiedring.Split(v_external_number_xml,','); insert into xml_external_number_tbl(external_number) select Items from unifiedring.tt_Split_temptable;
          			call unifiedring.Split(v_email,','); insert into xml_email_tbl(email) select Items from unifiedring.tt_Split_temptable;
          			call unifiedring.Split(v_Vec_device_product_id_xml,','); insert into xml_Vec_device_product_id_tbl(Vec_device_product_id) select Items from unifiedring.tt_Split_temptable;
         
                     call unifiedring.Split(v_billing_address1,','); insert into xml_billing_address1_tbl(billing_address1) select Items from unifiedring.tt_Split_temptable;
                     call unifiedring.Split(v_billing_address2,','); insert into xml_billing_address2_tbl(billing_address2) select Items from unifiedring.tt_Split_temptable;
                     call unifiedring.Split(v_billing_city,','); insert into xml_billing_city_tbl(billing_city) select Items from unifiedring.tt_Split_temptable;
                     call unifiedring.Split(v_billing_postcode,','); insert into xml_billing_postcode_tbl(billing_postcode) select Items from unifiedring.tt_Split_temptable;
                
                insert into tt_device_order(category,customer_name,address1,address2,city,postcode,country,phone_model,phone_id,phone_desc,price,phone_weight,ean_no,quantity,delivery_group,shipping_charge,shipping_tax_fee,
          				external_number,email,Vec_device_product_id,billing_address1,billing_address2,billing_city,billing_postcode)
                select 	category,customer_name,address1,address2,city,postcode,country,phone_model,phone_id,phone_desc,price,phone_weight,ean_no,quantity,delivery_group,shipping_charge,shipping_tax_fee,
          				external_number,email,Vec_device_product_id,billing_address1,billing_address2,billing_city,billing_postcode
                from xml_category_tbl a 
                left join xml_customer_name_tbl b on a.id = b.id
                left join xml_address1_tbl c on a.id = c.id
                left join xml_address2_tbl d on a.id = d.id
                left join xml_city_tbl e on a.id=e.id
                left join xml_postcode_tbl f on a.id=f.id
                left join xml_country_tbl g on a.id=g.id
                left join xml_phone_model_tbl h on a.id=h.id
                left join xml_phone_id_tbl i on a.id=i.id
                left join xml_phone_desc_tbl k on a.id=k.id
                left join xml_price_tbl l on a.id=l.id
                left join xml_phone_weight_tbl m on a.id=m.id
                left join xml_ean_no_tbl n on a.id=n.id
                left join xml_quantity_tbl o on a.id=o.id
                left join xml_delivery_group_tbl p on a.id=p.id
                left join xml_shipping_charge_tbl q on a.id=q.id
                left join xml_shipping_tax_fee_tbl r on a.id=r.id
                left join xml_external_number_tbl s on a.id=s.id
                left join xml_email_tbl t on a.id =t.id
                left join xml_Vec_device_product_id_tbl u on a.id=u.id
                left join xml_billing_address1_tbl v on a.id=v.id
                left join xml_billing_address2_tbl w on a.id=w.id
                left join xml_billing_city_tbl x on a.id=x.id
                left join xml_billing_postcode_tbl y on a.id=y.id;
                
                     
                     
     			insert into res_temp_id(Reseller_Id,comp_user_id) values(Reseller_Id,comp_user_id);
         
                   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
                   select Pk_rs_cmpid INTO v_pk_company_Id from  reseller_company a where a.reseller_id = Reseller_Id and a.cnt_ref_id = comp_user_id LIMIT 1;
                   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
                   
                   IF v_pk_company_Id IS NULL then   	
                      SET v_errcode = -1;
                      SET v_errmsg = 'Failure to get CompanyId';
                      LEAVE sp_exit;
                   end if;
                   
                   insert into Res_Comp_Device_Order(Fk_Resller_Id,Fk_rs_cmpid,tot_phone_charge,tot_discount,tot_tax_fee,tot_charge,createdate,Order_source,Order_Status,plan_charge,Number_charge,product,plan,Duration,Users,plan_ind_amount,discount_no_of_month,no_of_user_purchase,no_of_term,Discount_remark ,plan_id, product_id,setup_price,setup_discount,platform_user_fee, platform_user_count)
                   select Reseller_Id,v_pk_company_Id,phone_charge,discount,tax_fee,charge,CURRENT_TIMESTAMP,'RESELLER',1,plan_total_charge,Number_charge,Product,Plan,Duration,Users,plan_ind_amount,discount_no_of_month,no_of_user_purchase,no_of_term,Discount_remark,plan_id, product_id,setup_price,setup_discount,p_platform_user_fee, p_platform_user_count ;
                   
                   SET v_order_id = LAST_INSERT_ID();
                   set v_extn_order_id = LAST_INSERT_ID();
                   
                   if ROW_COUNT() > 0 then 
                      SET v_errcode = 0;
                      SET v_errmsg = 'success';
                   end if;
                   
                   select count(1) INTO v_tot_item from tt_device_order;
                   
                   while v_i < v_tot_item DO
                      set v_item_qty = 0;
                      set v_id = 0;
                      set v_j = 0;
                      set v_item_qty = 0;
                      set v_delivery_group = 0;
             
             
                      select id, quantity, delivery_group INTO v_id,v_item_qty,v_delivery_group from tt_device_order where IFNULL(status,0) = 0 order by delivery_group asc LIMIT 1;
             
             
             
                      if v_delivery_group > v_k then
             
           			 insert into  Res_Order_delivery_address(Order_Id,customer_name,address1,address2,city,postcode,country,shipping_charge,shipping_tax_fee,createdate,email,
                      billing_address1,billing_address2,billing_city,billing_postcode)
           			 select v_order_id,a.customer_name,a.address1,address2,city,postcode,country,shipping_charge,shipping_tax_fee,CURRENT_TIMESTAMP,email,
                      a.billing_address1,a.billing_address2,a.billing_city,a.billing_postcode 
           			 from tt_device_order a
           			 where a.id = v_id;
                      
             
                
                         SET v_sd_id = LAST_INSERT_ID();
                         set v_k = v_delivery_group;
                      end if;
                      
                      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
                      select sum(IFNULL(shipping_charge,0)) INTO v_total_shipping_charge from Res_Order_delivery_address where order_id = v_order_id;
                      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
                      set v_total_shipping_charge = IFNULL(v_total_shipping_charge,0);
                      update Res_Comp_Device_Order set Shipping_charge = v_total_shipping_charge
                      Where Order_Id = v_order_id;
                      
                      set v_vec_device_qty = 0;
                      set v_vec_device_product_id = 0;
                      
          			insert into Res_device_order_item(order_id,sd_id,category,
          			phone_id,phone_desc,price,weight,ean_no,quantity,status,phone_model,external_number,Vec_device_product_id)
          			select  v_order_id,v_sd_id,category,phone_id,phone_desc,price,
          			phone_weight,ean_no,quantity,1,phone_model,external_number,Vec_device_product_id
          			from tt_device_order where id = v_id;
                      
                      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
                      select quantity, Vec_device_product_id INTO v_vec_device_qty,v_vec_device_product_id from tt_device_order where id = v_id;
                      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
                      
                      IF IFNULL(v_vec_device_product_id,0) > 0 and IFNULL(v_vec_device_qty,0) > 0 then
                         CALL DEVICEMGT.device_mgt_update_stock_product(v_vec_device_product_id,v_vec_device_qty,null);               
                      end if;
                      
                      select external_number INTO v_external_number from tt_device_order where id = v_id; 
           
                      update tt_device_order set status = 1 where id = v_id;
                      
                      set v_i = v_i+1;
                   END WHILE;
                END;
                
    		if jsonAddonInfo is not null and comp_user_id is not null then
    			
               
               insert into reseller_addon_purchase_info (comp_user_id,plan_id,jsonAddonInfo,addon_total_charge,addon_total_chargewithout_tax,addon_Pay_Reference,addon_tax_per,addon_tax_fee)
   			values(comp_user_id,plan_id,jsonAddonInfo,addon_total_charge,addon_total_chargewithout_tax,addon_Pay_Reference,addon_tax_per,addon_tax_fee);
               
           end if;
                
                select v_errcode errcode,v_errmsg errmsg,v_domain_name domain_name,v_extn_pwd extn_pwd;
             
             end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Reseller_device_insert_stock_order1` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `Reseller_device_insert_stock_order1`(
     Reseller_Id INT,
     comp_user_id INT,
     phone_charge FLOAT,
     discount FLOAT,
     tax_fee FLOAT,
     charge FLOAT,
     stock_item LONGTEXT,
     plan_total_charge FLOAT,
     Number_charge FLOAT,
     Product LONGTEXT,          
     Plan VARCHAR(60),          
     Duration INT,          
     Users INT,          
     plan_ind_amount FLOAT)
sp_return : begin
     
     
     
        DECLARE v_errcode INT DEFAULT -1;
        DECLARE v_errmsg VARCHAR(50) DEFAULT 'failure';
        DECLARE v_order_id INT;
        DECLARE v_extn_order_id INT;
        DECLARE v_assign_type INT;
        DECLARE v_hdoc INT;
        DECLARE v_external_number VARCHAR(15);
     
        DECLARE v_i INT DEFAULT 0;
        DECLARE v_tot_item INT;
        DECLARE v_id INT;
        DECLARE v_item_qty INT DEFAULT 0;
        DECLARE v_order_itemid INT;
        DECLARE v_j INT DEFAULT 0;
        DECLARE v_delivery_group INT;
        DECLARE v_k INT DEFAULT 0;
        DECLARE v_sd_id INT;
        DECLARE v_domain_id INT;
        DECLARE v_domain_name VARCHAR(30);
        DECLARE v_extn_pwd VARCHAR(30);
        DECLARE v_pk_company_Id INT;
        DECLARE v_total_shipping_charge FLOAT;
        DECLARE v_vec_device_qty INT; 
        DECLARE v_vec_device_product_id INT;
 
 		DECLARE v_category VARCHAR(50);
 		DECLARE v_customer_name VARCHAR(150);
 		DECLARE v_address1 VARCHAR(150);
 		DECLARE v_address2 VARCHAR(150);
 		DECLARE v_city VARCHAR(50);
 		DECLARE v_postcode VARCHAR(20);
 		DECLARE v_country VARCHAR(80);
 		DECLARE v_phone_model VARCHAR(100);
 		DECLARE v_phone_id  VARCHAR(100);
 		DECLARE v_phone_desc  VARCHAR(100);
 		DECLARE v_price VARCHAR(100);
 		DECLARE v_phone_weight VARCHAR(100);
 		DECLARE v_ean_no VARCHAR(100);
 		DECLARE v_quantity VARCHAR(100);
 		DECLARE v_delivery_group_id VARCHAR(100);
 		DECLARE v_shipping_charge VARCHAR(100);
 		DECLARE v_shipping_tax_fee VARCHAR(100);
 		DECLARE v_external_number_xml VARCHAR(100);
 		DECLARE v_email VARCHAR(150);
 		DECLARE v_Vec_device_product_id_xml VARCHAR(100);
 		DECLARE v_billing_address1 text;
 		DECLARE v_billing_address2 text;
 		DECLARE v_billing_city text;
 		DECLARE v_billing_postcode text;
 
        Sp_exit:
        BEGIN
           set v_assign_type = 8;
           
            drop TEMPORARY table IF EXISTS tt_device_order;          
           create TEMPORARY table tt_device_order
           (
              id INT   AUTO_INCREMENT PRIMARY KEY,
              category VARCHAR(50),
              customer_name VARCHAR(150),
              address1 VARCHAR(150),
              address2 VARCHAR(150),
              city VARCHAR(50),
              postcode VARCHAR(20),
              country VARCHAR(80),
              phone_id VARCHAR(100),
              phone_desc VARCHAR(100),
              price FLOAT,
              phone_weight FLOAT,
              ean_no VARCHAR(100),
              quantity INT,
              status INT,
              delivery_group INT,
              shipping_charge FLOAT,
              shipping_tax_fee FLOAT,
              phone_model VARCHAR(100),
              external_number VARCHAR(15),
              email VARCHAR(150),
              Vec_device_product_id INT,
              billing_address1 varchar(250),
              billing_address2 varchar(250),
              billing_city varchar(250),
              billing_postcode varchar(250)
           );     
           
   	
      
      drop temporary table if exists xml_category_tbl; create temporary table xml_category_tbl( id int auto_increment primary key,category varchar(50));
      drop temporary table if exists xml_customer_name_tbl; create temporary table xml_customer_name_tbl( id int auto_increment primary key,customer_name varchar(150));
      drop temporary table if exists xml_address1_tbl; create temporary table xml_address1_tbl( id int auto_increment primary key,address1 varchar(150));
      drop temporary table if exists xml_address2_tbl; create temporary table xml_address2_tbl( id int auto_increment primary key,address2 varchar(150));
      drop temporary table if exists xml_city_tbl; create temporary table xml_city_tbl( id int auto_increment primary key,city varchar(50));
      drop temporary table if exists xml_postcode_tbl; create temporary table xml_postcode_tbl( id int auto_increment primary key,postcode varchar(50));
      drop temporary table if exists xml_country_tbl; create temporary table xml_country_tbl( id int auto_increment primary key,country varchar(50));
      drop temporary table if exists xml_phone_model_tbl; create temporary table xml_phone_model_tbl( id int auto_increment primary key,phone_model VARCHAR(100));
      drop temporary table if exists xml_phone_id_tbl; create temporary table xml_phone_id_tbl( id int auto_increment primary key,phone_id VARCHAR(100));
      drop temporary table if exists xml_phone_desc_tbl; create temporary table xml_phone_desc_tbl( id int auto_increment primary key,phone_desc VARCHAR(100));
      drop temporary table if exists xml_price_tbl; create temporary table xml_price_tbl( id int auto_increment primary key,price float);
      drop temporary table if exists xml_phone_weight_tbl; create temporary table xml_phone_weight_tbl( id int auto_increment primary key,phone_weight float);     
      drop temporary table if exists xml_ean_no_tbl; create temporary table xml_ean_no_tbl( id int auto_increment primary key,ean_no VARCHAR(100));
      drop temporary table if exists xml_quantity_tbl; create temporary table xml_quantity_tbl( id int auto_increment primary key,quantity int);
      drop temporary table if exists xml_delivery_group_tbl; create temporary table xml_delivery_group_tbl( id int auto_increment primary key,delivery_group int);
      drop temporary table if exists xml_shipping_charge_tbl; create temporary table xml_shipping_charge_tbl( id int auto_increment primary key,shipping_charge float);
       drop temporary table if exists xml_shipping_tax_fee_tbl; create temporary table xml_shipping_tax_fee_tbl( id int auto_increment primary key,shipping_tax_fee float);
      drop temporary table if exists xml_external_number_tbl; create temporary table xml_external_number_tbl( id int auto_increment primary key,external_number VARCHAR(15));
      drop temporary table if exists xml_email_tbl; create temporary table xml_email_tbl( id int auto_increment primary key,email VARCHAR(150));
      drop temporary table if exists xml_Vec_device_product_id_tbl; create temporary table xml_Vec_device_product_id_tbl( id int auto_increment primary key,Vec_device_product_id int);
      
      drop temporary table if exists xml_billing_address1_tbl; create temporary table xml_billing_address1_tbl( id int auto_increment primary key,billing_address1 varchar(250));
      drop temporary table if exists xml_billing_address2_tbl; create temporary table xml_billing_address2_tbl( id int auto_increment primary key,billing_address2 varchar(250));
      drop temporary table if exists xml_billing_city_tbl; create temporary table xml_billing_city_tbl( id int auto_increment primary key,billing_city varchar(250));
      drop temporary table if exists xml_billing_postcode_tbl; create temporary table xml_billing_postcode_tbl( id int auto_increment primary key,billing_postcode varchar(250));
      
      
         
  		SELECT 	replace(ExtractValue(stock_item, '//category[1]'),' ',','), 		replace(ExtractValue(stock_item, '//customer_name[1]'),' ',','), 
  				replace(ExtractValue(stock_item, '//address1[1]'),' ',','),			replace(ExtractValue(stock_item, '//address2[1]'),' ',','),
  				replace(ExtractValue(stock_item, '//city[1]'),' ',','), 			replace(ExtractValue(stock_item, '//postcode[1]'),' ',','), 
  				replace(ExtractValue(stock_item, '//country[1]'),' ',','),			replace(ExtractValue(stock_item, '//phone_model[1]'),' ',','),
  				replace(ExtractValue(stock_item, '//phone_id[1]'),' ',','), 		replace(ExtractValue(stock_item, '//phone_desc[1]'),' ',','), 
  				replace(ExtractValue(stock_item, '//price[1]'),' ',','),			replace(ExtractValue(stock_item, '//phone_weight[1]'),' ',','),
  				replace(ExtractValue(stock_item, '//ean_no[1]'),' ',','), 			replace(ExtractValue(stock_item, '//quantity[1]'),' ',','), 
  				replace(ExtractValue(stock_item, '//delivery_group[1]'),' ',','),	replace(ExtractValue(stock_item, '//shipping_charge[1]'),' ',','),
  				replace(ExtractValue(stock_item, '//shipping_tax_fee[1]'),' ',','),	replace(ExtractValue(stock_item, '//external_number[1]'),' ',','), 
  				replace(ExtractValue(stock_item, '//email[1]'),' ',','),			replace(ExtractValue(stock_item, '//Vec_device_product_id[1]'),' ',','),          
                 replace(ExtractValue(stock_item, '//billing_address1[1]'),' ',','),	replace(ExtractValue(stock_item, '//billing_address2[1]'),' ',','),
                 replace(ExtractValue(stock_item, '//billing_city[1]'),' ',','),		replace(ExtractValue(stock_item, '//billing_postcode[1]'),' ',',')   
 	   into v_category,v_customer_name,v_address1,v_address2,v_city,v_postcode,v_country,v_phone_model,v_phone_id,v_phone_desc,v_price,v_phone_weight,
 	   v_ean_no,v_quantity,v_delivery_group_id,v_shipping_charge,v_shipping_tax_fee,v_external_number_xml,v_email,v_Vec_device_product_id_xml,v_billing_address1,v_billing_address2,v_billing_city,v_billing_postcode;
       
       select v_category,v_customer_name,v_address1,v_address2,v_city,v_postcode,v_country,v_phone_model,v_phone_id,v_phone_desc,v_price,v_phone_weight,
 	   v_ean_no,v_quantity,v_delivery_group_id,v_shipping_charge,v_shipping_tax_fee,v_external_number_xml,v_email,v_Vec_device_product_id_xml,v_billing_address1,v_billing_address2,v_billing_city,v_billing_postcode;
 	   
         leave sp_return;
         
  			call unifiedring.Split(v_category,','); insert into xml_category_tbl(category) select Items from unifiedring.tt_Split_temptable;
  			call unifiedring.Split(v_customer_name,','); insert into xml_customer_name_tbl(customer_name) select Items from unifiedring.tt_Split_temptable;
  			call unifiedring.Split(v_address1,','); insert into xml_address1_tbl(address1) select Items from unifiedring.tt_Split_temptable;
  			call unifiedring.Split(v_address2,','); insert into xml_address2_tbl(address2) select Items from unifiedring.tt_Split_temptable;
  			call unifiedring.Split(v_city,','); insert into xml_city_tbl(city) select Items from unifiedring.tt_Split_temptable;
  			call unifiedring.Split(v_postcode,','); insert into xml_postcode_tbl(postcode) select Items from unifiedring.tt_Split_temptable;
  			call unifiedring.Split(v_country,','); insert into xml_country_tbl(country) select Items from unifiedring.tt_Split_temptable;
  			call unifiedring.Split(v_phone_model,','); insert into xml_phone_model_tbl(phone_model) select Items from unifiedring.tt_Split_temptable;
  			call unifiedring.Split(v_phone_id,','); insert into xml_phone_id_tbl(phone_id) select Items from unifiedring.tt_Split_temptable;
  			call unifiedring.Split(v_phone_desc,','); insert into xml_phone_desc_tbl(phone_desc) select Items from unifiedring.tt_Split_temptable;
  			call unifiedring.Split(v_price,','); insert into xml_price_tbl(price) select Items from unifiedring.tt_Split_temptable;
  			call unifiedring.Split(v_phone_weight,','); insert into xml_phone_weight_tbl(phone_weight) select Items from unifiedring.tt_Split_temptable;
  			call unifiedring.Split(v_ean_no,','); insert into xml_ean_no_tbl(ean_no) select Items from unifiedring.tt_Split_temptable;
  			call unifiedring.Split(v_quantity,','); insert into xml_quantity_tbl(quantity) select Items from unifiedring.tt_Split_temptable;
  			call unifiedring.Split(v_delivery_group_id,','); insert into xml_delivery_group_tbl(delivery_group) select Items from unifiedring.tt_Split_temptable;
  			call unifiedring.Split(v_shipping_charge,','); insert into xml_shipping_charge_tbl(shipping_charge) select Items from unifiedring.tt_Split_temptable;
  			call unifiedring.Split(v_shipping_tax_fee,','); insert into xml_shipping_tax_fee_tbl(shipping_tax_fee) select Items from unifiedring.tt_Split_temptable;
  			call unifiedring.Split(v_external_number_xml,','); insert into xml_external_number_tbl(external_number) select Items from unifiedring.tt_Split_temptable;
  			call unifiedring.Split(v_email,','); insert into xml_email_tbl(email) select Items from unifiedring.tt_Split_temptable;
  			call unifiedring.Split(v_Vec_device_product_id_xml,','); insert into xml_Vec_device_product_id_tbl(Vec_device_product_id) select Items from unifiedring.tt_Split_temptable;
 
             call unifiedring.Split(v_billing_address1,','); insert into xml_billing_address1_tbl(billing_address1) select Items from unifiedring.tt_Split_temptable;
             call unifiedring.Split(v_billing_address2,','); insert into xml_billing_address2_tbl(billing_address2) select Items from unifiedring.tt_Split_temptable;
             call unifiedring.Split(v_billing_city,','); insert into xml_billing_city_tbl(billing_city) select Items from unifiedring.tt_Split_temptable;
             call unifiedring.Split(v_billing_postcode,','); insert into xml_billing_postcode_tbl(billing_postcode) select Items from unifiedring.tt_Split_temptable;
        
        insert into tt_device_order(category,customer_name,address1,address2,city,postcode,country,phone_model,phone_id,phone_desc,price,phone_weight,ean_no,quantity,delivery_group,shipping_charge,shipping_tax_fee,
  				external_number,email,Vec_device_product_id,billing_address1,billing_address2,billing_city,billing_postcode)
        select 	category,customer_name,address1,address2,city,postcode,country,phone_model,phone_id,phone_desc,price,phone_weight,ean_no,quantity,delivery_group,shipping_charge,shipping_tax_fee,
  				external_number,email,Vec_device_product_id,billing_address1,billing_address2,billing_city,billing_postcode
        from xml_category_tbl a 
        left join xml_customer_name_tbl b on a.id = b.id
        left join xml_address1_tbl c on a.id = c.id
        left join xml_address2_tbl d on a.id = d.id
        left join xml_city_tbl e on a.id=e.id
        left join xml_postcode_tbl f on a.id=f.id
        left join xml_country_tbl g on a.id=g.id
        left join xml_phone_model_tbl h on a.id=h.id
        left join xml_phone_id_tbl i on a.id=i.id
        left join xml_phone_desc_tbl k on a.id=k.id
        left join xml_price_tbl l on a.id=l.id
        left join xml_phone_weight_tbl m on a.id=m.id
        left join xml_ean_no_tbl n on a.id=n.id
        left join xml_quantity_tbl o on a.id=o.id
        left join xml_delivery_group_tbl p on a.id=p.id
        left join xml_shipping_charge_tbl q on a.id=q.id
        left join xml_shipping_tax_fee_tbl r on a.id=r.id
        left join xml_external_number_tbl s on a.id=s.id
        left join xml_email_tbl t on a.id =t.id
        left join xml_Vec_device_product_id_tbl u on a.id=u.id
        left join xml_billing_address1_tbl v on a.id=v.id
        left join xml_billing_address2_tbl w on a.id=w.id
        left join xml_billing_city_tbl x on a.id=x.id
        left join xml_billing_postcode_tbl y on a.id=y.id;
        
             
 
           SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
           select Pk_rs_cmpid INTO v_pk_company_Id from  reseller_company a where a.reseller_id = Reseller_Id and a.cnt_ref_id = comp_user_id LIMIT 1;
           SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
           
           IF v_pk_company_Id IS NULL then   	
              SET v_errcode = -1;
              SET v_errmsg = 'Failure to get CompanyId';
              LEAVE sp_exit;
           end if;
           
           insert into Res_Comp_Device_Order(Fk_Resller_Id,Fk_rs_cmpid,tot_phone_charge,tot_discount,tot_tax_fee,tot_charge,createdate,Order_source,Order_Status,plan_charge,Number_charge,product,plan,Duration,Users,plan_ind_amount)
           select Reseller_Id,v_pk_company_Id,phone_charge,discount,tax_fee,charge,CURRENT_TIMESTAMP,'RESELLER',1,plan_total_charge,Number_charge,Product,Plan,Duration,Users,plan_ind_amount;
           
           SET v_order_id = LAST_INSERT_ID();
           set v_extn_order_id = LAST_INSERT_ID();
           
           if ROW_COUNT() > 0 then 
              SET v_errcode = 0;
              SET v_errmsg = 'success';
           end if;
           
           select count(1) INTO v_tot_item from tt_device_order;
           
           while v_i < v_tot_item DO
              set v_item_qty = 0;
              set v_id = 0;
              set v_j = 0;
              set v_item_qty = 0;
              set v_delivery_group = 0;
     
     
              select id, quantity, delivery_group INTO v_id,v_item_qty,v_delivery_group from tt_device_order where IFNULL(status,0) = 0 order by delivery_group asc LIMIT 1;
     
     
     
              if v_delivery_group > v_k then
     
   			 insert into  Res_Order_delivery_address(Order_Id,customer_name,address1,address2,city,postcode,country,shipping_charge,shipping_tax_fee,createdate,email,
              billing_address1,billing_address2,billing_city,billing_postcode)
   			 select v_order_id,a.customer_name,a.address1,address2,city,postcode,country,shipping_charge,shipping_tax_fee,CURRENT_TIMESTAMP,email,
              a.billing_address1,a.billing_address2,a.billing_city,a.billing_postcode 
   			 from tt_device_order a
   			 where a.id = v_id;
              
     
        
                 SET v_sd_id = LAST_INSERT_ID();
                 set v_k = v_delivery_group;
              end if;
              
              SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
              select sum(IFNULL(shipping_charge,0)) INTO v_total_shipping_charge from Res_Order_delivery_address where order_id = v_order_id;
              SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
              set v_total_shipping_charge = IFNULL(v_total_shipping_charge,0);
              update Res_Comp_Device_Order set Shipping_charge = v_total_shipping_charge
              Where Order_Id = v_order_id;
              
              set v_vec_device_qty = 0;
              set v_vec_device_product_id = 0;
              
  			insert into Res_device_order_item(order_id,sd_id,category,
  			phone_id,phone_desc,price,weight,ean_no,quantity,status,phone_model,external_number,Vec_device_product_id)
  			select  v_order_id,v_sd_id,category,phone_id,phone_desc,price,
  			phone_weight,ean_no,quantity,1,phone_model,external_number,Vec_device_product_id
  			from tt_device_order where id = v_id;
              
              SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
              select quantity, Vec_device_product_id INTO v_vec_device_qty,v_vec_device_product_id from tt_device_order where id = v_id;
              SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
              
              IF IFNULL(v_vec_device_product_id,0) > 0 and IFNULL(v_vec_device_qty,0) > 0 then
                 CALL DEVICEMGT.device_mgt_update_stock_product(v_vec_device_product_id,v_vec_device_qty,null);               
              end if;
              
              select external_number INTO v_external_number from tt_device_order where id = v_id; 
   
              update tt_device_order set status = 1 where id = v_id;
              
              set v_i = v_i+1;
           END WHILE;
        END;
        
        select v_errcode errcode,v_errmsg errmsg,v_domain_name domain_name,v_extn_pwd extn_pwd;
     
     end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `reseller_get_addon_list` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `reseller_get_addon_list`(
  p_company_id int
  )
Begin
  select * from reseller_addon_purchase_info where comp_user_id = p_company_id;
  End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `reseller_get_admin_audit` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `reseller_get_admin_audit`(
p_reseller_id int,
p_fromdate varchar(10),
p_todate varchar(10)
)
sp_return:Begin

		declare v_partner_Name varchar(100);        declare v_Mobile varchar(100);		declare v_Email varchar(100);        declare v_Total_amount float;        declare v_commission_amount float;
        declare v_cnt int default 1;		        declare v_tcnt int;			        declare v_reseller_id int;
        
		Drop TEMPORARY table IF EXISTS tt_getresellerid_list; create TEMPORARY table tt_getresellerid_list( reseller_id INT );
        Drop TEMPORARY table IF EXISTS tt_resellerccount_list; create TEMPORARY table tt_resellerccount_list ( idcol int auto_increment primary key, reseller_id INT );
        
        Drop TEMPORARY table IF EXISTS tt_output_table;
		create TEMPORARY table tt_output_table
		(
			id int auto_increment primary key,
            reseller_id INT,
            partner_Name varchar(100),
            Mobile varchar(20),
            Email varchar(50),
            Total_revenue float,
            Total_commision float,
            from_date varchar(10),
            to_date varchar(10)
		);
  
		if p_reseller_id = 0 then
			insert into tt_resellerccount_list (reseller_id)
			select  Distinct rs.reseller_id
			from smereseller.Reseller_commisson_info rc
			join smereseller.Reseller rs on rc.reseller_id = rs.reseller_id
			where Comm_assigned_by = 'COMP-PURCHASE'  and rs.Fk_Reseller_Id=1005
			and cast(Comm_date as date) between p_fromdate and p_todate;
        else
			insert into tt_resellerccount_list (reseller_id) values(p_reseller_id);
        end if;
        
		select count(*) into v_tcnt from tt_resellerccount_list;
  
		while v_cnt <= v_tcnt do
			select gl.reseller_id into v_reseller_id from tt_resellerccount_list gl where gl.idcol = v_cnt;

				call smereseller.sme_reseller_get_subordinates_list_new(v_reseller_id);
				insert into tt_getresellerid_list select a.reseller_id from tt_new_reseller_id a;

				select concat(Firstname,' ',Lastname),Mobile,Email into v_partner_Name,v_Mobile,v_Email from smereseller.Reseller where reseller_id = v_reseller_id;

				set v_Total_amount=0;
                set v_commission_amount=0;

				select sum(Total_Purchase_amount) as Total_amount,sum(Comm_amount) as commission_amount 
				into v_Total_amount,v_commission_amount
				from smereseller.Reseller_commisson_info rc
				join tt_getresellerid_list gr on rc.reseller_id  = gr.reseller_id
				where Comm_assigned_by = 'COMP-PURCHASE'
				and cast(Comm_date as date) between p_fromdate and p_todate;
                
               delete from tt_getresellerid_list;
							
                insert into tt_output_table (reseller_id,partner_Name,Mobile,Email,from_date,to_date,Total_revenue,Total_commision) 
                values(v_reseller_id,v_partner_Name,v_Mobile,v_Email,p_fromdate,p_todate,v_Total_amount,v_commission_amount);

        set v_cnt = v_cnt + 1;
        end while;
    
		select * from tt_output_table;
        DROP TEMPORARY TABLE IF EXISTS tt_output_table;
        Drop TEMPORARY TABLE IF EXISTS tt_getresellerid_list; 
        Drop TEMPORARY TABLE IF EXISTS tt_resellerccount_list;
    
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `reseller_get_admin_revenue_details_graph` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `reseller_get_admin_revenue_details_graph`(
  p_daterange int
)
sp_return:Begin
  
  		declare v_Total_amount decimal(10,2);       declare v_commission_amount decimal(10,2);		declare v_fromdate varchar(10);	declare v_todate varchar(10);
          
         if p_daterange = 1 then set v_fromdate = DATE_FORMAT(NOW() ,'%Y-%m-01'); set v_todate = DATE_FORMAT(NOW(),'%Y-%m-%d'); end if;
         if p_daterange = 2 then set v_fromdate = DATE_SUB(CURDATE(), interval 90 day); set v_todate = DATE_FORMAT(NOW(),'%Y-%m-%d'); end if;
         if p_daterange = 3 then set v_fromdate = DATE_SUB(CURDATE(), interval 180 day); set v_todate = DATE_FORMAT(NOW(),'%Y-%m-%d'); end if;
         if p_daterange = 4 then set v_fromdate = DATE_SUB(CURDATE(), interval 365 day); set v_todate = DATE_FORMAT(NOW(),'%Y-%m-%d'); end if;

 		select DATE_FORMAT(Comm_date, '%Y-%m') as monthfilter, sum(cast(Total_Purchase_amount as decimal(10,2))) as Total_amount,sum(cast(Comm_amount as decimal(10,2))) as commission_amount 
 		from smereseller.Reseller_commisson_info rc
 		where Comm_assigned_by = 'COMP-PURCHASE' and rc.reseller_id not in (1366,1005)
 		and cast(Comm_date as date) between v_fromdate and v_todate
 		group by DATE_FORMAT(Comm_date, '%Y-%m')
		order by DATE_FORMAT(Comm_date, '%Y-%m') desc;
 				
        
  End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `reseller_get_breakup_audit_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `reseller_get_breakup_audit_details`(
p_reseller_id int,
p_fromdate varchar(10),
p_todate varchar(10)
)
Begin
		
		Drop TEMPORARY table IF EXISTS tt_getresellerid_list;
		create TEMPORARY table tt_getresellerid_list
		(
			reseller_id INT
		);
        
		call smereseller.sme_reseller_get_subordinates_list_new(p_reseller_id);
		insert into tt_getresellerid_list select a.reseller_id from tt_new_reseller_id a;

		select rc.idpk as idcol, rc.Company_Id,a.company_name as CompanyName,prod_name as  Product,tier_name as Plan,rc.Total_Purchase_amount as Revenue, rc.Comm_amount as Commission
		from smereseller.reseller_company a 
		join wtms.wtms_copy_of_tier_management_temp b on a.plan_id = b.fk_tier_id
		join unifiedring.product_master pm on pm.prod_id = b.prod_type_id
		join smereseller.Reseller_commisson_info rc on rc.reseller_id = a.reseller_id and rc.Company_Id = a.Vpcp_Company_Id
        join tt_getresellerid_list gr on rc.reseller_id  = gr.reseller_id
		where Comm_assigned_by = 'COMP-PURCHASE'
        and a.Vpcp_Company_Id is not null 
        and cast(rc.Comm_date as date) between p_fromdate and p_todate;

End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `reseller_get_commission_breakup_audit_by_reseller_id` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `reseller_get_commission_breakup_audit_by_reseller_id`(
p_reseller_id int,
p_company_id int,
p_idcol int
)
Begin


		Drop TEMPORARY table IF EXISTS tt_getresellerid_list;
		create TEMPORARY table tt_getresellerid_list
		(
			reseller_id INT
		);
        
		call smereseller.sme_reseller_get_subordinates_list_new(p_reseller_id);
		insert into tt_getresellerid_list select a.reseller_id from tt_new_reseller_id a;
        
		select rc.idpk as idcol,first_name,last_name,mobileno, rc.Company_Id,a.company_name as CompanyName,prod_name as  Product,tier_name as Plan,rc.Total_Purchase_amount as Revenue, rc.Comm_amount as Commission
		from smereseller.reseller_company a 
		join wtms.wtms_copy_of_tier_management_temp b on a.plan_id = b.fk_tier_id
		join unifiedring.product_master pm on pm.prod_id = b.prod_type_id
		join smereseller.Reseller_commisson_info rc on rc.reseller_id = a.reseller_id and rc.Company_Id = a.Vpcp_Company_Id
        join tt_getresellerid_list gr on rc.reseller_id  = gr.reseller_id
		where Comm_assigned_by = 'COMP-PURCHASE' and Company_Id = p_company_id
        and a.Vpcp_Company_Id is not null and rc.idpk = p_idcol;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `reseller_get_comm_details_graph` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `reseller_get_comm_details_graph`(
  p_reseller_id int,
  p_daterange int
  )
sp_return:Begin
  
  		declare v_Total_amount decimal(10,2);       declare v_commission_amount decimal(10,2);		declare v_fromdate varchar(10);	declare v_todate varchar(10);
          
         if p_daterange = 1 then set v_fromdate = DATE_FORMAT(NOW() ,'%Y-%m-01'); set v_todate = DATE_FORMAT(NOW(),'%Y-%m-%d'); end if;
         if p_daterange = 2 then set v_fromdate = DATE_SUB(CURDATE(), interval 90 day); set v_todate = DATE_FORMAT(NOW(),'%Y-%m-%d'); end if;
         if p_daterange = 3 then set v_fromdate = DATE_SUB(CURDATE(), interval 180 day); set v_todate = DATE_FORMAT(NOW(),'%Y-%m-%d'); end if;
         if p_daterange = 4 then set v_fromdate = DATE_SUB(CURDATE(), interval 365 day); set v_todate = DATE_FORMAT(NOW(),'%Y-%m-%d'); end if;
          
  		Drop TEMPORARY table IF EXISTS tt_getresellerid_list; create TEMPORARY table tt_getresellerid_list( reseller_id INT );
         
 		call smereseller.sme_reseller_get_subordinates_list_new(p_reseller_id);
 		insert into tt_getresellerid_list select a.reseller_id from tt_new_reseller_id a;
 
 		select DATE_FORMAT(Comm_date, '%Y-%m') as monthfilter, ifnull(sum(cast(Total_Purchase_amount as decimal(10,2))),0) as Total_amount,ifnull(sum(cast(Comm_amount as decimal(10,2))),0) as commission_amount 
 		from smereseller.Reseller_commisson_info rc
 		join tt_getresellerid_list gr on rc.reseller_id  = gr.reseller_id
 		where Comm_assigned_by = 'COMP-PURCHASE'
 		and cast(Comm_date as date) between v_fromdate and v_todate
 		group by DATE_FORMAT(Comm_date, '%Y-%m')
         order by DATE_FORMAT(Comm_date, '%Y-%m') desc;
 				
        
  End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Reseller_get_comm_incentive_structure` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `Reseller_get_comm_incentive_structure`(
 Reseller_id INT)
BEGIN
 
 	
 	
    DECLARE v_comm_apply INT;
    DECLARE v_errcode INT;
    DECLARE v_errmsg VARCHAR(50);
    DECLARE default_int_val_0 int;
    DECLARE default_int_val_1 int;
    
    set default_int_val_0 = 0;
    set default_int_val_1 = 1;
 
    set v_errcode = -1;
    set v_errmsg = 'No records found';
 	
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select   IFNULL(comm_apply,default_int_val_0) INTO v_comm_apply from  Reseller  a where a.Reseller_id = Reseller_id LIMIT 1;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 	
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    Select a.Typeid as Plan_Type_Id,TypeName as Plan_desc,
		IFNULL(b.Inc_app_Month,a.Inc_app_Month) as Month_Revenue_Count,
		IFNULL(b.inc_percentage,a.inc_percentage) as Month_Rev_Percentage,
		IFNULL(b.After_Inc_apply_Month_Per,a.After_Inc_apply_Month_Per) as After_Inc_apply_Month_Per,
		default_int_val_1 as comm_apply_flag,
		'Yes' comm_apply,case when Is_monthly_Year = 1 then 'Monthly'
		when Is_monthly_Year = 2 then 'Yearly' end as Plan_type  
    from  reseller_plan_type a
    JOIN  Reseller_incentive_Config b on a.Typeid = b.Typeid
    and b.Reseller_Id = Reseller_id
    where Status = 1;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 
    if found_rows() > 0 then
       set v_errcode = 0;
       set v_errmsg = 'success';
    end if;

    select v_errcode as errcode,v_errmsg as errmsg;
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Reseller_get_comm_incentive_structure_log` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbteam`@`%` PROCEDURE `Reseller_get_comm_incentive_structure_log`(
Reseller_id INT,
From_date datetime,
To_date datetime)
begin

	select Reseller_Id,Typeid,Inc_app_Month,inc_percentage,After_Inc_apply_Month_Per,create_Date
	from Reseller_incentive_Config_log 
	where Reseller_id = Reseller_id and cast(create_Date as date) between From_date and To_date;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Reseller_get_comm_incentive_structure_log_v2` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `Reseller_get_comm_incentive_structure_log_v2`(
    Reseller_id INT)
BEGIN
    
    	
    	
       DECLARE v_comm_apply INT;
       DECLARE v_errcode INT;
       DECLARE v_errmsg VARCHAR(50);
       DECLARE default_int_val_0 int;
       DECLARE default_int_val_1 int;
       DECLARE v_create_Date datetime;
       
       set default_int_val_0 = 0;
       set default_int_val_1 = 1;
    
       set v_errcode = -1;
       set v_errmsg = 'No records found';
    	
       SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
       select   IFNULL(comm_apply,default_int_val_0) INTO v_comm_apply from  Reseller  a where a.Reseller_id = Reseller_id LIMIT 1;
       SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
       
       select max(create_Date) into @v_create_Date from Reseller_incentive_Config_log l where l.Reseller_Id = Reseller_id;
        
       SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
       Select a.Typeid as Plan_Type_Id,TypeName as Plan_desc,
   		IFNULL(b.Inc_app_Month,a.Inc_app_Month) as Month_Revenue_Count,
   		IFNULL(b.inc_percentage,a.inc_percentage) as Month_Rev_Percentage,
   		IFNULL(b.After_Inc_apply_Month_Per,a.After_Inc_apply_Month_Per) as After_Inc_apply_Month_Per,
   		default_int_val_1 as comm_apply_flag,
   		'Yes' comm_apply,case when Is_monthly_Year = 1 then 'Monthly'
   		when Is_monthly_Year = 2 then 'Yearly' end as Plan_type  
       from  reseller_plan_type a
       JOIN  Reseller_incentive_Config_log b on a.Typeid = b.Typeid
       and b.Reseller_Id = Reseller_id  and create_date = @v_create_Date
       where Status = 1;
       SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
    
       if found_rows() > 0 then
          set v_errcode = 0;
          set v_errmsg = 'success';
       end if;
   
       select v_errcode as errcode,v_errmsg as errmsg;
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `reseller_get_doc_approve_status_audit` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `reseller_get_doc_approve_status_audit`(
p_reseller_id int
)
Begin
	select b.Firstname,b.Lastname,b.Mobile,b.Email,a.* from smereseller.reseller_main_approveall_commission_audit a 
    left join smereseller.Reseller b on a.reseller_id = b.reseller_id
    where (a.reseller_id = p_reseller_id or ifnull(p_reseller_id,0)=0) ;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `reseller_get_doc_check_approve_status_audit` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `reseller_get_doc_check_approve_status_audit`(
p_reseller_id int,
p_fromdate varchar(10),
p_to_date varchar(10)
)
Begin
	select b.Firstname,b.Lastname,b.Mobile,b.Email,a.* from smereseller.reseller_main_approveall_commission_audit a 
    join smereseller.Reseller b on a.reseller_id = b.reseller_id
    where a.reseller_id = p_reseller_id and from_date = p_fromdate and to_date = p_to_date;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Reseller_get_Incentive_Scheme` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `Reseller_get_Incentive_Scheme`(Scheme_ID INT)
BEGIN
 
    DECLARE v_comm_apply INT;
    DECLARE v_errcode INT;
    DECLARE v_errmsg VARCHAR(50);  
   
    set v_errcode = -1;  
    set v_errmsg = 'No records found';  
    
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    Select a.Typeid as Plan_Type_Id,TypeName as Plan_desc,
  IFNULL(b.Inc_app_Month,a.Inc_app_Month) as Month_Revenue_Count,
  IFNULL(b.inc_percentage,a.inc_percentage) as Month_Rev_Percentage,
  IFNULL(b.After_Inc_apply_Month_Per,a.After_Inc_apply_Month_Per) as After_Inc_apply_Month_Per,
  case when a.Is_monthly_Year = 1 then 'Monthly'
    when a.Is_monthly_Year = 2 then 'Yearly' end as Plan_type  from reseller_plan_type a
    JOIN Inc_Scheme_Master b on a.Typeid = b.Typeid
    Where b.Is_ID = Scheme_ID
    and a.Status = 1;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
   
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `reseller_get_partner_count_graph` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `reseller_get_partner_count_graph`(
 p_daterange int
)
Begin

		declare v_fromdate varchar(10);	declare v_todate varchar(10);

		if p_daterange = 1 then set v_fromdate = DATE_FORMAT(NOW() ,'%Y-%m-01'); set v_todate = DATE_FORMAT(NOW(),'%Y-%m-%d'); end if;
        if p_daterange = 2 then set v_fromdate = DATE_SUB(CURDATE(), interval 90 day); set v_todate = DATE_FORMAT(NOW(),'%Y-%m-%d'); end if;
        if p_daterange = 3 then set v_fromdate = DATE_SUB(CURDATE(), interval 180 day); set v_todate = DATE_FORMAT(NOW(),'%Y-%m-%d'); end if;
        if p_daterange = 4 then set v_fromdate = DATE_SUB(CURDATE(), interval 365 day); set v_todate = DATE_FORMAT(NOW(),'%Y-%m-%d'); end if;

			select DATE_FORMAT(Create_date, '%Y-%m') as monthfilter,count(*) as counts
			from Reseller a
			where cast(Create_date as date) between v_fromdate and v_todate
			group by DATE_FORMAT(Create_date, '%Y-%m')
            order by DATE_FORMAT(Create_date, '%Y-%m') desc;


End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `reseller_get_partner_created_graph` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `reseller_get_partner_created_graph`(
	p_reseller_id int,
	p_daterange int
)
Begin
		declare v_fromdate varchar(10);	declare v_todate varchar(10);
 
		if p_daterange = 1 then set v_fromdate = DATE_FORMAT(NOW() ,'%Y-%m-01'); set v_todate = DATE_FORMAT(NOW(),'%Y-%m-%d'); end if;
		if p_daterange = 2 then set v_fromdate = DATE_SUB(CURDATE(), interval 90 day); set v_todate = DATE_FORMAT(NOW(),'%Y-%m-%d'); end if;
		if p_daterange = 3 then set v_fromdate = DATE_SUB(CURDATE(), interval 180 day); set v_todate = DATE_FORMAT(NOW(),'%Y-%m-%d'); end if;
		if p_daterange = 4 then set v_fromdate = DATE_SUB(CURDATE(), interval 365 day); set v_todate = DATE_FORMAT(NOW(),'%Y-%m-%d'); end if;
        if p_daterange = 5 then set v_fromdate = p_fromdate; set v_todate = p_todate; end if;

    
		
			select count(*) as partner_created from Reseller where reseller_id = p_reseller_id and calledby = 2
            and  cast(Create_date as date) between v_fromdate and v_todate; 

End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `reseller_get_partner_order_form_graph` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `reseller_get_partner_order_form_graph`(
  p_reseller_id int,
  p_daterange int
 )
Begin
 
 		declare v_fromdate varchar(10);	declare v_todate varchar(10);
 
 		if p_daterange = 1 then set v_fromdate = DATE_FORMAT(NOW() ,'%Y-%m-01'); set v_todate = DATE_FORMAT(NOW(),'%Y-%m-%d'); end if;
         if p_daterange = 2 then set v_fromdate = DATE_SUB(CURDATE(), interval 90 day); set v_todate = DATE_FORMAT(NOW(),'%Y-%m-%d'); end if;
         if p_daterange = 3 then set v_fromdate = DATE_SUB(CURDATE(), interval 180 day); set v_todate = DATE_FORMAT(NOW(),'%Y-%m-%d'); end if;
         if p_daterange = 4 then set v_fromdate = DATE_SUB(CURDATE(), interval 365 day); set v_todate = DATE_FORMAT(NOW(),'%Y-%m-%d'); end if;
 
 		select statusName,sum(counts)as cnt
 		from
 		(
 		select Distinct case when status = 1 then 'Requested' 
 						when status in (5,7) then 'Rejected' 
 						when status in (2,3,4) then 'Initiated' 
 						when status = 6 then 'Approved' 
 						when status = 8 then 'Completed' end as statusName,
 					count(*) as counts
 			from reseller_partner_order_form 
 			where (reseller_id = p_reseller_id or fk_reseller_id = p_reseller_id) 
            and (reseller_id not in (1366,1005))
 			and cast(create_on as date) between v_fromdate and v_todate
 			group by case when status = 1 then 'Requested' 
 						when status in (5,7) then 'Rejected' 
 						when status in (2,3,4) then 'Initiated' 
 						when status = 6 then 'Approved' 
 						when status = 8 then 'Completed' end
 			union all
 			select Distinct statusName, counts from temp_partner_form_status
 			) Z
 			group by statusName;
 
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `reseller_get_partner_status_graph` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `reseller_get_partner_status_graph`(
 p_daterange int
)
Begin

		declare v_fromdate varchar(10);	declare v_todate varchar(10);

		if p_daterange = 1 then set v_fromdate = DATE_FORMAT(NOW() ,'%Y-%m-01'); set v_todate = DATE_FORMAT(NOW(),'%Y-%m-%d'); end if;
        if p_daterange = 2 then set v_fromdate = DATE_SUB(CURDATE(), interval 90 day); set v_todate = DATE_FORMAT(NOW(),'%Y-%m-%d'); end if;
        if p_daterange = 3 then set v_fromdate = DATE_SUB(CURDATE(), interval 180 day); set v_todate = DATE_FORMAT(NOW(),'%Y-%m-%d'); end if;
        if p_daterange = 4 then set v_fromdate = DATE_SUB(CURDATE(), interval 365 day); set v_todate = DATE_FORMAT(NOW(),'%Y-%m-%d'); end if;

		select statusName,sum(counts)as cnt
		from
		(
		select Distinct case when status = 1 then 'Approved' when status = 0 then 'Rejected' Else 'Requested' end as statusName,count(*) as counts
			from Reseller a
			where cast(Create_date as date) between v_fromdate and v_todate
			group by case when status = 1 then 'Approved' when status = 0 then 'Rejected' Else 'Requested' end
        union all
			select Distinct statusName, counts from temp_reseller_form_status
		) Z
			group by statusName;

End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `reseller_get_sales_by_plan_graph` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `reseller_get_sales_by_plan_graph`(
  p_reseller_id int,
  p_daterange int,
  p_fromdate varchar(10),
  p_todate varchar(10),
  p_product_id int
 )
Begin
 
		declare v_fromdate varchar(10);	declare v_todate varchar(10);

		if p_daterange = 1 then set v_fromdate = DATE_FORMAT(NOW() ,'%Y-%m-01'); 		set v_todate = DATE_FORMAT(NOW(),'%Y-%m-%d'); 	end if;
		if p_daterange = 2 then set v_fromdate = DATE_SUB(CURDATE(), interval 90 day); 	set v_todate = DATE_FORMAT(NOW(),'%Y-%m-%d'); 	end if;
		if p_daterange = 3 then set v_fromdate = DATE_SUB(CURDATE(), interval 180 day); set v_todate = DATE_FORMAT(NOW(),'%Y-%m-%d'); 	end if;
		if p_daterange = 4 then set v_fromdate = DATE_SUB(CURDATE(), interval 365 day); set v_todate = DATE_FORMAT(NOW(),'%Y-%m-%d'); 	end if;
        if p_daterange = 5 then set v_fromdate = p_fromdate; set v_todate = p_todate; end if;
        
		select b.product_id,b.plan_id,c.tier_name,count(*) as cnt from reseller_company a 
		join unifiedring.ur_company_plan b on a.Vpcp_Company_Id = b.company_id
		join wtms.wtms_copy_of_tier_management_temp c on b.plan_id = c.fk_tier_id
		where Vpcp_Company_Id is not null and Ref_Lead_id in (18,15) and a.reseller_id in (1005,0) and b.status = 1
		and cast(b.createdate as date) between v_fromdate and v_todate
        and b.product_id = p_product_id
		group by b.product_id,b.plan_id,c.tier_name;
        
 
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `reseller_get_sales_dashboard_graph` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `reseller_get_sales_dashboard_graph`(
  p_reseller_id int,
  p_daterange int,
  p_fromdate varchar(10),
  p_todate varchar(10)
 )
Begin

		declare v_fromdate varchar(10);	declare v_todate varchar(10);

		if p_daterange = 1 then set v_fromdate = DATE_FORMAT(NOW() ,'%Y-%m-01'); 		set v_todate = DATE_FORMAT(NOW(),'%Y-%m-%d'); 	end if;
		if p_daterange = 2 then set v_fromdate = DATE_SUB(CURDATE(), interval 90 day); 	set v_todate = DATE_FORMAT(NOW(),'%Y-%m-%d'); 	end if;
		if p_daterange = 3 then set v_fromdate = DATE_SUB(CURDATE(), interval 180 day); set v_todate = DATE_FORMAT(NOW(),'%Y-%m-%d'); 	end if;
		if p_daterange = 4 then set v_fromdate = DATE_SUB(CURDATE(), interval 365 day); set v_todate = DATE_FORMAT(NOW(),'%Y-%m-%d'); 	end if;
        if p_daterange = 5 then set v_fromdate = p_fromdate; set v_todate = p_todate; end if;
        
		
		select count(*) as regular_deal 
        from reseller_company 
        where reseller_id = p_reseller_id
        and cast(create_date as date) between v_fromdate and v_todate
        and Ref_Lead_id in (18,15);
 
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Reseller_get_Scheme_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `Reseller_get_Scheme_info`(Scheme_ID INT)
BEGIN
 IF Scheme_ID is null then
      set Scheme_ID = 0;
   END IF;
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select distinct Is_ID as Scheme_ID,Scheme_Name from Inc_Scheme_Master
   where ((Scheme_ID = 0) OR  (Is_ID = Scheme_ID));
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `reseller_partner_order_approval` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `reseller_partner_order_approval`(
 p_id int,
 p_reseller_id int,
 p_approve1_user_id int,
 p_approve1_comments varchar(125),
 p_approve2_user_id int,
 p_approve2_comments varchar(125),
 p_approve3_user_id int,
 p_approve3_comments varchar(125) 
 )
begin
 
 	declare v_errcode int default -1;
     declare v_errmsg varchar(100) default 'Failure';
 
 	sp_exit : begin
 		if not exists(select 1 from reseller_partner_order_form where id = p_id and reseller_id = p_reseller_id limit 1) then
 			set v_errcode = -1;
 			set v_errmsg = 'Not exists';
 			leave sp_exit;
 		End if;
         
         update reseller_partner_order_form
         set approve1_user_id = p_approve1_user_id
 			,approve1_comments = p_approve1_comments
 			,approve2_user_id = p_approve2_user_id
 			,approve2_comments = p_approve2_comments
 			,approve3_user_id = p_approve3_user_id
 			,approve3_comments = p_approve3_comments
         where id = p_id and reseller_id = p_reseller_id;
 		
         set v_errcode = 0;
 		set v_errmsg = 'Success';
         
     
     end;
     select v_errcode as errcode, v_errmsg as errmsg;
     
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Reseller_Revenue_Details_graph` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `Reseller_Revenue_Details_graph`(Reseller_ID INT)
BEGIN

   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select DATE_FORMAT(Comm_date,'%Y%m') AS Rev_Month,sum(Comm_amount) as Revenue
   from Reseller_commisson_info a
   where ((Reseller_ID = 0) or (a.Reseller_Id = Reseller_ID))
   group by DATE_FORMAT(Comm_date,'%Y%m')
   order by DATE_FORMAT(Comm_date,'%Y%m') desc;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `reseller_update_commission_breakup_audit` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `reseller_update_commission_breakup_audit`(
p_reseller_id int,
p_company_id int,
p_idcol int,
p_comm_amt float,
p_remarks varchar(150)
)
Begin

	declare v_errcode int default -1;
    declare v_errmsg varchar(20) default 'Failure';

	update smereseller.Reseller_commisson_info 
	set Comm_amount = p_comm_amt, remarks = p_remarks
	where idpk = p_idcol and Reseller_Id = p_reseller_id and Company_Id = p_company_id;
    
    if row_Count()>0 then
		set v_errcode = 0;
        set v_errmsg = 'updated';
    End if;
    
    select v_errcode as errcode, v_errmsg as errmsg;
    
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `reseller_update_doc_approve_status_audit` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `reseller_update_doc_approve_status_audit`(
 p_id int,
 p_reseller_id int,
 p_docfileurl text,
 p_docstatus int,
 p_approveid int,
 p_processtype int,
 p_invoice_amount float,
 p_remarks varchar(150)
 )
Begin
 
 declare v_errcode int default -1;
 declare v_errmsg varchar(20) default '';
 
 	if p_processtype = 1 then
 		update smereseller.reseller_main_approveall_commission_audit
 		set docfileurl = p_docfileurl,
 			docstatus = p_docstatus,
 			docuploaddate = current_Timestamp, updatedAt = current_timestamp,
             invoice_amount  = p_invoice_amount,remarks = p_remarks
 		where id = p_id and reseller_id = p_reseller_id;
        
        if row_count()>0 then
        set v_errcode = 0;
        set v_errmsg = 'Updated';
        end if;
 	End if;
 
 	if p_processtype = 2 then
 		update smereseller.reseller_main_approveall_commission_audit
 		set  docstatus = p_docstatus, updatedAt = current_timestamp,approveid = p_approveid,
         invoice_amount  = p_invoice_amount,remarks = p_remarks
 		where id = p_id and reseller_id = p_reseller_id;
        
         if row_count()>0 then
        set v_errcode = 0;
        set v_errmsg = 'Updated';
        end if;
        
 	End if;
 
 select v_errcode as errcode, v_errmsg as errmsg;
 
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Reseller_update_Incentive_Scheme` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `Reseller_update_Incentive_Scheme`(
   comm_info_xml LONGTEXT,
   Scheme_name  VARCHAR(160),
   Scheme_ID INT,
   reseller_id int)
BEGIN
   
   	
 
      DECLARE v_hDoc INT; 
      DECLARE v_errcode INT; 
      DECLARE v_errmsg VARCHAR(160);
      
      DECLARE v_TypeID varchar(100) ;
      DECLARE v_inc_percentage varchar(100);
      DECLARE v_Inc_app_Month varchar(100) ;
      DECLARE v_After_Inc_apply_Month_Per varchar(100);
      
      declare SWF_count int;
   	
       set v_errcode =-1;
       set v_errmsg = 'Failure';
       
     
      
   	
      DROP TEMPORARY TABLE IF EXISTS tt_temp_reseller_structure;
      create TEMPORARY table tt_temp_reseller_structure
      (
         id INT   AUTO_INCREMENT PRIMARY KEY,
         TypeID INT,
         inc_percentage FLOAT,
         Inc_app_Month INT,
         After_Inc_apply_Month_Per FLOAT
      )  AUTO_INCREMENT = 1;
   	
      
      
      
      
    
    drop temporary table if exists xml_TypeID_tbl; create temporary table xml_TypeID_tbl( id int auto_increment primary key,TypeID int);
    drop temporary table if exists xml_inc_percentage_tbl; create temporary table xml_inc_percentage_tbl( id int auto_increment primary key,inc_percentage float);
    drop temporary table if exists xml_Inc_app_Month_tbl; create temporary table xml_Inc_app_Month_tbl( id int auto_increment primary key,Inc_app_Month int);
    drop temporary table if exists xml_After_Inc_apply_Month_Per_tbl; create temporary table xml_After_Inc_apply_Month_Per_tbl( id int auto_increment primary key,After_Inc_apply_Month_Per float);
  
   SELECT REPLACE(EXTRACTVALUE(comm_info_xml, '//TypeID[1]'),' ',','),
 		REPLACE(EXTRACTVALUE(comm_info_xml, '//inc_percentage[1]'),' ',','),
 		REPLACE(EXTRACTVALUE(comm_info_xml, '//Inc_app_Month[1]'),' ',','),
 		REPLACE(EXTRACTVALUE(comm_info_xml,'//After_Inc_apply_Month_Per[1]'),' ',',')
   	INTO v_TypeID , v_inc_percentage , v_Inc_app_Month , v_After_Inc_apply_Month_Per;		
         
      call unifiedring.Split(v_TypeID,','); insert into xml_TypeID_tbl(TypeID) select Items from unifiedring.tt_Split_temptable;
      call unifiedring.Split(v_inc_percentage,','); insert into xml_inc_percentage_tbl(inc_percentage) select Items from unifiedring.tt_Split_temptable;
      call unifiedring.Split(v_Inc_app_Month,','); insert into xml_Inc_app_Month_tbl(Inc_app_Month) select Items from unifiedring.tt_Split_temptable;
      call unifiedring.Split(v_After_Inc_apply_Month_Per,','); insert into xml_After_Inc_apply_Month_Per_tbl(After_Inc_apply_Month_Per) select Items from unifiedring.tt_Split_temptable;     
      
      insert into tt_temp_reseller_structure(TypeID,inc_percentage,Inc_app_Month,After_Inc_apply_Month_Per)
      select TypeID,inc_percentage,Inc_app_Month,After_Inc_apply_Month_Per
      from xml_TypeID_tbl a 
      join xml_inc_percentage_tbl b on a.id = b.id
      join xml_Inc_app_Month_tbl c on c.id = b.id
      join xml_After_Inc_apply_Month_Per_tbl d on d.id = c.id;
           
           
           update Reseller_incentive_Config a 
           join  tt_temp_reseller_structure b
           on a.Typeid=b.TypeID and a.Inc_app_Month=b.Inc_app_Month
           set a.inc_percentage=b.inc_percentage,a.After_Inc_apply_Month_Per=b.After_Inc_apply_Month_Per
           where a.Reseller_id=reseller_id;
           
             IF ROW_COUNT() > 0 then
            SET v_errcode = 0;
            SET v_errmsg = 'Success to update the Incentive Structre';
         end if;
           
     
   
   SELECT v_errcode AS errcode, v_errmsg AS errmsg; 
   
   END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `reseller_update_passord_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `reseller_update_passord_details`(
Reseller_id VARCHAR(100),  
Password VARCHAR(20)
)
begin

  declare errcode int default (-1);
  declare errmsg varchar(125) default ('failure');
  
  if exists (select * from Reseller a where a.Reseller_id=Reseller_id limit 1)
  then
  
    update Reseller a set a.password=Password where a.Reseller_id=Reseller_id;
    
    if row_count()>0
    then
    set errcode=0;
    set errmsg='Success to update the password';
    
    end if;
  
  end if;

select errcode as errcode,errmsg as errmsg;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `res_ur_get_order_dtls` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `res_ur_get_order_dtls`()
BEGIN

 
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    SELECT Orderid ,company_name,reseller_id seller_id, order_value,Pay_Status Status FROM  res_ur_ecom_pymt_dtls;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `smereseller_create_notification_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `smereseller_create_notification_details`(
 parent_partner_id int,
 partner_id int,
 partner_type int,
 type_of_method varchar(225),
 create_date datetime
 )
begin
 
 
 
     declare errcode int default(-1);
     declare errmsg varchar(125) default ('failure');
     
     sp_exit:begin
     
     if not exists (select * from Reseller a where a.Reseller_id=partner_id limit 1)
     then
         set errcode=-1;
         set errmsg='Partner not exists';
         leave sp_exit;
     end if;
     
     insert into reseller_notification_details (parent_partner_id,reseller_id,Partner_type,type_of_method,create_date)
     values (parent_partner_id,partner_id,partner_type,type_of_method,create_date);
     
     if row_count()>0
     then
 		set errcode=0;
         set errmsg='Partner notification created';
       leave sp_exit;
     end if;
     
     
 end sp_exit;
 
 select errcode as errcode,errmsg as errmsg;
 
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `smereseller_get_notification_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `smereseller_get_notification_details`(
     partner_id int
     )
begin
    
     declare v_last_30_days datetime;
     declare  v_parent_partner_id int;
     declare v_company_name varchar(555);
     set v_last_30_days=DATE_ADD(current_timestamp(), INTERVAL -30 DAY);
     

     
     select   a.id as notification_id,a.reseller_id as partner_id ,
     b.Company_name as company_name,
     ifnull(c.company_name,d.Company_name) as parent_company_name,
     a.Partner_type ,
     a.type_of_method ,
     a.is_read_flag ,
     a.create_date 
     from reseller_notification_details a 
     join Reseller b
     on a.Reseller_id=b.reseller_id
     left join reseller_company c
     on c.Vpcp_Company_Id=a.parent_partner_id
      left join Reseller d
     on d.Reseller_id=a.parent_partner_id
     where (a.reseller_id=partner_id or partner_id=0)  and  a.create_date > v_last_30_days
     order by a.id desc;
     
     end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `smereseller_update_read_notification_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `smereseller_update_read_notification_details`(
partner_id int,
id int,
mark_all_as_read int
)
begin

    declare errcode int default(-1);
    declare errmsg varchar(125) default ('failure');
    
 sp_exit:begin 
 
    if mark_all_as_read = 1  then
		 update reseller_notification_details a set a.is_read_flag=1; 
         
		if row_count()>0 then
			set errcode=0;
			set errmsg='Success - All msgs are read';
			leave sp_exit;
		end if;
    end if;

   if exists (select * from reseller_notification_details a where a.reseller_id=partner_id and a.id = id limit 1)
   then
    update reseller_notification_details a set a.is_read_flag=1 where a.reseller_id=partner_id and a.id = id;
    
	   if row_count()>0
		then
			set errcode=0;
			set errmsg='Partner read flag updated';
		  leave sp_exit;
		end if;
   end if;

   end sp_exit;
select errcode as errcode,errmsg as errmsg;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_create_agent_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_create_agent_info`(
 agent_name VARCHAR(150),  
 email_id VARCHAR(150),  
 password VARCHAR(100),  
 mobileno VARCHAR(20),  
 companyname VARCHAR(250),  
 Role_id INT, 
 client_ip VARCHAR(100),  
 process_type INT,
 status INT,  
 agent_id INT,  
 hubspot_contactid BIGINT,
 Hubspot_Owner_id bigint )
BEGIN

    
  
    DECLARE v_errcode INT;   
    DECLARE v_errmsg VARCHAR(160);  
    DECLARE v_Reseller_Id INT;  
    
    sp_exit:
    BEGIN
       IF process_type = 1 then
  
          IF EXISTS(SELECT  1 FROM Reseller where Email = email_id LIMIT 1) then
   
             SET v_errcode = -1;
             SET v_errmsg = 'Email ID already Exsists!';
             LEAVE sp_exit;
          end if;
          IF EXISTS(SELECT  1 FROM Reseller where Mobile = mobileno LIMIT 1) then
   
             SET v_errcode = -1;
             SET v_errmsg = 'Phone Number already Exsists!';
             LEAVE sp_exit;
          end if;
          
          IF EXISTS(SELECT 1 FROM Reseller a where a.Hubspot_Owner_id=Hubspot_Owner_id AND ifnull(a.Hubspot_Owner_id,0)>0 
          AND ifnull(Hubspot_Owner_id,0)>0) then
				SET v_errcode=-1;
				SET v_errmsg ='Hubspot owner Id already mapped with another Employee';
				LEAVE sp_exit;
			END if;
          
			INSERT INTO Reseller(Firstname,Company_name,Mobile,Email,password,status,fk_role_id,Client_ip,Last_Update,Hubspot_contactid,Hubspot_Owner_id,comm_apply)
			VALUES(agent_name,companyname,mobileno,email_id,password,status,Role_id,client_ip,CURRENT_TIMESTAMP,hubspot_contactid,Hubspot_Owner_id,0);
   
          SET v_Reseller_Id = LAST_INSERT_ID();
          IF ROW_COUNT() > 0 then
   
             SET v_errcode = 0;
             SET v_errmsg = 'Reseller Create Successfully.';
             LEAVE sp_exit;
          end if;
       end if;
       IF process_type = 2 then
  
          IF EXISTS(SELECT 1 FROM Reseller where Email = email_id AND Reseller_id <> agent_id LIMIT 1) then
   
             SET v_errcode = -1;
             SET v_errmsg = 'Email ID already Exsists!';
             LEAVE sp_exit;
          end if;
          IF EXISTS(SELECT  1 FROM Reseller where Mobile = mobileno  AND Reseller_id <> agent_id LIMIT 1) then
   
             SET v_errcode = -1;
             SET v_errmsg = 'Phone Number already Exsists!';
             LEAVE sp_exit;
          end if;
          
          IF EXISTS(SELECT 1 FROM Reseller a where a.Hubspot_Owner_id=Hubspot_Owner_id  
			AND Reseller_id<>agent_id AND ifnull(a.Hubspot_Owner_id,0)>0) AND ifnull(Hubspot_Owner_id,0)>0 then

				SET v_errcode=-1;
				SET v_errmsg='Hubspot owner Id already mapped with another Employee';
				leave sp_exit;
			END if;
          
          UPDATE Reseller a SET Firstname = agent_name,a.Company_name = companyname,a.Email = email_id,a.Mobile = mobileno,a.password = password,a.status = status,
				a.Hubspot_contactid = case when IFNULL(hubspot_contactid,0) > 0 then hubspot_contactid else Hubspot_contactid end,
                a.Hubspot_Owner_id=Hubspot_Owner_id
          where Reseller_id = agent_id;
          
          IF ROW_COUNT() > 0 then
             SET v_errcode = 0;
             SET v_errmsg = 'Reseller Updated Successfully.';
             LEAVE sp_exit;
          end if;
       end if;
    END;
    select v_errcode as errcode,v_errmsg as errmsg,v_Reseller_Id as agent_id;  
    
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_create_company_by_reseller` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_create_company_by_reseller`(
     		first_name VARCHAR(150),      
             last_name VARCHAR(150),      
             title VARCHAR(10),      
             company_name VARCHAR(60),      
             address_1 VARCHAR(250),       
             address_2 VARCHAR(250),      
             city VARCHAR(60),      
             state VARCHAR(60),      
             zip_code VARCHAR(8),      
             country VARCHAR(30),      
             phone VARCHAR(18),      
             mobileno VARCHAR(18),      
             email VARCHAR(100), 
             free_trail INT, 
             reseller_id INT,
             plan_id INT,
             plan_Billing_cycle INT,
             plan_Type_id INT ,
             myacc_password VARCHAR(50)  ,
             avail_number VARCHAR(20),
             Hubspot_companyid BIGINT ,
             Hubspot_contactid   BIGINT,
             number_country VARCHAR(150),
             number_citycode VARCHAR(250),
             number_type  VARCHAR(250),
             addon_price FLOAT,
             mobileno_price FLOAT,
             addon_bundleid INT,
             pur_mobileno_info LONGTEXT,
             add_bun_price float,
             lead_id int,
             city_id int,
             dept_id int,
             sales_id int)
BEGIN
           
                DECLARE v_errcode INT;        
                DECLARE v_errmsg VARCHAR(100); 
                DECLARE errcode INT;        
                DECLARE errmsg VARCHAR(100);
                DECLARE now DATETIME(3); 
              
                DECLARE avail_number_out VARCHAR(20);    
               
                DECLARE Cnt_ReffID INT;
                DECLARE Pk_rs_cmpid INT;
                DECLARE paid_amount FLOAT; 
                DECLARE default_int_val_0 int;
                DECLARE default_int_val_1 int;
                
 				DECLARE EXIT HANDLER FOR SQLEXCEPTION                    
 				BEGIN
 					GET STACKED DIAGNOSTICS CONDITION 1 v_errmsg = MESSAGE_TEXT;
 					ROLLBACK;
 				END;
                    
                IF plan_id is null				then set plan_id = 0;				END IF;
                IF plan_Type_id is null		then set plan_Type_id = 0;			END IF;
                IF myacc_password is null		then set myacc_password = '';		END IF;
                IF avail_number is null		then set avail_number = '';			END IF;
                IF Hubspot_companyid is null	then set Hubspot_companyid = 0;		END IF;
                IF Hubspot_contactid is null	then set Hubspot_contactid = 0;		END IF;
                IF number_country is null		then set number_country = '';		END IF;
                IF number_citycode is null		then set number_citycode = '';		END IF;
                IF number_type is null			then set number_type = '';			END IF;
                IF addon_price is null			then set addon_price = 0;			END IF;
                IF mobileno_price is null		then set mobileno_price = 0;		END IF;
                IF addon_bundleid is null		then set addon_bundleid = 0;		END IF;
                IF pur_mobileno_info is null	then set pur_mobileno_info = '';	END IF;
                IF add_bun_price is null 		then set add_bun_price=0; 			END IF;
           	 IF lead_id is null 			then set lead_id=0; 				END IF;
           	 IF city_id is null 			then set city_id=0; 				END IF;
             
             START TRANSACTION;
             sp_exit:
                BEGIN
           
                   SET now = CURRENT_TIMESTAMP;
                   SET default_int_val_0 = 0 ;
                   SET default_int_val_1 = 1;
                   
                   DROP TABLE IF EXISTS tt_reseller_cnt_id;
                   CREATE TABLE tt_reseller_cnt_id
                   (
        				id int auto_increment primary key,
                      Cnt_ReffID INT,
                      errcode INT,
                      errmsg VARCHAR(100)
                   );
             
                   IF EXISTS(SELECT 1 from reseller_company a where  a.email = email LIMIT 1) then
               
                      SET v_errcode = -1;
                      SET v_errmsg = 'Email ID already exists.';
                      LEAVE sp_exit;
                   end if;
                     
             		  CALL unifiedring.UR_Insert_Reseller_Company_Dtl(
                     company_name,default_int_val_1,NULL,first_name,email,mobileno,zip_code,address_1,
             		  address_2,address_2,city,country,free_trail,null,reseller_id,NULL,myacc_password,Cnt_ReffID,errcode,errmsg,first_name,last_name);
                   
                   insert into tt_reseller_cnt_id(errcode, errmsg, Cnt_ReffID)
                   select errcode, errmsg, Cnt_ReffID ; 
                   
                   select a.errcode, a.errmsg, a.Cnt_ReffID into v_errcode, v_errmsg, Cnt_ReffID from tt_reseller_cnt_id a;
             
                   IF v_errcode = -1 then
                      LEAVE sp_exit;
                   end if;
             
                   IF IFNULL(avail_number,'') <> '' then
             	
                      CALL DIDPORTAL.Partner_portal_update_did_number(avail_number,7,'PartnerPortal',avail_number_out);
             
                      if IFNULL(avail_number_out,'') <> '' then
                         set avail_number = avail_number_out;
                      end if;
                   end if;
             	
             	
                   if IFNULL(pur_mobileno_info,'') <> '' then
             	
                      CALL DIDPORTAL.msisdn_update_available_no_list(pur_mobileno_info,7,null,null,null,null,1);
                   end if;
             
             	 INSERT INTO reseller_company(first_name,last_name,title,company_name,address_1,address_2,city,state,zip_code,country,phone,mobileno,email,create_date,status,reseller_id,cnt_ref_id,free_trail,
             	 plan_id,plan_Billing_cycle,plan_Type_ID,Myacc_Password,avail_number,Hubspot_companyid,Hubspot_contactid,
             	 num_country,num_citycode,num_Type,addon_price,addon_bundleid,mobileno_price,addon_bun_price,Ref_Lead_id,Num_city_id,dept_id,sales_id)
             	 VALUES(first_name,last_name,title,company_name,address_1,address_2,city,state,zip_code,country,phone,mobileno,email,now,default_int_val_0,reseller_id,Cnt_ReffID,free_trail,
             	 plan_id,plan_Billing_cycle,plan_Type_id,myacc_password,avail_number,Hubspot_companyid,Hubspot_contactid,
             	 number_country,number_citycode,number_type,addon_price,addon_bundleid,mobileno_price,add_bun_price,lead_id,city_id,dept_id,sales_id);
              
                   IF ROW_COUNT() > 0 then
                      set v_errcode = 0;
                      set v_errmsg = 'Success to create company';
                   end if;
             
                   SET Pk_rs_cmpid = LAST_INSERT_ID();
             
                   if errcode = 0 then
           			select a.paid_amount INTO paid_amount from reseller_company a where a.reseller_id = reseller_id order by Pk_rs_cmpid desc LIMIT 1;
           			
           			IF ifnull(lead_id,0)>0 then	
           				IF EXISTS(SELECT 1 FROM Reseller_Lead_details a where a.Lead_id=lead_id) then
           					UPDATE Reseller_Lead_details a SET a.status=1,a.Fk_rs_cmpid=Pk_rs_cmpid where a.Lead_id=lead_id;
           				END if;
           			END if;
                   END if;
             
                   IF (IFNULL(pur_mobileno_info,'') <> '' or pur_mobileno_info <> 0) then
               
                      DROP TEMPORARY TABLE IF EXISTS tt_temp_mobileno;
                      create TEMPORARY table tt_temp_mobileno
                      (
                         msisdn VARCHAR(20)
                      );
             
             		 call unifiedring.Split(pur_mobileno_info,',');
             
             		 insert into tt_temp_mobileno
             		 select Items from unifiedring.tt_Split_temptable;
             
                      INSERT INTO res_comp_mobileno_info(msisdn,reseller_id,fk_rs_cmpid,create_date)
                      select a.msisdn,reseller_id,Pk_rs_cmpid,CURRENT_TIMESTAMP from tt_temp_mobileno a;
             
                   end if;
             
                END sp_exit;
             
                Select v_errcode errcode,v_errmsg errmsg,IFNULL(Cnt_ReffID,default_int_val_0) Cnt_ReffID;     
	COMMIT;                 
             END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_create_partner_order_form` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_create_partner_order_form`(
         	p_firstname VARCHAR(100),
         	p_lastname VARCHAR(100),
         	p_title VARCHAR(10),
         	p_company_name VARCHAR(100),
         	p_address1 VARCHAR(500),
         	p_address2 VARCHAR(500),
         	p_city VARCHAR(100),
         	p_statename VARCHAR(100),
         	p_zipcode VARCHAR(50),
         	p_country VARCHAR(100),
         	p_phone VARCHAR(20),
         	p_mobile VARCHAR(20),
         	p_email VARCHAR(100),
         	p_reseller_id int,
         	p_plan_id int,
         	p_product_id int,
         	p_plan_Billing_cycle int,
         	p_users int,
         	p_status int,
         	p_approves_status int,
         	p_create_by int,
           p_website_purpose int,
           p_customer_messages text,
           p_fk_reseller_id int,
           p_company_id int,
           p_designation varchar(150),
           p_Campaign_id bigint,
           p_source_url text,
           p_summary text,
           p_companyUrl text
         )
Begin
         		DECLARE v_errcode int;
         		DECLARE v_errmsg VARCHAR(250) default 'Failure';     
         		
         		INSERT INTO reseller_partner_order_form(reseller_id ,title ,firstname ,lastname ,company_name ,address1 ,address2 ,city ,statename ,zipcode ,country ,phone ,mobile ,email ,plan_id ,product_id ,plan_Billing_cycle ,users ,status ,approves_status ,create_by ,create_on ,website_purpose ,customer_messages,fk_reseller_id,company_id, designation,Campaign_id, source_url, summary, companyUrl)
         		VALUES(p_reseller_id ,p_title ,p_firstname ,p_lastname ,p_company_name ,p_address1 ,p_address2 ,p_city ,p_statename ,p_zipcode ,p_country ,p_phone ,p_mobile ,p_email ,p_plan_id ,p_product_id ,p_plan_Billing_cycle ,p_users ,p_status ,p_approves_status ,p_create_by ,now() ,p_website_purpose ,p_customer_messages,p_fk_reseller_id,p_company_id, p_designation,p_Campaign_id, p_source_url, p_summary, p_companyUrl);
         	
         		if row_count() > 0 then 
         			set v_errcode = 0;
                     set v_errmsg = 'Success : Inserted';
                     
                 End if;
         	select v_errcode as_errcode,v_errmsg as errmsg;
         End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_create_reseller_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_create_reseller_details`(
                Title VARCHAR(10),
                Firstname VARCHAR(100),
                Lastname VARCHAR(100),
                Company_name VARCHAR(255),
                Address1 VARCHAR(500),
                Address2 VARCHAR(500),
                City VARCHAR(100),
                Statename VARCHAR(100),
                Zipcode VARCHAR(50),
                Country VARCHAR(100),
                Phone VARCHAR(20),
                Mobile VARCHAR(20),
                Email VARCHAR(100),
                Fk_Reseller_Type INT,
                Fk_certification_Id INT,
                Fk_product_id INT,
                Fk_Vertical_id  INT,
                Fk_Stategy_id INT,
                Fk_Emp_Size_id INT,
                Fk_Cust_Size_id INT,
                Fk_Comp_Size_id INT,
                Fk_Part_prog_id INT,
                Client_ip VARCHAR(50),
                Process_type INT, 
                password VARCHAR(20),
                Reseller_Id INT,
                Fk_Role_Id INT,
                Fk_Reseller_Id INT,
                calledby VARCHAR(20),
                status INT,
                Bank_Name VARCHAR(50) ,
                Branch VARCHAR(100),
                IFSC VARCHAR(50),
                Account_Number VARCHAR(25),
                Acc_Holder_Name VARCHAR(50),
                Account_Type VARCHAR(30),
                Bank_Status INT,
                Bank_Country VARCHAR(20),
                Bank_City VARCHAR(20),
                Sort_code VARCHAR(25),
                KYC_id INT,
                BIC_number VARCHAR(25),
                sold_to VARCHAR(30),
                annual_gross_revenue VARCHAR(30),
                Hubspot_contactid BIGINT,
                flat_no VARCHAR(50),
                comp_reg_cert_name VARCHAR(100),
                uq_comp_reg_cert_name VARCHAR(100),
                Id_proof_name text,
                Uq_Id_proff_name text,
                Res_doc_status VARCHAR(50),
                Res_pend_Rej_reason  VARCHAR(100),
                commission_status int,
                partner_type int,
                payment_method int,
 				payment_days int
    )
BEGIN
                
               	DECLARE v_NOW DATETIME(3); 
                   DECLARE v_errcode int;
                   DECLARE v_errmsg VARCHAR(250);
                   DECLARE Scheme_ID INT;
                   DECLARE default_int_val int;
                   declare Reseller_Id_new int;
                   
                   set default_int_val = 0 ;
               
               sp_exit: BEGIN
                	
                   IF Reseller_Id is null 				then set Reseller_Id = 0; 				END IF;
                   IF Fk_Role_Id is null 				then set Fk_Role_Id = 1; 				END IF;
                   IF calledby is null 					then set calledby = 'ADMIN'; 			END IF;
                   IF status is null 					then set status = 0; 					END IF;
                   IF flat_no is null 					then set flat_no = ''; 					END IF;
                   IF comp_reg_cert_name is null 		then set comp_reg_cert_name = ''; 		END IF;
                   IF uq_comp_reg_cert_name is null 	then set uq_comp_reg_cert_name = ''; 	END IF;
                   IF Id_proof_name is null 			then set Id_proof_name = ''; 			END IF;
                   IF Uq_Id_proff_name is null 			then set Uq_Id_proff_name = ''; 		END IF;
                   IF Res_doc_status is null 			then set Res_doc_status = ''; 			END IF;
                   IF Res_pend_Rej_reason is null 		then set Res_pend_Rej_reason = ''; 		END IF;
                   
               	SET v_NOW = CURRENT_TIMESTAMP;
                   
                   SELECT a.Is_ID into Scheme_ID FROM Inc_Scheme_Master a WHERE a.STATUS=1 ORDER BY a.Is_ID DESC limit 1;
                	
                	
                      IF Process_type = 1 then
                         IF EXISTS(SELECT 1 FROM  Reseller b where b.Email = Email LIMIT 1) then
                            SET v_errcode = -1;
                            SET v_errmsg = 'Email ID already Exsists!';
                            LEAVE sp_exit;
                         end if;
                         
          			 
               			INSERT INTO Reseller(Title,Firstname,Lastname,Company_name,Address1,Address2,City,Statename,Zipcode,Country,Phone,Mobile,Email,
               			Fk_Reseller_Type,Fk_certification_Id,Fk_product_id,Fk_Vertical_id,Fk_Stategy_id,Fk_Emp_Size_id,Fk_Cust_Size_id,Fk_Comp_Size_id,
               			Fk_Part_prog_id,Create_date,Client_ip,password,Status,fk_role_id,Fk_Reseller_Id,calledby,sold_to,annual_gross_revenue,Hubspot_contactid,
               			flat_no,comp_reg_cert_name,uq_comp_reg_cert_name,Id_proof_name,Uq_Id_proff_name,Res_doc_status,Res_pend_Rej_reason,commission_status,partner_type,payment_method ,payment_days )
               			VALUES(Title,Firstname,Lastname,Company_name,Address1,Address2,City,Statename,Zipcode,Country,Phone,Mobile,Email,Fk_Reseller_Type,
               			Fk_certification_Id,Fk_product_id,Fk_Vertical_id,Fk_Stategy_id,Fk_Emp_Size_id,Fk_Cust_Size_id,Fk_Comp_Size_id,Fk_Part_prog_id,
               			v_NOW,Client_ip,password,status,Fk_Role_Id,Fk_Reseller_Id,calledby,sold_to,annual_gross_revenue,Hubspot_contactid,flat_no,
               			comp_reg_cert_name,uq_comp_reg_cert_name,Id_proof_name,Uq_Id_proff_name,Res_doc_status,Res_pend_Rej_reason,commission_status,partner_type,payment_method ,payment_days );
                         
                         
                		
                         SET Reseller_Id_new = LAST_INSERT_ID();
                         
                         IF row_count() > 0 then
                            SET v_errcode = 0;
                            SET v_errmsg = 'Reseller Create Successfully.';
                            
           					
                         end if;
                         
                         IF IFNULL(Account_Number,'') <> '' and IFNULL(Reseller_Id_new,0) > 0 then
                		
                			  INSERT INTO  Reseller_Bank_KYC_Info(Reseller_Id,Bank_Name,Branch,IFSC,Account_Number,Acc_Holder_Name,Account_Type,
                			Status,Create_date,Country,City,Sort_code,BIC_number)
                			VALUES(Reseller_Id_new,Bank_Name,Branch,IFSC,Account_Number,Acc_Holder_Name,Account_Type,Bank_Status,v_NOW,Bank_Country,Bank_City,Sort_code,BIC_number);
                         end if;
                         
                          IF status in (5) AND v_errcode=0 AND IFNULL(Scheme_ID,0)>0 and Fk_Role_Id in (2) then
               					IF NOT EXISTS(SELECT 1 FROM Reseller_incentive_Config a WHERE a.Reseller_Id= Reseller_Id_new limit 1) then
               						call Reseller_assign_Incenctive_Scheme (Reseller_Id_new,Scheme_ID);
               					END if;
               			END if;
                      end if;
                      
                      IF Process_type = 2 then
                	
                         IF NOT EXISTS(SELECT  1 FROM Reseller b WHERE b.Reseller_id = Reseller_Id LIMIT 1) then
                		
                            SET v_errcode = 0;
                            SET v_errmsg = 'Reseller Not found.';
                            LEAVE sp_exit;
                         end if;
                         IF  EXISTS(SELECT  1 FROM Reseller c WHERE c.Reseller_id <> Reseller_Id and c.Email = Email LIMIT 1) then
                		
                            SET v_errcode = -1;
                            SET v_errmsg = 'Email ID already Exists with different Reseller!!';
                            LEAVE sp_exit;
                         end if;
                         IF IFNULL(Account_Number,'') <> '' then
                		
                            IF EXISTS(SELECT  1 FROM Reseller_Bank_KYC_Info d WHERE d.Reseller_Id = Reseller_Id LIMIT 1) then
                			
                               Update Reseller_Bank_KYC_Info e
                               Set e.Bank_Name = Bank_Name,e.Branch = Branch,e.IFSC = IFSC,e.Account_Number = Account_Number,
                               e.Acc_Holder_Name = Acc_Holder_Name,e.Account_Type = Account_Type,
                               e.Status = Bank_Status,e.last_update = v_NOW,e.Country = Bank_Country,e.City = Bank_City,
                               e.Sort_code = Sort_code,e.BIC_number = BIC_number
                               Where e.Reseller_Id = Reseller_Id;
                            ELSE
                				 INSERT INTO Reseller_Bank_KYC_Info(Reseller_Id,Bank_Name,Branch,IFSC,Account_Number,Acc_Holder_Name,Account_Type,
                				Status,Create_date,Country,City,Sort_code,BIC_number)
                				VALUES(Reseller_Id,Bank_Name,Branch,IFSC,Account_Number,Acc_Holder_Name,Account_Type,Bank_Status,v_NOW,Bank_Country,Bank_City,Sort_code,BIC_number);
                            end if;
                         end if;
                         
                         UPDATE Reseller f SET f.Title = Title,f.Firstname = Firstname,f.Lastname = Lastname,f.Company_name = Company_name,
    						 f.Address1 = Address1,f.Address2 = Address2,f.City = City,f.Statename = Statename,
    						 f.Zipcode = Zipcode,f.Country = Country,f.Phone = Phone,f.Mobile = Mobile,
    						 f.Email = Email,f.Fk_Reseller_Type = Fk_Reseller_Type,f.Fk_certification_Id = Fk_certification_Id,
    						 f.Fk_product_id = Fk_product_id,f.Fk_Vertical_id = Fk_Vertical_id,
    						 f.Fk_Stategy_id = Fk_Stategy_id,f.Fk_Emp_Size_id = Fk_Emp_Size_id,
    						 f.Fk_Cust_Size_id = Fk_Cust_Size_id,f.Fk_Comp_Size_id = Fk_Comp_Size_id,
    						 f.Fk_Part_prog_id = Fk_Part_prog_id,f.Client_ip = Client_ip,
    						 f.Last_Update = v_NOW,f.fk_role_id = Fk_Role_Id,f.status = status,f.sold_to = IFNULL(sold_to,sold_to),
    						 f.annual_gross_revenue = IFNULL(annual_gross_revenue,annual_gross_revenue),f.Hubspot_contactid = case when IFNULL(Hubspot_contactid,0) > 0 then Hubspot_contactid else Hubspot_contactid end,
    						 f.flat_no = flat_no,f.comp_reg_cert_name = comp_reg_cert_name,f.uq_comp_reg_cert_name = uq_comp_reg_cert_name,
    						 f.Id_proof_name = Id_proof_name,f.Uq_Id_proff_name = Uq_Id_proff_name,
    						 f.Res_doc_status = Res_doc_status,f.Res_pend_Rej_reason = Res_pend_Rej_reason,
    						 f.commission_status = commission_status,
                           f.partner_type = ifnull(partner_type,f.partner_type),
                           f.payment_method = ifnull(payment_method,f.payment_method),
 							f.payment_days = ifnull(payment_days,f.payment_days)
                         WHERE f.Reseller_id = Reseller_Id;
                         
                         IF found_rows() > 0 then
                            SET v_errcode = 0;
                            SET v_errmsg = 'Reseller Updated Successfully.';
                            
                            if status = 1 then
           						update Reseller a set comm_apply = 1 where a.reseller_id = Reseller_Id;
           					end if;
                         end if;
                         
                          IF status in (5) AND v_errcode=0 AND IFNULL(Scheme_ID,0)>0 and Fk_Role_Id in (2) 
                          then
               					IF NOT EXISTS(SELECT 1 FROM Reseller_incentive_Config a WHERE a.Reseller_Id= Reseller_Id limit 1) then
               						call Reseller_assign_Incenctive_Scheme (Reseller_Id,Scheme_ID);
               					END if;
               			END if;
                      end if;
                      
                      IF Process_type = 3 then
                	
                         IF NOT EXISTS(SELECT  1 FROM Reseller g WHERE g.Reseller_id = Reseller_Id LIMIT 1) then
                		
                            SET v_errcode = 0;
                            SET v_errmsg = 'Reseller Not found.';
                            LEAVE sp_exit;
                         end if;
                         IF  EXISTS(SELECT  1 FROM Reseller h WHERE h.Reseller_id <> Reseller_Id and h.Email = Email LIMIT 1) then
                		
                            SET v_errcode = -1;
                            SET v_errmsg = 'Email ID already Exists with different Reseller!!';
                            LEAVE sp_exit;
                         end if;
                         
                         UPDATE Reseller i SET i.Status = status WHERE i.Reseller_id = Reseller_Id;
                         IF found_rows() > 0 then
                		
                            SET v_errcode = 0;
                            SET v_errmsg = 'Reseller Status Updated Successfully.';
                         end if;
                      end if;
               	 IF status in (5) AND v_errcode=0 AND IFNULL(Scheme_ID,0)>0 and Fk_Role_Id in (2) 
                          then
               					IF NOT EXISTS(SELECT 1 FROM Reseller_incentive_Config a WHERE a.Reseller_Id= Reseller_Id limit 1) then
               						call Reseller_assign_Incenctive_Scheme (Reseller_Id,Scheme_ID);
               					END if;
               			END if;
                      
                   END;
                            
                   select v_errcode as errcode,v_errmsg as errmsg,IFNULL(Reseller_Id_new,Reseller_Id) as Reseller_Id;
                	
                END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_create_special_bundle_request` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_create_special_bundle_request`(Reseller_id INT,  
 Customer_name VARCHAR(30),  
 Customer_email VARCHAR(30),  
 Bundle_type VARCHAR(30),  
 Budget VARCHAR(30),  
 Comments text,  
 Process_Type INT,  
 Request_ID INT,  
 Req_status INT,  
 Admin_comments text)
BEGIN
 
    DECLARE v_errcode INT;  
    DECLARE v_errmsg VARCHAR(250);  
    
    sp_exit:BEGIN
    
       IF Process_Type = 1 
       then
  
          IF EXISTS(SELECT  * FROM  Res_Special_bundle_req_info a WHERE a.Customer_Email = Customer_email
          AND a.Bundle_Type = Bundle_type LIMIT 1) 
          then
   
             Set v_errcode = -1;
             Set v_errmsg = 'Special Bundle Request already Exists!';
             LEAVE sp_exit;
          end if;
          INSERT INTO Res_Special_bundle_req_info(Reseller_id,Customer_Name,Customer_Email,Bundle_Type,Budget,Customer_requirement,Req_status,Request_date)
   VALUES(Reseller_id,Customer_name,Customer_email,Bundle_type,Budget,Comments,0,CURRENT_TIMESTAMP);
   
          IF ROW_COUNT() > 0 
          then
   
             Set v_errcode = 0;
             Set v_errmsg = 'Success to Create Special Bundle Request.';
          end if;
       end if;   
    
  
       
       IF Process_Type = 2 
       then 
          IF NOT EXISTS(SELECT  1 FROM Res_Special_bundle_req_info a WHERE a.Request_id = Request_ID LIMIT 1) 
          then  
             Set v_errcode = -1;
             Set v_errmsg = 'Special Bundle Request not found.';
             LEAVE sp_exit;
          end if;
          
          Update Res_Special_bundle_req_info a Set a.Admin_comment = Admin_comments,a.Req_status = Req_status,
          Lastupdate = CURRENT_TIMESTAMP,
          Customer_requirement = Comments,a.Customer_Email = Customer_email,
          a.Customer_Name = Customer_name,a.Bundle_Type = Bundle_type,a.Budget = Budget
          WHERE a.Request_id = Request_ID;
          
          IF found_rows() > 0 
          then  
             Set v_errcode = 0;
             Set v_errmsg = 'Success to Update Special Bundle Request.';
          end if;
       end if;
    END;
    select v_errcode as errcode,v_errmsg as errmsg;  
    
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_get_agent_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_get_agent_details`(agent_id INT)
BEGIN

  
   IF agent_id is null then
      set agent_id = 0;
   END IF;
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select Reseller_id as agent_id,Firstname as agent_name,password as password,
 Mobile,Email,Company_name,a.status,rs.status as status_name,
 IFNULL(a.Hubspot_contactid,0) as Hubspot_contactid from Reseller a
   left join Reseller_status_ref rs  on a.status = rs.status_id
   where fk_role_id = 7
   and  ((agent_id = 0) or (Reseller_id = agent_id));
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
   
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_get_campaign_partner_order_form` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_get_campaign_partner_order_form`(
     p_reseller_id int,
     p_Campaign_id bigint,
     from_date date,
     to_date date
      )
sp_return:Begin
   
  		if p_reseller_id in (18,15) then
  			select * from reseller_partner_order_form a where a.reseller_id in (18,15);
              leave sp_return;
          end if;
   
      
  		select b.Firstname as Reseller_Firstname,b.Lastname as Reseller_Lastname,b.Email as Reseller_Email,a.* from reseller_partner_order_form a 
  		left join Reseller b on a.reseller_id = b.Reseller_id
  		where (a.reseller_id = p_reseller_id or ifnull(p_reseller_id,0) = 0)
  		and (Campaign_id = p_Campaign_id)
        and cast(create_on as date) between from_date and to_date
  		order by create_on desc;
      
  End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_get_employee_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_get_employee_details`(employee_id INT)
BEGIN
 declare default_int_val int ;
 
 set default_int_val = 0;
 
    IF employee_id is null then
       set employee_id = 0;
    END IF;
    
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select Reseller_id as employee_id,Firstname as employee_name,password as password,
 	Mobile,Email,Company_name,a.Status,rs.status as status_name,
 	IFNULL(a.Hubspot_contactid,default_int_val) as Hubspot_contactid from Reseller a
    left join Reseller_status_ref rs  on a.status = rs.status_id
    where fk_role_id = 8
    and  ((employee_id = 0) or (Reseller_id = employee_id));
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 	
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_get_PartnerAgentBy_resellerid` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_get_PartnerAgentBy_resellerid`(
p_Reseller_id int
)
Begin
select Fk_Reseller_Id as PartnerId,Reseller_id as AgentId from smereseller.Reseller a where Reseller_id = p_Reseller_id;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_get_partner_order_form` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_get_partner_order_form`(
    p_reseller_id int,
    p_id int
     )
sp_return:Begin
  
 		if p_reseller_id in (18,15) then
 			select * from reseller_partner_order_form a where a.reseller_id in (18,15);
             leave sp_return;
         end if;
  
     
 		select b.Firstname as Reseller_Firstname,b.Lastname as Reseller_Lastname,b.Email as Reseller_Email,a.* from reseller_partner_order_form a 
 		left join Reseller b on a.reseller_id = b.Reseller_id
 		where (a.reseller_id = p_reseller_id or ifnull(p_reseller_id,0) = 0)
 		and (id = p_id or ifnull(p_id,0)=0)
 		order by create_on desc;
     
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_get_partner_order_form_by_company_plan_email` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_get_partner_order_form_by_company_plan_email`(
p_company_id int,
p_plan_id int,
p_email VARCHAR(100)
)
Begin

	
		if exists(select * from reseller_partner_order_form where company_id = p_company_id and plan_id = p_plan_id and email = p_email) then
			select 0 as errcode,'yes' as errmsg;
        else
			select -1 as errcode,'no' as errmsg;
        End if;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_get_reseller_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_get_reseller_details`(
     Reseller_id INT)
BEGIN
   
     
     
        SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   		Select a.Reseller_Id,Firstname,Lastname,Email as Email_Address,Mobile as Mobile_number,Phone as Work_number,Company_name,(CONCAT(Address1,', ',Address2)) as Company_address,
   				a.Title,a.fk_role_id,rr.role_name as member_role_type,a.create_date,a.status as status_id,
   				case when rs.status_id = 0 then  'Rejected' else rs.status end as reseller_status,
   				a.City,a.Zipcode,a.Country,a.address1 as building_name,a.address2 as street_name,b.Bank_Name,b.Branch,b.IFSC,b.Account_Number,b.Acc_Holder_Name,b.Account_Type,b.BIC_number,b.Sort_code,b.KYC_id,
   				b.country as Bank_Country,b.city as Bank_City,b.KYC_id,
   				IFNULL(a.flat_no,'') as flat_no,IFNULL(a.comp_reg_cert_name,'') as comp_reg_cert_name,
   				IFNULL(a.uq_comp_reg_cert_name,'') as uq_comp_reg_cert_name,
   				IFNULL(a.Id_proof_name,'') as Id_proof_name,
   				IFNULL(a.Uq_Id_proff_name,'') as Uq_Id_proff_name,
   				IFNULL(a.Res_doc_status,'') as Res_doc_status,
   				IFNULL(a.Res_pend_Rej_reason,'') as Res_pend_Rej_reason,
   				IFNULL(a.Hubspot_contactid,0) as Hubspot_contactid,
   				IFNULL(a.Id_proof_name,'') as Id_proof_name, IFNULL(a.Uq_Id_proff_name,'') as Uq_Id_proff_name,
   				ifnull(a.admin_approval,0) as admin_approval,
   				ifnull(a.finance_approval,0) as finance_approval,
				a.partner_type as partner_type,
 				a.payment_method as payment_method,
				a.payment_days as payment_days,
                a.sold_to as sold_to
   		from Reseller a 
   		left join Reseller_role rr  on a.fk_role_id = rr.Pk_role_id
   		left join Reseller_status_ref rs  on a.status = rs.status_id
   		Left join Reseller_Bank_KYC_Info b  on a.Reseller_id = b.Reseller_id
   		where a.Reseller_id = Reseller_id;
   		SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
     
     End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Sme_get_Reseller_list` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `Sme_get_Reseller_list`(reseller_id INT,  
 Fk_Reseler_Id INT,  
 role_Id INT,  
 calledby VARCHAR(20),  
 name VARCHAR(20),  
 city VARCHAR(20),  
 email VARCHAR(50),  
 status VARCHAR(1))
BEGIN
 
 declare default_int_val int;
 set default_int_val = 0 ;
 
    IF reseller_id is null then set reseller_id = 0; END IF;
    IF Fk_Reseler_Id is null then set Fk_Reseler_Id = 0; END IF;
    IF role_Id is null then set role_Id = 0; END IF;
    
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    SELECT a.Reseller_id,IFNULL(a.Title,'') as Title,IFNULL(a.Firstname,'') as Firstname,
    IFNULL(a.Lastname,'') as Lastname,IFNULL(a.Company_name,'') as Company_name,IFNULL(a.Address1,'') as Address1,
    IFNULL(a.Address2,'') as Address2,IFNULL(a.City,'') as City,IFNULL(a.Statename,'') as Statename,
    IFNULL(a.Zipcode,'') as Zipcode,IFNULL(a.Country,'') as Country,IFNULL(a.Phone,'') as Phone,
    IFNULL(a.Mobile,'') as Mobile,IFNULL(a.Email,'') as Email,IFNULL(a.Fk_Reseller_Type,default_int_val) as Fk_Reseller_Type,
    b.Reseller_Type as Reseller_Type,IFNULL(a.Fk_certification_Id,default_int_val) as Fk_certification_Id,
    IFNULL(c.certification,'') as certification,IFNULL(a.Fk_product_id,default_int_val) as Fk_product_id,
    IFNULL(d.product_name,'') as product_name,IFNULL(a.Fk_Vertical_id,default_int_val) as Fk_Vertical_id,
    IFNULL(e.Vertical_name,'') as Vertical_name,IFNULL(a.Fk_Stategy_id,default_int_val) as Fk_Stategy_id,
    IFNULL(f.Stategy_name,'') as Stategy_name,IFNULL(a.Fk_Emp_Size_id,default_int_val) as Fk_Emp_Size_id,
    IFNULL(g.Emp_size_name,'') as Emp_size_name,IFNULL(a.Fk_Cust_Size_id,default_int_val) as Fk_Cust_Size_id,
    IFNULL(k.Cust_size_name,'') as Cust_size_name,IFNULL(a.Fk_Comp_Size_id,default_int_val) as Fk_Comp_Size_id,IFNULL(j.Comp_size_name,'') as Comp_size_name,
    IFNULL(a.Fk_Part_prog_id,default_int_val) as Fk_Part_prog_id,IFNULL(i.Partner_prog_name,'') as Partner_prog_name,
    l.status as Reseller_Status,IFNULL(a.Client_ip,'') as Client_ip,IFNULL(m.role_name,'') as role_name,
    IFNULL(a.fk_role_id,default_int_val) as Role_Id,a.calledby,
    IFNULL(parent_reseller_name(a.Fk_Reseller_Id),'') as parent_reseller_name,a.status,
    a.Create_date as Create_date
    from Reseller a  
    LEFT JOIN Reseller_type_Master b     on a.Fk_Reseller_Type = b.Pk_Reseller_Type
    LEFT JOIN Reseller_certification_Master c on a.Fk_certification_Id = c.Pk_certification_id
    LEFT JOIN resell_product_Master d    on a.Fk_product_id = d.product_id
    LEFT JOIN Vertical_Master e    on a.Fk_Vertical_id = e.Vertical_id
    LEFT JOIN Sales_Stategy_Master f     on a.Fk_Stategy_id = f.Stategy_id
    LEFT JOIN Employee_Size_Master g     on a.Fk_Emp_Size_id = g.Pk_Emp_Size_Id
    LEFT JOIN Partner_Program_Master i   on a.Fk_Part_prog_id = i.Pk_Program_id
    LEFT JOIN Sell_Company_Size_Master j on a.Fk_Comp_Size_id = j.Pk_company_size_id
    LEFT JOIN Cust_Size_info_Master k    on a.Fk_Cust_Size_id = k.Pk_cust_Size_Id
    LEFT JOIN Reseller_status_ref l         on a.Status = l.status_id
    LEFT JOIN Reseller_role m     on a.fk_role_id = m.Pk_role_id  
    where  ((reseller_id = 0 and Fk_Reseler_Id = 0) or (a.Reseller_id = reseller_id) or
       ((Fk_Reseler_Id = 0 and reseller_id = 0) or (a.Fk_Reseller_Id = Fk_Reseler_Id))) and
       ((role_Id = 0) or (a.fk_role_id = role_Id)) and
       ((IFNULL(calledby,'') = '') or (a.calledby = calledby)) and
       ((IFNULL(status,'') = '') or (cast(a.status as CHAR(30)) = status)) and
       ((IFNULL(name,'') = '') or  ((a.Firstname like CONCAT_WS('','%',name,'%') or a.Lastname like CONCAT_WS('','%',name,'%'))
    or (CONCAT(Firstname,' ',Lastname) like CONCAT_WS('','%',name,'%')))) and
       ((IFNULL(city,'') = '') or (a.City like CONCAT_WS('','%',city,'%'))) and
       ((IFNULL(email,'') = '') or (a.Email like CONCAT_WS('','%',email,'%')))
    order by a.Create_date desc;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
     
     
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_get_subreseller_company_list` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_get_subreseller_company_list`(reseller_id INT)
BEGIN

  

   IF reseller_id is null then
      set reseller_id = 0;
   END IF;
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select b.Reseller_id as sub_reseller_id,a.Pk_rs_cmpid as Company_Id,a.Company_name  from reseller_company a  
   join Reseller b on a.reseller_id = b.Reseller_id  where ((reseller_id = 0) or (b.Fk_Reseller_Id = reseller_id)) or
   b.fk_role_id = 1
   and b.fk_role_id <> 4;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
  
  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_get_subreseller_list` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_get_subreseller_list`(reseller_id INT,
  name VARCHAR(20),
  city VARCHAR(20),
  email VARCHAR(20))
BEGIN
  
  declare default_int_val int;
  
  set default_int_val = 0 ;
  
     IF reseller_id is null then set reseller_id = 0;	END IF;
     IF name is null then set name = '';	END IF;
     IF city is null then set city = '';	END IF;
     IF email is null then set email = '';	END IF;
     
     SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
     Select a.Reseller_id as Reseller_Id, concat(Firstname,' ',Lastname) as Reseller_Name, IFNULL(b.role_name,'') as role_name,
  	IFNULL(a.fk_role_id,default_int_val) as Role_Id from Reseller a  Join Reseller_role b  on a.fk_role_id = b.Pk_role_id where
  	((reseller_id = 0) or (a.Fk_Reseller_Id = reseller_id)) and
  	((IFNULL(name,'') = '') or  (a.Firstname like CONCAT_WS('','%',name,'%'))) and
  	((IFNULL(city,'') = '') or (a.City like CONCAT_WS('','%',city,'%'))) and
  	((IFNULL(email,'') = '') or (a.Email like CONCAT_WS('','%',email,'%'))) and a.fk_role_id <> 4;
     SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
  
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_partner_order_form_update` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_partner_order_form_update`(
  	p_id int,
  	p_reseller_id int,
  	p_company_id int,
  	p_status int,
     p_new_plan_id int,
     p_plan_price float,
     p_plan_name varchar(100),
     p_plan_total_amount float,
     p_term_conditions longtext,
     p_customer_form_url text
  )
Begin
   
 		declare v_errcode int default -1;
 		declare v_errmsg varchar(50) default 'failure';
          
 		update reseller_partner_order_form
 		set company_id = p_company_id, 
 			status = p_status,
 			New_plan_id = p_new_plan_id,
 			Plan_price = p_plan_price,
 			Plan_name = p_plan_name,
 			Plan_total_amount = p_plan_total_amount,
            term_conditions = p_term_conditions,
            customer_form_url = p_customer_form_url
 		where id = p_id and reseller_id = p_reseller_id;
 
          set v_errcode = 0;
          set v_errmsg = 'Success : updated';
          
  		select v_errcode as errcode, v_errmsg as errmsg;
     End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_reseller_1` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_reseller_1`(reseller_id INT,
Pk_role_id INT,
date_range_id INT)
Begin
	
   DECLARE now DATETIME(3);
   DECLARE date_range VARCHAR(50);
   DECLARE inactive_companies INT;

   IF reseller_id is null then 		set reseller_id = 0; 		END IF;
   IF Pk_role_id is null then 		set Pk_role_id = 0; 		END IF;
   IF date_range_id is null then 	set date_range_id = ''; 	END IF;
   set now = STR_TO_DATE(DATE_FORMAT(CURRENT_TIMESTAMP,'%Y-%m-%d'),'%Y-%m-%d');
	
   If date_range_id = 1 then		set date_range = now; 						end if;
   If date_range_id = 2 then		set date_range = now;						end if;
   If date_range_id = 3 then		set date_range = TIMESTAMPADD(day,-1,now);	end if;
   If date_range_id = 4 then		set date_range = TIMESTAMPADD(day,-8,now);	end if;
   If date_range_id = 5 then		set date_range = TIMESTAMPADD(day,-15,now);	end if;
   If date_range_id = 6 then		set date_range = TIMESTAMPADD(day,-31,now);	end if;
   If date_range_id in(7,'') then	set date_range = '';						end if;
		
        
	drop TEMPORARY table IF EXISTS tt_reseller_list;
	create TEMPORARY table tt_reseller_list
   (
      reseller_id INT
   );


   CALL sme_reseller_get_subordinates_list_new(reseller_id);	
   
	insert into tt_reseller_list(reseller_id)
	select a.reseller_id from tt_new_reseller_id a;
	
     If date_range_id <> 3 then

      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select Distinct a.reseller_id as reseller_id,
			(CONCAT(a.Firstname,' ',a.lastname)) as member_name,
			b.role_name as member_type,
			IFNULL(a.fixed_inc_per,0)+IFNULL(a.var_inc_per,0) as comm_current_percentage,
			ur_get_reseller_commission(a.reseller_id,3) as comm_earned,
			ur_get_reseller_commission(a.reseller_id,4) as my_commission,
			ur_get_reseller_count(a.reseller_id,6) as act_comp_with_commission,
			ur_get_reseller_count(a.reseller_id,7) as act_comp_without_commission,
			ur_get_reseller_count(a.reseller_id,5) as inactive_companies
      from Reseller a 
      left join reseller_company rc  on a.reseller_id = rc.Reseller_id
      LEFT JOIN Reseller_role b  on a.fk_role_id = b.Pk_role_id
      LEFT JOIN Reseller_status_ref l on a.Status = l.status_id
      where
	(((a.reseller_id in (select r.reseller_id from tt_reseller_list r) or a.reseller_id = reseller_id) or IFNULL(reseller_id,0) = 0)
	OR ((a.Fk_Reseller_Id in (select s.reseller_id from tt_reseller_list s) or a.Fk_Reseller_Id = reseller_id) or IFNULL(reseller_id,0) = 0))
      AND ((Pk_role_id = 0) or (a.fk_role_id = Pk_role_id)) 
      and ((date_range = '') or cast(rc.create_date as DATE) between cast(date_range as DATE) and cast(now as DATE));
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
      End if;

   drop TEMPORARY table IF EXISTS tt_reseller_list;

End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_reseller_admin_account_login` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_reseller_admin_account_login`(username VARCHAR(64),  
  password VARCHAR(64))
sp_return:Begin
    
     DECLARE v_errcode INT;  
     DECLARE v_errmsg VARCHAR(50);  
     DECLARE v_status INT;  
     DECLARE v_email_id VARCHAR(64);  
     DECLARE v_login_id VARCHAR(64);  
     DECLARE v_Hubspot_contactid BIGINT; 
     DECLARE v_dept_id int;
     
     BEGIN
     
        set v_errcode = -1;
        set v_errmsg = 'Failure';
        
        If not Exists(select  * from sme_reseller_company_admin_user a
        where (a.email_id = username or cast(a.login_id as CHAR(30)) = username) and a.password = password LIMIT 1) 
        then  
           select -1 as errcode, 'Invalid details provided' as errmsg;
           LEAVE sp_return;
        end if;
        
        select 0 as  errcode, 'success' as  errmsg,
        
        a.*
       
        from sme_reseller_company_admin_user a where (a.email_id = username or cast(a.login_id as CHAR(30)) = username) 
        and a.password = password;
        
     END;

  End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_reseller_admin_main_dashboard_overview` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_reseller_admin_main_dashboard_overview`( p_daterange int)
BEGIN
      
 		DECLARE v_Total_company INT;		DECLARE v_freetrail INT;			DECLARE v_paid_subs INT;		DECLARE v_Total_revenue FLOAT;	DECLARE v_Total_commision FLOAT;	DECLARE v_Inc_Tier_Type INT;  
 		DECLARE v_Fixed_inc_per FLOAT;		DECLARE v_var_inc_per FLOAT;		DECLARE v_paid_amount FLOAT; 	DECLARE v_partner_created int;	DECLARE v_comm_amount float;		DECLARE v_active_deal int;
 		DECLARE v_inactive_deal int;		DECLARE v_fromdate varchar(10);		DECLARE v_todate varchar(10);
 
 		if p_daterange = 1 then set v_fromdate = DATE_FORMAT(NOW() ,'%Y-%m-01'); set v_todate = DATE_FORMAT(NOW(),'%Y-%m-%d'); end if;
         if p_daterange = 2 then set v_fromdate = DATE_SUB(CURDATE(), interval 90 day); set v_todate = DATE_FORMAT(NOW(),'%Y-%m-%d'); end if;
         if p_daterange = 3 then set v_fromdate = DATE_SUB(CURDATE(), interval 180 day); set v_todate = DATE_FORMAT(NOW(),'%Y-%m-%d'); end if;
         if p_daterange = 4 then set v_fromdate = DATE_SUB(CURDATE(), interval 365 day); set v_todate = DATE_FORMAT(NOW(),'%Y-%m-%d'); end if;
    
 		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
 		select   COUNT(1) INTO v_Total_company from reseller_company a 
 		inner Join Reseller b  on a.reseller_id = b.Reseller_id and a.vpcp_company_id is not null and b.Reseller_id not in (1366,1005)
 		where cast(b.Create_date as date) between v_fromdate and v_todate;
 		SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
 
 		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
 		select   COUNT(1) INTO v_freetrail from reseller_company a 
 		inner Join Reseller b  on a.reseller_id = b.Reseller_id and a.vpcp_company_id is not null and a.free_trail = 1 and b.Reseller_id not in (1366,1005)
 		where cast(b.Create_date as date) between v_fromdate and v_todate;
 		SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
 
 
 		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
 		select   COUNT(1) INTO v_paid_subs from reseller_company a 
 		inner Join Reseller b  on a.reseller_id = b.Reseller_id and a.vpcp_company_id is not null and (a.free_trail <> 1 or a.free_trail is null) and b.Reseller_id not in (1366,1005)
 		where cast(b.Create_date as date) between v_fromdate and v_todate;
 		SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
 		
 
 		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
 		select   sum(total_purchase_amount),sum(Comm_amount) INTO v_Total_revenue, v_comm_amount from Reseller_commisson_info a 
 		inner join Reseller b on a.reseller_id = b.reseller_id where a.Comm_assigned_by = 'COMP-PURCHASE' and b.Reseller_id not in (1366,1005)
 		and cast(a.Comm_date as date) between v_fromdate and v_todate;
 		SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ; 
 
 		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
 		select count(1) INTO v_partner_created from Reseller b where b.Fk_Reseller_Id = 1005 and cast(b.Create_date as date) between v_fromdate and v_todate;
 		SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ; 
 
 		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
 		select COUNT(1) INTO v_active_deal from reseller_company a inner Join Reseller b  on a.reseller_id = b.Reseller_id where a.status = 1 and a.vpcp_company_id is not null and b.Reseller_id not in (1366,1005)
         and cast(b.Create_date as date) between v_fromdate and v_todate;
 		SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ; 
 
 		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
 		select   COUNT(1) INTO v_inactive_deal from reseller_company a inner Join Reseller b  on a.reseller_id = b.Reseller_id where a.status = 0 and a.vpcp_company_id is not null and b.Reseller_id not in (1366,1005)
         and cast(b.Create_date as date) between v_fromdate and v_todate;
 		SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ; 
 
       
       select v_Total_company as Total_company,v_freetrail as freetrail,v_paid_subs as paid_subs,v_Total_revenue as Total_revenue,
   		ifnull(v_partner_created,0) as partner_created,ifnull(v_comm_amount,0) as comm_amount,ifnull(v_active_deal,0) as active_deal,ifnull(v_inactive_deal,0) as inactive_deal;  
       
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_reseller_admin_performance_dashboard` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_reseller_admin_performance_dashboard`(p_daterange int,p_fromdate varchar(10),p_todate varchar(10))
Begin
         
          DECLARE tt_Total_revenue FLOAT;		DECLARE default_int_val int;        DECLARE v_fromdate varchar(10);		DECLARE v_todate varchar(10);
  
  		 if p_daterange = 1 then set v_fromdate = DATE_FORMAT(NOW(),'%Y-%m-01'); set v_todate = DATE_FORMAT(NOW(),'%Y-%m-%d'); end if;
          if p_daterange = 2 then set v_fromdate = DATE_SUB(CURDATE(), interval 90 day); set v_todate = DATE_FORMAT(NOW(),'%Y-%m-%d'); end if;
          if p_daterange = 3 then set v_fromdate = DATE_SUB(CURDATE(), interval 180 day); set v_todate = DATE_FORMAT(NOW(),'%Y-%m-%d'); end if;
          if p_daterange = 4 then set v_fromdate = DATE_SUB(CURDATE(), interval 365 day); set v_todate = DATE_FORMAT(NOW(),'%Y-%m-%d'); end if;
          if p_daterange = 5 then set v_fromdate = p_fromdate; set v_todate = p_todate; end if;
            
          set default_int_val = 0 ;
  
  		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
  		drop temporary table if exists tt_temp_final_output;
  		create temporary table tt_temp_final_output 
          as 
  		select 	Distinct a.Reseller_id as reseller_id,(CONCAT(a.Firstname,' ',a.lastname)) as Member_name, rb.role_name as Member_type,
  				parent_reseller_name(a.fk_Reseller_id) as parent_reseller,
  				cast(IFNULL(sme_reseller_admin_performance_info(a.reseller_id,5,v_fromdate,v_todate),default_int_val) as float) as Revenue_generated,
  				cast(IFNULL(sme_reseller_admin_performance_info(a.reseller_id,2,v_fromdate,v_todate),default_int_val) as float) as comm_percentage
  		from Reseller a 
  		left JOIN Reseller_role rb  on a.fk_role_id = rb.Pk_role_id
  		left join Reseller_commisson_info rc  on a.Reseller_id = rc.Reseller_Id
  		where a.fk_role_id = 2 and a.Reseller_id <> 1366
          and cast(rc.Comm_date as date) between v_fromdate and v_todate
  		order by a.Reseller_id;
  		SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
  
            	SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
  				select a.reseller_id,a.Member_name,a.Member_type,a.parent_reseller,a.Revenue_generated,a.comm_percentage,count(*) as total_active_deals
  				from tt_temp_final_output a join Reseller b on a.reseller_id = b.reseller_id
  				join reseller_company rs on rs.reseller_id = b.reseller_id
  				where 
  				rs.status = 1 and rs.vpcp_company_id is not null
  				group by a.reseller_id,a.Member_name,a.Member_type,a.parent_reseller,a.Revenue_generated,a.comm_percentage;    
      		SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
         	
         
         End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_reseller_admin_revenue_dashboard` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_reseller_admin_revenue_dashboard`(
 member_type INT,
 date_range_id INT)
SWL_return:
 Begin

    DECLARE v_now DATETIME(3);
    DECLARE v_date_range VARCHAR(50);
    IF member_type is null then
       set member_type = 0;
    END IF;
    IF date_range_id is null then
       set date_range_id = '';
    END IF;
    set v_now = STR_TO_DATE(DATE_FORMAT(CURRENT_TIMESTAMP,'%Y-%m-%d'),'%Y-%m-%d');
 
    If date_range_id = 1 then	
       set v_date_range = v_now;
    end if;
    If date_range_id = 2 then	
       set v_date_range = v_now;
    end if;
    If date_range_id = 3 then	
       set v_date_range = TIMESTAMPADD(day,-1,v_now);
    end if;
    If date_range_id = 4 then	
       set v_date_range = TIMESTAMPADD(day,-8,v_now);
    end if;
    If date_range_id = 5 then	
       set v_date_range = TIMESTAMPADD(day,-15,v_now);
    end if;
    If date_range_id = 6 then	
       set v_date_range = TIMESTAMPADD(day,-31,v_now);
    end if;
    If date_range_id in(7,'') then	
       set v_date_range = '';
    end if;
 	
        drop TEMPORARY table IF EXISTS tt_temp_sum_commission;
 	
    create TEMPORARY table tt_temp_sum_commission
    (
       reseller_id INT,
       Revenue FLOAT
    );
 	
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    insert into tt_temp_sum_commission(reseller_id,Revenue)
    select a.reseller_id ,sum(rc.total_purchase_amount) as Revenue
    from Reseller a 
    LEFT JOIN Reseller_role rb  on a.fk_role_id = rb.Pk_role_id
    join Reseller_commisson_info rc  on a.reseller_id = rc.reseller_id
    WHERE  a.reseller_id not in (1366,1005)
    and (rb.Pk_role_id = member_type or member_type = 0) 
    and ((v_date_range = '') or cast(a.create_date as DATE) between cast(v_date_range as DATE) and cast(v_now as DATE))
    group by a.reseller_id;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 		
    select a.reseller_id,a.Revenue,(CONCAT(b.Firstname,' ',b.lastname)) as Resellers
    from tt_temp_sum_commission a join Reseller b on a.reseller_id = b.reseller_id;
 			
    LEAVE SWL_return;
 	
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_reseller_approve_reject_admin_submission` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_reseller_approve_reject_admin_submission`(reseller_id INT,  
   status INT,  
   comments LONGTEXT)
Begin
   
      DECLARE v_errcode INT;
      DECLARE v_errmsg VARCHAR(50);  
      DECLARE v_subm_status INT;     
      DECLARE v_Scheme_ID INT;   
     
      sp_exit:BEGIN
      
         if status in (1,'')  then  set v_subm_status = 1; end if;        
         if status = 2 then set v_subm_status = 4; end if;
         if status = 3 then set v_subm_status = 1; end if;        
         if status = 4 then set v_subm_status = 4; end if;
         
         SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
         select   a.Is_ID INTO v_Scheme_ID FROM Inc_Scheme_Master a WHERE a.STATUS = 1   ORDER BY a.Is_ID DESC LIMIT 1;
         SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
               
         if status = 2 
         then 
            update Reseller  a set a.status = v_subm_status, a.comments = comments
            where a.reseller_id = reseller_id;
            set v_errcode = 0;
            set v_errmsg = 'Pending';
            LEAVE sp_exit;
         
         Else 
            
            if status = 3 
            then
               update Reseller a set a.status = v_subm_status, a.comments = null
               where a.reseller_id = reseller_id;
               set v_errcode = 0;
               set v_errmsg = 'Approved';            
               CALL Reseller_assign_Incenctive_Scheme(reseller_id,v_Scheme_ID);
               
               update Reseller a set comm_apply = 1 where a.reseller_id = reseller_id;
               
               LEAVE sp_exit;
               
            Else 
            
               if status = 4 
               then 
                  update Reseller a set a.status = v_subm_status,a.comments = null
                  where a.reseller_id = reseller_id;
                  set v_errcode = 0;
                  set v_errmsg = 'Rejected';
                  LEAVE sp_exit;
               end if;
            end if;
         end if;
      END;
      
      
      
      select v_errcode as errcode,v_errmsg as errmsg;  
   End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_reseller_bank_drp_data` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_reseller_bank_drp_data`(drp_type INT)
BEGIN

  
 
   if drp_type = 1 then
 
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select PK_Cntry_id as drp_value,Country_name as drp_text from Res_Bank_Country_Master
      order by PK_Cntry_id asc;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   end if;  
   
  
   if drp_type = 2 then
 
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select PK_City_id as drp_value,City_name as drp_text from Res_Bank_City_Master
      order by PK_City_id asc;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   end if;  
   
  
   if drp_type = 3 then
 
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select PK_Account_id as drp_value,Account_name as drp_text from Res_Bank_Account_Type_Master
      order by PK_Account_id asc;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   end if;  

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_reseller_commisson_process_V4` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_reseller_commisson_process_V4`(Reseller_ID INT,  
 amount FLOAT,  
 company_id INT,  
 Pay_Reference_No VARCHAR(150))
sp_exit : BEGIN
    
    DECLARE v_count INT;   
    DECLARE v_tcount INT;   
    DECLARE v_tier_to FLOAT;
    DECLARE v_var_per_comm FLOAT;  		
    DECLARE v_purchase_cost FLOAT;     
    DECLARE v_P_Reseller_Id INT;   
    DECLARE v_Reseller_Role VARCHAR(250);     
    DECLARE v_admin_commisson FLOAT;  
    DECLARE v_parent_commisson FLOAT;  
    DECLARE v_comm_amount FLOAT;  
    DECLARE v_tcommisson FLOAT;  
    DECLARE v_org_Reseller_Id INT;      
    DECLARE v_Reseller_Level INT;  
    DECLARE v_Tier_id INT;       
    DECLARE v_fixed_percentage FLOAT;  
    DECLARE v_master_reseller_id INT;      
    DECLARE v_commsion_earned FLOAT;  
    DECLARE v_commison_earned_per FLOAT;  
    DECLARE v_role_id INT;      
    DECLARE v_master_res_comm FLOAT;  
    DECLARE v_res_mycomm FLOAT;  
    DECLARE v_master_subres_comm FLOAT;
    DECLARE v_Total_revenue FLOAT;
    DECLARE v_var_commisson FLOAT; 
    DECLARE v_my_var_comm FLOAT; 
    DECLARE v_roleid INT; 
    DECLARE v_fixed_per_master FLOAT; 
    DECLARE v_fk_role_id INT;  
    DECLARE v_Fixed_commisson FLOAT;
    
    
    DROP TEMPORARY TABLE IF EXISTS tt_temp_Reseller_list;
    create TEMPORARY table tt_temp_Reseller_list
    (
       id INT   AUTO_INCREMENT PRIMARY KEY,
       parent_reseller_id INT,
       Reseller_Id INT,
       Role_Name VARCHAR(250)
    )  AUTO_INCREMENT = 1;  
    
    
    CALL sme_reseller_get_chain_info_new (Reseller_ID);
    
    
          insert into tt_temp_Reseller_list (Reseller_Id ,parent_reseller_id,Role_Name)
       
       select reseller_id,parent_reseller_id,reseller_role from tt_temp_reseller_info;
         
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select   reseller_id INTO v_master_reseller_id from tt_temp_Reseller_list where Role_Name = 'Corportate Admin';
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
    
    set v_count = 1;  
    
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select   count(1) INTO v_tcount from tt_temp_Reseller_list;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
    
    set v_tcommisson = 0;  
    
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select   fk_role_id INTO v_role_id from Reseller a where a.reseller_id = Reseller_ID;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
    
   
    set v_purchase_cost = amount;  
    
    while v_count <= v_tcount DO
       begin
          
          sp_next:BEGIN
          
             set v_Tier_id = 0;
             set v_fixed_percentage = 0;
             set v_commsion_earned = 0;
             set v_role_id = 0;
             SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
             select   Reseller_Id, Role_Name, 0, 0, IFNULL(parent_reseller_id,0) INTO 
             v_org_Reseller_Id,v_Reseller_Role,v_admin_commisson,v_comm_amount,v_P_Reseller_Id 
             from tt_temp_Reseller_list where id = v_count    LIMIT 1;
             SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
             
             if v_count > 1 
             then
                set v_purchase_cost = 0;
             end if;
             
             set v_admin_commisson = 30;
             
             if IFNULL(v_admin_commisson,0) = 0 
             then
                LEAVE sp_next;
             end if;   
     
 			drop TEMPORARY table IF EXISTS tt_temp_total_revenue_tier;  
             create TEMPORARY table tt_temp_total_revenue_tier
             (
                reseller_id INT
             );
             
            
             CALL sme_reseller_get_subordinates_list_new (v_org_Reseller_Id);
             
      
            insert into tt_temp_total_revenue_tier select reseller_id from tt_new_reseller_id;
      
      
   
             SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
             select   Inc_Tier_Type, fk_role_id INTO v_Tier_id,v_fk_role_id 
             from Reseller a where  a.Reseller_id = v_org_Reseller_Id LIMIT 1;
             SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
             
             if v_Tier_id = 2 
             then            
                SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
                select   IFNULL(sum(total_purchase_amount),0)+amount INTO v_Total_revenue from Reseller_commisson_info 
                where reseller_id in(select reseller_id from tt_temp_total_revenue_tier);
                SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
          
     
                SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
                select   Commission INTO v_var_per_comm from sme_Reseller_Tier 
                where v_Total_revenue between Tier_min and Tier_To and Create_By = v_org_Reseller_Id    LIMIT 1;
                SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
   
       
    
                
                if not exists(select  IFNULL(commission,1) from sme_Reseller_Tier where create_by = v_org_Reseller_Id
                and v_Total_revenue between tier_min and Tier_to LIMIT 1) 
                then    
                   select max(Tier_to) INTO v_tier_to from sme_Reseller_Tier where create_by = v_org_Reseller_Id;
                   select IFNULL(commission,1) INTO v_var_per_comm from sme_Reseller_Tier 
                   where create_by = v_org_Reseller_Id and tier_to = v_tier_to;
                   
                Else
                
                   select   IFNULL(commission,1) INTO v_var_per_comm from sme_Reseller_Tier where create_by = v_org_Reseller_Id
                   and v_Total_revenue between tier_min and Tier_to;
                   
                end if;
                
                SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
                select   IFNULL(fixed_inc_per,0)+IFNULL(v_var_per_comm,0) INTO v_parent_commisson 
                from Reseller a where  a.Reseller_id = v_org_Reseller_Id    LIMIT 1;
                SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
                
             Else
             
                SET v_var_per_comm = 0;
                SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
                select   IFNULL(fixed_inc_per,0) INTO v_parent_commisson from Reseller a where  a.Reseller_id = v_org_Reseller_Id LIMIT 1;
                SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
             end if;					
     
   
             SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
             select   IFNULL(fixed_inc_per,0) INTO v_Fixed_commisson from Reseller a where  a.Reseller_id = v_org_Reseller_Id    LIMIT 1;
             SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
             
             if v_parent_commisson > v_admin_commisson 
             then
                LEAVE sp_next;
             end if;
             
             set v_parent_commisson = IFNULL(v_parent_commisson,0);
             
             if v_tcommisson > 0 and v_parent_commisson > v_tcommisson 
             then
                set v_parent_commisson = v_parent_commisson -v_tcommisson;
             end if;  
    
             set v_tcommisson = v_tcommisson+v_parent_commisson;
             set v_comm_amount = amount*(v_tcommisson)/100.0;
             
             if v_tcommisson > v_admin_commisson 
             then
                LEAVE sp_exit;
             end if;
             
             set v_Reseller_Level =(v_tcount+1) -v_count;
             
             Insert into Reseller_commisson_info(Reseller_Id,parent_Reseller_id,Total_Purchase_amount,Comm_per,Comm_amount,Comm_date,
    Comm_assigned_by,Company_Id,Status,Reseller_level,Tier_Id,my_comm,Pay_Reference_No,commison_earned,var_per_comm,fixed_inc_per)
    values(v_org_Reseller_Id,v_P_Reseller_Id,v_purchase_cost,v_parent_commisson,v_comm_amount,CURRENT_TIMESTAMP,
    'Job',company_id,1,v_Reseller_Level,v_Tier_id,v_comm_amount,Pay_Reference_No,v_commsion_earned,v_var_per_comm,v_Fixed_commisson);
   
             insert into my_check_comm(parent_commisson,var_per_comm,Total_revenue,org_Reseller_Id,Company_Id,amount,my_var_comm,
             tcommisson,Pay_Reference_No)
             select v_parent_commisson, v_var_per_comm ,v_Total_revenue ,v_org_Reseller_Id ,company_id,amount,v_comm_amount,
             v_tcommisson,Pay_Reference_No;
          END;
          set v_count = v_count+1;
       End;
    END WHILE;  
    
    select my_comm INTO v_master_res_comm from Reseller_commisson_info  a
    join Reseller b on a.Reseller_Id = b.Reseller_id where Total_Purchase_amount = amount and a.Pay_Reference_No = Pay_Reference_No
    and b.fk_role_id = 2;   
    
    
    select   my_comm INTO v_res_mycomm from Reseller_commisson_info  a
    join Reseller b on a.Reseller_Id = b.Reseller_id where Total_Purchase_amount = amount and a.Pay_Reference_No = Pay_Reference_No
    and b.fk_role_id = 3;   
    
    select   my_comm INTO v_master_subres_comm from Reseller_commisson_info  a
    join Reseller b on a.Reseller_Id = b.Reseller_id where Total_Purchase_amount = amount and a.Pay_Reference_No = Pay_Reference_No
    and b.fk_role_id = 4;   
    
    
    update Reseller_commisson_info a set Master_mycomm = IFNULL(v_master_res_comm,0),Res_mycomm = IFNULL(v_res_mycomm,0),
    Master_subres_comm = IFNULL(v_master_subres_comm,0)
    where Total_Purchase_amount = amount and a.Pay_Reference_No = Pay_Reference_No;  
    DROP  TABLE IF EXISTS tt_temp_reseller_info; 
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_reseller_comp_Validate_user` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_reseller_comp_Validate_user`(mobileno VARCHAR(20),
email VARCHAR(100))
BEGIN


	

   CALL unifiedring.sme_reseller_comp_validate_user_info(mobileno,email);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_reseller_create_admin_account` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_reseller_create_admin_account`(
  login_id INT ,
  first_name VARCHAR(64),
  last_name VARCHAR(64),
  email_id VARCHAR(64),
  password VARCHAR(15),
  phone_no VARCHAR(15),
  emp_no VARCHAR(8),
  status INT,
  process_type INT, 
  Hubspot_contactid BIGINT,
  dept_id int)
Begin

     DECLARE v_errcode INT;
     DECLARE v_errmsg VARCHAR(50);
     DECLARE v_now DATETIME(3);
     DECLARE v_id INT;
  	
     sp_exit:
     BEGIN
        set v_errcode = -1;
        set v_errmsg = 'Failure';
        set v_now = CURRENT_TIMESTAMP;
        
        if email_id is null or email_id  = '' then
  	
           set v_errcode = -1;
           set v_errmsg = 'emailid should be mandatory';
        end if;
        
        If process_type = 1 then
  	
           If Exists(select  1 from  sme_reseller_company_admin_user a where a.email_id = email_id LIMIT 1) 
           then
              set v_errcode = -1;
              set v_errmsg = 'Failure';
              LEAVE sp_exit;
           end if;
           
 		insert into sme_reseller_company_admin_user(first_name,last_name,email_id,password,phone_no,emp_no,status,create_date,role_id,Hubspot_contactid,dept_id)
  		values(first_name,last_name,email_id,password,phone_no,emp_no,status,v_now,2,Hubspot_contactid,dept_id);
  		
          
           
           select a.login_id into v_id from sme_reseller_company_admin_user a where a.email_id = email_id LIMIT 1;
           
           if ROW_COUNT() > 0 then
  		
              set v_errcode = 0;
              set v_errmsg = 'Inserted';
              LEAVE sp_exit;
           end if;
        end if;
        
        If process_type = 2 then
  	
           If not Exists(select  1 from sme_reseller_company_admin_user b where b.login_id = login_id LIMIT 1) then
  		
              set v_errcode = -1;
              set v_errmsg = 'invalid login id';
              LEAVE sp_exit;
           end if;
           
           If Exists(select  1 from sme_reseller_company_admin_user c where c.email_id = email_id and c.login_id <> login_id LIMIT 1) then
  		
              set v_errcode = -1;
              set v_errmsg = 'Email already found';
              LEAVE sp_exit;
           end if;
           
           UPDATE sme_reseller_company_admin_user a
           set a.first_name = first_name,a.last_name = last_name,a.email_id = email_id,
			   a.phone_no = phone_no,a.emp_no = emp_no,a.status = status,
			   a.modify_date = v_now,a.Hubspot_contactid = case when IFNULL(Hubspot_contactid,0) > 0 then Hubspot_contactid else Hubspot_contactid end,
			   a.dept_id = dept_id
           where a.login_id = login_id;
           
           if ROW_COUNT() > 0 then
  		
              set v_errcode = 0;
              set v_errmsg = 'Account updated';
              LEAVE sp_exit;
           end if;
        end if;
        If process_type = 3 then
  	
           If not Exists(select  1 from sme_reseller_company_admin_user d where d.login_id = login_id LIMIT 1) then
  		
              set v_errcode = -1;
              set v_errmsg = 'No records found';
              LEAVE sp_exit;
           end if;
           If Exists(select  1 from sme_reseller_company_admin_user  e where e.email_id = email_id and e.login_id <> login_id LIMIT 1) then
  		
              set v_errcode = -1;
              set v_errmsg = 'Email already found';
              LEAVE sp_exit;
           end if;
           UPDATE sme_reseller_company_admin_user a
           set a.first_name = first_name,a.last_name = last_name,a.email_id = email_id,
			   a.password = password,a.phone_no = phone_no,a.modify_date = v_now,
			   a.dept_id = dept_id
           where a.login_id = login_id;
           if ROW_COUNT() > 0 then
  		
              set v_errcode = 0;
              set v_errmsg = 'Profile updated';
              LEAVE sp_exit;
           end if;
        end if;
     END;
     select v_errcode as errcode, v_errmsg as errmsg, IFNULL(v_id,login_id) as login_id;
  	
  End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_reseller_create_approval_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_reseller_create_approval_details`(
   id int,
   status int,
   approve_user_id int, 
   approve_status int,
   approve_comments varchar(200),
   payment_method int,
   payment_days int
    )
begin
    
   		declare v_errcode int default -1;
           declare v_errmsg varchar(200) default 'Failure';
           
   	sp_exit : Begin
   		if not exists(select * from smereseller.Res_company_deal_creation a where a.id = id LIMIT 1)then
   			SET v_errcode = -1;
   			SET v_errmsg = 'Failure : Deal not found';
   			LEAVE sp_exit;
   		end if;
           
           if exists(select * from smereseller.Res_company_deal_creation a where a.id = id LIMIT 1)then
           
   			if status = 2 then
   				update smereseller.Res_company_deal_creation a
                   set 		a.approve1_user_id = approve_user_id,
							a.approve1_status = approve_status,
                           a.approve1_comments = approve_comments, 
                           a.status = status,
                           a.approve1_created_date = current_timestamp(),
                           a.payment_method = ifnull(payment_method,a.payment_method),
                           a.payment_days = ifnull(payment_days,a.payment_days)
                   where a.id = id;
  				Else if status = 3 then
  					update smereseller.Res_company_deal_creation a
						set a.approve2_user_id = approve_user_id,
							a.approve2_status = approve_status,
							a.approve2_comments = approve_comments, 
							a.status = status,
							a.approve2_created_date = current_timestamp(),
							a.payment_method = ifnull(payment_method,a.payment_method),
							a.payment_days = ifnull(payment_days,a.payment_days)
  					 where a.id = id;	
  				else if status = 4 then
					update smereseller.Res_company_deal_creation a
					set 	a.approve3_user_id = approve_user_id,
							a.approve3_status = approve_status,
							a.approve3_comments = approve_comments, 
							a.status = status,
							a.approve3_created_date = current_timestamp(),
							a.payment_method = ifnull(payment_method,a.payment_method),
							a.payment_days = ifnull(payment_days,a.payment_days)
  					 where a.id = id;	
  				else 
  					update smereseller.Res_company_deal_creation a
  					 set a.status = status  where a.id = id;	
  				 End if;       
  				End if;
               End if;
    
               if row_count()>0 then
   				SET v_errcode = 0;
   				SET v_errmsg = 'Success : Deal status updated';
   				LEAVE sp_exit;
               End if;
   
   		end if;
           
           
   	End sp_exit;
   		select v_errcode as errcode, v_errmsg as errmsg;
    End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_reseller_create_commison_tier` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_reseller_create_commison_tier`(Tier_Name VARCHAR(100),  
 Tier_min FLOAT,  
 Tier_To FLOAT,  
 Commission FLOAT,  
 Create_By VARCHAR(50),  
 Process_Type INT,  
 Tier_ID INT,  
 variable_per FLOAT)
BEGIN
 
    DECLARE v_errcode INT;  
    DECLARE v_errmsg VARCHAR(250);  
    
    
  
    sp_exit:BEGIN
    
       IF Process_Type = 1 
       then 
       begin
          IF EXISTS(SELECT  1 FROM  sme_Reseller_Tier a WHERE a.Tier_min = Tier_min
          AND a.Tier_To = Tier_To AND a.Create_By = Create_By LIMIT 1) 
          then  
          select '41';
             Set v_errcode = -1;
             Set v_errmsg = 'Tier already Exists!';
             LEAVE sp_exit;
          end if;
          
          IF Tier_min IS NULL OR Tier_To IS NULL 
          then  
          select '49';
             Set v_errcode = -1;
             Set v_errmsg = 'Please Enter Tier Min and Tier Maximum Value.';
             LEAVE sp_exit;
          end if;
          
           INSERT INTO sme_Reseller_Tier (Tier_Name,Tier_min,Tier_To,Commission,Create_By,Create_date,Status,variable_per)
			VALUES(Tier_Name,Tier_min,Tier_To,Commission,Create_By,CURRENT_TIMESTAMP,1,variable_per);
   
          IF found_rows() >= 0 
          then  
             Set v_errcode = 0;
             Set v_errmsg = 'Success to create Tier.';
             LEAVE sp_exit;
          end if;
          end;
       end if;
       
       
       
       
       IF Process_Type = 2 
       then 
       
          IF NOT EXISTS(SELECT  * FROM sme_Reseller_Tier a WHERE a.Tier_Id = Tier_ID LIMIT 1) 
          then  
             Set v_errcode = -1;
             Set v_errmsg = 'Commison Tier not found.';
          end if;
          
          IF Tier_min IS NULL OR Tier_To IS NULL 
          then  
             Set v_errcode = -1;
             Set v_errmsg = 'Please Enter Tier Min and Tier Maximum Value.';
             LEAVE sp_exit;
          end if;
             
          SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
       
       DROP TEMPORARY TABLE IF EXISTS tt_temp_Reseller;
       CREATE TEMPORARY TABLE tt_temp_Reseller AS select distinct Reseller_id as Reseller_id 
             from Reseller b where b.Fk_Reseller_Id = Create_By;
          SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
       
       IF  EXISTS(SELECT  * FROM sme_Reseller_Tier a WHERE a.Tier_min = Tier_min and a.Tier_To = Tier_To
          and a.Create_By in(select Reseller_id  from tt_temp_Reseller) LIMIT 1) 
          then  
             Set v_errcode = -1;
             Set v_errmsg = 'Before change please inform subreseller to change the incentive scheme.';
             LEAVE sp_exit;
          end if;
          
          Update sme_Reseller_Tier a Set a.Tier_Name = Tier_Name, a.Tier_min = Tier_min, a.Tier_To = Tier_To,
          a.variable_per = variable_per,
          a.Commission = Commission, a.last_Update = CURRENT_TIMESTAMP Where  a.Tier_Id = Tier_ID;
          
          IF found_rows() > 0 
          then  
             Set v_errcode = 0;
             Set v_errmsg = 'Success to Update Tier info.';
              LEAVE sp_exit;
          end if;
       end if;
    END;
    select v_errcode as errcode,v_errmsg as errmsg;  
    
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_Reseller_create_comp_emergency` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_Reseller_create_comp_emergency`(Cnt_ReffID INT,  
   Emgncy_contact_name VARCHAR(250),  
   Emgncy_PhoneNo VARCHAR(20),  
   Emgency_Address1 VARCHAR(500),  
   Emgency_Address2 VARCHAR(50),  
   State VARCHAR(150),  
   City VARCHAR(160),  
   Country VARCHAR(160),  
   Phone_No VARCHAR(20),  
   Email VARCHAR(100),  
   postcode VARCHAR(30))
BEGIN
  
      DECLARE v_errcode INT;  
      DECLARE v_errmsg VARCHAR(160);  
      
      DECLARE v_Pk_Res_CompID INT;  
      DECLARE v_Pk_EmgId INT;   
      
      sp_exit:
      BEGIN
         SET v_errcode = -1;
         SET v_errmsg = 'Failure to create details';
         
         IF Cnt_ReffID IS NULL then
    select '111';
            SET v_errcode = -1;
            SET v_errmsg = 'Input Details Found.';
            LEAVE sp_exit;
         end if;
         
         SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
         select IFNULL(Pk_rs_cmpid,0) INTO v_Pk_Res_CompID from reseller_company a where a.cnt_ref_id = Cnt_ReffID LIMIT 1;
         SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
                
         IF v_Pk_Res_CompID IS NULL then
            SET v_errcode = -1;
            SET v_errmsg = 'Input Details Found.';
            LEAVE sp_exit;
         end if;
         
         SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
         select   IFNULL(Pk_EmgId,0) INTO v_Pk_EmgId FROM  Reseller_Comp_Emg_info order by IFNULL(Pk_EmgId,0) desc LIMIT 1;
         SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
         SET v_Pk_EmgId = IFNULL(v_Pk_EmgId,0)+1;
         INSERT INTO Reseller_Comp_Emg_info(Pk_EmgId,Fk_Pk_rs_cmpid,Contact_name,Address1,Address2,Phone_No,Email_Id,Country,State,City,postcode)
 		VALUES(v_Pk_EmgId,v_Pk_Res_CompID,Emgncy_contact_name,Emgency_Address1,Emgency_Address2,Emgncy_PhoneNo,Email,Country,State,City,postcode);
    
         IF ROW_COUNT() > 0 then
    
            SET v_errcode = 0;
            SET v_errmsg = 'Success to create Emergency Contact details.';
            LEAVE sp_exit;
         end if;
      END;
      Select v_errcode as errcode,v_errmsg as errmsg;  
      
   END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_reseller_create_deal_creation` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_reseller_create_deal_creation`(
	id int,
	comp_user_id int,
	reseller_id int,
	payment_link text,
	hubspot_contact_id bigint,
	tier_id int,
	status int,
	create_by int,
	payment_method int,
	payment_days int
)
Begin
    
    	declare errcode int;
        declare errmsg varchar(50);
        
    	insert into smereseller.Res_company_deal_creation(comp_user_id,reseller_id,payment_link,create_date,status,hubspot_contact_id,approve1_user_id,approve1_status,approve1_comments,approve2_user_id,approve2_status,approve2_comments,approve1_created_date,approve2_created_date,tier_id,create_by,payment_method)
    	values(comp_user_id,reseller_id,payment_link,current_timestamp(),status,hubspot_contact_id,0,0,null,0,0,null,null,null,tier_id,create_by,payment_days);
    
    	select 0 as errcode,'Success' as errmsg;
    End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_reseller_create_KYC` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_reseller_create_KYC`(Reseller_Id INT,
Bank_Name VARCHAR(50),
Branch VARCHAR(100),
IFSC VARCHAR(50),
Account_Number VARCHAR(25),
Acc_Holder_Name VARCHAR(50),
Account_Type VARCHAR(30),
Status INT,
Process_Type INT, 
KYC_id INT,
Country VARCHAR(20),
City VARCHAR(20),
Sort_code VARCHAR(25),
BIC_number VARCHAR(25))
BEGIN

   DECLARE v_errcode INT;  
   DECLARE v_errmsg VARCHAR(250);  
   
 
   sp_exit:
   BEGIN
      IF Process_Type = 1 then
  
         IF EXISTS(SELECT 1 FROM  Reseller_Bank_KYC_Info a WHERE a.Reseller_Id = Reseller_Id LIMIT 1) then
     
            Set v_errcode = -1;
            Set v_errmsg = 'KYC details already Exists!';
            LEAVE sp_exit;
         end if;
         
		INSERT INTO Reseller_Bank_KYC_Info(Reseller_Id,Bank_Name,Branch,IFSC,Account_Number,Acc_Holder_Name,Account_Type,Status,Create_date,Country,City,Sort_code,BIC_number)
		VALUES(Reseller_Id,Bank_Name,Branch,IFSC,Account_Number,Acc_Holder_Name,Account_Type,Status,CURRENT_TIMESTAMP,Country,City,Sort_code,BIC_number);
 
         IF ROW_COUNT() > 0 then
  
            Set v_errcode = 0;
            Set v_errmsg = 'Success to create KYC.';
         end if;
      end if; 
 
 
      IF Process_Type = 2 then
  
         IF NOT EXISTS(SELECT  1 FROM Reseller_Bank_KYC_Info a WHERE a.Reseller_Id = Reseller_Id  AND a.KYC_id = KYC_id LIMIT 1) then
    
            Set v_errcode = -1;
            Set v_errmsg = 'KYC details not found.';
            LEAVE sp_exit;
         end if;
         
         Update Reseller_Bank_KYC_Info a Set a.Bank_Name = Bank_Name,a.Branch = Branch,a.IFSC = IFSC,a.Account_Number = Account_Number,
         a.Acc_Holder_Name = Acc_Holder_Name,a.Account_Type = Account_Type,a.Status = Status,a.last_update = CURRENT_TIMESTAMP,
         a.Country = Country,a.City = City, a.Sort_code = Sort_code,a.BIC_number = BIC_number  Where a.Reseller_Id = Reseller_Id
         AND a.KYC_id = KYC_id;
         IF ROW_COUNT() > 0 then
  
            Set v_errcode = 0;
            Set v_errmsg = 'KYC details updated Successfully.';
         end if;
      end if;
   END;
   select v_errcode as errcode,v_errmsg as errmsg;  
   
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_Reseller_delete_expired_company_Job` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_Reseller_delete_expired_company_Job`()
SWL_return:
BEGIN

sp_exit:
   BEGIN
		 DECLARE EXIT HANDLER FOR SQLEXCEPTION
         begin
            SELECT 'failed';
            ROLLBACK;
            
         end;
   
 
      START TRANSACTION;
      BEGIN
    
         DROP TEMPORARY TABLE IF EXISTS tt_temp_company_info;
         SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
         CREATE TEMPORARY TABLE tt_temp_company_info AS Select   Pk_rs_cmpid,Title,first_name,last_name,company_name,address_1,
		address_2,city,state,zip_code,country,phone,mobileno,email,create_date,status,
		reseller_id,cnt_ref_id,Vpcp_Company_Id,domain_Id,paid_amount,paid_reference,
		free_trail,plan_id,plan_Billing_cycle,plan_Type_ID,Myacc_Password,avail_number,
		Hubspot_companyid,Hubspot_contactid  
            from reseller_company
            where
            IFNULL(free_trail,0) <> 1
            and IFNULL(Vpcp_Company_Id,0) = 0
            and TIMESTAMPDIFF(DAY,create_date,CURRENT_TIMESTAMP) >= 30
            and IFNULL(email,'') not in(select IFNULL(email,'') from unifiedring.vbcp_company)
            order by create_date desc;
           
          
         SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
         insert into reseller_company_del_info(Pk_rs_cmpid,Title,first_name,last_name,company_name,address_1,
		address_2,city,state,zip_code,country,phone,mobileno,email,create_date,status,
		reseller_id,cnt_ref_id,Vpcp_Company_Id,domain_Id,paid_amount,paid_reference,
		free_trail,plan_id,plan_Billing_cycle,plan_Type_ID,Myacc_Password,avail_number,
		Hubspot_companyid,Hubspot_contactid,delete_date)
         select Pk_rs_cmpid,Title,first_name,last_name,company_name,address_1,
		address_2,city,state,zip_code,country,phone,mobileno,email,create_date,status,
		reseller_id,cnt_ref_id,Vpcp_Company_Id,domain_Id,paid_amount,paid_reference,
		free_trail,plan_id,plan_Billing_cycle,plan_Type_ID,Myacc_Password,avail_number,
		Hubspot_companyid,Hubspot_contactid,CURRENT_TIMESTAMP from  tt_temp_company_info; 

		
         delete a from  unifiedring.UR_ECom_User_Dtl a
         join tt_temp_company_info b on a.UR_ECom_Id = b.cnt_ref_id;
	
			
         delete a from unifiedring.UR_ECom_Company a
         join tt_temp_company_info b on a.Comp_ContactId = b.cnt_ref_id;
         insert into  Res_Comp_Device_Order_del_info(Order_Id,Fk_Resller_Id,Fk_rs_cmpid,tot_phone_charge,
		tot_discount,tot_tax_fee,tot_charge,createdate,Order_source,Order_Status,plan_charge,
		Number_charge,product,plan,Duration,Users,plan_ind_amount,Shipping_charge)
         select Order_Id,Fk_Resller_Id,Fk_rs_cmpid,tot_phone_charge,
		tot_discount,tot_tax_fee,tot_charge,createdate,Order_source,Order_Status,plan_charge,
		Number_charge,product,plan,Duration,Users,plan_ind_amount,Shipping_charge from  Res_Comp_Device_Order a
         join  tt_temp_company_info b on a.Fk_rs_cmpid = b.Pk_rs_cmpid;
         delete a from  Res_device_order_item a
         join  Res_Comp_Device_Order b on a.order_id = b.Order_Id
         join tt_temp_company_info c on  c.Pk_rs_cmpid = b.Fk_rs_cmpid;
         delete a from  Res_Order_delivery_address a
         join Res_Comp_Device_Order b on a.order_id = b.Order_Id
         join tt_temp_company_info c on  c.Pk_rs_cmpid = b.Fk_rs_cmpid;
         delete a from Res_Comp_Device_Order a
         join  tt_temp_company_info  b on a.Fk_rs_cmpid = b.Pk_rs_cmpid;
         delete a from  Reseller_Comp_Emg_info a
         join  tt_temp_company_info  b on a.Fk_Pk_rs_cmpid = b.Pk_rs_cmpid;

		
         delete a from  reseller_company a
         join tt_temp_company_info b on a.Pk_rs_cmpid = b.Pk_rs_cmpid;
      END;
  
      COMMIT;
       
      LEAVE SWL_return;
   
END sp_exit;
   
END SWL_return ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_reseller_drp_data` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_reseller_drp_data`(drp_type INT)
begin

   if drp_type = 1 
   then
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select Pk_Reseller_Type as drp_value,Reseller_Type as drp_text from Reseller_type_Master 
      order by Reseller_Type asc;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   end if;  
   
 
   if drp_type = 2 
   then
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select Pk_certification_id as drp_value,certification as drp_text from Reseller_certification_Master
      order by Pk_certification_id asc;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   end if;  
   
 
   if drp_type = 3 
   then
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select product_id as drp_value,product_name as drp_text from resell_product_Master
      order by product_id asc;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   end if;  
   
 
   if drp_type = 4 
   then
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select Vertical_id as drp_value,Vertical_name as drp_text  from Vertical_Master
      order by Vertical_id asc;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   end if;  
   
 
   if drp_type = 5 
   then 
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select Stategy_id as drp_value,Stategy_name as drp_text from Sales_Stategy_Master
      order by Stategy_id asc;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   end if;  
   
 
   if drp_type = 6 
   then
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select Pk_Emp_Size_Id as drp_value,Emp_size_name as drp_text from Employee_Size_Master
      order by Pk_Emp_Size_Id asc;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   end if;  
   
 
   if drp_type = 7 
   then
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select Pk_cust_Size_Id as drp_value,Cust_size_name as drp_text from Cust_Size_info_Master
      order by Pk_cust_Size_Id asc;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   end if;  
   
 
   if drp_type = 8 
   then 
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select Pk_company_size_id as drp_value,Comp_size_name as drp_text from Sell_Company_Size_Master
      order by Pk_company_size_id asc;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   end if;  
   
 
   if drp_type = 9 
   then 
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select Pk_Program_id as drp_value,Partner_prog_name as drp_text from Partner_Program_Master
      order by Pk_Program_id asc;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   end if;  
  
 
   if drp_type = 10 
   then 
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select Pk_role_id as drp_value,role_name as drp_text from Reseller_role where role_name <> ''
      and IFNULL(role_status,0) = 1
      order by Pk_role_id asc;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   end if;  
  
 
   if drp_type = 11 
   then
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select status_id as drp_value,status as drp_text from Reseller_status_ref
      order by status_id asc;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   end if;  
  
 
   if drp_type = 12 
   then
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select id as drp_value,commisson_structure as drp_text from Reseller_commisson_structure
      order by id asc;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   end if;  
  
 
   if drp_type = 13 
   then
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select date_id as drp_value,date_range as drp_text from Reseller_Date_range
      order by date_id asc;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   end if;   
   
   if drp_type = 14 
   then
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select subm_id as drp_value,subm_status as drp_text from reseller_submission_status
      order by subm_id asc;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   end if;  
  
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_reseller_email_id_check` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_reseller_email_id_check`(
email VARCHAR(100),  
mobileno VARCHAR(40))
Begin

	DECLARE v_errcode INT;  
	DECLARE v_errmsg VARCHAR(50);  
  
   If exists(select  1 from reseller_company a where (a.email = email or a.mobileno = mobileno) LIMIT 1) then
  
      set v_errcode = -1;
      set v_errmsg = 'Emailid/mobileno already exists';
   ELSE
      set v_errcode = 0;
      set v_errmsg = 'New email id/mobileno';
   end if;  
  
   select v_errcode as errcode,v_errmsg as errmsg;  
  
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_reseller_email_verify_admin_account` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_reseller_email_verify_admin_account`(email_id VARCHAR(64))
Begin


   DECLARE v_errcode INT;
   DECLARE v_errmsg VARCHAR(50);
			
   sp_exit:
   BEGIN
      If not Exists(select 1 from sme_reseller_company_admin_user a where a.email_id = email_id LIMIT 1) then
		
         set v_errcode = 0;
         set v_errmsg = 'New email id';
         LEAVE sp_exit;
      ELSE
         set v_errcode = 0;
         set v_errmsg = 'Email id already exists';
         LEAVE sp_exit;
      end if;
   END sp_exit;
   select v_errcode as errcode,v_errmsg as errmsg;
	
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_reseller_Forgot_Password_admin_account` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_reseller_Forgot_Password_admin_account`(login_id INT,  
email_id VARCHAR(64))
Begin

   DECLARE v_errcode INT;  
   DECLARE v_errmsg VARCHAR(50);  
   DECLARE v_password VARCHAR(64);  
   DECLARE v_Hubspot_contactid BIGINT;  
  
   
   sp_exit:BEGIN
   
      set v_errcode = -1;
      set v_errmsg = 'Failure';
   
   If not Exists(select * from sme_reseller_company_admin_user a where a.email_id = email_id and a.login_id = login_id LIMIT 1) 
   then  
         set v_errcode = -1;
         set v_errmsg = 'No record found';
         LEAVE sp_exit;
      end if;
      
      select a.password, IFNULL(a.Hubspot_contactid,0) INTO v_password,v_Hubspot_contactid 
      from sme_reseller_company_admin_user a where a.email_id = email_id and a.login_id = login_id;
      
      if found_rows() > 0 
      then  
         set v_errcode = 0;
         set v_errmsg = 'success';
         LEAVE sp_exit;
      end if;
   END;
   
   select v_errcode as errcode,v_errmsg as errmsg,login_id as login_id,v_password as password,
 IFNULL(v_Hubspot_contactid,0) as Hubspot_contactid;  
   
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_reseller_freetrial_activation` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_reseller_freetrial_activation`(Cnt_ReffID INT)
begin

  
  
   DECLARE v_errcode INT;  
   DECLARE v_errmsg VARCHAR(50);  
   DECLARE v_email VARCHAR(30);  
  
   sp_exit:
   BEGIN
      If not exists(select  1 from reseller_company where cnt_ref_id = Cnt_ReffID LIMIT 1) then
 
         set v_errcode = -1;
         set v_errmsg = 'Company not found';
         LEAVE sp_exit;
      end if;
      If exists(select  1 from reseller_company where cnt_ref_id = Cnt_ReffID and free_trail = 1
      AND STATUS = 1 LIMIT 1) then
 
         set v_errcode = -1;
         set v_errmsg = 'Company Free trail is already active status';
         LEAVE sp_exit;
      Else
         select   email INTO v_email from reseller_company where cnt_ref_id = Cnt_ReffID;
         update reseller_company set free_trail = 1,status = 1
         where cnt_ref_id = Cnt_ReffID;
      end if;
      If ROW_COUNT() > 0 then
 
         set v_errcode = 0;
         set v_errmsg = 'Company Free trail - status activated';
      end if;
   END;
   select v_errcode as errcode, v_errmsg as errmsg,v_email as email;  
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_reseller_get_admin_account_list` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_reseller_get_admin_account_list`(status VARCHAR(1),
   login_id INT)
Begin
 
      DECLARE subm_status VARCHAR(1);
   
      if status in (1,'') then	set subm_status = '';	end if;
      if status = '2' then		set subm_status = '4';	end if;
      if status = '3' then		set subm_status = '1';	end if;
      if status = '4' then		set subm_status = '0';	end if;
   
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select a.login_id as Admin_id,First_name,Last_name,Phone_no,Email_id,
      a.status as Status_id,
      emp_no as emp_no,password,dept_id
      from sme_reseller_company_admin_user a
      where (a.status = status or (IFNULL(status,'') = '')) and ((IFNULL(login_id,0) = 0) or a.login_id = login_id);
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   	
   End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_reseller_get_admin_members_view_performance_new_Company_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_reseller_get_admin_members_view_performance_new_Company_info`(reseller_id INT,
date_range_id INT)
Begin


	
   DECLARE v_now DATETIME(3);
   DECLARE v_date_range VARCHAR(50);
   DECLARE v_created_count INT;
   DECLARE v_freetrail_count INT;
   DECLARE v_paid_subs_count INT;
   DECLARE v_active_count INT;
   DECLARE v_inactive_count INT;
   IF reseller_id is null then
      set reseller_id = 0;
   END IF;
   IF date_range_id is null then
      set date_range_id = '';
   END IF;
   set v_now = STR_TO_DATE(DATE_FORMAT(CURRENT_TIMESTAMP,'%Y-%m-%d'),'%Y-%m-%d');

   If date_range_id = 1 then	
      set v_date_range = v_now;
   end if; 
   If date_range_id = 2 then	
      set v_date_range = v_now;
   end if;
   If date_range_id = 3 then	
      set v_date_range = TIMESTAMPADD(day,-1,v_now);
   end if;
   If date_range_id = 4 then	
      set v_date_range = TIMESTAMPADD(day,-8,v_now);
   end if;
   If date_range_id = 5 then	
      set v_date_range = TIMESTAMPADD(day,-15,v_now);
   end if;
   If date_range_id = 6 then	
      set v_date_range = TIMESTAMPADD(day,-31,v_now);
   end if;
   If date_range_id in(7,'') then	
      set v_date_range = '';
   end if;
	
	

   if date_range_id <> 3 then
	
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select Distinct	 a.reseller_id as reseller_id,
				(CONCAT(a.Firstname,' ',a.lastname)) as member_name,
				b.role_name as member_type,
				ur_get_reseller_count(a.reseller_id,1) as created,
				ur_get_reseller_count(a.reseller_id,2) as free_trails_count,
				ur_get_reseller_count(a.reseller_id,3) as paid_subscription_count,
				ur_get_reseller_count(a.reseller_id,4) as active_count,
				ur_get_reseller_count(a.reseller_id,5) as inactive_count,
				null as expired_count
      from Reseller a 
      left join  reseller_company rc  on a.reseller_id = rc.Reseller_id
      LEFT JOIN Reseller_role b  on a.fk_role_id = b.Pk_role_id
      LEFT JOIN Reseller_status_ref l	 on a.Status = l.status_id
      where ((v_date_range = '') or cast(rc.create_date as DATE) between cast(v_date_range as DATE) and cast(v_now as DATE))
      and rc.vpcp_company_id is not null;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   ELSE
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select Distinct	 a.reseller_id as reseller_id,
				(CONCAT(a.Firstname,' ',a.lastname)) as member_name,
				b.role_name as member_type,
				ur_get_reseller_count(a.reseller_id,1) as created,
				ur_get_reseller_count(a.reseller_id,2) as free_trails_count,
				ur_get_reseller_count(a.reseller_id,3) as paid_subscription_count,
				ur_get_reseller_count(a.reseller_id,4) as active_count,
				ur_get_reseller_count(a.reseller_id,5) as inactive_count,
				null as expired_count
      from Reseller a 
      left join reseller_company rc  on a.reseller_id = rc.Reseller_id
      LEFT JOIN Reseller_role b  on a.fk_role_id = b.Pk_role_id
      LEFT JOIN Reseller_status_ref l	 on a.Status = l.status_id
      where  ((v_date_range = '') or cast(rc.create_date as DATE) between cast(v_date_range as DATE) and cast(v_date_range as DATE))
      and rc.vpcp_company_id is not null;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   end if;


End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_reseller_get_admin_report_commission_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_reseller_get_admin_report_commission_info`(
      commission_structure INT,  
       date_range_id INT)
begin
       
          DECLARE v_errcode INT;  
          DECLARE v_errmsg VARCHAR(50);  
          DECLARE v_now DATETIME(3);  
          DECLARE v_date_range VARCHAR(50); 
          DECLARE commission_structure_type VARCHAR(10);  
          DECLARE v_revenue_earned FLOAT;
          DECLARE v_commission_per_earned FLOAT;
          DECLARE v_Comm_amount_earned FLOAT;
          DECLARE v_role_id INT;
          declare v_default_val int;
          
          
          set v_default_val = 0;
          
          IF commission_structure is null  then set commission_structure = 0; END IF;
          IF date_range_id is null  then set date_range_id = ''; END IF;
          if commission_structure in(1,'')  then set commission_structure_type = ''; end if;  
          if commission_structure = 2  then  set commission_structure_type = '1'; end if;  
          if commission_structure = 3  then          set commission_structure_type = '2'; end if;  
             
          set v_now = STR_TO_DATE(DATE_FORMAT(CURRENT_TIMESTAMP,'%Y-%m-%d'),'%Y-%m-%d');  
          
          If date_range_id = 1 then  		set v_date_range = v_now; 							end if;  
          If date_range_id = 2 then  		set v_date_range = v_now; 							end if;  
          If date_range_id = 3 then  		set v_date_range = TIMESTAMPADD(day,-1,v_now);      end if;  
          If date_range_id = 4 then			set v_date_range = TIMESTAMPADD(day,-8,v_now); 		end if;       
          If date_range_id = 5 then			set v_date_range = TIMESTAMPADD(day,-15,v_now); 	end if;  
          If date_range_id = 6 then  		set v_date_range = TIMESTAMPADD(day,-31,v_now); 	end if;  
          If date_range_id in(7,'') then  	set v_date_range = ''; 								end if;  
           
          drop TEMPORARY table IF EXISTS tt_temp_sum_commission;   
          create TEMPORARY table tt_temp_sum_commission
          (
             reseller_id INT,
             total_purchase_amount FLOAT,
             comm_per FLOAT,
             Comm_amount FLOAT,
             fixed_inc_per FLOAT,
             var_per_comm FLOAT,
             Inc_Tier_Type INT,
             comm_earned FLOAT,
             comm_date DATETIME(3)
          );  
          
          SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
          insert into tt_temp_sum_commission(reseller_id,total_purchase_amount,comm_per,fixed_inc_per,var_per_comm,Inc_Tier_Type,Comm_amount,comm_earned,comm_date)
          select distinct reseller_id,IFNULL(sum(total_purchase_amount),v_default_val) total_purchase_amount,IFNULL(comm_per,v_default_val) comm_per,fixed_inc_per,var_per_comm,Inc_Tier_Type,
     	my_comm,case when IFNULL(v_role_id,v_default_val) = 2 then sum(IFNULL(Master_mycomm,v_default_val))
          when IFNULL(v_role_id,v_default_val) = 3 then sum(IFNULL(Res_mycomm,v_default_val))
          when IFNULL(v_role_id,v_default_val) = 4 then sum(IFNULL(Master_subres_comm,v_default_val)) else v_default_val end ,comm_date
          from Reseller_commisson_info b 
          where b.reseller_Id in(select a.reseller_id from Reseller a where a.fk_role_id = 2)
          group by reseller_id,comm_per,fixed_inc_per,var_per_comm,Inc_Tier_Type,my_comm,
          commison_earned,comm_date
          order by reseller_id,comm_date;
          SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
     
          If date_range_id <> 3 
          then 
             SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
             select Distinct  a.reseller_id as reseller_id,(CONCAT(a.Firstname,' ',a.lastname)) as Name,
          b.role_name as member_type,
          IFNULL(a.Inc_Tier_Type,v_default_val) as commission_structure,
          IFNULL(a.fixed_inc_per,v_default_val) as commission_percentage,
          IFNULL(a.var_inc_per,v_default_val) as commission_percentage_var,
          cast(IFNULL(sme_reseller_performance_info(a.reseller_id,5),v_default_val) as DECIMAL(10,0)) as revenue_earned,
          cast(IFNULL(sme_reseller_performance_info(a.reseller_id,3),v_default_val) as DECIMAL(10,0)) as commission_earned
             from Reseller a 
             LEFT JOIN tt_temp_sum_commission tc on a.reseller_id = tc.reseller_id
             LEFT JOIN Reseller_role b  on a.fk_role_id = b.Pk_role_id
             LEFT JOIN Reseller_status_ref l  on a.Status = l.status_id
             where  a.fk_role_id = 2 and 
             (a.Inc_Tier_Type = commission_structure_type OR IFNULL(commission_structure_type,'') = '')
             and ((v_date_range = '') or cast(a.create_date as DATE) between cast(v_date_range as DATE) and cast(v_now as DATE));
             
             SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
             
             If found_rows() > 0 
             then  
                set v_errcode = 0;
                set v_errmsg = 'success';
             end if;
             
          Else
    
             SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
          select Distinct  a.reseller_id as reseller_id,(CONCAT(a.Firstname,' ',a.lastname)) as Name,
          b.role_name as member_type,
          IFNULL(a.Inc_Tier_Type,v_default_val)  as commission_structure,
          IFNULL(a.fixed_inc_per,v_default_val) as commission_percentage,
          IFNULL(a.var_inc_per,v_default_val) as commission_percentage_var,
          cast(IFNULL(sme_reseller_performance_info(a.reseller_id,5),v_default_val) as DECIMAL(10,0)) as revenue_earned,
          cast(IFNULL(sme_reseller_performance_info(a.reseller_id,3),v_default_val) as DECIMAL(10,0)) as commission_earned
             from Reseller a 
             LEFT JOIN tt_temp_sum_commission tc on a.reseller_id = tc.reseller_id
             LEFT JOIN Reseller_role b  on a.fk_role_id = b.Pk_role_id
             LEFT JOIN Reseller_status_ref l  on a.Status = l.status_id
     		where a.fk_role_id = 2 
     		and (a.Inc_Tier_Type = commission_structure_type OR IFNULL(commission_structure_type,'') = '')
     		And ((v_date_range = '') or cast(a.create_date as DATE) between cast(v_date_range as DATE) and cast(v_date_range as DATE));
     
             SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
             
             If found_rows() > 0 
             then  
                set v_errcode = 0;
                set v_errmsg = 'success';
             end if;
          end if;  
          
     
          select v_errcode as errcode,v_errmsg as errmsg;  
       end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_reseller_get_admin_submission_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_reseller_get_admin_submission_details`(reseller_id INT)
Begin

  
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   Select a.Title, a.Reseller_Id,Firstname,Lastname,Email as Email_Address,Mobile as Mobile_number,Phone as phone_number,
   Company_name,(CONCAT(Address1,', ',Address2)) as Company_address,
   l.status as reseller_status,IFNULL(a.Statename,'') as State,
   a.City,a.Zipcode,a.Country,
   b.Reseller_Type as Reseller_Type,
   IFNULL(c.certification,'') as certification,
   IFNULL(d.product_name,'') as product_name,
   IFNULL(e.Vertical_name,'') as most_sold_verticals,
   IFNULL(f.Stategy_name,'') as sales_strategy,
   IFNULL(g.Emp_size_name,'') as no_of_employees,
   IFNULL(k.Cust_size_name,'') as no_of_customers,
   a.sold_to as sold_to,
   a.annual_gross_revenue as annual_gross_revenue,
   IFNULL(i.Partner_prog_name,'') as Partner_prog_name,
   IFNULL(Hubspot_contactid,0) as Hubspot_contactid
   from Reseller a  
   LEFT JOIN Reseller_type_Master b     on a.Fk_Reseller_Type = b.Pk_Reseller_Type
   LEFT JOIN Reseller_certification_Master c on a.Fk_certification_Id = c.Pk_certification_id
   LEFT JOIN resell_product_Master d    on a.Fk_product_id = d.product_id
   LEFT JOIN Vertical_Master e    on a.Fk_Vertical_id = e.Vertical_id
   LEFT JOIN Sales_Stategy_Master f     on a.Fk_Stategy_id = f.Stategy_id
   LEFT JOIN Employee_Size_Master g     on a.Fk_Emp_Size_id = g.Pk_Emp_Size_Id
   LEFT JOIN Partner_Program_Master i   on a.Fk_Part_prog_id = i.Pk_Program_id
   LEFT JOIN Sell_Company_Size_Master j on a.Fk_Comp_Size_id = j.Pk_company_size_id
   LEFT JOIN Cust_Size_info_Master k    on a.Fk_Cust_Size_id = k.Pk_cust_Size_Id
   LEFT JOIN Reseller_status_ref l     on a.Status = l.status_id
   where  (a.Reseller_id = reseller_id);
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;   
    
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_reseller_get_admin_submission_list` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_reseller_get_admin_submission_list`(
 	status VARCHAR(1),
     submission_from VARCHAR(10),
     submission_to VARCHAR(10),
     p_sold_to VARCHAR(30)
 )
Begin
         
            DECLARE subm_status VARCHAR(1);
         
			IF status is null then 				set status = '';			END IF;
			IF submission_from is null then 	set submission_from = ''; 	END IF;
			IF submission_to is null then		set submission_to = '';		END IF;
			if status in(1,'') then 			set subm_status = ''; 		END IF;
			if status = 2 then 					set subm_status = 4;		END IF;
			if status = 3 then 					set subm_status = 1;		END IF;
			if status = 4 then 					set subm_status = '0';		END IF;
         	
            SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
			select 	a.reseller_id, a.Firstname,a.Lastname,a.Phone,a.Email,a.Status,a.Create_date,
					a.City,a.Zipcode, a.Country,a.Company_name,
					case when IFNULL(a.Status,'0') = '0' then 'Rejected' 
					when a.Status = '1' then 'Approved' 
					when (a.Status = '4') then 'Pending' end as Status_name,
					a.Hubspot_contactid as Hubspot_contactid,
					IFNULL(a.Mobile,'') as Mobile,
					IFNULL(calledby,'') as create_by,
					a.commission_status,
					a.partner_type,
					a.sold_to as sold_to
            from Reseller a 
            join Reseller_role b  on a.fk_role_id = b.Pk_role_id
            where a.fk_role_id = 2 and a.fk_reseller_id = 1005 and a.calledby in('web','admin',1,2,3,4)
            and ((submission_from = '') or (DATE_FORMAT(a.Create_date,'%Y-%m-%d') >= submission_from))
            and ((submission_to = '') or (DATE_FORMAT(a.Create_date,'%Y-%m-%d') <= submission_to))
            and ((IFNULL(subm_status,'') = '') or a.status = subm_status)
            and ((IFNULL(p_sold_to,'') = '') or a.sold_to = p_sold_to)
            order by a.create_date desc,a.reseller_id desc;
            SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
    
         End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_reseller_get_chain_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_reseller_get_chain_info`(Resller_id INT)
begin

   DECLARE v_count INT;   
   DECLARE v_tcount INT;   
   DECLARE v_Reseller_Id_Out VARCHAR(150);  
   DECLARE v_Reseller_ID_Val INT;   
   DECLARE v_Res_role VARCHAR(50);  
   DECLARE v_parent_reseller_id INT;   
   
   set v_count = 1;  
   set v_tcount = 500;  
  
  
   DROP TEMPORARY TABLE IF EXISTS tt_temp_reseller_info;  
   create TEMPORARY table tt_temp_reseller_info
   (
      id INT   AUTO_INCREMENT PRIMARY KEY,
      reseller_id INT,
      parent_reseller_id INT,
      reseller_role VARCHAR(250)
   )  AUTO_INCREMENT = 1;  
   
   
   set v_Reseller_Id_Out = '';  
   
   while v_count <= v_tcount DO
      set v_Res_role = '';
      set v_parent_reseller_id = Resller_id;
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   
      select IFNULL(a.Fk_Reseller_Id,0) INTO Resller_id from Reseller a
      join Reseller_role c on a.fk_role_id = c.Pk_role_id where a.Reseller_id = Resller_id    LIMIT 1;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
      
      if IFNULL(Resller_id,0) = 0 
      then
         set v_count = v_tcount;
      end if;
      
      if IFNULL(Resller_id,0) <> 0 
      then
  
         SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
         select   b.role_name INTO v_Res_role from Reseller a
         join Reseller_role b on a.fk_role_id = b.Pk_role_id where a.Reseller_id = Resller_id    LIMIT 1;
         SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
         
         insert into tt_temp_reseller_info(reseller_id,parent_reseller_id,reseller_role)
		 values(v_parent_reseller_id,Resller_id,v_Res_role);
      end if;
      set v_count = v_count+1;
   END WHILE;  
   
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select reseller_id,parent_reseller_id,reseller_role from tt_temp_reseller_info
   order by id asc;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
   
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_reseller_get_chain_info_new` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_reseller_get_chain_info_new`(Resller_id INT)
begin
 
    DECLARE v_count INT;   
    DECLARE v_tcount INT;   
    DECLARE v_Reseller_Id_Out VARCHAR(150);  
    DECLARE v_Reseller_ID_Val INT;   
    DECLARE v_Res_role VARCHAR(50);  
    DECLARE v_parent_reseller_id INT;   
    
    set v_count = 1;  
    set v_tcount = 500;  
   
   
    DROP  TABLE IF EXISTS tt_temp_reseller_info;  
    create  table tt_temp_reseller_info
    (
       id INT   AUTO_INCREMENT PRIMARY KEY,
       reseller_id INT,
       parent_reseller_id INT,
       reseller_role VARCHAR(250)
    )  AUTO_INCREMENT = 1;  
    
    
    set v_Reseller_Id_Out = '';  
    
    while v_count <= v_tcount DO
       set v_Res_role = '';
       set v_parent_reseller_id = Resller_id;
       SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    
       select IFNULL(a.Fk_Reseller_Id,0) INTO Resller_id from Reseller a
       join Reseller_role c on a.fk_role_id = c.Pk_role_id where a.Reseller_id = Resller_id    LIMIT 1;
       SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
       
       if IFNULL(Resller_id,0) = 0 
       then
          set v_count = v_tcount;
       end if;
       
       if IFNULL(Resller_id,0) <> 0 
       then
   
          SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
          select   b.role_name INTO v_Res_role from Reseller a
          join Reseller_role b on a.fk_role_id = b.Pk_role_id where a.Reseller_id = Resller_id    LIMIT 1;
          SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
          
          insert into  tt_temp_reseller_info(reseller_id,parent_reseller_id,reseller_role)
 		 values(v_parent_reseller_id,Resller_id,v_Res_role);
       end if;
       set v_count = v_count+1;
    END WHILE;  
    
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    
   
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
     
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_Reseller_get_commison_tier` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_Reseller_get_commison_tier`(
     Reseller_Id INT, 
     Tier_id INT)
BEGIN
    
     
        DECLARE v_Fk_Reseller_Id INT;
        DECLARE v_role_id INT; 
        declare v_out_zero_handle int;
        declare v_out_double_handle double default 0;
        
        set v_out_zero_handle = 0;
     
        IF Reseller_Id is null then
           set Reseller_Id = 0;
        END IF;
        IF Tier_id is null then
           set Tier_id = 0;
        END IF;
        SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        select   IFNULL(Fk_Reseller_Id,v_out_zero_handle), fk_role_id INTO v_Fk_Reseller_Id,v_role_id from Reseller a where a.Reseller_id = Reseller_Id    LIMIT 1;
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
     	
        set Reseller_Id = IFNULL(Reseller_Id,v_out_zero_handle);
     	
        if IFNULL(v_Fk_Reseller_Id,v_out_zero_handle) = 0 then
           set v_Fk_Reseller_Id = Reseller_Id;
        end if;
     
        
        SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        SELECT Tier_Id,Tier_Name,Tier_min,Tier_To,IFNULL(Commission,v_out_double_handle) as Commission,
     			 cast(Create_By as signed ) AS Create_By,
                Status,
     			case when v_role_id <> 1 then subsreseller_tier_commisson(Reseller_Id,Tier_min,Tier_To) ELSE v_out_zero_handle END as sub_commisson,
     			case when v_role_id <> 1 then subsreseller_get_tier_Id(Reseller_Id,Tier_min,Tier_To) ELSE v_out_zero_handle END as Sub_Com_Tier_ID 
                from sme_Reseller_Tier a 
        where ((Reseller_Id = 0) or (a.Create_By = v_Fk_Reseller_Id))
        and ((Tier_id = 0) or (a.Tier_id = Tier_id))
        order by Tier_Id asc;
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ; 
        
     END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_reseller_get_company_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_reseller_get_company_info`(
	Reseller_ID INT,  
	comp_name VARCHAR(20),  
	city VARCHAR(20),  
	email VARCHAR(30),  
	Pk_rs_cmpid INT,  
	Plan_id VARCHAR(4),  
	Subscription_Type VARCHAR(3),  
	Member_Type VARCHAR(3),  
	member_status VARCHAR(3)
)
BEGIN
                
    		DECLARE v_admin_id INT;  
    		DECLARE v_default int;
    		DECLARE v_default_char varchar(125);
    		DECLARE v_default_one int;
    		DECLARE v_sub_type_one varchar(125);
    		set v_default=0;
    		set v_default_char='';
    		set v_default_one=1;
    		set v_sub_type_one=null;
      
    		IF Reseller_ID is null then	set Reseller_ID = 0; END IF;
    		IF Pk_rs_cmpid is null then set Pk_rs_cmpid = 0; END IF;
    		IF Plan_id is null then set Plan_id = ''; END IF;
    		IF Subscription_Type is null then	set Subscription_Type = '';END IF;
    		IF Member_Type is null then set Member_Type = ''; END IF;
    		IF member_status is null then	set member_status = '';END IF;
    		SET v_admin_id = 1005;  
    
    		drop TEMPORARY table IF EXISTS tt_reseller_list;  
    		create TEMPORARY table tt_reseller_list
    		(
    		reseller_id INT
    		);  
    
                
                CALL sme_reseller_get_subordinates_list_new (Reseller_ID);
               
               
               insert into tt_reseller_list 
               select a.reseller_id from tt_new_reseller_id a;
                
                SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    			select b.reseller_id ,a.Title,a.first_name as Firstname,a.last_name as Lastname,a.Pk_rs_cmpid as Comapny_Id,a.Company_name,CONCAT(b.Firstname,'-',CAST(b.Reseller_id AS CHAR(30))) AS Created_by,a.mobileno,
    					a.Email,a.City,Case when a.status = 1 then 'ACTIVE' ELSE 'INACTIVE' END AS Comp_Status,a.Create_date,c.Contact_name as Emg_contact_name,c.Address1 as Emg_Address1,c.Address2 as Emg_Address2,c.State as Emg_State,
    					c.City as Emg_City,c.Country as Emg_Country,c.Phone_No as Emg_Phone_No,c.Email_Id as Emg_Email,IFNULL(c.postcode,v_default_char) as Emg_Zip_code,a.address_1 as Cmpny_address_1,a.address_2 as Cmpny_address_2,
    					a.state as Cmpny_state,a.zip_code as Cmpny_zip_code,a.Country as Cmpny_country,a.phone as Cmpny_phone,a.mobileno as Cmpny_mobile,a.email as Cmpny_email,m.role_name as Rolename,cd.plan,
    					cd.plan_ind_amount as plan_amount,cast(a.plan_Billing_cycle as CHAR(30)) as Billing_cycle, v_sub_type_one as Subscription_type,
    					case when IFNULL(a.free_trail,v_default_one) = 1 then 'Free' else 'Paid' end as Subscription_Type,cast(IFNULL(plan_id,v_default) as signed) as plan_id,l.status as member_status ,a.status as company_status_id,
    					IFNULL(a.Vpcp_Company_Id,v_default) as comp_id,case when IFNULL(a.Vpcp_Company_Id,v_default) > 0 then 'Deal Completed' else 'Deal Created' end as deal_status,IFNULL(a.Hubspot_companyid,v_default) as Hubspot_companyid,
    					IFNULL(a.Hubspot_contactid,v_default)  as Hubspot_contactid,case when IFNULL(a.paid_reference,v_default_char) <> '' then v_default_one else v_default end as paid_status,IFNULL(cnt_ref_id,v_default) as cnt_ref_id,
    					IFNULL(a.Ref_Lead_id,v_default) AS lead_id,cd.no_of_user_purchase as no_of_users,cd.tot_discount as discount,cd.tot_tax_fee,cd.tot_charge as total_amount,tm.Type_of_plan,tm.Custom_status,
                      cd.discount_no_of_month,cd.Discount_remark,a.dept_id,concat(rc.first_name,' ',rc.last_name) as login_user_name,tm.product_id
    			from reseller_company a 
    			inner join Reseller b on a.reseller_id = b.Reseller_id 
    			left join Reseller_Comp_Emg_info c on a.Pk_rs_cmpid = Fk_Pk_rs_cmpid
    			left join Res_Comp_Device_Order cd on a.Pk_rs_cmpid = cd.Fk_rs_cmpid and b.reseller_id = cd.Fk_Resller_Id
    			LEFT JOIN Reseller_status_ref l on b.Status = l.status_id
    			LEFT JOIN Reseller_role m on b.fk_role_id = m.Pk_role_id
 			LEFT JOIN wtms.wtms_copy_of_tier_management_temp tm on a.plan_id = tm.fk_tier_id
             LEFT JOIN smereseller.sme_reseller_company_admin_user rc on rc.login_id = a.sales_id
    			where ((Reseller_ID = 0) or (Reseller_ID = v_admin_id) or (b.Reseller_id in(select ccc.reseller_id from tt_reseller_list ccc)))
    			and ((IFNULL(Pk_rs_cmpid,v_default) = 0) or (a.Pk_rs_cmpid = Pk_rs_cmpid))
    			and ((IFNULL(comp_name,'') = '') or (a.Company_name like CONCAT_WS('','%',comp_name,'%')))
    			and ((IFNULL(city,'') = '') or (a.City like CONCAT_WS('','%',city,'%')))
    			and ((IFNULL(email,'') = '') or (a.Email like CONCAT_WS('','%',email,'%')))
    			and ((IFNULL(Plan_id,v_default) = '' or(a.plan_id = Plan_id) or IFNULL(Plan_id,v_default) = 0))
    			and ((IFNULL(Subscription_Type,'') = '') or(a.free_trail = Subscription_Type))
    			and ((IFNULL(Member_Type,'') = '') or(m.Pk_role_id = Member_Type))
    			and ((IFNULL(member_status,'') = '') or(a.status = member_status))
    			order by a.create_date desc;
                SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
                
             END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_reseller_get_company_manage_order` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_reseller_get_company_manage_order`(Reseller_id INT)
BEGIN

  
   IF Reseller_id is null then
      set Reseller_id = 0;
   END IF;
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select c.Order_Id,a.company_name,a.reseller_id,IFNULL(Pay_Reference,'') as Pay_Reference,
 Case when Pay_Status = 'Success' then 'Payment Completed'
   else 'Waiting For Payment' end as pay_status,IFNULL(b.Pay_Amount,tot_charge) AS Pay_Amount,cc_number,Vpcp_Company_Id,
 a.Pk_rs_cmpid as res_comapany_Id,c.tot_phone_charge,c.tot_discount,c.tot_tax_fee,c.plan_charge,c.Number_charge,
 IFNULL(c.Shipping_charge,0) as Shipping_charge
   from reseller_company a 
   LEFT join Reseller_Payment_Info b on a.Pk_rs_cmpid = b.Res_Comp_Id
   LEFT JOIN Res_Comp_Device_Order c on a.Pk_rs_cmpid = c.Fk_rs_cmpid
   where ( (Reseller_id = 0)  or (a.reseller_id = Reseller_id));
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
   
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_reseller_get_deal_creation` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_reseller_get_deal_creation`(
  	reseller_id int
  	,company_id int
  	,p_FromDate date
  	,p_ToDate date
   )
Begin
             
            	DECLARE v_FromDate		date;
            	DECLARE v_ToDate		date;
               
               if p_FromDate = 0 then SET v_FromDate = IFNULL(p_FromDate,'1900-01-01'); end if;
               if p_ToDate = 0 then SET v_ToDate = IFNULL(p_ToDate,NOW()); end if;
                
                SET v_FromDate = IFNULL(p_FromDate,'1900-01-01');
                SET v_ToDate = IFNULL(p_ToDate,NOW());
                  
			select 	dc.comp_user_id,dc.reseller_id,
			
					vc.company_name,vc.company_id,
					b.Email,e.tier_name as plan_name,
					a.tot_discount as discount,
					a.discount_no_of_month as discount_of_month,a.Duration,a.tot_charge,dc.payment_link,dc.hubspot_contact_id,dc.id,approve1_user_id,approve1_status,approve1_comments,approve2_user_id,
					approve2_status,approve2_comments,approve2_created_date,a.Users,a.Duration,a.plan_ind_amount,approve1_created_date,dc.create_date,dc.status,b.Hubspot_contactid,a.Discount_remark,
					dc.create_by,case when b.plan_Billing_cycle = 1 then e.platform_fee else e.platform_fee_year end as platform_fee,
					e.pro_user_count, dc.approve3_user_id,dc.approve3_status, dc.approve3_comments,dc.approve3_created_date,b.dept_id,concat(rc.first_name,' ',rc.last_name) as login_user_name,
					smereseller.getdealapprovalusername(approve1_user_id) as approve1_user_name,
					smereseller.getdealapprovalusername(approve2_user_id) as approve2_user_name,
					smereseller.getdealapprovalusername(approve3_user_id) as approve3_user_name,             
					a.setup_discount,a.setup_price as setup_fees,e.Installation_cost as plan_setup_fees,
					a.platform_user_fee, a.platform_user_count,r.partner_type,concat(r.Firstname,' ',r.Lastname) as reseller_user_name,dc.payment_method,dc.payment_days,e.product_id,r.Email as reseller_Email
			from smereseller.Res_company_deal_creation dc 
			join smereseller.Res_Comp_Device_Order a on dc.reseller_id = a.Fk_Resller_Id 
			join smereseller.reseller_company b on a.Fk_rs_cmpid = b.Pk_rs_cmpid and b.cnt_ref_id=dc.comp_user_id and b.reseller_id = dc.reseller_id
			left join wtms.wtms_copy_of_tier_management_temp e on dc.tier_id = e.fk_tier_id
			left join sme_reseller_company_admin_user rc on rc.login_id = b.sales_id
			left join smereseller.Reseller r on r.Reseller_id = dc.reseller_id
			LEFT JOIN unifiedring.UR_ECom_User_Dtl eu on eu.UR_ECom_Id = dc.comp_user_id
			LEFT JOIN unifiedring.UR_ECom_Payment_Dtl ep on eu.UR_ECom_Id = ep.Usr_Id
			LEFT JOIN unifiedring.UR_ECom_Company ec on ep.Usr_Id = ec.Comp_ContactId
			LEFT JOIN unifiedring.vbcp_company vc on ec.Comp_Id = vc.eshop_comp_id
			where (dc.reseller_id = reseller_id or ifnull(reseller_id,0) =0)
			and ((dc.comp_user_id= company_id  or ifnull(company_id,0)=0))
			
			order by dc.id desc ;

            End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_reseller_get_feature_detail` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_reseller_get_feature_detail`(
Feature_hdr int,
Feature_idx int
)
BEGIN
	
    if Feature_hdr is null then set Feature_hdr = 0; end if;
    if Feature_idx is null then set Feature_idx = 0; end if;
    
	call unifiedring.UTMS_get_feature_master_info (Feature_hdr, Feature_idx);
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_reseller_get_incentive_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_reseller_get_incentive_info`(
Reseller_ID INT)
BEGIN


	
	
   DECLARE v_role_id INT;
	
	 
   IF Reseller_ID is null then
      set Reseller_ID = 0;
   END IF;
   DROP TEMPORARY TABLE IF EXISTS tt_subreseller;
   CREATE TEMPORARY TABLE tt_subreseller
   (
      reseller_id INT
   );
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   a.fk_role_id INTO v_role_id from Reseller a 
   join Reseller_role b on a.fk_role_id = b.Pk_role_id where a.Reseller_id = Reseller_ID    LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

   if v_role_id in(2,3) then
	
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      insert into tt_subreseller(reseller_id)
      select Fk_Reseller_Id from Reseller where Fk_Reseller_Id = Reseller_ID;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
      insert into tt_subreseller(reseller_id)
		values(Reseller_ID);
   end if;
		
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   SELECT a.Reseller_Id,b.Firstname,b.Lastname,Total_Purchase_amount,Comm_amount,
	Comm_per,parent_Reseller_id,Reseller_level,b.Country,b.City,b.Zipcode,b.Mobile,
	case when a.status = 1 then 'No' else 'Yes' end as commisson_paid FROM Reseller_commisson_info a 
   join Reseller b on a.Reseller_Id = b.Reseller_id
   where ((Reseller_ID = 0) or (a.Reseller_Id = Reseller_ID) or (v_role_id = 2 and a.Reseller_Id in(select reseller_id from tt_subreseller)))
   order by a.Reseller_Id asc,a.Reseller_level asc;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_Reseller_get_KYC_dtls` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_Reseller_get_KYC_dtls`(Reseller_Id INT)
BEGIN
 declare v_int_default int ;
 set v_int_default=0;
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    Select Reseller_Id,IFNULL(Bank_Name,'') as Bank_Name,IFNULL(Branch,'') as Branch,IFNULL(IFSC,'') as IFSC,IFNULL(Account_Number,'') as Account_Number,
  IFNULL(Acc_Holder_Name,'') as Account_Holder_Name, Account_Type,IFNULL(Status,v_int_default) as Status,KYC_id,IFNULL(Country,'') as Country,IFNULL(City,'') as City,
  IFNULL(Sort_code,'') as Sort_code, IFNULL(BIC_number,'') as BIC_number from Reseller_Bank_KYC_Info  a where a.Reseller_Id = Reseller_Id;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;     
      
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_reseller_get_lead_by_employee` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_reseller_get_lead_by_employee`(
 reseller_id INT,
 Lead_id INT)
BEGIN
 
 	
    IF Lead_id is null then
       set Lead_id = 0;
    END IF;
    
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    Select a.Lead_id,Hubspot_contactd,First_name,Last_name,
 	Email_id,Phone_number,address1,street_address,city,post_code,country,industry,company_name,
 	company_domain,contact_owner,Employeee_count,Lead_createdate,Lead_source,status
    from Reseller_Lead_details a
    where a.Fk_Reseller_id = reseller_id
    and ((Lead_id = 0) or  (a.Lead_id = Lead_id))
    and   a.status = 0;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_reseller_get_license_based_config_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_reseller_get_license_based_config_info`(
p_reseller_id int,
p_plan_id INT,
p_duration int,
p_product_id int
)
Begin

	SET group_concat_max_len = 1000000;
    
    

	select b.tier_name,CC.id, CC.reseller_id, CC.plan_id, CC.duration, CC.user_price, CC.discount_user_price, CC.platform_fee, CC.discount_platform_fee, CC.setup_fee, CC.discount_setup_fee, CC.product_id, CC.create_date, CC.is_active,
		CONCAT('[',(SELECT 
				group_concat(JSON_OBJECT('tier_id',b.tier_id,'platform_fee_name', b.platform_fee_name,
				'platform_fee_month_price',b.platform_fee_month_price, 'platform_fee_month_discount_price',b.platform_fee_month_discount_price, 'platform_fee_yearly_price',b.platform_fee_yearly_price,
				'platform_fee_yearly_discount_price',b.platform_fee_yearly_discount_price, 'platform_fee_count',b.platform_fee_count)) as Z
		FROM reseller_license_based_platform_fee_json_dtl b 
		left join reseller_license_based_config_dtl a on a.reseller_id = b.reseller_id and a.plan_id = b.tier_id and a.product_id = b.product_id
		where b.reseller_id = p_reseller_id and b.product_id = CC.product_id and a.duration = CC.duration and (a.plan_id = CC.plan_id)
		group by b.tier_id
		),']' )as platform_fee_json_info
	from reseller_license_based_config_dtl CC
    join wtms.wtms_copy_of_tier_management_temp b on CC.plan_id = b.fk_tier_id
    where CC.reseller_id = p_reseller_id and (plan_id = p_plan_id or ifnull(p_plan_id,0)=0) and (duration = p_duration or ifnull(p_duration,0)=0) and (CC.product_id = p_product_id or ifnull(p_product_id,0)=0);
    
    
    
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_reseller_get_members_view_performance_commission_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_reseller_get_members_view_performance_commission_info`(reseller_id INT,
 Pk_role_id INT,
 date_range_id INT)
Begin
 	
    DECLARE now DATETIME(3);
    DECLARE date_range VARCHAR(50);
    DECLARE inactive_companies INT;
 
    IF reseller_id is null then 		set reseller_id = 0; 		END IF;
    IF Pk_role_id is null then 		set Pk_role_id = 0; 		END IF;
    IF date_range_id is null then 	set date_range_id = ''; 	END IF;
    set now = STR_TO_DATE(DATE_FORMAT(CURRENT_TIMESTAMP,'%Y-%m-%d'),'%Y-%m-%d');
 	
    If date_range_id = 1 then		set date_range = now; 						end if;
    If date_range_id = 2 then		set date_range = now;						end if;
    If date_range_id = 3 then		set date_range = TIMESTAMPADD(day,-1,now);	end if;
    If date_range_id = 4 then		set date_range = TIMESTAMPADD(day,-8,now);	end if;
    If date_range_id = 5 then		set date_range = TIMESTAMPADD(day,-15,now);	end if;
    If date_range_id = 6 then		set date_range = TIMESTAMPADD(day,-31,now);	end if;
    If date_range_id in(7,'') then	set date_range = '';						end if;
 		
         
 	drop TEMPORARY table IF EXISTS tt_reseller_listA;
 	create TEMPORARY table tt_reseller_listA
    (
       reseller_id INT
    );
    
    drop TEMPORARY table IF EXISTS tt_reseller_listB;
 	create TEMPORARY table tt_reseller_listB
    (
       reseller_id INT
    );
 
 
    CALL sme_reseller_get_subordinates_list_new(reseller_id);	
    
 	insert into tt_reseller_listA(reseller_id)
 	select a.reseller_id from tt_new_reseller_id a;
    
     	insert into tt_reseller_listB(reseller_id)
 	select a.reseller_id from tt_new_reseller_id a;
 
    If date_range_id <> 3 then
 
       SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
       select Distinct a.reseller_id as reseller_id,
 			(CONCAT(a.Firstname,' ',a.lastname)) as member_name,
 			b.role_name as member_type,
 			IFNULL(a.fixed_inc_per,0)+IFNULL(a.var_inc_per,0) as comm_current_percentage,
 			ur_get_reseller_commission(a.reseller_id,3) as comm_earned,
 			ur_get_reseller_commission(a.reseller_id,4) as my_commission,
 			ur_get_reseller_count(a.reseller_id,6) as act_comp_with_commission,
 			ur_get_reseller_count(a.reseller_id,7) as act_comp_without_commission,
 			ur_get_reseller_count(a.reseller_id,5) as inactive_companies
       from Reseller a 
       left join reseller_company rc  on a.reseller_id = rc.Reseller_id
       LEFT JOIN Reseller_role b  on a.fk_role_id = b.Pk_role_id
       LEFT JOIN Reseller_status_ref l on a.Status = l.status_id
       where
 	(((a.reseller_id in(select r.reseller_id from tt_reseller_listA r) or a.reseller_id = reseller_id) or IFNULL(reseller_id,0) = 0)
       OR ((a.Fk_Reseller_Id in(select rs.reseller_id from tt_reseller_listB rs) or a.Fk_Reseller_Id = reseller_id) or IFNULL(reseller_id,0) = 0))
       AND((Pk_role_id = 0) or (a.fk_role_id = Pk_role_id)) and
 			((date_range = '') or cast(rc.create_date as DATE) between cast(date_range as DATE) and cast(now as DATE));
       SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
    Else
       SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
       select Distinct a.reseller_id as reseller_id,
 			(CONCAT(a.Firstname,' ',a.lastname)) as member_name,
 			b.role_name as member_type,
 			IFNULL(a.fixed_inc_per,0)+IFNULL(a.var_inc_per,0) as comm_current_percentage,
 			ur_get_reseller_commission(a.reseller_id,3) as comm_earned,
 			ur_get_reseller_commission(a.reseller_id,4) as my_commission,
 			ur_get_reseller_count(a.reseller_id,6) as act_comp_with_commission,
 			ur_get_reseller_count(a.reseller_id,7) as act_comp_without_commission,
 			ur_get_reseller_count(a.reseller_id,5) as inactive_companies
       from Reseller a 
       left join reseller_company rc  on a.reseller_id = rc.Reseller_id
       LEFT JOIN Reseller_role b  on a.fk_role_id = b.Pk_role_id
       LEFT JOIN Reseller_status_ref l	 on a.Status = l.status_id
       where
 	(((a.reseller_id in(select rsl.reseller_id from tt_reseller_listA rsl) or a.reseller_id = reseller_id) or IFNULL(reseller_id,0) = 0)
       OR ((a.Fk_Reseller_Id in(select rsll.reseller_id from tt_reseller_listB rsll) or a.Fk_Reseller_Id = reseller_id) or IFNULL(reseller_id,0) = 0))
       AND((Pk_role_id = 0) or (a.fk_role_id = Pk_role_id)) and
 			((date_range = '') or cast(rc.create_date as DATE) between cast(date_range as DATE) and cast(date_range as DATE));
       SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
    end if;
 
    drop TEMPORARY table IF EXISTS tt_reseller_listA;
    drop TEMPORARY table IF EXISTS tt_reseller_listB;
 
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_reseller_get_members_view_performance_new_Company_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_reseller_get_members_view_performance_new_Company_info`(
    reseller_id INT,
    Pk_role_id INT,
    date_range_id INT)
Begin
    	
       DECLARE v_now DATETIME(3);
       DECLARE v_date_range VARCHAR(50);
       DECLARE v_created_count INT;
       DECLARE v_freetrail_count INT;
       DECLARE v_paid_subs_count INT;
       DECLARE v_active_count INT;
       DECLARE v_inactive_count INT;
       
       IF reseller_id is null then set reseller_id = 0; END IF;
       IF Pk_role_id is null then set Pk_role_id = 0; END IF;
       IF date_range_id is null then set date_range_id = ''; END IF;
       
       set v_now = STR_TO_DATE(DATE_FORMAT(CURRENT_TIMESTAMP,'%Y-%m-%d'),'%Y-%m-%d');
    
       If date_range_id = 1 then	set v_date_range = v_now; end if; 
       If date_range_id = 2 then	set v_date_range = v_now; end if;
       If date_range_id = 3 then	set v_date_range = TIMESTAMPADD(day,-1,v_now); end if;
       If date_range_id = 4 then	set v_date_range = TIMESTAMPADD(day,-8,v_now); end if;
       If date_range_id = 5 then	set v_date_range = TIMESTAMPADD(day,-15,v_now); end if;
       If date_range_id = 6 then	set v_date_range = TIMESTAMPADD(day,-31,v_now); end if;
       If date_range_id in(7,'') then set v_date_range = ''; end if;
    	
 		drop temporary table if exists tt_reseller_list1;
 		drop temporary table if exists tt_reseller_list12;
 
 		drop table IF EXISTS tt_reseller_list; create table tt_reseller_list (reseller_id INT primary key);
 		drop  table IF EXISTS tt_reseller_list1;create  table tt_reseller_list1 (reseller_id INT primary key);
 		drop  table IF EXISTS tt_reseller_list12; create  table tt_reseller_list12(reseller_id INT primary key);
 
 		CALL sme_reseller_get_subordinates_list_new(reseller_id);
 
 		insert into tt_reseller_list(reseller_id)
 		select z.reseller_id from tt_new_reseller_id z;
       
       create temporary table tt_reseller_list1 as select a.reseller_id from tt_reseller_list a;
       create temporary table tt_reseller_list12 as select b.reseller_id from tt_reseller_list1 b;
    
       if date_range_id <> 3 then
 			 SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
 				select Distinct a.reseller_id as reseller_id,(CONCAT(a.Firstname,' ',a.lastname)) as member_name,b.role_name as member_type,ur_get_reseller_count(a.reseller_id,1) as created,
 								ur_get_reseller_count(a.reseller_id,2) as free_trails_count,ur_get_reseller_count(a.reseller_id,3) as paid_subscription_count,ur_get_reseller_count(a.reseller_id,4) as active_count,
 								ur_get_reseller_count(a.reseller_id,5) as inactive_count,null as expired_count
 				from Reseller a 
 				left join reseller_company rc on a.reseller_id = rc.Reseller_id
 				LEFT JOIN Reseller_role b on a.fk_role_id = b.Pk_role_id
 				LEFT JOIN Reseller_status_ref l	on a.Status = l.status_id
 				where (((a.reseller_id in(select reseller_id from tt_reseller_list1) or a.reseller_id = reseller_id) or IFNULL(reseller_id,0) = 0)
 				OR ((a.Fk_Reseller_Id in(select reseller_id from tt_reseller_list) or a.Fk_Reseller_Id = reseller_id) or IFNULL(reseller_id,0) = 0))
 				AND ((Pk_role_id = 0) or (a.fk_role_id = Pk_role_id))
 				and ((v_date_range = '') or cast(rc.create_date as DATE) between cast(v_date_range as DATE) and cast(v_now as DATE));
 			 SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 		ELSE
 			SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
 				select Distinct	a.reseller_id as reseller_id,(CONCAT(a.Firstname,' ',a.lastname)) as member_name,b.role_name as member_type,ur_get_reseller_count(a.reseller_id,1) as created,
 								ur_get_reseller_count(a.reseller_id,2) as free_trails_count,ur_get_reseller_count(a.reseller_id,3) as paid_subscription_count,ur_get_reseller_count(a.reseller_id,4) as active_count,
 								ur_get_reseller_count(a.reseller_id,5) as inactive_count,null as expired_count
 				from Reseller a 
 				left join reseller_company rc on a.reseller_id = rc.Reseller_id
 				LEFT JOIN Reseller_role b on a.fk_role_id = b.Pk_role_id
 				LEFT JOIN Reseller_status_ref l	on a.Status = l.status_id
 				where (((a.reseller_id in(select reseller_id from tt_reseller_list12) or a.reseller_id = reseller_id) or IFNULL(reseller_id,0) = 0)
 				OR ((a.Fk_Reseller_Id in(select reseller_id from tt_reseller_list) or a.Fk_Reseller_Id = reseller_id) or IFNULL(reseller_id,0) = 0))
 				AND ((Pk_role_id = 0) or (a.fk_role_id = Pk_role_id))
 				and ((v_date_range = '') or cast(rc.create_date as DATE) between cast(v_date_range as DATE) and cast(v_date_range as DATE));
 			SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
       end if;
 drop table IF EXISTS tt_reseller_list;
    End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_reseller_get_member_admin_submission_list` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_reseller_get_member_admin_submission_list`(role_Id INT)
begin

declare v_default_value int ;
set v_default_value=0;
   
    IF role_Id is null then
       set role_Id = 0;
    END IF;
       drop TEMPORARY table IF EXISTS tt_temp;  
    create TEMPORARY table tt_temp
    (
       reseller_id INT,
       member_name VARCHAR(300),
       member_type VARCHAR(300),
       parent_reseller_name VARCHAR(300),
       Phone VARCHAR(100),
       Mobile VARCHAR(100),
       Email VARCHAR(200),
       create_date VARCHAR(120),
       status INT,
       Status_name VARCHAR(300),
       Role_Id INT,
       calledby VARCHAR(10)
    );  
   
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    insert into tt_temp(reseller_id,member_name,member_type,parent_reseller_name,Phone,Mobile,email,create_date,status,Status_name,Role_Id,calledby)
    SELECT a.reseller_id as reseller_id,
    (CONCAT(a.Firstname,' ',a.lastname)) as member_name,
    m.role_name as member_type,
    case when fk_role_id = 2 then '-' else
       IFNULL(parent_reseller_name(a.Fk_Reseller_Id),'') end as parent_reseller_name,
    IFNULL(a.Phone,'') as Phone,
    IFNULL(a.Mobile,'') as Mobile,
    IFNULL(a.Email,'') as Email,
    a.create_date as create_date,
    a.status as status,
    case when a.status = 0 then 'Rejected' when a.status = 1 then 'Approved' when a.status = 4 then 'Pending' end as Status_name,
    IFNULL(a.fk_role_id,v_default_value) as Role_Id,
    calledby
    from Reseller a  
    LEFT JOIN Reseller_status_ref l on a.Status = l.status_id
    LEFT JOIN Reseller_role m on a.fk_role_id = m.Pk_role_id
    where  
   ((role_Id = '') or (a.fk_role_id = role_Id))  
   
    and (role_Id in(2,3,4,5) and a.status = 1 and (a.fk_role_id = role_Id or (role_Id = ''))
    or (role_Id in(3,4,5) and a.status in(0) and (a.fk_role_id = role_Id) or (role_Id = '')))
    order by a.reseller_id desc;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
     
    select reseller_id,member_name,member_type,parent_reseller_name,Phone,Mobile,email,create_date,status,Status_name,Role_Id
    from tt_temp where
   ((role_id = 2 and calledby = 'web' and status = 1 or status is null) or
   (role_id in(3,4,5,6) and status in(1,0)) or
   (role_id = 2 and calledby = 'admin' and (status in(1,0) or status is null)));  
     
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_reseller_get_my_commissions_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_reseller_get_my_commissions_info`(Reseller_Id INT)
Begin

   DECLARE v_errcode INT;  
   DECLARE v_errmsg VARCHAR(50);  
   DECLARE v_now DATETIME(3);  
   DECLARE v_total_purchase_amount FLOAT;
   DECLARE v_comm_per FLOAT;
   DECLARE v_Comm_amount FLOAT;
   DECLARE v_Comm_date DATETIME(3);  
   DECLARE v_Fixed_inc_per FLOAT;
   DECLARE v_var_inc_per FLOAT;
   DECLARE v_Inc_Tier_Type INT;
   
  
   sp_exit:BEGIN
   
      If not exists(select  1 from Reseller a where a.reseller_id = Reseller_Id LIMIT 1) 
      then 
         set v_errcode = 0;
         set v_errmsg = 'reseller not found.';
         LEAVE sp_exit;
      end if;
      
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      SET v_comm_per =(select Distinct IFNULL(fixed_inc_per,0)+IFNULL(var_inc_per,0) from Reseller a 
      where a.Reseller_Id = Reseller_Id);
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      SET v_total_purchase_amount =(select IFNULL(sum(total_purchase_amount),0) from Reseller_commisson_info b 
      where b.Reseller_Id = Reseller_Id);
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      SET v_Comm_date =(select  Comm_date from Reseller_commisson_info b where b.Reseller_Id = Reseller_Id LIMIT 1);
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      SET v_Comm_amount =(select IFNULL(sum(my_comm),0) from Reseller_commisson_info b where b.Reseller_Id = Reseller_Id);
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select  a.reseller_id as reseller_id,
   v_total_purchase_amount total_amount_credited,
   v_comm_per Total_commission_earned,
   v_Comm_amount my_commision,
   null as balance_to_be_credited,
   v_Comm_date as last_payment_date
      from Reseller a   
      where (a.reseller_id = Reseller_Id or IFNULL(Reseller_Id,0) = 0)
      order by a.Create_date desc LIMIT 1;
      
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
      
      If found_rows() > 0 
      then 
         set v_errcode = 0;
         set v_errmsg = 'success';
      end if;
   END;
   select v_errcode as errcode,v_errmsg as errmsg;  
  
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_reseller_get_plan_drp` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_reseller_get_plan_drp`(Reseller_ID INT)
BEGIN

  
   
   
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   SELECT Pln_Idx,Pln_Name FROM unifiedring.UR_ECom_Plan
   WHERE Pln_Code like 'R%'
   ORDER BY Pln_Seq ASC;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
   
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_reseller_get_plan_info_list` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_reseller_get_plan_info_list`(
 Reseller_id INT,
 Product_ID	INT,
 Plan_id INT,
 is_tms_flag INT,
 plan_type INT)
Begin
 
 
    IF Product_ID is null then
       set Product_ID = 0;
    END IF;
    IF Plan_id is null then
       set Plan_id = 0;
    END IF;
    IF is_tms_flag is null then
       set is_tms_flag = 0;
    END IF;
    CALL unifiedring.sme_reseller_get_plan_info_list(Reseller_id,Product_ID,Plan_id,is_tms_flag,plan_type);
 
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_reseller_get_plan_type` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_reseller_get_plan_type`(plan_name VARCHAR(250),  duration INT,  OUT plan_Type INT,prod_type_id int)
BEGIN
    
       DECLARE v_plan_id INT;
       DECLARE v_Is_Monthly_Year INT;   
       DECLARE v_yearly_monthly_Duration INT;   
       
      
       
       select a.fk_tier_id INTO v_plan_id from wtms.wtms_copy_of_tier_management_temp a where a.tier_name = plan_name and a.prod_type_id = prod_type_id and is_review = 3 limit 1;
    
       SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
       
      
       
  		select case when c.cop_cont_id = 1 THEN 1 ELSE 2 end,c.cop_cont_id
  		INTO v_Is_Monthly_Year,v_yearly_monthly_Duration  
  		from wtms.wtms_copy_of_tier_management_temp a 
  		inner join wtms.wtms_contract_pricing_dtl b on a.fk_tier_id = b.tier_id
  		inner join wtms.wtms_contract_period_master c on c.cop_id=b.fk_contract_period_id
  		inner join wtms.wtms_no_of_users_master d on b.fk_user_type_id = d.nof_id
  		inner join wtms.wtms_ref_tier_purpose e on a.fk_purpose_id = e.purpose_id
  		where a.fk_tier_id = v_plan_id and a.status =1 and a.is_review=3 
  		and a.tier_name is not null and a.status = 1 and c.cop_cont_id = duration limit 1;
  
       SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
       
       SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
  	
          
          select Typeid INTO plan_Type from reseller_plan_type where Plan_duration = duration and status = 1 limit 1;
       SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
       
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_reseller_get_report_commission_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_reseller_get_report_commission_info`(
   	Reseller_Id INT,  
       member_type INT,
       commission_structure INT,
       date_range_id INT)
begin
       
          DECLARE v_errcode INT;  
          DECLARE v_errmsg VARCHAR(50);  
          DECLARE v_now DATETIME(3);  
          DECLARE v_date_range VARCHAR(50);  
          DECLARE v_revenue_earned FLOAT;
          DECLARE v_commission_per_earned FLOAT;
          DECLARE v_Comm_amount_earned FLOAT;     
          DECLARE v_fix_percentage FLOAT;  
          DECLARE v_varaibel_percenatge INT;   
          DECLARE v_inc_type INT;      
          DECLARE v_role_id INT;
          
          
  		IF Reseller_Id is null  then set Reseller_Id = 0; END IF;
  		IF member_type is null  then set member_type = 0; END IF;
  		IF commission_structure is null  then set commission_structure = 0; END IF;
  		IF date_range_id is null then set date_range_id = ''; END IF;
          
          sp_exit:BEGIN
             
             set v_now = STR_TO_DATE(DATE_FORMAT(CURRENT_TIMESTAMP,'%Y-%m-%d'),'%Y-%m-%d');           
             
  		If date_range_id = 1 then set v_date_range = v_now; end if;
  		If date_range_id = 2 then set v_date_range = v_now; end if;
  		If date_range_id = 3 then set v_date_range = TIMESTAMPADD(day,-1,v_now); end if;
  
  		If date_range_id = 4 then set v_date_range = TIMESTAMPADD(day,-8,v_now); end if;
  		If date_range_id = 5 then set v_date_range = TIMESTAMPADD(day,-15,v_now); end if;
  		If date_range_id = 6 then set v_date_range = TIMESTAMPADD(day,-31,v_now); end if;
  		If date_range_id in(7,'') then set v_date_range = ''; end if;
  
             Drop TEMPORARY table IF EXISTS tt_reseller_list;
             create TEMPORARY table tt_reseller_list
             (
                reseller_id INT
             );
       
       	  drop TEMPORARY table IF EXISTS tt_temp_sum_commission;           
             create TEMPORARY table tt_temp_sum_commission
             (
                reseller_id INT,
                total_purchase_amount FLOAT,
                comm_per FLOAT,
                Comm_amount FLOAT,
                fixed_inc_per FLOAT,
                var_per_comm FLOAT,
                Inc_Tier_Type INT,
                comm_earned FLOAT,
                comm_date DATETIME(3)
             );
             
             
             CALL sme_reseller_get_subordinates_list_new (Reseller_Id);
             
  
             insert into tt_reseller_list select a.reseller_id from tt_new_reseller_id a;
             
             drop TEMPORARY table IF EXISTS tt_reseller_listing;  
             create temporary table tt_reseller_listing as select a.reseller_id from tt_new_reseller_id a;
               
             select a.fk_role_id INTO v_role_id from Reseller a where a.reseller_id = Reseller_Id;  
             
             If not exists(select  1 from Reseller a where a.reseller_id = Reseller_Id LIMIT 1) 
             then 
                set v_errcode = 0;
                set v_errmsg = 'reseller not found.';
                LEAVE sp_exit;
             end if;
               
             select IFNULL(fixed_inc_per,0), IFNULL(var_inc_per,0), IFNULL(Inc_Tier_Type,0) 
             INTO v_fix_percentage,v_varaibel_percenatge,v_inc_type from Reseller a where a.Reseller_id = Reseller_Id limit 1;
     
             insert into tt_temp_sum_commission(reseller_id,total_purchase_amount,comm_per,fixed_inc_per,var_per_comm,Inc_Tier_Type,Comm_amount,comm_earned,comm_date)
             select distinct b.reseller_id,IFNULL(sum(b.total_purchase_amount),0) total_purchase_amount,IFNULL(b.comm_per,0) comm_per,fixed_inc_per,var_per_comm,Inc_Tier_Type,
  							my_comm,case when IFNULL(v_role_id,0) = 2 then sum(IFNULL(Master_mycomm,0))
  						   when IFNULL(v_role_id,0) = 3 then sum(IFNULL(Res_mycomm,0))
  						   when IFNULL(v_role_id,0) = 4 then sum(IFNULL(Master_subres_comm,0)) else 0 end ,comm_date
             from Reseller_commisson_info b
             where Reseller_Id in(select b.reseller_id from tt_reseller_list b)
             and b.comm_assigned_by = 'COMP-PURCHASE'
             group by b.reseller_id,comm_per,fixed_inc_per,var_per_comm,Inc_Tier_Type,my_comm,
             commison_earned,comm_date
             order by b.reseller_id,comm_date;    
             
             If date_range_id <> 3 
             then              
                select 	Distinct a.reseller_id as reseller_id,(CONCAT(a.Firstname,' ',a.lastname)) as Name,
  						b.role_name as member_type,
  						IFNULL(a.Inc_Tier_Type,0) as commission_structure,
  						IFNULL(a.fixed_inc_per,0) as commission_percentage,
  						IFNULL(a.var_inc_per,0) as commission_percentage_var,
  						null as Discount,     
  						cast(IFNULL(sme_reseller_performance_info(a.reseller_id,1),0) as DECIMAL(10,2)) as revenue_earned,     
  						cast(IFNULL(sme_reseller_performance_info(a.reseller_id,2),0) as DECIMAL(10,2)) as commission_earned,     
  						
  						
  						0 as fix_per,0 as var_inc_per
                from Reseller a 
                LEFT JOIN tt_temp_sum_commission tc on a.reseller_id = tc.reseller_id
                LEFT JOIN Reseller_role b  on a.fk_role_id = b.Pk_role_id
                LEFT JOIN Reseller_status_ref l  on a.Status = l.status_id
                where ((a.reseller_id in(select d.reseller_id from tt_reseller_listing d) or a.reseller_id = Reseller_Id) 
                or IFNULL(Reseller_Id,0) = 0) and
          ((v_date_range = '') or cast(a.create_date as DATE) between cast(v_date_range as DATE) and cast(v_now as DATE))
                and (b.Pk_role_id = member_type or member_type = 0);
                
            
                If found_rows() > 0 
                then  
                   set v_errcode = 0;
                   set v_errmsg = 'success';
                end if;
                
             Else
                  
                select 	Distinct a.reseller_id as reseller_id,(CONCAT(a.Firstname,' ',a.lastname)) as Name,
  						b.role_name as member_type,
  						IFNULL(a.Inc_Tier_Type,0) as commission_structure,
  						IFNULL(a.fixed_inc_per,0) as commission_percentage,
  						IFNULL(a.var_inc_per,0) as commission_percentage_var,
  						null as Discount,     
  						cast(IFNULL(sme_reseller_performance_info(a.reseller_id,1),0) as DECIMAL(10,0)) as revenue_earned,     
  						cast(IFNULL(sme_reseller_performance_info(a.reseller_id,3),2) as DECIMAL(10,2)) as commission_earned,     
  						
  						
  						0 as fix_per,0 as var_inc_per
                from Reseller a 
                LEFT JOIN tt_temp_sum_commission tc on a.reseller_id = tc.reseller_id
                LEFT JOIN Reseller_role b  on a.fk_role_id = b.Pk_role_id
                LEFT JOIN Reseller_status_ref l  on a.Status = l.status_id
                where ((a.reseller_id in(select e.reseller_id from tt_reseller_list e) or a.reseller_id = Reseller_Id) 
                or IFNULL(Reseller_Id,0) = 0) and
          ((v_date_range = '') or cast(a.create_date as DATE) between cast(v_date_range as DATE) and cast(v_date_range as DATE))
                and (b.Pk_role_id = member_type or member_type = 0);
                
       
                If found_rows() > 0 
                then  
                   set v_errcode = 0;
                   set v_errmsg = 'success';
                end if;
             end if;	
          END;
          select v_errcode as errcode,v_errmsg as errmsg;  
       end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_reseller_get_reseller_by_comm_breakdown` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_reseller_get_reseller_by_comm_breakdown`(reseller_id int)
Begin
 
 	select a.Reseller_id,b.company_name,round(sum(Total_Purchase_amount),2) as revenue_earned,round(sum(a.Comm_amount),2) as commission_earned,a.Comm_date as create_date,
			concat(c.Firstname,' ',c.Lastname) as Member_Name,
			case when c.fk_role_id = 2 then 'Partner' when c.fk_role_id = 3 then 'Agent' end as Member_type,
			d.product_id as Product_id,d.plan_id,e.tier_name as Plan_purchased,d.plan_duration
 	from smereseller.Reseller_commisson_info a join unifiedring.vbcp_company b on a.Company_Id = b.Company_Id
    join smereseller.Reseller c on a.Reseller_Id = c.Reseller_id
    join unifiedring.ur_company_plan d on a.Company_Id = d.Company_Id
    join wtms.wtms_copy_of_tier_management_temp e on e.fk_tier_id = d.plan_id
 	where a.Reseller_id = reseller_id and a.comm_assigned_by = 'COMP-PURCHASE'
 	group by a.Reseller_id,b.company_name,a.Comm_date,concat(c.Firstname,'',c.Lastname),fk_role_id,product_id,plan_id,tier_name,plan_duration;
 
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_reseller_get_special_bundle_request` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_reseller_get_special_bundle_request`(
Reseller_Id INT,  
Request_id INT)
BEGIN

    
    
   
   DECLARE v_admin INT;  
   IF Reseller_Id is null then
      set Reseller_Id = 0;
   END IF;
   IF Request_id is null then
      set Request_id = 0;
   END IF;
   SET v_admin = 1005;  
   
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   Select Request_id,Reseller_id as Sender_ID,IFNULL(Customer_Name,'') as Customer_Name,IFNULL(Customer_Email,'') as Customer_Email,
IFNULL(Bundle_Type,'') as Base_bundle,IFNULL(Budget,0) as Budget,IFNULL(Customer_requirement,'') as Comments,IFNULL(Admin_comment,'') as Admin_comments,
b.Status from Res_Special_bundle_req_info a  join special_bun_req_status_ref b  on a.Req_status = b.status_id where
((a.Reseller_Id = 0) or (a.Reseller_Id = v_admin) or (a.Reseller_id = Reseller_Id)) and
((Request_id = 0) or (a.Request_id = Request_id));
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_reseller_get_subordinates_list` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_reseller_get_subordinates_list`(reseller_id INT)
begin

     
     drop TEMPORARY table IF EXISTS  tt_t1;  
  
   create TEMPORARY table tt_t1
   (
      reseller_id INT
   );  
   
   

   insert into tt_t1
   select reseller_id from Reseller a where a.reseller_id = reseller_id;  
  
   insert into tt_t1
   select Distinct reseller_id from Reseller a where a.fk_reseller_id in(select Distinct reseller_id from tt_t1)
   and a.reseller_id not in(select Distinct reseller_id from tt_t1);  
  
   insert into tt_t1
   select Distinct reseller_id from Reseller a where a.fk_reseller_id in(select Distinct reseller_id from tt_t1)
   and a.reseller_id not in(select Distinct reseller_id from tt_t1);  
  
   insert into tt_t1
   select Distinct reseller_id from Reseller a where a.fk_reseller_id in(select Distinct reseller_id from tt_t1)
   and a.reseller_id not in(select Distinct reseller_id from tt_t1);  
  
   insert into tt_t1
   select Distinct reseller_id from Reseller a where a.fk_reseller_id in(select Distinct reseller_id from  tt_t1)
   and a.reseller_id not in(select Distinct reseller_id from tt_t1);  
  
   select reseller_id from tt_t1;  

End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_reseller_get_subordinates_list1` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_reseller_get_subordinates_list1`(p_reseller_id INT)
begin

set @query:=concat('drop table if exists tt_t',connection_id());
prepare s from @query;execute s;

set @query:=concat('create table tt_t',connection_id(),'(reseller_id INT,key(reseller_id))');
prepare s from @query;execute s;

set @query:=concat('insert into tt_t',connection_id(),' select a.reseller_id from Reseller a where a.reseller_id = ',p_reseller_id);
prepare s from @query;execute s;

set @query:=concat('insert into tt_t',connection_id(),' select Distinct reseller_id from Reseller B where B.fk_reseller_id in(select Distinct reseller_id from tt_t',connection_id(),') and B.reseller_id not in(select Distinct reseller_id from tt_t',connection_id(),');');
prepare s from @query;execute s;

set @query:=concat('insert into tt_t',connection_id(),' select Distinct reseller_id from Reseller c where c.fk_reseller_id in(select Distinct reseller_id from tt_t',connection_id(),') and c.reseller_id not in(select Distinct reseller_id from tt_t',connection_id(),');');
prepare s from @query;execute s;

set @query:=concat('insert into tt_t',connection_id(),' select Distinct reseller_id from Reseller d where d.fk_reseller_id in(select Distinct reseller_id from tt_t',connection_id(),') and d.reseller_id not in(select Distinct reseller_id from tt_t',connection_id(),');');
prepare s from @query;execute s;

set @query:=concat('insert into tt_t',connection_id(),' select Distinct reseller_id from Reseller e where e.fk_reseller_id in(select Distinct reseller_id from tt_t',connection_id(),') and e.reseller_id not in(select Distinct reseller_id from tt_t',connection_id(),');');
prepare s from @query;execute s;

set @query:=concat('select reseller_id from tt_t',connection_id());
prepare s from @query;execute s;

set @query:=concat('drop table if exists tt_t',connection_id());
prepare s from @query;execute s;

End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_reseller_get_subordinates_list121` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_reseller_get_subordinates_list121`(v_reseller_id INT)
begin
  
		drop TEMPORARY table IF EXISTS  tt_t12;
		drop TEMPORARY table IF EXISTS  tt_t13;
		drop TEMPORARY table IF EXISTS tt_t14;
		drop TEMPORARY table IF EXISTS tt_t15;
		drop TEMPORARY table IF EXISTS tt_t16;
		drop TEMPORARY table IF EXISTS tt_t17;
		drop TEMPORARY table IF EXISTS tt_t18;
		drop TEMPORARY table IF EXISTS tt_t19;
		drop TEMPORARY table IF EXISTS tt_t20;
		drop TEMPORARY table IF EXISTS tt_t21;
		drop TEMPORARY table IF EXISTS tt_t22;
		drop TEMPORARY table IF EXISTS tt_new_reseller_id;
       
     create TEMPORARY table tt_t12
     (
        reseller_id INT
     );

     insert into tt_t12
     select reseller_id from Reseller where reseller_id = v_reseller_id;
  
     CREATE temporary TABLE tt_t13 as  SELECT * FROM tt_t12;
     CREATE temporary TABLE tt_t14 as  SELECT * FROM tt_t13;
     CREATE temporary TABLE tt_t15 as  SELECT * FROM tt_t14;
     CREATE temporary TABLE tt_t16 as  SELECT * FROM tt_t15;
     CREATE temporary TABLE tt_t17 as  SELECT * FROM tt_t16;
     CREATE temporary TABLE tt_t18 as  SELECT * FROM tt_t17;
     CREATE temporary TABLE tt_t19 as  SELECT * FROM tt_t18;
     CREATE temporary TABLE tt_t20 as  SELECT * FROM tt_t19;
     CREATE temporary TABLE tt_t21 as  SELECT * FROM tt_t20;
     CREATE temporary TABLE tt_t22 as  SELECT * FROM tt_t21;
    
  
     insert into tt_t12
     select Distinct reseller_id from Reseller where fk_reseller_id in(select Distinct reseller_id from tt_t13)
     and reseller_id not in(select Distinct reseller_id from tt_t14);
  
     insert into tt_t12
     select Distinct reseller_id from Reseller where fk_reseller_id in(select Distinct reseller_id from tt_t15)
     and reseller_id not in(select Distinct reseller_id from tt_t16);
  
     insert into tt_t12
     select Distinct reseller_id from Reseller where fk_reseller_id in(select Distinct reseller_id from tt_t17)
     and reseller_id not in(select Distinct reseller_id from tt_t20);
  
     insert into tt_t12
     select Distinct reseller_id from Reseller where fk_reseller_id in(select Distinct reseller_id from tt_t21)
     and reseller_id not in(select Distinct reseller_id from tt_t22); 
  
	
 
     
  
  End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_reseller_get_subordinates_list_new` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_reseller_get_subordinates_list_new`(reseller_id INT)
begin  
 
     

    drop table if exists tt_new_reseller_id;  
    create table tt_new_reseller_id(reseller_id INT primary key);
    
    set @query:=concat('drop table if exists tt_t');
    prepare s from @query;execute s;
    
    set @query:=concat('create table tt_t(reseller_id INT primary key)');
    prepare s from @query;execute s;
    
    set @query:=concat('insert into tt_t(reseller_id)',' select a.reseller_id from Reseller a where a.reseller_id = ',reseller_id);
    prepare s from @query;execute s;
    
   set @query:=concat('insert into tt_t(reseller_id)',' select Distinct B.reseller_id from Reseller B where B.fk_reseller_id in(select Distinct f.reseller_id from tt_t f',') and B.reseller_id not in(select Distinct g.reseller_id from tt_t g',');');
    prepare s from @query;execute s;
    
    set @query:=concat('insert into tt_t(reseller_id)',' select Distinct c.reseller_id from Reseller c where c.fk_reseller_id in(select Distinct h.reseller_id from tt_t h',') and c.reseller_id not in(select Distinct i.reseller_id from tt_t i',');');
    prepare s from @query;execute s;
    
    set @query:=concat('insert into tt_t(reseller_id)',' select Distinct d.reseller_id from Reseller d where d.fk_reseller_id in(select Distinct j.reseller_id from tt_t j',') and d.reseller_id not in(select Distinct k.reseller_id from tt_t k',');');
    prepare s from @query;execute s;
    
    set @query:=concat('insert into tt_t(reseller_id)',' select Distinct e.reseller_id from Reseller e where e.fk_reseller_id in(select Distinct l.reseller_id from tt_t l',') and e.reseller_id not in(select Distinct m.reseller_id from tt_t m',');');
    prepare s from @query;execute s;
    
    
    set @query:=concat('insert into tt_new_reseller_id(reseller_id)','select Distinct z.reseller_id from tt_t z');
    prepare s from @query;execute s;
    
    set @query:=concat('drop table if exists tt_t');
     prepare s from @query;execute s;

    End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_reseller_get_subordinates_list_new1` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_reseller_get_subordinates_list_new1`(reseller_id INT)
begin
  
  drop table if exists tt_new_reseller_id;
  
  set @query:=concat('drop table if exists tt_t',connection_id());
  prepare s from @query;execute s;
  
  set @query:=concat('create table tt_t',connection_id(),'(id int auto_increment,reseller_id INT,key(id,reseller_id))');
  prepare s from @query;execute s;
  
  set @query:=concat('insert into tt_t(reseller_id)',connection_id(),' select a.reseller_id from Reseller a where a.reseller_id = ',reseller_id);
  prepare s from @query;execute s;
  
  set @query:=concat('insert into tt_t(reseller_id)',connection_id(),' select Distinct B.reseller_id from Reseller B where B.fk_reseller_id in(select Distinct f.reseller_id from tt_t f',connection_id(),') and B.reseller_id not in(select Distinct g.reseller_id from tt_t g',connection_id(),');');
  prepare s from @query;execute s;
  
  set @query:=concat('insert into tt_t(reseller_id)',connection_id(),' select Distinct c.reseller_id from Reseller c where c.fk_reseller_id in(select Distinct h.reseller_id from tt_t h',connection_id(),') and c.reseller_id not in(select Distinct i.reseller_id from tt_t i',connection_id(),');');
  prepare s from @query;execute s;
  
  set @query:=concat('insert into tt_t(reseller_id)',connection_id(),' select Distinct d.reseller_id from Reseller d where d.fk_reseller_id in(select Distinct j.reseller_id from tt_t j',connection_id(),') and d.reseller_id not in(select Distinct k.reseller_id from tt_t k',connection_id(),');');
  prepare s from @query;execute s;
  
  set @query:=concat('insert into tt_t(reseller_id)',connection_id(),' select Distinct e.reseller_id from Reseller e where e.fk_reseller_id in(select Distinct l.reseller_id from tt_t l',connection_id(),') and e.reseller_id not in(select Distinct m.reseller_id from tt_t m',connection_id(),');');
  prepare s from @query;execute s;
  
  set @query:=concat('create table tt_new_reseller_id as select * from tt_t',connection_id());
  prepare s from @query;execute s;
  
  set @query:=concat('drop table if exists tt_t',connection_id());
   prepare s from @query;execute s;
   
 
  
  End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_reseller_get_update_commission_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_reseller_get_update_commission_info`(reseller_id INT)
begin

   IF reseller_id is null then set reseller_id = 0; END IF;
   
   drop TEMPORARY table IF EXISTS tt_temp_sum_commission;
   create TEMPORARY table tt_temp_sum_commission
   (
      reseller_id INT,
      Revenue_earned FLOAT,
      commission_percentage FLOAT
   );

   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   insert into tt_temp_sum_commission(reseller_id,Revenue_earned) 
   select a.reseller_id,IFNULL(sum(a.total_purchase_amount),0) Revenue_earned 
   from Reseller_commisson_info a
   where a.Reseller_Id = reseller_id and a.total_purchase_amount is not null
   group by a.reseller_id,a.comm_per
   order by a.reseller_id;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select a.reseller_id,(CONCAT(Firstname,' ',lastname)) as Reseller_name,role_name,a.Create_date,
	IFNULL(a.fixed_inc_per,0)+IFNULL(a.var_inc_per,0) as commission_percentage,
	IFNULL(tc.Revenue_earned,0) as Revenue_earned
   from Reseller a
   LEFT JOIN Reseller_role b  on a.fk_role_id = b.Pk_role_id
   LEFT JOIN tt_temp_sum_commission tc on a.reseller_id = tc.reseller_id
   where a.reseller_id = reseller_id;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

   drop TEMPORARY table IF EXISTS tt_temp_sum_commission;

End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_reseller_insert_license_based_config_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_reseller_insert_license_based_config_info`(
 p_reseller_id int
 ,p_pricing_json json 
 ,p_platform_fee_json_info json
 )
Begin
 	declare v_errcode int;
    declare v_errmsg varchar(100);
 	declare v_JLength1 SMALLINT;
    declare v_JLength2 SMALLINT;
     
     SET v_JLength1 = JSON_LENGTH(p_pricing_json, "$");
     SET v_JLength2 = JSON_LENGTH(p_platform_fee_json_info, "$");
 
 		DROP TEMPORARY TABLE IF EXISTS tt_resellerpricing;
 		CREATE TEMPORARY TABLE tt_resellerpricing       
 		WITH RECURSIVE  CTE_JsonCount as
 		(	SELECT 	0 SlNo
 			UNION ALL
 			SELECT 	SlNo + 1	SlNo
 			FROM 	CTE_JsonCount
 			WHERE 	SlNo  < v_JLength1 - 1
 		)
 		SELECT  TRIM(BOTH '"' FROM (json_extract(p_pricing_json, concat('$[',SlNo,'].plan_id')))) AS plan_id,
 				TRIM(BOTH '"' FROM (json_extract(p_pricing_json, concat('$[',SlNo,'].duration')))) AS duration,
                 TRIM(BOTH '"' FROM (json_extract(p_pricing_json, concat('$[',SlNo,'].user_price')))) AS user_price,
                 TRIM(BOTH '"' FROM (json_extract(p_pricing_json, concat('$[',SlNo,'].discount_user_price')))) AS discount_user_price,
                 TRIM(BOTH '"' FROM (json_extract(p_pricing_json, concat('$[',SlNo,'].platform_fee')))) AS platform_fee,
                 TRIM(BOTH '"' FROM (json_extract(p_pricing_json, concat('$[',SlNo,'].discount_platform_fee')))) AS discount_platform_fee,
                 TRIM(BOTH '"' FROM (json_extract(p_pricing_json, concat('$[',SlNo,'].setup_fee')))) AS setup_fee,
                 TRIM(BOTH '"' FROM (json_extract(p_pricing_json, concat('$[',SlNo,'].discount_setup_fee')))) AS discount_setup_fee,
                 TRIM(BOTH '"' FROM (json_extract(p_pricing_json, concat('$[',SlNo,'].product_id')))) AS product_id
 		FROM CTE_JsonCount;
    
          if exists(select 1 from reseller_license_based_config_dtl where reseller_id = p_reseller_id limit 1) then
 			delete from reseller_license_based_config_dtl where reseller_id = p_reseller_id ;
          end if;
 
 		insert into reseller_license_based_config_dtl(reseller_id,plan_id,duration,user_price,discount_user_price,platform_fee,discount_platform_fee,setup_fee,discount_setup_fee,create_date,product_id)
         select p_reseller_id,a.plan_id,a.duration,a.user_price,a.discount_user_price,a.platform_fee,a.discount_platform_fee,a.setup_fee,a.discount_setup_fee,now(),a.product_id
         from tt_resellerpricing a;
         
         DROP TEMPORARY TABLE IF EXISTS tt_reseller_platform_fee_json_info;
 		CREATE TEMPORARY TABLE tt_reseller_platform_fee_json_info       
 		WITH RECURSIVE  CTE_JsonCount as
 		(	SELECT 	0 SlNo
 			UNION ALL
 			SELECT 	SlNo + 1	SlNo
 			FROM 	CTE_JsonCount
 			WHERE 	SlNo  < v_JLength2 - 1
 		)
 		SELECT  TRIM(BOTH '"' FROM (json_extract(p_platform_fee_json_info, concat('$[',SlNo,'].tier_id')))) AS tier_id,
 				TRIM(BOTH '"' FROM (json_extract(p_platform_fee_json_info, concat('$[',SlNo,'].platform_fee_name')))) AS platform_fee_name,
                 TRIM(BOTH '"' FROM (json_extract(p_platform_fee_json_info, concat('$[',SlNo,'].platform_fee_month_price')))) AS platform_fee_month_price,
                 TRIM(BOTH '"' FROM (json_extract(p_platform_fee_json_info, concat('$[',SlNo,'].platform_fee_month_discount_price')))) AS platform_fee_month_discount_price,
                 TRIM(BOTH '"' FROM (json_extract(p_platform_fee_json_info, concat('$[',SlNo,'].platform_fee_yearly_price')))) AS platform_fee_yearly_price,
                 TRIM(BOTH '"' FROM (json_extract(p_platform_fee_json_info, concat('$[',SlNo,'].platform_fee_yearly_discount_price')))) AS platform_fee_yearly_discount_price,
                 TRIM(BOTH '"' FROM (json_extract(p_platform_fee_json_info, concat('$[',SlNo,'].platform_fee_count')))) AS platform_fee_count,
                 TRIM(BOTH '"' FROM (json_extract(p_platform_fee_json_info, concat('$[',SlNo,'].product_id')))) AS product_id
 		FROM CTE_JsonCount;
        
		if exists(select 1 from reseller_license_based_platform_fee_json_dtl where reseller_id = p_reseller_id limit 1) then
			delete from reseller_license_based_platform_fee_json_dtl where reseller_id = p_reseller_id ;
		end if;
 
		insert into reseller_license_based_platform_fee_json_dtl(reseller_id,tier_id,platform_fee_name,platform_fee_month_price,platform_fee_month_discount_price,platform_fee_yearly_price,platform_fee_yearly_discount_price,platform_fee_count,create_date,product_id)
		select p_reseller_id,a.tier_id,a.platform_fee_name,a.platform_fee_month_price,a.platform_fee_month_discount_price,a.platform_fee_yearly_price,a.platform_fee_yearly_discount_price,a.platform_fee_count,now(),a.product_id
		from tt_reseller_platform_fee_json_info a;
         
		if row_count() > 0 then 
			set v_errcode = 0;
			set v_errmsg = 'Inserted';
		end if;
 
 	select v_errcode as errcode, v_errmsg as errmsg;
 
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Sme_reseller_insert_phone_add_number_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `Sme_reseller_insert_phone_add_number_dtl`(
  company_id	INT,
  domain_id	INT,
  extension	VARCHAR(255),
  external_number	VARCHAR(15),
  assign_type	INT,
  charge_price	FLOAT,
  prorata	FLOAT,
  tax_per	VARCHAR(30),
  tax_fee	FLOAT,
  total_charge	FLOAT,
  reference_no	VARCHAR(50),
  country	VARCHAR(20),
   number_type	VARCHAR(20),
 OUT errcode	INT ,
 OUT errmsg	VARCHAR(250) ,
  called_by	VARCHAR(100),
  site_id	INT,
  upload_path	VARCHAR(500),
  ivr_id	INT)
begin
  
     CALL unifiedring.UR_ma_insert_phone_add_number_dtl(company_id,domain_id,extension,external_number,assign_type,charge_price,
     prorata,tax_per,tax_fee,total_charge,reference_no,
     country,number_type,errcode,errmsg,called_by,site_id,upload_path,
     ivr_id,NULL,NULL,NULL,NULL);
  	
  

  
  end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_reseller_main_dashboard_overview` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_reseller_main_dashboard_overview`(reseller_id INT)
BEGIN
       
          DECLARE v_Total_company INT;
          DECLARE v_freetrail INT;
          DECLARE v_paid_subs INT;
          DECLARE v_Total_revenue FLOAT;
          DECLARE v_Total_commision FLOAT;
          DECLARE v_Inc_Tier_Type INT;  
          DECLARE v_Fixed_inc_per FLOAT;
          DECLARE v_var_inc_per FLOAT;
          DECLARE v_paid_amount FLOAT;
          DECLARE v_agentCreated int;
          DECLARE v_total_active_deals int;
          DECLARE v_pendingDeals int;
          
          drop TEMPORARY table IF EXISTS tt_reseller_list;  
          create TEMPORARY table tt_reseller_list
          ( 
            id int auto_increment primary key,
             reseller_id INT
          );  
          
   		
   		
   		
          
          call sme_reseller_get_subordinates_list121(reseller_id);
              
   		insert into tt_reseller_list (reseller_id)
   		select a.reseller_id from tt_t12 a;
   
          SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
          select COUNT(1) INTO v_Total_company from reseller_company a 
          Join Reseller b on a.reseller_id = b.Reseller_id
          and b.reseller_id in (select c.reseller_id from tt_reseller_list c);
          SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
          
          SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
          select COUNT(1) INTO v_freetrail from reseller_company a  
          where a.free_trail = 1 and a.reseller_id in (select b.reseller_id from tt_reseller_list b);
          SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
          
          SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
          select COUNT(1) INTO v_paid_subs from reseller_company a  
          where (a.free_trail <> 1 or a.free_trail is null) and a.reseller_id in (select b.reseller_id from tt_reseller_list b);
          SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
          
          SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
          select sum(total_purchase_amount) INTO v_Total_revenue from Reseller_commisson_info c where c.reseller_id = reseller_id and comm_assigned_by = 'COMP-PURCHASE';
          SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
          
          SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
          select sum(comm_amount) INTO v_Total_commision from Reseller_commisson_info c where c.reseller_id = reseller_id and comm_assigned_by = 'COMP-PURCHASE';
          SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ; 
          
 		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
 		select count(Distinct a.reseller_id) into v_agentCreated from tt_t12 a 
        join smereseller.Reseller b on a.reseller_id = b.fk_reseller_id;
        
 		SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
         
         SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
 		select count(*) into v_total_active_deals from reseller_company rs where rs.reseller_id in (select Distinct a.reseller_id from tt_t12 a) and rs.status = 1;
         SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
         
         SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
 		select count(*) into v_pendingDeals from reseller_company rs where rs.reseller_id in (select Distinct a.reseller_id from tt_t12 a) and rs.status = 0;
         SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
              
          select v_Total_company as Total_company,v_freetrail as freetrail,v_paid_subs as paid_subs,
          ifnull(v_Total_revenue,0) as Total_revenue, ifnull(v_Total_commision,0) as Total_commision,ifnull(v_agentCreated,0) as agentCreated,ifnull(v_total_active_deals,0) as total_active_deals, ifnull(v_pendingDeals,0) as pendingDeals;
         
       END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_reseller_main_dashboard_overview1` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_reseller_main_dashboard_overview1`(reseller_id INT)
BEGIN
  
     DECLARE v_Total_company INT;
     DECLARE v_freetrail INT;
     DECLARE v_paid_subs INT;
     DECLARE v_Total_revenue FLOAT;
     DECLARE v_Total_commision FLOAT;
     DECLARE v_Inc_Tier_Type INT;  
     DECLARE v_Fixed_inc_per FLOAT;
     DECLARE v_var_inc_per FLOAT;
     DECLARE v_paid_amount FLOAT;
     
     drop TEMPORARY table IF EXISTS tt_reseller_list;  
     create TEMPORARY table tt_reseller_list
     (
        reseller_id INT
     );  
     
     
     CALL sme_reseller_get_subordinates_list_new (reseller_id);
     
         
        insert into tt_reseller_list (reseller_id)
        select a.reseller_id from tt_new_reseller_id a;
     
     SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
     select COUNT(1) INTO v_Total_company from reseller_company a 
     Join Reseller b on a.reseller_id = b.Reseller_id
     and b.reseller_id in (select c.reseller_id from tt_reseller_list c);
     SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
     
     SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
     select COUNT(1) INTO v_freetrail from reseller_company a  
     where a.free_trail = 1 and a.reseller_id in (select b.reseller_id from tt_reseller_list b);
     SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
     
     SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
     select COUNT(1) INTO v_paid_subs from reseller_company a  
     where (a.free_trail <> 1 or a.free_trail is null) and a.reseller_id in (select b.reseller_id from tt_reseller_list b);
     SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
     
     SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
     select sum(total_purchase_amount) INTO v_Total_revenue from Reseller_commisson_info c where c.reseller_id = reseller_id;
     SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
     
     SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
     select sum(my_comm) INTO v_Total_commision from Reseller_commisson_info c where c.reseller_id = reseller_id;
     SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ; 
         
     select v_Total_company as Total_company,v_freetrail as freetrail,v_paid_subs as paid_subs,
     v_Total_revenue as Total_revenue, v_Total_commision as Total_commision;        
    
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_reseller_mycommission_calculation` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_reseller_mycommission_calculation`(reseller_id INT,  
paid_amount FLOAT,  
Users FLOAT,  
Price FLOAT,  
new_tax FLOAT,  
company_id INT,  
domain_id INT,  
Pay_Reference_No VARCHAR(80))
Begin
  
   DECLARE v_fixed_inc_per FLOAT; 
   DECLARE v_Inc_Tier_Type INT;
   DECLARE v_var_inc_per_assigned FLOAT; 
   DECLARE v_var_per_comm FLOAT; 
   DECLARE v_Total_revenue FLOAT;  
   DECLARE v_P_fixed_inc_per FLOAT; 
   DECLARE v_P_Inc_Tier_Type INT;
   DECLARE v_P_var_inc_per_assigned FLOAT;  
   DECLARE v_output FLOAT; 
   DECLARE v_ID INT; 
   DECLARE v_my_per FLOAT; 
   DECLARE v_my_parent_total FLOAT;
   DECLARE v_temp_my_parent FLOAT;  
  
   select fixed_inc_per, IFNULL(Inc_Tier_Type,1), var_inc_per INTO v_fixed_inc_per,v_Inc_Tier_Type,v_var_inc_per_assigned 
   from Reseller a where a.reseller_id = reseller_id;  
  
   
   select   IFNULL(fixed_inc_per,0), IFNULL(Inc_Tier_Type,0), var_inc_per INTO v_P_fixed_inc_per,v_P_Inc_Tier_Type,v_P_var_inc_per_assigned 
   from Reseller a where a.FK_reseller_id = reseller_id;  
   
   SET v_my_per = IFNULL(v_fixed_inc_per,0)+IFNULL(v_var_inc_per_assigned,0);  
   SET v_temp_my_parent = IFNULL(v_P_fixed_inc_per,0)+IFNULL(v_P_var_inc_per_assigned,0);  
   
   
   if v_my_per > v_temp_my_parent 
   then 
      set v_my_parent_total = v_my_per -v_temp_my_parent;
      
   Else
   
      set v_my_parent_total = v_temp_my_parent -v_my_per;
   end if;  
   
   
   
 
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   sum(paid_amount) INTO v_Total_revenue from reseller_company a where a.reseller_id = reseller_id;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
   
 
   select   commission INTO v_var_per_comm from sme_Reseller_Tier where create_by = reseller_id
   and v_Total_revenue between tier_min and Tier_to;  
   
   insert into sme_reseller_mycommission_calc_log(reseller_id,company_id,paid_amount,Total_revenue,fixed_inc_per,var_inc_per_assigned,Inc_Tier_Type,var_per_comm,domain_id,Pay_Reference_No,CREATE_DATE,Users,Price,new_tax,new_revenue,my_parent_total)
 values(reseller_id,company_id,paid_amount,v_Total_revenue,v_fixed_inc_per,v_var_inc_per_assigned,v_Inc_Tier_Type,v_var_per_comm,domain_id,Pay_Reference_No,CURRENT_TIMESTAMP,Users,Price,new_tax,paid_amount,v_my_parent_total);  
   
 
   Set v_ID  = LAST_INSERT_ID();  
   
   If v_Inc_Tier_Type = 2 
   then
 
      SET v_output =((paid_amount)*(v_fixed_inc_per)/100.0+(paid_amount)*(v_var_per_comm)/100.0);
      
      UPDATE sme_reseller_mycommission_calc_log b
      set b.my_comm = v_output
      where b.reseller_id = reseller_id and b.ID = v_ID;
      
   Else
   
      SET v_output =((paid_amount)*(v_fixed_inc_per)/100.0);
      
      UPDATE sme_reseller_mycommission_calc_log b
      set b.my_comm = v_output
      where b.reseller_id = reseller_id and b.ID = v_ID;
   end if;  
  
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_reseller_new_commisson_incentive` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_reseller_new_commisson_incentive`(
  Reseller_ID INT,
  amount FLOAT,
  company_id INT,
  Pay_Reference_No VARCHAR(150),
  Processby VARCHAR(150),
  Type_ID INT
  )
BEGIN
  
  	
     DECLARE count INT; 
     DECLARE tcount INT; 
     DECLARE tier_to FLOAT;
     DECLARE var_per_comm FLOAT;
  	
     DECLARE purchase_cost FLOAT;
 
     DECLARE P_Reseller_Id INT; 
     DECLARE Reseller_Role VARCHAR(250);
  	
     DECLARE admin_commisson FLOAT;
     DECLARE parent_commisson FLOAT;
     DECLARE comm_amount FLOAT;
     DECLARE tcommisson FLOAT;
     DECLARE org_Reseller_Id INT; 
  	
     DECLARE Reseller_Level INT;
     DECLARE Tier_id INT;  
  	
     DECLARE fixed_percentage FLOAT;
     DECLARE master_reseller_id INT; 
  	
     DECLARE commsion_earned FLOAT;
     DECLARE commison_earned_per FLOAT;
     DECLARE role_id INT; 
  	
     DECLARE inc_percentage FLOAT;
  	
     DECLARE scheme_ID INT;
     DECLARE lat_Scheme_ID INT;  
  	
     DECLARE partner_id INT; 
     DECLARE role INT; 
  	
     DECLARE agent_id INT; 
  	
     DECLARE purchase_count INT; 
  	
     DECLARE partner_comm FLOAT; 
     DECLARE part_inc_per FLOAT; 
     DECLARE part_inc FLOAT; 
     DECLARE agent_inc_per FLOAT; 
     DECLARE agent_inc_price FLOAT; 
 
     DECLARE master_res_comm FLOAT;
     DECLARE res_mycomm FLOAT;
     DECLARE master_subres_comm FLOAT;
 
     DROP TEMPORARY TABLE IF EXISTS tt_temp_Reseller_list;
     create TEMPORARY table tt_temp_Reseller_list
     (
        id INT AUTO_INCREMENT PRIMARY KEY,
        parent_reseller_id INT,
        Reseller_Id INT,
        Role_Name VARCHAR(250)
     )  AUTO_INCREMENT = 1;
  	
     set comm_amount = 0;
  	
   
  	
     SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
     select IFNULL(a.Is_Id,0), IFNULL(a.fk_role_id,0), case when IFNULL(a.fk_role_id,0) = 3 then IFNULL(a.Fk_Reseller_Id,0) else 0 end, 
 			case when IFNULL(a.fk_role_id,0) = 4 then IFNULL(a.Fk_Reseller_Id,0) else 0 end 
 	INTO scheme_ID,role,partner_id,agent_id 
 	from Reseller a where a.Reseller_id = Reseller_ID;
     SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
  	
     SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
     select a.Is_ID INTO lat_Scheme_ID FROM  Inc_Scheme_Master a WHERE a.STATUS = 1 ORDER BY a.Is_ID DESC LIMIT 1;
     SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   	
  	
     IF IFNULL(scheme_ID,0) <> IFNULL(lat_Scheme_ID,0) and role = 2 then
  	
        CALL Reseller_assign_Incenctive_Scheme(Reseller_ID,lat_Scheme_ID);
     end if;
  	
     SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
     select IFNULL(a.Is_Id,0) INTO scheme_ID from Reseller a  where a.Reseller_id = Reseller_ID;
     SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
  	
     SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
     select count(1) INTO purchase_count from  Reseller_Payment_Info a where a.Reseller_Id = Reseller_ID and a.Vpcp_Comp_Id = company_id
     and a.pay_status = 'Success';
     SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
  	
  	
     SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
     select IFNULL(a.inc_percentage,0) INTO inc_percentage from Reseller_incentive_Config a where a.Reseller_Id = Reseller_ID and a.Typeid = Type_ID
     and purchase_count <= Inc_app_Month    LIMIT 1;
     SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
  	
     IF IFNULL(inc_percentage,0) = 0 AND purchase_count > 1 then
  	
  		
        SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        select IFNULL(a.After_Inc_apply_Month_Per,0) INTO inc_percentage from Reseller_incentive_Config a where a.Reseller_Id = Reseller_ID and a.Typeid = Type_ID
        and a.purchase_count >= Inc_app_Month LIMIT 1;
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
     end if;
  	
     if IFNULL(inc_percentage,0) > 0 then
  	
        set comm_amount = amount*(inc_percentage/100.00);
     end if;
 
     IF IFNULL(agent_id,0) > 0 AND   IFNULL(role,0) = 4 then
  	
        CALL reseller_comm_get_incnentive_percentage(agent_id,company_id,Type_ID,agent_inc_per);
        set comm_amount = inc_percentage/100*(amount*(agent_inc_per/100.00));
        set  agent_inc_price =((amount)*(part_inc_per/100.00));
        set  agent_inc_price = agent_inc_price -comm_amount;
 
  		
 		Insert into  Reseller_commisson_info(Reseller_Id,Total_Purchase_amount,Comm_per,Comm_amount,Comm_date,Comm_assigned_by,Company_Id,Status,
 		Reseller_level,Tier_Id,my_comm,Pay_Reference_No,commison_earned,var_per_comm,fixed_inc_per,plan_Type_ID,Scheme_ID)
 		values(agent_id,amount,agent_inc_per,agent_inc_price,CURRENT_TIMESTAMP,Processby,company_id,1,Reseller_Level,Tier_id,agent_inc_price,
 		Pay_Reference_No,commsion_earned,NULL,Null,Type_ID,scheme_ID);
     end if;
  	
  	
  
  		
  	
     IF IFNULL(partner_id,0) > 0 AND  IFNULL(role,0) = 3 then
  	
        CALL reseller_comm_get_incnentive_percentage(partner_id,company_id,Type_ID,part_inc_per);
        IF IFNULL(part_inc_per,0) > 0 then
  		
           set comm_amount = inc_percentage/100*(amount*(part_inc_per/100.00));
           set  part_inc =((amount)*(part_inc_per/100.00));
           set  part_inc = part_inc -comm_amount;
        end if;
 		set part_inc = IFNULL(part_inc,0);
 
 		Insert into Reseller_commisson_info(Reseller_Id,Total_Purchase_amount,Comm_per,Comm_amount,Comm_date,Comm_assigned_by,Company_Id,Status,
 		Reseller_level,Tier_Id,my_comm,Pay_Reference_No,commison_earned,var_per_comm,fixed_inc_per,plan_Type_ID,Scheme_ID)
 		values(partner_id,amount,part_inc_per,part_inc,CURRENT_TIMESTAMP,Processby,company_id,1,Reseller_Level,Tier_id,part_inc,
 		Pay_Reference_No,commsion_earned,NULL,Null,Type_ID,scheme_ID);
     end if;
  	
  	
     set comm_amount = IFNULL(comm_amount,0);
  	
  	
     Insert into Reseller_commisson_info(Reseller_Id,Total_Purchase_amount,Comm_per,Comm_amount,Comm_date,
  	Comm_assigned_by,Company_Id,Status,Reseller_level,Tier_Id,my_comm,Pay_Reference_No,commison_earned,var_per_comm,fixed_inc_per,plan_Type_ID,Scheme_ID)
  	values(Reseller_ID,amount,inc_percentage,comm_amount,CURRENT_TIMESTAMP,Processby,company_id,1,Reseller_Level,Tier_id,comm_amount,
 	Pay_Reference_No,commsion_earned,NULL,Null,Type_ID, scheme_ID);
 
     select a.my_comm INTO master_res_comm from Reseller_commisson_info a
     join Reseller b on a.Reseller_Id = b.Reseller_id where a.Total_Purchase_amount = amount and a.Pay_Reference_No = Pay_Reference_No
     and b.fk_role_id = 2; 
  	
  	
     select a.my_comm INTO res_mycomm from Reseller_commisson_info  a
     join Reseller b on a.Reseller_Id = b.Reseller_id where a.Total_Purchase_amount = amount and a.Pay_Reference_No = Pay_Reference_No
     and b.fk_role_id = 3; 
  	
     select   my_comm INTO master_subres_comm from Reseller_commisson_info  a
     join Reseller b on a.Reseller_Id = b.Reseller_id where a.Total_Purchase_amount = amount and a.Pay_Reference_No = Pay_Reference_No
     and b.fk_role_id = 4; 
  	
     update Reseller_commisson_info a set a.Master_mycomm = IFNULL(master_res_comm,0),a.Res_mycomm = IFNULL(res_mycomm,0),
     a.Master_subres_comm = IFNULL(master_subres_comm,0)
     where a.Total_Purchase_amount = amount and a.Pay_Reference_No = Pay_Reference_No;
  		
  	
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_reseller_performance_dashboard` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_reseller_performance_dashboard`(reseller_id INT)
Begin
       
          DECLARE v_Total_revenue FLOAT;  
            drop TEMPORARY table IF EXISTS tt_reseller_list;  
            drop TEMPORARY table IF EXISTS tt_reseller_list_list;
         
          create TEMPORARY table tt_reseller_list
          (
            id int not null primary key auto_increment,
             reseller_id INT,
             index(reseller_id)
          );  
          
        
          
          CALL sme_reseller_get_subordinates_list_new(reseller_id);
         
             
             SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
             insert into tt_reseller_list(reseller_id)
             select a.reseller_id from tt_new_reseller_id a;
             SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
             
             create temporary table tt_reseller_list_list as select distinct a.reseller_id  from tt_reseller_list a;
             
             CREATE INDEX reseller_id_idx ON tt_reseller_list_list (reseller_id);
          
          SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
          drop temporary table if exists temp_final_output;
          create temporary table temp_final_output as 
          select Distinct a.reseller_id,(CONCAT(a.Firstname,' ',a.lastname)) as Member_name,
          rb.role_name as Member_type,
          parent_reseller_name(a.fk_Reseller_id) as parent_reseller,  
          
          cast(IFNULL(sme_reseller_performance_info(b.reseller_id,1),0) as DECIMAL(10,2)) as Revenue_generated,
          cast(IFNULL(ur_get_reseller_commission(b.reseller_id,2),0) as DECIMAL(10,2)) as comm_percentage,
          cast(IFNULL(sme_reseller_performance_info(b.reseller_id,2),0) as DECIMAL(10,2)) as commission_earned
          from tt_reseller_list_list b 
          left join Reseller a  on a.reseller_id = b.reseller_id
          left JOIN Reseller_role rb  on a.fk_role_id = rb.Pk_role_id
          left join Reseller_commisson_info rc  on b.reseller_id = rc.reseller_id
          order by a.reseller_id;
          SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  

		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
			select a.reseller_id,a.Member_name,a.Member_type,a.parent_reseller,a.Revenue_generated,a.comm_percentage,a.commission_earned,count(*) as total_active_deals
            from temp_final_output a join Reseller b on a.reseller_id = b.reseller_id
			join reseller_company rs on rs.reseller_id = b.reseller_id
			where rs.reseller_id in (select Distinct nr.reseller_id from tt_new_reseller_id nr) and rs.status = 1 and rs.vpcp_company_id is not null
			group by a.reseller_id,a.Member_name,a.Member_type,a.parent_reseller,a.Revenue_generated,a.comm_percentage,a.commission_earned;    
		SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  

       End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_reseller_performance_info_111` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_reseller_performance_info_111`(v_reseller_id INT)
BEGIN
  	
  
  
     
    drop temporary table if exists tt_reseller_parentMT; create temporary table tt_reseller_parentMT(Reseller_id int); 
    
    drop temporary table if exists tt_reseller_parentMT_Dumy1; create temporary table tt_reseller_parentMT_Dumy1(Reseller_id int); 
    drop temporary table if exists tt_reseller_parentMT_Dumy2; create temporary table tt_reseller_parentMT_Dumy2(Reseller_id int);
    drop temporary table if exists tt_reseller_parentMT_Dumy3; create temporary table tt_reseller_parentMT_Dumy3(Reseller_id int);
    drop temporary table if exists tt_reseller_parentMT_Dumy4; create temporary table tt_reseller_parentMT_Dumy4(Reseller_id int);
    drop temporary table if exists tt_reseller_parentMT_Dumy5; create temporary table tt_reseller_parentMT_Dumy5(Reseller_id int);
    drop temporary table if exists tt_reseller_parentMT_Dumy6; create temporary table tt_reseller_parentMT_Dumy6(Reseller_id int);
    
    drop temporary table if exists tt_reseller_parent1; create temporary table tt_reseller_parent1(Reseller_id int);
    drop temporary table if exists tt_reseller_parent2; create temporary table tt_reseller_parent2(Reseller_id int);
     
     
     insert into tt_reseller_parentMT (Reseller_id) select a.Reseller_id from Reseller a where a.Reseller_id = v_reseller_id;
     insert into tt_reseller_parent1 (Reseller_id) select a.Reseller_id from Reseller a where a.Reseller_id = v_reseller_id;
     insert into tt_reseller_parent2 (Reseller_id) select a.Reseller_id from Reseller a where a.Reseller_id = v_reseller_id;
     
	 
		insert into  tt_reseller_parentMT
		select Distinct reseller_id from Reseller where fk_reseller_id in (select Distinct reseller_id from tt_reseller_parent1)
		and reseller_id not in ( select Distinct reseller_id from tt_reseller_parent2);
     
			insert into tt_reseller_parentMT_Dumy1 (Reseller_id) select a.Reseller_id from tt_reseller_parentMT a;
            insert into tt_reseller_parentMT_Dumy2 (Reseller_id) select a.Reseller_id from tt_reseller_parentMT a;
     
      
		insert into  tt_reseller_parentMT
		select Distinct reseller_id from Reseller where fk_reseller_id in (select Distinct reseller_id from tt_reseller_parentMT_Dumy1)
		and reseller_id not in ( select Distinct reseller_id from tt_reseller_parentMT_Dumy2);
     
			insert into tt_reseller_parentMT_Dumy3 (Reseller_id) select a.Reseller_id from tt_reseller_parentMT a;
            insert into tt_reseller_parentMT_Dumy4 (Reseller_id) select a.Reseller_id from tt_reseller_parentMT a;
     
      
		insert into  tt_reseller_parentMT
		select Distinct reseller_id from Reseller where fk_reseller_id in (select Distinct reseller_id from tt_reseller_parentMT_Dumy3)
		and reseller_id not in ( select Distinct reseller_id from tt_reseller_parentMT_Dumy4);
     
			insert into tt_reseller_parentMT_Dumy5 (Reseller_id) select a.Reseller_id from tt_reseller_parentMT a;
            insert into tt_reseller_parentMT_Dumy6 (Reseller_id) select a.Reseller_id from tt_reseller_parentMT a;
     
	  
     
		insert into  tt_reseller_parentMT
		select Distinct reseller_id from Reseller where fk_reseller_id in (select Distinct reseller_id from tt_reseller_parentMT_Dumy5)
		and reseller_id not in ( select Distinct reseller_id from tt_reseller_parentMT_Dumy6);

	select * from tt_reseller_parentMT;
  	
  
  
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_Reseller_phoneno_get_city` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_Reseller_phoneno_get_city`(countryid INT)
BEGIN

   CALL unifiedring.UR_ma_phone_number_get_city(countryid);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_Reseller_phone_add_number_get_number_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_Reseller_phone_add_number_get_number_dtl`(
company_id INT,
number_type VARCHAR(20),
area_code VARCHAR(100),
country VARCHAR(100),
no_user INT)
BEGIN


	
   CALL unifiedring.UR_ma_phone_add_number_get_number_dtl(company_id,number_type,area_code,country,no_user);
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_reseller_revenue_commission_dashboard` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_reseller_revenue_commission_dashboard`(
  reseller_id INT,
  data_rev_comm INT,
  member_type INT,
  date_range_id INT)
SWL_return:
  Begin
 
  
     DECLARE v_now DATETIME(3);
     DECLARE v_date_range VARCHAR(50);
     
 	IF member_type is null then set member_type = 0; END IF;
 	IF date_range_id is null then set date_range_id = ''; END IF;
     
 	set v_now = STR_TO_DATE(DATE_FORMAT(CURRENT_TIMESTAMP,'%Y-%m-%d'),'%Y-%m-%d');
 
 	If date_range_id = 1 then set v_date_range = v_now; end if;
 	If date_range_id = 2 then set v_date_range = v_now; end if;
 	If date_range_id = 3 then set v_date_range = TIMESTAMPADD(day,-1,v_now); end if;
 	If date_range_id = 4 then set v_date_range = TIMESTAMPADD(day,-8,v_now); end if;
 	If date_range_id = 5 then set v_date_range = TIMESTAMPADD(day,-15,v_now); end if;
 	If date_range_id = 6 then set v_date_range = TIMESTAMPADD(day,-31,v_now); end if;
 	If date_range_id in(7,'') then set v_date_range = ''; end if;
  	
 	drop TEMPORARY table IF EXISTS tt_reseller_list;
 	drop TEMPORARY table IF EXISTS tt_temp_sum_commission;
 
     create TEMPORARY table tt_reseller_list
     (
        reseller_id INT
     );
  	
     create TEMPORARY table tt_temp_sum_commission
     (
        reseller_id INT,
        Revenue FLOAT,
        Commissions FLOAT
     );
  	
 		
 		CALL sme_reseller_get_subordinates_list_new(reseller_id);
 		
 
 		insert into tt_reseller_list
 		select a.reseller_id from tt_new_reseller_id a;
        
        
     If data_rev_comm = 1 then
  	
        SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        insert into tt_temp_sum_commission(reseller_id,Revenue)
        select a.reseller_id ,sum(rc.total_purchase_amount) as Revenue 
        from tt_reseller_list a 
        join  Reseller b  on a.reseller_id = b.reseller_id
        LEFT JOIN Reseller_role rb  on b.fk_role_id = rb.Pk_role_id
        join Reseller_commisson_info rc  on a.reseller_id = rc.reseller_id
        WHERE (rb.Pk_role_id = member_type or member_type = 0) and ((v_date_range = '') or cast(b.create_date as DATE) between cast(v_date_range as DATE) and cast(v_now as DATE))
        and rc.Comm_assigned_by = 'COMP-PURCHASE'
        group by a.reseller_id;
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
        
         
        
        
        select a.reseller_id,a.Revenue,(CONCAT(b.Firstname,' ',b.lastname)) as Resellers,count(*) as total_active_deals
        from tt_temp_sum_commission a join Reseller b on a.reseller_id = b.reseller_id
        join reseller_company rs on rs.reseller_id = b.reseller_id
        where rs.reseller_id in (select Distinct nr.reseller_id from tt_new_reseller_id nr) and rs.status = 1 and rs.vpcp_company_id is not null
        group by a.reseller_id,a.Revenue,b.Firstname,b.lastname;
   
        LEAVE SWL_return;
     end if;
  	
     If data_rev_comm = 2 then
  	
        SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
 		insert into tt_temp_sum_commission(reseller_id,Commissions)
 		select a.reseller_id ,sum(rc.my_comm) as Commissions from tt_reseller_list a 
 		join Reseller b  on a.reseller_id = b.reseller_id
 		LEFT JOIN Reseller_role rb  on b.fk_role_id = rb.Pk_role_id
 		join Reseller_commisson_info rc  on a.reseller_id = rc.reseller_id
 		WHERE rc.total_purchase_amount is not null 
 		and (rb.Pk_role_id = member_type or member_type = 0) 
 		and ((v_date_range = '') or cast(b.create_date as DATE) between cast(v_date_range as DATE) and cast(v_now as DATE))
 		and rc.Comm_assigned_by = 'COMP-PURCHASE'
 		group by a.reseller_id;
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
        
        
        
        
        select a.reseller_id,a.Revenue,(CONCAT(b.Firstname,' ',b.lastname)) as Resellers,count(*) as total_active_deals
        from tt_temp_sum_commission a join Reseller b on a.reseller_id = b.reseller_id
        join reseller_company rs on rs.reseller_id = b.reseller_id
        where rs.reseller_id in (select Distinct nr.reseller_id from tt_new_reseller_id nr) and rs.status = 1 and rs.vpcp_company_id is not null
        group by a.reseller_id,a.Revenue,b.Firstname,b.lastname;
        
        LEAVE SWL_return;
     end if;
  
  End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_reseller_update_commision_status_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_reseller_update_commision_status_details`(
 p_resellerid int
 ,p_commission_status int
 ,p_Status int
 ,p_admin_approval int
 ,p_finance_approval int
 )
Begin
 
 		declare v_errcode int default -1;
 		declare v_errmsg varchar(50) default 'Failure';
 
 		if exists(select 1 from Reseller where Reseller_id = p_resellerid limit 1) then
 			UPDATE Reseller
 			set commission_status = ifnull(p_commission_status,commission_status)
 				,status = p_Status
                ,admin_approval = ifnull(p_admin_approval,admin_approval)
                ,finance_approval = ifnull(p_finance_approval,finance_approval)
 			WHERE Reseller_id = p_resellerid;
 			
 			set v_errcode = 0;
 			set v_errmsg = 'Reseller : Updated';
 				
 		End if;
 
 	select v_errcode as errcode, v_errmsg as errmsg;
 	End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_reseller_update_get_admin_commission_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_reseller_update_get_admin_commission_info`(reseller_id INT,  
 Pk_role_id INT,  
 status_id VARCHAR(1),  
 date_range_id INT)
Begin  
   
    DECLARE v_now DATETIME(3);  
    DECLARE v_date_range VARCHAR(50);
    DECLARE v_subm_status VARCHAR(1);  
    
    IF reseller_id is null then set reseller_id = 0; END IF;
    IF Pk_role_id is null then set Pk_role_id = 0; END IF;
    IF date_range_id is null then set date_range_id = ''; END IF;
    
    set v_now = STR_TO_DATE(DATE_FORMAT(CURRENT_TIMESTAMP,'%Y-%m-%d'),'%Y-%m-%d');  
    
    if status_id in (1,'') then set v_subm_status = ''; end if;  
    if status_id = 2 then set v_subm_status = 4; end if;  
    if status_id = 3 then set v_subm_status = 1; end if;  
    if status_id = 4 then set v_subm_status = 0; end if;  
    If date_range_id = 1 then set v_date_range = v_now; end if;  
    If date_range_id = 2 then set v_date_range = v_now; end if;  
    If date_range_id = 3 then set v_date_range = TIMESTAMPADD(day,-1,v_now); end if;  
	If date_range_id = 4 then set v_date_range = TIMESTAMPADD(day,-8,v_now); end if;  
    If date_range_id = 5 then set v_date_range = TIMESTAMPADD(day,-15,v_now); end if;  
    If date_range_id = 6 then set v_date_range = TIMESTAMPADD(day,-31,v_now); end if;  
    If date_range_id in(7,'') then set v_date_range = ''; end if;  
   
    drop TEMPORARY table IF EXISTS tt_temp_sum_commission;  
    create TEMPORARY table tt_temp_sum_commission
    (
       reseller_id INT,
       Revenue_earned FLOAT,
       commission_percentage FLOAT
    );  
   
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    insert into tt_temp_sum_commission(reseller_id,Revenue_earned)
    select reseller_id,IFNULL(sum(total_purchase_amount),0) Revenue_earned
    from Reseller_commisson_info 
    where total_purchase_amount is not null
    group by reseller_id,comm_per
    order by reseller_id;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
    
    
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select Distinct a.reseller_id as reseller_id,
    (CONCAT(a.Firstname,' ',a.lastname)) as Name,
    b.role_name as member_type,
    a.create_date as joined,
    IFNULL(a.fixed_inc_per,0)+IFNULL(a.var_inc_per,0) as commission_percentage,
    case when a.status = 0 then 'Rejected' when a.status = 1 then 'Approved' when a.status = 4 then 'Pending' end as status,
    fk_reseller_id as parent_reseller
    from Reseller a 
    LEFT JOIN Reseller_role b  on a.fk_role_id = b.Pk_role_id
    LEFT JOIN Reseller_status_ref l  on a.Status = l.status_id
    where a.fk_role_id = 2 and    
    ((IFNULL(v_subm_status,'') = '') or (cast(a.status as CHAR(30)) = v_subm_status)) and
    ((v_date_range = '') or cast(a.create_date as DATE) between cast(v_date_range as DATE) and cast(v_now as DATE));
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;      
   
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_reseller_update_get_commission_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_reseller_update_get_commission_info`(
    reseller_id INT,  
    Pk_role_id INT,  
    status_id VARCHAR(100),  
    date_range_id INT)
Begin
   
       DECLARE v_now DATETIME(3);  
       DECLARE v_date_range VARCHAR(50); 
       DECLARE v_subm_status VARCHAR(100);
       SET v_now = STR_TO_DATE(DATE_FORMAT(CURRENT_TIMESTAMP,'%Y-%m-%d'),'%Y-%m-%d');
       
  	if status_id in (1,'Active')		then set v_subm_status = '';					end if;
  	if status_id = 2					then set v_subm_status = 4;						end if;
  	if status_id = 3					then set v_subm_status = 1;						end if;
  	if status_id = 4					then set v_subm_status = 0;						end if;
  		 
       IF reseller_id is null 	then set reseller_id = 0; 								end if;
       IF Pk_role_id is null 	then set Pk_role_id = 0; 								end if;
       
       IF date_range_id is null 	then set date_range_id = ''; 							end if;
       If date_range_id = 1 		then set v_date_range = v_now; 							end if;  
       If date_range_id = 2 		then set v_date_range = v_now; 							end if;  
       If date_range_id = 3 		then set v_date_range = TIMESTAMPADD(day,-1,v_now); 	end if;  
       If date_range_id = 4 		then set v_date_range = TIMESTAMPADD(day,-8,v_now); 	end if;  
       If date_range_id = 5 		then set v_date_range = TIMESTAMPADD(day,-15,v_now); 	end if;  
       If date_range_id = 6 		then set v_date_range = TIMESTAMPADD(day,-41,v_now); 	end if;  
       If date_range_id in(7,0) 	then set v_date_range = ''; 							end if;  
       
       drop TEMPORARY table IF EXISTS tt_reseller_list;  
       create TEMPORARY table tt_reseller_list
       (
          reseller_id INT
       );  
         
       drop TEMPORARY table IF EXISTS tt_temp_sum_commission;  
       create TEMPORARY table tt_temp_sum_commission
       (
          reseller_id INT,
          Revenue_earned FLOAT,
          commission_percentage FLOAT
       );  
      
      
           CALL sme_reseller_get_subordinates_list_new(reseller_id);
      
       
          insert into tt_reseller_list
          select a.reseller_id from tt_new_reseller_id a;
    
       SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
       insert into tt_temp_sum_commission(reseller_id,Revenue_earned)
       select a.reseller_id,IFNULL(sum(a.total_purchase_amount),0) Revenue_earned
       from Reseller_commisson_info a
       where a.Reseller_Id in(select a.reseller_id from tt_reseller_list ) and total_purchase_amount is not null
       group by a.reseller_id,a.comm_per
       order by a.reseller_id;
       SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
       
       
       SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
       select Distinct a.reseller_id as reseller_id,
   			(CONCAT(a.Firstname,' ',a.lastname)) as Name,
   			b.role_name as member_type,
   			a.create_date as joined,  
   			IFNULL(a.fixed_inc_per,0)+IFNULL(a.var_inc_per,0) as commission_percentage,   
   			l.status as status,fk_reseller_id as parent_reseller
       from Reseller a 
       LEFT JOIN tt_temp_sum_commission tc on a.reseller_id = tc.reseller_id
       LEFT JOIN  Reseller_role b  on a.fk_role_id = b.Pk_role_id
       LEFT JOIN  Reseller_status_ref l  on a.Status = l.status_id
       where ((a.reseller_id in(select b.reseller_id from tt_reseller_list b) or a.reseller_id = reseller_id) or reseller_id = 0) and
       ((Pk_role_id = 0) or (a.fk_role_id = Pk_role_id)) and
      
       ((ifnull(v_subm_status,'') = '') or (cast(a.status as CHAR(30)) = v_subm_status)) and 
       ((v_date_range = 0) or cast(a.create_date as DATE) between cast(v_date_range as DATE) and cast(v_now as DATE));
       SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;   
   
    End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_reseller_update_master_reseller_password` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_reseller_update_master_reseller_password`(Reseller_id INT,
password VARCHAR(30))
begin


   DECLARE errcode INT;
   DECLARE errmsg VARCHAR(50);
   DECLARE Email_id VARCHAR(100);
	
   sp_exit:
   BEGIN
      set errcode = -1;
      set errmsg = 'Failure';
      if not exists(select 1 from Reseller a where a.Reseller_id = Reseller_id and a.fk_role_id = 2 LIMIT 1) then
	
         set errcode = -1;
         set errmsg = 'Failure';
         LEAVE sp_exit;
      end if;
      
      select Email INTO Email_id from Reseller a where a.Reseller_id = Reseller_id and a.fk_role_id = 2;
      
      Update Reseller a set a.password = password where a.Reseller_id = Reseller_id;
      
      if ROW_COUNT() > 0 then
	
         set errcode = 0;
         set errmsg = 'Success';
         LEAVE sp_exit;
      end if;
   END;
   select errcode  as errcode,errmsg as errmsg,Email_id as Email_id;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_reseller_update_password` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_reseller_update_password`(
  Reseller_ID INT,
  Email VARCHAR(150),
  Pro_password VARCHAR(20))
BEGIN
  
  
  	
  	
     DECLARE v_errcode INT; 
     DECLARE v_errmsg VARCHAR(250);
     DECLARE v_Hubspot_contactid BIGINT; 
     DECLARE v_role_id INT; 
     
     sp_exit:
     BEGIN
        SET v_errcode = -1;
        SET v_errmsg = 'Please try with valid user id and email to get your password.';
      
        IF NOT EXISTS(SELECT  1 FROM Reseller b where 
        b.Email = Email LIMIT 1) then
  	
           SET v_errcode = -1;
           SET v_errmsg = 'Please try with valid user id and email to get your password.';
           LEAVE sp_exit;
        end if;
        IF IFNULL(Pro_password,'') <> '' then
  	
           UPDATE Reseller a SET a.password = Pro_password
           WHERE 
           a.Email = Email;
           
           select a.Hubspot_contactid,a.fk_role_id into v_Hubspot_contactid,v_role_id from Reseller a WHERE 
           a.Email = Email;
           
           
           IF found_rows() > 0 then
              SET v_errcode = 0;
              SET v_errmsg = 'Success to update password';
              LEAVE sp_exit;
           end if;
        end if;
     END;
     select v_errcode as errcode,v_errmsg as errmsg,IFNULL(v_Hubspot_contactid,0) as Hubspot_contactid,IFNULL(v_role_id,0) AS Role_id;
  	
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_reseller_validate_email` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_reseller_validate_email`(email_id VARCHAR(100))
BEGIN
   
   DECLARE v_errcode INT;  
   DECLARE v_errmsg VARCHAR(250);  
   
   sp_exit:BEGIN
   
      set v_errcode = 0;
      set v_errmsg = 'Email Id not found';
      
      IF EXISTS(SELECT  1 FROM Reseller a where a.Email = email_id LIMIT 1) 
      then 
         set v_errcode = -1;
         set v_errmsg = 'Email Id already exists!';
         LEAVE sp_exit;
      end if;
   END;
   select v_errcode as errcode,v_errmsg as errmsg;  
   
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_reseller_validate_email_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_reseller_validate_email_info`(email_id VARCHAR(150))
BEGIN

   DECLARE v_errcode INT;  
   DECLARE v_errmsg VARCHAR(160);  
   
   
   sp_exit:
   BEGIN
      set v_errcode = 0;
      set v_errmsg = 'ok';
      IF  EXISTS(SELECT  1 FROM Reseller WHERE  Email = email_id LIMIT 1) then
 
         SET v_errcode = -1;
         SET v_errmsg = 'Email ID already Exists.';
         LEAVE sp_exit;
      end if;
      IF  EXISTS(SELECT  1 FROM sme_reseller_company_admin_user A WHERE  A.email_id = email_id LIMIT 1) then
 
         SET v_errcode = -1;
         SET v_errmsg = 'Email ID already Exists.';
         LEAVE sp_exit;
      end if;
   END;
   Select v_errcode as errcode,v_errmsg as errmsg;  
   
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_reseller_validate_partner_email` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_reseller_validate_partner_email`(mobileno VARCHAR(20),
  email VARCHAR(100))
BEGIN
  	
     DECLARE errcode INT;
     DECLARE errmsg VARCHAR(160);
  	
     sp_exit:
     BEGIN
        set errcode = 0;
        set errmsg = 'Not registered';
        IF EXISTS(Select 1 from Reseller a where IFNULL(a.Email,'') = email LIMIT 1) then 	  
           SET errcode = -1;
           SET errmsg = 'Email Already Registered';
           LEAVE sp_exit;
        end if;
        IF EXISTS(Select 1 from Reseller a where a.Mobile = mobileno LIMIT 1) then 	  
           SET errcode = -1;
           SET errmsg = 'Mobile Number already registered';
           LEAVE sp_exit;
        end if;
 	
 
     END;
     SELECT errcode AS errcode, errmsg as errmsg;
  	
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_reseller_variable_percentage_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_reseller_variable_percentage_info`(reseller_id INT,
   ID INT ,
   between_from INT,
   between_to INT,
   apply_per FLOAT,
   processtype INT, 
   incentive_type INT,
   fixed_percentage FLOAT,
   var_percentage FLOAT)
SWL_return:
   Begin
   
      DECLARE errcode INT;
      DECLARE errmsg VARCHAR(30);
   	
      DECLARE fixed_per FLOAT;
      DECLARE inc_type INT; 
      DECLARE Fk_Reseller_Id INT; 
      DECLARE fk_role_id INT;
      DECLARE var_inc_per FLOAT;
      DECLARE SwRowCount INT;
      DECLARE default_int_val int;
   	
      IF ID is null					then set ID = 0;				END IF;
      IF between_from is null		then set between_from = 0;		END IF;
      IF between_to is null			then set between_to = 0;		END IF;
      IF apply_per is null			then set apply_per = 0;			END IF;
      IF incentive_type is null		then set incentive_type = 0;    END IF;
      IF fixed_percentage is null	then set fixed_percentage = 0;	END IF;
      IF var_percentage is null		then set var_percentage = 0;    END IF;
      
      set default_int_val = 0 ; 
   
      sp_exit:
      BEGIN
         IF ID is null				then set ID = 0;				END IF;
         IF between_from is null		then set between_from = 0;		END IF;
         IF between_to is null		then set between_to = 0;		END IF;
         IF apply_per is null		then set apply_per = 0;			END IF;
         IF incentive_type is null	then set incentive_type = 0;	END IF;
         IF fixed_percentage is null	then set fixed_percentage = 0;	END IF;
         IF var_percentage is null	then set var_percentage = 0;	END IF;
   
         set errcode = -1;
         set errmsg = 'Failure';
   	
   	
         SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
         select Fk_Reseller_Id INTO Fk_Reseller_Id from Reseller a where a.Reseller_id = reseller_id;
         SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   
         SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
         select fk_role_id INTO fk_role_id from Reseller a where a.Reseller_id = Fk_Reseller_Id;
         SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   	
   	
   		Drop TEMPORARY table IF EXISTS tt_temp_child_reseller_id;
   		create TEMPORARY table tt_temp_child_reseller_id
   		(
   			reseller_id INT
   		);
     
   	
   		CALL sme_reseller_get_subordinates_list_new(reseller_id);
	
   
   		insert into tt_temp_child_reseller_id(reseller_id)
   		select a.reseller_id from tt_new_reseller_id a;
   
       
         If processtype = 1 then
   	
            SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
            select fixed_inc_per, Inc_Tier_Type INTO fixed_per, inc_type from Reseller a where a.Reseller_id = reseller_id;
            SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   
            SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;			
            select Tier_Id as ID, cast(Create_By as SIGNED INTEGER) as reseller_id,cast(Tier_min as SIGNED INTEGER) as between_from, 
   				cast(Tier_To as SIGNED INTEGER) between_to,Commission as apply_per,IFNULL(fixed_per,0) as fixed_per,
                 IFNULL(inc_type,default_int_val) as inc_type,
   				IFNULL(varaible_per,default_int_val) as varaible_per
            from sme_Reseller_Tier  where Create_By = reseller_id;
   
            SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
            If found_rows() > 0 then
   		
               set errcode = 0;
               set errmsg = 'success';
   
   			Drop TEMPORARY table IF EXISTS tt_temp_child_reseller_id;
   
               select errcode as errcode,errmsg as errmsg;
               LEAVE SWL_return;
   
            End if;
         End if;
   
         If processtype = 2 then
   	
   		insert into sme_Reseller_Tier(Create_By,Tier_min,Tier_To,Commission,Create_date,varaible_per,Tier_type)
   		values(reseller_id,between_from,between_to,apply_per,CURRENT_TIMESTAMP,var_percentage,incentive_type);
   		
            Set ID  = LAST_INSERT_ID();
   
   			if ROW_COUNT() > 0 then
   		
   				set errcode = 0;
   				set errmsg = 'Inserted';
   			End if;
               
            if errcode = 0 then
   		
			update Reseller a set fixed_inc_per = fixed_percentage, var_inc_per = var_percentage, Inc_Tier_Type = incentive_type 
   			where a.Reseller_id = reseller_id;
   
               if fk_role_id = 2 then
   			
                  update Reseller a set parent_rem_fixed_per = fixed_inc_per - (fixed_percentage + var_percentage)
                  where a.Reseller_id = Fk_Reseller_Id;
               end if;
   
               SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
               select fixed_inc_per, var_inc_per INTO fixed_per,var_inc_per from Reseller a where a.Reseller_id = Fk_Reseller_Id;
               SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   
               update Reseller a set a.parent_rem_fixed_per = fixed_per - (fixed_percentage + var_percentage)
               where a.Reseller_id in(select b.reseller_id from tt_temp_child_reseller_id b where b.reseller_id <> reseller_id);
   
               Drop TEMPORARY table IF EXISTS tt_temp_child_reseller_id;
   
            End if;
            LEAVE sp_exit;
         End if;
   
         If processtype = 3 then
   	
            update sme_Reseller_Tier
            set Tier_min = between_from,Tier_To = between_to,Commission = apply_per,
            varaible_per = var_percentage,Tier_type = incentive_type,last_Update = CURRENT_TIMESTAMP
            where Create_By = reseller_id and Tier_Id = ID;
            if ROW_COUNT() > 0 then
   		
               set errcode = 0;
               set errmsg = 'Updated';
            end if;
            if errcode = 0 then
   		
               update Reseller a set fixed_inc_per = fixed_percentage,var_inc_per = case when IFNULL(var_percentage,0) > 0 then var_percentage else var_inc_per end,Inc_Tier_Type = incentive_type where a.Reseller_id = reseller_id;
               if fk_role_id = 2 then
   			
                  update Reseller a set parent_rem_fixed_per = fixed_inc_per - (fixed_percentage + IFNULL(var_percentage,0))
                  where a.Reseller_id = Fk_Reseller_Id;
               end if;
               SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
               select fixed_inc_per, var_inc_per INTO fixed_per, var_inc_per from Reseller a where a.Reseller_id = Fk_Reseller_Id;
               SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
               update Reseller a set parent_rem_fixed_per = fixed_per - (fixed_percentage + var_percentage)
               where a.reseller_id in(select b.reseller_id from tt_temp_child_reseller_id b where b.reseller_id <> reseller_id);
               drop TEMPORARY table IF EXISTS tt_temp_child_reseller_id;
            end if;
            LEAVE sp_exit;
         end if;
         If processtype = 4 then
   	
            Delete from sme_Reseller_Tier where Create_By = reseller_id and Tier_Id = ID;
            
            if ROW_COUNT() > 0 then
   		
               set errcode = 0;
               set errmsg = 'Deleted';
               LEAVE sp_exit;
            end if;
         end if;
         if  processtype = 5 then
   	
            update Reseller a set fixed_inc_per = fixed_percentage,var_inc_per = var_percentage,Inc_Tier_Type = incentive_type
            where a.Reseller_id = reseller_id;
            if ROW_COUNT() > 0 then
   		
               set errcode = 0;
               set errmsg = 'Success';
               LEAVE sp_exit;
            end if;
         end if;
         if processtype = 6 then
   	
            SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
            Select fixed_inc_per as fixed_per,var_inc_per as varaible_per,IFNULL(Inc_Tier_Type,default_int_val) as inc_type  
            from Reseller a
            where a.Reseller_id = reseller_id;
            SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
         end if;
      END sp_exit;
      select errcode as errcode,errmsg as errmsg,ID as ID; 
   End SWL_return ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_res_portal_dashboard_overview` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_res_portal_dashboard_overview`()
BEGIN


 
	
           
   DECLARE v_new_customers INT;
   DECLARE v_new_orders INT; 
   DECLARE v_internal_sales FLOAT;
   DECLARE v_external_sales FLOAT;
 
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   count(1) INTO v_new_customers from reseller_company  a 
   Join Reseller b  on a.reseller_id = b.Reseller_id where
   EXTRACT(MONTH FROM a.create_date) = EXTRACT(MONTH FROM TIMESTAMPADD(MONTH,0,CURRENT_TIMESTAMP)) and
   EXTRACT(YEAR FROM a.create_date) = EXTRACT(YEAR FROM TIMESTAMPADD(YEAR,0,CURRENT_TIMESTAMP));
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
	 
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   count(b.Order_Id) INTO v_new_orders from reseller_company a 
   Join Res_Comp_Device_Order b  on a.Pk_rs_cmpid = b.Fk_rs_cmpid
   Join res_ur_ecom_pymt_dtls c  on b.Order_Id = Orderid where
   c.Pay_Status = 'Success';
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
	 
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   sum(IFNULL(Pay_Amount,0)) INTO v_internal_sales from  res_ur_ecom_pymt_dtls a 
   Join reseller_company b  on a.comp_id = b.Pk_rs_cmpid where Pay_Status = 'Success' and b.country in('UK','United Kingdom');
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
	 
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   sum(IFNULL(Pay_Amount,0)) INTO v_external_sales from  res_ur_ecom_pymt_dtls a 
   Join reseller_company b  on a.comp_id = b.Pk_rs_cmpid where Pay_Status = 'Success' and b.country not in('UK','United Kingdom');
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
	 
   select v_new_customers New_customers,v_new_orders New_orders,IFNULL(v_internal_sales,0) Internal_sales,IFNULL(v_external_sales,0) External_sales;
 
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_res_update_company_dtls` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_res_update_company_dtls`(Pk_rs_cmpid INT,  
 Reseller_id INT,  
 First_name VARCHAR(150),  
 Last_name VARCHAR(150),  
 Title VARCHAR(5),  
 Company_name VARCHAR(60),  
 Address_1 VARCHAR(100),  
 Address_2 VARCHAR(100),  
 City VARCHAR(60),  
 State VARCHAR(60),  
 Zip_code VARCHAR(8),  
 Country VARCHAR(30),  
 Phone_no VARCHAR(18),  
 Mobile_no VARCHAR(18),  
 Email VARCHAR(100),  
 Status INT)
BEGIN
   
    DECLARE v_errcode INT;    
    DECLARE v_errmsg VARCHAR(250);
    DECLARE v_comp_ID INT;    
   
       
    sp_exit:BEGIN
    
       IF not EXISTS(SELECT  1  from reseller_company a where a.email = Email and a.Pk_rs_cmpid = Pk_rs_cmpid LIMIT 1) 
       then 
          SET v_errcode = -1;
          SET v_errmsg = 'Email ID not exists.';
          LEAVE sp_exit;
       end if;
       
       IF  EXISTS(SELECT  1  from reseller_company  a where IFNULL(a.phone,'') = Phone_no
       and a.Pk_rs_cmpid <> Pk_rs_cmpid LIMIT 1)  and IFNULL(Phone_no,'') <> '' 
       then 
          SET v_errcode = -1;
          SET v_errmsg = 'Already registered mobile number.';
          LEAVE sp_exit;
       end if;
       
       IF  EXISTS(SELECT  1  from reseller_company a where IFNULL(a.mobileno,'') = Mobile_no
       and a.Pk_rs_cmpid <> Pk_rs_cmpid LIMIT 1)  and IFNULL(Mobile_no,'') <> '' 
       then 
          SET v_errcode = -1;
          SET v_errmsg = 'Already registered mobile number.';
          LEAVE sp_exit;
       end if;
       
       SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
       select   Vpcp_Company_Id INTO v_comp_ID from reseller_company a where a.Pk_rs_cmpid = Pk_rs_cmpid;
       
       SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
     
       
       Update reseller_company a Set a.first_name = First_name, a.last_name = Last_name, a.Title = Title,
       a.company_name = Company_name, a.address_1 = Address_1, a.address_2 = Address_2, a.city = City,
       a.state = State, a.zip_code = Zip_code, a.country = Country, a.phone = Phone_no,
       a.mobileno = Mobile_no, a.email = Email, a.status = Status Where a.Reseller_Id = Reseller_id  
       AND a.Pk_rs_cmpid = Pk_rs_cmpid;
       
       UPDATE reseller_company a Join unifiedring.UR_ECom_Company b on a.cnt_ref_id = Comp_ContactId join
       unifiedring.UR_ECom_User_Dtl c on b.Comp_ContactId = c.UR_ECom_Id set b.Comp_Name = Company_name,
       b.Comp_Address = Address_1,b.Comp_Building = Address_2,b.Comp_PostCode = Zip_code,b.Comp_Street = City,
       b.Comp_City = State,b.Comp_Country = Country
       where a.Reseller_Id = Reseller_id  AND a.Pk_rs_cmpid = Pk_rs_cmpid;
       
       UPDATE reseller_company a Join unifiedring.UR_ECom_Company b on a.cnt_ref_id = Comp_ContactId join
       unifiedring.UR_ECom_User_Dtl c on b.Comp_ContactId = c.UR_ECom_Id set c.UR_ECom_Name = Company_name,
       c.UR_ECom_Phone_Number = Phone_no,c.UR_ECom_Status = Status,c.UR_ECom_Email = Email
       where a.Reseller_Id = Reseller_id  AND a.Pk_rs_cmpid = Pk_rs_cmpid;
       
       UPDATE reseller_company a join unifiedring.vbcp_company d
       on  a.Vpcp_Company_Id = d.company_id set d.company_name = Company_name,
       d.account_status = case when Status = 1 then 'Active' else 'Inactive' end,d.postcode = Zip_code,d.address1 = Address_1,
       d.address2 = Address_2,d.city = City,d.email = Email,d.country = Country where a.Reseller_Id = Reseller_id  
       AND a.Pk_rs_cmpid = Pk_rs_cmpid;
       
       IF found_rows() > 0 
       then  
          Set v_errcode = 0;
          Set v_errmsg = 'Company details updated Successfully.';
       end if;
    END;
    
    select v_errcode as errcode,v_errmsg as errmsg;    
      
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_res_update_emgncy_dtls` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_res_update_emgncy_dtls`(
 Pk_rs_cmpid INT,  
 Emgncy_Contact_name VARCHAR(50),  
 Emgncy_address_1 VARCHAR(50),  
 Emgncy_address_2 VARCHAR(50),  
 Emgncy_state VARCHAR(30),  
 Emgncy_city VARCHAR(30),  
 Emgncy_country VARCHAR(30),  
 Emgncy_phone_no VARCHAR(30),  
 Emgncy_email VARCHAR(30),  
 Emgncy_zip_code VARCHAR(30))
BEGIN
 
    DECLARE v_errcode INT;    
    DECLARE v_errmsg VARCHAR(250);   
    
    sp_exit:BEGIN
    
       IF NOT EXISTS(SELECT  1  from Reseller_Comp_Emg_info  WHERE Fk_Pk_rs_cmpid = Pk_rs_cmpid LIMIT 1) 
       then
     
          Set v_errcode = -1;
          Set v_errmsg = 'Emergency details not found.';
          LEAVE sp_exit;
       end if;
       
       UPDATE reseller_company a join unifiedring.ur_myacc_emergency_contact_details c on a.Vpcp_Company_Id = c.company_id set c.firstname = Emgncy_Contact_name,c.Address_Line_1 = Emgncy_address_1,
       c.Address_Line_2 = Emgncy_address_2,c.City = Emgncy_city,c.Telephone_number = Emgncy_phone_no where  a.Pk_rs_cmpid = Pk_rs_cmpid;
       
       UPDATE reseller_company a join Reseller_Comp_Emg_info b on a.Pk_rs_cmpid = b.Fk_Pk_rs_cmpid 
       set b.Contact_name = Emgncy_Contact_name,b.Address1 = Emgncy_address_1,b.Address2 = Emgncy_address_2,
       b.State = Emgncy_state,b.City = Emgncy_city,
       b.Country = Emgncy_country,b.Phone_No = Emgncy_phone_no,b.Email_Id = Emgncy_email,
       b.postcode = Emgncy_zip_code
       where a.Pk_rs_cmpid = Pk_rs_cmpid;
       
       IF found_rows() > 0 
       then
   
          Set v_errcode = 0;
          Set v_errmsg = 'Emergency details updated Successfully.';
       end if;
       
    END sp_exit;
    
    select v_errcode as errcode,v_errmsg as errmsg;    
      
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_UpdateCustDirDocSignStatus_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_UpdateCustDirDocSignStatus_info`(
 	p_reseller_id int,
 	p_id int,
     p_doc_url text,
     p_docusign_status int,
 	process_type int 
 )
Begin
 
 	declare v_errcode int default -1;
     declare v_errmsg varchar(100) default 'failure';
 
 	if process_type = 1 Then    
 		update reseller_partner_order_form set customer_url = p_doc_url,docusign_status = p_docusign_status, customer_update_date = current_timestamp where id = p_id and reseller_id = p_reseller_id;
         if row_count() > 0 then set v_errcode = 0; set v_errmsg = 'Updated'; End if;
 	End if;
     
 	if process_type = 2 Then
 		update reseller_partner_order_form set docusign_status = p_docusign_status, customer_update_date = current_timestamp where customer_url = p_doc_url;
         if row_count() > 0 then set v_errcode = 0; set v_errmsg = 'Updated'; End if;
 	End if;
     
 	if process_type = 3 Then
 		update reseller_partner_order_form set customer_url = p_doc_url,docusign_status = p_docusign_status, director_update_date = current_timestamp where id = p_id and reseller_id = p_reseller_id;
         if row_count() > 0 then set v_errcode = 0; set v_errmsg = 'Updated'; End if;    
 	End if;
     
 	if process_type = 4 Then
 		update reseller_partner_order_form set docusign_status = p_docusign_status, director_update_date = current_timestamp where customer_url = p_doc_url;
         if row_count() > 0 then set v_errcode = 0; set v_errmsg = 'Updated'; End if;
 	End if;
 
 
 	select v_errcode as errcode, v_errmsg as errmsg;
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_update_partner_order_form_status` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_update_partner_order_form_status`(
p_company_id int,
p_status int
)
begin

	update reseller_partner_order_form set status = p_status where company_id = p_company_id;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_update_reseller_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_update_reseller_details`(Reseller_id INT,
Firstname VARCHAR(100),
Lastname VARCHAR(100),
Email_Address VARCHAR(100),
Mobile_number VARCHAR(20),
Work_number VARCHAR(20),
Company_address1 VARCHAR(500),
Company_address2 VARCHAR(500),
Zipcode VARCHAR(50),
City VARCHAR(100),
Country VARCHAR(100),
Account_Number VARCHAR(25),
Acc_Holder_Name VARCHAR(50),
Sort_code VARCHAR(25),
KYC_id INT)
BEGIN

   DECLARE errcode INT;  
   DECLARE errmsg VARCHAR(250);  

   update Reseller a
   set a.Firstname = Firstname,a.Lastname = Lastname,a.Email = Email_Address,
   a.Mobile = Mobile_number,a.Phone = Work_number,a.Address1 = Company_address1,
   a.Address2 = Company_address2,a.Zipcode = Zipcode,a.City = City,
   a.Country = Country
   where a.Reseller_Id = Reseller_id;
    
   IF ROW_COUNT() > 0 then
	  
      Set errcode = 0;
      Set errmsg = 'Details updated Successfully.';
   end if;  

   select errcode as errcode,errmsg as errmsg;  
   
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_update_reseller_status` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_update_reseller_status`(
 Reseller_id INT,
 status INT
 )
begin
 
    DECLARE v_errcode INT;  
    DECLARE v_errmsg VARCHAR(250);
  
    Set v_errcode = -1;  
    Set v_errmsg = 'Reseller details not found.';  
  
    IF EXISTS(SELECT  1 FROM Reseller A WHERE A.Reseller_Id = Reseller_id LIMIT 1) then
 	 
       UPDATE Reseller a
       set a.status = status
       where a.Reseller_Id = Reseller_id;
    end if;
 	
    IF ROW_COUNT() > 0 then
 	  
       Set v_errcode = 0;
       Set v_errmsg = 'Success';
    end if;  
 
    select v_errcode as errcode,v_errmsg as errmsg;  
    
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sme_validate_login_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sme_validate_login_details`(Reseller_id VARCHAR(100),  
      Password VARCHAR(20),  
      login_ip_address VARCHAR(100))
SWL_return:BEGIN
      
         DECLARE v_errcode INT;  
         DECLARE v_errmsg VARCHAR(250);  
         DECLARE v_found INT;  
         DECLARE v_rs_password VARCHAR(20);  
         DECLARE v_status INT; 
         DECLARE v_type INT; 
         DECLARE default_int_val int;
         
         set default_int_val = 0 ;
         
         sp_err : BEGIN
         
            If Reseller_id REGEXP '^[0-9,]?$' 
            then 
               set v_type = 1;
            else
               set v_type = 2;
            end if;
   
            set v_errcode = -1;
            set v_errmsg = 'Failure to get Login.';
            set v_found = 0;
            
            if IFNULL(Reseller_id,'') = '' OR IFNULL(Password,'') = '' 
            then 
               set v_errcode = -1;
               set v_errmsg = 'Mandatory Fields are Missing!';
               LEAVE sp_err;
            end if;
            
            if v_type = 1 
            then     
               SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
               select   1, a.password, IFNULL(Status,0) INTO v_found,v_rs_password,v_status from  Reseller a
               where a.Reseller_id = Reseller_id LIMIT 1;
               SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
            end if;
            
            if v_type = 2 
            then     
               SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
               select 1,a.password, IFNULL(Status,0) INTO v_found,v_rs_password,v_status from Reseller a where a.Email = Reseller_id LIMIT 1;
               SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
            end if;
            
            if v_found = 0 
            then 
               set v_errcode = -1;
               set v_errmsg = 'UserName is Invalid!';
               LEAVE sp_err;
            end if;
   
            if v_found = 1 and v_rs_password <> Password 
            then 
               set v_errcode = -1;
               set v_errmsg = 'Password is Invalid!';
               LEAVE sp_err;
            end if;
            
            IF v_status = 0 
            then 
               set v_errcode = -1;
               set v_errmsg = 'Your account is inactive.Please contact system administrator!';
               LEAVE sp_err;
            end if;
            
            IF v_status = 3 
            then 
               set v_errcode = -1;
               set v_errmsg = 'Your account is deleted.Please contact system administrator!';
               LEAVE sp_err;
            end if;
            
            SET v_errcode = 0;
            SET v_errmsg = 'Success';
            
            if v_type = 1 
            then 
               UPDATE Reseller a SET a.Last_login_date = CURRENT_TIMESTAMP, a.Last_login_ip = login_ip_address
               WHERE a.Reseller_id = Reseller_id;
            end if;
      	
            
            if v_type = 2 
            then 
               UPDATE Reseller b SET b.Last_login_date = CURRENT_TIMESTAMP,b.Last_login_ip = login_ip_address
               WHERE b.Email = Reseller_id;
            end if;
            
            SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
				SELECT a.Reseller_id,IFNULL(a.Title,'') as Title,IFNULL(Firstname,'') as Firstname,
						IFNULL(Lastname,'') as Lastname,IFNULL(Company_name,'') as Company_name,IFNULL(Address1,'') as Address1,
						IFNULL(Address2,'') as Address2,IFNULL(City,'') as City,IFNULL(Statename,'') as Statename,
						IFNULL(Zipcode,'') as Zipcode,IFNULL(Country,'') as Country,IFNULL(Phone,'') as Phone,
						IFNULL(Mobile,'') as Mobile,IFNULL(Email,'') as Email,IFNULL(a.Fk_Reseller_Type,default_int_val) as Fk_Reseller_Type,
						b.Reseller_Type as Reseller_Type,IFNULL(a.Fk_certification_Id,default_int_val) as Fk_certification_Id,
						IFNULL(c.certification,'') as certification,IFNULL(a.Fk_product_id,default_int_val) as Fk_product_id,
						IFNULL(d.product_name,'') as product_name,IFNULL(a.Fk_Vertical_id,default_int_val) as Fk_Vertical_id,
						IFNULL(e.Vertical_name,'') as Vertical_name,IFNULL(a.Fk_Stategy_id,default_int_val) as Fk_Stategy_id,
						IFNULL(f.Stategy_name,'') as Stategy_name,IFNULL(a.Fk_Emp_Size_id,default_int_val) as Fk_Emp_Size_id,
						IFNULL(g.Emp_size_name,'') as Emp_size_name,IFNULL(a.Fk_Cust_Size_id,default_int_val) as Fk_Cust_Size_id,
						IFNULL(k.Cust_size_name,'') as Cust_size_name,IFNULL(a.Fk_Comp_Size_id,default_int_val) as Fk_Comp_Size_id,IFNULL(j.Comp_size_name,'') as Comp_size_name,
						IFNULL(a.Fk_Part_prog_id,default_int_val) as Fk_Part_prog_id,IFNULL(i.Partner_prog_name,'') as Partner_prog_name,
						l.status as Reseller_Status,IFNULL(a.Client_ip,'') as Client_ip,v_errcode as errcode,v_errmsg as errmsg,
						Last_login_date,IFNULL(Last_login_ip,'') AS Last_login_ip,IFNULL(m.role_name,'') as role_name,
						IFNULL(a.fk_role_id,default_int_val) as Role_Id,Fk_Reseller_Id as Fk_Reseller_Id,
						IFNULL(a.Hubspot_contactid,default_int_val) as Hubspot_contactid,
						unifiedring.fn_check_plan_exclusive(fk_role_id) as is_plan_exclusive,
						a.partner_type,
                        a.payment_method,
                        a.payment_days
				from  Reseller a
				LEFT JOIN Reseller_type_Master b     on a.Fk_Reseller_Type = b.Pk_Reseller_Type
				LEFT JOIN Reseller_certification_Master c on a.Fk_certification_Id = c.Pk_certification_id
				LEFT JOIN resell_product_Master d    on a.Fk_product_id = d.product_id
				LEFT JOIN Vertical_Master e    on a.Fk_Vertical_id = e.Vertical_id
				LEFT JOIN Sales_Stategy_Master f     on a.Fk_Stategy_id = f.Stategy_id
				LEFT JOIN Employee_Size_Master g     on a.Fk_Emp_Size_id = g.Pk_Emp_Size_Id
				LEFT JOIN Partner_Program_Master i    on  a.Fk_Part_prog_id = i.Pk_Program_id
				LEFT JOIN Sell_Company_Size_Master j on  a.Fk_Comp_Size_id = j.Pk_company_size_id
				LEFT JOIN Cust_Size_info_Master k    on  a.Fk_Cust_Size_id = k.Pk_cust_Size_Id
				JOIN Reseller_status_ref l         on a.Status = l.status_id
				JOIN Reseller_role m     on a.fk_role_id = m.Pk_role_id
				where cast(a.Reseller_id as CHAR(30)) = Reseller_id or a.Email = Reseller_id;
            SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
            LEAVE SWL_return;
         END;
         select v_errcode as errcode,v_errmsg as errmsg;   
      END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sms_reseller_get_plan_type` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sms_reseller_get_plan_type`()
BEGIN

  
   
   
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select Typeid,TypeName from reseller_plan_type
   Where status = 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ur_assign_comminsion_to_reseller` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ur_assign_comminsion_to_reseller`(  
 company_id int,  
 Pay_Reference_No varchar(50),  
 amount double ,  
 Plan  int,  
 duration int,  
 Plan_amunt double)
sp_lbl: BEGIN  

  declare v_reseller_id int;   
  declare v_Type_ID  int;   
  declare v_plan_name varchar(250);  
  declare v_res_compid int;
  declare default_int_val int;
  
  set default_int_val = 0 ; 

  select a.reseller_id,a.Pk_rs_cmpid into v_reseller_id, v_res_compid from reseller_company a where a.Vpcp_Company_Id = company_id;  
    
  if ifnull(v_reseller_id,0) = 0  then  
  	leave sp_lbl ;
  end if; 
  
	  insert into Reseller_Payment_Info(Paydate,Pay_Reference,Pay_Status,Reseller_Id,Vpcp_Comp_Id,Res_Comp_Id,Pay_Amount,Plan_amunt)  
	  select current_timestamp(),Pay_Reference_No,'Success',v_reseller_id,company_id,v_res_compid,amount,Plan_amunt;

  select b.Pln_Name into v_plan_name from unifiedring.UR_ECom_Plan b where b.Pln_Idx=Plan limit 1 ;  


  if ifnull(v_reseller_id,0)>0 then  
	   call sme_reseller_get_plan_type(v_plan_name,duration,ifnull(v_Type_ID,default_int_val));

	   call sme_reseller_new_commisson_incentive( v_reseller_id,amount,company_id,Pay_Reference_No,'Bill Payment',v_Type_ID);  
       
  end if;   
    
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ur_myaccount_whatsapp_integration_insert` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ur_myaccount_whatsapp_integration_insert`(
p_company_name 				INT,	
p_company_id   				INT,
p_reg_company_name 			VARCHAR(50),		
p_business_vertical 		VARCHAR(100),		
p_company_website 			VARCHAR(100),		
p_business_unit 			VARCHAR(100),	
p_contact_name 				VARCHAR(50),	
p_contact_designation 		VARCHAR(50),			
p_contact_email_address 	VARCHAR(50),			
p_launch_regions 			VARCHAR(50),	
p_whatsapp_phone_num 		VARCHAR(20), 		
p_whatsapp_conversation_volume 	VARCHAR(250),			
p_disp_acc_name 			VARCHAR(50),	
p_fb_business_mngr_id 		VARCHAR(50),			
p_fb_business_mngr_name 	VARCHAR(50),			
p_is_approved 				INT,	
p_createdate 				DATETIME

)
begin

DECLARE v_errcode INT;
DECLARE v_errmsg  VARCHAR(50);
DECLARE v_curdate DATETIME;

SET v_curdate = now();

		Insert into ur_myaccount_social_media_whatsapp_integration(company_name ,company_id ,reg_company_name ,business_vertical,company_website,business_unit,contact_name,contact_designation,contact_email_address,launch_regions,
				whatsapp_phone_num,whatsapp_conversation_volume,disp_acc_name,fb_business_mngr_id,fb_business_mngr_name,createdate )
		values(p_company_name,p_company_id,p_reg_company_name,p_business_vertical,p_company_website,p_business_unit,p_contact_name,p_contact_designation,p_contact_email_address,p_launch_regions,
				p_whatsapp_phone_num,p_whatsapp_conversation_volume,p_disp_acc_name,p_fb_business_mngr_id,p_fb_business_mngr_name,v_curdate);
                
		if row_count()>0
        then
        SET v_errcode = 0;
        SET v_errmsg  = 'Inserted Successfully';
        end if;
SELECT v_errcode as errcode , v_errmsg as errmsg ;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ur_myacc_insert_sales_user_campaign_comments_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ur_myacc_insert_sales_user_campaign_comments_info`(
p_campaign_id int,
p_userformId  int,
p_comments text
)
Begin

	declare v_errcode int default -1;
    declare v_errmsg varchar(50) default 'Failure';
    
		insert into ur_myacc_sales_user_campaign_dtl(campaign_id, userId, comments)
        values(p_campaign_id, p_userformId, p_comments);
        
        if row_Count()>0 then
			set v_errcode = 0;
            set v_errmsg = 'Inserted';
        End if;

	select v_errcode as errcode, v_errmsg as errmsg;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ur_tms_get_reseller_discount_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ur_tms_get_reseller_discount_info`(product_id INT)
BEGIN


	
	
   CALL unifiedring.unifiedring_get_reseller_discount_info(product_id);
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ur_update_device_purchase_to_company` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ur_update_device_purchase_to_company`(company_id INT,
 pk_res_compid INT)
SWL_return:
 BEGIN

    DECLARE order_id INT; 
    DECLARE res_ordeR_id INT; 
 	
    DECLARE sd_id INT;

    IF IFNULL(company_id,0) = 0 then
       LEAVE SWL_return;
    end if;
 		
 
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select   a.Order_Id INTO res_ordeR_id from  Res_Comp_Device_Order a
    join  Res_device_order_item b on a.Order_Id = b.order_id where  a.Fk_rs_cmpid = pk_res_compid and  IFNULL(b.price,0) > 0;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 	
    if IFNULL(res_ordeR_id,0) = 0 then
       LEAVE SWL_return;
    end if;
 
    insert into unifiedring.ur_device_order(company_id,referenceid,tot_phone_charge,tot_discount, tot_tax_fee,tot_charge,createdate,order_source)
    select  b.Vpcp_Company_Id,paid_Reference,a.tot_phone_charge,a.tot_discount,
 	a.tot_tax_fee,a.tot_charge,CURRENT_TIMESTAMP,'PartnerPortal' from Res_Comp_Device_Order a
    join reseller_company b on a.Fk_rs_cmpid = b.Pk_rs_cmpid  where b.Vpcp_Company_Id = company_id;
 	
 	
    set order_id = LAST_INSERT_ID();
 	
 	
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    insert into unifiedring.ur_order_delivery_address(order_id,customer_name,address1,address2,city,postcode,country,
 	shipping_charge,shipping_tax_fee,email,mobileno,billing_type,company_name,state)
    select order_id order_id,customer_name,address1,address2,city,postcode,country,
 	shipping_charge,shipping_tax_fee,email,mobileno,billing_type,company_name,
 	state from Res_Order_delivery_address a
    where a.order_id = res_ordeR_id;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 	
 	
    set sd_id = LAST_INSERT_ID();
 	
    insert into  unifiedring.ur_device_order_item(order_id,sd_id,category,phone_id,phone_model,phone_desc,price,weight,
 		ean_no,quantity,status,inventory_id,discount_price,external_number,Vec_Device_Product_Id)
    select order_id,sd_id,category,phone_id,phone_model,phone_desc,price,
 	weight,ean_no,quantity,status,inventory_id,discount_price,
 	external_number,Vec_device_product_id from Res_device_order_item a where a.order_id = res_ordeR_id;
 	
 
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-21  9:53:13
