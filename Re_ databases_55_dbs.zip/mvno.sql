-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: mvno
-- ------------------------------------------------------
-- Server version	8.0.44-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `mvno`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `mvno` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `mvno`;

--
-- Table structure for table `multi_number_register`
--

DROP TABLE IF EXISTS `multi_number_register`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `multi_number_register` (
  `id` int NOT NULL AUTO_INCREMENT,
  `reg_number` varchar(20) NOT NULL,
  `svc_id` int NOT NULL,
  `status` int DEFAULT NULL,
  `account_type` int NOT NULL,
  `account_info` varchar(20) NOT NULL,
  `custcode` varchar(8) DEFAULT NULL,
  `batchcode` int DEFAULT NULL,
  `serialcode` int DEFAULT NULL,
  `joindate` datetime DEFAULT NULL,
  `stopdate` datetime DEFAULT NULL,
  `lastupdate` datetime DEFAULT NULL,
  `startdate` datetime DEFAULT NULL,
  `enddate` datetime DEFAULT NULL,
  `last_pay` datetime DEFAULT NULL,
  `due_pay` datetime DEFAULT NULL,
  `updateby` varchar(32) DEFAULT NULL,
  `paymode` int DEFAULT '1',
  `procesurl` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`reg_number`,`svc_id`,`account_type`,`account_info`),
  UNIQUE KEY `id` (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=5300 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `multi_number_subscription`
--

DROP TABLE IF EXISTS `multi_number_subscription`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `multi_number_subscription` (
  `msisdn_remote` varchar(20) NOT NULL,
  `svc_id` int NOT NULL,
  `status` int NOT NULL,
  `last_update` datetime(3) DEFAULT NULL,
  `expiry_date` varchar(10) DEFAULT NULL,
  `hlrdb_link` varchar(30) DEFAULT NULL,
  `msisdn_local` varchar(20) DEFAULT NULL,
  `custcode_local` varchar(8) DEFAULT NULL,
  `batchcode_local` int DEFAULT NULL,
  `serialcode_local` int DEFAULT NULL,
  `type` int DEFAULT NULL,
  `msisdn_pair` varchar(20) DEFAULT NULL,
  `last_unused` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`msisdn_remote`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `mvno_pstn_message_info`
--

DROP TABLE IF EXISTS `mvno_pstn_message_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mvno_pstn_message_info` (
  `smsid` int NOT NULL AUTO_INCREMENT,
  `sms_sender` varchar(30) DEFAULT NULL,
  `sms_receiver` varchar(30) DEFAULT NULL,
  `sms_text` longtext,
  `create_date` datetime(3) DEFAULT NULL,
  `status` int DEFAULT NULL,
  `tp_dcs` int DEFAULT NULL,
  `tp_udl` int DEFAULT NULL,
  `tp_sri` int DEFAULT NULL,
  PRIMARY KEY (`smsid`),
  KEY `idx1_mvno_pstn_message_info` (`sms_sender`,`status`),
  KEY `idx2_mvno_pstn_message_info` (`status`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `portin_promo`
--

DROP TABLE IF EXISTS `portin_promo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `portin_promo` (
  `sitecode` varchar(3) DEFAULT NULL,
  `promoid` int DEFAULT NULL,
  `promo_name` varchar(500) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `promotion_topup`
--

DROP TABLE IF EXISTS `promotion_topup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `promotion_topup` (
  `promoid` int NOT NULL,
  `promoname` varchar(32) NOT NULL,
  `promotype` int NOT NULL,
  `sitecode` varchar(5) NOT NULL,
  `startdate` datetime(3) NOT NULL,
  `enddate` datetime(3) NOT NULL,
  `extra_amount` double NOT NULL,
  `currcode` varchar(3) DEFAULT NULL,
  `max_counter` int DEFAULT NULL,
  `insertby` varchar(32) DEFAULT NULL,
  `comment` varchar(128) DEFAULT NULL,
  `minbal` double DEFAULT NULL,
  `cardid` int DEFAULT NULL,
  `vc_tariffclass` varchar(4) NOT NULL DEFAULT '*',
  `vc_price` float NOT NULL DEFAULT '0',
  `accum_extra_amount` float NOT NULL DEFAULT '0',
  `accum_delay` int NOT NULL DEFAULT '0',
  `accum_maxcounter` int NOT NULL DEFAULT '0',
  `custcode` char(8) NOT NULL DEFAULT '*',
  `batchcode` int NOT NULL DEFAULT '-1',
  `serialcode_fr` int NOT NULL DEFAULT '-1',
  `serialcode_to` int NOT NULL DEFAULT '-1',
  `status` int DEFAULT '0',
  `extra_minute` int NOT NULL DEFAULT '0',
  `esp_promoid` int DEFAULT NULL,
  `esp_promotype` int DEFAULT NULL,
  `param1` varchar(200) DEFAULT NULL,
  `updatemode` int DEFAULT '0',
  `packageid` int NOT NULL,
  `paymenttype` int NOT NULL DEFAULT '1',
  `calledbyapp` varchar(20) NOT NULL DEFAULT '*',
  `cc_amount` double NOT NULL DEFAULT '0',
  `cc_currcode` varchar(3) NOT NULL DEFAULT '*',
  `firstlocdate_fr` datetime(3) DEFAULT NULL,
  `firstlocdate_to` datetime(3) DEFAULT NULL,
  `topup_flag` int NOT NULL DEFAULT '-1',
  `isPortIn` int DEFAULT '0',
  `webregister_flag` int DEFAULT '0',
  `webregister_delay` int DEFAULT '0',
  `trffclass` varchar(4) NOT NULL DEFAULT '*',
  `topup_flag_info` int DEFAULT '-1',
  `bundle_id` int NOT NULL DEFAULT '0',
  `bundle_id_mode` int DEFAULT '0',
  `daycode` varchar(20) DEFAULT NULL,
  `package_trffclass` varchar(4) DEFAULT NULL,
  `max_counter_mode` int DEFAULT NULL,
  `portindate_fr` datetime(3) DEFAULT NULL,
  `portindate_to` datetime(3) DEFAULT NULL,
  `simtype` int DEFAULT NULL,
  `firsttopupdate_fr` datetime(3) DEFAULT NULL,
  `firsttopupdate_to` datetime(3) DEFAULT NULL,
  `simidtype` int NOT NULL DEFAULT '0',
  `firsttopupdate_delay_fr` int DEFAULT NULL,
  `firsttopupdate_delay_to` int DEFAULT NULL,
  `topup_flag_period` int DEFAULT NULL,
  `package_date_extension` int DEFAULT NULL,
  `referer_flag` int DEFAULT NULL,
  `max_amount` float DEFAULT NULL,
  `max_amount_mode` int DEFAULT NULL,
  `max_delay_mode` int DEFAULT NULL,
  `max_delay` int DEFAULT NULL,
  `accumulated_mode` int DEFAULT NULL,
  `accumulated_info` int DEFAULT NULL,
  `accumulated_amount` float DEFAULT NULL,
  `need_activation` int DEFAULT NULL,
  `max_counter_additional_amount` float DEFAULT NULL,
  `accumulated_delay` int DEFAULT NULL,
  `register_flag` int DEFAULT NULL,
  `register_startdate` datetime(3) DEFAULT NULL,
  `register_enddate` datetime(3) DEFAULT NULL,
  `bundle_groupid` int DEFAULT NULL,
  `bundle_groupid_ban` int DEFAULT NULL,
  `expdate_mode` int DEFAULT NULL,
  `expdate_param` varchar(25) DEFAULT NULL,
  `bundle_notif_mode` int DEFAULT NULL,
  `static_topup_date_to` datetime(3) DEFAULT NULL,
  `static_topup_delay` int DEFAULT NULL,
  `trfclass_groupid` int DEFAULT NULL,
  `max_counter_delay` int DEFAULT NULL,
  `prev_topup_usage` float DEFAULT NULL,
  `bv_price` float DEFAULT NULL,
  PRIMARY KEY (`promoid`,`sitecode`,`custcode`,`batchcode`,`serialcode_fr`,`serialcode_to`,`paymenttype`,`vc_tariffclass`,`vc_price`,`cc_amount`,`cc_currcode`,`calledbyapp`,`trffclass`,`bundle_id`,`simidtype`,`topup_flag`),
  KEY `idx1_promotion_topup` (`sitecode`,`custcode`,`batchcode`,`serialcode_fr`,`serialcode_to`,`startdate`,`enddate`,`paymenttype`,`vc_tariffclass`,`vc_price`,`cc_currcode`,`cc_amount`,`calledbyapp`,`firstlocdate_fr`,`firstlocdate_to`,`status`),
  KEY `idx4_promotion_topup` (`sitecode`,`custcode`,`batchcode`,`serialcode_fr`,`serialcode_to`,`paymenttype`,`vc_tariffclass`,`vc_price`,`cc_currcode`,`cc_amount`,`calledbyapp`,`firstlocdate_fr`,`firstlocdate_to`,`topup_flag`,`isPortIn`,`webregister_flag`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `reward_log`
--

DROP TABLE IF EXISTS `reward_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reward_log` (
  `logid` int NOT NULL AUTO_INCREMENT,
  `logdate` datetime(3) DEFAULT NULL,
  `resellerid` int DEFAULT NULL,
  `activationid` int DEFAULT NULL,
  `rewardid` int DEFAULT NULL,
  `topupid` int DEFAULT NULL,
  `mobileno` varchar(20) DEFAULT NULL,
  `custcode` varchar(8) DEFAULT NULL,
  `batchcode` int DEFAULT NULL,
  `serialcode` int DEFAULT NULL,
  `simtype` int DEFAULT NULL,
  `voucherid` int DEFAULT NULL,
  `rewardamount` float DEFAULT NULL,
  `rewardcurrency` varchar(3) DEFAULT NULL,
  `status` int DEFAULT '0',
  `message` varchar(64) DEFAULT NULL,
  `rewardtype` int DEFAULT NULL,
  `rewardinfo` varchar(64) DEFAULT NULL,
  `paymentType` int DEFAULT NULL,
  `paymentref` varchar(64) DEFAULT NULL,
  `subresellerid` int DEFAULT NULL,
  PRIMARY KEY (`logid`),
  KEY `idx101` (`logdate`,`resellerid`,`mobileno`),
  KEY `reward_log_idx1` (`custcode`,`batchcode`,`serialcode`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `reward_reseller`
--

DROP TABLE IF EXISTS `reward_reseller`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reward_reseller` (
  `rewardid` int NOT NULL,
  `resellerid` int NOT NULL,
  `rewardtype` int DEFAULT NULL,
  `totalreward` float DEFAULT '0',
  `currency` varchar(3) DEFAULT NULL,
  `counter` int DEFAULT NULL,
  `lastupdate` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`rewardid`,`resellerid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sms_campaign`
--

DROP TABLE IF EXISTS `sms_campaign`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sms_campaign` (
  `campaign_id` int NOT NULL,
  `campaign_type` int NOT NULL,
  `startdate` datetime(3) DEFAULT NULL,
  `enddate` datetime(3) DEFAULT NULL,
  `max_counter` int DEFAULT NULL,
  `max_counter_mode` int DEFAULT NULL,
  `sitecode` varchar(3) NOT NULL,
  `custcode` varchar(8) NOT NULL,
  `batchcode` int NOT NULL,
  `serialcode_fr` int NOT NULL,
  `serialcode_to` int NOT NULL,
  `status` int DEFAULT NULL,
  `sim_tariffclass` varchar(5) NOT NULL,
  `firstlocdate_fr` datetime(3) DEFAULT NULL,
  `firstlocdate_to` datetime(3) DEFAULT NULL,
  `sms_notification` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`campaign_id`,`campaign_type`,`sitecode`,`custcode`,`batchcode`,`serialcode_fr`,`serialcode_to`,`sim_tariffclass`),
  KEY `idx1_sms_campaign` (`sitecode`,`custcode`,`batchcode`,`serialcode_fr`,`serialcode_to`,`sim_tariffclass`,`firstlocdate_fr`,`firstlocdate_to`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sms_campaign_dest`
--

DROP TABLE IF EXISTS `sms_campaign_dest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sms_campaign_dest` (
  `campaign_id` int NOT NULL,
  `prefix` varchar(30) NOT NULL,
  `sitecode` varchar(3) NOT NULL,
  PRIMARY KEY (`campaign_id`,`prefix`,`sitecode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sms_campaign_log`
--

DROP TABLE IF EXISTS `sms_campaign_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sms_campaign_log` (
  `logid` int NOT NULL AUTO_INCREMENT,
  `logdate` datetime(3) DEFAULT NULL,
  `campaign_id` int DEFAULT NULL,
  `campaign_type` int DEFAULT NULL,
  `msisdn` varchar(16) DEFAULT NULL,
  `custcode` varchar(8) DEFAULT NULL,
  `batchcode` int DEFAULT NULL,
  `serialcode` int DEFAULT NULL,
  `prefix` varchar(30) DEFAULT NULL,
  `sms_notification` varchar(255) DEFAULT NULL,
  UNIQUE KEY `logid` (`logid`),
  KEY `idx1_sms_campaign_log` (`msisdn`),
  KEY `idx2_sms_campaign_log` (`custcode`,`batchcode`,`serialcode`),
  KEY `idx3_sms_campaign_log` (`campaign_id`,`campaign_type`,`custcode`,`batchcode`,`serialcode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `topup_activity_register`
--

DROP TABLE IF EXISTS `topup_activity_register`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `topup_activity_register` (
  `mobileno` varchar(20) NOT NULL,
  `auto_topup` int DEFAULT NULL,
  `auto_topup_disable_by` varchar(150) DEFAULT NULL,
  `auto_topup_disable_date` datetime(3) DEFAULT NULL,
  `auto_topup_enable_by` varchar(150) DEFAULT NULL,
  `auto_topup_enable_date` datetime(3) DEFAULT NULL,
  `no_of_topup` int DEFAULT NULL,
  `first_topup_amount` float DEFAULT NULL,
  `first_topup_method_used` varchar(150) DEFAULT NULL,
  `first_time_topup_date` datetime(3) DEFAULT NULL,
  `latest_auto_topup_attempt_date` datetime(3) DEFAULT NULL,
  `latest_auto_topup_attempt_failure_reason` varchar(100) DEFAULT NULL,
  `latest_auto_topup_attempt_status` varchar(150) DEFAULT NULL,
  `status` int DEFAULT NULL,
  `insert_date` datetime(3) DEFAULT NULL,
  `last_topup_date` datetime(3) DEFAULT NULL,
  `latest_topup_amount` float DEFAULT NULL,
  `latest_topup_type` varchar(250) DEFAULT NULL,
  `last_topup_vou_method` varchar(100) DEFAULT NULL,
  `lat_topup_method_used` varchar(100) DEFAULT NULL,
  `last_topup_payment_ref` varchar(100) DEFAULT NULL,
  `total_revenue` float DEFAULT NULL,
  `int_topup_network_name` varchar(100) DEFAULT NULL,
  `lat_int_topup_amount` float DEFAULT NULL,
  `lat_int_topup_comp_status` varchar(100) DEFAULT NULL,
  `no_int_topup_made` int DEFAULT NULL,
  `int_total_topup_amount` float DEFAULT NULL,
  `int_topup_failure_reason` varchar(500) DEFAULT NULL,
  `iccid` varchar(20) DEFAULT NULL,
  `sim_login_date` datetime(3) DEFAULT NULL,
  `sim_dispatch_date` datetime(3) DEFAULT NULL,
  `sim_last_login_date` datetime(3) DEFAULT NULL,
  `sim_inserted` varchar(10) DEFAULT NULL,
  `sim_type` varchar(250) DEFAULT NULL,
  `freesimid` int DEFAULT NULL,
  `subscriberid` int DEFAULT NULL,
  `firstname` varchar(150) DEFAULT NULL,
  `lastname` varchar(150) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `houseno` varchar(100) DEFAULT NULL,
  `address1` varchar(1000) DEFAULT NULL,
  `address2` varchar(1000) DEFAULT NULL,
  `city` varchar(150) DEFAULT NULL,
  `state` varchar(250) DEFAULT NULL,
  `postcode` varchar(100) DEFAULT NULL,
  `dob` datetime(3) DEFAULT NULL,
  `hubspot_contact_id` varchar(20) DEFAULT NULL,
  `mobilephone` varchar(50) DEFAULT NULL,
  `ordersim_url` varchar(1000) DEFAULT NULL,
  `email_verification_status` varchar(50) DEFAULT NULL,
  `Country` varchar(100) DEFAULT NULL,
  `country_code` varchar(10) DEFAULT NULL,
  `alternate_email_id` varchar(150) DEFAULT NULL,
  `first_referral_date` datetime(3) DEFAULT NULL,
  `last_referral_date` datetime(3) DEFAULT NULL,
  `number_of_referrals_made` int DEFAULT NULL,
  `referred_someone` varchar(10) DEFAULT NULL,
  `referred_someone_first_time` varchar(10) DEFAULT NULL,
  `referee_subscriber_id` int DEFAULT NULL,
  `portin_current_network_name` varchar(50) DEFAULT NULL,
  `portin_request_completion_status` varchar(200) DEFAULT NULL,
  `portin_request_failure_reason` varchar(200) DEFAULT NULL,
  `portout_network_name` varchar(100) DEFAULT NULL,
  `reason_for_portout` varchar(50) DEFAULT NULL,
  `latest_purchase_attempt_payment_mode` varchar(100) DEFAULT NULL,
  `total_purchase_amount_of_the_customer` float DEFAULT NULL,
  `avg_customer_wait_time_between_purchases` int DEFAULT NULL,
  `latest_purchase_attempt_date` datetime(3) DEFAULT NULL,
  `latest_purchase_attempt_payment_status` varchar(10) DEFAULT NULL,
  `latest_purchase_attempt_payment_method` varchar(100) DEFAULT NULL,
  `latest_product_being_purchased` varchar(20) DEFAULT NULL,
  `latest_attempt_payment_reference_number` varchar(100) DEFAULT NULL,
  `latest_payment_attempt_failure_reason` varchar(500) DEFAULT NULL,
  `hs_analytics_source` varchar(250) DEFAULT NULL,
  `hs_language` varchar(10) DEFAULT NULL,
  `lifecyclestage` varchar(50) DEFAULT NULL,
  `Registered_to_myaccount` varchar(10) DEFAULT NULL,
  `Smart_Rates_user` varchar(25) DEFAULT NULL,
  `lastcalldate` datetime(3) DEFAULT NULL,
  `lastsmsdate` datetime(3) DEFAULT NULL,
  `lastgprsdate` datetime(3) DEFAULT NULL,
  `latest_buying_stage` varchar(250) DEFAULT NULL,
  `hs_lead_status` varchar(100) DEFAULT NULL,
  `arpu` float DEFAULT NULL,
  `no_of_times_top_up_20_and_above` int DEFAULT NULL,
  `first_topup_status` varchar(5) DEFAULT NULL,
  `International_Topup_Country_Name` varchar(15) DEFAULT NULL,
  `latest_topup_amount_being_purchased` float DEFAULT NULL,
  `frequent_topup_method` varchar(25) DEFAULT NULL,
  `Latest_SIM_with_Topup_Amount_Being_Purchased` float DEFAULT NULL,
  `sim_country` varchar(10) DEFAULT NULL,
  `sim_order_status` varchar(15) DEFAULT NULL,
  `SIM_ordered_by` varchar(10) DEFAULT NULL,
  `Latest_Preloaded_SIM_Amount_Being_Purchased` varchar(155) DEFAULT NULL,
  `latest_bundle_payment_mode` varchar(100) DEFAULT NULL,
  `create_modify_date` datetime(3) DEFAULT NULL,
  `first_time_topup_payment_method_used` varchar(150) DEFAULT NULL,
  `customer_type` varchar(150) DEFAULT NULL,
  `latest_sim_with_bundle_name_being_purchased` varchar(250) DEFAULT NULL,
  `email_verify` int DEFAULT NULL,
  `is_myaccount` int DEFAULT NULL,
  `no_topup_20_above` varchar(250) DEFAULT NULL,
  `topup_count_90_days` varchar(250) DEFAULT NULL,
  `freq_topup_method` varchar(250) DEFAULT NULL,
  `credit_allowance_used` int DEFAULT NULL,
  `sim_swap_status` varchar(50) DEFAULT NULL,
  `requested_for_sim_swap` varchar(50) DEFAULT NULL,
  `portin_request` varchar(500) DEFAULT NULL,
  `portin_status` varchar(500) DEFAULT NULL,
  `lat_product_vou_attempt_status` varchar(150) DEFAULT NULL,
  `lat_product_vou_failed_reason` varchar(250) DEFAULT NULL,
  `is_non_vectone` int DEFAULT NULL,
  `customer_request_for_refund` varchar(50) DEFAULT NULL,
  `refund_reference_number` varchar(100) DEFAULT NULL,
  `refund_status` varchar(50) DEFAULT NULL,
  `Bundle_Prefernce` longtext,
  `Topup_Preference` longtext,
  `price_range_Pref` longtext,
  `types_of_quarries` varchar(500) DEFAULT NULL,
  `top_up_sub_query` varchar(500) DEFAULT NULL,
  `bundle_sub_query` varchar(500) DEFAULT NULL,
  `sub_query2` varchar(500) DEFAULT NULL,
  `refund_amount_To` varchar(250) DEFAULT NULL,
  `refund_amount` float DEFAULT NULL,
  PRIMARY KEY (`mobileno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `topup_log`
--

DROP TABLE IF EXISTS `topup_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `topup_log` (
  `topuplogid` int NOT NULL AUTO_INCREMENT,
  `mobileno` varchar(16) DEFAULT NULL,
  `paymentType` int DEFAULT NULL,
  `paymentRef` varchar(64) DEFAULT NULL,
  `createdate` datetime(3) DEFAULT NULL,
  `transstatusID` int DEFAULT NULL,
  `amount` float DEFAULT NULL,
  `prevbal` float DEFAULT NULL,
  `afterbal` float DEFAULT NULL,
  `custcode` varchar(8) DEFAULT NULL,
  `batchcode` int DEFAULT NULL,
  `serialcode` int DEFAULT NULL,
  `acc_currcode` varchar(4) DEFAULT NULL,
  `currcode` varchar(4) DEFAULT NULL,
  `calledby` varchar(20) DEFAULT NULL,
  `old_trffclass` varchar(4) DEFAULT NULL,
  `new_trffclass` varchar(4) DEFAULT NULL,
  `vc_eflag` int DEFAULT NULL,
  `tp_tariffclass` varchar(4) DEFAULT NULL,
  `errcode` int DEFAULT NULL,
  `errmsg` varchar(30) DEFAULT NULL,
  `charityID` int DEFAULT NULL,
  `charity_amount` float DEFAULT NULL,
  `topup_url` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`topuplogid`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `topup_product`
--

DROP TABLE IF EXISTS `topup_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `topup_product` (
  `productid` int NOT NULL AUTO_INCREMENT,
  `tariffclass` char(4) NOT NULL,
  `productname` varchar(32) NOT NULL,
  `comment` varchar(128) DEFAULT NULL,
  `insertby` varchar(20) DEFAULT NULL,
  `insertdate` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`productid`),
  UNIQUE KEY `idx_tariffclass` (`tariffclass`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping events for database 'mvno'
--

--
-- Dumping routines for database 'mvno'
--
/*!50003 DROP PROCEDURE IF EXISTS `adm_cancel_promopack_byICCID_bypromoid` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `adm_cancel_promopack_byICCID_bypromoid`(v_cc VARCHAR(8),
v_bc INT,
v_sc INT,
v_promoid INT)
begin



   DECLARE v_packageid INT;
   DECLARE v_m_cc VARCHAR(8);
   DECLARE v_m_bc INT;
   DECLARE v_m_sc INT;
	
   DECLARE v_count INT;
   DECLARE v_total_count INT;
	
   DECLARE v_errcode INT;

	
   DROP TEMPORARY TABLE IF EXISTS tt_promo_to_pack_temp;
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   CREATE TEMPORARY TABLE tt_promo_to_pack_temp
   (
      idx INT AUTO_INCREMENT UNIQUE
   ) AS select v_promoid as promoid, packageid from promotion_topup  WHERE 1 = 0;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   INSERT INTO tt_promo_to_pack_temp(promoid, packageid) select v_promoid as promoid, packageid
	
   from promotion_topup 
   where promoid = v_promoid;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
	
   set v_count = 1;
   select   count(*) INTO v_total_count from tt_promo_to_pack_temp;
	
   while v_count <= v_total_count DO
      select   packageid INTO v_packageid from tt_promo_to_pack_temp where idx = v_count;
		
		
      CALL esp.pack_set_status(v_packageid,v_cc,v_bc,v_sc,-1,v_m_cc,v_m_bc,v_m_sc,v_errcode);
      set v_count = v_count+1;
   END WHILE;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `gmsc_getaccount_mvno` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbteam`@`%` PROCEDURE `gmsc_getaccount_mvno`(v_msisdn VARCHAR(16))
begin

   CALL esp.esp_getaccount_mvno(v_msisdn);  
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `hubspot_do_auto_topup_activity_register` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `hubspot_do_auto_topup_activity_register`(
mobileno varchar(20),
auto_topup int,
auto_topup_enable_date datetime,
auto_topup_enable_by varchar(100),
auto_topup_disable_date datetime,
auto_topup_disable_by varchar(100),
latest_auto_topup_attempt_date datetime,
latest_auto_topup_attempt_failure_reason varchar(100),
latest_auto_topup_attempt_status varchar(250)
)
BEGIN
	
	declare iccid varchar(20);
	declare hubspot_contact_id int;

	if auto_topup ='' then set auto_topup = 0; end if;
	
	if auto_topup_enable_by ='' then set auto_topup_enable_by = null; end if;
	
	if auto_topup_disable_by ='' then set auto_topup_disable_by = null; end if;
	
	if latest_auto_topup_attempt_failure_reason ='' then set latest_auto_topup_attempt_failure_reason = null; end if;
	if latest_auto_topup_attempt_status ='' then set latest_auto_topup_attempt_status = null; end if;

	select a.iccid into iccid from esp.mvno_account a where a.mobileno=mobileno;
	
	select a.hubspot_contact_id into hubspot_contact_id from topup_activity_register a
	where a.mobileno=mobileno;
	
	if ifnull(hubspot_contact_id,0)=0 then
		call esp.hubspot_mvno_get_contact_id  (mobileno,hubspot_contact_id);
	END if;
	
	IF EXISTS(SELECT 1 FROM topup_activity_register where mobileno=mobileno) then
		UPDATE topup_activity_register a SET a.auto_topup=case when auto_topup is not null then auto_topup else a.auto_topup end,
			a.auto_topup_disable_date=case when auto_topup_disable_date is not null then auto_topup_disable_date else  a.auto_topup_disable_date end,
			a.auto_topup_enable_date=case when auto_topup_enable_date is not null then auto_topup_enable_date else  a.auto_topup_enable_date end,
			a.auto_topup_enable_by=case when auto_topup_enable_by is not null then auto_topup_enable_by else  a.auto_topup_enable_by end,
			a.auto_topup_disable_by=case when auto_topup_disable_by is not null then auto_topup_disable_by else  a.auto_topup_disable_by end,
			a.latest_auto_topup_attempt_date=case when latest_auto_topup_attempt_date is not null then latest_auto_topup_attempt_date else  a.latest_auto_topup_attempt_date end,
			a.latest_auto_topup_attempt_failure_reason=case when latest_auto_topup_attempt_failure_reason is not null then latest_auto_topup_attempt_failure_reason else  a.latest_auto_topup_attempt_failure_reason end,
			a.latest_auto_topup_attempt_status=case when latest_auto_topup_attempt_status is not null then latest_auto_topup_attempt_status else  latest_auto_topup_attempt_status end,
			a.status=0,iccid=iccid,a.create_modify_date = current_timestamp(),
			a.hubspot_contact_id=hubspot_contact_id
		where a.mobileno=mobileno;
	ELSE
		INSERT INTO topup_activity_register(mobileno,auto_topup,auto_topup_disable_by,auto_topup_disable_date,
		auto_topup_enable_by,auto_topup_enable_date,latest_auto_topup_attempt_date,latest_auto_topup_attempt_failure_reason,
		latest_auto_topup_attempt_status,STATUS,insert_date,iccid,create_modify_date,hubspot_contact_id)
		VALUES(mobileno,auto_topup,auto_topup_disable_by,auto_topup_disable_date,
		auto_topup_enable_by,auto_topup_enable_date,latest_auto_topup_attempt_date,latest_auto_topup_attempt_failure_reason,
		latest_auto_topup_attempt_status,0,current_timestamp(),iccid,current_timestamp(),hubspot_contact_id);
	END if;
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `mvno_get_pstn_message_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbteam`@`%` PROCEDURE `mvno_get_pstn_message_info`()
BEGIN

   drop TEMPORARY table IF EXISTS tt_temp_pstn_message;   
   CREATE TEMPORARY TABLE tt_temp_pstn_message AS select smsid,sms_sender,sms_receiver,sms_text,tp_dcs,tp_udl,tp_sri 
      from mvno_pstn_message_info where status = 0;   
   
   UPDATE tt_temp_pstn_message a
   join mvno_pstn_message_info b on a.smsid = b.smsid set b.status = 1;     
   
   select * from tt_temp_pstn_message;   
  
  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `mvno_get_sms_campaign` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `mvno_get_sms_campaign`(
 	sitecode VARCHAR(3),  
 	msisdn VARCHAR(16),  
 	destination VARCHAR(16),  
 	datenow DATETIME(3),  
 OUT errcode INT ,  
 OUT errmsg VARCHAR(255))
begin
 
  
    DECLARE v_iccid VARCHAR(20);  
    DECLARE v_currcode VARCHAR(3);  
    DECLARE v_custcode VARCHAR(8);  
    DECLARE v_batchcode INT;  
    DECLARE v_serialcode INT;  
    DECLARE v_trffclass VARCHAR(4);  
    DECLARE v_paytype INT;   
    DECLARE v_telcocode VARCHAR(3);  
    DECLARE v_firstlocdate DATETIME(3);        
    
  
    DECLARE v_campaign_id INT;  
    DECLARE v_campaign_type INT;  
    DECLARE v_max_counter INT;  
    DECLARE v_max_counter_mode INT;  
    DECLARE v_sms_notification VARCHAR(255);  
    DECLARE v_prefix VARCHAR(30);     
    DECLARE v_totalcounter INT;
    DECLARE v_count INT; 
    DECLARE v_max_count INT;
    DECLARE Swv_RowCount INT;  
    
    set errcode = -1;  
    set errmsg = '';  
   
    DROP TEMPORARY TABLE IF EXISTS tt_sms_camp_temp;    
    create TEMPORARY table tt_sms_camp_temp
    (
       id INT   AUTO_INCREMENT PRIMARY KEY,
       campaign_id INT,
       campaign_type INT,
       max_counter INT,
       max_counter_mode INT,
       sms_notification VARCHAR(255)
    )  AUTO_INCREMENT = 1;  
    
  
    CALL esp.esp_get_sms_camp_Accinfo(msisdn,v_iccid,v_currcode,v_custcode,v_batchcode,v_serialcode,v_trffclass,v_paytype,v_telcocode);  
    
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select   a.FirstUpdate INTO v_firstlocdate from hlrdb.SIM a  where iccid = v_iccid;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
    
  
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    insert into tt_sms_camp_temp(campaign_id, campaign_type, max_counter, max_counter_mode, sms_notification)
    select campaign_id, campaign_type, max_counter, max_counter_mode, sms_notification
    from sms_campaign a
    where (a.sitecode = sitecode)
    and (custcode = v_custcode or custcode = '*')
    and (batchcode = v_batchcode or batchcode is null or batchcode = -1)
    and ((v_serialcode between serialcode_fr and serialcode_to) or (serialcode_fr <= v_serialcode and serialcode_to = -1) 
    or (serialcode_fr = -1 and serialcode_to = -1))
    and (datenow between startdate and enddate)
    and (sim_tariffclass = v_trffclass or sim_tariffclass = '*')
    and (firstlocdate_fr <= v_firstlocdate or firstlocdate_fr is null)
    and (firstlocdate_to >= v_firstlocdate or firstlocdate_to is null);
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
    
    set v_count = 1;  
    
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select   count(1) INTO v_max_count from tt_sms_camp_temp;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
    
    while v_count <= v_max_count DO
       begin
       
          fetch_next:BEGIN
          
             SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
             select   campaign_id, campaign_type, max_counter, max_counter_mode, sms_notification 
             INTO v_campaign_id,v_campaign_type,v_max_counter,v_max_counter_mode,v_sms_notification from tt_sms_camp_temp  where id = v_count;
             SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
             
             SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
             select   prefix INTO v_prefix from sms_campaign_dest a where a.sitecode = sitecode and campaign_id = v_campaign_id 
             and SUBSTRING(destination,1, CHAR_LENGTH(prefix)) = prefix   order by prefix desc LIMIT 1;
             SET Swv_RowCount = found_rows();
             SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
             
             if Swv_RowCount <= 0 or v_prefix is null 
             then
                LEAVE fetch_next;
             end if;  
      
   
             if v_max_counter > 0 
             then
     
    
                if v_max_counter_mode = 0 
                then 
    
                   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
                   select   count(*) INTO v_totalcounter from sms_campaign_log  where campaign_id = v_campaign_id 
                   and campaign_type = v_campaign_type
                   and custcode = v_custcode and batchcode = v_batchcode and serialcode = v_serialcode;
                   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
                   
                   if v_totalcounter >= v_max_counter 
                   then
     
                      set errmsg = 'This user has reached maximum counter.';
                      LEAVE fetch_next;
                   end if;
                   
                end if;
                
             end if;
             
             set errmsg = CONCAT_WS('',errmsg,v_sms_notification);
             set errcode = 0;
             
             
             insert into sms_campaign_log(logdate,campaign_id,campaign_type,msisdn,custcode,batchcode,serialcode,prefix,sms_notification)
 			values(datenow,v_campaign_id,v_campaign_type,msisdn,v_custcode,v_batchcode,v_serialcode,v_prefix,v_sms_notification);
   
          END fetch_next;
          
          set v_count = v_count+1;
          
       end;
       
    END WHILE;  
    
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `tp_insert_topup_log_v3` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `tp_insert_topup_log_v3`(mobileno VARCHAR(20),
paymentType INT,
paymentRef VARCHAR(64),
createdate DATETIME(3),
transStatusID INT,
amount FLOAT,
prevbal FLOAT,
afterbal FLOAT,
custcode VARCHAR(8),  
batchcode INT,
serialcode INT,
acc_currcode VARCHAR(3),
currcode VARCHAR(3),
calledby VARCHAR(5),
old_trffclass VARCHAR(4),
new_trffclass VARCHAR(4),
vc_eflag INT,
tp_tariffclass VARCHAR(4),
OUT topuplogid INT)
begin



	 insert into topup_log(mobileno,paymentType,paymentRef,createdate,transStatusID,amount,prevbal,afterbal,custcode,
	batchcode,serialcode,acc_currcode,currcode,calledby,old_trffclass,new_trffclass,vc_eflag,tp_tariffclass)
	values(mobileno,paymentType,paymentRef,createdate,transStatusID,amount,prevbal,afterbal,custcode,
	batchcode,serialcode,acc_currcode,currcode,calledby,old_trffclass,new_trffclass,vc_eflag,tp_tariffclass);
	
   set topuplogid = LAST_INSERT_ID();
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `WEB_update_balance_ccdc_temporary` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `WEB_update_balance_ccdc_temporary`(
usertype INT,
userinfo VARCHAR(30),
paymentref VARCHAR(64), 
productid INT, 
amount FLOAT, 
ccdc_curr VARCHAR(3),
calledby VARCHAR(4),
OUT prev_bal FLOAT ,
OUT after_bal FLOAT ,
OUT errcode INT ,
OUT errmsg VARCHAR(200))
SWL_return:
begin

   DECLARE v_acc_trffclass VARCHAR(5);
   DECLARE v_tp_tariffclass VARCHAR(5);
   DECLARE v_transStatusID INT;
   DECLARE Swv_RowCount INT;
	
   IF calledby is null then
      set calledby = 'WEB';
   END IF;
   set errcode = -1;
   set errmsg = '';
	
	
   if amount >= 0 then
      set paymentref = CONCAT_WS('','credit_',paymentref);
   else
      set paymentref = CONCAT_WS('','debit_',paymentref);
   end if;
		
	
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   a.tariffclass INTO v_tp_tariffclass from  topup_product a where a.productid = productid;
   SET Swv_RowCount = ROW_COUNT();
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   if Swv_RowCount <= 0 then
	
      set errmsg = 'Product not found!';
      LEAVE SWL_return;
   end if;
	
	
   CALL esp.tp_update_balance_ccdc_temporary(usertype,userinfo,paymentref,v_tp_tariffclass,amount,ccdc_curr,
   calledby,prev_bal,after_bal,errcode,errmsg);
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-21  9:51:39
