-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: Einstein_seo
-- ------------------------------------------------------
-- Server version	8.0.44-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `Einstein_seo`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `Einstein_seo` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `Einstein_seo`;

--
-- Table structure for table `tb_ein_company_plan`
--

DROP TABLE IF EXISTS `tb_ein_company_plan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_ein_company_plan` (
  `cp_id` int NOT NULL AUTO_INCREMENT,
  `company_id` int NOT NULL,
  `product_id` int DEFAULT NULL,
  `plan_id` int DEFAULT NULL,
  `plan_duration` int DEFAULT NULL,
  `next_bill_date` datetime(3) DEFAULT NULL,
  `status` int DEFAULT NULL,
  `createdate` datetime DEFAULT CURRENT_TIMESTAMP,
  `plan_price` float DEFAULT NULL,
  `last_bill_date` datetime(3) DEFAULT NULL,
  `plan_start_date` datetime(3) DEFAULT NULL,
  `plan_end_date` datetime(3) DEFAULT NULL,
  `bill_cycle` int DEFAULT NULL,
  `Is_free_trail` int DEFAULT NULL,
  `Is_FT_to_paid` int DEFAULT '0',
  `contract_end_date` datetime(3) DEFAULT NULL,
  `contract_start_date` datetime(3) DEFAULT NULL,
  `contract_canceled_date` datetime(3) DEFAULT NULL,
  `pro_user_count` int DEFAULT NULL,
  `standard_user_count` int DEFAULT NULL,
  `basic_user_count` int DEFAULT NULL,
  `free_Paid` int DEFAULT NULL,
  PRIMARY KEY (`cp_id`),
  UNIQUE KEY `company_id` (`company_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_ein_country_config`
--

DROP TABLE IF EXISTS `tb_ein_country_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_ein_country_config` (
  `id` int DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `resourceName` varchar(50) DEFAULT NULL,
  `countryCode` varchar(30) NOT NULL,
  `canonicalName` varchar(100) DEFAULT NULL,
  `flagUrl` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`countryCode`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_ein_country_target_type_config`
--

DROP TABLE IF EXISTS `tb_ein_country_target_type_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_ein_country_target_type_config` (
  `idx` int NOT NULL AUTO_INCREMENT,
  `resourceName` varchar(500) DEFAULT NULL,
  `status` varchar(500) DEFAULT NULL,
  `id` varchar(500) DEFAULT NULL,
  `name` varchar(500) DEFAULT NULL,
  `countryCode` varchar(500) DEFAULT NULL,
  `targetType` varchar(500) DEFAULT NULL,
  `canonicalName` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`idx`)
) ENGINE=InnoDB AUTO_INCREMENT=262141 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_ein_creative_toolkit_dtl`
--

DROP TABLE IF EXISTS `tb_ein_creative_toolkit_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_ein_creative_toolkit_dtl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userid` int DEFAULT NULL,
  `sessionId` varchar(40) DEFAULT NULL,
  `contentTitle` text,
  `content` json DEFAULT NULL,
  `fktypeid` int DEFAULT NULL,
  `createdat` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedat` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_tb_ein_creative_toolkit_dtl_fk` (`fktypeid`),
  CONSTRAINT `idx_tb_ein_creative_toolkit_dtl_fk` FOREIGN KEY (`fktypeid`) REFERENCES `tb_ein_creative_toolkit_type` (`typeid`)
) ENGINE=InnoDB AUTO_INCREMENT=155 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_ein_creative_toolkit_type`
--

DROP TABLE IF EXISTS `tb_ein_creative_toolkit_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_ein_creative_toolkit_type` (
  `typeid` int NOT NULL AUTO_INCREMENT,
  `typename` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`typeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_ein_keyword_research_dtl`
--

DROP TABLE IF EXISTS `tb_ein_keyword_research_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_ein_keyword_research_dtl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userid` int DEFAULT NULL,
  `keyword` text,
  `keywordType` int DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `searchJson` json DEFAULT NULL,
  `sessionId` varchar(40) DEFAULT NULL,
  `createdat` datetime DEFAULT CURRENT_TIMESTAMP,
  `referredat` date DEFAULT NULL,
  `isdeleted` tinyint DEFAULT '0',
  `relatedKeyword` json DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=151 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_ein_keyword_research_log`
--

DROP TABLE IF EXISTS `tb_ein_keyword_research_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_ein_keyword_research_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `searchid` int DEFAULT NULL,
  `keywordSplit` varchar(150) DEFAULT NULL,
  `resultSplit` json DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_tb_ein_keyword_research_log_searchid` (`searchid`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=169 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_ein_sign_signup_user_dtl`
--

DROP TABLE IF EXISTS `tb_ein_sign_signup_user_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_ein_sign_signup_user_dtl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(250) DEFAULT NULL,
  `verify_code` varchar(10) DEFAULT NULL,
  `is_verified` int DEFAULT '0',
  `created_date` datetime(3) DEFAULT NULL,
  `deviceid` varchar(100) DEFAULT NULL,
  `ip_address` varchar(20) DEFAULT NULL,
  `expiry_time` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_ein_users_dtl`
--

DROP TABLE IF EXISTS `tb_ein_users_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_ein_users_dtl` (
  `userid` int NOT NULL AUTO_INCREMENT,
  `company_id` int DEFAULT NULL,
  `firstname` varchar(100) DEFAULT NULL,
  `lastname` varchar(100) DEFAULT NULL,
  `emailAddress` varchar(250) DEFAULT NULL,
  `extension` int DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `status` int DEFAULT '1',
  `source` varchar(50) DEFAULT NULL,
  `ipAddress` varchar(100) DEFAULT NULL,
  `industry` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `profpicUrl` text,
  `createDate` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime DEFAULT NULL,
  `device` varchar(50) DEFAULT NULL,
  `token` text,
  PRIMARY KEY (`userid`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping events for database 'Einstein_seo'
--

--
-- Dumping routines for database 'Einstein_seo'
--
/*!50003 DROP PROCEDURE IF EXISTS `ein_create_personal_sign_signup_user_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ein_create_personal_sign_signup_user_dtl`(
       email VARCHAR(250),
       deviceid VARCHAR(100),
       ip_address VARCHAR(20)
       )
Begin
       
          DECLARE verify_code VARCHAR(10);
          DECLARE errcode INT; 
          DECLARE errmsg VARCHAR(250);
          DECLARE now DATETIME(3);
          DECLARE default_val_0 int;
       
          sp_exit:
          BEGIN
       
             set errcode = -1;
             set errmsg = '';
             set now = CURRENT_TIMESTAMP;
             set default_val_0 = 0 ;

             if exists(select * from tb_ein_sign_signup_user_dtl a  where a.email = email and a.is_verified = 1 LIMIT 1) then
       		
                set errcode = -1;
                set errmsg = 'This email address already verified';
                LEAVE sp_exit;
             end if;
       
             SET verify_code = right(FORMAT(RAND(),7),6);
       
             if exists(select * from tb_ein_sign_signup_user_dtl a  where a.email = email and a.is_verified = 0 LIMIT 1) then
       		
                UPDATE tb_ein_sign_signup_user_dtl a set a.verify_code = verify_code,a.created_date = now,a.deviceid = deviceid,
                a.ip_address = ip_address,a.expiry_time = 15
                where a.email = email and a.is_verified = 0;
                if ROW_COUNT() > 0 then
       			
                   set errcode = 0;
                   set errmsg = 'success';
                   LEAVE sp_exit;
                end if;
             end if;
             if not exists(select * from tb_ein_sign_signup_user_dtl a where a.email = email LIMIT 1) then
       		
       			insert into tb_ein_sign_signup_user_dtl(email,verify_code,is_verified,created_date,deviceid,ip_address,expiry_time)
       			values(email,verify_code,0,now,deviceid,ip_address,15);
       			
                if ROW_COUNT() > 0 then
       			
                   set errcode = 0;
                   set errmsg = 'success to generate pin';
                end if;
             end if;
          END;
     
          select errcode as errcode,errmsg as errmsg, IFNULL(verify_code,default_val_0) as verify_code;
       
       End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ein_delete_keyword_research_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ein_delete_keyword_research_info`(
p_sessionId varchar(40)
)
begin
	declare v_errcode int;
    declare v_errmsg varchar(50);
    
    sp_exit:Begin
		if not exists(select 1 from tb_ein_keyword_research_dtl where sessionId = p_sessionId limit 1 ) then
			set v_errcode = -1;
            set v_errmsg = 'Not found';
            leave sp_exit;
		End if;
        
        update tb_ein_keyword_research_dtl
			set isdeleted = 1
        where sessionId = p_sessionId;
        
        set v_errcode = 0;
		set v_errmsg = 'Record Deleted'; 
        
    end ;

    select v_errcode as errcode, v_errmsg as errmsg;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ein_get_country_list_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ein_get_country_list_info`()
Begin
select * from tb_ein_country_config;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ein_get_geotargetdata_list_by_countrycode` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ein_get_geotargetdata_list_by_countrycode`(p_countryCode varchar(10))
Begin
select * from tb_ein_country_target_type_config where countryCode = p_countryCode;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ein_get_keyword_research_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ein_get_keyword_research_info`(
  p_userid int,
  p_country varchar(100),
  p_keywordType int
  )
Begin
  
 	if p_keywordType in (1,2,3) then 
 		set @v_where = concat('keywordType in (1,2,3) and country = ''',p_country,'''') ; 
 	elseif p_keywordType = 4 then
 		set @v_where = concat('keywordType = 4');
 	else
 		set @v_where = concat('keywordType = 5');
 	End if;
     
     set @sql = concat('select * from tb_ein_keyword_research_dtl where ',@v_where,' and userid = ',p_userid,' and isdeleted = 0 order by 1 desc limit 3;');

 	PREPARE STMT FROM @sql;
 	EXECUTE STMT;
 	DEALLOCATE PREPARE STMT;
 
  End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ein_get_keyword_research_info_by_sessionId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ein_get_keyword_research_info_by_sessionId`(
 p_sessionId varchar(40)
 )
Begin
 
 	select keyword ,keywordType ,searchJson, createdat, country, city from tb_ein_keyword_research_dtl where sessionId = p_sessionId ;
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ein_get_keyword_research_record_list` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ein_get_keyword_research_record_list`(
          p_keyword text,
          p_keywordType int,
          p_country varchar(100) ,
          p_city varchar(100)
          )
sp_return: Begin
       
      		declare v_tcnt int;
      		declare v_cnt int;
      		set v_cnt = 1;
            SET SESSION group_concat_max_len = 1000000;
         
      		drop temporary table if exists tt_keyword_listsplit; create temporary table tt_keyword_listsplit ( id int auto_increment primary key, kwd text , relatedKeyword json); 
     		drop temporary table if exists tt_kwd_list; create temporary table tt_kwd_list ( id int auto_increment primary key, keyword text,searchJson json, country varchar(100) ,city varchar(100), referredat date, relatedKeyword json); 
              
              call Split(p_keyword,',');    insert into tt_keyword_listsplit(kwd) 	select items from tt_Split_temptable;
              
              Select count(*) into v_tcnt from tt_keyword_listsplit;
      
      		if p_keywordType in (1,2,3) then 
      			set @v_where = concat('ifnull(country,'''') = ''',ifnull(p_country,''),''' and ifnull(city,'''')= ''',ifnull(p_city,''),''' and ') ; 
      
      		elseif p_keywordType = 4 then
      			set @v_where = '';
      		else
      			set @v_where = concat('ifnull(country,'''') = ''',ifnull(p_country,''),''' and ');
      		End if;
      
      		if p_keywordType <> 2 then
      			set @sql = concat('select keyword, searchJson, country, city, DATE_FORMAT(referredat,''%Y-%m-%d'') as referredat from tb_ein_keyword_research_dtl where ',@v_where,'keywordType = ',p_keywordType,' and keyword = ''',p_keyword,''' and isdeleted = 0 and current_date() < date_add(referredat, interval 7 day) order by 1 desc limit 1;');
      		Else
      		
      			while v_cnt <= v_tcnt do
      			
      				insert into tt_kwd_list(keyword, searchJson, country, city, referredat, relatedKeyword)
      				select a.keywordSplit,a.resultSplit as searchJson,c.country, c.city, c.referredat, c.relatedKeyword
                     from tb_ein_keyword_research_log a join tt_keyword_listsplit b on a.keywordSplit = b.kwd  
      				join tb_ein_keyword_research_dtl c on c.id = a.searchid
      				where b.id = v_cnt 
                    and isdeleted = 0
      				and current_date() <= date_add(referredat, interval 7 day) order by 1 desc limit 1;
      			
      				set v_cnt = v_cnt + 1 ;
      			end while;
                  
                  
                  select p_keyword as keyword, concat('[',group_concat(concat('{"',keyword,'":',searchJson,'}')),']') as searchJson,
     					country as country, city as city ,DATE_FORMAT(referredat,'%Y-%m-%d') as referredat, relatedKeyword
                  from tt_kwd_list
                  group by country, city, referredat, relatedKeyword;
                  
      			leave sp_return;
      		End if;
              
              PREPARE STMT FROM @sql;
              EXECUTE STMT;
              DEALLOCATE PREPARE STMT;
              
          End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ein_insert_keyword_research_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ein_insert_keyword_research_info`(
    p_userid int,
    p_keyword text,
    p_keywordType int,
    p_country varchar(100),
    p_city  varchar(100),
    p_searchJson json,
    p_sessionId varchar(40),
    p_referredat date
    )
Begin
    
    	declare v_errcode int default -1;
   	declare v_errmsg varchar(50) default 'Failure';
       declare v_cnt int;
       declare v_tcnt int;
       declare v_kwd text;
       declare k_kwdid int;
       declare jval json;
       
       set @SWV_Error = 0;
       Begin
   		DECLARE EXIT HANDLER FOR SQLEXCEPTION
   		begin
   			SET v_errcode = @SWV_Error;
   			GET STACKED DIAGNOSTICS CONDITION 1 v_errmsg = MESSAGE_TEXT;
   			Rollback;
   			select v_errcode as errcode, v_errmsg as errmsg;
   		end;
       
       set v_cnt = 1;
       
   		drop temporary table if exists tt_keyword_split; create temporary table tt_keyword_split ( id int auto_increment primary key, kwd text ); 
   		
           call Split(p_keyword,',');    insert into tt_keyword_split(kwd) 	select items from tt_Split_temptable;
       
   		Select count(*) into v_tcnt from tt_keyword_split;
       
   		START TRANSACTION;
   		insert into tb_ein_keyword_research_dtl(userid, keyword, keywordType, country, city, searchJson,sessionId,referredat)
    		values(p_userid, p_keyword, p_keywordType, p_country, p_city, p_searchJson, p_sessionId,ifnull(p_referredat,current_date()));
           
           set k_kwdid = last_insert_id();
           set @p_searchJson = p_searchJson;
           
           
           if p_keywordType = 2 then
   		while v_cnt<=v_tcnt do
   			select kwd into v_kwd from tt_keyword_split where id = v_cnt;
               drop temporary table if exists ttjson;
   			set @sqls= concat('create temporary table ttjson as 
   			SELECT * FROM json_table(@p_searchJson,''$[*]'' columns (
   			cols json path ''$."',v_kwd,'"''
   			)
   			) AS temp_table
   			where cols is not null');
   
   			PREPARE STMT FROM @sqls;
   			EXECUTE STMT;
   			DEALLOCATE PREPARE STMT;
   
   			insert into tb_ein_keyword_research_log(searchid, keywordSplit, resultSplit)
   			select k_kwdid ,v_kwd ,cols from ttjson;
   
   			drop temporary table ttjson;
   
   			set v_cnt = v_cnt + 1;
   		End while;
   		Else
   			insert into tb_ein_keyword_research_log(searchid, keywordSplit, resultSplit)
   			values(k_kwdid ,p_keyword ,p_searchJson);
           End if;
    		
           if exists(select 1 from tb_ein_keyword_research_log where searchid = k_kwdid limit 1) then
    			set v_errcode = 0;
   			set v_errmsg = 'Inserted';
    		End if;
        
        COMMIT;
        select v_errcode as errcode, v_errmsg as errmsg;
      End;  
        
    End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ein_insert_update_user_extension_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ein_insert_update_user_extension_dtl`(
    p_company_id int,
    p_firstname varchar(100),
    p_lastname varchar(100),
    p_emailAddress varchar(100),
    p_extension int,
    p_password varchar(50),
    p_source varchar(20),
    p_ipAddress varchar(100),
    p_industry varchar(100),
    p_country varchar(100),
    p_profpicUrl text,
    p_token text
    )
Begin
    
 		declare v_errcode int;
 		declare v_errmsg varchar(50);
        declare v_userid int;
        
 		DECLARE EXIT HANDLER FOR SQLEXCEPTION
 		BEGIN
 			SHOW ERRORS;
 			ROLLBACK;   
 		END; 
          START TRANSACTION;
    	if not exists(select 1 from tb_ein_users_dtl where emailAddress = p_emailAddress limit 1) then
    		insert into tb_ein_users_dtl (company_id, firstname, lastname, emailAddress, extension, password,  source, ipAddress, industry, country, profpicUrl, token)
            values(p_company_id, p_firstname, p_lastname, p_emailAddress, p_extension, p_password, p_source, p_ipAddress, p_industry, p_country, p_profpicUrl, p_token);
            
            set  v_userid = LAST_INSERT_ID();
            
            if row_count()>0 then
    			set v_errcode = 0;
                set v_errmsg = 'Inserted';           
            End if;
            
    	else
    		update tb_ein_users_dtl a
    		set a.company_id = ifnull(p_company_id, a.company_id)
    			,a.firstname = ifnull(p_firstname, a.firstname)
    			,a.lastname = ifnull(p_lastname, a.lastname)
    			,a.extension = ifnull(p_extension, a.extension)
    			,a.password = ifnull(p_password,a.password)
    			,a.source = ifnull(p_source,a.source)
    			,a.ipAddress = ifnull(p_ipAddress,a.ipAddress)
    			,a.industry = ifnull(p_industry,a.industry)
    			,a.country = ifnull(p_country,a.country)
    			,a.profpicUrl = ifnull(p_profpicUrl,a.profpicUrl)
             ,a.token = ifnull(p_token,a.token)
    		where emailAddress = p_emailAddress;
    
    		if row_count()>0 then
    			set v_errcode = 0;
    			set v_errmsg = 'Updated';
    		End if;
        End if;
        
        
       
        COMMIT;    
    	select v_errcode as errcode, v_errmsg as errmsg,ifnull(v_userid,0) as userid;
    End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ein_update_keyword_related_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ein_update_keyword_related_dtl`(
 p_sessionId varchar(40),
 p_relatedKeyword json
 )
Begin
	declare v_errcode int;
    declare v_errsmg varchar(50);
    
    sp_exit:begin
    if not exists(select 1 from tb_ein_keyword_research_dtl where sessionId = p_sessionId limit 1) then
		set v_errcode = -1;
        set v_errsmg = 'Record not found';
        leave sp_exit;
    End if;
		
        update tb_ein_keyword_research_dtl
			set relatedKeyword =  JSON_ARRAY_APPEND(relatedKeyword, '$', p_relatedKeyword)
        where sessionId = p_sessionId;
        
        set v_errcode = 0;
        set v_errsmg = 'Updated'; 
        
    end;
    select v_errcode as errcode, v_errmsg as errmsg;
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ein_user_login_validation` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ein_user_login_validation`(
   	p_email VARCHAR(250)
   	,p_password VARCHAR(50)
   	,source varchar(50)
   	,signintype tinyint 
      ,device_id varchar(50)
   )
sp_return: Begin
          
   	   declare v_found int;
   	   declare v_company_id int;
   	   declare v_plan_end_date datetime;
                  
                  
          			if not exists(select 1 from tb_ein_users_dtl a where emailAddress = p_email limit 1)then
          				select -1 as errcode, 'User not found' as errmsg;
          				leave sp_return;
          			end if;
                   
                   if signintype=0 then
         				if exists(select 1 from tb_ein_users_dtl a where emailAddress = p_email and BINARY password <> p_password) then
         					select -1 as errcode, 'Incorrect Password' as errmsg;
         					leave sp_return;
         				end if;
       			
         				select 1 into v_found from tb_ein_users_dtl where emailAddress = p_email and BINARY password = p_password and status = 1 ;
         				
         				if v_found is null then
         					select -1 as errcode, 'Inactive / wrong Password' as errmsg;
         					leave sp_return;
   					End if;
   				End if;
                         
                        
   						select company_id, createDate into v_company_id, v_plan_end_date from tb_ein_users_dtl where emailAddress = p_email limit 1;
                        
                             if DATE_ADD(v_plan_end_date, INTERVAL 300 DAY) < current_date() then
     							select -1 as errcode, 'Inactive plan' as errmsg;
     							leave sp_return; 
                             End if;
     
     						if v_company_id is null then
                             
 								select 0 as errcode, 'Login successfully' as errmsg,a.*
 								from tb_ein_users_dtl a                     
 								where a.emailAddress = p_email 
 								and ((BINARY a.password = p_password and signintype = 0) or (signintype = 1))
 								and status = 1 ; 
                              
                              call unifiedring.ur_myacc_insert_login_master_issue_log (p_email,p_password,0,'Login successfully','','','',source,device_id,'',null);
                              
     						Else
     							
                                 
                                 select 0 as errcode, 'Login successfully' as errmsg,a.*
 								from tb_ein_users_dtl a                     
 								where a.emailAddress = p_email 
 								and ((BINARY a.password = p_password and signintype = 0) or (signintype = 1))
 								and status = 1 ; 
                                 
                                 call unifiedring.ur_myacc_insert_login_master_issue_log (p_email,p_password,0,'Login successfully','','','',source,device_id,'',null);
                                 
     						End if;
   
          
          	End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ein_validate_personal_sign_signup_user_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ein_validate_personal_sign_signup_user_dtl`(
       email VARCHAR(250),
       verify_code VARCHAR(10)
       )
Begin
       
          DECLARE errcode INT; 
          DECLARE errmsg VARCHAR(250);
          DECLARE now DATETIME(3);
          Declare Timediff int; 
          Declare v_expiry_time int; 
          Declare v_create_time datetime(3);
          
          sp_exit:
          BEGIN
             set errcode = -1;
             set errmsg = '';
             set now = CURRENT_TIMESTAMP;
             
             if not exists(select * from tb_ein_sign_signup_user_dtl a  where a.email = email LIMIT 1) then
       		
                set errcode = -1;
                set errmsg = 'Incorrect email address';
                LEAVE sp_exit;
             end if;
             
             if exists(select * from tb_ein_sign_signup_user_dtl a  where a.email = email and a.is_verified = 1 LIMIT 1) then
       		
                set errcode = -1;
                set errmsg = 'This email address already verified';
                LEAVE sp_exit;
             end if;
             
             if exists(select * from tb_ein_sign_signup_user_dtl a  where a.email = email and a.verify_code <> verify_code and a.is_verified = 0 LIMIT 1) then
       		
                set errcode = -1;
                set errmsg = 'Invalid OTP';
                LEAVE sp_exit;
             end if;
             
             if exists(select * from tb_ein_sign_signup_user_dtl a  where a.email = email and a.verify_code = verify_code and a.is_verified = 0 LIMIT 1) then
             
     			select a.expiry_time, a.created_date into v_expiry_time, v_create_time
     			from tb_ein_sign_signup_user_dtl a where a.email = email and a.verify_code = verify_code  
     			order by id desc limit 1;
     
     			set Timediff = timestampdiff(MINUTE,v_create_time,NOW(3));  
     
     			if v_expiry_time <  Timediff Then  
     				set errcode = -1;  
     				set errmsg = 'OTP has expired, please click on Resend code to continue';  
     				leave sp_exit;
     			End if;  
                 
                set errcode = 0;
                set errmsg = 'Success : Email verified';
                
                UPDATE tb_ein_sign_signup_user_dtl a set a.is_verified = 1
                where a.email = email and a.verify_code = verify_code;
                LEAVE sp_exit;
             end if;
             
          END;
          select errcode as errcode,errmsg as errmsg; 
       
       End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Split` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `Split`(v_String VARCHAR(8000), v_Delimiter CHAR(1))
SWL_return:
 begin
 
      
    DECLARE v_idx INT;     
    DECLARE v_slice VARCHAR(8000);     
 
    DROP TEMPORARY TABLE IF EXISTS tt_Split_temptable;
    CREATE TEMPORARY TABLE IF NOT EXISTS tt_Split_temptable
    (
       items VARCHAR(8000)
    );
    SET v_idx = 1;     
    if  CHAR_LENGTH(v_String) < 1 or v_String is null then  
       LEAVE SWL_return;
    end if;     
 
    SWL_Label:
    while v_idx != 0 DO
       set v_idx = LOCATE(v_Delimiter,v_String);
       if v_idx != 0 then
          set v_slice = left(v_String,v_idx -1);
       else
          set v_slice = v_String;
       end if;
       if( CHAR_LENGTH(v_slice) > 0) then
          insert into tt_Split_temptable(Items) values(v_slice);
       end if;
       set v_String = right(v_String, CHAR_LENGTH(v_String) -v_idx);
       if  CHAR_LENGTH(v_String) = 0 then 
          LEAVE SWL_Label;
       end if;
    END WHILE; 
    LEAVE SWL_return;     
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `tb_ein_get_creative_toolkit_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `tb_ein_get_creative_toolkit_dtl`(
p_sessionId varchar(40), p_userId int
)
Begin
  	select * from Einstein_seo.tb_ein_creative_toolkit_dtl where (sessionId = p_sessionId or ifnull(p_sessionId,'')='') and userid = p_userid order by 1 desc limit 1;
  End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `tb_ein_insert_update_creative_toolkit_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `tb_ein_insert_update_creative_toolkit_dtl`(
p_userid int,
p_sessionId varchar(40),
p_content JSON,
p_fktypeid int
)
begin
	declare v_errcode int default -1;
    declare v_errmsg varchar(150) default 'Not found';
    declare v_contentTitle text;
	
    if not exists(select 1 from tb_ein_creative_toolkit_dtl where sessionId = p_sessionId limit 1) then
    
			SELECT 	contentmsg.userMessage	
			INTO 	v_contentTitle
			FROM  JSON_TABLE
            (
				p_content, '$[*]' COLUMNS 
				(	
					userMessage	 	text PATH '$.userMessage'
                )
			) contentmsg;   
    
		insert into tb_ein_creative_toolkit_dtl(userid, sessionId, contentTitle, content, fktypeid)
        values(p_userid, p_sessionId, v_contentTitle, p_content, p_fktypeid);
        
        SET v_errcode = 0;
		SET v_errmsg = 'Inserted successfully';
        
    else
			update tb_ein_creative_toolkit_dtl
			set	content = JSON_ARRAY_APPEND(content, '$', p_content)
            where sessionId = p_sessionId;
            
            IF ROW_COUNT() > 0 THEN
			  SET v_errcode = 0;
			  SET v_errmsg = 'Updated successfully';
			END IF;     
    
    End if;
    
    select v_errcode as errcode, v_errmsg as errmsg;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `tb_ein_likedislike_creative_toolkit_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `tb_ein_likedislike_creative_toolkit_dtl`(
  p_userid int,
  p_sessionId varchar(40),
  p_userMessage varchar(40),
  p_like tinyint,
  p_dislike tinyint
  )
Begin
 		declare v_errcode int default -1;
 		declare v_errmsg varchar(150) default 'Not found';
 		DECLARE updatedContent LONGTEXT;
  	
      sp_exit:begin
  		if not exists(select 1 from tb_ein_creative_toolkit_dtl where sessionId = p_sessionId limit 1) then
  			SET v_errcode = -1;
  			SET v_errmsg = 'record not found';
  			leave sp_exit;
  		end if;
          
 	UPDATE tb_ein_creative_toolkit_dtl
     SET content = (
         SELECT JSON_ARRAYAGG(
             CASE
                 WHEN JSON_UNQUOTE(JSON_EXTRACT(elem, '$.messageId')) = p_userMessage THEN 
                     JSON_SET(
                         elem,
                         '$.like', p_like,
                         '$.dislike', p_dislike
                     )
                 ELSE 
                     elem
             END
         )
         FROM JSON_TABLE(content, '$[*]' COLUMNS (elem JSON PATH '$')) AS elements
     )
     WHERE JSON_CONTAINS(content, JSON_OBJECT('messageId', p_userMessage), '$') and sessionId = p_sessionId ;
            
  			IF ROW_COUNT() > 0 THEN
  			  SET v_errcode = 0;
  			  SET v_errmsg = 'Updated successfully';
  			END IF; 
      end;
      
      select v_errcode as errcode, v_errmsg as errmsg;
  End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-21  9:50:44
