-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: npopr_au
-- ------------------------------------------------------
-- Server version	8.0.44-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `npopr_au`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `npopr_au` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `npopr_au`;

--
-- Table structure for table `homenbrange`
--

DROP TABLE IF EXISTS `homenbrange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `homenbrange` (
  `idx` int NOT NULL,
  `firstnb` varchar(20) NOT NULL,
  `lastnb` varchar(20) NOT NULL,
  UNIQUE KEY `PK_homenbrange` (`firstnb`,`lastnb`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `npcountry`
--

DROP TABLE IF EXISTS `npcountry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `npcountry` (
  `prefix` varchar(15) NOT NULL,
  `country` varchar(64) NOT NULL,
  `homeoperatorrcid` varchar(20) DEFAULT NULL,
  UNIQUE KEY `npcountry_PK` (`prefix`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `porting`
--

DROP TABLE IF EXISTS `porting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `porting` (
  `idx` bigint NOT NULL AUTO_INCREMENT,
  `firstnb` varchar(20) NOT NULL,
  `lastnb` varchar(20) NOT NULL,
  `portedflag` int NOT NULL,
  `rcid` char(10) NOT NULL,
  `flag` int DEFAULT NULL,
  PRIMARY KEY (`firstnb`,`lastnb`,`portedflag`),
  UNIQUE KEY `idx` (`idx`),
  KEY `idx_20120917_1` (`firstnb`,`lastnb`,`portedflag`,`rcid`),
  KEY `idx_20120917_2` (`rcid`),
  KEY `idx2` (`portedflag`,`firstnb`,`lastnb`,`rcid`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=12174682 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `porting_new`
--

DROP TABLE IF EXISTS `porting_new`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `porting_new` (
  `idx` bigint NOT NULL AUTO_INCREMENT,
  `firstnb` varchar(20) NOT NULL,
  `lastnb` varchar(20) NOT NULL,
  `portedflag` int NOT NULL,
  `rcid` char(10) NOT NULL,
  `flag` int DEFAULT NULL,
  PRIMARY KEY (`firstnb`,`lastnb`,`portedflag`),
  UNIQUE KEY `idx` (`idx`),
  KEY `idx_20120917_1` (`firstnb`,`lastnb`,`portedflag`,`rcid`),
  KEY `idx_20120917_2` (`rcid`),
  KEY `idx2` (`portedflag`,`firstnb`,`lastnb`,`rcid`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=12174105 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping events for database 'npopr_au'
--

--
-- Dumping routines for database 'npopr_au'
--
/*!50003 DROP PROCEDURE IF EXISTS `MNP_GET_NUMBER` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `MNP_GET_NUMBER`(nb VARCHAR(30),      
OUT mnp_number VARCHAR(30) ,      
OUT portedflag INT ,      
OUT rcid VARCHAR(30) ,      
OUT isOnward INT)
BEGIN


   DECLARE nbnocc VARCHAR(30);      
   DECLARE home_rcid VARCHAR(20);
   DECLARE Swv_RowCount INT;
   set portedflag = 0;
   set isOnward = 0;

   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

   select   right(nb,CHAR_LENGTH(RTRIM(nb)) -CHAR_LENGTH(RTRIM(a.prefix))), rtrim(ltrim(a.homeOperatorRcid)) 
   INTO nbnocc,home_rcid 
   from npcountry  a
   where left(nb,CHAR_LENGTH(RTRIM(a.prefix))) = a.prefix;

   SET Swv_RowCount = ROW_COUNT();
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   if Swv_RowCount > 0 then
     
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select   ltrim(RTRIM(a.rcid)), a.portedflag INTO rcid,portedflag 
	  from porting   a
	  where nb between a.firstnb and a.lastnb   order by portedflag desc LIMIT 1;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
      if portedflag = 1 then

         if exists(select * from homenbrange a where nb between a.firstnb  and a.lastnb and rcid <> home_rcid) then
            set isOnward = 1;
         end if;
      end if;
      set mnp_number = IFNULL(CONCAT(rcid,ltrim(portedflag),nbnocc),nb);
   else
      set mnp_number = nb;
   end if;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-21  9:51:53
