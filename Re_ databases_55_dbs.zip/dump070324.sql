-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: dump070324
-- ------------------------------------------------------
-- Server version	8.0.44-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `dump070324`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `dump070324` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `dump070324`;

--
-- Table structure for table `UR_ECom_User_Dtl`
--

DROP TABLE IF EXISTS `UR_ECom_User_Dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UR_ECom_User_Dtl` (
  `UR_ECom_Id` int NOT NULL AUTO_INCREMENT,
  `UR_ECom_Name` varchar(60) DEFAULT NULL,
  `UR_ECom_Phone_Number` varchar(30) DEFAULT NULL,
  `UR_ECom_Email` varchar(100) DEFAULT NULL,
  `UR_ECom_Status` int DEFAULT NULL,
  `UR_ECom_Created_Date` datetime(3) DEFAULT NULL,
  `UR_ECom_user_status` tinyint unsigned NOT NULL DEFAULT '0',
  `b2b_user_id` int DEFAULT NULL,
  `UR_MyAcc_Password` varchar(50) DEFAULT NULL,
  `UR_Ecom_first_name` varchar(150) DEFAULT NULL,
  `UR_Ecom_last_name` varchar(150) DEFAULT NULL,
  `verification_code` text,
  PRIMARY KEY (`UR_ECom_Id`),
  KEY `FK__ur_user_b__ur_ec__1043F038Idx2` (`UR_ECom_Id`),
  KEY `idx_ECom_User_1` (`UR_ECom_Status`,`UR_ECom_user_status`),
  FULLTEXT KEY `idx_full_idx_ECom_User_1` (`UR_ECom_Name`,`UR_ECom_Phone_Number`,`UR_ECom_Email`),
  FULLTEXT KEY `idx_full_idx_ECom_User_2` (`UR_MyAcc_Password`,`UR_Ecom_first_name`,`UR_Ecom_last_name`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=25418 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `UR_ECom_User_Extension_Dtl`
--

DROP TABLE IF EXISTS `UR_ECom_User_Extension_Dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UR_ECom_User_Extension_Dtl` (
  `Idx` int NOT NULL AUTO_INCREMENT,
  `Createdate` datetime(3) DEFAULT NULL,
  `Basket_id` int NOT NULL,
  `Company_id` int NOT NULL,
  `Firstname` varchar(100) DEFAULT NULL,
  `Surname` varchar(100) DEFAULT NULL,
  `Department` varchar(100) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `Mobileno` varchar(20) DEFAULT NULL,
  `Direct_Number` varchar(20) DEFAULT NULL,
  `Extension_Number` varchar(15) NOT NULL,
  `User_Language` varchar(50) DEFAULT NULL,
  `Greeting_Language` varchar(50) DEFAULT NULL,
  `Regional_Language` varchar(50) DEFAULT NULL,
  `Role_Id` int DEFAULT NULL,
  `Status` int DEFAULT NULL,
  `Recorded_usename_filepath` varchar(50) DEFAULT NULL,
  `Home_Country_Code` varchar(100) DEFAULT NULL,
  `Time_format` int DEFAULT NULL,
  `Time_zone` varchar(200) DEFAULT NULL,
  `Recorded_by` int DEFAULT NULL,
  `Recorded_type` int DEFAULT NULL,
  `Recorded_greeting` varchar(100) DEFAULT NULL,
  `MyAcc_Password` varchar(60) DEFAULT NULL,
  `dialby_dir_enable` int DEFAULT NULL,
  `provision_file` varchar(100) DEFAULT NULL,
  `extn_audio_file` longtext,
  `extn_name_audio_file` longtext,
  `is_mapped` int DEFAULT NULL,
  `extn_last_login` datetime(3) DEFAULT NULL,
  `account_plan_id` int DEFAULT NULL,
  `emp_id` varchar(20) DEFAULT NULL,
  `desktop_admin` int DEFAULT NULL,
  `compliance_export` int DEFAULT NULL,
  `updated_at` datetime(3) DEFAULT NULL,
  `device_type` varchar(150) DEFAULT NULL,
  `browser` varchar(250) DEFAULT NULL,
  `login_type` varchar(250) DEFAULT NULL,
  `last_login` datetime(3) DEFAULT NULL,
  `phone_name` varchar(250) DEFAULT NULL,
  `site_id` int DEFAULT NULL,
  `is_callerid` int DEFAULT NULL,
  `callerid_number` varchar(16) DEFAULT NULL,
  `host_code` int DEFAULT NULL,
  `partipation_code` int DEFAULT NULL,
  `bc_no_caller_id` int DEFAULT '0',
  `updated_conference_number` varchar(20) DEFAULT NULL,
  `country_code` int DEFAULT NULL,
  `Hubspot_contactid` int DEFAULT NULL,
  `onboarding_link` longtext,
  `phone_id` varchar(250) DEFAULT NULL,
  `pwd_reset_by` varchar(150) DEFAULT NULL,
  `pwd_rest_ip` varchar(150) DEFAULT NULL,
  `Pay_reference` varchar(75) DEFAULT NULL,
  `Payment_Amount` float DEFAULT NULL,
  `Paystatus` varchar(150) DEFAULT NULL,
  `Meeting_Id` varchar(15) DEFAULT NULL,
  `Is_Operator` int DEFAULT NULL,
  `user_conv_type` int DEFAULT NULL,
  `User_conv_payref` varchar(50) DEFAULT NULL,
  `User_conv_amount` float DEFAULT NULL,
  `user_conv_date` datetime(3) DEFAULT NULL,
  `UR_Mobileno` varchar(20) DEFAULT NULL,
  `is_cancel` int DEFAULT NULL,
  `position` varchar(250) DEFAULT NULL,
  `Is_asr_access` int DEFAULT NULL,
  `is_tour_flag` int NOT NULL DEFAULT (0),
  `is_tour_flag_and` int DEFAULT '0',
  `is_tour_flag_ios` int DEFAULT '0',
  `is_tour_flag_web` int DEFAULT '0',
  `worklocation` varchar(50) DEFAULT NULL,
  `Reportingto` varchar(50) DEFAULT NULL,
  `RoleID` int DEFAULT NULL,
  `Isdeleted` tinyint DEFAULT '0',
  `Delete_date` datetime DEFAULT NULL,
  `Del_User_Available_days` int DEFAULT NULL,
  `org_role_id` int DEFAULT NULL,
  `chatbot_tour` int DEFAULT '0',
  `chatflow_tour` int DEFAULT '0',
  `dashboard_tour` int DEFAULT '0',
  `is_email_verified` int DEFAULT '0',
  `description` varchar(800) DEFAULT NULL,
  PRIMARY KEY (`Basket_id`,`Company_id`,`Extension_Number`),
  UNIQUE KEY `Idx` (`Idx`),
  UNIQUE KEY `uc_email` (`Email`),
  KEY `FK_UR_ECom_User_Extension_Dtl_Role` (`RoleID`),
  KEY `idx_basket_company_extension` (`Basket_id`,`Company_id`,`Extension_Number`),
  KEY `idx_Extension_Number_basket` (`Extension_Number`,`Basket_id`),
  KEY `idx_Extension_Number` (`Extension_Number`),
  KEY `idx_basket_id` (`Basket_id`),
  KEY `idx_Isdeleted` (`Isdeleted`),
  KEY `idx_Basket_Company_Extension_Role` (`Basket_id`,`Company_id`,`Extension_Number`,`Role_Id`),
  KEY `idx_Company_Extension` (`Company_id`,`Extension_Number`),
  KEY `idx_Company_id` (`Company_id`),
  FULLTEXT KEY `idx_UR_ECom_mob_ext` (`Email`,`Extension_Number`),
  FULLTEXT KEY `idx_full_idx_ECom_User_1` (`device_type`,`login_type`),
  FULLTEXT KEY `idx_full_idx_ECom_User_2` (`Email`),
  CONSTRAINT `FK_UR_ECom_User_Extension_Dtl_Role` FOREIGN KEY (`RoleID`) REFERENCES `RoleMaster` (`RoleId`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=27920 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ur_app_login_details`
--

DROP TABLE IF EXISTS `ur_app_login_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ur_app_login_details` (
  `app_log_id` int NOT NULL AUTO_INCREMENT,
  `company_id` int DEFAULT NULL,
  `dir_user_id` int DEFAULT NULL,
  `login_user_name` varchar(100) DEFAULT NULL,
  `login_password` varchar(50) DEFAULT NULL,
  `mobile_number` varchar(20) DEFAULT NULL,
  `security_quest_id` int DEFAULT NULL,
  `security_ans` varchar(250) DEFAULT NULL,
  `is_enable` tinyint(1) DEFAULT '1',
  `created_by` varchar(50) DEFAULT NULL,
  `created_date` datetime(3) DEFAULT NULL,
  `modified_by` varchar(50) DEFAULT NULL,
  `modified_date` datetime(3) DEFAULT NULL,
  `login_source` varchar(30) DEFAULT NULL,
  `device_id` varchar(150) DEFAULT NULL,
  `ip_address` varchar(20) DEFAULT NULL,
  `is_active` int NOT NULL DEFAULT '0',
  `email_notify` tinyint unsigned NOT NULL DEFAULT '0',
  `email_to_notify` varchar(100) DEFAULT NULL,
  `status_msg` varchar(4000) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `user_status` int DEFAULT NULL,
  `call_queue_status` int DEFAULT NULL,
  `profile_image_url` varchar(250) DEFAULT NULL,
  `user_type` int DEFAULT NULL,
  `notification_recive` int DEFAULT NULL,
  `notification_sound` int DEFAULT NULL,
  `notification_team` int DEFAULT NULL,
  `notification_direct_msg` int DEFAULT NULL,
  `notification_mention` int DEFAULT NULL,
  `notification_call_voice_text` int DEFAULT NULL,
  `notification_join_now` int DEFAULT NULL,
  `notification_email_mention` int DEFAULT NULL,
  `notification_email_daily_digest` int DEFAULT NULL,
  `notification_email_direct_msg` int DEFAULT NULL,
  `notification_email_team_msg` int DEFAULT NULL,
  `notification_email_unread_badge_count` int DEFAULT NULL,
  `is_archive` int DEFAULT '0',
  `is_phone_notif_info` int DEFAULT NULL,
  `is_phone_notif` int DEFAULT '1',
  `profile_image_thumbnail` longtext,
  PRIMARY KEY (`app_log_id`),
  KEY `idx1_ur_app_login_details` (`company_id`),
  KEY `idx2_ur_app_login_details` (`dir_user_id`,`company_id`),
  KEY `FK__ur_app_bl__app_l__3F12570CIdx2` (`app_log_id`),
  KEY `idx_app_login_details_1` (`dir_user_id`),
  KEY `idx_app_login_details_pn` (`is_phone_notif_info`),
  KEY `idx_app_log_n` (`company_id`,`login_user_name`,`login_password`),
  KEY `idx_ur_app_dtl_1` (`dir_user_id`,`company_id`,`app_log_id`),
  KEY `idx_ur_app_dtl_2` (`dir_user_id`,`app_log_id`),
  KEY `idx_ur_app_dtl_3` (`dir_user_id`,`app_log_id`,`login_user_name`),
  KEY `idx_ur_app_dtl_4` (`dir_user_id`,`company_id`,`login_user_name`),
  KEY `idx_dir_user_id` (`dir_user_id`),
  KEY `idx_app_log_id` (`app_log_id`),
  FULLTEXT KEY `idx_full_text_1` (`login_user_name`,`login_password`),
  FULLTEXT KEY `idx_full_text_2` (`mobile_number`),
  FULLTEXT KEY `idx_ur_app_log` (`login_source`,`device_id`,`ip_address`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=28636 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ur_local_number_log`
--

DROP TABLE IF EXISTS `ur_local_number_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ur_local_number_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `company_id` int DEFAULT NULL,
  `extn` int DEFAULT NULL,
  `did_number` varchar(50) DEFAULT NULL,
  `country` varchar(50) DEFAULT NULL,
  `areacode` varchar(15) DEFAULT NULL,
  `called_by` varchar(50) DEFAULT NULL,
  `errcode` int DEFAULT NULL,
  `createdate` datetime(3) DEFAULT NULL,
  `user_type` int DEFAULT NULL,
  `order_id` int DEFAULT NULL,
  `itemid` int DEFAULT NULL,
  `is_delete_num` int DEFAULT NULL,
  `is_msisdn` int NOT NULL DEFAULT '0',
  `Number_Type_Info` varchar(250) DEFAULT NULL,
  `is_need_to_pay` int NOT NULL DEFAULT '0',
  `addon_purchaseid` int DEFAULT NULL,
  `isportin` int DEFAULT NULL,
  `UR_Number` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_did_number` (`did_number`),
  KEY `idx_company_id` (`company_id`),
  KEY `idx_did_number_company_id` (`did_number`,`company_id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=67972 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ur_sip_credential`
--

DROP TABLE IF EXISTS `ur_sip_credential`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ur_sip_credential` (
  `app_log_id` int DEFAULT NULL,
  `sip_login_id` bigint NOT NULL AUTO_INCREMENT,
  `sip_password` varchar(15) DEFAULT NULL,
  `created_by` varchar(50) DEFAULT NULL,
  `created_date` datetime(3) DEFAULT NULL,
  `modified_by` varchar(50) DEFAULT NULL,
  `modified_date` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`sip_login_id`),
  KEY `idx_sip_credential_1` (`app_log_id`),
  KEY `idx_sip_credential_2` (`app_log_id`,`sip_login_id`),
  KEY `idx_app_log_id` (`app_log_id`),
  KEY `idx_sip_login_id` (`sip_login_id`),
  FULLTEXT KEY `idx_full_text_sip_password` (`sip_password`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=29937 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vbcp_company_users`
--

DROP TABLE IF EXISTS `vbcp_company_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vbcp_company_users` (
  `company_id` int NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(20) DEFAULT NULL,
  `created_date` datetime(3) DEFAULT NULL,
  `created_by` varchar(100) DEFAULT NULL,
  `isActive` tinyint DEFAULT NULL,
  `dir_user_id` bigint DEFAULT NULL,
  `external_contact_number` varchar(32) DEFAULT NULL,
  `email` varchar(64) DEFAULT NULL,
  `position` varchar(64) DEFAULT NULL,
  `Title` varchar(5) DEFAULT NULL,
  `first_name` varchar(64) DEFAULT NULL,
  `last_name` varchar(64) DEFAULT NULL,
  `full_name` varchar(64) DEFAULT NULL,
  `flag` varchar(1) DEFAULT '1',
  `assign_ext_number` int DEFAULT NULL,
  `email_sts` int NOT NULL DEFAULT '1',
  `extn_no` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`username`),
  KEY `fk_vbcp_company_users_email_statusIdx` (`email_sts`),
  KEY `vbcp_company_users_vt_member_group_tracker_fkIdx2` (`username`),
  KEY `idx_vbcp_co_1` (`company_id`,`dir_user_id`),
  FULLTEXT KEY `idx_full_vbcp_co_Com_1` (`username`,`password`,`email`,`position`,`extn_no`),
  CONSTRAINT `fk_vbcp_company_users_email_status` FOREIGN KEY (`email_sts`) REFERENCES `ur_email_status` (`email_sts`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping events for database 'dump070324'
--

--
-- Dumping routines for database 'dump070324'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-21  9:50:39
