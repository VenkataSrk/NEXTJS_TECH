-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: whatsappcampaign
-- ------------------------------------------------------
-- Server version	8.0.44-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `AppPush_SearchHistoryDtl`
--

DROP TABLE IF EXISTS `AppPush_SearchHistoryDtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AppPush_SearchHistoryDtl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `domainId` int NOT NULL,
  `searchDetails` longtext,
  `createdOn` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedOn` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `AppPush_campaign_master_dtl`
--

DROP TABLE IF EXISTS `AppPush_campaign_master_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AppPush_campaign_master_dtl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `domainId` int NOT NULL,
  `campaignChatId` varchar(300) NOT NULL,
  `campaignName` varchar(250) NOT NULL,
  `campaignGoal` varchar(250) DEFAULT NULL,
  `industryType` varchar(100) DEFAULT NULL,
  `objective` varchar(400) DEFAULT NULL,
  `urlDtl` varchar(250) DEFAULT NULL,
  `scheduleType` smallint DEFAULT NULL,
  `targetAudienceType` int DEFAULT NULL,
  `contactDtl` json DEFAULT NULL,
  `TemplateDtl` text,
  `deviceDtl` json DEFAULT NULL,
  `sourceDtl` varchar(15) DEFAULT NULL,
  `imageUrl` varchar(300) DEFAULT NULL,
  `Status` varchar(50) DEFAULT NULL,
  `createdOn` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedOn` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `campaignChatId` (`campaignChatId`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=136 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `AppPush_campaign_master_dtl_Backup20251028`
--

DROP TABLE IF EXISTS `AppPush_campaign_master_dtl_Backup20251028`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AppPush_campaign_master_dtl_Backup20251028` (
  `id` int NOT NULL AUTO_INCREMENT,
  `domainId` int NOT NULL,
  `campaignChatId` varchar(300) DEFAULT NULL,
  `campaignName` varchar(250) NOT NULL,
  `campaignGoal` varchar(250) DEFAULT NULL,
  `industryType` varchar(100) DEFAULT NULL,
  `objective` varchar(400) DEFAULT NULL,
  `urlDtl` varchar(250) DEFAULT NULL,
  `scheduleType` smallint DEFAULT NULL,
  `targetAudienceType` int DEFAULT NULL,
  `contactDtl` json DEFAULT NULL,
  `TemplateDtl` text,
  `deviceDtl` json DEFAULT NULL,
  `sourceDtl` varchar(15) DEFAULT NULL,
  `imageUrl` varchar(300) DEFAULT NULL,
  `Status` varchar(50) DEFAULT NULL,
  `createdOn` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedOn` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `campaignChatId` (`campaignChatId`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `AppPush_encryption_config`
--

DROP TABLE IF EXISTS `AppPush_encryption_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AppPush_encryption_config` (
  `configId` int NOT NULL AUTO_INCREMENT,
  `domainId` int NOT NULL,
  `appId` varchar(100) NOT NULL,
  `secretKey` varchar(100) NOT NULL,
  `createdOn` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedOn` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`configId`),
  UNIQUE KEY `domainId` (`domainId`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `AppPush_main_config`
--

DROP TABLE IF EXISTS `AppPush_main_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AppPush_main_config` (
  `id` int NOT NULL AUTO_INCREMENT,
  `domainId` int DEFAULT NULL,
  `type` varchar(100) DEFAULT NULL,
  `projectId` varchar(100) DEFAULT NULL,
  `privateKeyId` varchar(600) DEFAULT NULL,
  `privateKey` varchar(5000) DEFAULT NULL,
  `clientEmail` varchar(100) DEFAULT NULL,
  `clientId` varchar(100) DEFAULT NULL,
  `authURI` varchar(100) DEFAULT NULL,
  `tokenURI` varchar(100) DEFAULT NULL,
  `authProviderURL` varchar(100) DEFAULT NULL,
  `clientURL` varchar(500) DEFAULT NULL,
  `universe_domain` varchar(100) DEFAULT NULL,
  `createdOn` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedOn` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `domainId` (`domainId`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `AppPush_tb_indiv_user_click_open_cnt_dtl`
--

DROP TABLE IF EXISTS `AppPush_tb_indiv_user_click_open_cnt_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AppPush_tb_indiv_user_click_open_cnt_dtl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `domainId` int NOT NULL,
  `campaignChatId` varchar(300) NOT NULL,
  `userID` int NOT NULL,
  `actionId` int NOT NULL,
  `channelType` varchar(20) DEFAULT 'AppPush',
  `createdOn` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `actionId` (`actionId`),
  CONSTRAINT `AppPush_tb_indiv_user_click_open_cnt_dtl_ibfk_1` FOREIGN KEY (`actionId`) REFERENCES `wc_ref_tb_Action_details` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4879 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `AppPush_tb_openRate_history_dtl`
--

DROP TABLE IF EXISTS `AppPush_tb_openRate_history_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AppPush_tb_openRate_history_dtl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `domainId` int NOT NULL,
  `campaignId` int NOT NULL,
  `campaignChatId` varchar(300) NOT NULL,
  `deviceId` varchar(100) NOT NULL,
  `status` varchar(50) NOT NULL,
  `createdOn` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedOn` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3168 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Apppush_campaign_schedule_dtl`
--

DROP TABLE IF EXISTS `Apppush_campaign_schedule_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Apppush_campaign_schedule_dtl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `domainId` int DEFAULT NULL,
  `campaignId` int DEFAULT NULL,
  `campaignChatId` varchar(300) DEFAULT NULL,
  `scheduleType` smallint DEFAULT NULL,
  `schedulefromDate` datetime DEFAULT NULL,
  `scheduletoDate` datetime DEFAULT NULL,
  `sentStatus` tinyint DEFAULT '0',
  `updatedDate` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=128 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Email_tb_indiv_admin_action_dtl`
--

DROP TABLE IF EXISTS `Email_tb_indiv_admin_action_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Email_tb_indiv_admin_action_dtl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `domainId` int NOT NULL,
  `campaignChatId` varchar(300) NOT NULL,
  `userID` int DEFAULT NULL,
  `actionId` int NOT NULL,
  `channelType` varchar(20) DEFAULT 'Email',
  `createdOn` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `actionId` (`actionId`),
  CONSTRAINT `Email_tb_indiv_admin_action_dtl_ibfk_1` FOREIGN KEY (`actionId`) REFERENCES `wc_ref_tb_Action_details` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Email_tb_indiv_user_click_open_cnt_dtl`
--

DROP TABLE IF EXISTS `Email_tb_indiv_user_click_open_cnt_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Email_tb_indiv_user_click_open_cnt_dtl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `domainId` int NOT NULL,
  `campaignChatId` varchar(300) NOT NULL,
  `userID` int NOT NULL,
  `actionId` int NOT NULL,
  `channelType` varchar(20) DEFAULT 'Email',
  `createdOn` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `actionId` (`actionId`),
  KEY `idx_Email_tb_indiv_user_click_open_cnt_dtl_actionId` (`actionId`,`campaignChatId`),
  KEY `idx_campaignchatid_domainId` (`campaignChatId`,`domainId`),
  CONSTRAINT `Email_tb_indiv_user_click_open_cnt_dtl_ibfk_1` FOREIGN KEY (`actionId`) REFERENCES `wc_ref_tb_Action_details` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1243186 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `InApp_tb_indiv_user_click_open_cnt_dtl`
--

DROP TABLE IF EXISTS `InApp_tb_indiv_user_click_open_cnt_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `InApp_tb_indiv_user_click_open_cnt_dtl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `domainId` int NOT NULL,
  `campaignChatId` varchar(300) NOT NULL,
  `userID` int NOT NULL,
  `actionId` int NOT NULL,
  `channelType` varchar(20) DEFAULT 'InApp',
  `createdOn` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `actionId` (`actionId`),
  CONSTRAINT `InApp_tb_indiv_user_click_open_cnt_dtl_ibfk_1` FOREIGN KEY (`actionId`) REFERENCES `wc_ref_tb_Action_details` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Send_Email_To_Customer_2026_01_27`
--

DROP TABLE IF EXISTS `Send_Email_To_Customer_2026_01_27`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Send_Email_To_Customer_2026_01_27` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sender_email_id` varchar(100) NOT NULL,
  `receiver_email_id` varchar(100) NOT NULL,
  `campaign_name` varchar(100) NOT NULL,
  `email_subject` varchar(50) DEFAULT NULL,
  `email_message` text,
  `send_datetime` datetime DEFAULT NULL,
  `status` tinyint DEFAULT '1',
  `createdOn` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedOn` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Sendmail_Status_Tracker_Campaign_Wise_2026_01_27`
--

DROP TABLE IF EXISTS `Sendmail_Status_Tracker_Campaign_Wise_2026_01_27`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Sendmail_Status_Tracker_Campaign_Wise_2026_01_27` (
  `tracking_id` int NOT NULL AUTO_INCREMENT,
  `sender_email_id` varchar(100) NOT NULL,
  `receiver_email_id` varchar(100) NOT NULL,
  `send_status` tinyint DEFAULT '1',
  `open_status` tinyint DEFAULT '1',
  `createdOn` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedOn` datetime DEFAULT NULL,
  PRIMARY KEY (`tracking_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Users_2026_01_27`
--

DROP TABLE IF EXISTS `Users_2026_01_27`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Users_2026_01_27` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `dob` varchar(20) NOT NULL,
  `contact_no` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `status` tinyint DEFAULT '1',
  `registration_date` date DEFAULT NULL,
  `createdOn` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedOn` datetime DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `connectors_list`
--

DROP TABLE IF EXISTS `connectors_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `connectors_list` (
  `conid` int NOT NULL AUTO_INCREMENT,
  `connector_name` varchar(100) DEFAULT NULL,
  `imageUrl` varchar(500) DEFAULT NULL,
  `createdAt` datetime DEFAULT CURRENT_TIMESTAMP,
  `isrunning` tinyint DEFAULT '1',
  `industryType` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`conid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `crm_connector_token_info`
--

DROP TABLE IF EXISTS `crm_connector_token_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `crm_connector_token_info` (
  `idcol` int NOT NULL AUTO_INCREMENT,
  `domainId` int NOT NULL,
  `roleId` int DEFAULT NULL,
  `connector_name` varchar(100) NOT NULL,
  `token` text,
  `contactSyncDetails` json DEFAULT NULL,
  `syncStatus` tinyint DEFAULT '0',
  `syncTime` bigint DEFAULT '0',
  `contactSyncType` varchar(100) DEFAULT NULL,
  `conId` int DEFAULT NULL,
  `isConnected` int DEFAULT '1',
  `createAt` datetime DEFAULT NULL,
  `updateAt` datetime DEFAULT NULL,
  PRIMARY KEY (`idcol`,`domainId`,`connector_name`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `customer_contact_18677`
--

DROP TABLE IF EXISTS `customer_contact_18677`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_contact_18677` (
  `id` int NOT NULL AUTO_INCREMENT,
  `coid` int DEFAULT NULL,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `customer_contact_18795`
--

DROP TABLE IF EXISTS `customer_contact_18795`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_contact_18795` (
  `id` int NOT NULL AUTO_INCREMENT,
  `coid` int DEFAULT NULL,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT CURRENT_TIMESTAMP,
  `fdsfsf` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `customer_contact_18852`
--

DROP TABLE IF EXISTS `customer_contact_18852`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_contact_18852` (
  `id` int NOT NULL AUTO_INCREMENT,
  `coid` int DEFAULT NULL,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT CURRENT_TIMESTAMP,
  `bggbn` varchar(50) DEFAULT NULL,
  `Country` varchar(250) DEFAULT NULL,
  `fefe` varchar(250) DEFAULT NULL,
  `rete` varchar(250) DEFAULT NULL,
  `sv` varchar(250) DEFAULT NULL,
  `rgtg` varchar(250) DEFAULT NULL,
  `gevwef` varchar(250) DEFAULT NULL,
  `tttt` varchar(250) DEFAULT NULL,
  `Chatbot` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `customer_contact_7286`
--

DROP TABLE IF EXISTS `customer_contact_7286`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_contact_7286` (
  `id` int NOT NULL AUTO_INCREMENT,
  `coid` int DEFAULT NULL,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT CURRENT_TIMESTAMP,
  `testname` varchar(50) DEFAULT NULL,
  `test` varchar(250) DEFAULT NULL,
  `l` varchar(250) DEFAULT NULL,
  `dd` varchar(250) DEFAULT NULL,
  `gd` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `customer_contact_7477`
--

DROP TABLE IF EXISTS `customer_contact_7477`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_contact_7477` (
  `id` int NOT NULL AUTO_INCREMENT,
  `coid` int DEFAULT NULL,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT CURRENT_TIMESTAMP,
  `test_test` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `customer_contact_7717`
--

DROP TABLE IF EXISTS `customer_contact_7717`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_contact_7717` (
  `id` int NOT NULL AUTO_INCREMENT,
  `coid` int DEFAULT NULL,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT CURRENT_TIMESTAMP,
  `testname` varchar(50) DEFAULT NULL,
  `testage` varchar(250) DEFAULT NULL,
  `testphone` varchar(250) DEFAULT NULL,
  `testd` varchar(250) DEFAULT NULL,
  `testdomain` varchar(250) DEFAULT NULL,
  `test_test` varchar(250) DEFAULT NULL,
  `tests` varchar(250) DEFAULT NULL,
  `tdgfdgd` varchar(250) DEFAULT NULL,
  `fghdfhfdh` varchar(250) DEFAULT NULL,
  `gjgjgj` varchar(250) DEFAULT NULL,
  `ijkkgh` varchar(250) DEFAULT NULL,
  `tgdsfgsd` varchar(250) DEFAULT NULL,
  `test` varchar(250) DEFAULT NULL,
  `jgjfgjfgj` varchar(250) DEFAULT NULL,
  `name` varchar(250) DEFAULT NULL,
  `gdfgdsf` varchar(250) DEFAULT NULL,
  `dfgdsfg` varchar(250) DEFAULT NULL,
  `asdfasdf` varchar(250) DEFAULT NULL,
  `sfdsadfasdf` varchar(250) DEFAULT NULL,
  `sdfsdfasd` varchar(250) DEFAULT NULL,
  `sdafasdf` varchar(250) DEFAULT NULL,
  `sdfsadfasdf` varchar(250) DEFAULT NULL,
  `testttt` varchar(250) DEFAULT NULL,
  `daasdfs` varchar(250) DEFAULT NULL,
  `sdfsdfddfs` varchar(250) DEFAULT NULL,
  `sdfsdfasdffsadfsdafsadf` varchar(250) DEFAULT NULL,
  `mad` varchar(250) DEFAULT NULL,
  `sdfsdf` varchar(250) DEFAULT NULL,
  `optinal` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ec_OverallClickRateDtl`
--

DROP TABLE IF EXISTS `ec_OverallClickRateDtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ec_OverallClickRateDtl` (
  `sno` int NOT NULL AUTO_INCREMENT,
  `domainId` int DEFAULT NULL,
  `campaignId` int DEFAULT NULL,
  `campaignType` varchar(20) DEFAULT 'Email',
  `clickRateCount` int DEFAULT '0',
  `emailId` varchar(500) DEFAULT NULL,
  `uniqueClickA` int DEFAULT '0',
  `uniqueClickB` int DEFAULT '0',
  `clickOn` date DEFAULT NULL,
  `createdAt` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`sno`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=650 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ec_OverallOpenRateDtl`
--

DROP TABLE IF EXISTS `ec_OverallOpenRateDtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ec_OverallOpenRateDtl` (
  `sno` int NOT NULL AUTO_INCREMENT,
  `domainId` int DEFAULT NULL,
  `campaignId` int DEFAULT NULL,
  `campaignType` varchar(20) DEFAULT 'Email',
  `openRateCount` int DEFAULT '0',
  `emailId` varchar(500) DEFAULT NULL,
  `uniqueOpenA` int DEFAULT '0',
  `uniqueOpenB` int DEFAULT '0',
  `ratedOn` date DEFAULT NULL,
  `createdAt` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`sno`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=2311 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ec_campaign_HistoryDtl`
--

DROP TABLE IF EXISTS `ec_campaign_HistoryDtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ec_campaign_HistoryDtl` (
  `sno` int NOT NULL AUTO_INCREMENT,
  `domainId` int DEFAULT NULL,
  `campaignId` int DEFAULT NULL,
  `campaignChatId` varchar(300) DEFAULT NULL,
  `campaignType` varchar(20) DEFAULT 'Email',
  `totalOpenCount` int DEFAULT '0',
  `totalClickCount` int DEFAULT '0',
  `uniqueOpenCount` int DEFAULT '0',
  `uniqueClickCount` int DEFAULT '0',
  `deliveryCount` int DEFAULT NULL,
  `createdAt` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`sno`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=912 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ec_campaign_clickRate_history_dtl`
--

DROP TABLE IF EXISTS `ec_campaign_clickRate_history_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ec_campaign_clickRate_history_dtl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `domainId` int NOT NULL,
  `campaignId` int NOT NULL,
  `emailId` int NOT NULL,
  `uniqueClickA` int DEFAULT NULL,
  `uniqueClickB` int DEFAULT NULL,
  `CreatedOn` datetime DEFAULT CURRENT_TIMESTAMP,
  `UpdatedOn` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8411 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ec_campaign_contacts_dtl`
--

DROP TABLE IF EXISTS `ec_campaign_contacts_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ec_campaign_contacts_dtl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `createdate` datetime DEFAULT CURRENT_TIMESTAMP,
  `domainId` int DEFAULT NULL,
  `campaignId` int DEFAULT NULL,
  `contactEmail` varchar(100) DEFAULT NULL,
  `isSent` tinyint DEFAULT '0',
  `Template` varchar(2) DEFAULT NULL,
  `templateType` char(1) DEFAULT NULL,
  `isStop` tinyint NOT NULL DEFAULT '0',
  `deliveryTime` datetime DEFAULT NULL,
  `stopTime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_campaign_sent_stop` (`campaignId`,`isSent`,`isStop`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=197094 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ec_campaign_contacts_dtl_backup`
--

DROP TABLE IF EXISTS `ec_campaign_contacts_dtl_backup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ec_campaign_contacts_dtl_backup` (
  `id` int NOT NULL DEFAULT '0',
  `createdate` datetime DEFAULT CURRENT_TIMESTAMP,
  `domainId` int DEFAULT NULL,
  `campaignId` int DEFAULT NULL,
  `contactEmail` varchar(100) DEFAULT NULL,
  `isSent` tinyint DEFAULT '0',
  `Template` varchar(2) DEFAULT NULL,
  `templateType` char(1) DEFAULT NULL,
  `deliveryTime` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ec_campaign_contacts_dtl_backup_22122025`
--

DROP TABLE IF EXISTS `ec_campaign_contacts_dtl_backup_22122025`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ec_campaign_contacts_dtl_backup_22122025` (
  `id` int NOT NULL DEFAULT '0',
  `createdate` datetime DEFAULT CURRENT_TIMESTAMP,
  `domainId` int DEFAULT NULL,
  `campaignId` int DEFAULT NULL,
  `contactEmail` varchar(100) DEFAULT NULL,
  `isSent` tinyint DEFAULT '0',
  `Template` varchar(2) DEFAULT NULL,
  `templateType` char(1) DEFAULT NULL,
  `deliveryTime` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ec_campaign_contacts_dtl_bkp_2026_02_16`
--

DROP TABLE IF EXISTS `ec_campaign_contacts_dtl_bkp_2026_02_16`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ec_campaign_contacts_dtl_bkp_2026_02_16` (
  `id` int NOT NULL DEFAULT '0',
  `createdate` datetime DEFAULT CURRENT_TIMESTAMP,
  `domainId` int DEFAULT NULL,
  `campaignId` int DEFAULT NULL,
  `contactEmail` varchar(100) DEFAULT NULL,
  `isSent` tinyint DEFAULT '0',
  `Template` varchar(2) DEFAULT NULL,
  `templateType` char(1) DEFAULT NULL,
  `isStop` tinyint NOT NULL DEFAULT '0',
  `deliveryTime` datetime DEFAULT NULL,
  `stopTime` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ec_campaign_contacts_dtl_bkp_2026_02_16_2`
--

DROP TABLE IF EXISTS `ec_campaign_contacts_dtl_bkp_2026_02_16_2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ec_campaign_contacts_dtl_bkp_2026_02_16_2` (
  `id` int NOT NULL DEFAULT '0',
  `createdate` datetime DEFAULT CURRENT_TIMESTAMP,
  `domainId` int DEFAULT NULL,
  `campaignId` int DEFAULT NULL,
  `contactEmail` varchar(100) DEFAULT NULL,
  `isSent` tinyint DEFAULT '0',
  `Template` varchar(2) DEFAULT NULL,
  `templateType` char(1) DEFAULT NULL,
  `isStop` tinyint NOT NULL DEFAULT '0',
  `deliveryTime` datetime DEFAULT NULL,
  `stopTime` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ec_campaign_contacts_dtl_bkp_2026_02_20`
--

DROP TABLE IF EXISTS `ec_campaign_contacts_dtl_bkp_2026_02_20`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ec_campaign_contacts_dtl_bkp_2026_02_20` (
  `id` int NOT NULL DEFAULT '0',
  `createdate` datetime DEFAULT CURRENT_TIMESTAMP,
  `domainId` int DEFAULT NULL,
  `campaignId` int DEFAULT NULL,
  `contactEmail` varchar(100) DEFAULT NULL,
  `isSent` tinyint DEFAULT '0',
  `Template` varchar(2) DEFAULT NULL,
  `templateType` char(1) DEFAULT NULL,
  `isStop` tinyint NOT NULL DEFAULT '0',
  `deliveryTime` datetime DEFAULT NULL,
  `stopTime` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ec_campaign_contacts_dtl_test_2026_01_29`
--

DROP TABLE IF EXISTS `ec_campaign_contacts_dtl_test_2026_01_29`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ec_campaign_contacts_dtl_test_2026_01_29` (
  `id` int NOT NULL AUTO_INCREMENT,
  `createdate` datetime DEFAULT CURRENT_TIMESTAMP,
  `domainId` int DEFAULT NULL,
  `campaignId` int DEFAULT NULL,
  `contactEmail` varchar(100) DEFAULT NULL,
  `isSent` tinyint DEFAULT '0',
  `Template` varchar(2) DEFAULT NULL,
  `templateType` char(1) DEFAULT NULL,
  `isStop` tinyint NOT NULL DEFAULT '0',
  `deliveryTime` datetime DEFAULT NULL,
  `stopTime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=181059 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ec_campaign_folder_list`
--

DROP TABLE IF EXISTS `ec_campaign_folder_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ec_campaign_folder_list` (
  `id` int NOT NULL AUTO_INCREMENT,
  `createdate` datetime DEFAULT CURRENT_TIMESTAMP,
  `domainId` int DEFAULT NULL,
  `folderid` int DEFAULT NULL,
  `campaignId` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ec_campaign_openRate_history_dtl`
--

DROP TABLE IF EXISTS `ec_campaign_openRate_history_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ec_campaign_openRate_history_dtl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `domainId` int NOT NULL,
  `campaignId` int NOT NULL,
  `emailId` int NOT NULL,
  `uniqueOpenA` int DEFAULT NULL,
  `uniqueOpenB` int DEFAULT NULL,
  `CreatedOn` datetime DEFAULT CURRENT_TIMESTAMP,
  `UpdatedOn` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22958 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ec_campaign_winning_dtl`
--

DROP TABLE IF EXISTS `ec_campaign_winning_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ec_campaign_winning_dtl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `createdate` datetime DEFAULT CURRENT_TIMESTAMP,
  `campaignId` int DEFAULT NULL,
  `A` int DEFAULT '0',
  `B` int DEFAULT '0',
  `updatedDate` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ec_email_campaign_AB_testing_dtl`
--

DROP TABLE IF EXISTS `ec_email_campaign_AB_testing_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ec_email_campaign_AB_testing_dtl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `createdate` datetime DEFAULT CURRENT_TIMESTAMP,
  `campaignId` int DEFAULT NULL,
  `testtype` int DEFAULT NULL,
  `variant` json DEFAULT NULL,
  `variantDistribution` json DEFAULT NULL,
  `winningCriteria` int DEFAULT NULL,
  `AB_testWindow` int DEFAULT NULL,
  `AB_testWindowtype` int DEFAULT NULL,
  `examineTime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=393 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ec_email_campaign_AB_testing_dtl_test_test_2026_01_29`
--

DROP TABLE IF EXISTS `ec_email_campaign_AB_testing_dtl_test_test_2026_01_29`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ec_email_campaign_AB_testing_dtl_test_test_2026_01_29` (
  `id` int NOT NULL AUTO_INCREMENT,
  `createdate` datetime DEFAULT CURRENT_TIMESTAMP,
  `campaignId` int DEFAULT NULL,
  `testtype` int DEFAULT NULL,
  `variant` json DEFAULT NULL,
  `variantDistribution` json DEFAULT NULL,
  `winningCriteria` int DEFAULT NULL,
  `AB_testWindow` int DEFAULT NULL,
  `AB_testWindowtype` int DEFAULT NULL,
  `examineTime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ec_email_campaign_config_dtl`
--

DROP TABLE IF EXISTS `ec_email_campaign_config_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ec_email_campaign_config_dtl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `domainId` int NOT NULL,
  `emailId` varchar(70) NOT NULL,
  `aliasName` varchar(50) DEFAULT NULL,
  `isBot` tinyint NOT NULL DEFAULT '0',
  `createdOn` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedOn` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ec_email_campaign_master_dtl`
--

DROP TABLE IF EXISTS `ec_email_campaign_master_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ec_email_campaign_master_dtl` (
  `campaignId` int NOT NULL AUTO_INCREMENT,
  `campaignchatid` varchar(300) NOT NULL,
  `createdate` datetime DEFAULT CURRENT_TIMESTAMP,
  `domainId` int NOT NULL,
  `Name` text,
  `Goal` text,
  `Type` varchar(100) DEFAULT NULL,
  `TargetAud` varchar(100) DEFAULT NULL,
  `Objective` text,
  `isIndivCamp` tinyint NOT NULL DEFAULT '0' COMMENT '0-Normal Campaign, 1-Hubspot Campaign, 2-Admin Approval Campaign, 3-Campaign Notification',
  `AB_testing` tinyint DEFAULT '0',
  `AItemplateA` json DEFAULT NULL,
  `AItemplateB` json DEFAULT NULL,
  `contactslist` json DEFAULT NULL,
  `emailDelivery` int DEFAULT NULL,
  `emailDeliveryAt` date DEFAULT NULL,
  `emailDeliveryStarttime` date DEFAULT NULL,
  `emailDeliveryEndtime` date DEFAULT NULL,
  `createdBy` varchar(100) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`campaignId`),
  UNIQUE KEY `campaignchatid` (`campaignchatid`),
  KEY `idx_email_campaign_master_dtl_campaignchatid_domainId` (`campaignchatid`,`domainId`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=2754 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ec_email_campaign_master_dtl_Backup20251028`
--

DROP TABLE IF EXISTS `ec_email_campaign_master_dtl_Backup20251028`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ec_email_campaign_master_dtl_Backup20251028` (
  `campaignId` int NOT NULL AUTO_INCREMENT,
  `campaignchatid` varchar(300) DEFAULT NULL,
  `createdate` datetime DEFAULT CURRENT_TIMESTAMP,
  `domainId` int DEFAULT NULL,
  `Name` text,
  `Goal` text,
  `Type` varchar(100) DEFAULT NULL,
  `TargetAud` varchar(100) DEFAULT NULL,
  `Objective` text,
  `AB_testing` tinyint DEFAULT '0',
  `AItemplateA` json DEFAULT NULL,
  `AItemplateB` json DEFAULT NULL,
  `contactslist` json DEFAULT NULL,
  `emailDelivery` int DEFAULT NULL,
  `emailDeliveryAt` date DEFAULT NULL,
  `emailDeliveryStarttime` date DEFAULT NULL,
  `emailDeliveryEndtime` date DEFAULT NULL,
  `createdBy` varchar(100) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`campaignId`),
  UNIQUE KEY `campaignchatid` (`campaignchatid`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=140 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ec_email_campaign_master_dtl_backup_domain_18852`
--

DROP TABLE IF EXISTS `ec_email_campaign_master_dtl_backup_domain_18852`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ec_email_campaign_master_dtl_backup_domain_18852` (
  `campaignId` int DEFAULT NULL,
  `campaignchatid` varchar(300) DEFAULT NULL,
  `createdate` datetime DEFAULT NULL,
  `domainId` int DEFAULT NULL,
  `Name` text,
  `Goal` text,
  `Type` varchar(100) DEFAULT NULL,
  `TargetAud` varchar(100) DEFAULT NULL,
  `Objective` text,
  `AB_testing` tinyint DEFAULT NULL,
  `AItemplateA` json DEFAULT NULL,
  `AItemplateB` json DEFAULT NULL,
  `contactslist` json DEFAULT NULL,
  `emailDelivery` int DEFAULT NULL,
  `emailDeliveryAt` date DEFAULT NULL,
  `emailDeliveryStarttime` date DEFAULT NULL,
  `emailDeliveryEndtime` date DEFAULT NULL,
  `createdBy` varchar(100) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ec_email_campaign_master_dtl_exclude_email`
--

DROP TABLE IF EXISTS `ec_email_campaign_master_dtl_exclude_email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ec_email_campaign_master_dtl_exclude_email` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fk_campaignId` int NOT NULL,
  `campaignchatid` varchar(300) NOT NULL,
  `createdate` datetime DEFAULT CURRENT_TIMESTAMP,
  `domainId` int NOT NULL,
  `contactslist` json DEFAULT NULL,
  `createdBy` varchar(100) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `checkDomainIdChatId` (`campaignchatid`),
  KEY `index_fk_campaignId` (`fk_campaignId`),
  CONSTRAINT `fk_exclude_campaign` FOREIGN KEY (`fk_campaignId`) REFERENCES `ec_email_campaign_master_dtl` (`campaignId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=347 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ec_email_campaign_master_dtl_test_test_2026_01_29`
--

DROP TABLE IF EXISTS `ec_email_campaign_master_dtl_test_test_2026_01_29`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ec_email_campaign_master_dtl_test_test_2026_01_29` (
  `campaignId` int NOT NULL AUTO_INCREMENT,
  `campaignchatid` varchar(300) NOT NULL,
  `createdate` datetime DEFAULT CURRENT_TIMESTAMP,
  `domainId` int NOT NULL,
  `Name` text,
  `Goal` text,
  `Type` varchar(100) DEFAULT NULL,
  `TargetAud` varchar(100) DEFAULT NULL,
  `Objective` text,
  `isIndivCamp` tinyint NOT NULL DEFAULT '0',
  `AB_testing` tinyint DEFAULT '0',
  `AItemplateA` json DEFAULT NULL,
  `AItemplateB` json DEFAULT NULL,
  `contactslist` json DEFAULT NULL,
  `emailDelivery` int DEFAULT NULL,
  `emailDeliveryAt` date DEFAULT NULL,
  `emailDeliveryStarttime` date DEFAULT NULL,
  `emailDeliveryEndtime` date DEFAULT NULL,
  `createdBy` varchar(100) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`campaignId`),
  UNIQUE KEY `campaignchatid` (`campaignchatid`),
  KEY `idx_email_campaign_master_dtl_campaignchatid_domainId` (`campaignchatid`,`domainId`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ec_email_campaign_search_history`
--

DROP TABLE IF EXISTS `ec_email_campaign_search_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ec_email_campaign_search_history` (
  `id` int NOT NULL AUTO_INCREMENT,
  `domain_id` int DEFAULT NULL,
  `search_details` text,
  `created_on` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_on` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ec_email_failed_contact_dtl`
--

DROP TABLE IF EXISTS `ec_email_failed_contact_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ec_email_failed_contact_dtl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `domainId` int NOT NULL,
  `campaignId` int NOT NULL,
  `campaignChatId` varchar(300) NOT NULL,
  `userId` int DEFAULT NULL,
  `contactEmail` varchar(100) NOT NULL,
  `createdOn` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedOn` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2277 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ec_email_unsubscribe_dtl`
--

DROP TABLE IF EXISTS `ec_email_unsubscribe_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ec_email_unsubscribe_dtl` (
  `unSubId` int NOT NULL AUTO_INCREMENT,
  `domainId` int NOT NULL,
  `campaignchatid` varchar(300) NOT NULL,
  `emailId` varchar(150) NOT NULL,
  `tempType` char(5) NOT NULL,
  `createdOn` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`unSubId`)
) ENGINE=InnoDB AUTO_INCREMENT=159 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ec_folder_dtl`
--

DROP TABLE IF EXISTS `ec_folder_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ec_folder_dtl` (
  `folderid` int NOT NULL AUTO_INCREMENT,
  `createdate` datetime DEFAULT CURRENT_TIMESTAMP,
  `domainId` int DEFAULT NULL,
  `folderName` varchar(150) DEFAULT NULL,
  `createdBy` varchar(100) DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`folderid`)
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ec_tb_smtp_config_dtl`
--

DROP TABLE IF EXISTS `ec_tb_smtp_config_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ec_tb_smtp_config_dtl` (
  `config_id` int NOT NULL AUTO_INCREMENT,
  `domainId` int DEFAULT NULL,
  `aliasName` varchar(50) DEFAULT NULL,
  `port` int DEFAULT NULL,
  `host` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `userName` varchar(50) DEFAULT NULL,
  `fromEmail` varchar(50) DEFAULT NULL,
  `isBot` tinyint DEFAULT '0',
  `createdOn` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedOn` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`config_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `inApp_SearchHistoryDtl`
--

DROP TABLE IF EXISTS `inApp_SearchHistoryDtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inApp_SearchHistoryDtl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `domainId` int NOT NULL,
  `searchDetails` longtext,
  `createdOn` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedOn` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `inApp_campaignHistoryDtl`
--

DROP TABLE IF EXISTS `inApp_campaignHistoryDtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inApp_campaignHistoryDtl` (
  `historyid` int NOT NULL AUTO_INCREMENT,
  `domainId` int NOT NULL,
  `campaignId` int NOT NULL,
  `campaignName` varchar(300) NOT NULL,
  `campaignType` varchar(20) DEFAULT 'inApp',
  `historyDtl` json DEFAULT NULL,
  `createdOn` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedOn` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`historyid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `inApp_campaign_contacts_dtl`
--

DROP TABLE IF EXISTS `inApp_campaign_contacts_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inApp_campaign_contacts_dtl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `createdate` datetime DEFAULT CURRENT_TIMESTAMP,
  `domainId` int DEFAULT NULL,
  `campaignId` int DEFAULT NULL,
  `deviceId` varchar(50) DEFAULT NULL,
  `sip_log_id` bigint DEFAULT NULL,
  `extension` int DEFAULT NULL,
  `isSent` tinyint DEFAULT '0',
  `Template` varchar(2) DEFAULT NULL,
  `templateType` char(1) DEFAULT NULL,
  `deliveryTime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `inApp_campaign_master_dtl`
--

DROP TABLE IF EXISTS `inApp_campaign_master_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inApp_campaign_master_dtl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `domainId` int NOT NULL,
  `campaignChatId` varchar(300) DEFAULT NULL,
  `campaignName` varchar(250) DEFAULT NULL,
  `campaignGoal` varchar(250) DEFAULT NULL,
  `industryType` varchar(250) DEFAULT NULL,
  `objective` varchar(400) DEFAULT NULL,
  `urlDtl` varchar(250) DEFAULT NULL,
  `scheduleType` smallint DEFAULT NULL,
  `targetAudienceType` int DEFAULT NULL,
  `contactDtl` json DEFAULT NULL,
  `TemplateDtl` json DEFAULT NULL,
  `deviceDtl` json DEFAULT NULL,
  `sourceDtl` varchar(15) DEFAULT NULL,
  `Status` varchar(50) DEFAULT NULL,
  `ImgUrl` varchar(350) DEFAULT NULL,
  `createdOn` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedOn` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `campaignChatId` (`campaignChatId`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `inApp_campaign_schedule_dtl`
--

DROP TABLE IF EXISTS `inApp_campaign_schedule_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inApp_campaign_schedule_dtl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `campaignId` int NOT NULL,
  `triggerType` int NOT NULL,
  `scheduleFromDate` datetime DEFAULT NULL,
  `scheduleToDate` datetime DEFAULT NULL,
  `cronStatus` tinyint DEFAULT '0',
  `sentStatus` tinyint DEFAULT '0',
  `createdOn` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedOn` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sc_SMSConfigDtl`
--

DROP TABLE IF EXISTS `sc_SMSConfigDtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_SMSConfigDtl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `domainId` int DEFAULT NULL,
  `senderNumber` varchar(20) DEFAULT NULL,
  `aliasName` varchar(150) DEFAULT NULL,
  `senderId` varchar(150) DEFAULT NULL,
  `SMSEnable` tinyint DEFAULT '0',
  `SMSBot` tinyint DEFAULT '0',
  `createdOn` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedOn` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sc_SMSOverallHistoryDtl`
--

DROP TABLE IF EXISTS `sc_SMSOverallHistoryDtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_SMSOverallHistoryDtl` (
  `SMSHistoryid` int NOT NULL AUTO_INCREMENT,
  `domainId` int DEFAULT NULL,
  `campaignId` int DEFAULT NULL,
  `campaignName` varchar(150) DEFAULT NULL,
  `triggerType` int DEFAULT NULL,
  `senderName` varchar(100) DEFAULT NULL,
  `contactDtl` json DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `schedulefromDate` datetime DEFAULT NULL,
  `createdDateOn` datetime DEFAULT NULL,
  `updatedOn` datetime DEFAULT NULL,
  PRIMARY KEY (`SMSHistoryid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sc_SMSTagCampMapping`
--

DROP TABLE IF EXISTS `sc_SMSTagCampMapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_SMSTagCampMapping` (
  `TM_no` int NOT NULL AUTO_INCREMENT,
  `TagId` int DEFAULT NULL,
  `Campaignid` int DEFAULT NULL,
  PRIMARY KEY (`TM_no`),
  UNIQUE KEY `TaId` (`TagId`,`Campaignid`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sc_SMS_sent_status_details`
--

DROP TABLE IF EXISTS `sc_SMS_sent_status_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_SMS_sent_status_details` (
  `id` int NOT NULL AUTO_INCREMENT,
  `domainId` int NOT NULL,
  `campaignChatId` varchar(300) NOT NULL,
  `fromMobileNo` varchar(20) NOT NULL,
  `toMobileNo` varchar(20) NOT NULL,
  `status` varchar(50) NOT NULL,
  `createdOn` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedOn` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `messageId` varchar(100) DEFAULT NULL,
  `sentAt` datetime DEFAULT CURRENT_TIMESTAMP,
  `description` varchar(800) DEFAULT NULL,
  `bulkId` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6125 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sc_SMScampaignTagDtl`
--

DROP TABLE IF EXISTS `sc_SMScampaignTagDtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_SMScampaignTagDtl` (
  `TagId` int NOT NULL AUTO_INCREMENT,
  `domainId` int DEFAULT NULL,
  `Tags` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`TagId`),
  UNIQUE KEY `domainId` (`domainId`,`Tags`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sc_SMSsearchHistoryDtl`
--

DROP TABLE IF EXISTS `sc_SMSsearchHistoryDtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_SMSsearchHistoryDtl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `domainId` int NOT NULL,
  `searchDetails` longtext,
  `createdOn` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedOn` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sc_campaign_master_dtl`
--

DROP TABLE IF EXISTS `sc_campaign_master_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_campaign_master_dtl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `campaignchatid` varchar(300) NOT NULL,
  `createdDate` datetime DEFAULT CURRENT_TIMESTAMP,
  `domainId` int NOT NULL,
  `name` varchar(250) DEFAULT NULL,
  `campaignGoal` varchar(250) DEFAULT NULL,
  `campaignObjective` varchar(400) DEFAULT NULL,
  `websiteURL` varchar(250) DEFAULT NULL,
  `targetAudienceType` int DEFAULT NULL,
  `contactDtls` json DEFAULT NULL,
  `senderName` varchar(250) DEFAULT NULL,
  `templatePrompt` text,
  `triggerType` int DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `updateddate` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `campaignchatid` (`campaignchatid`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=214 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sc_campaign_master_dtl_Backup20251028`
--

DROP TABLE IF EXISTS `sc_campaign_master_dtl_Backup20251028`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_campaign_master_dtl_Backup20251028` (
  `id` int NOT NULL AUTO_INCREMENT,
  `campaignchatid` varchar(300) DEFAULT NULL,
  `createdDate` datetime DEFAULT CURRENT_TIMESTAMP,
  `domainId` int DEFAULT NULL,
  `name` varchar(250) DEFAULT NULL,
  `campaignGoal` varchar(250) DEFAULT NULL,
  `campaignObjective` varchar(400) DEFAULT NULL,
  `websiteURL` varchar(250) DEFAULT NULL,
  `targetAudienceType` int DEFAULT NULL,
  `contactDtls` json DEFAULT NULL,
  `senderName` varchar(250) DEFAULT NULL,
  `templatePrompt` text,
  `triggerType` int DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `updateddate` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `campaignchatid` (`campaignchatid`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sc_campaign_master_schedule_dtl`
--

DROP TABLE IF EXISTS `sc_campaign_master_schedule_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_campaign_master_schedule_dtl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `domainId` int DEFAULT NULL,
  `campaignId` int DEFAULT NULL,
  `schedulefromDate` datetime DEFAULT NULL,
  `scheduletoDate` datetime DEFAULT NULL,
  `sentStatus` tinyint DEFAULT '0',
  `updatedDate` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=230 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sms_tb_indiv_user_click_open_cnt_dtl`
--

DROP TABLE IF EXISTS `sms_tb_indiv_user_click_open_cnt_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sms_tb_indiv_user_click_open_cnt_dtl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `domainId` int NOT NULL,
  `campaignChatId` varchar(300) NOT NULL,
  `userID` int NOT NULL,
  `actionId` int NOT NULL,
  `channelType` varchar(20) DEFAULT 'SMS',
  `createdOn` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `actionId` (`actionId`),
  CONSTRAINT `sms_tb_indiv_user_click_open_cnt_dtl_ibfk_1` FOREIGN KEY (`actionId`) REFERENCES `wc_ref_tb_Action_details` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=531 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_StoreConnection`
--

DROP TABLE IF EXISTS `tb_StoreConnection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_StoreConnection` (
  `conId` int NOT NULL,
  `domainId` int NOT NULL,
  `domainName` varchar(150) DEFAULT NULL,
  `shopDomain` varchar(100) DEFAULT NULL,
  `accessToken` varchar(250) DEFAULT NULL,
  `isConnected` tinyint DEFAULT NULL,
  `connectionName` varchar(250) DEFAULT NULL,
  `connectorName` varchar(100) DEFAULT NULL,
  `token` longtext,
  `userName` varchar(150) DEFAULT NULL,
  `pwd` varchar(100) DEFAULT NULL,
  `syncStatus` tinyint DEFAULT '0',
  `syncTime` bigint DEFAULT '0',
  `contactSyncDetails` json DEFAULT NULL,
  `contactSyncType` varchar(100) DEFAULT NULL,
  `scriptId` varchar(1000) DEFAULT NULL,
  `botData` varchar(1000) DEFAULT NULL,
  `chatWidgetStatus` tinyint DEFAULT NULL,
  `settings` json DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `updatedDate` datetime DEFAULT NULL,
  `StoreConnectionId` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`StoreConnectionId`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_campaignContactFileHistory`
--

DROP TABLE IF EXISTS `tb_campaignContactFileHistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_campaignContactFileHistory` (
  `fileId` int NOT NULL AUTO_INCREMENT,
  `domainId` int NOT NULL,
  `fileName` varchar(150) NOT NULL,
  `filePath` varchar(300) NOT NULL,
  `status` varchar(50) DEFAULT NULL,
  `records` int DEFAULT '0',
  `createdOn` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedOn` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`fileId`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_campaign_knowledge_base_dtl`
--

DROP TABLE IF EXISTS `tb_campaign_knowledge_base_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_campaign_knowledge_base_dtl` (
  `kbCampId` int NOT NULL AUTO_INCREMENT,
  `domainId` int NOT NULL,
  `filename` varchar(100) DEFAULT NULL,
  `mimetype` varchar(100) DEFAULT NULL,
  `size` int DEFAULT NULL,
  `uploadUrl` varchar(250) DEFAULT NULL,
  `industrial_type` varchar(70) DEFAULT NULL,
  `companyName` varchar(50) NOT NULL,
  `url` varchar(300) DEFAULT NULL,
  `contact_info` json DEFAULT NULL,
  `product_info` json DEFAULT NULL,
  `pdf_info` json DEFAULT NULL,
  `createdOn` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedOn` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`kbCampId`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_contact_dtl`
--

DROP TABLE IF EXISTS `user_contact_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_contact_dtl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `domainId` int NOT NULL,
  `createdAt` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wc_AI_convertation_master_details`
--

DROP TABLE IF EXISTS `wc_AI_convertation_master_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wc_AI_convertation_master_details` (
  `id` int NOT NULL AUTO_INCREMENT,
  `campaignchatid` varchar(300) NOT NULL,
  `domainId` int NOT NULL,
  `conversationName` varchar(300) DEFAULT NULL,
  `conversation` json DEFAULT NULL,
  `team` smallint NOT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'DRAFT',
  `isArchieve` tinyint NOT NULL DEFAULT '0',
  `uploadedImages` json DEFAULT NULL,
  `campaignPayload` json DEFAULT NULL,
  `createdOn` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedOn` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `Idx_campaignchatid` (`campaignchatid`)
) ENGINE=InnoDB AUTO_INCREMENT=2298 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wc_AI_recommmendation_dtl`
--

DROP TABLE IF EXISTS `wc_AI_recommmendation_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wc_AI_recommmendation_dtl` (
  `domainId` int NOT NULL,
  `recommendation` text,
  `createdOn` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedOn` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`domainId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wc_TagCampMapping`
--

DROP TABLE IF EXISTS `wc_TagCampMapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wc_TagCampMapping` (
  `TM_no` int NOT NULL AUTO_INCREMENT,
  `TagId` int DEFAULT NULL,
  `Campaignid` int DEFAULT NULL,
  PRIMARY KEY (`TM_no`),
  UNIQUE KEY `TaId` (`TagId`,`Campaignid`)
) ENGINE=InnoDB AUTO_INCREMENT=78 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wc_analytics_history_dtl`
--

DROP TABLE IF EXISTS `wc_analytics_history_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wc_analytics_history_dtl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `domainId` int NOT NULL,
  `campaignchatId` varchar(300) NOT NULL,
  `campaignId` int DEFAULT NULL,
  `fromNo` varchar(30) DEFAULT NULL,
  `toNo` varchar(30) DEFAULT NULL,
  `messageId` varchar(500) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `createdOn` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedOn` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=288 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wc_business_configuration`
--

DROP TABLE IF EXISTS `wc_business_configuration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wc_business_configuration` (
  `id` int NOT NULL AUTO_INCREMENT,
  `createdDate` datetime DEFAULT CURRENT_TIMESTAMP,
  `domainId` int DEFAULT NULL,
  `businessName` varchar(100) DEFAULT NULL,
  `mobileNumber` varchar(30) NOT NULL,
  `status` varchar(30) DEFAULT NULL,
  `isactive` tinyint DEFAULT '1',
  `messageLimit` int DEFAULT NULL,
  `updateddate` datetime DEFAULT NULL,
  `appId` varchar(200) DEFAULT NULL,
  `appSecret` varchar(200) DEFAULT NULL,
  `authToken` varchar(500) DEFAULT NULL,
  `phoneNumberId` varchar(200) DEFAULT NULL,
  `wabaId` varchar(200) DEFAULT NULL,
  `businessId` varchar(200) DEFAULT NULL,
  `isBot` tinyint DEFAULT '0',
  `updatedOn` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mobileBasedDomainId` (`domainId`,`mobileNumber`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wc_business_configuration_bkp_2026_02_13`
--

DROP TABLE IF EXISTS `wc_business_configuration_bkp_2026_02_13`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wc_business_configuration_bkp_2026_02_13` (
  `id` int NOT NULL AUTO_INCREMENT,
  `createdDate` datetime DEFAULT CURRENT_TIMESTAMP,
  `domainId` int DEFAULT NULL,
  `businessName` varchar(100) DEFAULT NULL,
  `mobileNumber` varchar(30) NOT NULL,
  `status` varchar(30) DEFAULT NULL,
  `isactive` tinyint DEFAULT '1',
  `messageLimit` int DEFAULT NULL,
  `updateddate` datetime DEFAULT NULL,
  `appId` varchar(200) DEFAULT NULL,
  `appSecret` varchar(200) DEFAULT NULL,
  `authToken` varchar(500) DEFAULT NULL,
  `phoneNumberId` varchar(200) DEFAULT NULL,
  `wabaId` varchar(200) DEFAULT NULL,
  `businessId` varchar(200) DEFAULT NULL,
  `isBot` tinyint DEFAULT '0',
  `updatedOn` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mobileBasedDomainId` (`domainId`,`mobileNumber`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wc_business_configuration_bkp_2026_02_14`
--

DROP TABLE IF EXISTS `wc_business_configuration_bkp_2026_02_14`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wc_business_configuration_bkp_2026_02_14` (
  `id` int NOT NULL DEFAULT '0',
  `createdDate` datetime DEFAULT CURRENT_TIMESTAMP,
  `domainId` int DEFAULT NULL,
  `businessName` varchar(100) DEFAULT NULL,
  `mobileNumber` varchar(30) NOT NULL,
  `status` varchar(30) DEFAULT NULL,
  `isactive` tinyint DEFAULT '1',
  `messageLimit` int DEFAULT NULL,
  `updateddate` datetime DEFAULT NULL,
  `appId` varchar(200) DEFAULT NULL,
  `appSecret` varchar(200) DEFAULT NULL,
  `authToken` varchar(500) DEFAULT NULL,
  `phoneNumberId` varchar(200) DEFAULT NULL,
  `wabaId` varchar(200) DEFAULT NULL,
  `businessId` varchar(200) DEFAULT NULL,
  `isBot` tinyint DEFAULT '0',
  `updatedOn` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wc_business_configuration_bkp_2026_02_16`
--

DROP TABLE IF EXISTS `wc_business_configuration_bkp_2026_02_16`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wc_business_configuration_bkp_2026_02_16` (
  `id` int NOT NULL AUTO_INCREMENT,
  `createdDate` datetime DEFAULT CURRENT_TIMESTAMP,
  `domainId` int DEFAULT NULL,
  `businessName` varchar(100) DEFAULT NULL,
  `mobileNumber` varchar(30) NOT NULL,
  `status` varchar(30) DEFAULT NULL,
  `isactive` tinyint DEFAULT '1',
  `messageLimit` int DEFAULT NULL,
  `updateddate` datetime DEFAULT NULL,
  `appId` varchar(200) DEFAULT NULL,
  `appSecret` varchar(200) DEFAULT NULL,
  `authToken` varchar(500) DEFAULT NULL,
  `phoneNumberId` varchar(200) DEFAULT NULL,
  `wabaId` varchar(200) DEFAULT NULL,
  `businessId` varchar(200) DEFAULT NULL,
  `isBot` tinyint DEFAULT '0',
  `updatedOn` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mobileBasedDomainId` (`domainId`,`mobileNumber`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wc_business_configuration_bkp_2026_02_17`
--

DROP TABLE IF EXISTS `wc_business_configuration_bkp_2026_02_17`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wc_business_configuration_bkp_2026_02_17` (
  `id` int NOT NULL AUTO_INCREMENT,
  `createdDate` datetime DEFAULT CURRENT_TIMESTAMP,
  `domainId` int DEFAULT NULL,
  `businessName` varchar(100) DEFAULT NULL,
  `mobileNumber` varchar(30) NOT NULL,
  `status` varchar(30) DEFAULT NULL,
  `isactive` tinyint DEFAULT '1',
  `messageLimit` int DEFAULT NULL,
  `updateddate` datetime DEFAULT NULL,
  `appId` varchar(200) DEFAULT NULL,
  `appSecret` varchar(200) DEFAULT NULL,
  `authToken` varchar(500) DEFAULT NULL,
  `phoneNumberId` varchar(200) DEFAULT NULL,
  `wabaId` varchar(200) DEFAULT NULL,
  `businessId` varchar(200) DEFAULT NULL,
  `isBot` tinyint DEFAULT '0',
  `updatedOn` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mobileBasedDomainId` (`domainId`,`mobileNumber`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wc_campaignTagDtl`
--

DROP TABLE IF EXISTS `wc_campaignTagDtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wc_campaignTagDtl` (
  `TagId` int NOT NULL AUTO_INCREMENT,
  `domainId` int DEFAULT NULL,
  `Tags` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`TagId`),
  UNIQUE KEY `domainId` (`domainId`,`Tags`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wc_campaign_master_dtl`
--

DROP TABLE IF EXISTS `wc_campaign_master_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wc_campaign_master_dtl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `domainId` int NOT NULL,
  `campaignchatid` varchar(300) NOT NULL,
  `campName` varchar(255) NOT NULL,
  `campType` varchar(255) NOT NULL,
  `tags` varchar(100) DEFAULT NULL,
  `contactList` json DEFAULT NULL,
  `template` varchar(150) NOT NULL,
  `templateId` int DEFAULT NULL,
  `triggerType` int NOT NULL,
  `recurring` json DEFAULT NULL,
  `lastRecurrentDate` date DEFAULT NULL,
  `scheduleDate` varchar(20) DEFAULT NULL,
  `cloneStatus` tinyint DEFAULT NULL,
  `listId` int DEFAULT NULL,
  `listName` varchar(150) DEFAULT NULL,
  `templateData` json DEFAULT NULL,
  `optimalType` tinyint DEFAULT NULL,
  `createdDate` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedDate` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `campaignStatus` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `campaignchatId` (`campaignchatid`),
  KEY `campaign_dtl_FK` (`templateId`),
  CONSTRAINT `campaign_dtl_FK` FOREIGN KEY (`templateId`) REFERENCES `wc_template_master_dtl` (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=174 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wc_campaign_master_dtl_Backup20251028`
--

DROP TABLE IF EXISTS `wc_campaign_master_dtl_Backup20251028`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wc_campaign_master_dtl_Backup20251028` (
  `id` int NOT NULL AUTO_INCREMENT,
  `domainId` int DEFAULT NULL,
  `campaignchatId` varchar(300) DEFAULT NULL,
  `campName` varchar(255) NOT NULL,
  `campType` varchar(255) NOT NULL,
  `tags` varchar(100) DEFAULT NULL,
  `contactList` json DEFAULT NULL,
  `template` varchar(150) NOT NULL,
  `templateId` int DEFAULT NULL,
  `triggerType` int NOT NULL,
  `recurring` json DEFAULT NULL,
  `lastRecurrentDate` date DEFAULT NULL,
  `scheduleDate` varchar(20) DEFAULT NULL,
  `cloneStatus` tinyint DEFAULT NULL,
  `listId` int DEFAULT NULL,
  `listName` varchar(150) DEFAULT NULL,
  `templateData` json DEFAULT NULL,
  `optimalType` tinyint DEFAULT NULL,
  `createdDate` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedDate` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `campaignStatus` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `campaignchatId` (`campaignchatId`),
  KEY `campaign_dtl_FK` (`templateId`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=167 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wc_contact_list_condition_dtl`
--

DROP TABLE IF EXISTS `wc_contact_list_condition_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wc_contact_list_condition_dtl` (
  `cid` int NOT NULL AUTO_INCREMENT,
  `domainId` int DEFAULT NULL,
  `filterCond` json DEFAULT NULL,
  `UIFilterCond` json DEFAULT NULL,
  `createdAt` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`cid`)
) ENGINE=InnoDB AUTO_INCREMENT=86 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wc_contact_list_master_dtl`
--

DROP TABLE IF EXISTS `wc_contact_list_master_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wc_contact_list_master_dtl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `domainId` int NOT NULL,
  `baseType` tinyint NOT NULL,
  `listName` varchar(250) NOT NULL,
  `listType` tinyint NOT NULL,
  `conditionId` int DEFAULT NULL,
  `contactList` json DEFAULT NULL,
  `creatorId` int DEFAULT NULL,
  `createdBy` varchar(200) DEFAULT NULL,
  `createdAt` datetime DEFAULT CURRENT_TIMESTAMP,
  `updateAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=98 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wc_contact_list_master_dtl_20250717_backup`
--

DROP TABLE IF EXISTS `wc_contact_list_master_dtl_20250717_backup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wc_contact_list_master_dtl_20250717_backup` (
  `id` int NOT NULL AUTO_INCREMENT,
  `domainId` int NOT NULL,
  `baseType` tinyint NOT NULL,
  `listName` varchar(250) NOT NULL,
  `listType` tinyint NOT NULL,
  `conditionId` int DEFAULT NULL,
  `contactList` json DEFAULT NULL,
  `creatorId` int DEFAULT NULL,
  `createdBy` varchar(200) DEFAULT NULL,
  `createdAt` datetime DEFAULT CURRENT_TIMESTAMP,
  `updateAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wc_customerTag`
--

DROP TABLE IF EXISTS `wc_customerTag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wc_customerTag` (
  `ctgid` int NOT NULL AUTO_INCREMENT,
  `domainId` int NOT NULL,
  `ctgName` varchar(50) NOT NULL,
  `ctgDesc` varchar(500) DEFAULT NULL,
  `ctgStatus` tinyint DEFAULT '0',
  `createdAt` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ctgid`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wc_customerType`
--

DROP TABLE IF EXISTS `wc_customerType`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wc_customerType` (
  `ctid` int NOT NULL AUTO_INCREMENT,
  `domainId` int NOT NULL,
  `ctName` varchar(50) NOT NULL,
  `ctDesc` varchar(500) DEFAULT NULL,
  `ctStatus` tinyint DEFAULT '0',
  `createdAt` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ctid`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wc_customer_contact_column_properties`
--

DROP TABLE IF EXISTS `wc_customer_contact_column_properties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wc_customer_contact_column_properties` (
  `id` int NOT NULL AUTO_INCREMENT,
  `domainID` int DEFAULT NULL,
  `tableName` varchar(50) DEFAULT NULL,
  `columName` varchar(50) DEFAULT NULL,
  `columnType` varchar(50) DEFAULT NULL,
  `columnCategory` varchar(200) DEFAULT NULL,
  `isMandatory` tinyint DEFAULT NULL,
  `isDisplay` tinyint DEFAULT NULL,
  `columnValue` text,
  `createAt` datetime DEFAULT NULL,
  `modifedAt` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `columnLabel` varchar(50) DEFAULT NULL,
  `placeHolder` varchar(300) DEFAULT NULL,
  `errMsg` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wc_master_revert_status_details`
--

DROP TABLE IF EXISTS `wc_master_revert_status_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wc_master_revert_status_details` (
  `campaignchatId` varchar(300) NOT NULL,
  `domainId` int NOT NULL,
  `isReverted` tinyint NOT NULL DEFAULT '0',
  `createdDate` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedDate` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`campaignchatId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wc_oauthDtl`
--

DROP TABLE IF EXISTS `wc_oauthDtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wc_oauthDtl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `domainID` int NOT NULL,
  `tokenID` varchar(100) NOT NULL,
  `createdOn` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedOn` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `domainID` (`domainID`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wc_overall_campaign_bell_notification`
--

DROP TABLE IF EXISTS `wc_overall_campaign_bell_notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wc_overall_campaign_bell_notification` (
  `id` int NOT NULL AUTO_INCREMENT,
  `domainId` int DEFAULT NULL,
  `channelType` varchar(50) NOT NULL,
  `title` varchar(500) DEFAULT NULL,
  `message` text,
  `status` varchar(50) DEFAULT NULL,
  `isRead` tinyint DEFAULT '0',
  `createdOn` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedOn` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `isNotification_Sent` tinyint DEFAULT '0',
  `campaignchatId` varchar(300) NOT NULL,
  `deliveryTime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_domain_created` (`domainId`,`createdOn`)
) ENGINE=InnoDB AUTO_INCREMENT=432 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wc_ref_tb_Action_details`
--

DROP TABLE IF EXISTS `wc_ref_tb_Action_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wc_ref_tb_Action_details` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ActionName` varchar(20) NOT NULL,
  `Details` varchar(150) DEFAULT NULL,
  `createdOn` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedOn` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wc_ref_tb_channel_details`
--

DROP TABLE IF EXISTS `wc_ref_tb_channel_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wc_ref_tb_channel_details` (
  `channelName` varchar(20) NOT NULL,
  `channelId` smallint NOT NULL AUTO_INCREMENT,
  `openAction` tinyint DEFAULT NULL,
  `clickAction` tinyint DEFAULT NULL,
  `createdOn` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedOn` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`channelId`),
  UNIQUE KEY `channelId` (`channelId`),
  UNIQUE KEY `un_channelName` (`channelName`),
  CONSTRAINT `wc_ref_tb_channel_details_chk_1` CHECK ((`openAction` in (0,1))),
  CONSTRAINT `wc_ref_tb_channel_details_chk_2` CHECK ((`clickAction` in (0,1)))
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wc_tb_campaign_chat_draft_dtl`
--

DROP TABLE IF EXISTS `wc_tb_campaign_chat_draft_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wc_tb_campaign_chat_draft_dtl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `domainId` int NOT NULL,
  `campaignChatId` varchar(300) NOT NULL,
  `payLoad` json NOT NULL,
  `createdOn` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedOn` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wc_tb_campaign_customer_chat_conversation_History`
--

DROP TABLE IF EXISTS `wc_tb_campaign_customer_chat_conversation_History`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wc_tb_campaign_customer_chat_conversation_History` (
  `chatId` int NOT NULL AUTO_INCREMENT,
  `domainId` int NOT NULL,
  `campaignChatId` varchar(50) NOT NULL,
  `ccaasMessage` json DEFAULT NULL,
  `nlpMessage` json DEFAULT NULL,
  `createdOn` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedOn` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`chatId`),
  KEY `index_byDomainIdAndCampaignChatId` (`domainId`,`campaignChatId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wc_tb_campaign_knowledgeBase_file_details`
--

DROP TABLE IF EXISTS `wc_tb_campaign_knowledgeBase_file_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wc_tb_campaign_knowledgeBase_file_details` (
  `id` int NOT NULL AUTO_INCREMENT,
  `domainId` int NOT NULL,
  `unique_id` varchar(50) NOT NULL,
  `filename` varchar(100) DEFAULT NULL,
  `minetype` varchar(100) DEFAULT NULL,
  `size` int DEFAULT NULL,
  `uploadUrl` varchar(250) DEFAULT NULL,
  `createdOn` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedOn` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wc_tb_draft_template_message_dtl`
--

DROP TABLE IF EXISTS `wc_tb_draft_template_message_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wc_tb_draft_template_message_dtl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `domainId` int NOT NULL,
  `campaignChatId` varchar(300) NOT NULL,
  `channelType` varchar(50) NOT NULL,
  `template` json DEFAULT NULL,
  `createdOn` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedOn` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wc_tb_knowledge_base_pdf_dtl`
--

DROP TABLE IF EXISTS `wc_tb_knowledge_base_pdf_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wc_tb_knowledge_base_pdf_dtl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `domainId` int NOT NULL,
  `uniqueId` varchar(50) DEFAULT NULL,
  `companyName` varchar(50) DEFAULT NULL,
  `industrial_type` varchar(70) DEFAULT NULL,
  `filename` varchar(100) DEFAULT NULL,
  `minetype` varchar(100) DEFAULT NULL,
  `uploadUrl` varchar(250) DEFAULT NULL,
  `size` int DEFAULT NULL,
  `pdf_info` json DEFAULT NULL,
  `createdOn` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedOn` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wc_tb_knowledge_base_website_dtl`
--

DROP TABLE IF EXISTS `wc_tb_knowledge_base_website_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wc_tb_knowledge_base_website_dtl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `domainId` int NOT NULL,
  `companyName` varchar(50) DEFAULT NULL,
  `industrialType` varchar(70) DEFAULT NULL,
  `websideUrl` varchar(250) DEFAULT NULL,
  `productInfo` json DEFAULT NULL,
  `contactInfo` json DEFAULT NULL,
  `createdOn` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedOn` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ind_di` (`domainId`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wc_tb_knowledge_base_website_dtl_bkp_2026_02_17`
--

DROP TABLE IF EXISTS `wc_tb_knowledge_base_website_dtl_bkp_2026_02_17`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wc_tb_knowledge_base_website_dtl_bkp_2026_02_17` (
  `id` int NOT NULL AUTO_INCREMENT,
  `domainId` int NOT NULL,
  `companyName` varchar(50) DEFAULT NULL,
  `industrialType` varchar(70) DEFAULT NULL,
  `websideUrl` varchar(250) DEFAULT NULL,
  `productInfo` json DEFAULT NULL,
  `contactInfo` json DEFAULT NULL,
  `createdOn` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedOn` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wc_tb_recurrence_new_schedule`
--

DROP TABLE IF EXISTS `wc_tb_recurrence_new_schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wc_tb_recurrence_new_schedule` (
  `recId` int NOT NULL AUTO_INCREMENT,
  `domainId` int NOT NULL,
  `reportId` int NOT NULL,
  `recurrenceType` tinyint NOT NULL,
  `reportResultStartDate` date NOT NULL,
  `reportResultEndDate` date DEFAULT NULL,
  `timeZone` varchar(50) NOT NULL,
  `fileTypeIsPDF` tinyint NOT NULL DEFAULT '0',
  `fileTypeIsCSV` tinyint NOT NULL DEFAULT '0',
  `fileTypeIsXLS` tinyint NOT NULL DEFAULT '0',
  `fileTypeIsXLSL` tinyint NOT NULL DEFAULT '0',
  `emailId` varchar(90) NOT NULL,
  `subject` varchar(500) NOT NULL,
  `message` text NOT NULL,
  `createdOn` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedOn` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`recId`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wc_tb_recurrence_new_schedule_Daily`
--

DROP TABLE IF EXISTS `wc_tb_recurrence_new_schedule_Daily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wc_tb_recurrence_new_schedule_Daily` (
  `id` int NOT NULL AUTO_INCREMENT,
  `FK_recId` int DEFAULT NULL,
  `domainId` int NOT NULL,
  `numbericTimeZone` varchar(50) NOT NULL,
  `repeatEvery` int NOT NULL,
  `frequenceHour` smallint NOT NULL,
  `frequenceMinute` smallint NOT NULL,
  `userSysTime` datetime NOT NULL,
  `convertToUTC` datetime NOT NULL,
  `UTC_startTime` datetime NOT NULL,
  `isCompleted` tinyint NOT NULL DEFAULT '0',
  `isStop` tinyint NOT NULL DEFAULT '0',
  `createdOn` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedOn` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `FK_recId` (`FK_recId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wc_tb_recurrence_new_schedule_Monthly`
--

DROP TABLE IF EXISTS `wc_tb_recurrence_new_schedule_Monthly`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wc_tb_recurrence_new_schedule_Monthly` (
  `id` int NOT NULL AUTO_INCREMENT,
  `FK_recId` int DEFAULT NULL,
  `domainId` int NOT NULL,
  `numbericTimeZone` varchar(50) NOT NULL,
  `repeatEvery` int NOT NULL,
  `ordinalNumber` int NOT NULL,
  `weekDays` int DEFAULT NULL,
  `type` tinyint DEFAULT NULL,
  `DateNo` int DEFAULT NULL,
  `frequenceHour` smallint NOT NULL,
  `frequenceMinute` smallint NOT NULL,
  `userSetTime` datetime NOT NULL,
  `convertToUTC` datetime NOT NULL,
  `UTC_startTime` datetime NOT NULL,
  `isCompleted` tinyint NOT NULL DEFAULT '0',
  `isStop` tinyint NOT NULL DEFAULT '0',
  `createdOn` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedOn` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wc_tb_recurrence_new_schedule_Once`
--

DROP TABLE IF EXISTS `wc_tb_recurrence_new_schedule_Once`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wc_tb_recurrence_new_schedule_Once` (
  `id` int NOT NULL AUTO_INCREMENT,
  `FK_recId` int DEFAULT NULL,
  `domainId` int NOT NULL,
  `numbericTimeZone` varchar(50) NOT NULL,
  `TimeHour` int DEFAULT NULL,
  `TimeMinute` int DEFAULT NULL,
  `userSetTime` datetime NOT NULL,
  `convertToUTC` datetime NOT NULL,
  `UTC_startTime` datetime NOT NULL,
  `isCompleted` tinyint NOT NULL DEFAULT '0',
  `isStop` tinyint NOT NULL DEFAULT '0',
  `createdOn` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedOn` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `FK_recId` (`FK_recId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wc_tb_recurrence_new_schedule_Weekly`
--

DROP TABLE IF EXISTS `wc_tb_recurrence_new_schedule_Weekly`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wc_tb_recurrence_new_schedule_Weekly` (
  `id` int NOT NULL AUTO_INCREMENT,
  `FK_recId` int DEFAULT NULL,
  `domainId` int NOT NULL,
  `numbericTimeZone` varchar(50) NOT NULL,
  `repeatEvery` int NOT NULL,
  `isSunday` tinyint DEFAULT NULL,
  `isMonday` tinyint DEFAULT NULL,
  `isTueday` tinyint DEFAULT NULL,
  `isWednesday` tinyint DEFAULT NULL,
  `isThursday` tinyint DEFAULT NULL,
  `isFriday` tinyint DEFAULT NULL,
  `isSaturday` tinyint DEFAULT NULL,
  `maxWeek` int DEFAULT NULL,
  `minWeek` int DEFAULT NULL,
  `frequenceHour` smallint NOT NULL,
  `frequenceMinute` smallint NOT NULL,
  `userSysTime` datetime NOT NULL,
  `convertToUTC` datetime NOT NULL,
  `UTC_startTime` datetime NOT NULL,
  `isCompleted` tinyint NOT NULL DEFAULT '0',
  `isStop` tinyint NOT NULL DEFAULT '0',
  `createdOn` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedOn` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `FK_recId` (`FK_recId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wc_tb_template_chat_memory`
--

DROP TABLE IF EXISTS `wc_tb_template_chat_memory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wc_tb_template_chat_memory` (
  `id` int NOT NULL AUTO_INCREMENT,
  `domainId` int NOT NULL,
  `campaignChatId` varchar(300) NOT NULL,
  `templateId` varchar(300) DEFAULT NULL,
  `channel` varchar(50) NOT NULL,
  `conversation` json DEFAULT NULL,
  `template` text,
  `team` int DEFAULT NULL,
  `createdOn` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedOn` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2938 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wc_template_master_dtl`
--

DROP TABLE IF EXISTS `wc_template_master_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wc_template_master_dtl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `createdAt` datetime DEFAULT CURRENT_TIMESTAMP,
  `domainId` int DEFAULT NULL,
  `templateName` varchar(150) NOT NULL,
  `whatsappAccount` varchar(200) DEFAULT NULL,
  `category` varchar(100) NOT NULL,
  `language` varchar(100) NOT NULL,
  `headerType` varchar(200) DEFAULT NULL,
  `headerValue` text,
  `message` text,
  `footer` text,
  `buttonType` json DEFAULT NULL,
  `status` varchar(30) DEFAULT NULL,
  `variable` varchar(100) DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  `clonedfrom` int DEFAULT NULL,
  `templateId` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `templateName` (`templateName`)
) ENGINE=InnoDB AUTO_INCREMENT=337 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wc_user_contact_dtl`
--

DROP TABLE IF EXISTS `wc_user_contact_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wc_user_contact_dtl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `domainId` int NOT NULL,
  `firstName` varchar(100) NOT NULL,
  `lastName` varchar(100) DEFAULT NULL,
  `whatsappNumber` varchar(30) DEFAULT NULL,
  `phoneNumber` varchar(30) DEFAULT NULL,
  `email` varchar(200) NOT NULL,
  `customerType` varchar(100) DEFAULT NULL,
  `tags` varchar(100) DEFAULT NULL,
  `location` varchar(100) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `address` text,
  `state` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `postCode` varchar(50) DEFAULT NULL,
  `istempCustomer` varchar(300) DEFAULT '0',
  `createdAt` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime DEFAULT NULL,
  `source` varchar(100) DEFAULT NULL,
  `deviceId` varchar(150) DEFAULT NULL,
  `deviceOS` varchar(50) DEFAULT NULL,
  `pushNotificationId` varchar(3000) DEFAULT NULL,
  `sip_log_id` bigint DEFAULT NULL,
  `extension` int DEFAULT NULL,
  `lifeCycleStage` varchar(50) DEFAULT 'Lead',
  `isUnSub_Whatsapp` tinyint NOT NULL DEFAULT '0',
  `isUnSub_SMS` tinyint NOT NULL DEFAULT '0',
  `isUnSub_Email` tinyint NOT NULL DEFAULT '0',
  `isUnSub_AppPush` tinyint NOT NULL DEFAULT '0',
  `isUnSub_WebPush` tinyint NOT NULL DEFAULT '0',
  `isUnSub_InApp` tinyint NOT NULL DEFAULT '0',
  `industryType` varchar(250) DEFAULT NULL,
  `jobTitle` varchar(250) DEFAULT NULL,
  `companyName` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `domainId` (`domainId`,`email`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=60605 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wc_user_contact_dtl_6617_backup`
--

DROP TABLE IF EXISTS `wc_user_contact_dtl_6617_backup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wc_user_contact_dtl_6617_backup` (
  `id` int NOT NULL DEFAULT '0',
  `domainId` int NOT NULL,
  `firstName` varchar(100) NOT NULL,
  `lastName` varchar(100) DEFAULT NULL,
  `whatsappNumber` varchar(30) DEFAULT NULL,
  `phoneNumber` varchar(30) DEFAULT NULL,
  `email` varchar(200) NOT NULL,
  `customerType` varchar(100) DEFAULT NULL,
  `tags` varchar(100) DEFAULT NULL,
  `location` varchar(100) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `address` text,
  `state` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `postCode` varchar(50) DEFAULT NULL,
  `istempCustomer` varchar(300) DEFAULT '0',
  `createdAt` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime DEFAULT NULL,
  `source` varchar(100) DEFAULT NULL,
  `deviceId` varchar(150) DEFAULT NULL,
  `deviceOS` varchar(50) DEFAULT NULL,
  `pushNotificationId` varchar(3000) DEFAULT NULL,
  `sip_log_id` bigint DEFAULT NULL,
  `extension` int DEFAULT NULL,
  `lifeCycleStage` varchar(50) DEFAULT 'Lead',
  `isUnSub_Whatsapp` tinyint NOT NULL DEFAULT '0',
  `isUnSub_SMS` tinyint NOT NULL DEFAULT '0',
  `isUnSub_Email` tinyint NOT NULL DEFAULT '0',
  `isUnSub_AppPush` tinyint NOT NULL DEFAULT '0',
  `isUnSub_WebPush` tinyint NOT NULL DEFAULT '0',
  `isUnSub_InApp` tinyint NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wc_user_contact_dtl_Backup20250203`
--

DROP TABLE IF EXISTS `wc_user_contact_dtl_Backup20250203`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wc_user_contact_dtl_Backup20250203` (
  `id` int NOT NULL AUTO_INCREMENT,
  `domainId` int NOT NULL,
  `firstName` varchar(100) NOT NULL,
  `lastName` varchar(100) DEFAULT NULL,
  `whatsappNumber` varchar(30) DEFAULT NULL,
  `phoneNumber` varchar(30) DEFAULT NULL,
  `email` varchar(200) NOT NULL,
  `customerType` varchar(100) DEFAULT NULL,
  `tags` varchar(100) DEFAULT NULL,
  `location` varchar(100) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `address` text,
  `state` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `postCode` varchar(20) DEFAULT NULL,
  `createdAt` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime DEFAULT NULL,
  `source` varchar(100) DEFAULT NULL,
  `deviceId` varchar(50) DEFAULT NULL,
  `deviceOS` varchar(50) DEFAULT NULL,
  `pushNotificationId` varchar(3000) DEFAULT NULL,
  `sip_log_id` bigint DEFAULT NULL,
  `extension` int DEFAULT NULL,
  `lifeCycleStage` varchar(50) DEFAULT 'Lead',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7731 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wc_whatsapp_earlier_config_dtl`
--

DROP TABLE IF EXISTS `wc_whatsapp_earlier_config_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wc_whatsapp_earlier_config_dtl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `domainId` int DEFAULT NULL,
  `campaingChatId` varchar(300) NOT NULL,
  `template` varchar(500) DEFAULT NULL,
  `status` varchar(50) NOT NULL,
  `payloadDtl` json DEFAULT NULL,
  `createdOn` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedOn` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `campaingChatId` (`campaingChatId`)
) ENGINE=InnoDB AUTO_INCREMENT=196 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wc_worktualConnectorCcaas`
--

DROP TABLE IF EXISTS `wc_worktualConnectorCcaas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wc_worktualConnectorCcaas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `domainId` int NOT NULL,
  `clientId` varchar(150) NOT NULL,
  `clientSecret` varchar(150) NOT NULL,
  `createdOn` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedOn` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `domainId` (`domainId`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `webPush_tb_configuration`
--

DROP TABLE IF EXISTS `webPush_tb_configuration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `webPush_tb_configuration` (
  `config_id` int NOT NULL AUTO_INCREMENT,
  `domainId` int NOT NULL,
  `webUrl` varchar(300) NOT NULL,
  `logoUrl` varchar(300) NOT NULL,
  `createdAt` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`config_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `webPush_tb_indiv_user_click_open_cnt_dtl`
--

DROP TABLE IF EXISTS `webPush_tb_indiv_user_click_open_cnt_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `webPush_tb_indiv_user_click_open_cnt_dtl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `domainId` int NOT NULL,
  `campaignChatId` varchar(300) NOT NULL,
  `userID` int NOT NULL,
  `actionId` int NOT NULL,
  `channelType` varchar(20) DEFAULT 'WebPush',
  `createdOn` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `actionId` (`actionId`),
  CONSTRAINT `webPush_tb_indiv_user_click_open_cnt_dtl_ibfk_1` FOREIGN KEY (`actionId`) REFERENCES `wc_ref_tb_Action_details` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `webpush_TokenDtl`
--

DROP TABLE IF EXISTS `webpush_TokenDtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `webpush_TokenDtl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `domainId` int DEFAULT NULL,
  `userId` int DEFAULT NULL,
  `userName` varchar(200) DEFAULT NULL,
  `TokenId` varchar(500) DEFAULT NULL,
  `browser` varchar(500) DEFAULT NULL,
  `emailId` varchar(250) DEFAULT NULL,
  `createdOn` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedOn` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uni_domain_email` (`domainId`,`emailId`),
  KEY `index_webPush_domain_emailId` (`domainId`,`emailId`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=1684 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `webpush_campaign_schedule_dtl`
--

DROP TABLE IF EXISTS `webpush_campaign_schedule_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `webpush_campaign_schedule_dtl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `domainId` int DEFAULT NULL,
  `campaignId` int DEFAULT NULL,
  `campaignChatId` varchar(300) DEFAULT NULL,
  `scheduleType` smallint DEFAULT NULL,
  `schedulefromDate` datetime DEFAULT NULL,
  `scheduletoDate` datetime DEFAULT NULL,
  `cronStatus` tinyint DEFAULT '0',
  `sentStatus` tinyint DEFAULT '0',
  `updatedDate` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=199 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `webpush_masterCampaignDtl`
--

DROP TABLE IF EXISTS `webpush_masterCampaignDtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `webpush_masterCampaignDtl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `domainId` int NOT NULL,
  `campaignChatId` varchar(300) NOT NULL,
  `campaignName` varchar(250) NOT NULL,
  `goal` varchar(250) DEFAULT NULL,
  `industryType` varchar(100) DEFAULT NULL,
  `objective` varchar(400) DEFAULT NULL,
  `urlDtl` varchar(250) DEFAULT NULL,
  `scheduleType` smallint DEFAULT NULL,
  `targetAudienceType` int DEFAULT NULL,
  `contactDtl` json DEFAULT NULL,
  `templateDtl` text,
  `deviceDtl` json DEFAULT NULL,
  `sourceDtl` varchar(15) DEFAULT NULL,
  `imageUrl` varchar(300) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `createdOn` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedOn` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `campaignChatId` (`campaignChatId`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=232 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `webpush_masterCampaignDtl_Backup20251028`
--

DROP TABLE IF EXISTS `webpush_masterCampaignDtl_Backup20251028`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `webpush_masterCampaignDtl_Backup20251028` (
  `id` int NOT NULL AUTO_INCREMENT,
  `domainId` int DEFAULT NULL,
  `campaignChatId` varchar(300) DEFAULT NULL,
  `campaignName` varchar(250) NOT NULL,
  `goal` varchar(250) DEFAULT NULL,
  `industryType` varchar(100) DEFAULT NULL,
  `objective` varchar(400) DEFAULT NULL,
  `urlDtl` varchar(250) DEFAULT NULL,
  `scheduleType` smallint DEFAULT NULL,
  `targetAudienceType` int DEFAULT NULL,
  `contactDtl` json DEFAULT NULL,
  `templateDtl` text,
  `deviceDtl` json DEFAULT NULL,
  `sourceDtl` varchar(15) DEFAULT NULL,
  `imageUrl` varchar(300) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `createdOn` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedOn` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `campaignChatId` (`campaignChatId`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `webpush_searchHistoryDtl`
--

DROP TABLE IF EXISTS `webpush_searchHistoryDtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `webpush_searchHistoryDtl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `domainId` int NOT NULL,
  `searchDetails` longtext,
  `createdOn` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedOn` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `webpush_sent_status_details`
--

DROP TABLE IF EXISTS `webpush_sent_status_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `webpush_sent_status_details` (
  `id` int NOT NULL AUTO_INCREMENT,
  `domainId` int NOT NULL,
  `campaignChatId` varchar(300) NOT NULL,
  `status` varchar(50) NOT NULL,
  `createdOn` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedOn` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `sentAt` datetime DEFAULT CURRENT_TIMESTAMP,
  `description` varchar(800) DEFAULT NULL,
  `token` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `whatsapp_tb_indiv_user_click_open_cnt_dtl`
--

DROP TABLE IF EXISTS `whatsapp_tb_indiv_user_click_open_cnt_dtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `whatsapp_tb_indiv_user_click_open_cnt_dtl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `domainId` int NOT NULL,
  `campaignChatId` varchar(300) NOT NULL,
  `userID` int NOT NULL,
  `actionId` int NOT NULL,
  `channelType` varchar(20) DEFAULT 'Whatsapp',
  `createdOn` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `actionId` (`actionId`),
  KEY `idx_whatsapp_action_campaignchat` (`actionId`,`campaignChatId`),
  CONSTRAINT `whatsapp_tb_indiv_user_click_open_cnt_dtl_ibfk_1` FOREIGN KEY (`actionId`) REFERENCES `wc_ref_tb_Action_details` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `z_fake_tb`
--

DROP TABLE IF EXISTS `z_fake_tb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `z_fake_tb` (
  `sum_no` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping routines for database 'whatsappcampaign'
--
/*!50003 DROP PROCEDURE IF EXISTS `AppPush_getCrone` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `AppPush_getCrone`()
BEGIN
  		DECLARE v_currentDate	DATETIME;
          
          SET v_currentDate = CAST(DATE_FORMAT(CONVERT_TZ(NOW(), "+00:00", "+05:30"),"%Y-%m-%d %H:%i:00") as datetime);
          
          
          DROP TEMPORARY TABLE IF EXISTS tt_AppPushSchenduleDate;
          CREATE TEMPORARY TABLE tt_AppPushSchenduleDate
          
          SELECT t1.campaignId, t1.id as scheduleId,  t2.*  
          FROM Apppush_campaign_schedule_dtl 				t1
          JOIN AppPush_campaign_master_dtl					t2			ON t1.campaignId = t2.id
          LEFT JOIN wc_master_revert_status_details			t3 			ON t2.campaignChatId = t3.campaignchatId
          WHERE CAST(DATE_FORMAT(t1.schedulefromDate, "%Y-%m-%d %H:%i:00") AS DATETIME) <= v_currentDate
       
          AND t1.sentStatus = 0
          AND t1.scheduleType != 0
          AND t3.campaignchatId IS NULL;
          
          
          SELECT * FROM tt_AppPushSchenduleDate;
          
          UPDATE Apppush_campaign_schedule_dtl t1
          JOIN tt_AppPushSchenduleDate t2 ON t1.id = t2.scheduleId 
          SET sentStatus = 1; 
          
  		DROP TEMPORARY TABLE IF EXISTS tt_AppPushSchenduleDate;
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AppPush_getMasterCampaignDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `AppPush_getMasterCampaignDtl`(
	p_domainId								INT
)
BEGIN
		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        
        SELECT t1.campaignName, t1.`Status`, t1.createdOn, t2.schedulefromDate as publishDate FROM AppPush_campaign_master_dtl t1
        JOIN Apppush_campaign_schedule_dtl t2 ON t1.id = t2.campaignId
        WHERE t1.domainId = p_domainId
        ORDER BY  t1.createdOn DESC;
        
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
        
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AppPush_getSearchHistoryDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `AppPush_getSearchHistoryDtl`(
		p_domainId			INT
)
BEGIN

		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        
			SELECT domainId, searchDetails 
				FROM AppPush_SearchHistoryDtl WHERE domainId = p_domainId;
                
                
		SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AppPush_get_encryption_config` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `AppPush_get_encryption_config`(
	
	p_domainId					INT
)
BEGIN
			SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
            
            SELECT configId , domainId, appId, secretKey
            FROM AppPush_encryption_config
            WHERE p_domainId = domainId;
            
            
            SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AppPush_get_main_config_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `AppPush_get_main_config_dtl`(
  		p_domainId					INT
  )
BEGIN
  			SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
              
              SELECT 
  					id
  					,domainId
                      ,`type`
  					,projectId
  					,privateKeyId
  					,privateKey
  					,clientEmail
  					,clientId
  					,authURI						AS 'authUrl'
  					,tokenURI						AS 'tokenUrl'	
  					,authProviderURL				AS  'authProviderUrl'
  					,clientURL						AS  'clientUrl'
  					,universe_domain				AS 	'universeDomain'
                    
              FROM AppPush_main_config WHERE domainId = p_domainId;
              
              SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
  		
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AppPush_get_openRate_history_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `AppPush_get_openRate_history_dtl`(	
 	p_domainId				INT,
     p_campaignChatId		VARCHAR(300)
    
 )
BEGIN
 		
         SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;	
         
 			 SELECT id , domainId , campaignId , campaignChatId , deviceId , `status`, createdOn
 				FROM AppPush_tb_openRate_history_dtl WHERE domainId = p_domainId
 						AND campaignChatId = p_campaignChatId;
             
 		SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AppPush_get_pushNotificationId_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `AppPush_get_pushNotificationId_dtl`(
   	p_domainId			INT,
   	p_deviceId			VARCHAR(150)
   )
BEGIN
   
   	SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   
   		SELECT deviceId, deviceOS as deviceType, pushNotificationId FROM wc_user_contact_dtl WHERE domainId = p_domainId AND deviceId = p_deviceId;
   	
       SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ; 
   
   END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AppPush_InsertUpdateMasterCampaignDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `AppPush_InsertUpdateMasterCampaignDtl`(
   	
   	p_domainId								INT,
   	p_campaignName							VARCHAR(250),
       p_campaignGoal							VARCHAR(250),
       p_industryType							VARCHAR(250),
       p_objective								VARCHAR(400),
       p_urlDtl								VARCHAR(250),
       p_scheduleType							SMALLINT,			
       p_schedulefromDate						DATETIME, 
       p_scheduletoDate						DATETIME,
       p_targetAudienceType					INT,				
       p_contactDtl							JSON,	
       p_TemplateDtl							TEXT,
       p_status								VARCHAR(50),
       p_deviceDtl								JSON,
       p_imageUrl								VARCHAR(300),
       p_sourceDtl								VARCHAR(15),
       p_campaignChatId							VARCHAR(300)
   )
SP:BEGIN
   			DECLARE v_errCode			INT DEFAULT -1;
               DECLARE v_errMsg			VARCHAR(50) DEFAULT "Failed to Insert";
               DECLARE v_lastInsertId		INT;
               
               DECLARE EXIT HANDLER FOR SQLEXCEPTION
               BEGIN
   						ROLLBACK;
                           SELECT -1 AS errCode, "Failed To Insert" AS errMsg;
               END;
 				
               IF p_campaignChatId IS NULL THEN
               
 				SELECT v_errCode AS errCode, v_errMsg AS errMsg;
                 LEAVE SP;
                 
 			  END IF;
                 
   			START TRANSACTION;
               
                   INSERT INTO AppPush_campaign_master_dtl
   				(domainId, campaignName , campaignGoal, industryType, objective, urlDtl, scheduleType, targetAudienceType, contactDtl, 
                   TemplateDtl, `Status`, deviceDtl, imageUrl, sourceDtl, campaignChatId)
   				VALUES
   				(p_domainId, p_campaignName , p_campaignGoal, p_industryType, p_objective, p_urlDtl, p_scheduleType, p_targetAudienceType,
   					p_contactDtl, p_TemplateDtl,   p_status, p_deviceDtl , p_imageUrl, p_sourceDtl, p_campaignChatId);
   		
   				IF ROW_COUNT() > 0 THEN
                   
   					SET v_lastInsertId = last_insert_id();
                       
   						IF p_scheduleType IN (0, 1) THEN 
   
   							INSERT INTO Apppush_campaign_schedule_dtl(domainId, campaignId, scheduleType ,schedulefromDate, campaignChatId) 
   							VALUES(p_domainId, v_lastInsertId, p_scheduleType,  IFNULL(p_schedulefromDate, NOW()), p_campaignChatId);
   
   						ELSE
   
   							INSERT INTO Apppush_campaign_schedule_dtl(domainId, campaignId, scheduleType ,schedulefromDate, scheduletoDate, campaignChatId) 
   							VALUES(p_domainId, v_lastInsertId, p_scheduleType, p_schedulefromDate, p_scheduletoDate, p_campaignChatId);
   
   						END IF;
                           
                           IF ROW_COUNT() > 0 THEN
   							SET v_errCode = 1;
   							SET v_errMsg = "Inserted Successfully";
   							COMMIT;
   						END IF;
                       
   				END IF;
                   
               SELECT v_errCode AS errCode, v_errMsg AS errMsg;
   END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AppPush_insertUpdateSearchHistoryDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `AppPush_insertUpdateSearchHistoryDtl`(
		p_domainId			INT,
        p_searchDetails		LONGTEXT
)
BEGIN
				DECLARE v_errCode		SMALLINT DEFAULT -1;
                DECLARE v_errMsg		VARCHAR(50) DEFAULT "Failed";
                DECLARE v_id			INT;
			
			IF NOT EXISTS(SELECT 1 FROM AppPush_SearchHistoryDtl WHERE domainId = p_domainId) THEN
				
               INSERT INTO AppPush_SearchHistoryDtl(domainId, searchDetails) VALUES(p_domainId, p_searchDetails);
               
               IF ROW_COUNT() > 0 THEN 
					SET v_errCode = 0;
                    SET v_errMsg = "Inserted Successfully";
               END IF;
               
            ELSE
					SELECT id INTO v_id FROM AppPush_SearchHistoryDtl WHERE domainId = p_domainId;
                    
                    UPDATE AppPush_SearchHistoryDtl
                    SET searchDetails = p_searchDetails
                    WHERE id = v_id and domainId = p_domainId;
                    
                    IF ROW_COUNT() > 0 THEN 
					
                    SET v_errCode = 1;
                    SET v_errMsg = "Updated Successfully";
                    
					END IF;
                    
                    
            END IF; 
            
            SELECT v_errCode AS errCode , v_errMsg AS errMsg;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AppPush_insert_encryption_config` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `AppPush_insert_encryption_config`(
 	p_configId					INT,
 	p_domainId					INT,
     p_appId				VARCHAR(100),
     p_secretKey 			VARCHAR(100)
  )
BEGIN
 			DECLARE v_errMsg	VARCHAR(50) DEFAULT "Failed";
             DECLARE v_errCode	INT DEFAULT -1;
             
 			
 					
 			
             
             
 			IF p_configId IS NULL THEN 
 					
                     IF NOT exists(SELECT 1 FROM AppPush_encryption_config WHERE domainId = p_domainId) THEN 
                     
                     INSERT INTO AppPush_encryption_config(appId, domainId, secretKey) values(p_appId, p_domainId, p_secretKey);
                     
 						IF ROW_COUNT() > 0 THEN 
 						
 							SET v_errCode = 0;
 							SET v_errMsg = "Inserted Successfully";
             
 						END IF;
                     
 					END IF;
                 
             ELSE
 					UPDATE AppPush_encryption_config
                     SET appId = IFNULL(p_appId, appId),
 						secretKey = IFNULL(p_secretKey, p_secretKey)
 					WHERE configId = p_configId AND domainId = p_domainId;
                     
                     IF ROW_COUNT() > 0 THEN 
 						
 							SET v_errCode = 1;
 							SET v_errMsg = "Updated Successfully";
             
 						END IF;
             
             END IF;
             
             SELECT v_errCode as errCode, v_errMsg as errMsg;
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AppPush_insert_openRate_history_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `AppPush_insert_openRate_history_dtl`(	
  		p_domainId				INT,
         p_campaignChatId		VARCHAR(300),
         p_deviceId				VARCHAR(100),
  		p_status				VARCHAR(50)	
     )
BEGIN
    		 DECLARE v_campaignId			INT;
             DECLARE v_customerId			INT;
             DECLARE v_errMsg				VARCHAR(50) 	DEFAULT 'failed';
             DECLARE v_errCode				INT 			DEFAULT  -1;
             DECLARE v_statusCode			INT				DEFAULT 5;	
             declare v_currentDate			DATETIME		DEFAULT now();
             
             DECLARE EXIT HANDLER FOR SQLEXCEPTION
             BEGIN
    					
                        SELECT v_errCode AS errCode, v_errMsg AS errMsg;
    					ROLLBACK;
             END;
             
             
             SELECT id INTO v_campaignId 
    			FROM AppPush_campaign_master_dtl 
    		WHERE domainId = p_domainId AND campaignChatId = p_campaignChatId;
             
             SELECT id INTO v_customerId  
    			FROM wc_user_contact_dtl 
    		WHERE domainId = p_domainId AND deviceId = p_deviceId;
            
            
            IF p_status = 'OPEN' THEN 
    				SET v_statusCode = 3;
    			ELSEIF p_status = 'DELIVERY'THEN
    				SET v_statusCode = 2;
            END IF;
            
    		
    		START TRANSACTION;
             
     		IF EXISTS (SELECT 1 FROM AppPush_campaign_master_dtl WHERE domainId = p_domainId AND campaignChatId = p_campaignChatId)THEN 
     		
    			INSERT INTO AppPush_tb_openRate_history_dtl
                 (domainId, campaignId, campaignChatId, deviceId, `status`, createdOn)
                 VALUES(p_domainId, v_campaignId, p_campaignChatId, p_deviceId, p_status, v_currentDate);
                 
                 IF ROW_COUNT() > 0 THEN 
    				SET v_errMsg = "Inserted Successfully";
     				SET v_errCode = 0;
                END IF;
                 
    		END IF;		
    		
            IF (v_customerId IS NOT NULL) THEN 
                
                INSERT INTO AppPush_tb_indiv_user_click_open_cnt_dtl
    				(domainId, campaignChatId, userID, actionId, createdOn) 
    			VALUES(p_domainId, p_campaignChatId, v_customerId, v_statusCode, v_currentDate);
    		
    		 END IF;
     		
     			SELECT v_errCode as errCode, v_errMsg as errMsg;
                
                COMMIT;
    
     END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AppPush_Insert_Update_main_config_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `AppPush_Insert_Update_main_config_dtl`(
  		p_id						INT,
  		p_domainId					INT ,
          p_type						VARCHAR(100),
  		p_projectId					VARCHAR(100),
  		p_privateKeyId  			VARCHAR(600),
  		p_privateKey				VARCHAR(5000),
  		p_clientEmail				VARCHAR(100),
  		p_clientId 					VARCHAR(100),
  		p_authURI 					VARCHAR(100),
  		p_tokenURI 					VARCHAR(100),
  		p_authProviderURL			VARCHAR(100),
  		p_clientURL					VARCHAR(500),
  		p_universe_domain			VARCHAR(100)
  )
BEGIN
  			
              DECLARE  v_errCode		INT DEFAULT -1;
              DECLARE  v_errMsg		VARCHAR(50) DEFAULT "Failed";
  
  			IF p_id  IS NULL THEN 
  					
                      IF NOT EXISTS(SELECT 1 FROM AppPush_main_config WHERE domainId = p_domainId) THEN
                      
  						INSERT INTO AppPush_main_config(domainId, `type`, projectId, privateKeyId, privateKey, clientEmail,	clientId,		
  								authURI, tokenURI, authProviderURL, clientURL,universe_domain) 
  						VALUES(p_domainId, p_type, p_projectId,	p_privateKeyId,	p_privateKey, p_clientEmail, p_clientId, 
  								p_authURI, p_tokenURI, p_authProviderURL, p_clientURL, p_universe_domain);
                      
  						IF ROW_COUNT() > 0 THEN
                          
  							SET v_errCode  		= 	0;
  							SET v_errMsg	 	= "Inserted Successfully";	
                          
                          END IF;
  						
                      END IF;
              
              ELSE
  					
  					 IF EXISTS(SELECT 1 FROM AppPush_main_config WHERE domainId = p_domainId AND id = p_id) THEN
                      
  						UPDATE AppPush_main_config
                          set  `type`					= IFNULL(p_type, `type`),
  							 projectId 				= IFNULL(p_projectId, projectId), 
  							 privateKeyId 			= IFNULL(p_privateKeyId, privateKeyId), 
                               privateKey 			= IFNULL(p_privateKey, privateKey), 
                               clientEmail 			= IFNULL(p_clientEmail, privateKey),	
                               clientId 				= IFNULL(p_clientId, clientId),		
  							 authURI 				= IFNULL(p_authURI, authURI), 
                               tokenURI 				= IFNULL(p_tokenURI, tokenURI), 
                               authProviderURL 		= IFNULL(p_authProviderURL, authProviderURL), 
                               clientURL 				= IFNULL(p_clientURL, clientURL),
                               universe_domain 		= IFNULL(p_universe_domain, universe_domain) 
                               WHERE domainId = p_domainId AND id = p_id;
                      
  						IF ROW_COUNT() > 0 THEN
                          
  							SET v_errCode  		= 	1;
  							SET v_errMsg	 	= "Updated Successfully";
  						
                          END IF;
                          
  					END IF;
                      
              END IF;
              
              SELECT v_errCode as errCode , v_errMsg as errMsg;
  
  end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `campaign_get_find_cron_domain` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `campaign_get_find_cron_domain`(
     p_conId  INT
     ,p_connectorName	VARCHAR(100)
 )
BEGIN
     SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
 
      select conId, domainId, shopDomain, accessToken, isConnected, connectionName, connectorName, token, userName, pwd, syncStatus, syncTime
      , contactSyncDetails, contactSyncType, scriptId, botData, chatWidgetStatus, settings, createDate, updatedDate, StoreConnectionId
      from tb_StoreConnection where syncStatus = 1 and isConnected = 1 and conId= p_conId and connectorName collate utf8mb4_0900_ai_ci = p_connectorName;
 
     SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `campaign_nlp_test_contact_count` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `campaign_nlp_test_contact_count`(
 	p_domainId  	INT 
 )
BEGIN
 		
         SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
         
         SELECT count(domainId) as Count  FROM wc_user_contact_dtl 
         WHERE  domainId = p_domainId;
 
 		  SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `campaign_nlp_test_customer_records` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `campaign_nlp_test_customer_records`(p_domainId  	INT )
begin
  		
          SELECT id
  			, domainId
  			, firstName
  			, lastName
  			, whatsappNumber
  			, phoneNumber
  			, email
  			, customerType
  			, tags
  			, location
  			, city
  			, address
  			, state
  			, country
  			, postCode
  			, createdAt
  			, updatedAt
  			, source
  			, deviceId
  			, sip_log_id
  			, extension
  			, lifeCycleStage
			, industryType
			, jobTitle
			, companyName
  		FROM wc_user_contact_dtl 
          WHERE  domainId = p_domainId 
          LIMIT 10;
  
  end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `campaign_nlp_test_distinct_count_check` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `campaign_nlp_test_distinct_count_check`(p_domainId  	INT )
begin
  
  
          
			SELECT location COLLATE utf8mb4_bin as location, count(*) as count
          FROM wc_user_contact_dtl 
          WHERE  domainId = p_domainId
          group by location COLLATE utf8mb4_bin;
     
			SELECT city COLLATE utf8mb4_bin as city, count(*) as count
          FROM wc_user_contact_dtl 
          WHERE  domainId = p_domainId
          group by city COLLATE utf8mb4_bin;
          
			SELECT state COLLATE utf8mb4_bin as state, count(*) as count
          FROM wc_user_contact_dtl 
          WHERE  domainId = p_domainId
          group by state COLLATE utf8mb4_bin;
          
			SELECT country COLLATE utf8mb4_bin as country, count(*) as count
          FROM wc_user_contact_dtl 
          WHERE  domainId = p_domainId
          group by country COLLATE utf8mb4_bin;
	 
			SELECT industryType COLLATE utf8mb4_bin as industryType, count(*) as count
          FROM wc_user_contact_dtl 
          WHERE  domainId = p_domainId
          group by industryType COLLATE utf8mb4_bin;
		  
			SELECT jobTitle COLLATE utf8mb4_bin as jobTitle, count(*) as count
          FROM wc_user_contact_dtl 
          WHERE  domainId = p_domainId
          group by jobTitle COLLATE utf8mb4_bin;
		   
			SELECT companyName COLLATE utf8mb4_bin as companyName, count(*) as count
          FROM wc_user_contact_dtl 
          WHERE  domainId = p_domainId
          group by companyName COLLATE utf8mb4_bin;
		   
  
  end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `campaign_nlp_test_null_and_whiteSpace_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `campaign_nlp_test_null_and_whiteSpace_dtl`(p_domainId  	INT )
begin
 	
 	 SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
 
 	SELECT 'id' as 'column_name', 
     SUM(case when id IS NULL THEN 1 ELSE 0 END)  as nullCount,
     SUM(case when id = '' THEN 1 ELSE 0 END)  as emptyString
     FROM wc_user_contact_dtl 
         WHERE  domainId = p_domainId
      UNION ALL   
 	SELECT 'domainId' as 'column_name', 
     SUM(case when domainId IS NULL THEN 1 ELSE 0 END)  as nullCount,
     SUM(case when domainId = '' THEN 1 ELSE 0 END)  as emptyString
     FROM wc_user_contact_dtl 
         WHERE  domainId = p_domainId
 	UNION ALL
     SELECT 'firstName' as 'column_name', 
     SUM(case when firstName IS NULL THEN 1 ELSE 0 END)  as nullCount,
     SUM(case when firstName = '' THEN 1 ELSE 0 END)  as emptyString
     FROM wc_user_contact_dtl 
         WHERE  domainId = p_domainId
      UNION ALL   
       SELECT 'lastName' as 'column_name', 
     SUM(case when lastName IS NULL THEN 1 ELSE 0 END)  as nullCount,
     SUM(case when lastName = '' THEN 1 ELSE 0 END)  as emptyString
     FROM wc_user_contact_dtl 
         WHERE  domainId = p_domainId
          UNION ALL   
       SELECT 'whatsappNumber' as 'column_name', 
     SUM(case when whatsappNumber IS NULL THEN 1 ELSE 0 END)  as nullCount,
     SUM(case when whatsappNumber = '' THEN 1 ELSE 0 END)  as emptyString
     FROM wc_user_contact_dtl 
         WHERE  domainId = p_domainId
          UNION ALL   
       SELECT 'phoneNumber' as 'column_name', 
     SUM(case when phoneNumber IS NULL THEN 1 ELSE 0 END)  as nullCount,
     SUM(case when phoneNumber = '' THEN 1 ELSE 0 END)  as emptyString
     FROM wc_user_contact_dtl 
         WHERE  domainId = p_domainId
          UNION ALL   
       SELECT 'email' as 'column_name', 
     SUM(case when email IS NULL THEN 1 ELSE 0 END)  as nullCount,
     SUM(case when email = '' THEN 1 ELSE 0 END)  as emptyString
     FROM wc_user_contact_dtl 
         WHERE  domainId = p_domainId
         
          UNION ALL   
       SELECT 'customerType' as 'column_name', 
     SUM(case when customerType IS NULL THEN 1 ELSE 0 END)  as nullCount,
     SUM(case when customerType = '' THEN 1 ELSE 0 END)  as emptyString
     FROM wc_user_contact_dtl 
         WHERE  domainId = p_domainId
         
          UNION ALL   
       SELECT 'tags' as 'column_name', 
     SUM(case when tags IS NULL THEN 1 ELSE 0 END)  as nullCount,
     SUM(case when tags = '' THEN 1 ELSE 0 END)  as emptyString
     FROM wc_user_contact_dtl 
         WHERE  domainId = p_domainId
         
         UNION ALL   
       SELECT 'location' as 'column_name', 
     SUM(case when location IS NULL THEN 1 ELSE 0 END)  as nullCount,
     SUM(case when location = '' THEN 1 ELSE 0 END)  as emptyString
     FROM wc_user_contact_dtl 
         WHERE  domainId = p_domainId
         
          UNION ALL   
       SELECT 'city' as 'column_name', 
     SUM(case when city IS NULL THEN 1 ELSE 0 END)  as nullCount,
     SUM(case when city = '' THEN 1 ELSE 0 END)  as emptyString
     FROM wc_user_contact_dtl 
         WHERE  domainId = p_domainId
         
         UNION ALL   
       SELECT 'address' as 'column_name', 
     SUM(case when address IS NULL THEN 1 ELSE 0 END)  as nullCount,
     SUM(case when address = '' THEN 1 ELSE 0 END)  as emptyString
     FROM wc_user_contact_dtl 
         WHERE  domainId = p_domainId
         
         UNION ALL   
       SELECT 'state' as 'column_name', 
     SUM(case when state IS NULL THEN 1 ELSE 0 END)  as nullCount,
     SUM(case when state = '' THEN 1 ELSE 0 END)  as emptyString
     FROM wc_user_contact_dtl 
         WHERE  domainId = p_domainId
 		
         UNION ALL
 		SELECT 'country' AS column_name,
     SUM(CASE WHEN country IS NULL THEN 1 ELSE 0 END) AS nullCount,
     SUM(CASE WHEN country = '' THEN 1 ELSE 0 END) AS emptyString
 FROM wc_user_contact_dtl
 WHERE domainId = p_domainId
 			UNION ALL
 			SELECT 'postCode' AS column_name,
 				SUM(CASE WHEN postCode IS NULL THEN 1 ELSE 0 END) AS nullCount,
 				SUM(CASE WHEN postCode = '' THEN 1 ELSE 0 END) AS emptyString
 			FROM wc_user_contact_dtl
 			WHERE domainId = p_domainId
 			UNION ALL
 			SELECT 'source' AS column_name,
 				SUM(CASE WHEN source IS NULL THEN 1 ELSE 0 END) AS nullCount,
 				SUM(CASE WHEN source = '' THEN 1 ELSE 0 END) AS emptyString
 			FROM wc_user_contact_dtl
 			WHERE domainId = p_domainId
 			UNION ALL
 			SELECT 'deviceId' AS column_name,
 				SUM(CASE WHEN deviceId IS NULL THEN 1 ELSE 0 END) AS nullCount,
 				SUM(CASE WHEN deviceId = '' THEN 1 ELSE 0 END) AS emptyString
 			FROM wc_user_contact_dtl
 			WHERE domainId = p_domainId
 			UNION ALL
 			SELECT 'sip_log_id' AS column_name,
 				SUM(CASE WHEN sip_log_id IS NULL THEN 1 ELSE 0 END) AS nullCount,
 				SUM(CASE WHEN sip_log_id = '' THEN 1 ELSE 0 END) AS emptyString
 			FROM wc_user_contact_dtl
 			WHERE domainId = p_domainId
 			UNION ALL
 			SELECT 'extension' AS column_name,
 				SUM(CASE WHEN extension IS NULL THEN 1 ELSE 0 END) AS nullCount,
 				SUM(CASE WHEN extension = '' THEN 1 ELSE 0 END) AS emptyString
 			FROM wc_user_contact_dtl
 			WHERE domainId = p_domainId
 			UNION ALL
 			SELECT 'lifeCycleStage' AS column_name,
 				SUM(CASE WHEN lifeCycleStage IS NULL THEN 1 ELSE 0 END) AS nullCount,
 				SUM(CASE WHEN lifeCycleStage = '' THEN 1 ELSE 0 END) AS emptyString
 			FROM wc_user_contact_dtl
 			WHERE domainId = p_domainId;
 
 			SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ccaas_get_shop_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ccaas_get_shop_details`(
    p_shopDomain  VARCHAR(100)
)
BEGIN
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

	select conId, domainId, domainName, shopDomain, accessToken, isConnected, connectionName, connectorName, token, userName, pwd, syncStatus
    , syncTime, contactSyncDetails, contactSyncType, scriptId, botData, chatWidgetStatus, settings, createDate, updatedDate, StoreConnectionId
    
    from tb_StoreConnection where shopDomain collate utf8mb4_0900_ai_ci = p_shopDomain and isConnected= 1;
   

    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ec_create_email_campaign_master_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ec_create_email_campaign_master_dtl`(
          p_domainId int,
          p_Name text,
          p_Goal text,
          p_Type varchar(100),
          p_TargetAud varchar(100),
          p_Objective text,
          p_AB_testing tinyint,
          p_AItemplateA json,
          p_AItemplateB json,
          p_contactEmail json,
          p_emailDelivery int,
          p_emailDeliveryAt date,
          p_emailDeliveryStarttime date,
          p_emailDeliveryEndtime date,
          p_AB_testtype int,
          p_AB_variant json,
          p_AB_variantDistribution json,
          p_AB_winningCriteria int,
          p_AB_testWindow int,
          p_AB_testWindowtype int,
          p_createdBy varchar(100),
          p_campaignchatid	varchar(300),
          p_isIndivCamp		tinyint
          )
SP:Begin
          
         	declare v_errcode 		int default - 1;
         	declare v_errmsg 		TEXT default 'Failure';
         	declare v_campaignId 	int;
             DECLARE v_A				SMALLINT;
             DECLARE v_B				SMALLINT;
             DECLARE v_TotalCount	INT;
             DECLARE v_CreateExamineTime		DATETIME;
             DECLARE v_currentDate			DATETIME;					
              
              DECLARE EXIT HANDLER FOR SQLEXCEPTION                   
            		BEGIN
            			GET DIAGNOSTICS CONDITION 1 @st = RETURNED_SQLSTATE, @p2 =  MESSAGE_TEXT;
            			set v_errmsg =  CONCAT(@st, ' : ', @p2);
            			set  @st='';
            			select -1 as errcode, v_errmsg as errmsg;
            			ROLLBACK;
            		END;
      		
              IF p_campaignchatid IS NULL THEN 
      			SELECT v_errcode as errcode, v_errmsg as errmsg;
                  LEAVE SP;
              END IF;
                  
            	START TRANSACTION;
          		sp_exit:begin
    			
      SET @existing_emails = NULL;
      SET @excluded_emails = NULL;
      
      CALL sp_exclude_email(p_contactEmail, @existing_emails, @excluded_emails);
    
          			insert into ec_email_campaign_master_dtl(domainId, Name, Goal, Type, TargetAud, Objective, AB_testing, AItemplateA, AItemplateB, contactslist, emailDelivery, createdBy, emailDeliveryAt, emailDeliveryStarttime, emailDeliveryEndtime, campaignchatid, isIndivCamp)
          			values(p_domainId,p_Name,  p_Goal, p_Type,p_TargetAud,p_Objective,p_AB_testing,p_AItemplateA,p_AItemplateB,@existing_emails,p_emailDelivery,p_createdBy, p_emailDeliveryAt, p_emailDeliveryStarttime, p_emailDeliveryEndtime , p_campaignchatid, p_isIndivCamp);
                      	
          			set v_campaignId = last_insert_id();
         					
          			insert into ec_email_campaign_master_dtl_exclude_email (fk_campaignId,domainId,campaignchatid,contactslist,createdBy,status) 
  					values(v_campaignId,p_domainId,p_campaignchatid,@excluded_emails,p_createdBy,0); 
    					  
  					  
          			if p_AB_testing = 1 then
                     
         					SET v_currentDate = CAST(DATE_FORMAT(NOW(),"%y-%m-%d %h:%i:00") as datetime);
         					
                             SET v_CreateExamineTime = (SELECT 
         												CASE WHEN p_AB_testWindowtype = 1 THEN date_add(v_currentDate, interval p_AB_testWindow minute) 
         													WHEN p_AB_testWindowtype = 2 THEN  date_add(v_currentDate, interval p_AB_testWindow hour)
                                                              END );
                                                              
                             
          				insert into ec_email_campaign_AB_testing_dtl (campaignId, testtype, variant, variantDistribution, winningCriteria, AB_testWindow, AB_testWindowtype, examineTime)
          				values(v_campaignId, p_AB_testtype, p_AB_variant, p_AB_variantDistribution, p_AB_winningCriteria, p_AB_testWindow, p_AB_testWindowtype, v_CreateExamineTime);
          			End if;
          			
          			if  json_valid(p_contactEmail)=0 then
          				set v_errcode = -1;
          				set v_errmsg = 'Invalid json object';
          				leave sp_exit;
          			Else
  						 
                         DROP TEMPORARY TABLE IF EXISTS tt_contactEmail;
                         CREATE TEMPORARY TABLE tt_contactEmail(SlNo SMALLINT AUTO_INCREMENT PRIMARY KEY,contactEmail VARCHAR(150), deliveryTime DATETIME, Template	VARCHAR(2));
                         
                         INSERT INTO tt_contactEmail(contactEmail, deliveryTime)
         				select 	tm.contactEmail 
         					,	tm.deliveryTime
         				from json_table(@existing_emails, '$[*]' columns(
         					contactEmail varchar(100) path '$.contactEmail',
         					deliveryTime datetime PATH '$.deliveryTime'
          				)) as tm;
                         
                         IF p_AB_testing = 1 THEN
         					SELECT 	MAX(SlNo)
         					INTO	v_TotalCount
         					FROM 	tt_contactEmail;
         						
         					SET v_A	= v_TotalCount * json_extract(p_AB_variantDistribution,'$.A') / 100
         					, 	v_B = v_A + (v_TotalCount * json_extract(p_AB_variantDistribution,'$.B') / 100);
         					
         					UPDATE 	tt_contactEmail
         					SET 	Template	= 'A'
         					WHERE 	SlNo 		<= v_A;
         					
         					UPDATE 	tt_contactEmail
         					SET 	Template	= 'B'
         					WHERE 	SlNo 		> v_A AND SlNo <= v_B ;                
         				 
         					insert into  ec_campaign_contacts_dtl(domainId, campaignId, contactEmail,deliveryTime,Template)
         					select 	p_domainId,v_campaignId,CE.contactEmail,CE.deliveryTime,CE.Template 
         					from	tt_contactEmail CE;
         				ELSE
         					insert into  ec_campaign_contacts_dtl(domainId, campaignId, contactEmail,deliveryTime,Template)
         					select 	p_domainId,v_campaignId,CE.contactEmail,CE.deliveryTime,'A'
         					from	tt_contactEmail CE;                    
         				END IF;
  					End if;
  
          			-- if row_Count()>0 then
          				set v_errcode = 0;
          				set v_errmsg = 'Campaign Created';
          			-- End if;
                  
          		End sp_exit;
              COMMIT;
              
              DROP TEMPORARY TABLE IF EXISTS tt_contactEmail;
              
         	select v_campaignId as campaignId,v_errcode as errcode, v_errmsg as errmsg;
          End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ec_create_email_campaign_master_dtl_bkp_2026_02_11` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ec_create_email_campaign_master_dtl_bkp_2026_02_11`(
         p_domainId int,
         p_Name text,
         p_Goal text,
         p_Type varchar(100),
         p_TargetAud varchar(100),
         p_Objective text,
         p_AB_testing tinyint,
         p_AItemplateA json,
         p_AItemplateB json,
         p_contactEmail json,
         p_emailDelivery int,
         p_emailDeliveryAt date,
         p_emailDeliveryStarttime date,
         p_emailDeliveryEndtime date,
         p_AB_testtype int,
         p_AB_variant json,
         p_AB_variantDistribution json,
         p_AB_winningCriteria int,
         p_AB_testWindow int,
         p_AB_testWindowtype int,
         p_createdBy varchar(100),
         p_campaignchatid	varchar(300),
         p_isIndivCamp		tinyint
         )
SP:Begin
         
        	declare v_errcode 		int default - 1;
        	declare v_errmsg 		TEXT default 'Failure';
        	declare v_campaignId 	int;
            DECLARE v_A				SMALLINT;
            DECLARE v_B				SMALLINT;
            DECLARE v_TotalCount	INT;
            DECLARE v_CreateExamineTime		DATETIME;
            DECLARE v_currentDate			DATETIME;					
             
             DECLARE EXIT HANDLER FOR SQLEXCEPTION                   
           		BEGIN
           			GET DIAGNOSTICS CONDITION 1 @st = RETURNED_SQLSTATE, @p2 =  MESSAGE_TEXT;
           			set v_errmsg =  CONCAT(@st, ' : ', @p2);
           			set  @st='';
           			select -1 as errcode, v_errmsg as errmsg;
           			ROLLBACK;
           		END;
     		
             IF p_campaignchatid IS NULL THEN 
     			SELECT v_errcode as errcode, v_errmsg as errmsg;
                 LEAVE SP;
             END IF;
                 
           	START TRANSACTION;
         		sp_exit:begin
   			
     SET @existing_emails = NULL;
     SET @excluded_emails = NULL;
     
     CALL sp_exclude_email(p_contactEmail, @existing_emails, @excluded_emails);
   
         			insert into ec_email_campaign_master_dtl(domainId, Name, Goal, Type, TargetAud, Objective, AB_testing, AItemplateA, AItemplateB, contactslist, emailDelivery, createdBy, emailDeliveryAt, emailDeliveryStarttime, emailDeliveryEndtime, campaignchatid, isIndivCamp)
         			values(p_domainId,p_Name,  p_Goal, p_Type,p_TargetAud,p_Objective,p_AB_testing,p_AItemplateA,p_AItemplateB,@existing_emails,p_emailDelivery,p_createdBy, p_emailDeliveryAt, p_emailDeliveryStarttime, p_emailDeliveryEndtime , p_campaignchatid, p_isIndivCamp);
                     	
         			set v_campaignId = last_insert_id();
        					
         			insert into ec_email_campaign_master_dtl_exclude_email (fk_campaignId,domainId,campaignchatid,contactslist,createdBy,status) 
 					values(v_campaignId,p_domainId,p_campaignchatid,@excluded_emails,p_createdBy,0); 
   					  
 					  
         			if p_AB_testing = 1 then
                    
        					SET v_currentDate = CAST(DATE_FORMAT(NOW(),"%y-%m-%d %h:%i:00") as datetime);
        					
                            SET v_CreateExamineTime = (SELECT 
        												CASE WHEN p_AB_testWindowtype = 1 THEN date_add(v_currentDate, interval p_AB_testWindow minute) 
        													WHEN p_AB_testWindowtype = 2 THEN  date_add(v_currentDate, interval p_AB_testWindow hour)
                                                             END );
                                                             
                            
         				insert into ec_email_campaign_AB_testing_dtl (campaignId, testtype, variant, variantDistribution, winningCriteria, AB_testWindow, AB_testWindowtype, examineTime)
         				values(v_campaignId, p_AB_testtype, p_AB_variant, p_AB_variantDistribution, p_AB_winningCriteria, p_AB_testWindow, p_AB_testWindowtype, v_CreateExamineTime);
         			End if;
         			
         			if  json_valid(p_contactEmail)=0 then
         				set v_errcode = -1;
         				set v_errmsg = 'Invalid json object';
         				leave sp_exit;
         			Else
 						 
                        DROP TEMPORARY TABLE IF EXISTS tt_contactEmail;
                        CREATE TEMPORARY TABLE tt_contactEmail(SlNo SMALLINT AUTO_INCREMENT PRIMARY KEY,contactEmail VARCHAR(150), deliveryTime DATETIME, Template	VARCHAR(2));
                        
                        INSERT INTO tt_contactEmail(contactEmail, deliveryTime)
        				select 	tm.contactEmail 
        					,	tm.deliveryTime
        				from json_table(@existing_emails, '$[*]' columns(
        					contactEmail varchar(100) path '$.contactEmail',
        					deliveryTime datetime PATH '$.deliveryTime'
         				)) as tm;
                        
                        IF p_AB_testing = 1 THEN
        					SELECT 	MAX(SlNo)
        					INTO	v_TotalCount
        					FROM 	tt_contactEmail;
        						
        					SET v_A	= v_TotalCount * json_extract(p_AB_variantDistribution,'$.A') / 100
        					, 	v_B = v_A + (v_TotalCount * json_extract(p_AB_variantDistribution,'$.B') / 100);
        					
        					UPDATE 	tt_contactEmail
        					SET 	Template	= 'A'
        					WHERE 	SlNo 		<= v_A;
        					
        					UPDATE 	tt_contactEmail
        					SET 	Template	= 'B'
        					WHERE 	SlNo 		> v_A AND SlNo <= v_B ;                
        				 
        					insert into  ec_campaign_contacts_dtl(domainId, campaignId, contactEmail,deliveryTime,Template)
        					select 	p_domainId,v_campaignId,CE.contactEmail,CE.deliveryTime,CE.Template 
        					from	tt_contactEmail CE;
        				ELSE
        					insert into  ec_campaign_contacts_dtl(domainId, campaignId, contactEmail,deliveryTime,Template)
        					select 	p_domainId,v_campaignId,CE.contactEmail,CE.deliveryTime,'A'
        					from	tt_contactEmail CE;                    
        				END IF;
 					End if;
 
         			-- if row_Count()>0 then
         				set v_errcode = 0;
         				set v_errmsg = 'Campaign Created';
         			-- End if;
                 
         		End sp_exit;
             COMMIT;
             
             DROP TEMPORARY TABLE IF EXISTS tt_contactEmail;
             
        	select v_campaignId as campaignId,v_errcode as errcode, v_errmsg as errmsg;
         End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ec_create_email_campaign_master_dtl_test_2026_01_29` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ec_create_email_campaign_master_dtl_test_2026_01_29`(
       p_domainId int,
       p_Name text,
       p_Goal text,
       p_Type varchar(100),
       p_TargetAud varchar(100),
       p_Objective text,
       p_AB_testing tinyint,
       p_AItemplateA json,
       p_AItemplateB json,
       p_contactEmail json,
       p_emailDelivery int,
       p_emailDeliveryAt date,
       p_emailDeliveryStarttime date,
       p_emailDeliveryEndtime date,
       p_AB_testtype int,
       p_AB_variant json,
       p_AB_variantDistribution json,
       p_AB_winningCriteria int,
       p_AB_testWindow int,
       p_AB_testWindowtype int,
       p_createdBy varchar(100),
       p_campaignchatid	varchar(300),
       p_isIndivCamp		tinyint
       )
SP:Begin
       
      	declare v_errcode 		int default - 1;
      	declare v_errmsg 		TEXT default 'Failure';
      	declare v_campaignId 	int;
          DECLARE v_A				SMALLINT;
          DECLARE v_B				SMALLINT;
          DECLARE v_TotalCount	INT;
          DECLARE v_CreateExamineTime		DATETIME;
          DECLARE v_currentDate			DATETIME;					
           
           DECLARE EXIT HANDLER FOR SQLEXCEPTION                   
         		BEGIN
         			GET DIAGNOSTICS CONDITION 1 @st = RETURNED_SQLSTATE, @p2 =  MESSAGE_TEXT;
         			set v_errmsg =  CONCAT(@st, ' : ', @p2);
         			set  @st='';
         			select -1 as errcode, v_errmsg as errmsg;
         			ROLLBACK;
         		END;
   		
           IF p_campaignchatid IS NULL THEN 
   			SELECT v_errcode as errcode, v_errmsg as errmsg;
               LEAVE SP;
           END IF;
               
         	START TRANSACTION;
       		sp_exit:begin
 			
 
 
 SET @existing_emails = NULL;
 SET @excluded_emails = NULL;
 
 CALL sp_exclude_email(p_contactEmail, @existing_emails, @excluded_emails);
 
 SELECT @existing_emails AS existing_emails;
 SELECT @excluded_emails AS excluded_emails;
 
 
 
 
 
       			insert into ec_email_campaign_master_dtl_test_test_2026_01_29(domainId, Name, Goal, Type, TargetAud, Objective, AB_testing, AItemplateA, AItemplateB, contactslist, emailDelivery, createdBy, emailDeliveryAt, emailDeliveryStarttime, emailDeliveryEndtime, campaignchatid, isIndivCamp)
       			values(p_domainId,p_Name,  p_Goal, p_Type,p_TargetAud,p_Objective,p_AB_testing,p_AItemplateA,p_AItemplateB,@existing_emails,p_emailDelivery,p_createdBy, p_emailDeliveryAt, p_emailDeliveryStarttime, p_emailDeliveryEndtime , p_campaignchatid, p_isIndivCamp);
                   	
       			set v_campaignId = last_insert_id();
      					
 
       			insert into ec_email_campaign_master_dtl_exclude_email(campaignId,domainId, Name, Goal, Type, TargetAud, Objective, AB_testing, AItemplateA, AItemplateB, contactslist, emailDelivery, createdBy, emailDeliveryAt, emailDeliveryStarttime, emailDeliveryEndtime, campaignchatid, isIndivCamp)
       			values(v_campaignId,p_domainId,p_Name,  p_Goal, p_Type,p_TargetAud,p_Objective,p_AB_testing,p_AItemplateA,p_AItemplateB,@excluded_emails,p_emailDelivery,p_createdBy, p_emailDeliveryAt, p_emailDeliveryStarttime, p_emailDeliveryEndtime , p_campaignchatid, p_isIndivCamp);
                   	
 
 
 
    			
       			if p_AB_testing = 1 then
                  
      					SET v_currentDate = CAST(DATE_FORMAT(NOW(),"%y-%m-%d %h:%i:00") as datetime);
      					
                          SET v_CreateExamineTime = (SELECT 
      												CASE WHEN p_AB_testWindowtype = 1 THEN date_add(v_currentDate, interval p_AB_testWindow minute) 
      													WHEN p_AB_testWindowtype = 2 THEN  date_add(v_currentDate, interval p_AB_testWindow hour)
                                                           END );
                                                           
                          
       				insert into ec_email_campaign_AB_testing_dtl_test_test_2026_01_29 (campaignId, testtype, variant, variantDistribution, winningCriteria, AB_testWindow, AB_testWindowtype, examineTime)
       				values(v_campaignId, p_AB_testtype, p_AB_variant, p_AB_variantDistribution, p_AB_winningCriteria, p_AB_testWindow, p_AB_testWindowtype, v_CreateExamineTime);
       			End if;
       			
       			if  json_valid(p_contactEmail)=0 then
       				set v_errcode = -1;
       				set v_errmsg = 'Invalid json object';
       				leave sp_exit;
       			Else
       				
                      DROP TEMPORARY TABLE IF EXISTS tt_contactEmail;
                      CREATE TEMPORARY TABLE tt_contactEmail(SlNo SMALLINT AUTO_INCREMENT PRIMARY KEY,contactEmail VARCHAR(150), deliveryTime DATETIME, Template	VARCHAR(2));
                      
                      INSERT INTO tt_contactEmail(contactEmail, deliveryTime)
      				select 	tm.contactEmail 
      					,	tm.deliveryTime
      				from json_table(p_contactEmail, '$[*]' columns(
      					contactEmail varchar(100) path '$.contactEmail',
      					deliveryTime datetime PATH '$.deliveryTime'
       				)) as tm;
                      
                      IF p_AB_testing = 1 THEN
      					SELECT 	MAX(SlNo)
      					INTO	v_TotalCount
      					FROM 	tt_contactEmail;
      						
      					SET v_A	= v_TotalCount * json_extract(p_AB_variantDistribution,'$.A') / 100
      					, 	v_B = v_A + (v_TotalCount * json_extract(p_AB_variantDistribution,'$.B') / 100);
      					
      					UPDATE 	tt_contactEmail
      					SET 	Template	= 'A'
      					WHERE 	SlNo 		<= v_A;
      					
      					UPDATE 	tt_contactEmail
      					SET 	Template	= 'B'
      					WHERE 	SlNo 		> v_A AND SlNo <= v_B ;                
      				 
      					insert into  ec_campaign_contacts_dtl_test_2026_01_29(domainId, campaignId, contactEmail,deliveryTime,Template)
      					select 	p_domainId,v_campaignId,CE.contactEmail,CE.deliveryTime,CE.Template 
      					from	tt_contactEmail CE;
      				ELSE
      					insert into  ec_campaign_contacts_dtl_test_2026_01_29(domainId, campaignId, contactEmail,deliveryTime,Template)
      					select 	p_domainId,v_campaignId,CE.contactEmail,CE.deliveryTime,'A'
      					from	tt_contactEmail CE;                    
      				END IF;
       			End if;
       			
       			if row_Count()>0 then
       				set v_errcode = 0;
       				set v_errmsg = 'Campaign Created';
       			End if;
               
       		End sp_exit;
           COMMIT;
           
           DROP TEMPORARY TABLE IF EXISTS tt_contactEmail;
           
      	select v_campaignId as campaignId,v_errcode as errcode, v_errmsg as errmsg;
       End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ec_delete_folder_list` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ec_delete_folder_list`(
 p_domainId int,
 p_folderid varchar(50)
 )
Begin
 	declare v_errcode int default -1;
     declare v_errmsg varchar(50) default 'Failure';
     
     call Split(p_folderid,','); 
     
     drop temporary table if exists tt_fold_id;
     create temporary table tt_fold_id ( id int auto_increment primary key, folderId int );     
     
     insert into tt_fold_id(folderId)    select items from tt_Split_temptable;
     
     delete a from ec_folder_dtl a 
     join tt_fold_id b on a.folderId = b.folderId
     where a.domainId = p_domainId;
     
     if row_count()>0 then
 		set v_errcode = 0;
 		set v_errmsg = 'Folder deleted';
     End if;
     
     select v_errcode as errcode, v_errmsg as errmsg;
     
     drop temporary table if exists tt_fold_id;
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ec_delete_no_interaction_contact_by_campaign` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ec_delete_no_interaction_contact_by_campaign`(
    IN p_domainId INT,
    IN p_email VARCHAR(200)
)
proc: BEGIN
    DECLARE v_errMsg  VARCHAR(100) DEFAULT 'Success';
    DECLARE v_errCode SMALLINT DEFAULT 0;

    IF p_domainId IS NULL OR p_email IS NULL THEN
        SET v_errCode = 1;
        SET v_errMsg  = 'domainId and email are mandatory';
        SELECT v_errCode AS errCode, v_errMsg AS errMsg;
        LEAVE proc;
    END IF;

    IF EXISTS ( SELECT 1 FROM wc_user_contact_dtl WHERE domainId = p_domainId AND email = p_email ) THEN

        delete FROM wc_user_contact_dtl WHERE domainId = p_domainId AND email = p_email;

        IF ROW_COUNT() > 0 THEN
            SET v_errCode = 0;
            SET v_errMsg  = 'Deleted successfully';
        ELSE
            SET v_errCode = 3;
            SET v_errMsg  = 'Delete failed';
        END IF;

    ELSE
        SET v_errCode = 2;
        SET v_errMsg  = 'Email does not exist for the given domainId';
    END IF;

    SELECT v_errCode AS errCode, v_errMsg AS errMsg;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ec_email_campaign_get_config_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ec_email_campaign_get_config_dtl`(	
	p_domainId		INT
)
BEGIN
		
			SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
            
            SELECT id, domainId, emailId, aliasName, isBot, createdOn, updatedOn
				FROM ec_email_campaign_config_dtl WHERE domainId = p_domainId;
            
            SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ec_email_campaign_get_search_history` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ec_email_campaign_get_search_history`(
		p_domain_id				INT
)
BEGIN
	SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	SELECT 	search_details FROM ec_email_campaign_search_history
	WHERE 	domain_id = p_domain_id;
	SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ec_email_campaign_insert_config_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ec_email_campaign_insert_config_dtl`(
	p_id			INT,
	p_domainId		INT,
    p_emailId		VARCHAR(70),
    p_aliasName		VARCHAR(50),
    p_isBot			TINYINT
)
BEGIN
			DECLARE v_errMsg  VARCHAR(50) DEFAULT "Failed";
            DECLARE v_errCode	SMALLINT	DEFAULT -1;	

		IF p_id IS NULL THEN 

			IF NOT EXISTS (SELECT 1 FROM ec_email_campaign_config_dtl WHERE emailId = p_emailId)
			THEN 
			
				INSERT INTO ec_email_campaign_config_dtl
				(domainId, emailId, aliasName, isBot)
				VALUES
				(p_domainId, p_emailId, p_aliasName, p_isBot);
		
					IF ROW_COUNT() > 0 THEN 
							
							SET v_errCode	=  0;
							SET v_errMsg	= "Inserted Succesfully";
					
					END IF;
                    
			END IF;
        
        ELSE
				IF EXISTS (SELECT 1 FROM ec_email_campaign_config_dtl WHERE emailId = p_emailId and id = p_id)
				THEN 
						UPDATE ec_email_campaign_config_dtl
						SET isBot = p_isBot
						WHERE  id = p_id AND emailId = p_emailId;
        
				IF ROW_COUNT() > 0 THEN 
					
                    SET v_errCode	=  1;
                    SET v_errMsg	= "Updated Succesfully";
            
				END IF;
                
                
        END IF;
				
        END IF;
		
        SELECT v_errCode AS  errCode, v_errMsg AS errMsg;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ec_email_campaign_insert_update_search_history` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ec_email_campaign_insert_update_search_history`(
		p_domain_id				INT,
		p_search_details		text
)
BEGIN
		DECLARE v_errMsg		VARCHAR(50) DEFAULT "failed";
        DECLARE v_errCode		SMALLINT DEFAULT "-1";
        
        IF NOT EXISTS(SELECT 1 FROM ec_email_campaign_search_history WHERE domain_id = p_domain_id) THEN
        
					INSERT INTO ec_email_campaign_search_history(domain_id, search_details)
						VALUES(p_domain_id, p_search_details);
                
                IF ROW_COUNT() > 0 THEN 
						
                        SET v_errCode = 0;
                        SET v_errMsg = "Inserted Successfully";
                        
                END IF;
                
		ELSEIF EXISTS(SELECT 1 FROM ec_email_campaign_search_history WHERE domain_id = p_domain_id) THEN
			
            UPDATE 	ec_email_campaign_search_history
			SET 	search_details = p_search_details
			WHERE 	domain_id = p_domain_id;
				
                IF ROW_COUNT() > 0 THEN 
						
                        SET v_errCode = 1;
                        SET v_errMsg = "Updated Successfully";
                        
                END IF;
                
        END IF;
        
        SELECT v_errCode as errCode, v_errMsg AS errMsg;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ec_email_insert_failed_contact_sent_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ec_email_insert_failed_contact_sent_dtl`(
 	p_domainId			INT,	
 	p_campaignId		INT,
 	p_emailId			VARCHAR(100)
 )
BEGIN
 		 DECLARE v_errCode				TINYINT DEFAULT -1;
         DECLARE v_errMsg				VARCHAR(50) DEFAULT 'failed';
         DECLARE v_campaignchatid		VARCHAR(300);
         DECLARE v_userId				INT;
         DECLARE v_id					INT;		--  ******* ec_campaign_contacts_dtl -> column ************
         
 		select id INTO v_id from ec_campaign_contacts_dtl where domainId = p_domainId and campaignId = p_campaignId and contactEmail = p_emailId;
         
 			IF v_id IS NOT NULL THEN 
 				UPDATE ec_campaign_contacts_dtl
 					SET	isStop	= 1,
 						stopTime = current_timestamp()
 				WHERE id  = v_id;
 				
                 IF ROW_COUNT() > 0 THEN 
 					SELECT campaignchatid INTO v_campaignchatid 
 						FROM ec_email_campaign_master_dtl 
 					WHERE domainId = p_domainId AND campaignId = p_campaignId;
         
 					SELECT id INTO v_userId 
 						FROM wc_user_contact_dtl 
 					WHERE domainId = p_domainId AND  email = p_emailId; 
         
 					INSERT INTO ec_email_failed_contact_dtl(domainId, campaignId, campaignChatId, userId, contactEmail, createdOn)
 						VALUES(p_domainId, p_campaignId , v_campaignchatid , v_userId, p_emailId, now());
                         
 					IF ROW_COUNT() > 0 THEN 
 						SET v_errCode = 0 , v_errMsg = "Inserted Successfully";
					ELSEIF v_userId is null then 
						SET v_errCode = 0 , v_errMsg = "Inserted Successfully";
 					END IF;
                         
 				END IF;
 			END IF;
         
 
 		SELECT v_errCode AS errCode, v_errMsg AS errMsg;
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ec_getCountforClickAndOpenRate` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ec_getCountforClickAndOpenRate`(
     	p_domainId				INT,
     	p_campaignchatid		VARCHAR(300)
     )
BEGIN	
   		DECLARE v_emailCount			INT DEFAULT 0;
           DECLARE v_totalOpenRate		INT DEFAULT 0;
           DECLARE v_totalClickRate		INT DEFAULT 0;
           DECLARE v_uniqueOpenRate		INT DEFAULT 0;
           DECLARE v_uniqueClickRate		INT DEFAULT 0;
           DECLARE v_TotalA				INT DEFAULT 0;
           DECLARE v_TotalB				INT DEFAULT 0;
           DECLARE v_campaignId			INT DEFAULT 0;
           
           
           SELECT campaignId INTO  v_campaignId FROM ec_email_campaign_master_dtl WHERE domainId = p_domainId AND p_campaignchatid = campaignchatid;
           
           
   
   
   	SELECT COUNT(tt.emaildtl) INTO v_emailCount FROM ec_email_campaign_master_dtl t1,
   	JSON_TABLE(contactslist, '$[*]' COLUMNS
   		(
   			emaildtl varchar(150) path '$.contactEmail'
   		)) as tt
   	WHERE t1.domainId = p_domainId AND t1.campaignId = v_campaignId;
    
     	SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
     	WITH CTE_OverallOpenRateDtl AS(
     		SELECT 	campaignId
     			,	SUM(uniqueOpenA)	AS TotalA
     			,	SUM(uniqueOpenB)	AS TotalB
             FROM 	ec_OverallOpenRateDtl 
             WHERE 	domainId 	= p_domainId
             AND 	campaignId	= v_campaignId
             GROUP BY campaignId
         )    
     	SELECT	H.totalOpenRate
   			,H.totalClickRate
   			,IFNULL(H.uniqueOpenCount,0) 	
   			,IFNULL(H.uniqueClickCount,0)	
   			,O.TotalA
   			,O.TotalB
               INTO v_totalOpenRate, v_totalClickRate, v_uniqueOpenRate, v_uniqueClickRate, v_TotalA, v_TotalB
     	FROM 	ec_campaign_HistoryDtl		H
         LEFT JOIN CTE_OverallOpenRateDtl	O ON O.campaignId = H.campaignId
     	WHERE 	H.domainId 	= p_domainId 
         AND 	O.campaignId 	= v_campaignId;
         
         
         SELECT v_emailCount 		as emailCount, 
   			v_totalOpenRate 	as totalOpenRate, 
               v_totalClickRate	as totalClickRate, 
               v_uniqueOpenRate  	as uniqueOpenRate, 
               v_uniqueClickRate	as uniqueClickRate, 
               v_TotalA			as TotalA, 
               v_TotalB			as TotalB;
     	SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
     END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ec_getEmailCampaignInParticularFolder` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ec_getEmailCampaignInParticularFolder`(
		p_domainId			INT,
		p_folderId			INT
)
BEGIN
		
        SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
				
            SELECT t1.campaignId, t1.domainId, t1.Name, t1.Goal, t1.Type, t1.TargetAud,
					t1.Objective
            FROM ec_email_campaign_master_dtl t1
            JOIN ec_campaign_folder_list t2 
            ON t1.campaignId = t2.campaignId AND t1.domainId = t2.domainId
            WHERE t2.folderid = p_folderId; 
								
		SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
            
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ec_getWinning_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ec_getWinning_dtl`(
	p_campaignId		INT
)
BEGIN

		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

		SELECT id, createdate, campaignId, A, B
        FROM ec_campaign_winning_dtl
        WHERE campaignId = p_campaignId;

		SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;        
        
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ec_get_all_config_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ec_get_all_config_dtl`(p_domainId		INT)
BEGIN
 		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
 
 		SELECT config_id as id, aliasName , fromEmail as emailId, "smtp" as configType FROM ec_tb_smtp_config_dtl
         WHERE domainId = p_domainId
         UNION ALL
         SELECT id ,aliasName , emailId as emailId, "worktual" as configType FROM ec_email_campaign_config_dtl
         WHERE domainId = p_domainId;
         
         SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ec_get_campaign_email_status_list` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ec_get_campaign_email_status_list`(
p_domainId int,
p_campaignId int
)
Begin
	select * from ec_campaign_contacts_dtl where domainId = p_domainId and campaignId = p_campaignId and isSent = 0;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ec_get_clickRate_History_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ec_get_clickRate_History_dtl`(	p_domainId				INT		
   , p_campaignChatId			VARCHAR(300)	
   , p_fromDate				DATE
   , p_toDate					DATE
   )
BEGIN
  			DECLARE v_campaignId		INT;
              
              
              SELECT campaignId INTO v_campaignId FROM ec_email_campaign_master_dtl  WHERE domainId = p_domainId AND campaignchatid =  p_campaignChatId;
              
              
              SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
              
              SELECT 
  					id ,domainId ,campaignId ,emailId ,uniqueClickA ,uniqueClickB ,CreatedOn
              FROM ec_campaign_clickRate_history_dtl 
              WHERE campaignId = v_campaignId 
  				AND domainId = p_domainId 	
  				AND DATE(CreatedOn) >= p_fromDate AND DATE(CreatedOn) <= p_toDate ; 
              
  			SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
  
   END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ec_get_emails_for_all_campaigns` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ec_get_emails_for_all_campaigns`(v_Limit 	SMALLINT)
BEGIN
    		DECLARE v_CurDate		DATETIME DEFAULT NOW();
         
    		SET v_CurDate = DATE_ADD(DATE_ADD(NOW(), INTERVAL 5 HOUR), interval 30 minute);  
              
           DROP TEMPORARY TABLE IF EXISTS tt_campaignIds;     
           
           SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
           CREATE TEMPORARY TABLE tt_campaignIds
          SELECT t1.id				AS contactId
     		,	t1.campaignId 
     		,	t1.contactEmail
     		,	t1.deliveryTime
             ,	t1.Template
             ,	t1.domainId
           FROM 	ec_campaign_contacts_dtl 					t1
           JOIN 	ec_email_campaign_master_dtl				t2		ON t1.campaignId = t2.campaignId
           LEFT JOIN wc_master_revert_status_details			t3		ON t2.campaignchatid = t3.campaignchatId
           WHERE isSent 			= 0
 		  AND 	deliveryTime 	<= v_CurDate
           AND 	t3.campaignchatId IS NULL
           AND  t1.isStop		!= 1					-- ********** Added on 12-01-2026 ************
           ORDER BY deliveryTime  
           LIMIT v_Limit; 
           
      	WITH CTE_campaignId AS (
      		SELECT 	DISTINCT campaignId
              FROM 	tt_campaignIds
          )
          SELECT CMP.campaignId
       		,	CMP.domainId
   			,	CMP.AItemplateA
              ,	CMP.AItemplateB
             
  
  
           FROM 	CTE_campaignId					C_C
           JOIN 	ec_email_campaign_master_dtl 	CMP	ON CMP.campaignId = C_C.campaignId;
           
           SELECT t1.contactId
       		,	t1.campaignId 
       		,	t1.contactEmail
     		,	t1.deliveryTime
			,	t1.Template
			, 	t2.id
			,	t2.domainId
			,	t2.firstName
			,	t2.lastName
			,	t2.whatsappNumber
			,	t2.phoneNumber
			,	t2.email
			,	t2.customerType
			,	t2.tags
			,	t2.location
			,	t2.city
			,	t2.address
			,	t2.state
			,	t2.country
			,	t2.postCode
			,	t2.createdAt
			,	t2.updatedAt
			,	t2.`source`
			,	t2.deviceId
			,	t2.deviceOS
			,	t2.pushNotificationId
			,	t2.sip_log_id
			,	t2.extension
			,	t2.lifeCycleStage
           FROM 	tt_campaignIds	t1
           LEFT JOIN wc_user_contact_dtl	t2		ON t1.contactEmail = t2.email AND 	t1.domainId = t2.domainId;
           
           
           SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ ;
       
           DROP TEMPORARY TABLE IF EXISTS tt_campaignId;
       END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ec_get_emails_for_campaign` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ec_get_emails_for_campaign`(p_campaignId INT)
BEGIN
	DECLARE v_CurDate		DATETIME DEFAULT NOW();
    
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    SELECT 	id				AS contactId
		,	campaignId 
		,	contactEmail
        ,	deliveryTime
    FROM 	ec_campaign_contacts_dtl 
    WHERE 	campaignId	= p_campaignId
    and 	isSent 		= 0
    AND 	deliveryTime <= v_CurDate
    ORDER BY deliveryTime;  
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ ;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ec_get_email_campaign_master_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ec_get_email_campaign_master_dtl`(
 p_domainId int
 )
Begin
 	select a.campaignId, a.domainId, Name, Goal, Type, TargetAud, Objective, AB_testing, AItemplateA, AItemplateB, contactslist,
		emailDelivery, emailDeliveryAt, emailDeliveryStarttime, emailDeliveryEndtime, createdBy, status ,
 		testtype, variant, variantDistribution, winningCriteria, AB_testWindow, AB_testWindowtype, a.createdate
     from ec_email_campaign_master_dtl a 
     LEFT JOIN ec_email_campaign_AB_testing_dtl b on a.campaignId = b.campaignId
     where a.domainId = p_domainId
     order by a.createdate desc
     ;
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ec_get_folder_list` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ec_get_folder_list`(
p_domainId int,
p_folderid int
)
Begin
	select * from ec_folder_dtl where domainId = p_domainId and (folderid = p_folderid or ifnull(p_folderid,'')= '');
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ec_get_no_interaction_contact_by_campaign` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ec_get_no_interaction_contact_by_campaign`(
      IN p_domainId INT
  )
SP:BEGIN
      DECLARE v_errMsg   VARCHAR(50) DEFAULT 'Success';
      DECLARE v_errCode  SMALLINT DEFAULT 0;
  
      DECLARE done INT DEFAULT 0;
      DECLARE v_campaignId INT;
      DECLARE v_offset INT;
  
       
       DECLARE insert_cursor CURSOR FOR SELECT campaignId FROM ec_email_campaign_master_dtl WHERE domainId = p_domainId ORDER BY createdate DESC limit 3;
  
      DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;
  
      START TRANSACTION;
  
      DROP TEMPORARY TABLE IF EXISTS tt_clickRate_history_dtl;
      CREATE TEMPORARY TABLE tt_clickRate_history_dtl (
          cid        INT AUTO_INCREMENT PRIMARY KEY,
          domainId   INT,
          campaignId INT,
          email      VARCHAR(200)
      );
       DROP TEMPORARY TABLE IF EXISTS tt_openRate_history_dtl;
      CREATE TEMPORARY TABLE tt_openRate_history_dtl (
          cid        INT AUTO_INCREMENT PRIMARY KEY,
          domainId   INT,
          campaignId INT,
          email      VARCHAR(200)
      );
      OPEN insert_cursor;
  
      read_loop: LOOP
          FETCH insert_cursor INTO v_campaignId;
  
          IF done = 1 THEN
              LEAVE read_loop;
          END IF;
  
          INSERT INTO tt_clickRate_history_dtl (domainId, campaignId, email) SELECT a.domainId, a.campaignId, b.email FROM ec_campaign_clickRate_history_dtl a JOIN wc_user_contact_dtl b ON a.emailId = b.id WHERE a.campaignId = v_campaignId AND (a.uniqueClickA = 0 and uniqueClickB =0) ;
  
          INSERT INTO tt_openRate_history_dtl (domainId, campaignId, email) SELECT a.domainId, a.campaignId, b.email FROM ec_campaign_openRate_history_dtl a  JOIN wc_user_contact_dtl b ON a.emailId = b.id WHERE a.campaignId = v_campaignId AND (a.uniqueOpenA = 0 and uniqueOpenB =0);
  
      END LOOP;
  
      CLOSE insert_cursor;
      COMMIT;

 SELECT DISTINCT a.email FROM tt_clickRate_history_dtl a JOIN tt_openRate_history_dtl b ON a.email = b.email;
 
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ec_get_openRate_History_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ec_get_openRate_History_dtl`(	p_domainId				INT		
  , p_campaignChatId			VARCHAR(300)	
  , p_fromDate				DATE
  , p_toDate					DATE
  )
BEGIN
 			DECLARE v_campaignId		INT;
             
             
             SELECT campaignId INTO v_campaignId FROM ec_email_campaign_master_dtl  WHERE domainId = p_domainId AND campaignchatid =  p_campaignChatId;
             
             
             SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
             
             SELECT 
 					id ,domainId ,campaignId ,emailId ,uniqueOpenA ,uniqueOpenB ,CreatedOn
             FROM ec_campaign_openRate_history_dtl 
             WHERE campaignId = v_campaignId 
 				AND domainId = p_domainId 	
 				AND DATE(CreatedOn) >= p_fromDate AND DATE(CreatedOn) <= p_toDate ; 
             
 			SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ec_get_smtp_config_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ec_get_smtp_config_dtl`(
p_domainId		INT
)
begin


SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

select 
		config_id
		,domainId
		,aliasName
		,port
		,host
		,password
		,userName
		,fromEmail
		,isBot
		,createdOn
		,updatedOn
FROM ec_tb_smtp_config_dtl where domainId = p_domainId;

SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ec_InsertClickRateDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ec_InsertClickRateDtl`(
  		p_domainId				INT,
          p_campaignId			INT,
          p_emailId				VARCHAR(200),
          p_tempType				CHAR(1)		
      )
SP:BEGIN		
   			    DECLARE v_errMsg							VARCHAR(50) DEFAULT "Failed";
                  DECLARE v_errCode							SMALLINT DEFAULT -1;
                  DECLARE v_errCode1							SMALLINT DEFAULT 0;
                  DECLARE v_insertId							INT;
                  DECLARE v_CheckHistoryId					INT;
                  DECLARE v_ratedOn							DATETIME;
                  DECLARE v_contactId							VARCHAR(500);
                  DECLARE v_tempA								INT DEFAULT 0;
                  DECLARE v_tempB								INT  DEFAULT 0;
                  DECLARE v_campEmailId						TEXT;
                  DECLARE v_tempClickRateCount				INT DEFAULT 1;
                  DECLARE v_clickRateCount					INT DEFAULT 0;
                  DECLARE v_givenEmailId						INT;
   			    DECLARE v_campaignChatId					VARCHAR(300);				
                  DECLARE v_actionId							INT DEFAULT 4;
                  
   				DECLARE EXIT HANDLER FOR SQLEXCEPTION
   				BEGIN
   					SELECT v_errCode AS errCode, v_errMsg AS errMsg;
                       ROLLBACK;
   				END;
                  
                  IF NOT EXISTS(SELECT 1 FROM ec_email_campaign_master_dtl WHERE domainId = p_domainId AND campaignId = p_campaignId)
                  THEN
     					select v_errCode as errCode, "please check the given campaignId and domainId" as errMsg;
     					LEAVE SP;
                  END IF;
                  
                  
                  
                  SET v_ratedOn = current_timestamp();
                  
      	
                SELECT id INTO v_contactId FROM wc_user_contact_dtl 
      				WHERE domainId = p_domainId AND email = p_emailId;
                   
                   
                   SELECT campaignchatid INTO v_campaignChatId  
   				FROM ec_email_campaign_master_dtl 
   			WHERE domainId = p_domainId AND campaignId = p_campaignId;
                   
                      
      					IF p_tempType = 'A' THEN
      						SET v_tempA = 1;
      					ELSEIF p_tempType = 'B' THEN
      						SET v_tempB = 1;
      					END IF;
                      
    				SET v_givenEmailId = v_contactId;
                    
      				SELECT GROUP_CONCAT(emailId,','), IFNULL(SUM(clickRateCount),0) INTO v_campEmailId, v_clickRateCount 
      						FROM ec_OverallClickRateDtl 
      						WHERE domainId = p_domainId AND campaignId = p_campaignId;
               
      		
          
                      IF v_campEmailId IS NOT NULL THEN
                          
      					CALL split(v_campEmailId, ',');
                          
                          
                          IF EXISTS( SELECT 1 FROM tt_Split_temptable WHERE items = v_contactId)THEN
      								SET v_contactId =  NULL;
      								SET v_tempA = 0;
                                      SET v_tempB = 0;
                                      SET v_tempClickRateCount = 0;
                          END IF;
      				
                      END IF;
                  
                  START TRANSACTION;
                  
      			IF NOT EXISTS( SELECT 1 FROM ec_OverallClickRateDtl WHERE domainId = p_domainId AND campaignId = p_campaignId AND clickOn = date(v_ratedOn)) THEN
                   
      				 INSERT INTO ec_OverallClickRateDtl (domainId, campaignId, clickOn, clickRateCount, emailId, uniqueClickA, uniqueClickB) 
      							VALUES(p_domainId, p_campaignId, DATE(v_ratedOn), v_tempClickRateCount, v_contactId, v_tempA, v_tempB);
      					
      				 IF ROW_COUNT() > 0 THEN 
                          SET v_insertId = last_insert_id();
                       END IF;	
                     
      			 ELSE 
      					UPDATE ec_OverallClickRateDtl 
      						SET clickRateCount = clickRateCount+v_tempClickRateCount,
      							emailId = IFNULL(CONCAT(emailId,",",v_contactId), emailId),
                                  uniqueClickA = uniqueClickA + v_tempA,
                                  uniqueClickB = uniqueClickB + v_tempB,
                                  updatedAt = now()
      					WHERE domainId = p_domainId 
      							AND campaignId = p_campaignId 
      							AND clickOn =DATE(v_ratedOn);
      					
                          IF ROW_COUNT() > 0 THEN 
      						SET v_insertId = last_insert_id();
      					END IF;
                          
                   END IF;  
                   
                  
                   
                   IF v_insertId IS NOT NULL THEN 
      					
                        SET v_CheckHistoryId =  (SELECT sno FROM ec_campaign_HistoryDtl WHERE domainId = p_domainId AND campaignId = p_campaignId);
                        
                        
      				
                      IF v_CheckHistoryId IS NULL 
      					THEN	
      								INSERT INTO ec_campaign_HistoryDtl (domainId, campaignId, totalClickCount, uniqueClickCount, campaignChatId) 
      										VALUES(p_domainId , p_campaignId, 1, (v_clickRateCount+v_tempClickRateCount), v_campaignChatId);
                                      
                                      IF ROW_COUNT() > 0 THEN 
                                          SET v_errCode1 = 1;
                                      END IF;
      					ELSE
      							 UPDATE ec_campaign_HistoryDtl
      								SET totalClickCount = totalClickCount + 1,
      									uniqueClickCount	= (v_clickRateCount+v_tempClickRateCount)
      							   WHERE sno = v_CheckHistoryId;
                                      
                                      IF ROW_COUNT() > 0 THEN 
      									
                                          SET v_errCode1 = 1;
                                      END IF;
      								
      				END IF;
    					 IF v_errCode1 = 1 THEN  
    					
                        INSERT INTO ec_campaign_clickRate_history_dtl( domainId ,campaignId ,emailId ,uniqueClickA ,uniqueClickB, CreatedOn)
                        VALUES(p_domainId ,p_campaignId , v_givenEmailId , case when p_tempType = 'A' then 1 else 0 end ,
                        case when p_tempType = 'B' then 1 else 0 end, v_ratedOn);
                        
                        IF ROW_COUNT() > 0 THEN 
  									IF (v_actionId IS NOT NULL AND v_givenEmailId IS NOT NULL) THEN
    								
    											INSERT INTO Email_tb_indiv_user_click_open_cnt_dtl(domainId, campaignChatId, userID, actionId, createdOn)
    											VALUES(p_domainId, v_campaignChatId, v_givenEmailId, v_actionId,  v_ratedOn);
                                                
    												IF ROW_COUNT() > 0 THEN
    													SET v_errCode = 1;
    													SET v_errMsg = "Inserted Successfully";
    												END IF;
    										END IF;
                                      
                        END IF;
                        
                    END IF; 
                    
                      
      					SELECT v_errCode AS errCode,  v_errMsg AS errMsg;
                        COMMIT;
                   
                   END IF;
                   
      END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ec_insertMoveCampaigntoFolder` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ec_insertMoveCampaigntoFolder`(
    p_domainId			INT,
    p_campaignId		VARCHAR(50),
    p_folderId			INT
)
sp:BEGIN
		DECLARE v_errMsg  	VARCHAR(50) DEFAULT "Failed / Campaign already exist";
		DECLARE v_errCode  	INT DEFAULT -1;
        
        
        IF EXISTS(SELECT 1 FROM ec_folder_dtl WHERE domainId = p_domainId AND folderid = p_folderId) THEN
			
            CALL Split(p_campaignId,',');
            
            DROP TEMPORARY TABLE IF EXISTS tt_ec_moveCampaigntoFolder_01;
			CREATE TEMPORARY TABLE tt_ec_moveCampaigntoFolder_01
				SELECT items FROM tt_Split_temptable;
			
            
            INSERT INTO ec_campaign_folder_list(domainId, folderid, campaignId)
            SELECT p_domainId, p_folderId, t1.items FROM tt_ec_moveCampaigntoFolder_01 t1
            LEFT JOIN ec_campaign_folder_list t2 ON t2.campaignId = t1.items AND t2.folderid = p_folderId 
			WHERE t2.campaignId IS NULL;
            
            
            IF row_count() > 0 THEN
				SET v_errMsg = "Inserted Successfully";
                SET v_errCode = 1;
            END IF;
        
        END IF;
        
        SELECT v_errCode AS errCode, v_errMsg AS errMsg;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ec_InsertOpenRateDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ec_InsertOpenRateDtl`(
   		 p_domainId			INT,
            p_campaignId		INT,
            p_emailId			VARCHAR(200),
            p_tempType			CHAR(1)
        )
sp:BEGIN		
   				 DECLARE v_errMsg							VARCHAR(50) DEFAULT "Failed";
                    DECLARE v_errCode						SMALLINT DEFAULT -1;
                    DECLARE v_errCode1						SMALLINT DEFAULT 0;
                    DECLARE v_insertId						INT;
                    DECLARE v_CheckHistoryId				INT;										
                    DECLARE v_ratedOn						DATETIME;
                    DECLARE v_contactId						VARCHAR(500);		
                    DECLARE v_tempA							INT DEFAULT 0;					
                    DECLARE v_tempB							INT  DEFAULT 0;					
                    DECLARE v_campEmailId					TEXT;					
                    DECLARE v_tempOpenRateCount				INT DEFAULT 1;		
                    DECLARE v_openRateCount					INT DEFAULT 0;					
                    DECLARE v_givenEmailId					INT;					  
                    DECLARE v_campaignChatId				VARCHAR(300);					
  				  DECLARE v_actionId						INT DEFAULT 3;
                
                    DECLARE EXIT HANDLER FOR SQLEXCEPTION
                    BEGIN
      					SELECT v_errCode AS errCode, v_errMsg AS errMsg;
                          ROLLBACK;
                    END;
                    
			
                    IF NOT EXISTS(SELECT 1 FROM ec_email_campaign_master_dtl WHERE domainId = p_domainId AND p_campaignId = campaignId)
                    THEN
       				SELECT v_errCode as errCode, "please check the given campaignId and domainId" AS  errMsg;
       				LEAVE sp;
                   
                    END IF;
                    
                    SET v_ratedOn = CURRENT_TIMESTAMP();
                    
      				START TRANSACTION;
                     
                   
                  SELECT id INTO v_contactId FROM wc_user_contact_dtl 
        				WHERE domainId = p_domainId AND email = p_emailId;
                     
                 
                 SELECT campaignchatid INTO v_campaignChatId  
     				FROM ec_email_campaign_master_dtl 
     			WHERE domainId = p_domainId AND campaignId = p_campaignId;		
     			
                        
        					IF p_tempType = 'A' THEN
        						SET v_tempA = 1;
        					ELSEIF p_tempType = 'B' THEN
        						SET v_tempB = 1;
        					END IF;
                        
       		 SET v_givenEmailId = v_contactId;
                
                
        				SELECT GROUP_CONCAT(emailId,','), IFNULL(SUM(openRateCount),0) INTO v_campEmailId, v_openRateCount 
        						FROM ec_OverallOpenRateDtl 
        						WHERE domainId = p_domainId AND campaignId = p_campaignId;
 
             
                        IF v_campEmailId IS NOT NULL THEN
                            
        					CALL split(v_campEmailId, ',');
  
             
                            IF EXISTS( SELECT 1 FROM tt_Split_temptable WHERE items = v_contactId)THEN
   										SET v_contactId =  NULL;
   										SET v_tempA = 0;
   										SET v_tempB = 0;
   										SET v_tempOpenRateCount = 0;
                            END IF;
        				
                        END IF;
               
                    
        			IF NOT EXISTS( SELECT 1 FROM ec_OverallOpenRateDtl WHERE domainId = p_domainId AND campaignId = p_campaignId AND ratedOn = DATE(v_ratedOn)) THEN
       				
        				 INSERT INTO ec_OverallOpenRateDtl (domainId, campaignId, ratedOn, openRateCount, emailId, uniqueOpenA, uniqueOpenB) 
        							VALUES(p_domainId, p_campaignId, DATE(v_ratedOn), v_tempOpenRateCount, v_contactId, v_tempA, v_tempB);
        					
        				 IF ROW_COUNT() > 0 THEN 
                            SET v_insertId = last_insert_id();
                         END IF;	
                       
        			 ELSE 
        					UPDATE ec_OverallOpenRateDtl 
        						SET openRateCount = openRateCount+v_tempOpenRateCount,
        							emailId = IFNULL(CONCAT(emailId,",",v_contactId), emailId),
                                    uniqueOpenA = uniqueOpenA + v_tempA,
                                    uniqueOpenB = uniqueOpenB + v_tempB,
                                    updatedAt = now()
        					WHERE domainId = p_domainId 
        							AND campaignId = p_campaignId 
        							AND ratedOn =date(v_ratedOn);
        					
                            IF ROW_COUNT() > 0 THEN 
        						SET v_insertId = last_insert_id();
        					END IF;
                            
                     END IF;  
                     
   
                     IF v_insertId IS NOT NULL THEN 
        					
                          SET v_CheckHistoryId =  (SELECT sno FROM ec_campaign_HistoryDtl WHERE domainId = p_domainId AND campaignId = p_campaignId);
                          
                     
                        IF v_CheckHistoryId IS NULL 
        					THEN	
        								INSERT INTO ec_campaign_HistoryDtl (domainId, campaignId, totalOpenCount, uniqueOpenCount, campaignChatId) 
        										VALUES(p_domainId , p_campaignId, 1, (v_openRateCount+v_tempOpenRateCount), v_campaignChatId);
                                             
                                        
                                        IF ROW_COUNT() > 0 THEN 
                                            SET v_errCode1 = 1;
                                        END IF;
        					ELSE
        							 UPDATE ec_campaign_HistoryDtl
        								SET totalOpenCount = totalOpenCount + 1,
        									uniqueOpenCount	= (v_openRateCount+v_tempOpenRateCount)
        							   WHERE sno = v_CheckHistoryId;
                                        
                                        IF ROW_COUNT() > 0 THEN 
                                            SET v_errCode1 = 1;
                                        END IF;
        				
        				END IF;
     				
                       
                       IF v_errCode1 = 1 THEN  
       					
                           INSERT INTO ec_campaign_openRate_history_dtl( domainId ,campaignId ,emailId ,uniqueOpenA ,uniqueOpenB, CreatedOn)
                           VALUES(p_domainId ,p_campaignId , v_givenEmailId , case when p_tempType = 'A' then 1 else 0 end ,
                           case when p_tempType = 'B' then 1 else 0 end, v_ratedOn);
    					
    							IF ROW_COUNT() > 0 THEN 

                                       
    									IF (v_actionId IS NOT NULL AND v_givenEmailId IS NOT NULL) THEN
    								
    											INSERT INTO Email_tb_indiv_user_click_open_cnt_dtl(domainId, campaignChatId, userID, actionId, createdOn)
    											VALUES(p_domainId, v_campaignChatId, v_givenEmailId, v_actionId,  v_ratedOn);
                                                
    												IF ROW_COUNT() > 0 THEN
    													SET v_errCode = 1;
    													SET v_errMsg = "Inserted Successfully";
    												END IF;
    										END IF;
    								END IF;
    				END IF;
   
   			SELECT v_errCode AS errCode,  v_errMsg AS errMsg;
            COMMIT;
   END IF;
   END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ec_InsertUpdateWinning_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ec_InsertUpdateWinning_dtl`(
	p_campaignId		INT,
    p_AScore			INT,
    p_BScore			INT
)
BEGIN
			DECLARE v_errMsg		VARCHAR(50) DEFAULT "Failed";
            DECLARE v_errCode		INT DEFAULT -1;
            DECLARE v_currentTime	DATETIME DEFAULT NOW();
           DECLARE 	v_checkDate		DATETIME;
            

			IF NOT EXISTS(SELECT 1 FROM ec_campaign_winning_dtl WHERE campaignId = p_campaignId) THEN
                
					INSERT INTO ec_campaign_winning_dtl(campaignId, A, B) VALUES(p_campaignId, p_AScore, p_BScore);
                    
                    IF ROW_COUNT() > 0 THEN 
						SET v_errMsg = "Inserted Successfully";
						SET v_errCode = 1;
					END IF;
                    
			ELSE
					IF EXISTS(SELECT 1 FROM ec_email_campaign_AB_testing_dtl WHERE campaignId = p_campaignId AND testtype = 1) THEN
			
            
			
					SELECT CASE WHEN t1.AB_testWindowtype = 1 THEN  date_add(t2.createdate, interval t1.AB_testWindow minute) 
								WHEN t1.AB_testWindowtype = 2 THEN 	date_add(t2.createdate, interval t1.AB_testWindow hour)
							END INTO v_checkDate
                    FROM ec_email_campaign_AB_testing_dtl 		t1
						JOIN ec_campaign_winning_dtl			t2 ON t1.campaignId = t2.campaignId
						WHERE t2.campaignId = p_campaignId;
                        
                        
                        UPDATE ec_campaign_winning_dtl 
							SET  A = p_AScore,
								B = p_BScore
						WHERE campaignId = p_campaignId AND v_currentTime <= v_checkDate;
                        
       
       
						IF ROW_COUNT() > 0 THEN 
							SET v_errMsg = "Updated Successfully";
							SET v_errCode = 2;
						ELSE
							SET v_errMsg = "Time exceeded";
							SET v_errCode = -2;
						END IF;
                    
                    ELSE
                    
						UPDATE ec_campaign_winning_dtl
							SET   A = p_AScore,
								  B = p_BScore
						WHERE campaignId = p_campaignId;
                    
						IF ROW_COUNT() > 0 THEN 
							SET v_errMsg = "Updated Successfully";
							SET v_errCode = 2;
						END IF;
            END IF;
		END IF;
            SELECT v_errCode as errCode , v_errMsg as errMsg;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ec_insert_campaign_contact` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ec_insert_campaign_contact`(
p_domainId int,
p_campaignId int,
p_contactEmail json
)
Begin
	declare v_errcode int default - 1;
    declare v_errmsg varchar(50) default 'Failure';
    
    sp_exit:begin
    
		if  json_valid(p_contactEmail)=0 then
			set v_errcode = -1;
			set v_errmsg = 'Invalid json object';
			leave sp_exit;
        End if;
    
		if exists(select 1 from ec_campaign_contacts_dtl where domainId = p_domainId and campaignId = p_campaignId limit 1) then
			set v_errcode = -1;
			set v_errmsg = 'Contact already imported';
			leave sp_exit;
		End if;
		
        insert into ec_campaign_contacts_dtl(domainId, campaignId, contactEmail)
        select p_domainId,p_campaignId,tm.* from json_table(p_contactEmail, '$[*]' columns(
			contactEmail varchar(100) path '$.email'
        )) as tm;
		
        
        if row_count()>0 then
			set v_errcode = -1;
			set v_errmsg = 'Contact Inserted';
         End if;
 
    
    end;
    select v_errcode as errcode, v_errmsg as errmsg;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ec_insert_or_update_smtp_config_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ec_insert_or_update_smtp_config_dtl`(
 	p_config_id		INT ,
     p_domainId		INT,
     p_aliasName		VARCHAR(50),
     p_port			INT,
     p_host			VARCHAR(50),
     p_password		VARCHAR(50),
     p_userName		VARCHAR(50),
     p_fromEmail		VARCHAR(50),
     p_isBot			TINYINT
 )
BEGIN
 
 		DECLARE v_errCode		INT default -1;
         DECLARE v_errMsg		VARCHAR(50) default 'Failed';
 
 		IF p_config_id IS NULL THEN 
         
 			INSERT INTO ec_tb_smtp_config_dtl(aliasName ,`port` ,`host` ,`password`	,userName ,fromEmail ,isBot, domainId	)
             values(p_aliasName, p_port, p_host ,p_password	,p_userName	,p_fromEmail ,p_isBot, p_domainId);
 		
         IF row_count() > 0 THEN 
 			SET v_errMsg = "Inserted Successfully";
             SET v_errCode = 0;
 			
 		END IF;
         
         ELSE
 				UPDATE ec_tb_smtp_config_dtl
 					SET aliasName = IFNULL(p_aliasName, aliasName) 
                     ,`port` = IFNULL(p_port, `port`) 
                     ,`host` = IFNULL(p_host, `host`)
                     ,`password` = IFNULL(p_password, `password`)	
                     ,userName = IFNULL(p_userName, userName) 
                     ,fromEmail = IFNULL(p_fromEmail, fromEmail)
                     ,isBot = IFNULL(p_isBot, isBot)
 				WHERE config_id = p_config_id and domainId = p_domainId;
 			
              IF ROW_COUNT() > 0 THEN 
 				SET v_errMsg = "Updated Successfully";
 				SET v_errCode = 1;
 			
 			END IF;
             
 		END IF;
             
             SELECT v_errCode as errCode, v_errMsg as errMsg;
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ec_insert_unsubscribe_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ec_insert_unsubscribe_dtl`(
 	p_domainId			INT,
     p_campaignchatid	INT,					-- ccaas sends the campaign id not campaign chat id
     p_emailId			VARCHAR(150),
     p_tempType			CHAR(5)	
 )
BEGIN
 		
         DECLARE v_errCode	SMALLINT DEFAULT -1;
         DECLARE v_errMsg	VARCHAR(50) DEFAULT "Failed";	
         declare v_campaignchatid	varchar(300) default 0;
         
         DECLARE EXIT HANDLER FOR SQLEXCEPTION
         BEGIN
					SELECT v_errCode AS errCode, v_errMsg AS errMsg;
                    ROLLBACK;
         END;
         
         START TRANSACTION;
         
         IF EXISTS(SELECT 1 FROM wc_user_contact_dtl WHERE domainId = p_domainId  AND email = p_emailId) THEN
         
				 UPDATE wc_user_contact_dtl
							SET isUnSub_Email = 1
					WHERE domainId = p_domainId  AND email = p_emailId;
         
         SELECT campaignchatid INTO v_campaignchatid FROM ec_email_campaign_master_dtl where campaignId = p_campaignchatid;
         
         IF NOT EXISTS(SELECT 1 FROM ec_email_unsubscribe_dtl WHERE domainId = p_domainId AND campaignchatid = v_campaignchatid
 			AND emailId = p_emailId) THEN
         
 			INSERT INTO ec_email_unsubscribe_dtl(domainId, campaignchatid, emailId, tempType, createdOn)
 				VALUES(p_domainId, v_campaignchatid, p_emailId, p_tempType, now());
                
                 
                IF ROW_COUNT() > 0 THEN 
 				
                 SET v_errCode = 0;
                 SET v_errMsg = "Inserted Successfully";
				 COMMIT;
                END IF;
 								
 		END IF;					
     						
		END IF;	
        
     	SELECT 	v_errCode AS errCode, v_errMsg AS v_errMsg;		
 		
 
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ec_insert_update_campaign_move_to_folder` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ec_insert_update_campaign_move_to_folder`(
p_domainId int,
p_folderid int,
p_campaignId varchar(100)
)
Begin
	declare v_errcode int default -1;
    declare v_errmsg varchar(50) default 'Failure';
    
    call Split(p_campaignId,',');
    
     drop temporary table if exists tt_camp_id;
     create temporary table tt_camp_id ( id int auto_increment primary key, campaignId int );     
     
     insert into tt_camp_id(campaignId)    select items from tt_Split_temptable;
     
     
     if exists(select 1 from ec_campaign_folder_list where  domainId = p_domainId and folderid = p_folderid) then
		delete from ec_campaign_folder_list where  domainId = p_domainId and folderid = p_folderid;
     End if;
    
		insert into ec_campaign_folder_list(domainId, folderid, campaignId)
        select p_domainId,p_folderid,campaignId from tt_camp_id;
        
        if row_Count()>0 then
			set v_errcode = 0;
            set v_errmsg = 'Campaign moved to folder created';
        End if;
    
	select v_errcode as errcode, v_errmsg as errmsg; 
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ec_insert_update_folder_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ec_insert_update_folder_dtl`(
	p_folderid int,
	p_domainId int,
	p_folderName varchar(150),
	p_createdBy varchar(100)
)
Begin
	declare v_errcode int default -1;
    declare v_errmsg varchar(50) default 'Failure';
    declare v_folder_id int;
    
    select folderid into v_folder_id from ec_folder_dtl where domainId = p_domainId and folderid = p_folderid;
    
    if v_folder_id is null then
		insert into ec_folder_dtl(domainId, folderName, createdBy)
        values(p_domainId, p_folderName, p_createdBy);
        
        if row_count()>0 then
			set v_errcode = 0;
            set v_errmsg = 'Folder created';
        End if;
    else
		update ec_folder_dtl
        set folderName = ifnull(p_folderName,folderName),
			updatedAt = now()
        where domainId = p_domainId and folderid = p_folderid;

        if row_count()>0 then
			set v_errcode = 0;
            set v_errmsg = 'Folder Updated';
        End if;
    End if;
    
    select v_errcode as errcode, v_errmsg as errmsg;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ec_updateCampaignIssentDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ec_updateCampaignIssentDtl`(
	p_id 		TEXT,
	p_isSent	TINYINT
)
BEGIN
		DECLARE v_errMsg				VARCHAR(50) DEFAULT "Failed";
        DECLARE v_errCode				INT DEFAULT -1;
        DECLARE v_isSent				TINYINT	;
        DECLARE v_campaignChatId		VARCHAR(300);
        DECLARE v_domainId				INT;
        DECLARE v_userId				INT;
        DECLARE v_isIndivCamp			TINYINT;
        DECLARE v_createdOn				DATETIME DEFAULT NOW();
        
        DECLARE EXIT HANDLER FOR SQLEXCEPTION
			BEGIN
					SELECT 	v_errMsg AS errMsg, v_errCode AS errCode;
					ROLLBACK;
			END;
                
        SET v_isSent = IFNULL(p_isSent, 0);
        
        DROP TEMPORARY TABLE IF EXISTS tt_Ids;
        CREATE TEMPORARY TABLE tt_Ids(id	int);
        
        CALL Split(p_id,',');        
        
        INSERT INTO tt_Ids(id)
        SELECT items FROM tt_Split_temptable;
        
        START TRANSACTION;
        
		UPDATE 	ec_campaign_contacts_dtl	CC
		JOIN 	tt_Ids						t_I	ON t_I.id = CC.id
		SET 	isSent 	= v_isSent;
		
		IF ROW_COUNT() > 0 THEN 		
		
				SELECT t1.domainId, t2.id ,  t3.campaignchatid,  isIndivCamp INTO v_domainId, v_userId, v_campaignChatId, v_isIndivCamp
					FROM ec_campaign_contacts_dtl 			t1
						JOIN wc_user_contact_dtl			t2				ON t1.contactEmail = t2.email 		AND t1.domainId = t2.domainId	  
                        JOIN ec_email_campaign_master_dtl 	t3 				ON t3.campaignId = t1.campaignId 	AND t3.domainId = t1.domainId
					WHERE t1.id = p_id ;
            
           
            
            IF v_isIndivCamp !=2 THEN
            
				INSERT INTO Email_tb_indiv_user_click_open_cnt_dtl(domainId, campaignChatId, userID, actionId, createdOn)values(v_domainId, v_campaignChatId, v_userId, 1, v_createdOn);
                
                IF ROW_COUNT() > 0 THEN 
                    SET v_errMsg = "Updated Successfully";
                    SET v_errCode = 1;	
                END IF;
                
			ELSE
            
                
                INSERT INTO Email_tb_indiv_admin_action_dtl(domainId, campaignChatId, userID, actionId, createdOn)
                                             VALUES(v_domainId, v_campaignChatId, v_userId, 1,  v_createdOn);
                
				IF ROW_COUNT() > 0 THEN 
                    SET v_errMsg = "Updated Successfully";
                    SET v_errCode = 1;	
                END IF;
			END IF;
            
		END IF;
		COMMIT;
        SELECT v_errCode as errCode, v_errMsg as errMsg;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ec_update_campaign_contacts_templates` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ec_update_campaign_contacts_templates`(
	 p_domainId 	INT,
	 p_campaignId	INT,
	 p_Template		VARCHAR(2)
 )
BEGIN
 	DECLARE v_errcode 		INT DEFAULT - 1;
	DECLARE v_errmsg 		VARCHAR(50) DEFAULT 'No Update';
    
	UPDATE 	ec_campaign_contacts_dtl
    SET 	Template	= p_Template
	WHERE 	domainId	= p_domainId
	AND 	campaignId	= p_campaignId
    AND 	Template	IS NULL; 
    
	IF ROW_COUNT() > 0 THEN
		SET v_errcode = 0;
		SET v_errmsg = 'Templates updated successfully';
	END IF;
    
    SELECT v_errcode AS errcode, v_errmsg AS errmsg;
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ec_update_campaign_email_sent_status` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ec_update_campaign_email_sent_status`(
p_domainId int,
p_campaignId int,
p_contactEmail json,
p_isSent tinyint,
p_templateType char(1) 
)
begin
	declare v_errcode int default - 1;
    declare v_errmsg varchar(50) default 'Failure';
    
    sp_exit:begin
		if exists(select 1 from ec_campaign_contacts_dtl where domainId = p_domainId and campaignId = p_campaignId limit 1) then
			set v_errcode = -1;
			set v_errmsg = 'campaignId not available';
			leave sp_exit;
		End if;
        
        drop temporary table if exists tt_json_con;
        create temporary table tt_json_con(
        id int auto_increment primary key,
        contactEmail varchar(100)
        );
        
		insert into tt_json_con(contactEmail)
        select * from json_table(p_contactEmail, '$[*]' columns(
			contactEmail varchar(100) path '$.email'
        )) as tm;
        
        update ec_campaign_contacts_dtl a 
        join tt_json_con b on a.contactEmail = b.contactEmail        
        set isSent = p_isSent,
			templateType = p_templateType
        where domainId = p_domainId and campaignId = p_campaignId;
        
        if row_count()>0 then
			set v_errcode = -1;
			set v_errmsg = 'Email updated';
         End if;
        
	end;
     select v_errcode as errcode, v_errmsg as errmsg;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ec_update_campaign_template` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `ec_update_campaign_template`()
BEGIN
  	DROP TEMPORARY TABLE IF EXISTS tt_campaign;
  	CREATE TEMPORARY TABLE tt_campaign(
  		campaignId 			INT,
  		AB_testing			TINYINT,
  		winningCriteria		TINYINT,
  		Template			VARCHAR(2)
  	);
  
  	INSERT INTO tt_campaign(campaignId,AB_testing,winningCriteria)
  	SELECT 	DISTINCT
  			c.campaignId 
  		,	c.AB_testing
  		,	AB.winningCriteria		
  	FROM 	ec_campaign_contacts_dtl  			cc
  	JOIN 	ec_email_campaign_master_dtl		c	ON c.campaignId		= cc.campaignId											
  	LEFT JOIN ec_email_campaign_AB_testing_dtl	AB	ON AB.campaignId	= c.campaignId
  	WHERE 	cc.Template		IS NULL
  	AND 	(AB.examineTime	<= 	DATE_FORMAT(NOW(), '%Y-%m-%d %H:%i:00') OR AB.campaignId IS NULL);
  
	set session  sql_safe_updates = 0;
  
  	UPDATE 	tt_campaign	t_c
  	SET 	t_c.Template	= 'A'
  	WHERE 	t_c.AB_testing 	= 0;
  
  	UPDATE 	tt_campaign				t_c
  	JOIN 	ec_OverallOpenRateDtl	O	ON O.campaignId = t_c.campaignId
  	SET 	t_c.Template		= CASE 	WHEN uniqueOpenA < uniqueOpenB THEN 'B' ELSE 'A' END
  	WHERE 	t_c.winningCriteria = 1;	 
  
  	UPDATE 	tt_campaign				t_c
  	JOIN 	ec_OverallClickRateDtl	C	ON C.campaignId = t_c.campaignId
  	SET 	t_c.Template		= CASE 	WHEN uniqueClickA < uniqueClickB THEN 'B' ELSE 'A' END
  	WHERE 	t_c.winningCriteria = 2;	 
  
  	UPDATE 	ec_campaign_contacts_dtl	cc
  	JOIN 	tt_campaign					t_c	ON 	t_c.campaignId 	= cc.campaignId
  											AND cc.Template		IS NULL
  	SET 	cc.Template	= IFNULL(t_c.Template,'A')
    WHERE 	1 = 1;
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `inApp_getCronDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `inApp_getCronDtl`()
BEGIN
  		
          DECLARE v_currentDate		DATETIME;
          
          
          SET v_currentDate	=  cast(CONVERT_TZ(NOW(), "+00:00", "+05:30") as datetime);
          
         
         
         DROP TEMPORARY TABLE IF EXISTS tt_inAppCroneDtl;
  		CREATE TEMPORARY TABLE tt_inAppCroneDtl
         
         SELECT t1.* 
  		FROM inApp_campaign_master_dtl t1
          JOIN inApp_campaign_schedule_dtl t2 						ON t1.id = t2.campaignId
          LEFT JOIN wc_master_revert_status_details t3 				ON  t1.campaignChatId = t3.campaignchatId
          WHERE t2.triggerType != 0
          AND t2.cronStatus = 0
          AND t3.campaignchatId IS NULL
          AND cast(date_format(t2.scheduleFromDate, "%Y-%m-%d %H:%i:00") as datetime) <= v_currentDate;
          
          
          SELECT * FROM tt_inAppCroneDtl;
          
          UPDATE tt_inAppCroneDtl t1 
          JOIN inApp_campaign_schedule_dtl t2 ON t1.id = t2.campaignId
          SET t2.cronStatus = 1;
  			
          DROP TEMPORARY TABLE tt_inAppCroneDtl;
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `inApp_getMasterCampaignDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `inApp_getMasterCampaignDtl`(
	p_id									INT,
	p_domainId								INT
)
BEGIN
		
        SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        
        SELECT t1.id, t1.campaignName, t1.`Status`, t1.createdOn , t2.scheduleFromDate as publishedDate
			FROM inApp_campaign_master_dtl t1
				JOIN inApp_campaign_schedule_dtl t2 ON t1.id = t2.campaignId
			WHERE (t1.id = p_id OR IFNULL(p_id, '') = '') AND t1.domainId = p_domainId
            ORDER BY t1.createdOn DESC;
        
		SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `inApp_getSearchHistoryDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `inApp_getSearchHistoryDtl`(
		p_domainId			INT
)
BEGIN

		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        
			SELECT domainId, searchDetails 
				FROM inApp_SearchHistoryDtl WHERE domainId = p_domainId;
                
                
		SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `inApp_InsertMasterCampaignDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `inApp_InsertMasterCampaignDtl`(
	p_domainId								INT,
	p_campaignName							VARCHAR(250),
    p_campaignGoal							VARCHAR(250),
    p_industryType							VARCHAR(250),
    p_objective								VARCHAR(400),
    p_urlDtl								VARCHAR(250),
    p_scheduleType							SMALLINT, 
    p_targetAudienceType					INT,
    p_contactDtl							JSON,
    p_TemplateDtl							JSON,
    p_scheduleFromDate						DATETIME,
	p_scheduleToDate						DATETIME,	
    p_Status								VARCHAR(50),
    p_ImgUrl								VARCHAR(350),
    p_deviceDtl								JSON,
    p_sourceDtl								VARCHAR(15),
    p_historyDtl							JSON
)
BEGIN
			DECLARE v_errCode			INT DEFAULT -1;
            DECLARE v_errMsg			VARCHAR(50) DEFAULT "Failed to Insert";
            DECLARE v_InsertId			INT;
            
            DECLARE EXIT HANDLER FOR SQLEXCEPTION
            BEGIN
					SELECT v_errCode AS errCode, v_errMsg AS errMsg;
                    
					ROLLBACK;
            END;
            
            START TRANSACTION;
            
            INSERT INTO inApp_campaign_master_dtl
            (domainId, campaignName , campaignGoal, industryType, objective, urlDtl, scheduleType, targetAudienceType, contactDtl, 
            TemplateDtl, `Status`, ImgUrl, deviceDtl, sourceDtl)
            VALUES
            (p_domainId, p_campaignName , p_campaignGoal, p_industryType, p_objective, p_urlDtl, p_scheduleType, p_targetAudienceType,
				p_contactDtl, p_TemplateDtl, p_Status, p_ImgUrl, p_deviceDtl, p_sourceDtl);
	
            IF ROW_COUNT() > 0 THEN 
            
				SET v_InsertId = last_insert_id();
                
                INSERT INTO inApp_campaign_schedule_dtl(campaignId, triggerType, scheduleFromDate, scheduleToDate)
                VALUES(v_InsertId, p_scheduleType, IFNULL(p_scheduleFromDate, NOW()), p_scheduleToDate);
                
                IF ROW_COUNT() > 0 THEN 
                
					INSERT INTO inApp_campaignHistoryDtl(domainId, campaignId, campaignName, historyDtl)
					VALUES(p_domainId,v_InsertId, p_campaignName, p_historyDtl);
					
					
                   IF ROW_COUNT() > 0 THEN   
					
                    COMMIT;
                    SET v_errCode = 1;
					SET v_errMsg = "Inserted Successfully";
                    
					END IF;
			 END IF;
                
            END IF;
            
            SELECT v_errCode AS errCode, v_errMsg AS errMsg;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `inApp_InsertUpdateMasterCampaignDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `inApp_InsertUpdateMasterCampaignDtl`(
 	p_id									INT,
 	p_domainId								INT,
 	p_campaignName							VARCHAR(300),
     p_campaignGoal							TEXT,
     p_industryType							VARCHAR(150),
     p_objective								TEXT,
     p_urlDtl								VARCHAR(150),
     p_scheduleType							SMALLINT,
     p_targetAudienceType					INT,
     p_contactDtl							JSON,
     p_TemplateDtl							JSON,
     p_status								VARCHAR(50),
 	p_publishedDate							DATETIME
 )
BEGIN
 
		DECLARE v_errCode	INT DEFAULT -1;
		DECLARE v_errMsg	VARCHAR(50) DEFAULT "Failed to Insert";
        DECLARE v_id		INT;
          
          IF p_id IS NULL THEN 
 				
                 INSERT INTO inApp_campaign_master_dtl
 				(domainId, campaignName , campaignGoal, industryType, objective, urlDtl, scheduleType, targetAudienceType, contactDtl, TemplateDtl, `Status`, publishedDate	)
 				VALUES
 				(p_domainId, p_campaignName , p_campaignGoal, p_industryType, p_objective, p_urlDtl, p_scheduleType, p_targetAudienceType,
 					p_contactDtl, p_TemplateDtl,   p_status, p_publishedDate);
                    
				set v_id = last_insert_id();
 		
 				IF ROW_COUNT() > 0 THEN          
 					SET v_errCode = 1;
 					SET v_errMsg = "Inserted Successfully";
 				END IF;
                 
 		  ELSE 
 				UPDATE inApp_campaign_master_dtl
 					SET campaignName 			= IFNULL(p_campaignName, campaignName), 
                         campaignGoal 			= IFNULL(p_campaignGoal, campaignGoal), 
                         industryType 			= IFNULL(p_industryType, industryType), 
                         objective 				= IFNULL(p_objective, objective), 
                         urlDtl					= IFNULL(p_urlDtl, urlDtl), 
                         scheduleType			= IFNULL(p_scheduleType, scheduleType), 
                         targetAudienceType		= IFNULL(p_targetAudienceType, targetAudienceType), 
                         contactDtl				= IFNULL(p_contactDtl, contactDtl), 
                         TemplateDtl				= IFNULL(p_TemplateDtl, TemplateDtl), 
                         `Status`				= IFNULL(p_status, `Status`), 
                         publishedDate			= IFNULL(p_publishedDate, publishedDate)
 				WHERE id = p_id AND domainId = p_domainId;
                 
                 IF ROW_COUNT() > 0 THEN
 					SET v_errCode = 2;
 					SET v_errMsg = "Updated Successfully";
                 END IF;
 		
           END IF;  
           
             SELECT v_errCode AS errCode, v_errMsg AS errMsg;
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `inApp_insertUpdateSearchHistoryDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `inApp_insertUpdateSearchHistoryDtl`(
		p_domainId			INT,
        p_searchDetails		LONGTEXT
)
BEGIN
				DECLARE v_errCode		SMALLINT DEFAULT -1;
                DECLARE v_errMsg		VARCHAR(50) DEFAULT "Failed";
                DECLARE v_id			INT;
			
			IF NOT EXISTS(SELECT 1 FROM inApp_SearchHistoryDtl WHERE domainId = p_domainId) THEN
				
               INSERT INTO inApp_SearchHistoryDtl(domainId, searchDetails) VALUES(p_domainId, p_searchDetails);
               
               IF ROW_COUNT() > 0 THEN 
					SET v_errCode = 0;
                    SET v_errMsg = "Inserted Successfully";
               END IF;
               
            ELSE
					SELECT id INTO v_id FROM inApp_SearchHistoryDtl WHERE domainId = p_domainId;
                    
                    UPDATE inApp_SearchHistoryDtl
                    SET searchDetails = p_searchDetails
                    WHERE id = v_id and domainId = p_domainId;
                    
                    IF ROW_COUNT() > 0 THEN 
					
                    SET v_errCode = 1;
                    SET v_errMsg = "Updated Successfully";
                    
					END IF;
                    
                    
            END IF; 
            
            SELECT v_errCode AS errCode , v_errMsg AS errMsg;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `inApp_UpdateCampaignUserStatusDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `inApp_UpdateCampaignUserStatusDtl`(
p_domainId int,
p_campaignId INT,
p_sip_log_id bigint,
p_status int
 )
Begin
 			declare v_errcode int default -1;
 			declare v_errmsg varchar(50) default 'Not found';
 			
 			DECLARE EXIT HANDLER FOR SQLEXCEPTION                   
 			BEGIN
 				GET DIAGNOSTICS CONDITION 1 @st = RETURNED_SQLSTATE, @p2 =  MESSAGE_TEXT;
 				set v_errmsg =  CONCAT(@st, ' : ', @p2);
 				set  @st='';
 				select v_errcode as errcode, v_errmsg as errmsg;
 				ROLLBACK;
 			END;
 			
 			START TRANSACTION;
					update inApp_campaign_contacts_dtl
					set isSent = p_status,
						deliveryTime = now()
					where domainId = p_domainId and campaignId = p_campaignId and sip_log_id = p_sip_log_id;
 				
 				if row_Count()>0 then
 					set v_errcode = 0;
 					set v_errmsg = 'Updated';
 				End if;
 
 			COMMIT;
 			
 				select v_errcode as errcode, v_errmsg as errmsg;
 	End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `inApp_UpdateIsSentStatus` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `inApp_UpdateIsSentStatus`(p_domainId		INT,
 p_sip_log_id	INT,
 p_campaignId	varchar(1000)
)
SP:BEGIN
			DECLARE v_errMsg		varchar(50) default "failed";
            DECLARE v_errCode		INT default -1;
            
            call split(p_campaignId, ",");
            
            DROP TEMPORARY TABLE IF EXISTS tt_inAppUpdateIsSentStatus;
            CREATE TEMPORARY TABLE tt_inAppUpdateIsSentStatus
            select tt1.items, t2.domainId , t2.sip_log_id  as sip_log_id  , t2.id  
				FROM tt_Split_temptable tt1
                join inApp_campaign_contacts_dtl t2 ON tt1.items = t2.campaignId 
                where  t2.domainId = p_domainId and t2.sip_log_id = p_sip_log_id;
            
            
            IF EXISTS( select 1	from tt_inAppUpdateIsSentStatus) THEN 
						
                        UPDATE inApp_campaign_contacts_dtl t1 JOIN 
								tt_inAppUpdateIsSentStatus tt2  ON t1.id = tt2.id
                                SET t1.isSent = 1;
                               
                               
						IF row_count() > 0 THEN
								
                                SET v_errMsg = "Updated Successfully...";
                                SET v_errCode = 1;
                        
                        END IF;
 

            END IF;
    
		SELECT v_errCode as errCode,  v_errMsg as errMsg;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sc_createSMSCampaignDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sc_createSMSCampaignDtl`(
  p_domainId							INT,
  p_name								VARCHAR(250),	
  P_targetAudienceType					INT,
  p_senderName							VARCHAR(250),
  p_templatePrompt						TEXT,
  p_triggerType							INT,			
  p_schedulefromDate					DATETIME,
  p_scheduletoDate						DATETIME,
  p_status								VARCHAR(100),
  p_contactDtls							JSON,
  p_campaignGoal						VARCHAR(250),
  p_campaignObjective					VARCHAR(400),
  p_websiteURL							VARCHAR(250),
  p_campaignchatid						VARCHAR(300)
  )
SP: BEGIN
  				 DECLARE flag1 			TINYINT			DEFAULT 0;
                  DECLARE flag2 			TINYINT			DEFAULT 0;
                  DECLARE v_newInserted		INT				;
                  DECLARE	v_errCode		TINYINT			DEFAULT -1;
                  DECLARE	v_errMsg		VARCHAR(50)		DEFAULT "Failed";
              
					IF p_campaignchatid IS NULL THEN 
						SELECT v_errCode AS v_errCode, v_errMsg AS v_errMsg;
						LEAVE SP;
					END IF;
  						
  					INSERT INTO sc_campaign_master_dtl (domainId, `name`, targetAudienceType , 
  						 senderName, templatePrompt, triggerType, `status`, contactDtls, campaignGoal, campaignObjective, 
                           websiteURL, campaignchatid) 
                      VALUES( p_domainId, p_name, p_targetAudienceType, 
  								p_senderName, p_templatePrompt,  p_triggerType,   p_status, p_contactDtls
                                  ,p_campaignGoal, p_campaignObjective, p_websiteURL, p_campaignchatid);
  							
  					IF ROW_COUNT() > 0 THEN 
  							SET v_newInserted = last_insert_id();
                              SET flag1 =1; 
                             
  			
  								IF	p_triggerType IN (0, 1) THEN
  									
                                      INSERT INTO sc_campaign_master_schedule_dtl (domainId, campaignId, schedulefromDate )
  										VALUES(p_domainId, v_newInserted, IFNULL(p_schedulefromDate, now()));
  							
  								ELSE
                                  
                                      INSERT INTO sc_campaign_master_schedule_dtl (domainId, campaignId, schedulefromDate, scheduletoDate )
  										VALUES(p_domainId, v_newInserted, p_schedulefromDate, p_scheduletoDate);
                                          
  								END IF;
                                  
                                  IF ROW_COUNT() > 0 THEN 
  									SET flag2 =1;
  										
                                          IF flag2 =1 AND flag1 =1 THEN
  											SET v_errCode = 1;
                                              SET v_errMsg = "Inserted Successfully";
                                          END IF;
                                          
  								END IF;
  				END IF; 
          
          SELECT v_errCode AS errCode, v_errMsg AS errMsg;
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sc_deleteSMSCampaignDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sc_deleteSMSCampaignDtl`(
	p_domainId			INT,
	p_id				INT
)
BEGIN
			DECLARE v_flag1 TINYINT DEFAULT 0;
            DECLARE v_errMsg VARCHAR(50) DEFAULT "failed";
            DECLARE v_errCode INT DEFAULT -1;
            
		
        IF EXISTS(SELECT 1 FROM sc_campaign_master_dtl WHERE id = p_id AND domainId = p_domainId) THEN
				
                DELETE FROM sc_campaign_master_dtl WHERE id = p_id AND domainId = p_domainId;
                
                IF ROW_COUNT() > 0 THEN
						
                        SET v_flag1 = 1;
                        
						DELETE FROM sc_campaign_master_schedule_dtl WHERE campaignId = p_id  AND domainId = p_domainId;
                        
                        IF ROW_COUNT() > 0 THEN
							
									IF (v_flag1 = 1) THEN
										
                                        SET v_errMsg = "Deleted Successfully";
                                        
                                        SET v_errCode = 1;
                                    
                                    END IF;
						END IF;
				END IF;
        END IF;
        
        
		SELECT  v_errCode as errCode, v_errMsg as errMsg;
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sc_getCroneForSMSCampDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sc_getCroneForSMSCampDtl`()
BEGIN
 		DECLARE v_currentDateTime DATETIME DEFAULT now();
         
        SET v_currentDateTime = CAST(DATE_FORMAT(CONVERT_TZ(v_currentDateTime, '+00:00', '+05:12'), "%y-%m-%d %h:%m:00") AS DATETIME);
        
      
 	
         DROP TEMPORARY TABLE IF EXISTS tt_CroneForSMSCampDtl;
         CREATE TEMPORARY TABLE tt_CroneForSMSCampDtl
         SELECT t1.campaignId, t1.domainId, t1.id 
			FROM sc_campaign_master_schedule_dtl t1
 			JOIN sc_campaign_master_dtl t2 ON t1.campaignId = t2.id
            LEFT JOIN wc_master_revert_status_details t3 ON t2.campaignchatid = t3.campaignchatid 
         WHERE t2.triggerType = 1 
 			AND IFNULL(sentStatus, 0) != 1 
			AND CAST(DATE_FORMAT(t1.schedulefromDate,"%y-%m-%d %h:%m:00") AS DATETIME) <= v_currentDateTime
			AND t3.campaignchatId IS NULL;
 			
         
         SELECT * FROM sc_campaign_master_dtl t1
         JOIN tt_CroneForSMSCampDtl t2 ON t1.id= t2.campaignId;
         
         UPDATE sc_campaign_master_schedule_dtl t1
         JOIN tt_CroneForSMSCampDtl t2 ON t1.id = t2.id
         SET t1.sentStatus = 1;
         
 
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sc_getSearchHistoryDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sc_getSearchHistoryDtl`(
		p_domainId			INT
)
BEGIN

		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        
			SELECT domainId, searchDetails 
				FROM sc_SMSsearchHistoryDtl WHERE domainId = p_domainId;
                
                
		SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sc_getSMSCampaignDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sc_getSMSCampaignDtl`(p_domainId		INT)
BEGIN
			
            SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
            
            SELECT t1.id, t1.`name`, t1.`status`, t1.createdDate, t1.updateddate , t2.schedulefromDate as publishDate
            FROM sc_campaign_master_dtl t1
            JOIN sc_campaign_master_schedule_dtl t2 ON t2.campaignId = t1.id
            WHERE t1.domainId = p_domainId
            order by t1.createdDate desc
            ;
            
            SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sc_getSMSConfigDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sc_getSMSConfigDtl`(p_domainId				INT)
BEGIN
			SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
				
                
		 select domainId, senderNumber, aliasName, senderId, SMSEnable, SMSBot
          FROM sc_SMSConfigDtl
				WHERE domainId = p_domainId;
  
            SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sc_getSMSTagDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sc_getSMSTagDtl`(p_domainId INT)
BEGIN
	SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
		
        SELECT  Tags
			FROM  sc_SMScampaignTagDtl WHERE domainId = p_domainId;
        
	SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sc_get_smsconfig_isenable_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sc_get_smsconfig_isenable_dtl`(p_domainId				INT)
BEGIN
  			SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
  				
                  
  		 select domainId, senderNumber, aliasName, senderId, SMSEnable, SMSBot
            FROM sc_SMSConfigDtl
  				WHERE domainId = p_domainId AND SMSEnable = 1;
    
              SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sc_get_SMS_sent_status_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sc_get_SMS_sent_status_details`(	
 	p_domainId						INT		,
  	p_campaignChatId				VARCHAR(300)
 )
BEGIN
 		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
 			
             
             SELECT domainId, campaignChatId, fromMobileNo, toMobileNo, `status`, createdOn
             FROM sc_SMS_sent_status_details 
 				WHERE domainId = p_domainId AND campaignChatId = p_campaignChatId;
 
 		SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sc_insertUpdateSearchHistoryDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sc_insertUpdateSearchHistoryDtl`(
		p_domainId			INT,
        p_searchDetails		LONGTEXT
)
BEGIN
				DECLARE v_errCode		SMALLINT DEFAULT -1;
                DECLARE v_errMsg		VARCHAR(50) DEFAULT "Failed";
                DECLARE v_id			INT;
			
			IF NOT EXISTS(SELECT 1 FROM sc_SMSsearchHistoryDtl WHERE domainId = p_domainId) THEN
				
               INSERT INTO sc_SMSsearchHistoryDtl(domainId, searchDetails) VALUES(p_domainId, p_searchDetails);
               
               IF ROW_COUNT() > 0 THEN 
					SET v_errCode = 0;
                    SET v_errMsg = "Inserted Successfully";
               END IF;
               
            ELSE
					SELECT id INTO v_id FROM sc_SMSsearchHistoryDtl WHERE domainId = p_domainId;
                    
                    UPDATE sc_SMSsearchHistoryDtl
                    SET searchDetails = p_searchDetails
                    WHERE id = v_id and domainId = p_domainId;
                    
                    IF ROW_COUNT() > 0 THEN 
					
                    SET v_errCode = 1;
                    SET v_errMsg = "Updated Successfully";
                    
					END IF;
                    
                    
            END IF; 
            
            SELECT v_errCode AS errCode , v_errMsg AS errMsg;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sc_insert_SMS_sent_status_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sc_insert_SMS_sent_status_details`(	
     	p_domainId						INT		,
      	p_campaignChatId				VARCHAR(300),
      	p_fromMobileNo					VARCHAR(20),			
      	p_toMobileNo					VARCHAR(20),
      	p_status						VARCHAR(50),
        p_messageId					VARCHAR(100),
        p_description					VARCHAR(800),
        p_bulkId						VARCHAR(100)
      )
BEGIN
      		
              DECLARE  v_errCode				TINYINT  		DEFAULT -1;
              DECLARE  v_errMsg					VARCHAR(50)  	DEFAULT "Failed";
              DECLARE 	v_userID				INT;	
              DECLARE  v_actionId				INT DEFAULT 5;
              DECLARE  v_currentDate			DATETIME		DEFAULT NOW();
              DECLARE  v_fromMobileNo			VARCHAR(20);			
              
              
              DECLARE EXIT HANDLER FOR SQLEXCEPTION
              BEGIN
   				
                   SELECT v_errCode AS errCode, v_errMsg AS errMsg;
   				ROLLBACK;
              
              END;
              
              -- ============================================================
              --  				Extracting the paticular user id 
              -- ============================================================
      		
   			SELECT id INTO v_userID FROM wc_user_contact_dtl WHERE phoneNumber = p_toMobileNo AND domainId = p_domainId;
            
            IF 	p_fromMobileNo IS NULL THEN
				select senderNumber INTO v_fromMobileNo  FROM sc_SMSConfigDtl where domainId = p_domainId and SMSEnable = 1;
			END IF;	
            
             
             -- ===================================================================
             
               IF p_status = "DELIVERED" THEN 
   			    SET v_actionId = 2;
			  ELSEIF p_status = "CLICK" THEN
				SET v_actionId = 4;
 			END IF;
           
           START TRANSACTION;
           
           -- ==========================================================
           
 		IF EXISTS(SELECT 1 FROM sc_campaign_master_dtl WHERE domainId = p_domainId and campaignchatid = p_campaignChatId) THEN 
             
      		INSERT INTO sc_SMS_sent_status_details(domainId, campaignChatId, fromMobileNo, toMobileNo, `status`, messageId, `description` ,bulkId, sentAt)
 			VALUES(p_domainId, p_campaignChatId, IFNULL(p_fromMobileNo, v_fromMobileNo), p_toMobileNo, p_status, p_messageId, p_description, p_bulkId, v_currentDate);
          
          IF ROW_COUNT() > 0 THEN 
 						
   						SET v_errCode = 0;
   						SET v_errMsg = 'Inserted Successfully';
                         
			END IF;
          
		END IF;
 			-- ==============================================
             
               IF v_userID IS NOT NULL THEN 
   				
 					INSERT INTO sms_tb_indiv_user_click_open_cnt_dtl(domainId, campaignChatId, userID, actionId, createdOn) 
   						VALUES(p_domainId, p_campaignChatId, v_userID, v_actionId, v_currentDate);
   
            END IF;
            
			  COMMIT;
              SELECT v_errCode as errCode, v_errMsg as errMsg;
      		
      END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sc_updateSMSConfigDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sc_updateSMSConfigDtl`(
	p_domainId				INT,
	p_senderNumber			VARCHAR(20),
    p_aliasName				VARCHAR(150),
    p_senderId				VARCHAR(150),
    p_SMSEnable				TINYINT,
    p_SMSBot				TINYINT
)
BEGIN			
				DECLARE v_errMsg		VARCHAR(50) DEFAULT "failed to Update";
                DECLARE v_errCode		SMALLINT	DEFAULT -1;
			
			
            IF EXISTS ( SELECT 1 FROM sc_SMSConfigDtl WHERE senderNumber = p_senderNumber AND domainId = p_domainId) THEN 
					
					UPDATE sc_SMSConfigDtl
                    SET aliasName 		= IFNULL(p_aliasName, aliasName),
						senderId 		= IFNULL(p_senderId, senderId),
                        SMSEnable 		= IFNULL(p_SMSEnable, SMSEnable),
						SMSBot 			= IFNULL(p_SMSBot, SMSBot)
					WHERE senderNumber = p_senderNumber AND domainId = p_domainId;
                    
                    IF ROW_COUNT() > 0 THEN 
						SET v_errMsg 		= "Updated Successfully";
                        SET v_errCode 		= 1;
                        
                    END IF;
            END IF;
            
	 SELECT v_errCode as errCode,  v_errMsg as errMsg;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Split` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `Split`(v_String VARCHAR(8000), v_Delimiter CHAR(1))
SWL_return:
 begin
 
      
    DECLARE v_idx INT;     
    DECLARE v_slice VARCHAR(8000);     
 
    DROP TEMPORARY TABLE IF EXISTS tt_Split_temptable;
    CREATE TEMPORARY TABLE IF NOT EXISTS tt_Split_temptable
    (
       items VARCHAR(8000)
    );
    SET v_idx = 1;     
    if  CHAR_LENGTH(v_String) < 1 or v_String is null then  
       LEAVE SWL_return;
    end if;     
 
    SWL_Label:
    while v_idx != 0 DO
       set v_idx = LOCATE(v_Delimiter,v_String);
       if v_idx != 0 then
          set v_slice = left(v_String,v_idx -1);
       else
          set v_slice = v_String;
       end if;
       if( CHAR_LENGTH(v_slice) > 0) then
          insert into tt_Split_temptable(Items) values(v_slice);
       end if;
       set v_String = right(v_String, CHAR_LENGTH(v_String) -v_idx);
       if  CHAR_LENGTH(v_String) = 0 then 
          LEAVE SWL_Label;
       end if;
    END WHILE; 
    LEAVE SWL_return;     
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_delete_knowledge_base_folder_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sp_delete_knowledge_base_folder_dtl`(
     IN p_id               INT,
     IN p_domainId         INT)
SP:BEGIN
     DECLARE v_errCode  INT DEFAULT 0;
     DECLARE v_errMsg   VARCHAR(100) DEFAULT 'Failed';
     DECLARE v_insertId INT DEFAULT 0;
 
 
 	IF p_domainId IS NULL THEN
 				SET v_errCode = 3;
 				SET v_errMsg  = 'domainId is mandatory';
 	END IF;
 
 
     /* DELETE */
     IF p_id IS not NULL THEN
 
         delete from tb_campaign_knowledge_base_folder_dtl where kbFolderId = p_id and domainId = p_domainId;
 		 
         IF ROW_COUNT() > 0 THEN
             SET v_errCode = 1;
             SET v_errMsg  = 'Deleted Successfully';
         END IF;
  
     END IF;
 
     SELECT v_errCode AS errCode, v_errMsg AS errMsg;
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_exclude_email` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sp_exclude_email`(in p_contactEmail json,
       OUT o_existing_email_json JSON,
       OUT o_excluded_email_json JSON
   )
BEGIN
       DECLARE v_cnt INT DEFAULT 0;
       DECLARE v_cnt_exclude INT DEFAULT 0;
   
       DROP TEMPORARY TABLE IF EXISTS tt_customer_details_excluded_mail;
       CREATE TEMPORARY TABLE tt_customer_details_excluded_mail
       (
           cid INT AUTO_INCREMENT PRIMARY KEY,
           contactEmail VARCHAR(255),
           deliveryTime DATETIME(0)
       );
   
       INSERT INTO tt_customer_details_excluded_mail (contactEmail, deliveryTime)
       SELECT jt.contactEmail, jt.deliveryTime
       FROM JSON_TABLE(p_contactEmail,
           '$[*]' COLUMNS (
               contactEmail VARCHAR(255) PATH '$.contactEmail',
               deliveryTime DATETIME PATH '$.deliveryTime'
           )
       ) jt;
   
       -- Existing emails count
       SELECT COUNT(*) INTO v_cnt FROM tt_customer_details_excluded_mail t WHERE EXISTS ( SELECT 1 FROM wc_user_contact_dtl w WHERE w.email = t.contactEmail);
   
       -- Excluded emails count
       SELECT COUNT(*) INTO v_cnt_exclude FROM tt_customer_details_excluded_mail t WHERE NOT EXISTS ( SELECT 1 FROM wc_user_contact_dtl w WHERE w.email = t.contactEmail );
   
       -- Existing emails JSON
       IF v_cnt > 0 THEN
           SELECT JSON_ARRAYAGG(JSON_OBJECT( 'contactEmail', contactEmail, 'deliveryTime', DATE_FORMAT(deliveryTime,'%Y-%m-%d %H:%i:%s') ) )
           INTO o_existing_email_json
           FROM tt_customer_details_excluded_mail t
           WHERE EXISTS ( SELECT 1 FROM wc_user_contact_dtl w WHERE w.email = t.contactEmail          );
       ELSE
           SET o_existing_email_json = JSON_ARRAY();
       END IF;
   
       -- Excluded emails JSON
       IF v_cnt_exclude > 0 THEN
           SELECT JSON_ARRAYAGG( JSON_OBJECT( 'contactEmail', contactEmail, 'deliveryTime', DATE_FORMAT(deliveryTime,'%Y-%m-%d %H:%i:%s') ) )
           INTO o_excluded_email_json
           FROM tt_customer_details_excluded_mail t
           WHERE NOT EXISTS ( SELECT 1 FROM wc_user_contact_dtl w WHERE w.email = t.contactEmail          );
       ELSE
           SET o_excluded_email_json = JSON_ARRAY();
       END IF;
   
   END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_get_knowledge_base_folder_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sp_get_knowledge_base_folder_dtl`(
       IN p_domainId         INT)
SP:BEGIN
       DECLARE v_errCode  INT DEFAULT 0;
       DECLARE v_errMsg   VARCHAR(100) DEFAULT 'Failed';
    
   
   	IF p_domainId IS NULL THEN
   				SET v_errCode = 3;
   				SET v_errMsg  = 'domainId is mandatory';
   	END IF;
    
   select kbFolderId, domainId, foldername, collection_info from tb_campaign_knowledge_base_folder_dtl where domainId = p_domainId;
   
   END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_get_send_campain_by_user` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sp_get_send_campain_by_user`(in p_email_id varchar(100))
begin


declare v_send_status int;
declare v_open_status int;



SELECT COUNT(send_status) AS send_status INTO v_send_status FROM Sendmail_Status_Tracker_Campaign_Wise_2026_01_27 WHERE send_status = 1 and sender_email_id= p_email_id;
SELECT COUNT(open_status) AS open_status INTO v_open_status FROM Sendmail_Status_Tracker_Campaign_Wise_2026_01_27 WHERE open_status = 1 and sender_email_id= p_email_id;


SELECT v_send_status, v_open_status;


end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_insert_send_campain_by_user` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sp_insert_send_campain_by_user`(in p_email_id varchar(100), in p_campaign_name VARCHAR(100) ,in p_email_subject VARCHAR(100) ,
in p_email_message VARCHAR(50) )
begin

declare done int default 0;

declare v_username varchar(100);
declare v_email varchar(100);

 

DECLARE insert_cursor CURSOR FOR SELECT username,email  FROM Users_2026_01_27 WHERE status = 1 and email not in('a.worktual@gmail.com') ;

DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;
	 
	 

OPEN insert_cursor;
read_loop: LOOP 
FETCH insert_cursor INTO v_username,v_email;

IF done THEN
	LEAVE read_loop;
END IF;
 

insert into Send_Email_To_Customer_2026_01_27 
(sender_email_id ,receiver_email_id ,campaign_name ,email_subject ,email_message ,send_datetime ,status ,createdOn ,updatedOn) values
(p_email_id,v_email,p_campaign_name,p_email_subject,p_email_message,now(),1,now(),now());
 

insert into Sendmail_Status_Tracker_Campaign_Wise_2026_01_27(sender_email_id ,receiver_email_id ,send_status ,open_status ,createdOn ,updatedOn)values
(p_email_id,v_email,1,1,now(),now());

    END LOOP read_loop;
    CLOSE insert_cursor;


 

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_insert_update_knowledge_base_folder_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `sp_insert_update_knowledge_base_folder_dtl`(
      IN p_id               INT,
      IN p_domainId         INT,
      IN p_foldername       VARCHAR(100),
      IN p_collection_info  JSON)
SP:BEGIN
      DECLARE v_errCode  INT DEFAULT 0;
      DECLARE v_errMsg   VARCHAR(100) DEFAULT 'Failed';
      DECLARE v_insertId INT DEFAULT 0;
  
  
  	IF p_domainId IS NULL THEN
  				SET v_errCode = 3;
  				SET v_errMsg  = 'domainId is mandatory';
  	END IF;
  
  
      /* INSERT */
      IF p_id IS NULL THEN
  
          INSERT INTO tb_campaign_knowledge_base_folder_dtl (domainId, foldername, collection_info, createdOn, updatedOn) VALUES
              (p_domainId, p_foldername, p_collection_info, NOW(), NOW());
  
          IF ROW_COUNT() > 0 THEN
              SET v_errCode = 1;
              SET v_errMsg  = 'Inserted Successfully';
              SET v_insertId = LAST_INSERT_ID();
          END IF;
  
      /* UPDATE */
      ELSE
  UPDATE tb_campaign_knowledge_base_folder_dtl
  SET foldername = p_foldername,
      collection_info = JSON_ARRAY_APPEND( IFNULL(collection_info, JSON_ARRAY()), '$', p_collection_info )
  WHERE kbFolderId = p_id   AND domainId   = p_domainId;
  
          IF ROW_COUNT() > 0 THEN
              SET v_errCode = 2;
              SET v_errMsg  = 'Updated Successfully';
              SET v_insertId = p_id;
          END IF;
  
      END IF;
  
      SELECT v_errCode AS errCode, v_errMsg AS errMsg, v_insertId AS insertId;
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `up_connector_install_based_domain` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `up_connector_install_based_domain`(
                p_domainId   INT 
                )
BEGIN
              	SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED ;
    				SELECT a.conid AS conId, a.connector_name, a.imageUrl, b.idcol,
                    b.domainId, b.roleId, b.token, b.contactSyncDetails, 
    				b.syncStatus, b.syncTime, b.contactSyncType, b.isConnected , a.industryType
    				FROM connectors_list a
    				LEFT JOIN crm_connector_token_info b ON a.conid = b.conId AND b.domainId = p_domainId AND b.isConnected = 1
   				WHERE a.isrunning = 1
    				UNION
    				SELECT 
    				a.conid AS conId, a.connector_name, a.imageUrl, b.idcol, 
    				b.domainId, b.roleId, b.token, b.contactSyncDetails, 
    				b.syncStatus, b.syncTime, b.contactSyncType,b.isConnected, a.industryType
    				FROM connectors_list a
    				RIGHT JOIN crm_connector_token_info b ON a.conid = b.conId WHERE b.domainId = p_domainId AND b.isConnected = 1 
                    AND a.isrunning = 1
                    order by conId asc;
                  SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ; 
          END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `up_GetStoreConnection` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `up_GetStoreConnection`(	 
      p_domainId			INT	  
      ,p_conId  			INT)
BEGIN
     	SELECT 	SC.conId
   		,	SC.domainId
   		,	SC.shopDomain 		
   		,	SC.isConnected
   		,	SC.connectionName
   		,	REPLACE(SC.connectorName,'_',' ')	AS connectorName
   		,	SC.token
   		,   SC.syncStatus			
   		,   SC.contactSyncDetails
   		,   SC.pwd        
   		,   SC.userName
   		,	SC.syncTime
   		,	SC.scriptId			
   		,   SC.botData 			
   		,   SC.chatWidgetStatus 	
   		,   SC.contactSyncType
   		,   SC.StoreConnectionId
   		,	SC.settings
     	FROM 	tb_StoreConnection SC
     	WHERE 	domainId= p_domainId
     	AND 	conId   = p_conId
  	AND    isConnected =1;    
   END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `up_insert_update_connectors_list` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `up_insert_update_connectors_list`(
        p_conid          	INT,
        p_connector_name 	VARCHAR(100),
        p_imageUrl		varchar(500),
        p_isrunning		Tinyint,
        p_industryType varchar(50)
   )
BEGIN
       DECLARE v_errcode INT DEFAULT -1;
       DECLARE v_errmsg VARCHAR(55) DEFAULT 'No Record to Config';
       DECLARE v_CurDate DATETIME;
       DECLARE v_conid INT;
   
       SET v_CurDate = NOW();
  	
      select conid into v_conid from connectors_list where conid = p_conid;
   
  	if v_conid is null then
  		INSERT INTO connectors_list (conid,connector_name,imageUrl,createdAt, industryType)
  		VALUES (p_conid,p_connector_name,p_imageUrl,v_CurDate, p_industryType); 
          
  		SET v_conid = LAST_INSERT_ID();
          
          if row_count()>0 then
  			set v_errcode = 0;
              set v_errmsg = 'Connectors list Inserted  successfully';
          End if;
          
       ELSE
  		UPDATE connectors_list
          SET connector_name= ifnull(p_connector_name,connector_name),
  			imageUrl = ifnull(p_imageUrl,imageUrl),
  			isrunning= ifnull(p_isrunning,isrunning),
            industryType = ifnull(p_industryType, industryType)
          WHERE conid = p_conid;
          
          set v_errcode = 0;
  		set v_errmsg = 'Connectors list Updated successfully';
          
       END IF;
   
       SELECT v_errcode AS errCode, v_errmsg AS errMsg;
   END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `up_insert_update_connector_token` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `up_insert_update_connector_token`( 
            p_domainId 				INT, 
            p_roleId 				INT,  
            p_connector_name 		VARCHAR(100),
            p_token 					TEXT,
            p_syncStatus				TINYint,
            p_conId			        INT,        
            p_contactSyncDetails		JSON,
            P_syncTime				BIGINT,
            p_contactSyncType        VARCHAR(100),
            p_isConnected			TINYINT
            )
Begin   
         	DECLARE v_errcode 	INT DEFAULT 1;
         	DECLARE v_errmsg 	VARCHAR(50) DEFAULT 'Failure';
      	    DECLARE v_idcol		INT;
             
         	SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED ;
   		SELECT 	idcol INTO v_idcol 
         	FROM 	crm_connector_token_info                                               
         	WHERE 	domainId 		COLLATE utf8mb4_unicode_ci 	= p_domainId 
         	AND 	connector_name 	COLLATE utf8mb4_unicode_ci  = p_connector_name 
 			AND     isConnected = 1 LIMIT 1;
   		SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;    
   
         	IF v_idcol IS NULL
             THEN		
         		INSERT INTO crm_connector_token_info(domainId,roleId,connector_name,token,contactSyncDetails,createAt,syncStatus,conId,contactSyncType,isConnected)
         		VALUES(p_domainId,p_roleId,p_connector_name,p_token,p_contactSyncDetails,current_timestamp,p_syncStatus,p_conId,p_contactSyncType,p_isConnected);
         
         		SET v_errcode = 0;
         		SET v_errmsg = 'Inserted';
         	ELSE
         		UPDATE 	crm_connector_token_info
         		SET 	token 				= IFNULL(p_token,token),
         				syncStatus 			= IFNULL(p_syncStatus,syncStatus),
   					    syncTime			= IFNULL(p_syncTime,syncTime),
         				contactSyncDetails	= IFNULL(p_contactSyncDetails,contactSyncDetails),
   					    contactSyncType     = IFNULL(p_contactSyncType,contactSyncType),
     					isConnected			= IFNULL(p_isConnected,isConnected),
         				updateAt 			= current_timestamp
         		WHERE 	idcol  = v_idcol ;
                 
         		SET v_errcode = 0;
         		SET v_errmsg = 'Updated';
         	END IF;
            	
            	SELECT v_errcode as errcode,v_errmsg as errmsg;   
         END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `up_insert_update_hubspot_store_connection` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `up_insert_update_hubspot_store_connection`(	 
      	     p_conId					INT
            ,p_domainId					INT	
            ,p_isConnected				TINYINT
            ,p_connectionName			VARCHAR(250)
            ,p_connectorName			VARCHAR(100)
            ,p_syncStatus				tinyint
            ,p_contactSyncDetails		JSON
            ,p_token					VARCHAR(1000)
            ,p_syncTime 				BIGINT
            ,p_contactSyncType          VARCHAR(100)
            ,p_shopDomain				VARCHAR(100)
            ,p_domainName				VARCHAR(150)
            )
BEGIN
      		DECLARE v_StoreConnectionId INT;
    		    DECLARE v_CurDate			DATETIME;
      		DECLARE v_errCode			INT	DEFAULT -1;
      		DECLARE v_errMsg			VARCHAR(150) DEFAULT 'Failed to Insert/Update Store Connection';
                
      		SET v_CurDate =  NOW();
      
      		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED ; 
             SELECT 	StoreConnectionId	INTO v_StoreConnectionId
     		FROM 	tb_StoreConnection
     		WHERE 	conId			= p_conId
     		AND 	domainId		= p_domainId
     		AND 	connectionName	= p_connectionName collate utf8mb4_0900_ai_ci
     		AND  	connectorName	= p_connectorName collate utf8mb4_0900_ai_ci
 			AND     isConnected = 1  ;
             SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
     		
            	IF v_StoreConnectionId IS NULL
            	THEN
     			INSERT INTO tb_StoreConnection
                    (conId
            			,domainId 
                        ,domainName
            			,isConnected
            			,connectionName
        				,connectorName	
    					,syncStatus
    					,contactSyncDetails
    					,token
        				,syncTime
 					,contactSyncType
                    ,shopDomain
            			,createDate
            			,updatedDate)
                    VALUES
                    (	 p_conId				
                         ,p_domainId	
                         ,p_domainName
                         ,p_isConnected		
                         ,p_connectionName	
                         ,p_connectorName		
                         ,p_syncStatus		
                         ,p_contactSyncDetails
                         ,p_token		
                         ,p_syncTime
                         ,p_contactSyncType 
                         , p_shopDomain
                         ,v_CurDate
 						,v_CurDate);        
                       
                       SET 	v_errCode	= 0
      					,	v_errMsg	= 'HubSpot Store Connection Inserted Successfully';	
             ELSE
     			UPDATE 	tb_StoreConnection
                 SET 
                 	    syncStatus 			= IFNULL(p_syncStatus,syncStatus),
   					syncTime			    = IFNULL(p_syncTime,syncTime),
       				contactSyncDetails	    = IFNULL(p_contactSyncDetails,contactSyncDetails),
  					contactsynctype         = IFnull(p_contactsynctype,contactsynctype),  
                      isConnected            = IFNULL(p_isConnected,isConnected),
    				 	updatedDate			    = v_CurDate,
                        shopDomain			= IFNULL(p_shopDomain, shopDomain)
     			WHERE 	StoreConnectionId 	= v_StoreConnectionId;
                 
                   SET 	v_errCode	= 0
     				,	v_errMsg	= 'HubSpot Store Connection Updated Successfully';	
      		END IF;	
     
     		SELECT 	v_errCode AS errCode,v_errMsg AS errMsg;	
     END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_AI_chat_channel_wise_user_count` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_AI_chat_channel_wise_user_count`(p_domainId			INT)
begin
		declare v_totalCount	int;
        declare v_emailCount	int;
        declare v_whatsappCount	int;
        declare v_smsCount		int;
        declare v_AppPushCount	int;
        declare v_WebPushCount	int;

		set session transaction isolation level read uncommitted;
        
        select count(1)	into v_totalCount 		FROM wc_user_contact_dtl where domainId = p_domainId;
        
        select count(1)	into v_emailCount 		FROM wc_user_contact_dtl where domainId = p_domainId and email is not null;
        
        select count(1)	into v_whatsappCount 	FROM wc_user_contact_dtl where domainId = p_domainId and whatsappNumber is not null;
        
        select count(1)	into v_smsCount 		FROM wc_user_contact_dtl where domainId = p_domainId and phoneNumber is not null;
        
        select count(1)	into v_AppPushCount 	FROM wc_user_contact_dtl where domainId = p_domainId and deviceId is not null;
        
        select count(1)	into v_WebPushCount 	FROM wc_user_contact_dtl where domainId = p_domainId and pushNotificationId is not null;
        
        select v_totalCount as Total_Count, v_emailCount as Email_Count, v_whatsappCount as Whatsapp_Count, 
			v_smsCount as SMS_Count, v_AppPushCount as AppPush_Count, v_WebPushCount as WebPush_Count;
        
		set session transaction isolation level repeatable read;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_AI_chat_current_campaign_report` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_AI_chat_current_campaign_report`(
    	p_DomainId						INT,		
    	p_CreatedOrScheduleDate			DATE	
   		
   						
    )
BEGIN
    			 SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
                 
                WITH cte1 AS( 
   							
                               
                 SELECT domainId AS 'domainId', id AS 'CampaignId' ,campaignchatid AS 'CampaignChatId', campName AS 'CampaignName', 'WhatsApp' AS 'Channel' , createdDate AS 'createdOn'
    				FROM wc_campaign_master_dtl 
    			WHERE domainId = p_DomainId AND (DATE(createdDate) = p_CreatedOrScheduleDate OR DATE(scheduleDate) =  p_CreatedOrScheduleDate)
               
                UNION ALL		
                               
                 SELECT domainId AS 'domainId', campaignId AS 'CampaignId' , campaignchatid AS 'CampaignChatId', `Name` AS 'CampaignName', 'Email' AS 'Channel' , createdate AS 'createdOn'
    				FROM ec_email_campaign_master_dtl 
    			WHERE domainId = p_DomainId AND date(p_CreatedOrScheduleDate) between DATE(emailDeliveryStarttime) and DATE(emailDeliveryEndtime)
				-- ( DATE(emailDeliveryStarttime) >= p_CreatedOrScheduleDate  AND   DATE(emailDeliveryEndtime) <= p_CreatedOrScheduleDate)
               -- AND isIndivCamp != 2
                AND isIndivCamp = 0
                UNION ALL		
                
    			SELECT m.domainId AS 'domainId', m.id AS 'CampaignId', m.campaignchatid AS 'CampaignChatId', m.`name` AS 'CampaignName', 'SMS' AS 'Channel' , m.createdDate AS 'createdOn'
   				FROM sc_campaign_master_dtl m
                   JOIN sc_campaign_master_schedule_dtl	s  	ON 	m.id = s.campaignId AND m.domainId = s.domainId	
   			WHERE m.domainId = p_DomainId AND (DATE(createdDate) = p_CreatedOrScheduleDate
   				OR CASE WHEN m.triggerType = 0 THEN  DATE(s.schedulefromDate) = p_CreatedOrScheduleDate
   						WHEN m.triggerType IN (1) AND s.scheduletoDate IS NOT NULL 	THEN  (date(p_CreatedOrScheduleDate) between DATE(schedulefromDate) and DATE(scheduletoDate))
                           WHEN m.triggerType IN (1) AND s.scheduletoDate IS NULL 		THEN  DATE(s.schedulefromDate) = p_CreatedOrScheduleDate 
                           END)
                           
    			UNION ALL		
                                   
                SELECT m.domainId AS 'domainId', m.id AS 'CampaignId', m.campaignChatId AS 'CampaignChatId', m.campaignName AS 'CampaignName', 'AppPush' AS 'Channel' , m.createdOn AS 'createdOn'
                   FROM AppPush_campaign_master_dtl 		m
                   JOIN Apppush_campaign_schedule_dtl		s		ON m.id = s.campaignId		AND m.domainId = s.domainId
    			WHERE m.domainId = p_DomainId AND (DATE(createdOn) =p_CreatedOrScheduleDate OR 
   				CASE WHEN s.scheduleType  = 0 									THEN p_CreatedOrScheduleDate = DATE(s.schedulefromDate)
   					 WHEN s.scheduleType  IN(1) AND scheduletoDate IS NULL 		THEN p_CreatedOrScheduleDate = DATE(s.schedulefromDate)
                        WHEN s.scheduleType  IN(1) AND scheduletoDate IS NOT NULL 	THEN  (date(p_CreatedOrScheduleDate) between DATE(schedulefromDate) and DATE(scheduletoDate) )
                        END)
                
    			UNION ALL			
               
    			SELECT m.domainId AS 'domainId', m.id AS 'CampaignId' , m.campaignChatId AS 'CampaignChatId', m.campaignName AS 'CampaignName', 'WebPush' AS 'Channel' , m.createdOn AS 'createdOn'
                   FROM webpush_masterCampaignDtl			m
                   JOIN webpush_campaign_schedule_dtl		s		ON 		m.id = s.campaignId  AND m.domainId = s.domainId
    			WHERE m.domainId = p_DomainId AND (DATE(m.createdOn) =  p_CreatedOrScheduleDate OR
   				CASE WHEN s.scheduleType = 0 								THEN 			DATE(s.schedulefromDate) =  p_CreatedOrScheduleDate
                   WHEN s.scheduleType IN (1) AND s.scheduletoDate IS NULL 	THEN 			DATE(s.schedulefromDate) =  p_CreatedOrScheduleDate
   				WHEN s.scheduleType IN (1) AND s.scheduletoDate IS NOT NULL THEN 		 (date(p_CreatedOrScheduleDate) between DATE(schedulefromDate) and DATE(scheduletoDate)) END)
                
                )		
                
               SELECT CampaignChatId, JSON_ARRAYAGG(JSON_OBJECT('CampaignId', CampaignId, 'ChannelName', `Channel`, 'CampaignName', campaignName)) as "campaign_Details", MIN(createdOn) as mincreated 
    				FROM cte1
    				GROUP BY CampaignChatId
                    ORDER BY mincreated DESC;
                 
                 
                 SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_AI_chat_future_campaign_report` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_AI_chat_future_campaign_report`(
  	p_DomainId						INT,		
  	p_ScheduleDate					DATE	
 		
 						
                         
  )
BEGIN
  			 SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
               
              WITH cte1 AS( 
 							
                             
               SELECT domainId AS 'domainId', id AS 'CampaignId' ,campaignchatid AS 'CampaignChatId', campName AS 'CampaignName', 'WhatsApp' AS 'Channel' , createdDate AS 'createdOn'
  				FROM wc_campaign_master_dtl 
  			WHERE domainId = p_DomainId AND triggerType NOT IN (0) AND DATE(scheduleDate) > p_ScheduleDate
             
              UNION ALL		
                             
               SELECT domainId AS 'domainId', campaignId AS 'CampaignId' , campaignchatid AS 'CampaignChatId', `Name` AS 'CampaignName', 'Email' AS 'Channel' , createdate AS 'createdOn'
  				FROM ec_email_campaign_master_dtl 
  			WHERE domainId = p_DomainId AND emailDelivery NOT IN (1) AND (DATE(emailDeliveryStarttime) > p_ScheduleDate OR DATE(emailDeliveryEndtime) > p_ScheduleDate) and isIndivCamp =0
             
              UNION ALL		
              
  			SELECT m.domainId AS 'domainId', m.id AS 'CampaignId', m.campaignchatid AS 'CampaignChatId', m.`name` AS 'CampaignName', 'SMS' AS 'Channel' , m.createdDate AS 'createdOn'
 				FROM sc_campaign_master_dtl m
                 JOIN sc_campaign_master_schedule_dtl	s  	ON 	m.id = s.campaignId AND m.domainId = s.domainId	
 			WHERE m.domainId = p_DomainId AND  m.triggerType NOT IN (0) AND (DATE(s.schedulefromDate) > p_ScheduleDate OR DATE(s.scheduletoDate) > p_ScheduleDate)
                         
  			UNION ALL		
                                 
              SELECT m.domainId AS 'domainId', m.id AS 'CampaignId', m.campaignChatId AS 'CampaignChatId', m.campaignName AS 'CampaignName', 'AppPush' AS 'Channel' , m.createdOn AS 'createdOn'
                 FROM AppPush_campaign_master_dtl 		m
                 JOIN Apppush_campaign_schedule_dtl		s		ON m.id = s.campaignId		AND m.domainId = s.domainId
  			WHERE m.domainId = p_DomainId AND s.scheduleType  NOT IN (0) AND (DATE(schedulefromDate) > p_ScheduleDate OR DATE(s.scheduletoDate) > p_ScheduleDate)
              
  			UNION ALL			
             
  			SELECT m.domainId AS 'domainId', m.id AS 'CampaignId' , m.campaignChatId AS 'CampaignChatId', m.campaignName AS 'CampaignName', 'WebPush' AS 'Channel' , m.createdOn AS 'createdOn'
                 FROM webpush_masterCampaignDtl			m
                 JOIN webpush_campaign_schedule_dtl		s		ON 		m.id = s.campaignId  AND m.domainId = s.domainId
  			WHERE m.domainId = p_DomainId AND  s.scheduleType NOT IN (0) AND (DATE(s.schedulefromDate) >  p_ScheduleDate  OR DATE(scheduletoDate) > p_ScheduleDate)
              
              )		
              
             SELECT CampaignChatId, JSON_ARRAYAGG(JSON_OBJECT('CampaignId', CampaignId, 'ChannelName', `Channel`, 'CampaignName', campaignName)) as "campaign_Details", MIN(createdOn) as mincreated 
  				FROM cte1
  				GROUP BY CampaignChatId
                  ORDER BY mincreated DESC;
               
               
               SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_AI_chat_past_campaign_report` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_AI_chat_past_campaign_report`(
 	p_DomainId						INT,		
 	p_ScheduleDate					DATE	
 )
BEGIN
 			 SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
              
             WITH cte1 AS( 
							
                            
              SELECT domainId AS 'domainId', id AS 'CampaignId' ,campaignchatid AS 'CampaignChatId', campName AS 'CampaignName', 'WhatsApp' AS 'Channel' , createdDate AS 'createdOn'
 				FROM wc_campaign_master_dtl 
 			WHERE domainId = p_DomainId AND DATE(scheduleDate) < p_ScheduleDate
            
             UNION ALL		
                            
              SELECT domainId AS 'domainId', campaignId AS 'CampaignId' , campaignchatid AS 'CampaignChatId', `Name` AS 'CampaignName', 'Email' AS 'Channel' , createdate AS 'createdOn'
 				FROM ec_email_campaign_master_dtl 
 			WHERE domainId = p_DomainId AND  DATE(emailDeliveryEndtime) < p_ScheduleDate  
            
             UNION ALL		
             
 			SELECT m.domainId AS 'domainId', m.id AS 'CampaignId', m.campaignchatid AS 'CampaignChatId', m.`name` AS 'CampaignName', 'SMS' AS 'Channel' , m.createdDate AS 'createdOn'
				FROM sc_campaign_master_dtl m
                JOIN sc_campaign_master_schedule_dtl	s  	ON 	m.id = s.campaignId AND m.domainId = s.domainId	
			WHERE m.domainId = p_DomainId AND 
					CASE WHEN s.scheduletoDate IS NULL THEN	DATE(s.schedulefromDate) < p_ScheduleDate
						 ELSE DATE(s.scheduletoDate) < p_ScheduleDate END 
                        
 			UNION ALL		
                                
             SELECT m.domainId AS 'domainId', m.id AS 'CampaignId', m.campaignChatId AS 'CampaignChatId', m.campaignName AS 'CampaignName', 'AppPush' AS 'Channel' , m.createdOn AS 'createdOn'
                FROM AppPush_campaign_master_dtl 		m
                JOIN Apppush_campaign_schedule_dtl		s		ON m.id = s.campaignId		AND m.domainId = s.domainId
 			WHERE m.domainId = p_DomainId AND
					CASE WHEN s.scheduletoDate IS NULL THEN	DATE(s.schedulefromDate) < p_ScheduleDate
						 ELSE DATE(s.scheduletoDate) < p_ScheduleDate END 			
            
 			UNION ALL			
            
 			SELECT m.domainId AS 'domainId', m.id AS 'CampaignId' , m.campaignChatId AS 'CampaignChatId', m.campaignName AS 'CampaignName', 'WebPush' AS 'Channel' , m.createdOn AS 'createdOn'
                FROM webpush_masterCampaignDtl			m
                JOIN webpush_campaign_schedule_dtl		s		ON 		m.id = s.campaignId  AND m.domainId = s.domainId
 			WHERE m.domainId = p_DomainId AND
						CASE WHEN s.scheduletoDate IS NULL THEN	DATE(s.schedulefromDate) < p_ScheduleDate
						 ELSE DATE(s.scheduletoDate) < p_ScheduleDate END 			
                         
             )		
             
            SELECT CampaignChatId, JSON_ARRAYAGG(JSON_OBJECT('CampaignId', CampaignId, 'ChannelName', `Channel`, 'CampaignName', campaignName)) as "campaign_Details", MIN(createdOn) as mincreated 
 				FROM cte1
 				GROUP BY CampaignChatId
                 ORDER BY mincreated DESC;
              
              
              SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_AI_delete_knowledge_base_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_AI_delete_knowledge_base_dtl`(
	p_domainId			INT,
    p_uniqueId			VARCHAR(50)
)
begin
		DECLARE v_errCode		TINYINT default -1;
        DECLARE v_errMsg		VARCHAR(50) DEFAULT "Failed";
        declare v_id			int;
        
        select id into v_id FROM wc_tb_knowledge_base_pdf_dtl WHERE domainId = p_domainId AND uniqueId = p_uniqueId;
        
       
        
        IF v_id is not null THEN
				
                DELETE FROM wc_tb_knowledge_base_pdf_dtl
					where id = v_id;
                    
				if row_count() > 0 then 
					set v_errCode = 0;
                    set v_errMsg = "Deleted Successfully";
				end if;
                
        end if;
		
        select v_errCode as errCode, v_errMsg as errMsg;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_analytics_get_Campaigns_ClickRate_present_past_week` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_analytics_get_Campaigns_ClickRate_present_past_week`(p_domainId		INT)
BEGIN
		DECLARE v_currentTotal 		INT DEFAULT 0;
        DECLARE v_pastTotal 		INT DEFAULT 0;
		DECLARE v_currentdate	 	DATE DEFAULT now();
        DECLARE v_currentfirstdate	DATE;
        DECLARE v_pastlastdate 		DATE;
        DECLARE v_pastfirstdate 	DATE;
        
        DECLARE v_currentemailClickRate			INT		DEFAULT 0;
		DECLARE v_pastemailClickRate			INT		DEFAULT 0;
        
        
        declare v_currentWebPushClickRate		int		default 0;
		declare v_pastWebPushClickRate			int		default 0;
        
        
        set v_currentfirstdate = subdate(v_currentdate , interval 6 day);
		set v_pastlastdate	= subdate(adddate(v_currentdate, interval -1 day) , interval 6 day);
        set v_pastfirstdate = subdate(v_pastlastdate,  interval 6 day);
		
     
     
     DROP TEMPORARY TABLE IF EXISTS tt_current_campaignchatId_dtl;
     CREATE TEMPORARY TABLE tt_current_campaignchatId_dtl
     with current7Week as( 
		select campaignchatId FROM wc_campaign_master_dtl where domainId = p_domainId AND DATE(createdDate) BETWEEN v_currentfirstdate AND v_currentdate
			UNION ALL 	
		select campaignchatid FROM ec_email_campaign_master_dtl where domainId= p_domainId AND DATE(createdate) BETWEEN v_currentfirstdate AND v_currentdate
			UNION ALL 
		select campaignchatid FROM sc_campaign_master_dtl where domainId = p_domainId AND DATE(createdDate) BETWEEN v_currentfirstdate AND v_currentdate
			UNION ALL
		select campaignChatId FROM AppPush_campaign_master_dtl  where domainId = p_domainId AND DATE(createdOn) BETWEEN v_currentfirstdate AND v_currentdate
			UNION ALL
		select campaignChatId FROM inApp_campaign_master_dtl where domainId = p_domainId AND DATE(createdOn) BETWEEN v_currentfirstdate AND v_currentdate
			UNION ALL
		select campaignChatId FROM webpush_masterCampaignDtl where domainId = p_domainId AND DATE(createdOn) BETWEEN v_currentfirstdate AND v_currentdate
    )
    SELECT distinct(campaignchatId) FROM current7Week where campaignchatId is not null;
    
		
    
			drop temporary table if exists tt_past_campaignchatId_dtl;
			create temporary table tt_past_campaignchatId_dtl
			with last7Week as( 
			select campaignchatId FROM wc_campaign_master_dtl where domainId = p_domainId AND DATE(createdDate) 	BETWEEN v_pastfirstdate AND v_pastlastdate
				UNION ALL 	
			select campaignchatid FROM ec_email_campaign_master_dtl where domainId= p_domainId AND DATE(createdate) BETWEEN v_pastfirstdate AND v_pastlastdate
				UNION ALL 
			select campaignchatid FROM sc_campaign_master_dtl where domainId = p_domainId AND DATE(createdDate) BETWEEN v_pastfirstdate AND v_pastlastdate
				UNION ALL
			select campaignChatId FROM AppPush_campaign_master_dtl  where domainId = p_domainId AND DATE(createdOn) BETWEEN v_pastfirstdate AND v_pastlastdate
				UNION ALL
			select campaignChatId FROM inApp_campaign_master_dtl where domainId = p_domainId AND DATE(createdOn) BETWEEN v_pastfirstdate AND v_pastlastdate
				UNION ALL
			select campaignChatId FROM webpush_masterCampaignDtl where domainId = p_domainId AND DATE(createdOn) BETWEEN v_pastfirstdate AND v_pastlastdate
			)
			SELECT distinct(campaignchatId) FROM last7Week where campaignchatId is not null;

 
    
    
    
			 SELECT SUM(IFNULL(t1.uniqueClickCount, 0)) INTO v_currentemailClickRate
				FROM ec_campaign_HistoryDtl t1
				JOIN tt_current_campaignchatId_dtl t2 ON t1.campaignChatId = t2.campaignchatId;
                
			SELECT SUM(IFNULL(t1.uniqueClickCount, 0)) INTO v_pastemailClickRate
				FROM ec_campaign_HistoryDtl t1
				JOIN tt_past_campaignchatId_dtl t2 ON t1.campaignChatId = t2.campaignchatId;  
                
       
       
       
       
       SELECT COUNT(t1.id) INTO v_currentWebPushClickRate  FROM webpush_sent_status_details t1
        JOIN tt_current_campaignchatId_dtl t2 ON  t1.campaignChatId = t2.campaignchatId
        WHERE t1.`status` = 'OPEN'; 
     
		 SELECT COUNT(t1.id) INTO v_pastWebPushClickRate  FROM webpush_sent_status_details t1
        JOIN tt_past_campaignchatId_dtl t2 ON  t1.campaignChatId = t2.campaignchatId
        WHERE t1.`status` = 'OPEN'; 
        
        
        
			SELECT IFNULL(v_currentemailClickRate,0) + IFNULL(v_currentWebPushClickRate,0) AS CurrentTotalClickRate,
					IFNULL(v_pastemailClickRate, 0) + IFNULL(v_pastWebPushClickRate, 0) AS PastTotalClickRate;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_analytics_get_Campaigns_openRate_present_past_week` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_analytics_get_Campaigns_openRate_present_past_week`(p_domainId		INT)
BEGIN
  		DECLARE v_currentTotal 		INT DEFAULT 0;
          DECLARE v_pastTotal 		INT DEFAULT 0;
  		DECLARE v_currentdate 		DATE DEFAULT now();
          DECLARE v_currentfirstdate	DATE;
          DECLARE v_pastlastdate 		DATE;
          DECLARE v_pastfirstdate 	DATE;
          
          DECLARE v_currentemailOpenRate			INT		DEFAULT 0;
  		DECLARE v_pastemailOpenRate				INT		DEFAULT 0;
          
  		DECLARE v_currentAppPushOpenRate		INT		DEFAULT 0;
  		DECLARE v_pastappPushOpenRate			INT		DEFAULT 0;
          
  		DECLARE v_currentWhatsappOpenRate		INT		DEFAULT 0;
  		DECLARE v_pastWhatsappOpenRate			INT		DEFAULT 0;
          
          
          SET v_currentfirstdate = subdate(v_currentdate , INTERVAL 6 DAY);
  		SET v_pastlastdate	= subdate(adddate(v_currentdate, INTERVAL -1 day) , INTERVAL 6 DAY);
          SET v_pastfirstdate = subdate(v_pastlastdate,  INTERVAL 6 DAY);
  		
       
       
       DROP TEMPORARY TABLE IF EXISTS tt_current_campaignchatId_dtl;
       CREATE TEMPORARY TABLE tt_current_campaignchatId_dtl
       WITH current7Week AS( 
  		SELECT campaignchatId FROM wc_campaign_master_dtl where domainId = p_domainId AND DATE(createdDate) BETWEEN v_currentfirstdate AND v_currentdate
  			UNION ALL 	
  		SELECT campaignchatid FROM ec_email_campaign_master_dtl where domainId= p_domainId AND DATE(createdate) BETWEEN v_currentfirstdate AND v_currentdate
  			UNION ALL 
  		SELECT campaignchatid FROM sc_campaign_master_dtl where domainId = p_domainId AND DATE(createdDate) BETWEEN v_currentfirstdate AND v_currentdate
  			UNION ALL
  		SELECT campaignChatId FROM AppPush_campaign_master_dtl  where domainId = p_domainId AND DATE(createdOn) BETWEEN v_currentfirstdate AND v_currentdate
  			UNION ALL
  		SELECT campaignChatId FROM inApp_campaign_master_dtl where domainId = p_domainId AND DATE(createdOn) BETWEEN v_currentfirstdate AND v_currentdate
  			UNION ALL
  		SELECT campaignChatId FROM webpush_masterCampaignDtl where domainId = p_domainId AND DATE(createdOn) BETWEEN v_currentfirstdate AND v_currentdate
      )
      SELECT distinct(campaignchatId) FROM current7Week where campaignchatId is not null;
      
  
      
  	DROP TEMPORARY TABLE IF EXISTS tt_past_campaignchatId_dtl;
  	CREATE TEMPORARY TABLE tt_past_campaignchatId_dtl
      WITH last7Week AS( 
      SELECT campaignchatId FROM wc_campaign_master_dtl WHERE domainId = p_domainId AND DATE(createdDate) 	BETWEEN v_pastfirstdate AND v_pastlastdate
  		UNION ALL 	
  	select campaignchatid FROM ec_email_campaign_master_dtl where domainId= p_domainId AND DATE(createdate) BETWEEN v_pastfirstdate AND v_pastlastdate
  		UNION ALL 
  	select campaignchatid FROM sc_campaign_master_dtl where domainId = p_domainId AND DATE(createdDate) BETWEEN v_pastfirstdate AND v_pastlastdate
  		UNION ALL
  	select campaignChatId FROM AppPush_campaign_master_dtl  where domainId = p_domainId AND DATE(createdOn) BETWEEN v_pastfirstdate AND v_pastlastdate
  		UNION ALL
  	select campaignChatId FROM inApp_campaign_master_dtl where domainId = p_domainId AND DATE(createdOn) BETWEEN v_pastfirstdate AND v_pastlastdate
  		UNION ALL
  	select campaignChatId FROM webpush_masterCampaignDtl where domainId = p_domainId AND DATE(createdOn) BETWEEN v_pastfirstdate AND v_pastlastdate
      )
      SELECT distinct(campaignchatId) FROM last7Week where campaignchatId is not null;
  
      
  			
              SELECT SUM(IFNULL(t1.uniqueOpenCount, 0)) INTO v_currentemailOpenRate
  				FROM ec_campaign_HistoryDtl t1
  				JOIN tt_current_campaignchatId_dtl t2 ON t1.campaignChatId = t2.campaignchatId;
                  
  			SELECT SUM(IFNULL(t1.uniqueOpenCount, 0)) INTO v_pastemailOpenRate
  				FROM ec_campaign_HistoryDtl t1
  				JOIN tt_past_campaignchatId_dtl t2 ON t1.campaignChatId = t2.campaignchatId;  
                  
         
           
  	 
       
  		SELECT COUNT(t1.id) INTO v_currentAppPushOpenRate
  			FROM AppPush_tb_openRate_history_dtl	t1 
  			JOIN tt_current_campaignchatId_dtl			t2 ON t1.campaignChatId = t2.campaignchatId
              WHERE t1.`status` = 'OPEN';  
              
  		SELECT COUNT(t1.id) INTO v_pastappPushOpenRate
  			FROM AppPush_tb_openRate_history_dtl	t1 
  			JOIN tt_past_campaignchatId_dtl			t2 ON t1.campaignChatId = t2.campaignchatId
              WHERE t1.`status` = 'OPEN';  
       
  	 	
              
  		
  	
          SELECT COUNT(t1.id) INTO  v_currentWhatsappOpenRate FROM wc_analytics_history_dtl t1
          JOIN tt_current_campaignchatId_dtl	t2 	ON t1.campaignchatId = t2.campaignchatId
          WHERE t1.status = "read";  
          
          SELECT COUNT(t1.id) INTO  v_pastWhatsappOpenRate FROM wc_analytics_history_dtl t1
          JOIN tt_past_campaignchatId_dtl	t2 	ON t1.campaignchatId = t2.campaignchatId
          WHERE t1.status = "read";  
          
         
          
          SELECT 
          (IFNULL(v_currentWhatsappOpenRate,0)+ IFNULL(v_currentAppPushOpenRate,0)+ IFNULL(v_currentemailOpenRate, 0)) as TotalCurrentOpenRate,
          ( IFNULL(v_pastWhatsappOpenRate,0) + IFNULL(v_pastappPushOpenRate,0) + IFNULL(v_pastemailOpenRate,0) ) as TotalPastOpenRate;
   END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_analytics_get_Campaigns_present_past_week` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_analytics_get_Campaigns_present_past_week`(p_domainId		INT)
BEGIN
 		declare v_current INT DEFAULT 0;
         declare v_past INT DEFAULT 0;
 		declare v_currentdate date default now();
         declare v_currentfirstdate	date;
         declare v_pastlastdate date;
         declare v_pastfirstdate date;
         
         set v_currentfirstdate = subdate(v_currentdate , interval 6 day);
 		set v_pastlastdate	= subdate(adddate(v_currentdate, interval -1 day) , interval 6 day);
         
         set v_pastfirstdate = subdate(v_pastlastdate,  interval 6 day);
 		
      
      
      
     with current7Week as( 
     select campaignchatId FROM wc_campaign_master_dtl where domainId = p_domainId AND DATE(createdDate) BETWEEN v_currentfirstdate AND v_currentdate
 		UNION ALL 	
 	select campaignchatid FROM ec_email_campaign_master_dtl where domainId= p_domainId AND DATE(createdate) BETWEEN v_currentfirstdate AND v_currentdate
 		UNION ALL 
 	select campaignchatid FROM sc_campaign_master_dtl where domainId = p_domainId AND DATE(createdDate) BETWEEN v_currentfirstdate AND v_currentdate
 		UNION ALL
 	select campaignChatId FROM AppPush_campaign_master_dtl  where domainId = p_domainId AND DATE(createdOn) BETWEEN v_currentfirstdate AND v_currentdate
 		UNION ALL
 	select campaignChatId FROM inApp_campaign_master_dtl where domainId = p_domainId AND DATE(createdOn) BETWEEN v_currentfirstdate AND v_currentdate
 		UNION ALL
 	select campaignChatId FROM webpush_masterCampaignDtl where domainId = p_domainId AND DATE(createdOn) BETWEEN v_currentfirstdate AND v_currentdate
     )
     SELECT COUNT(distinct(campaignchatId)) INTO v_current  FROM current7Week where campaignchatId is not null;
 
 
  with last7Week as( 
     select campaignchatId FROM wc_campaign_master_dtl where domainId = p_domainId AND DATE(createdDate) 	BETWEEN v_pastfirstdate AND v_pastlastdate
 		UNION ALL 	
 	select campaignchatid FROM ec_email_campaign_master_dtl where domainId= p_domainId AND DATE(createdate) BETWEEN v_pastfirstdate AND v_pastlastdate
 		UNION ALL 
 	select campaignchatid FROM sc_campaign_master_dtl where domainId = p_domainId AND DATE(createdDate) BETWEEN v_pastfirstdate AND v_pastlastdate
 		UNION ALL
 	select campaignChatId FROM AppPush_campaign_master_dtl  where domainId = p_domainId AND DATE(createdOn) BETWEEN v_pastfirstdate AND v_pastlastdate
 		UNION ALL
 	select campaignChatId FROM inApp_campaign_master_dtl where domainId = p_domainId AND DATE(createdOn) BETWEEN v_pastfirstdate AND v_pastlastdate
 		UNION ALL
 	select campaignChatId FROM webpush_masterCampaignDtl where domainId = p_domainId AND DATE(createdOn) BETWEEN v_pastfirstdate AND v_pastlastdate
     )
     SELECT COUNT(distinct(campaignchatId)) INTO  v_past FROM last7Week where campaignchatId is not null;
 
 
 
 	SELECT	v_current as Current_total, v_past as Past_total;
 		
 
 
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_analytics_get_messageId_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_analytics_get_messageId_dtl`(
 	p_messageId    varchar(500)
 )
BEGIN
 		
         SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
 
 			SELECT id , domainId , campaignchatId , campaignId , fromNo , toNo , messageId , `status`
             FROM wc_analytics_history_dtl WHERE messageId = p_messageId;
 
         SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_analytics_update_status_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_analytics_update_status_dtl`(
	p_messageId       VARCHAR(500),
    p_domainId		  INT,
	p_toNo			  VARCHAR(30),
	p_status		  VARCHAR(50)		
)
BEGIN
				DECLARE  v_errMsg					VARCHAR(50) DEFAULT 'Failed';
                DECLARE  v_errCode					INT DEFAULT 0;
                DECLARE  v_actionId					INT DEFAULT 5;
                DECLARE  v_campaignchatId			VARCHAR(300); 
                DECLARE  v_userId					INT;	
                
                DECLARE EXIT HANDLER FOR SQLEXCEPTION 
                BEGIN
						SELECT v_errCode AS errCode,  v_errMsg   AS errMsg;
                        ROLLBACK;                        
                END;

				START TRANSACTION;
                
                UPDATE wc_analytics_history_dtl
					SET `status` = p_status
				WHERE domainId = p_domainId
					AND messageId = p_messageId
                    AND toNo = p_toNo;
                    
                 IF ROW_COUNT() > 0 THEN 
													-- **************** now inserting in whatsapp_tb_indiv_user_click_open_cnt_dtl ***************************
                    IF p_status = 'DELIVERY' THEN
						SET v_actionId = 2;
					ELSEIF p_status = 'read' THEN 
						SET v_actionId = 3;
                    END IF;
                 
					SELECT campaignchatId INTO v_campaignchatId 		   -- ************ getting the campaign Id *********************				
								FROM wc_analytics_history_dtl 
					WHERE domainId = p_domainId AND messageId = p_messageId AND toNo = p_toNo;
                    
                     SELECT id INTO v_userId 								-- ************ getting the user Id *********************
								FROM wc_user_contact_dtl 
					WHERE domainId = p_domainId and  whatsappNumber  = p_toNo;
                    
                    INSERT INTO whatsapp_tb_indiv_user_click_open_cnt_dtl
                    (domainId, campaignChatId, userID, actionId) VALUES(p_domainId, v_campaignchatId, v_userId ,v_actionId);
                    
                    IF ROW_COUNT() > 0 THEN
						SET v_errMsg 		= 'Updated';
						SET v_errCode 		= 1;
					END IF;
			
                 END IF;
            COMMIT;     
			SELECT v_errCode AS errCode, v_errMsg as errMsg ; 

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_Chart_totalCampaign_based_on_domainId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_Chart_totalCampaign_based_on_domainId`(
 	p_domainId	INT
  )
BEGIN
 			DECLARE v_Whatsapp		INT;
             DECLARE v_Email			INT;
             DECLARE v_SMS			INT;
             DECLARE v_AppPush		INT;
             DECLARE v_WebPush		INT;
             DECLARE v_InApp			INT;
             
             
             SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
             
 				SELECT COUNT(1) INTO v_Whatsapp FROM wc_campaign_master_dtl WHERE domainId = p_domainId;
 
 				SELECT COUNT(1) INTO v_Email 	FROM ec_email_campaign_master_dtl where domainId = p_domainId;
 					
                 SELECT COUNT(1) INTO v_SMS		FROM sc_campaign_master_dtl	WHERE domainId = p_domainId;
 					
                 SELECT COUNT(1) INTO v_AppPush 	FROM AppPush_campaign_master_dtl	WHERE domainId = p_domainId;
 					
                 SELECT COUNT(1)	INTO v_WebPush 	FROM webpush_masterCampaignDtl WHERE domainId = p_domainId;
 				
                 SELECT COUNT(1) INTO v_InApp  	FROM inApp_campaign_master_dtl	WHERE domainId = p_domainId;
 	
 				SELECT v_Whatsapp AS Whatsapp, v_Email AS Email, v_SMS AS SMS, v_AppPush AS AppPush
 						,v_WebPush as WebPush, v_InApp as InApp;
                 
             SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_chart_weekly_camp_summary` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_chart_weekly_camp_summary`(
 		 p_domainId 				INT
 		
 )
BEGIN
 		
             DECLARE email_openRate		INT default 0;
 			DECLARE webpush_openRate	INT default 0;	
             DECLARE apppush_openRate	INT default 0;
             DECLARE totalCoversationRate	INT default 0;
             DECLARE totalCTR				INT DEFAULT 0;
         
 			SELECT count(*) INTO email_openRate  FROM ec_campaign_openRate_history_dtl where domainId = p_domainId;
 	
 			SELECT count(*) INTO webpush_openRate FROM webpush_sent_status_details where domainId = p_domainId and
             status = 'open';		
 		
 			SELECT count(*) INTO apppush_openRate FROM AppPush_tb_openRate_history_dtl	where domainId = p_domainId and   `status` = 'Open';	
             
 
             
             SELECt email_openRate + webpush_openRate + apppush_openRate AS totalOpenRate, totalCoversationRate, totalCTR;
         
     
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_create_custom_field_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_create_custom_field_info`(	 
  	p_domainid 		INT	 
  	,p_field_type 			VARCHAR(50) 	
  	,p_field_name 			VARCHAR(50) 	
  	,p_field_datatype 		VARCHAR(50) 	
  	,p_field_label 			VARCHAR(50) 	
  	,p_field_value 			VARCHAR(2000)	
  	,p_field_category 		VARCHAR(200)	
  	,p_isMandatory 			TINYINT 
  	,p_placeHolder 			VARCHAR(300) 
  	,p_errMsg 				VARCHAR(300) 
      ,p_isDisplay			TINYINT 
   )
Begin
       	
      	declare v_errcode 	int;
      	declare v_errmsg 	varchar(150);
      	declare v_FieldId 	int;
          declare v_DB		VARCHAR(20);	
          
          SET v_DB = DATABASE();
          
           sp_exit:begin
       	IF EXISTS(SELECT 1 FROM information_schema.tables where TABLE_SCHEMA = v_DB and TABLE_NAME = concat('customer_contact_',p_domainid) limit 1) 
          THEN
       		If exists(SELECT 1 FROM information_schema.columns WHERE table_name IN ('customer_contact',concat('customer_contact_',p_domainid)) and COLUMN_NAME = p_field_name AND table_schema = v_DB LIMIT 1)       
              THEN
       			SET v_errcode = -1;
      			SET v_errmsg = 'Column already exists';
                  LEAVE sp_exit;
      		END IF;
           
       		SET @coladd = CONCAT("ALter table customer_contact_",p_domainid," add ",p_field_name," varchar(250);") ;
               
       		PREPARE coladd FROM @coladd;
       		EXECUTE coladd;
       		DEALLOCATE PREPARE coladd;
               
      		SET v_errcode = 0;
      		SET v_errmsg = 'Custom field added';
           ELSE
       		set  @newtbl = concat("create table customer_contact_",p_domainid, "(id int auto_increment primary key, coid int, createdAt datetime, updatedAt datetime default now(), ",p_field_name," varchar(50))");
               
     		PREPARE newtbl FROM @newtbl;
     		EXECUTE newtbl;
     		DEALLOCATE PREPARE newtbl;
               
               set v_errcode = 0;
               set v_errmsg = 'Custom field created';
           
           End if;
               
      	
      	insert into wc_customer_contact_column_properties(tableName,columName,columnLabel,placeHolder,errMsg,columnType,columnCategory,isMandatory,isDisplay,columnValue,createAt,domainID)
      	values(concat('customer_contact_',p_domainid),p_field_name,p_field_label,p_placeHolder,p_errMsg,p_field_type,p_field_category,p_isMandatory,p_isDisplay,p_field_value,current_timestamp,p_domainid);
      
      	set v_FieldId = last_insert_id();         
           
       	End sp_exit;
           select v_errcode as errcode, v_errmsg as errmsg,v_FieldId as FieldId ;
       
       End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_cron_insert_Admin_bounce_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_cron_insert_Admin_bounce_dtl`()
BEGIN
		DECLARE v_startDate	 DATE 		DEFAULT now();
        DECLARE v_errCode	TINYINT 	DEFAULT -1;
        DECLARE v_errMsg	VARCHAR(50) DEFAULT 'Failed';
        
        set v_startDate = subdate(v_startDate, interval 1 day);
        
        --  select v_startDate;			-- *************** to check ***************
        
        DROP TEMPORARY TABLE IF EXISTS tt_delivery_bounce_dtl;
        CREATE TEMPORARY TABLE tt_delivery_bounce_dtl
        
				select -- t1.campaign_id, 
						t2.domainId,
						t2.campaignchatid, 
					--  t1.mail_to,
						t3.id,
						CASE 	WHEN t1.delivery_status = 'sent' 		THEN 2 
								WHEN t1.delivery_status = 'bounced' 	THEN 6
								ELSE 5
						END AS	'actionId', 
						CONCAT(t1.log_date,' ',t1.log_time) as SentOn
				FROM worktual_email_campaign.email_delivery_details 	t1
					JOIN ec_email_campaign_master_dtl 						t2  ON t1.campaign_id = t2.campaignId
					JOIN wc_user_contact_dtl								t3  ON	t3.email COLLATE utf8mb4_0900_ai_ci = t1.mail_to AND t3.domainId = t2.domainId 
				WHERE t1.campaign_id IS NOT NULL 
					AND  t1.delivery_status IN ('sent', 'bounced')
					AND t2.campaignchatid IS NOT NULL 
                    AND t2.isIndivCamp = 2
					AND DATE(t1.log_date) = v_startDate;
		
        
		 INSERT INTO Email_tb_indiv_admin_action_dtl(domainId, campaignChatId, userID, actionId, createdOn)
 			 SELECT domainId, campaignchatid,id, actionId, SentOn   FROM tt_delivery_bounce_dtl;
             
        IF ROW_COUNT() > 0 then
 			 SET 	v_errCode = 0;
             SET	v_errMsg = "Inserted Successfully";
         END IF;
         
        
        SELECT v_errCode as errCode, v_errMsg as errMsg;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_cron_insert_bounce_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_cron_insert_bounce_dtl`()
BEGIN
		DECLARE v_startDate	 DATE 		DEFAULT now();
        DECLARE v_errCode	TINYINT 	DEFAULT -1;
        DECLARE v_errMsg	VARCHAR(50) DEFAULT 'Failed';
        
        set v_startDate = subdate(v_startDate, interval 1 day);
        
        --  select v_startDate;			-- *************** to check ***************
        
        DROP TEMPORARY TABLE IF EXISTS tt_delivery_bounce_dtl;
        CREATE TEMPORARY TABLE tt_delivery_bounce_dtl
        
				select -- t1.campaign_id, 
						t2.domainId,
						t2.campaignchatid, 
					--  t1.mail_to,
						t3.id,
						CASE 	WHEN t1.delivery_status = 'sent' 		THEN 2 
								WHEN t1.delivery_status = 'bounced' 	THEN 6
								ELSE 5
						END AS	'actionId', 
						CONCAT(t1.log_date,' ',t1.log_time) as SentOn
				FROM worktual_email_campaign.email_delivery_details 	t1
					JOIN ec_email_campaign_master_dtl 						t2  ON t1.campaign_id = t2.campaignId
					JOIN wc_user_contact_dtl								t3  ON	t3.email COLLATE utf8mb4_0900_ai_ci = t1.mail_to AND t3.domainId = t2.domainId 
				WHERE t1.campaign_id IS NOT NULL 
					AND  t1.delivery_status IN ('sent', 'bounced')
					AND t2.campaignchatid IS NOT NULL 
					AND DATE(t1.log_date) = v_startDate;
		
        
		 INSERT INTO Email_tb_indiv_user_click_open_cnt_dtl(domainId, campaignChatId, userID, actionId, createdOn)
 			 SELECT domainId, campaignchatid,id, actionId, SentOn   FROM tt_delivery_bounce_dtl;
             
        IF ROW_COUNT() > 0 then
 			 SET 	v_errCode = 0;
             SET	v_errMsg = "Inserted Successfully";
         END IF;
         
        
        SELECT v_errCode as errCode, v_errMsg as errMsg;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_deleteCampaignMasterDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_deleteCampaignMasterDtl`(	
    p_domainId	INT,
    p_id		INT
)
BEGIN
		DECLARE v_errCode		INT DEFAULT -1;
        DECLARE v_errMsg		VARCHAR(100) DEFAULT "Failed";
        
        IF EXISTS(SELECT 1 FROM wc_campaign_master_dtl WHERE id = p_id AND domainId = p_domainId) THEN
				
                DELETE FROM wc_campaign_master_dtl WHERE id = p_id AND domainId = p_domainId;
        
			IF ROW_COUNT() > 0 THEN
				SET v_errCode = 0;
                SET v_errMsg = "Deleted Successfully";
			END IF;
        
        END IF;
        
        SELECT v_errCode AS errCode , v_errMsg AS errMsg;
        
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_deleteCustomerTag` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_deleteCustomerTag`(
	p_ctgid			INT,
    p_domainId		INT
)
BEGIN
		DECLARE v_errMsg varchar(50) DEFAULT "Failed";
        DECLARE v_errCode INT DEFAULT -1;
		
        DELETE FROM wc_customerTag
        WHERE ctgid = p_ctgid AND domainId = p_domainId;
        
       IF ROW_COUNT() > 0 THEN
			
            SET v_errMsg = "Deleted Successfully";
            SET v_errCode = 1;
		END IF;
        
        SELECT v_errCode AS errCode, v_errMsg AS errMsg;
        
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_deleteCustomerType` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_deleteCustomerType`(
	p_ctid			INT,
    p_domainId		INT
)
BEGIN
		DECLARE v_errMsg varchar(50) DEFAULT "Failed";
        DECLARE v_errCode INT DEFAULT -1;
		
        DELETE FROM wc_customerType
        WHERE ctid = p_ctid AND domainId = p_domainId;
        
       IF ROW_COUNT() > 0 THEN
			
            SET v_errMsg = "Deleted Successfully";
            SET v_errCode = 1;
		END IF;
        
        SELECT v_errCode AS errCode, v_errMsg AS errMsg;
        
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_deleteOauthTokentDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_deleteOauthTokentDtl`(
	p_domainID  INT
)
BEGIN
		DECLARE v_errMsg 	VARCHAR(50) DEFAULT "Failed";
        DECLARE v_errCode 	INT DEFAULT -1;
        
        IF EXISTS (SELECT 1 FROM wc_oauthDtl WHERE domainID = p_domainID) THEN 
			
            DELETE FROM wc_oauthDtl WHERE domainID = p_domainID;
		
			IF row_count()> 0 THEN 
				
                SET v_errMsg = "Deleted Successfully";
                SET v_errCode = 0;
			END IF;
        END IF;
        
	SELECT v_errCode AS errCode, v_errMsg as errMsg;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_deleteTemplateDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_deleteTemplateDtl`(
	p_id			INT,
    p_domainId 		INT
  
)
BEGIN
		DECLARE v_check		INT DEFAULT 0;
        DECLARE v_errCode	INT DEFAULT 1;
        DECLARE v_errMsg	VARCHAR(100) DEFAULT "Failed";
        
        
        SELECT 1 INTO v_check FROM wc_template_master_dtl WHERE domainId = p_domainId AND id = p_id;
        
        IF v_check = 1 THEN
			
            DELETE FROM wc_template_master_dtl WHERE domainId = p_domainId AND id = p_id;
			
            IF ROW_COUNT() > 0 THEN
				SET v_errCode = 0;
				SET v_errMsg = "Deleted Successfully";
			END IF;
            
        END IF;
        
        SELECT  v_errCode AS errCode, v_errMsg AS errMsg;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_deleteWorktualConnectorCcaas` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_deleteWorktualConnectorCcaas`(
	p_domainID  INT
)
BEGIN
		DECLARE v_errMsg 	VARCHAR(50) DEFAULT "Failed";
        DECLARE v_errCode 	INT DEFAULT -1;
        
        IF EXISTS (SELECT 1 FROM wc_worktualConnectorCcaas WHERE domainID = p_domainID) THEN 
			
            DELETE FROM wc_worktualConnectorCcaas WHERE domainID = p_domainID;
		
			IF row_count()> 0 THEN 
				
                SET v_errMsg = "Deleted Successfully";
                SET v_errCode = 0;
			END IF;
        END IF;
        
	SELECT v_errCode AS errCode, v_errMsg as errMsg;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_delete_AI_chat_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_delete_AI_chat_dtl`(
  	p_domainId					INT,
    p_campaignchatid			VARCHAR(200)
  	
  )
BEGIN
  		DECLARE v_errCode		TINYINT			DEFAULT -1;
          DECLARE v_errMsg		VARCHAR(20)		DEFAULT "Failed";
          
          
          IF EXISTS(SELECT 1 FROM wc_AI_convertation_master_details WHERE campaignchatid = p_campaignchatid AND domainId = p_domainId) THEN
  			
              DELETE FROM wc_AI_convertation_master_details
  				WHERE campaignchatid = p_campaignchatid AND domainId = p_domainId AND `status` = "DRAFT";
                  
  			IF ROW_COUNT() > 0 THEN 
  				SET v_errCode 	= 1;
                  SET v_errMsg 	= "Deleted Successfully";
  			END IF;
              
          END IF;
  		
          SELECT v_errCode AS errCode, v_errMsg AS errMsg;
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_delete_campaign_knowledgeBase_file_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_delete_campaign_knowledgeBase_file_details`(
	p_domainId			INT,
    p_unique_id			VARCHAR(50)
)
BEGIN
			DECLARE v_id		INT DEFAULT 0;
            DECLARE v_errMsg	VARCHAR(50) 	DEFAULT 'failed';
            DECLARE v_errCode	SMALLINT 		DEFAULT  -1;
		
			SELECT id INTO v_id FROM wc_tb_campaign_knowledgeBase_file_details 
					WHERE domainId = p_domainId AND unique_id = p_unique_id;
		
			IF v_id !=0 THEN  
					DELETE FROM wc_tb_campaign_knowledgeBase_file_details 
					WHERE id = v_id;
                    
                    IF row_count() > 0 THEN 
						SET v_errMsg = 'Deleted Successfully';
                        SET v_errCode = 0;
					end if;
	
			end if;
            
            
            select v_errCode as errCode, v_errMsg as errMsg;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_delete_campaign_knowledge_base_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_delete_campaign_knowledge_base_dtl`(p_domainId		INT)
BEGIN
 			 DECLARE v_errMsg	VARCHAR(20)	DEFAULT "Failed";
              DECLARE v_errCode	INT DEFAULT -1;
              DECLARE v_kbCampId	INT DEFAULT 0;
              
  			SELECT kbCampId INTO v_kbCampId FROM tb_campaign_knowledge_base_dtl WHERE domainId = p_domainId;
              
              IF v_kbCampId !=0 THEN
  					
                      DELETE FROM tb_campaign_knowledge_base_dtl 
                      WHERE kbCampId = v_kbCampId;
                      
                      IF ROW_COUNT() > 0 THEN 
                      
  						SET v_errMsg = "Deleted";
                          SET v_errCode = 1;
                      
                      END IF;
              
              END IF;
  				
                  
                  SELECT v_errCode AS errCode, v_errMsg as errMsg;
  	
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_delete_customer_contact_custom_field` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_delete_customer_contact_custom_field`(	
	p_cid			INT ,
    p_domainID		INT
)
BEGIN
		 DECLARE v_id 			INT;
         DECLARE v_errMsg		VARCHAR(50) DEFAULT "Failed";
         DECLARE v_errCode		INT DEFAULT -1;
         DECLARE v_tableName	VARCHAR(100);
         DECLARE v_columName	VARCHAR(50);
         
         SELECT id, columName INTO v_id, v_columName FROM wc_customer_contact_column_properties WHERE id = p_cid and domainID = p_domainID;
         
         IF v_id IS NOT NULL THEN
			
            DELETE FROM wc_customer_contact_column_properties WHERE id = v_id and domainID = p_domainID;
            
            IF ROW_COUNT() > 0 THEN
					SET v_errMsg = "Deleted Successfully";
					SET v_errCode = 1;
                    
                    SET v_tableName = CONCAT('customer_contact_',p_domainID);
                    
                    SET @v_preStatment = CONCAT("ALTER TABLE ",v_tableName, " DROP COLUMN ", v_columName);
                    
                    
                    PREPARE stmt FROM @v_preStatment;
                    
                    EXECUTE stmt;
                    
                    DEALLOCATE PREPARE stmt;
                    
			END IF;
            
		END IF;
            SELECT v_errCode AS errCode, v_errMsg AS errMsg;
        
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_delete_knowledge_base_pdf_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_delete_knowledge_base_pdf_dtl`(
p_domainId		INT,
p_uniqueId		varchar(50)
)
begin
			declare v_errMsg varchar(50) default 'failed';
            declare v_errCode smallint default -1;
			declare v_id	int default 0;		
        
				
			select id into v_id from wc_tb_knowledge_base_pdf_dtl where domainId = p_domainId and uniqueId = p_uniqueId;
        
			IF 	v_id != 0 then
            
					delete from wc_tb_knowledge_base_pdf_dtl where id = v_id;
                    
                    if row_count() > 0 then
						set v_errMsg = "Deleted Successfully";
                        set v_errCode = 1;
					end if;
			end if;
            
            select v_errCode as errCode, v_errMsg as errMsg;
       
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_delete_knowledge_base_website_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_delete_knowledge_base_website_dtl`(
     IN p_domainId INT,
     IN p_id INT
 )
BEGIN
   
     DECLARE EXIT HANDLER FOR SQLEXCEPTION
     BEGIN
         ROLLBACK;
      END;
 
     START TRANSACTION;
 
      IF EXISTS ( SELECT 1 FROM wc_tb_knowledge_base_website_dtl WHERE id = p_id AND domainId = p_domainId ) THEN
 
         DELETE FROM wc_tb_knowledge_base_website_dtl WHERE id = p_id;
  
             COMMIT;
   
     END IF;
 
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_GetAdvancefilterCondResultDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_GetAdvancefilterCondResultDtl`(
	p_domain INT,
	p_condition	JSON
)
BEGIN
	DECLARE total_Q INT ;
	DECLARE total_Q1 INT ;
	DECLARE total_Q2 INT ;
	DECLARE count_01 INT;
	DECLARE count_02 INT;

	DECLARE v_errCode	INT DEFAULT -1;
    DECLARE v_errMsg	VARCHAR(100) DEFAULT "Failed";
    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        SELECT v_errCode AS errCode, v_errMsg AS errMsg;
    END;
 
 SET total_Q = 0;
 SET total_Q1 = 0;
 SET total_Q2 = 0;
 
 DROP TEMPORARY TABLE IF EXISTS tt_AdvancefilterCondResultDtl_01 ;
 CREATE TEMPORARY TABLE tt_AdvancefilterCondResultDtl_01 (count1 INT, count2 INT, det1 VARCHAR(200),det2 VARCHAR(100), det3 VARCHAR(200));
 
 DROP TEMPORARY TABLE IF EXISTS tt_AdvancefilterCondResultDtl_02;
 CREATE TEMPORARY TABLE tt_AdvancefilterCondResultDtl_02 (id INT AUTO_INCREMENT, queryCon TEXT, PRIMARY KEY(id));
 
 DROP TEMPORARY TABLE IF EXISTS tt_AdvancefilterCondResultDtl_result;
 CREATE TEMPORARY TABLE tt_AdvancefilterCondResultDtl_result (id INT, domainId int, firstName varchar(100), lastName varchar(100),
  whatsappNumber varchar(30), phoneNumber varchar(30), email varchar(200), customerType varchar(100),
  tags varchar(100), location varchar(100), city varchar(100) , address text, state varchar(100),
  country varchar(100), postCode int , createdAt datetime, updatedAt datetime
 );
 
 
 SET count_01 = (SELECT JSON_length(p_condition));
 
 
 
 WHILE total_Q < count_01  DO
    
   SET count_02 =  (SELECT JSON_length(json_EXTRACT(p_condition, CONCAT('$[',total_Q2,'].Input1') )));
    
		WHILE total_Q1 < count_02 DO
	
				INSERT INTO tt_AdvancefilterCondResultDtl_01 (count1, count2, det1 ,det2, det3) 
				SELECT 
                total_Q, total_Q1,
                JSON_UNQUOTE(JSON_EXTRACT(p_condition, CONCAT('$[',total_Q,'].Input1[',total_Q1,']'))),
						JSON_UNQUOTE(JSON_EXTRACT(p_condition, CONCAT('$[',total_Q,'].Input2[',total_Q1,']')))
						,JSON_UNQUOTE(JSON_EXTRACT(p_condition, CONCAT('$[',total_Q,'].Input3[',total_Q1,']')));
       
		SET total_Q1 = total_Q1 +1;
   
		END WHILE;
    
    SET total_Q2 = total_Q2 +1;
    
    SET total_Q1 = 0;
    
    SET count_02 = 0;
     
	SET total_Q = total_Q +1;
    
END WHILE;



 SET SQL_SAFE_UPDATES = 0;

IF EXISTS(SELECT 1 FROM tt_AdvancefilterCondResultDtl_01 WHERE det2 = 'is')THEN
	UPDATE tt_AdvancefilterCondResultDtl_01 SET det2 = '=', det3 = QUOTE(det3) WHERE det2 = 'is';
END IF;

IF EXISTS(SELECT 1 FROM tt_AdvancefilterCondResultDtl_01 WHERE det2 = 'isNot')THEN
	UPDATE tt_AdvancefilterCondResultDtl_01 SET det2 = '!=' , det3 = QUOTE(det3) WHERE det2 = 'isNot';
END IF;

IF EXISTS(SELECT 1 FROM tt_AdvancefilterCondResultDtl_01 WHERE det2 = 'startsWith')THEN
	UPDATE tt_AdvancefilterCondResultDtl_01 SET det2 = 'LIKE', det3 = QUOTE(CONCAT(det3,'%')) WHERE det2 = 'startsWith';
END IF;

IF EXISTS(SELECT 1 FROM tt_AdvancefilterCondResultDtl_01 WHERE det2 = 'endsWith')THEN
	UPDATE tt_AdvancefilterCondResultDtl_01 SET det2 = 'LIKE', det3 = QUOTE(CONCAT('%',det3)) WHERE det2 = 'endsWith';
END IF;

IF EXISTS(SELECT 1 FROM tt_AdvancefilterCondResultDtl_01 WHERE det2 = 'in')THEN
	UPDATE tt_AdvancefilterCondResultDtl_01 SET  det3 = REPLACE(REPLACE(det3,'[','('), ']',')') WHERE det2 = 'in';
END IF;

IF EXISTS(SELECT 1 FROM tt_AdvancefilterCondResultDtl_01 WHERE det2 = 'notIN')THEN
	UPDATE tt_AdvancefilterCondResultDtl_01 SET  det3 = REPLACE(REPLACE(det3,'[','('), ']',')') WHERE det2 = 'notIN';
END IF;

IF EXISTS(SELECT 1 FROM tt_AdvancefilterCondResultDtl_01 WHERE det2 = 'contains')THEN
	UPDATE tt_AdvancefilterCondResultDtl_01 SET det2 = 'LIKE',  det3 = QUOTE(CONCAT('%',det3,'%')) WHERE det2 = 'contains';
END IF;

IF EXISTS(SELECT 1 FROM tt_AdvancefilterCondResultDtl_01 WHERE det2 = 'doesNotContain')THEN
	UPDATE tt_AdvancefilterCondResultDtl_01 SET det2 = 'NOT LIKE',  det3 = QUOTE(CONCAT('%',det3,'%')) WHERE det2 = 'doesNotContain';
END IF;

IF EXISTS(SELECT 1 FROM tt_AdvancefilterCondResultDtl_01 WHERE det2 = 'between')THEN
	UPDATE tt_AdvancefilterCondResultDtl_01 SET det3 = REPLACE(REPLACE(REPLACE(det3,',',' AND'),'[',''),']','') WHERE det2 = 'between';
END IF;

IF EXISTS(SELECT 1 FROM tt_AdvancefilterCondResultDtl_01 WHERE det2 = 'within')THEN
	UPDATE tt_AdvancefilterCondResultDtl_01 SET 
		det1 = 'TIME(createdAt)' ,
        det2 = 'between' ,
		det3 = REPLACE(REPLACE(REPLACE(det3,',',' AND'),'[',''),']','') 
    WHERE det2 = 'within';
END IF;

SET SQL_SAFE_UPDATES = 1;



SET count_02 = (SELECT MAX(count1) FROM tt_AdvancefilterCondResultDtl_01);

 WHILE total_Q1 <= count_02  do
	
    INSERT INTO tt_AdvancefilterCondResultDtl_02 (queryCon)
 
SELECT CONCAT('INSERT INTO tt_AdvancefilterCondResultDtl_result ( id, domainId , firstName, lastName, whatsappNumber , phoneNumber , email , customerType ,
  tags , location , city  , address , state , country , postCode  , createdAt , updatedAt  )
					SELECT id, domainId , firstName, lastName, whatsappNumber , phoneNumber , email , customerType ,
  tags , location , city  , address , state , country , postCode  , createdAt , updatedAt 
  FROM wc_user_contact_dtl WHERE domainId = ',p_domain,' AND ',GROUP_CONCAT(CONCAT(det1," ", det2," ",det3)SEPARATOR ' AND ')) FROM tt_AdvancefilterCondResultDtl_01 WHERE count1 = total_Q1 ;
	SET total_Q1 = total_Q1 +1;
    

    
END WHILE;

	SET total_Q1 = 1;
    
    
	
    
	
    SPinn: WHILE total_Q1 <= count_01 DO
					
                    
						SET @v_sql_query = (SELECT queryCon FROM tt_AdvancefilterCondResultDtl_02 WHERE id = total_Q1);
						PREPARE stmt FROM @v_sql_query;
					 	EXECUTE stmt;
						DEALLOCATE PREPARE stmt;
					
                    IF EXISTS(SELECt 1 FROM tt_AdvancefilterCondResultDtl_result) THEN 
							SELECT * FROM tt_AdvancefilterCondResultDtl_result;
                            SET v_errCode = 0;
							SET v_errMsg =  "Success";
                            LEAVE SPinn;
					ELSE
						SET total_Q1 = total_Q1+1;
					END IF;
			END WHILE;
		
        IF total_Q1 > count_01 THEN
			SET v_errCode = -2;
			SET v_errMsg =  "Record not found";
        END IF;
        
	SELECT v_errCode AS errCode, v_errMsg AS errMsg;
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_GetAdvancefilterCondResultDtl_altered` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_GetAdvancefilterCondResultDtl_altered`(
	p_domain INT,
	p_condition	JSON
)
BEGIN
	DECLARE total_Q INT ;
	DECLARE total_Q1 INT ;
	DECLARE total_Q2 INT ;
	DECLARE count_01 INT;
	DECLARE count_02 INT;

	DECLARE v_errCode	INT DEFAULT -1;
    DECLARE v_errMsg	VARCHAR(100) DEFAULT "Failed";
    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        SELECT v_errCode AS errCode, v_errMsg AS errMsg;
    END;
 
 SET total_Q = 0;
 SET total_Q1 = 0;
 SET total_Q2 = 0;
 
 DROP TEMPORARY TABLE IF EXISTS tt_AdvancefilterCondResultDtl_01 ;
 CREATE TEMPORARY TABLE tt_AdvancefilterCondResultDtl_01 (count1 INT, count2 INT, det1 VARCHAR(200),det2 VARCHAR(100), det3 VARCHAR(200));
 
 DROP TEMPORARY TABLE IF EXISTS tt_AdvancefilterCondResultDtl_02;
 CREATE TEMPORARY TABLE tt_AdvancefilterCondResultDtl_02 (id INT AUTO_INCREMENT, queryCon TEXT, PRIMARY KEY(id));
 
 DROP TEMPORARY TABLE IF EXISTS tt_AdvancefilterCondResultDtl_result;
 CREATE TEMPORARY TABLE tt_AdvancefilterCondResultDtl_result (id INT, domainId int, firstName varchar(100), lastName varchar(100),
  whatsappNumber varchar(30), phoneNumber varchar(30), email varchar(200), customerType varchar(100),
  tags varchar(100), location varchar(100), city varchar(100) , address text, state varchar(100),
  country varchar(100), postCode int , createdAt datetime, updatedAt datetime
 );
 
 
 SET count_01 = (SELECT JSON_length(p_condition));
 
 
 
 WHILE total_Q < count_01  DO
    
   SET count_02 =  (SELECT JSON_length(json_EXTRACT(p_condition, CONCAT('$[',total_Q2,'].Input1') )));
    
		WHILE total_Q1 < count_02 DO
	
				INSERT INTO tt_AdvancefilterCondResultDtl_01 (count1, count2, det1 ,det2, det3) 
				SELECT 
                total_Q, total_Q1,
                JSON_UNQUOTE(JSON_EXTRACT(p_condition, CONCAT('$[',total_Q,'].Input1[',total_Q1,']'))),
						JSON_UNQUOTE(JSON_EXTRACT(p_condition, CONCAT('$[',total_Q,'].Input2[',total_Q1,']')))
						,JSON_UNQUOTE(JSON_EXTRACT(p_condition, CONCAT('$[',total_Q,'].Input3[',total_Q1,']')));
       
		SET total_Q1 = total_Q1 +1;
   
		END WHILE;
    
    SET total_Q2 = total_Q2 +1;
    
    SET total_Q1 = 0;
    
    SET count_02 = 0;
     
	SET total_Q = total_Q +1;
    
END WHILE;



 SET SESSION SQL_SAFE_UPDATES = 0;

IF EXISTS(SELECT 1 FROM tt_AdvancefilterCondResultDtl_01 WHERE det2 = 'is')THEN
	UPDATE tt_AdvancefilterCondResultDtl_01 SET det2 = '=', det3 = QUOTE(det3) WHERE det2 = 'is';
END IF;

IF EXISTS(SELECT 1 FROM tt_AdvancefilterCondResultDtl_01 WHERE det2 = 'isNot')THEN
	UPDATE tt_AdvancefilterCondResultDtl_01 SET det2 = '!=' , det3 = QUOTE(det3) WHERE det2 = 'isNot';
END IF;

IF EXISTS(SELECT 1 FROM tt_AdvancefilterCondResultDtl_01 WHERE det2 = 'startsWith')THEN
	UPDATE tt_AdvancefilterCondResultDtl_01 SET det2 = 'LIKE', det3 = QUOTE(CONCAT(det3,'%')) WHERE det2 = 'startsWith';
END IF;

IF EXISTS(SELECT 1 FROM tt_AdvancefilterCondResultDtl_01 WHERE det2 = 'endsWith')THEN
	UPDATE tt_AdvancefilterCondResultDtl_01 SET det2 = 'LIKE', det3 = QUOTE(CONCAT('%',det3)) WHERE det2 = 'endsWith';
END IF;

IF EXISTS(SELECT 1 FROM tt_AdvancefilterCondResultDtl_01 WHERE det2 = 'in')THEN
	UPDATE tt_AdvancefilterCondResultDtl_01 SET  det3 = REPLACE(REPLACE(det3,'[','('), ']',')') WHERE det2 = 'in';
END IF;

IF EXISTS(SELECT 1 FROM tt_AdvancefilterCondResultDtl_01 WHERE det2 = 'notIN')THEN
	UPDATE tt_AdvancefilterCondResultDtl_01 SET  det3 = REPLACE(REPLACE(det3,'[','('), ']',')') WHERE det2 = 'notIN';
END IF;

IF EXISTS(SELECT 1 FROM tt_AdvancefilterCondResultDtl_01 WHERE det2 = 'contains')THEN
	UPDATE tt_AdvancefilterCondResultDtl_01 SET det2 = 'LIKE',  det3 = QUOTE(CONCAT('%',det3,'%')) WHERE det2 = 'contains';
END IF;

IF EXISTS(SELECT 1 FROM tt_AdvancefilterCondResultDtl_01 WHERE det2 = 'doesNotContain')THEN
	UPDATE tt_AdvancefilterCondResultDtl_01 SET det2 = 'NOT LIKE',  det3 = QUOTE(CONCAT('%',det3,'%')) WHERE det2 = 'doesNotContain';
END IF;

IF EXISTS(SELECT 1 FROM tt_AdvancefilterCondResultDtl_01 WHERE det2 = 'between')THEN
	UPDATE tt_AdvancefilterCondResultDtl_01 SET det3 = REPLACE(REPLACE(REPLACE(det3,',',' AND'),'[',''),']','') WHERE det2 = 'between';
END IF;

IF EXISTS(SELECT 1 FROM tt_AdvancefilterCondResultDtl_01 WHERE det2 = 'within')THEN
	UPDATE tt_AdvancefilterCondResultDtl_01 SET 
		det1 = 'TIME(createdAt)' ,
        det2 = 'between' ,
		det3 = REPLACE(REPLACE(REPLACE(det3,',',' AND'),'[',''),']','') 
    WHERE det2 = 'within';
END IF;





SET count_02 = (SELECT MAX(count1) FROM tt_AdvancefilterCondResultDtl_01);

 WHILE total_Q1 <= count_02  do
	
    INSERT INTO tt_AdvancefilterCondResultDtl_02 (queryCon)
 
SELECT CONCAT('INSERT INTO tt_AdvancefilterCondResultDtl_result ( id, domainId , firstName, lastName, whatsappNumber , phoneNumber , email , customerType ,
  tags , location , city  , address , state , country , postCode  , createdAt , updatedAt  )
					SELECT id, domainId , firstName, lastName, whatsappNumber , phoneNumber , email , customerType ,
  tags , location , city  , address , state , country , postCode  , createdAt , updatedAt 
  FROM wc_user_contact_dtl WHERE domainId = ',p_domain,' AND ',GROUP_CONCAT(CONCAT(det1," ", det2," ",det3)SEPARATOR ' AND ')) FROM tt_AdvancefilterCondResultDtl_01 WHERE count1 = total_Q1 ;
	SET total_Q1 = total_Q1 +1;
    

    
END WHILE;

	SET total_Q1 = 1;
    
    
	
    
    
   
	
    SPinn: WHILE total_Q1 <= count_01 DO
					
                    
						SET @v_sql_query = (SELECT queryCon FROM tt_AdvancefilterCondResultDtl_02 WHERE id = total_Q1);
						PREPARE stmt FROM @v_sql_query;
					 	EXECUTE stmt;
			
					
                
                    
                    IF EXISTS(SELECt 1 FROM tt_AdvancefilterCondResultDtl_result) THEN 
						
                            SET v_errCode = 0;
							SET v_errMsg =  "Success";
                            LEAVE SPinn;
					ELSE
						SET total_Q1 = total_Q1+1;
					END IF;
			END WHILE;
		
        IF total_Q1 > count_01 THEN
			SET v_errCode = -2;
			SET v_errMsg =  "Record not found";
        END IF;
        
	
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_getAllCampaignDashboardDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_getAllCampaignDashboardDtl`(
	p_domainId 				INT,
    p_fromDate				DATETIME,
    p_toDate				DATETIME	
    
)
BEGIN

		DECLARE v_toDate  				DATETIME;
	
		
		SET v_toDate = date_format(p_toDate,"%y-%m-%d 23:59:59");
        
       
			
		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
			
            DROP temporary table if exists tt_AllCampaignDtl;
            CREATE TEMPORARY TABLE tt_AllCampaignDtl
            SELECT "Whatsapp"as `Mode`, id as campaignId, triggerType, CASE WHEN cloneStatus IS NULL AND triggerType = 0 THEN 1 ELSE cloneStatus END AS cloneStatus, 
            createdDate, scheduleDate
				FROM  wc_campaign_master_dtl 
				WHERE domainId =  p_domainId AND createdDate BETWEEN p_fromDate AND v_toDate;
            
            
            INSERT INTO tt_AllCampaignDtl
            SELECT "SMS", t1.id , t1.triggerType ,  CASE WHEN t2.sentStatus IS NULL AND t1.triggerType = 0 THEN 1 ELSE t2.sentStatus END AS cloneStatus, t1.createdDate, t2.schedulefromDate
				FROM  sc_campaign_master_dtl t1
				JOIN sc_campaign_master_schedule_dtl t2 ON t1.id = t2.campaignId 
				WHERE t1.domainId =  p_domainId 
					AND t1.createdDate BETWEEN p_fromDate AND v_toDate;
                    
            INSERT INTO tt_AllCampaignDtl
            SELECT "Email", campaignId, emailDelivery, `status`, 
            createdate , emailDeliveryAt 
				FROM  ec_email_campaign_master_dtl 
				WHERE domainId =  p_domainId AND createdate BETWEEN p_fromDate AND v_toDate;
                
       
			
			
            
            SELECT `Mode`, count(campaignId) as `count` FROM tt_AllCampaignDtl
            GROUP BY `Mode`;
            
			SELECT  `Mode`,
					SUM(CASE WHEN MONTH(scheduleDate)= 1 THEN 1 ELSE 0 END )AS "JAN",
                    SUM(CASE WHEN MONTH(scheduleDate)= 2 THEN 1 ELSE 0 END )AS "FEB",
                    SUM(CASE WHEN MONTH(scheduleDate)= 3 THEN 1 ELSE 0 END )AS "MAR",
                    SUM(CASE WHEN MONTH(scheduleDate)= 4 THEN 1 ELSE 0 END )AS "APR",
                    SUM(CASE WHEN MONTH(scheduleDate)= 5 THEN 1 ELSE 0 END )AS "MAY",
                    SUM(CASE WHEN MONTH(scheduleDate)= 6 THEN 1 ELSE 0 END )AS "JUN",
                    SUM(CASE WHEN MONTH(scheduleDate)= 7 THEN 1 ELSE 0 END )AS "JUL",
                    SUM(CASE WHEN MONTH(scheduleDate)= 8 THEN 1 ELSE 0 END )AS "AUG",
                    SUM(CASE WHEN MONTH(scheduleDate)= 9 THEN 1 ELSE 0 END )AS "SEP",
                    SUM(CASE WHEN MONTH(scheduleDate)= 10 THEN 1 ELSE 0 END )AS "OCT",
                    SUM(CASE WHEN MONTH(scheduleDate)= 11 THEN 1 ELSE 0 END) AS "NOV",
                    SUM(CASE WHEN MONTH(scheduleDate)= 12 THEN 1 ELSE 0 END) AS "DEC"
            FROM tt_AllCampaignDtl 
             WHERE cloneStatus = 1
            GROUP BY `Mode`;
            
            
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_GetBusinessAccountInfo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_GetBusinessAccountInfo`(
	p_domainId INT,
    p_mobileNumber varchar(30)
)
begin

		SELECT * FROM wc_business_configuration 
        WHERE domainId = p_domainId 
        AND (mobileNumber = p_mobileNumber or ifnull(p_mobileNumber,'')='');
        
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_GetCampaignMasterDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_GetCampaignMasterDtl`(
	p_domainId			INT,
    p_campName			VARCHAR(150)
)
BEGIN
	SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    SELECT   id, domainId,
  `campName` AS "campaignName", `campType`AS "campaignType" , `contactList`,
  `template` AS "templateName", `templateId` , `triggerType` , `lastRecurrentDate` , `scheduleDate` ,
  `cloneStatus`, `templateData`, createdDate, optimalType, campaignStatus
    FROM wc_campaign_master_dtl WHERE domainId = p_domainId AND (campName = p_campName OR IFNULL(p_campName,'') = '')
    ORDER BY createdDate DESC
    ;
      
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_getCampaignTagDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_getCampaignTagDtl`(	
 	p_domainId 	INT
 )
BEGIN
 
		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
 		
         SELECT DISTINCT t1.Tags FROM wc_campaignTagDtl t1
			JOIN wc_TagCampMapping t2 ON t1.TagId = t2.TagId
 			WHERE domainId = p_domainId;
 
		SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_getConfigurationMobileWabaDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_getConfigurationMobileWabaDtl`(p_domainId		INT)
BEGIN
	SELECT mobileNumber, wabaId FROM wc_business_configuration
    WHERE domainId = p_domainId;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_getContactDtlFromMasterList` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_getContactDtlFromMasterList`(p_id INT)
BEGIN

		SELECT contactList  FROM wc_contact_list_master_dtl WHERE id = p_id ;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_getContactInformationDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_getContactInformationDtl`(
   	p_domainId		INT,
     p_offset	    INT,
     p_limit			INT
   )
BEGIN
 		
        IF  p_offset is null and p_limit is null then 
        
 			SELECT id, domainId ,firstName ,lastName ,whatsappNumber ,phoneNumber ,email ,customerType ,tags ,location ,city ,address ,state
 					,country ,postCode ,createdAt ,updatedAt, `source`, deviceId, deviceOS, sip_log_id, extension, 
 					CONCAT(firstName," ",lastName) AS `Name`, lifeCycleStage, pushNotificationId, istempCustomer,
                     isUnSub_Whatsapp, isUnSub_SMS, isUnSub_Email, isUnSub_AppPush, isUnSub_WebPush, isUnSub_InApp, industryType, jobTitle, companyName
 					FROM wc_user_contact_dtl
 				WHERE domainId = p_domainId OR IFNULL(p_domainId, '')= ''
 				order by createdAt desc;
 		ELSE
 				SELECT id, domainId ,firstName ,lastName ,whatsappNumber ,phoneNumber ,email ,customerType ,tags ,location ,city ,address ,state
 					,country ,postCode ,createdAt ,updatedAt, `source`, deviceId, deviceOS, sip_log_id, extension, 
 					CONCAT(firstName," ",lastName) AS `Name`, lifeCycleStage, pushNotificationId, istempCustomer
                     isUnSub_Whatsapp, isUnSub_SMS, isUnSub_Email, isUnSub_AppPush, isUnSub_WebPush, isUnSub_InApp, industryType, jobTitle, companyName
 					FROM wc_user_contact_dtl
 				WHERE (domainId = p_domainId OR IFNULL(p_domainId, '')= '') AND istempCustomer = 0
 				order by createdAt desc LIMIT p_offset, p_limit;
 		END IF;
   END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_getCroneDtlBasedOnTime` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_getCroneDtlBasedOnTime`()
BEGIN
  	DECLARE v_currentTime	DATETIME;
      
  	SET v_currentTime = CAST(DATE_FORMAT(CONVERT_TZ(CURRENT_TIMESTAMP(),'+00:00', '+05:30'), "%y-%m-%d %h:%i:00") AS DATETIME);
      
  	 
      
      DROP TEMPORARY TABLE IF EXISTS tt_cloneDtl;
  	CREATE TEMPORARY TABLE tt_cloneDtl
  		select md.*
 		FROM wc_campaign_master_dtl as md
 		left JOIN wc_master_revert_status_details	as rs
 		ON	md.campaignchatId = rs.campaignchatId
 		WHERE CAST(DATE_FORMAT(md.scheduleDate, '%y-%m-%d %h:%i:00')AS DATETIME)  <= now()
 				AND md.triggerType IN(1, 2) 
 				 AND IFNULL(md.cloneStatus, 0) != 1
 				AND rs.campaignchatId IS NULL;
     
  
     SELECT id, domainId, campName AS "campaignName", campType AS "campaignType", contactList, template AS "templateName", templateId,
     triggerType, scheduleDate, cloneStatus, createdDate, updatedDate, templateData FROM tt_cloneDtl;
      
      UPDATE wc_campaign_master_dtl t1 join
      tt_cloneDtl t2 ON t1.id = t2.id  
      SET t1.cloneStatus = 1;
      
  
   END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_getCroneDtlBasedOnTimeRecurrent` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_getCroneDtlBasedOnTimeRecurrent`()
BEGIN
	DECLARE v_currentDate			DATETIME;
  
    DECLARE v_recurrentStartDate	DATE;
    DECLARE v_recurrentEndDate		DATE;
    
    SET v_currentDate = CONVERT_TZ(CURRENT_TIMESTAMP(),"+00:00", "+05:11");

 
    
   
   
    
     DROP TEMPORARY TABLE IF EXISTS tt_cloneDtlRecurrent;
	 CREATE TEMPORARY TABLE tt_cloneDtlRecurrent(
		SELECT
			t1.id, 
            t1.domainId,  
            t1.campName, 
            t1.campType, 
            t1.contactList,  
            t1.template, 
            t1.scheduleDate,
            t1.recurring,
            t1.triggerType,
            t1.templateId,
            t1.lastRecurrentDate, 
            t1.cloneStatus, 
            t1.listId, 
            t1.listName, 
            t1.templateData,
            j.hours,
            j.mins,
			date_add(date_add(j.startDate , interval j.hours hour), interval j.mins  minute) AS startDate,
			date_add(date_add(j.endDate, interval j.hours hour), interval j.mins  minute) AS endDate
		FROM wc_campaign_master_dtl t1,  
			JSON_TABLE( JSON_ARRAY(recurring), '$[*]' 
            COLUMNS( hours INT path'$.hour', mins INT path'$.mins', endDate DATETIME path'$.endDate', startDate DATETIME path'$.startDate'))as j
		WHERE t1.triggerType = 3  
			AND (DATE(v_currentDate) BETWEEN  j.startDate AND j.endDate)
			AND TIME_FORMAT(v_currentDate, "%H:%i:00") = TIME_FORMAT(CONCAT(lpad(j.hours, 2, 0),":",Lpad(j.mins, 2, 0),":00"), "%H:%i:00")		
			AND IFNULL(t1.cloneStatus, 0) != 1 
			AND (IFNULL(t1.lastRecurrentDate, '')= '' OR  t1.lastRecurrentDate != DATE(v_currentDate)));

	


   SELECT id, domainId, campName AS "campaignName", campType AS "campaignType", contactList, template AS "templateName",
			templateId, recurring, triggerType, lastRecurrentDate, scheduleDate,cloneStatus, listId, listName, templateData
   FROM tt_cloneDtlRecurrent;
   
  
   
    SELECT startDate, endDate INTO	v_recurrentStartDate, v_recurrentEndDate
    FROM tt_cloneDtlRecurrent;
    
    
	IF EXISTS (SELECT 1 FROM tt_cloneDtlRecurrent) THEN
       IF (DATE(v_currentDate) = v_recurrentEndDate AND v_recurrentEndDate IS NOT NULL)  THEN
			UPDATE wc_campaign_master_dtl
			SET cloneStatus = 1,
				lastRecurrentDate = DATE(v_currentDate)
			WHERE id IN (SELECT id FROM tt_cloneDtlRecurrent WHERE date(endDate) = v_currentDate);
		
		ELSE
			 UPDATE wc_campaign_master_dtl 
			 SET lastRecurrentDate = DATE(v_currentDate)
			 WHERE id IN (SELECT id FROM tt_cloneDtlRecurrent WHERE date(endDate) != v_currentDate);
		
        END IF;
	
    END IF;
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_getCustomerListConditionDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_getCustomerListConditionDtl`(
	p_id 		INT,
    p_domainId	INT
)
BEGIN	
			
			
		DECLARE v_getCid 		INT;
        DECLARE v_getCodition	JSON; 
        DECLARE v_getNewResult  JSON;
        DECLARE v_listType 		INT ;
        
		SELECT  conditionId, listType INTO  v_getCid, v_listType FROM wc_contact_list_master_dtl   
 				WHERE domainId = p_domainId AND id = p_id ;
                
		 SELECT filterCond INTO v_getCodition 
				FROM wc_contact_list_condition_dtl
				WHERE domainId = p_domainId AND cid = v_getCid  ;	
                
		
        
        IF v_listType = 2 THEN 
        
        call wc_GetAdvancefilterCondResultDtl_altered(p_domainId, v_getCodition);
        
        SELECT JSON_ARRAYAGG( JSON_OBJECT('id', id, 'domainId', domainId, 'firstName', firstName, 
                'lastName', IFNULL(lastName,''), 'whatsappNumber', whatsappNumber, 'phoneNumber', IFNULL(phoneNumber,''), 
                'email', IFNULL(email,''), 'customerType', IFNULL(customerType,''), 'tags', IFNULL(tags,''), 
                'location', IFNULL(location,''),'city', IFNULL(city,''), 'address', IFNULL(address,''), 
                'state', IFNULL(state,''), 'country', IFNULL(country,''), 'postCode', IFNULL(postCode,''),
                'createdAt', createdAt, 'updatedAt', IFNULL(updatedAt, ''))
				) INTO v_getNewResult
		FROM tt_AdvancefilterCondResultDtl_result;
        
			IF v_getNewResult IS NOT NULL THEN
        
				UPDATE wc_contact_list_master_dtl SET contactList = v_getNewResult
					WHERE id = p_id and domainId = p_domainId;
       
			END IF;
            
       END IF;
       
			SELECT * FROM wc_contact_list_master_dtl
			WHERE domainId = p_domainId AND id = p_id; 
         
			SELECT * FROM wc_contact_list_condition_dtl
			WHERE domainId = p_domainId  AND cid = v_getCid  ;																			
          
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_getCustomerTagDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_getCustomerTagDtl`(p_domainId INT)
BEGIN
	SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
		
        SELECT  ctgid,domainId, ctgName, ctgDesc, ctgStatus, createdAt, updatedAt
			FROM  wc_customerTag WHERE domainId = p_domainId;
        
	SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_getCustomerTypeDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_getCustomerTypeDtl`(p_domainId INT)
BEGIN
	SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
		
        SELECT  ctid, domainId, ctName, ctDesc, ctStatus, createdAt, updatedAt
			FROM  wc_customerType
            WHERE domainId = p_domainId
            ;
        
	SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_getDashboardTemplateStatus` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_getDashboardTemplateStatus`(
	p_domainId			INT,
    p_fromDate			DATETIME,
	p_endDate			DATETIME,
    p_limit				INT,
	p_offset			INT
)
BEGIN
		DECLARE v_offset	INT;
        
        SET v_offset = p_offset * p_limit;
        
		
		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        
        SELECT templateName, DATE(createdAt) as createdDate, `status`, category as "campaignType" FROM wc_template_master_dtl
        WHERE domainId = p_domainId
        AND(createdAt BETWEEN p_fromDate AND p_endDate)
        LIMIT v_offset, p_limit;
        
        
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
        
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_getListDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_getListDtl`(
	p_id 		INT,
    p_domainId	INT
)
BEGIN
	
    SELECT * FROM wc_contact_list_master_dtl
    WHERE domainId = p_domainId AND (id = p_id OR IFNULL(p_id, '') = '');
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_getListFilterOptionDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`crmdev`@`%` PROCEDURE `wc_getListFilterOptionDtl`( p_domainId INT)
BEGIN
	
    SELECT DISTINCT customerType 	FROM wc_user_contact_dtl WHERE domainId = p_domainId AND customerType IS NOT NULL AND customerType != "";
    SELECT DISTINCT tags 			FROM wc_user_contact_dtl WHERE domainId = p_domainId AND tags IS NOT NULL AND tags != "";  
    SELECT DISTINCT location 		FROM wc_user_contact_dtl WHERE domainId = p_domainId AND location IS NOT NULL AND location != "";
    SELECT DISTINCT city 			FROM wc_user_contact_dtl WHERE domainId = p_domainId AND city IS NOT NULL AND city != "";
    SELECT DISTINCT state 			FROM wc_user_contact_dtl WHERE domainId = p_domainId AND state IS NOT NULL AND state != "";
    SELECT DISTINCT country 		FROM wc_user_contact_dtl WHERE domainId = p_domainId AND country IS NOT NULL AND country != "";
    SELECT DISTINCT postCode 		FROM wc_user_contact_dtl WHERE domainId = p_domainId AND postCode IS NOT NULL AND postCode != "";
        
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_GetMasterTemplateDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_GetMasterTemplateDtl`(
	p_domainId			INT,
	p_templateName		varchar(150)
)
BEGIN
		
        SELECT id, createdAt, domainId, templateName, whatsappAccount, category, language, headerType, headerValue, message As bodymessage,
				footer, buttonType, status, variable, updatedAt, case when clonedfrom is null then 0 else clonedfrom end as cloneId,
                templateId
		FROM wc_template_master_dtl
        WHERE domainId =p_domainId AND (templateName= p_templateName OR ifnull(p_templateName,'')= '')
        ORDER BY createdAt DESC  
        ;
        
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_getTemporaryContactDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_getTemporaryContactDtl`(	p_domainId				INT,
 	p_istempCustomer		varchar(300)	
 )
BEGIN
 		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
 
 		select   `id` , `domainId` , `firstName` , `lastName` , `whatsappNumber` , `phoneNumber` , `email` , `customerType` , `tags` , `location` , `city` , `address` ,
 				`state` , `country` , `postCode` , `istempCustomer` , `createdAt` ,  `source` , `deviceId` , `deviceOS` , `pushNotificationId` , `sip_log_id` ,
 				`extension` , `lifeCycleStage` , `isUnSub_Whatsapp` , `isUnSub_SMS` , `isUnSub_Email` , `isUnSub_AppPush` , `isUnSub_WebPush` , `isUnSub_InApp`, industryType, jobTitle, companyName
 		FROM wc_user_contact_dtl
 				WHERE  (IFNULL(p_domainId, '') = '' OR domainId = p_domainId) AND istempCustomer = p_istempCustomer;
 	
 		SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_getUserContactDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_getUserContactDtl`(p_domainId 		INT)
BEGIN

		SET SESSION transaction isolation level read uncommitted;
		SELECT * FROM wc_user_contact_dtl
        WHERE domainId = p_domainId;
        
        SET SESSION transaction isolation level repeatable read;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_getWhatappIdAndAuthtokenDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_getWhatappIdAndAuthtokenDtl`(
 	p_templateName 		VARCHAR(150),
     p_domainId			INT
 )
BEGIN
 	DECLARE v_getWhatsapp		varchar(200);
     
     SELECT whatsappAccount INTO v_getWhatsapp FROM wc_template_master_dtl WHERE domainId = p_domainId 
 				AND templateName = p_templateName;
 			
 	IF v_getWhatsapp IS NOT NULL THEN	
 		
             SELECT phoneNumberId , authToken, mobileNumber FROM wc_business_configuration WHERE mobileNumber = v_getWhatsapp;
             
 	END IF;
     
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_getWhatsappTagDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_getWhatsappTagDtl`(p_domainId INT)
BEGIN
	SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
		
        SELECT  Tags
			FROM  wc_campaignTagDtl WHERE domainId = p_domainId;
        
	SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_getworktualConnectorCcaas` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_getworktualConnectorCcaas`(
p_domainId		INT
)
BEGIN

		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        
		SELECT  `id` ,`domainId`,`clientId` ,`clientSecret`,`createdOn`,`updatedOn`
		FROM wc_worktualConnectorCcaas where domainId = p_domainId;
    
		SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_get_admin_temp_dtl_for_all_channel` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_get_admin_temp_dtl_for_all_channel`(
		 p_domainId				INT,
		 p_campaignchatid		VARCHAR(300)
)
BEGIN
		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
			
            SELECT campaignchatid,
					case when instr(campaignchatid, 'Email') = 1 then 'Email'
						 when instr(campaignchatid, 'Sms') = 1		then 'SMS'
                         when instr(campaignchatid, 'Whatsapp') = 1 then 'Whatsapp'
                         when instr(campaignchatid, 'Apppush') = 1	then 'AppPush'
                         when instr(campaignchatid, 'Webpush') = 1	then 'WebPush'
                         when instr(campaignchatid, 'inapp') = 1	then 'InApp' end as 'Channel', 
					`Name`,  
                    AItemplateA as 'template' 
				FROM ec_email_campaign_master_dtl
				WHERE domainId = p_domainId AND campaignchatid LIKE CONCAT('%',p_campaignchatid) 
                HAVING `Channel` is not null;

        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_get_AI_chat_archieve_dtl_for_ccaas_CMPGN` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_get_AI_chat_archieve_dtl_for_ccaas_CMPGN`(
	p_domainId		INT 
)
BEGIN

		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        
		SELECT id, campaignchatid, conversationName, updatedOn 
			FROM wc_AI_convertation_master_details
        WHERE domainId =  p_domainId AND team = 1 AND `status` = 'DRAFT' AND isArchieve = 1
        ORDER BY updatedOn DESC
        ;
        
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_get_AI_chat_convo_for_ccaas_CMPGN` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_get_AI_chat_convo_for_ccaas_CMPGN`(
  	p_id					INT,
  	p_domainId				INT,
      p_campaignchatid		VARCHAR(300)
  )
BEGIN
  
  		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
          
  		SELECT id ,campaignchatid ,domainId ,conversationName ,conversation ,team ,`status` ,createdOn ,updatedOn
  			FROM wc_AI_convertation_master_details
          WHERE id = p_id AND domainId =  p_domainId AND campaignchatid = p_campaignchatid;
          
          SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_get_AI_chat_dtl_for_ccaas_CMPGN` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_get_AI_chat_dtl_for_ccaas_CMPGN`(
 	p_domainId		INT 
 )
BEGIN
 
 		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
         
		 -- SELECT a.id, a.campaignchatid, a.conversationName FROM wc_AI_convertation_master_details a left join ec_email_campaign_master_dtl b 			on a.campaignchatid != b.campaignchatid WHERE a.domainId =  p_domainId AND a.team = 1 AND a.`status` = 'DRAFT' AND a.isArchieve = 0          order by a.updatedOn DESC;
		 
		  SELECT  a.id, a.campaignchatid, a.conversationName
FROM wc_AI_convertation_master_details a
WHERE a.domainId = p_domainId AND a.team = 1 AND a.`status` = 'DRAFT' AND a.isArchieve = 0
  AND NOT EXISTS (
        SELECT 1
        FROM ec_email_campaign_master_dtl b
        WHERE b.campaignchatid = a.campaignchatid
  )
ORDER BY a.updatedOn DESC;

		 
         SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_get_AI_convertation_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_get_AI_convertation_details`(
 	p_domainId			INT
 )
BEGIN
 
 		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
 
 		SELECT 
 				campaignchatid, domainId, conversation, `status`, createdOn, updatedOn
         FROM
 				wc_AI_convertation_master_details WHERE domainId =  p_domainId; 
           
 		SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_get_AI_convertation_details_using_chatId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_get_AI_convertation_details_using_chatId`(
      p_campaignchatid	VARCHAR(300),
      p_domainId		INT,
      p_team			TINYINT,
      p_status			VARCHAR(50)	
    )
BEGIN
    
    		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    
    		SELECT *
            FROM
    				wc_AI_convertation_master_details 
				WHERE campaignchatid = p_campaignchatid AND domainId = p_domainId AND team = p_team AND `status` = p_status; 
              
    		SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_get_AI_convertation_details_using_domainId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_get_AI_convertation_details_using_domainId`(
   	p_domainId			INT
   )
BEGIN
   
   		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   
   		SELECT 
   				campaignchatid, conversationName
           FROM
   				wc_AI_convertation_master_details WHERE domainId =  p_domainId AND team = 1 AND `status` = "draft"; 
             
   		SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_get_AI_convertation_using_chatId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_get_AI_convertation_using_chatId`(
 		p_domainId			INT,
     	p_campaignchatid		VARCHAR(300)
 
    )
BEGIN
    
    		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    
    		SELECT conversation
            FROM
    				wc_AI_convertation_master_details WHERE 
                 domainId = p_domainId
                 AND campaignchatid = p_campaignchatid
                 AND `status` = "draft"
                 AND team = 1; 
              
    		SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_get_AI_recommendation_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_get_AI_recommendation_dtl`(
  	p_domainId					INT
  )
BEGIN
	DECLARE v_domainId		INT;
    DECLARE v_curdate		date default now();
    
    IF EXISTS (SELECT 1 FROM wc_AI_recommmendation_dtl WHERE domainId = p_domainId AND createdOn < v_curdate)
    THEN    
		DELETE FROM wc_AI_recommmendation_dtl WHERE domainId = p_domainId;   
	END IF;
  
	SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
  
	SELECT 	recommendation 
    FROM  	wc_AI_recommmendation_dtl
	WHERE	domainId = p_domainId;
	SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
  
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_get_all_campaign_schedule_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_get_all_campaign_schedule_dtl`(
   p_domainId		INT
   )
BEGIN
   
   	SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;	
     
    SELECT  DISTINCT tt.campaignChatId , tt.campaignName FROM (
   	SELECT  t1.campaignchatId AS campaignChatId, t1.campName AS campaignName
       FROM wc_campaign_master_dtl t1 
       LEFT JOIN wc_master_revert_status_details t2	ON t1.campaignchatId = t2.campaignchatId
       WHERE t1.domainId = p_domainId AND t1.triggerType != 0 AND t2.campaignchatId IS NULL
       
       
       UNION ALL
       
       SELECT t1.campaignchatid AS campaignChatId, t1.`Name` AS campaignName
       FROM ec_email_campaign_master_dtl t1
        LEFT JOIN wc_master_revert_status_details t2	ON t1.campaignchatId = t2.campaignchatId
       WHERE t1.domainId = p_domainId AND t1.emailDelivery != 1 AND t2.campaignchatId IS NULL
       
       UNION ALL
       
        SELECT t1.campaignchatid AS campaignChatId  , t1.`name` AS campaignName
        FROM sc_campaign_master_dtl	t1
        LEFT JOIN wc_master_revert_status_details t2	ON t1.campaignchatId = t2.campaignchatId
        WHERE t1.domainId = p_domainId AND t1.triggerType != 0 AND t2.campaignchatId IS NULL
   
   	UNION ALL
   
       SELECT t1.campaignChatId AS campaignChatId, t1.campaignName AS campaignName
       FROM AppPush_campaign_master_dtl  t1
  		LEFT JOIN wc_master_revert_status_details t2	ON t1.campaignChatId = t2.campaignchatId
       where t1.domainId = p_domainId AND t1.scheduleType  != 0	AND t2.campaignchatId IS NULL
       
       UNION ALL
       SELECT  t1.campaignChatId  AS campaignChatId , t1.campaignName AS campaignName
       FROM webpush_masterCampaignDtl t1
        LEFT JOIN wc_master_revert_status_details t2	ON t1.campaignchatId = t2.campaignchatId
       WHERE t1.domainId = p_domainId AND scheduleType != 0 AND t2.campaignchatId IS NULL
       
       UNION ALL
   
   	SELECT t1.campaignChatId AS campaignChatId, t1.campaignName AS campaignName
       FROM inApp_campaign_master_dtl t1
       LEFT JOIN wc_master_revert_status_details t2	ON t1.campaignchatId = t2.campaignchatId	
       WHERE t1.domainId = p_domainId AND t1.scheduleType != 0 AND t2.campaignchatId IS NULL) 
       as tt;
       
   
   	SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;	
   
   END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_get_analysis_All_campaign_dtl_based_on_campaignChatId_NLP` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_get_analysis_All_campaign_dtl_based_on_campaignChatId_NLP`(
   	p_campaignchatId			VARCHAR(300),
       p_domainId					INT
   )
BEGIN
   		
           DROP TEMPORARY TABLE IF EXISTS tt_emailCampaign_dtl;
   		CREATE TEMPORARY TABLE tt_emailCampaign_dtl
                WITH cte1 AS(
     			SELECT  t1.campaignId, 
   					t1.campaignchatid, 
                       t1.`Name`, 
                       t1.createdate,
   					(IFNULL(t2.uniqueOpenCount,0) * 0.4) + (IFNULL(t2.uniqueClickCount,0) * 0.4) as Total
   			FROM 
   				ec_email_campaign_master_dtl 			AS t1
   				JOIN ec_campaign_HistoryDtl 			AS t2 	ON t1.campaignId = t2.campaignId
   			WHERE t1.domainId = p_domainId AND t1.campaignChatId = p_campaignchatId
     			)
               SELECT  t1.`Name` AS `Name`, t1.Total + (COUNT(isSent) * 0.2) AS TotalCount  
   				FROM cte1 as t1
     				JOIN ec_campaign_contacts_dtl AS t2 ON t1.campaignId = t2.campaignId AND isSent = 1
                   GROUP BY t1.`Name`, t1.Total;
                   
   		
           
           
           
           
           
           DROP TEMPORARY TABLE IF EXISTS tt_smsCampaign_dtl;
   		CREATE TEMPORARY TABLE tt_smsCampaign_dtl
   				 WITH cte1 AS(
     			SELECT t1.campaignchatid, t1.createdDate, t1.`name`, t2.`status` 
             FROM 
     			sc_campaign_master_dtl 			AS t1
     			JOIN sc_SMS_sent_status_details 		AS t2 ON t1.campaignChatId = t2.campaignChatId
     			WHERE t1.domainId = p_domainId and t2.`status` = 'DELIVERED' AND t1.campaignChatId = p_campaignchatId
     			)
                SELECT  campaignchatid AS 'ChatId', `name` AS 'Name', (0 * 0.5)+(COUNT(`status`) * 0.5) as TotalCount  FROM cte1
                 GROUP BY   campaignchatid, `name`;
           
          
           
           
           
           
            DROP TEMPORARY TABLE IF EXISTS tt_WhatsappCampaign_dtl;
   		 CREATE TEMPORARY TABLE tt_WhatsappCampaign_dtl
               WITH cte1 as(
     				SELECT t1.campaignchatId, t1.campName, 
     				CASE WHEN status = 'read' THEN 1 ELSE 0 END AS `Status`
     				FROM 
     					wc_campaign_master_dtl t1
     					JOIN wc_analytics_history_dtl t2
     					ON t1.campaignchatId = t2.campaignchatId
     					WHERE t1.domainId = p_domainId AND t1.campaignchatId = p_campaignchatId
                         )
     				SELECT campaignchatId AS 'ChatId', campName  AS 'Name', (0 * 0.6) + (SUM(`Status`) * 0.4) as TotalCount  FROM cte1
     					GROUP BY  campaignchatId, campName; 
           
           
     
           
           
           
           
   		DROP TEMPORARY TABLE IF EXISTS tt_WebpushCampaign_dtl;
   		 CREATE TEMPORARY TABLE tt_WebpushCampaign_dtl
   			WITH cte1 AS(
     				SELECT t1.campaignChatId, t1.campaignName, 
     				CASE WHEN t2.status = 'OPEN' THEN 1 ELSE 0 END AS `Open`
     				FROM webpush_masterCampaignDtl t1
     				LEFT JOIN webpush_sent_status_details t2
     				ON t1.campaignChatId = t2.campaignChatId
     				WHERE t2.domainId = p_domainId AND t1.campaignChatId = p_campaignchatId
     				) 
   			SELECT campaignChatId AS 'ChatId',  campaignName AS 'Name', (COUNT(1)*0.4)+(SUM(`Open`)*0.6) AS TotalCount FROM cte1
     			GROUP BY  campaignChatId, campaignName;
           
           
           
           
           
           DROP TEMPORARY TABLE IF EXISTS tt_ApppushCampaign_dtl;
   		 CREATE TEMPORARY TABLE tt_ApppushCampaign_dtl
           WITH cte1 AS(
     				SELECT t1.campaignChatId, t1.campaignName, 
     				CASE WHEN t2.status = 'OPEN' THEN 1 ELSE 0 END AS `Open`
     				FROM AppPush_campaign_master_dtl t1
   				JOIN AppPush_tb_openRate_history_dtl t2
     				ON t1.campaignChatId = t2.campaignChatId
     				WHERE t2.domainId = p_domainId AND t1.campaignChatId = p_campaignchatId
     				) 
     			SELECT campaignChatId AS 'ChatId', campaignName AS 'Name', (COUNT(1)*0.4)+(SUM(`Open`)*0.6) AS TotalCount FROM
     			cte1
     			GROUP BY  campaignChatId, campaignName;
           
   		
           
   
  			
              
               DROP TEMPORARY TABLE IF EXISTS tt_inAppCampaign_dtl;
  			 CREATE TEMPORARY TABLE tt_inAppCampaign_dtl
  				WITH cte1 AS(
  				SELECT t1.id , t1.campaignChatId, t1.campaignName, isSent FROM 
  				inApp_campaign_master_dtl t1
  				LEFT JOIN inApp_campaign_contacts_dtl t2
  				ON t1.id = t2.campaignId
  				WHERE t1.domainId = p_domainId AND t2.isSent = 1 AND t1.campaignChatId = p_campaignchatId
  				)
  				SELECT campaignChatId AS 'ChatId', campaignName AS 'Name', (0 * 0.5)+COUNT(isSent * 0.5) AS TotalCount FROM cte1
  				GROUP BY  campaignChatId, campaignName;
              
  			
              
              
              
              
              SELECT Name, 'Email' as 'channel',  TotalCount FROM tt_emailCampaign_dtl
              UNION ALL
  			SELECT Name, 'SMS' as 'channel', TotalCount FROM tt_smsCampaign_dtl
              union all
  			SELECT Name, 'Whatsapp' as 'channel',TotalCount FROM tt_WhatsappCampaign_dtl
              UNION ALL
              select Name, 'Webpush' as 'channel', TotalCount from tt_WebpushCampaign_dtl
              UNION ALL
              SELECT Name, 'Apppush' as 'channel',  TotalCount FROM tt_ApppushCampaign_dtl
              UNION ALL
              SELECT Name, 'InApp' as 'channel', TotalCount FROM tt_inAppCampaign_dtl;
   
   END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_get_analytics_campaign_performace_ranking` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_get_analytics_campaign_performace_ranking`(
    	p_domainId		INT
    )
BEGIN
    	
        DECLARE v_emailTotalOpenRate			INT			DEFAULT 0;
        DECLARE v_emailTotalClickRate		INT			DEFAULT 0;
        DECLARE v_emaildeliveryRate			INT			DEFAULT 0;	
        
        DECLARE v_smsDeliveryRate			INT 		DEFAULT 0;
        DECLARE v_smsClickRate				INT			DEFAULT 0;	
        
 	   DECLARE v_webpushClickRate			INT			DEFAULT 0;
 	   DECLARE v_webpushDeliveryRate		INT			DEFAULT 0;
    	
        DECLARE v_apppushClickRate			INT			DEFAULT 0;
        DECLARE	v_apppushDeliveryRate		INT			DEFAULT 0;
        
        DECLARE v_inAppClickRate				INT			DEFAULT 0;
        DECLARE v_inAppDeliveryRate			INT			DEFAULT 0;
        
    	   DECLARE v_whatsappReadRate			INT			DEFAULT 0;
    	   DECLARE v_whatsappClickRate			INT			DEFAULT 0;
  
      
  		 DECLARE v_totalEmailContact 					INT DEFAULT 0;
          DECLARE v_totalWhatsappContact 				INT DEFAULT 0;
          DECLARE v_totalSMSContact	 					INT DEFAULT 0;
          DECLARE v_totalWebPushContact 					INT DEFAULT 0;
          DECLARE v_totalAppPushContact 					INT DEFAULT 0;
          DECLARE v_totalInAppContact 					INT DEFAULT 0;
          
  	
          
          SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
          
  		select COUNT(*) INTO v_totalWhatsappContact FROM wc_analytics_history_dtl 
  			WHERE domainId = p_domainId AND `status` IN ('DELIVERY', 'read');
  		
  		SELECT SUM(IFNULL(JSON_LENGTH(contactDtls), 0)) INTO v_totalSMSContact
  			FROM sc_campaign_master_dtl WHERE domainId = p_domainId;	
          
          SELECT SUM(IFNULL(JSON_LENGTH(contactslist), 0))  INTO v_totalEmailContact 
  			FROM ec_email_campaign_master_dtl WHERE domainId = p_domainId;
          
          SELECT SUM(IFNULL(JSON_LENGTH(contactDtl), 0))	INTO v_totalAppPushContact
  			FROM AppPush_campaign_master_dtl WHERE domainId = p_domainId;
          
  		SELECT SUM(IFNULL(JSON_LENGTH(contactDtl),0))	INTO v_totalWebPushContact
  			FROM webpush_masterCampaignDtl	WHERE domainId = p_domainId;
  		
  		SELECT SUM(IFNULL(JSON_LENGTH(contactDtl), 0))	INTO v_totalInAppContact
  			FROM  inApp_campaign_master_dtl	WHERE domainId	= p_domainId; 	
              
              
        
      
        SELECT SUM(IFNULL(uniqueOpenCount, 0)) , SUM(IFNULL(uniqueClickCount, 0))  INTO v_emailTotalOpenRate , v_emailTotalClickRate
        FROM ec_campaign_HistoryDtl WHERE domainId = p_domainId;
        
        SELECT COUNT(isSent)  INTO v_emaildeliveryRate FROM ec_campaign_contacts_dtl where domainId = p_domainId AND isSent = 1;  
    
    
    
    
    	SELECT count(id) INTO  v_smsDeliveryRate FROM sc_SMS_sent_status_details WHERE `status` = 'DELIVERED' AND domainId = p_domainId;
    
        
    		
            
            
            
            
    			
    		SELECT count(id) INTO  v_webpushClickRate FROM webpush_sent_status_details WHERE domainId = p_domainId AND `status` = 'OPEN';
            
            SELECT count(id) INTO  v_webpushDeliveryRate FROM webpush_sent_status_details WHERE domainId = p_domainId;
            
            
            
            
            
            
            
            
            
 		 SELECT COUNT(id) INTO v_apppushClickRate FROM AppPush_tb_openRate_history_dtl WHERE domainId = p_domainId AND `status` = 'OPEN';
            
    		 SELECT COUNT(id) INTO v_apppushDeliveryRate FROM AppPush_tb_openRate_history_dtl WHERE domainId = p_domainId;
             
        
    		  
            
            
            
            
            SELECT COUNT(id) INTO v_inAppClickRate FROM inApp_campaign_contacts_dtl where domainId = p_domainId AND isSent = 1;
            
            
            
            
            
            
  
  		SELECT COUNT(1) INTO v_whatsappReadRate 
  				FROM wc_analytics_history_dtl WHERE `status` = 'read' 	AND domainId = p_domainId;
  
        
        
        SELECT ROUND(IFNULL((((v_emailTotalOpenRate * 100)/v_emaildeliveryRate) * 0.4)+(((v_emailTotalClickRate*100)/v_emaildeliveryRate) * 0.4)+(((v_emaildeliveryRate*100)/v_totalEmailContact) * 0.2),0)) 			AS 	Email,
    			ROUND(IFNULL(((v_smsdeliveryRate * 100)/v_totalSMSContact) * 0.5, 0) + IFNULL((((v_smsClickRate*100)/v_smsdeliveryRate) * 0.5), 0))																		AS	SMS,
  			ROUND(IFNULL(((v_webpushDeliveryRate * 100)/v_totalWebPushContact) * 0.4, 0)+ IFNULL((((v_webpushClickRate*100)/v_webpushDeliveryRate) * 0.6),0))														AS	WebPush,
  			ROUND(IFNULL(((v_apppushDeliveryRate * 100)/v_totalAppPushContact) * 0.4, 0)+ IFNULL((((v_apppushClickRate*100)/v_apppushDeliveryRate) * 0.6), 0))														AS 	appPush,
   			ROUND(IFNULL(((v_inAppDeliveryRate * 100)/v_totalInAppContact)* 0.5, 0)+ IFNULL((((v_inAppClickRate *100)/v_inAppDeliveryRate) * 0.5),0))																AS	inApp,	
 			ROUND(IFNULL(((v_whatsappReadRate * 100)/v_totalWhatsappContact)* 0.6,0) + IFNULL((((v_whatsappClickRate * 100)/v_totalWhatsappContact) * 0.4),0))																															AS	Whatsapp;
    
 		SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
    
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_get_analytics_Campaign_Performance_Benchmark` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_get_analytics_Campaign_Performance_Benchmark`(
   p_domainId 		INT
   )
BEGIN
   		  
   
   
             DECLARE v_currentTotalSMSContact	 					INT DEFAULT 0;
             DECLARE v_pastTotalSMSContact	 						INT DEFAULT 0;
     		DECLARE v_fromDate								DATE;
     		DECLARE v_toDate								DATE DEFAULT NOW();
           DECLARE v_PastToDate							DATE;
           DECLARE v_PastFromDate							DATE;
   		DECLARE v_CurrentCount							FLOAT;
           DECLARE v_PastCount								FLOAT;
   
   
   
           
   	
                SELECT DATE_SUB( DATE(NOW()) , INTERVAL 6 DAY) INTO v_fromDate;
                
                SELECT DATE_SUB(v_fromDate , INTERVAL 1 DAY) INTO v_PastToDate;
            
   			SELECT DATE_SUB(v_PastToDate , INTERVAL 6 DAY) INTO v_PastFromDate;
   		
          
      
      
      
   		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   			
   		SELECT IFNULL(SUM(IFNULL(JSON_LENGTH(contactDtls), 0)),0) INTO v_currentTotalSMSContact
   			FROM sc_campaign_master_dtl 
   			WHERE domainId = p_domainId AND (DATE(createdDate) >= v_fromDate AND DATE(createdDate) <= v_toDate);
               
   		SELECT IFNULL(SUM(IFNULL(JSON_LENGTH(contactDtls), 0)),0) INTO v_pastTotalSMSContact
   			FROM sc_campaign_master_dtl 
   			WHERE domainId = p_domainId AND (DATE(createdDate) >= v_PastFromDate AND DATE(createdDate) <= v_PastToDate);
               
               
			
         
		
         
   		DROP TEMPORARY TABLE IF EXISTS tt_CurrentEmailChannelcampaignDtl;	
     		CREATE TEMPORARY TABLE tt_CurrentEmailChannelcampaignDtl
         
     			WITH cte1 AS(
     				SELECT 
     						t1.campaignChatId,
     						t1.campaignId,
     						IFNULL(t2.uniqueOpenCount,0) 		AS uniqueOpenRate, 
     						IFNULL(t2.uniqueClickCount, 0)		AS uniqueClickRate
     					FROM ec_email_campaign_master_dtl 			t1	
     					LEFT JOIN ec_campaign_HistoryDtl						t2	ON t1.campaignId = t2.campaignId
     					WHERE t1.domainId = p_domainId		AND 	(DATE(t1.createdate) >= v_fromDate  AND DATE(t1.createdate) <= v_toDate )
     				),
     				cte2 AS(
     				SELECT campaignId,
     						COUNT(id) AS CountOfDelivery
     					FROM ec_campaign_contacts_dtl
     				WHERE domainId = p_domainId AND isSent = 1
     				GROUP BY campaignId
     				)
     				SELECT 'Email' as`Channel`, 
							SUM(t1.uniqueOpenRate) AS OpenRate, 
                            SUM(t1.uniqueClickRate) as ClickRate, 
							SUM(IFNULL(t2.CountOfDelivery,0)) as CountOfDelivery , 
                            
                            CASE WHEN SUM(IFNULL(t1.uniqueOpenRate,0)) != 0 AND SUM(IFNULL(t2.CountOfDelivery,0)) != 0 THEN  
								IFNULL(   (SUM(IFNULL(t1.uniqueOpenRate,0))*100)/ SUM(IFNULL(t2.CountOfDelivery,0))   ,0)  
                            ELSE 0 END +
                            CASE WHEN SUM(IFNULL(t1.uniqueClickRate,0)) != 0 AND SUM(IFNULL(t2.CountOfDelivery,0)) != 0 THEN  
                              IFNULL( (SUM(IFNULL(t1.uniqueClickRate, 0))*100) / SUM(IFNULL(t2.CountOfDelivery,0))  ,0)		
                            ELSE 0 
                            END AS 'Score'
                            
                            
     				FROM cte1 t1
     				LEFT JOIN cte2 t2 ON t1.campaignId = t2.campaignId;
                   
                
                   
   		
                   
   		DROP TEMPORARY TABLE IF EXISTS tt_PastEmailChannelcampaignDtl;	
     		CREATE TEMPORARY TABLE tt_PastEmailChannelcampaignDtl
         
     			WITH cte1 AS(
     				SELECT 
     						t1.campaignChatId,
     						t1.campaignId,
     						IFNULL(t2.uniqueOpenCount,0) 		AS uniqueOpenRate, 
     						IFNULL(t2.uniqueClickCount, 0)		AS uniqueClickRate
     					FROM ec_email_campaign_master_dtl 			t1	
     					LEFT JOIN ec_campaign_HistoryDtl						t2	ON t1.campaignId = t2.campaignId
     					WHERE t1.domainId = p_domainId		AND 	(DATE(t1.createdate) >= v_PastFromDate  AND DATE(t1.createdate) <= v_PastToDate )
     				),
     				cte2 AS(
     				SELECT campaignId,
     						COUNT(id) AS CountOfDelivery
     					FROM ec_campaign_contacts_dtl
     				WHERE domainId = p_domainId AND isSent = 1
     				GROUP BY campaignId
     				)
     				SELECT 'Email' as`Channel`, SUM(t1.uniqueOpenRate) AS OpenRate, SUM(t1.uniqueClickRate) as ClickRate, 
     								SUM(IFNULL(t2.CountOfDelivery,0)) as CountOfDelivery  
     				,	 CASE WHEN SUM(IFNULL(t1.uniqueOpenRate,0)) != 0 AND SUM(IFNULL(t2.CountOfDelivery,0)) != 0 THEN  	 
								IFNULL(  (SUM(IFNULL(t1.uniqueOpenRate, 0))*100)/ SUM(IFNULL(t2.CountOfDelivery,0))  ,0) 
								ELSE 0 end 
					+	  CASE WHEN SUM(IFNULL(t1.uniqueClickRate,0)) != 0 AND SUM(IFNULL(t2.CountOfDelivery,0)) != 0 THEN  
								IFNULL((SUM(IFNULL(t1.uniqueClickRate,0))*100)/ SUM(IFNULL(t2.CountOfDelivery,0)),0)		
								ELSE 0 
                    end AS 'Score'
     				FROM cte1 t1
     				LEFT JOIN cte2 t2 ON t1.campaignId = t2.campaignId;
                   
                   
   	DROP TEMPORARY TABLE IF EXISTS tt_CurrentSMSChannelcampaignDtl;	
     	CREATE TEMPORARY TABLE tt_CurrentSMSChannelcampaignDtl
         
         WITH cte1 AS(
     			SELECT
     				COUNT(t2.`status`) 			AS 	'CampaignStatus'
     			FROM sc_campaign_master_dtl  t1
     				LEFT JOIN sc_SMS_sent_status_details t2 ON t1.campaignchatid = t2.campaignChatId
     			WHERE t1.domainId = p_domainId AND t2.status = 'DELIVERED' 
     				AND	(DATE(t1.createdDate)  >= v_fromDate  AND DATE(t1.createdDate) <= v_toDate )
     					
             )
             SELECT "SMS" as `Channel`, 
             CASE WHEN v_currentTotalSMSContact !=0 AND CampaignStatus !=0 
				THEN IFNULL(((CampaignStatus * 100)/ v_currentTotalSMSContact)*0.5,0) ELSE 0 END AS 'Score'from cte1;
             
             
           
           
   		
           
           DROP TEMPORARY TABLE IF EXISTS tt_PastSMSChannelcampaignDtl;	
     	CREATE TEMPORARY TABLE tt_PastSMSChannelcampaignDtl
         
         WITH cte1 AS(
     			SELECT
     				COUNT(t2.`status`) 			AS 	'CampaignStatus'
     			FROM sc_campaign_master_dtl  t1
     				LEFT JOIN sc_SMS_sent_status_details t2 ON t1.campaignchatid = t2.campaignChatId
     			WHERE t1.domainId = p_domainId AND t2.status = 'DELIVERED' 
     				AND	(DATE(t1.createdDate)  >= v_PastFromDate  AND DATE(t1.createdDate) <= v_PastToDate )
     					
             )
             SELECT "SMS" as `Channel`, 
             CASE WHEN v_pastTotalSMSContact !=0 AND CampaignStatus !=0 THEN IFNULL(((CampaignStatus * 100)/ v_pastTotalSMSContact)*0.5,0) ELSE 0 END AS 'Score'from cte1;
           
           
           
   	
       
       
     	DROP TEMPORARY TABLE IF EXISTS tt_CurrentWhatsappChannelcampaignDtl;	
     	CREATE TEMPORARY TABLE tt_CurrentWhatsappChannelcampaignDtl
            WITH cte AS(
     		SELECT 
     			IFNULL(SUM(case when t2.`status` = 'DELIVERY' OR  t2.`status` = 'read' THEN  1 ELSE 0 END),0) AS 'Sent',
     			IFNULL(SUM(case when t2.`status` = 'read'		THEN 1 ELSE 0 END ),0)AS 'Read' 
     		FROM wc_campaign_master_dtl t1
     		LEFT JOIN wc_analytics_history_dtl t2 ON t1.campaignchatId = t2.campaignchatId
     		WHERE t1.domainId = p_domainId AND (DATE(t1.createdDate)  >= v_fromDate  AND DATE(t1.createdDate) <= v_toDate )
     		)
     			SELECT 'Whatsapp' AS `Channel`, 
     			CASE WHEN `Read` !=0 AND Sent != 0 THEN (((`Read`*100)/Sent) * 0.6) + (0 * 0.4) ELSE 0 END AS 'Score'  FROM cte;
           
           
            
            
   		
           
   	DROP TEMPORARY TABLE IF EXISTS tt_PastWhatsappChannelcampaignDtl;	
     	CREATE TEMPORARY TABLE tt_PastWhatsappChannelcampaignDtl
            WITH cte AS(
     		SELECT 
     			IFNULL(SUM(case when t2.`status` = 'DELIVERY' OR t2.`status` = 'read' THEN  1 ELSE 0 END),0) AS 'Sent',
     			IFNULL(SUM(case when t2.`status` = 'read'		THEN 1 ELSE 0 END ),0)AS 'Read' 
     		FROM wc_campaign_master_dtl t1
     		LEFT JOIN wc_analytics_history_dtl t2 ON t1.campaignchatId = t2.campaignchatId
     		WHERE t1.domainId = p_domainId AND (DATE(t1.createdDate)  >= v_PastFromDate  AND DATE(t1.createdDate) <= v_PastToDate )
     		)
     			SELECT 'Whatsapp' AS `Channel`, 
     			CASE WHEN `Read` !=0 AND Sent != 0 THEN (((`Read`*100)/Sent) * 0.6) + (0 * 0.4) ELSE 0 END AS 'Score'  FROM cte;
           
           
            
   	
       
       
   		DROP TEMPORARY TABLE IF EXISTS tt_CurrentWebPushChannelcampaignDtl;	
   		CREATE TEMPORARY TABLE tt_CurrentWebPushChannelcampaignDtl
     				with cte01 as(
     					SELECT IFNULL(SUM(CASE WHEN t2.`status` = 'DELIVERY' OR  t2.`status` = 'OPEN'THEN 1 ELSE 0 END),0)  As DeliveryRate, 
     							IFNULL(SUM(CASE WHEN t2.`status` = 'OPEN' THEN 1 ELSE 0 END),0) AS OpenRate
     					FROM  webpush_masterCampaignDtl					t1
     					LEFT JOIN   webpush_sent_status_details			t2	ON t1.campaignChatId = t2.campaignChatId
     						WHERE t1.domainId = p_domainId AND (DATE(t1.createdOn )>= v_fromDate  AND DATE(t1.createdOn) <= v_toDate)
                             )
                             SELECT 'WebPush' as `Channel`, 
     							CASE WHEN OpenRate !=0 AND DeliveryRate !=0 THEN (((OpenRate*100)/DeliveryRate)*1.0) ELSE 0 END AS 'Score'     
     						FROM cte01;
                    
     		
           
           
           
           DROP TEMPORARY TABLE IF EXISTS tt_PastWebPushChannelcampaignDtl;	
   		CREATE TEMPORARY TABLE tt_PastWebPushChannelcampaignDtl
     				with cte01 as(
     					SELECT IFNULL(SUM(CASE WHEN t2.`status` = 'DELIVERY' OR t2.`status` = 'OPEN' THEN 1 ELSE 0 END),0)  As DeliveryRate, 
     							IFNULL(SUM(CASE WHEN t2.`status` = 'OPEN' THEN 1 ELSE 0 END),0) AS OpenRate
     					FROM  webpush_masterCampaignDtl					t1
     					LEFT JOIN   webpush_sent_status_details			t2	ON t1.campaignChatId = t2.campaignChatId
     						WHERE t1.domainId = p_domainId AND (DATE(t1.createdOn )>= v_PastFromDate  AND DATE(t1.createdOn) <= v_PastToDate)
                             )
                             SELECT 'WebPush' as `Channel`, 
     							CASE WHEN OpenRate !=0 AND DeliveryRate !=0 THEN (((OpenRate*100)/DeliveryRate)*1.0) ELSE 0 END AS 'Score'     
     						FROM cte01;
                           
             
             
   		
           
   			
   		DROP TEMPORARY TABLE IF EXISTS tt_CurrentAppPushChannelcampaignDtl;	
     		CREATE TEMPORARY TABLE tt_CurrentAppPushChannelcampaignDtl	
                     WITH cte01 AS(
     						SELECT IFNULL(SUM((case when t2.`status` = 'DELIVERY' OR t2.`status` = 'OPEN' THEN 1 ELSE 0 END)), 0) AS DeliveryRate,
     								IFNULL(SUM((case when t2.`status` = 'OPEN' THEN 1 ELSE 0 END)), 0) AS OpenRate
     					FROM AppPush_campaign_master_dtl t1
     					LEFT JOIN AppPush_tb_openRate_history_dtl  t2 ON t1.campaignChatId = t2.campaignChatId
     					WHERE t1.domainId = p_domainId AND(DATE(t1.createdOn) >= v_fromDate  AND DATE(t1.createdOn) <= v_toDate) 
                     )
     				SELECT  'AppPush' as `Channel`,  
                     CASE WHEN OpenRate !=0 AND DeliveryRate !=0 THEN  IFNULL(((OpenRate*100)/DeliveryRate),0) * 1.0 ELSE 0 END 	AS 'Score' FROM cte01;
   
   			
               
               
               
               
   		DROP TEMPORARY TABLE IF EXISTS tt_PastAppPushChannelcampaignDtl;	
     		CREATE TEMPORARY TABLE tt_PastAppPushChannelcampaignDtl	
                     WITH cte01 AS(
     						SELECT IFNULL(SUM((case when t2.`status` = 'DELIVERY' OR t2.`status` = 'OPEN' THEN 1 ELSE 0 END)), 0) AS DeliveryRate,
     								IFNULL(SUM((case when t2.`status` = 'OPEN' THEN 1 ELSE 0 END)), 0) AS OpenRate
     					FROM AppPush_campaign_master_dtl t1
     					LEFT JOIN AppPush_tb_openRate_history_dtl  t2 ON t1.campaignChatId = t2.campaignChatId
     					WHERE t1.domainId = p_domainId AND(DATE(t1.createdOn) >= v_PastFromDate  AND DATE(t1.createdOn) <= v_PastToDate) 
                     )
     				SELECT  'AppPush' as `Channel`,  
                     CASE WHEN OpenRate !=0 AND DeliveryRate !=0 THEN  IFNULL(((OpenRate*100)/DeliveryRate),0) * 1.0 ELSE 0 END 	AS 'Score' FROM cte01;
                     
   			
               
               
               
               
               
               
               SELECT ROUND(SUM(TotalCount),2) INTO v_CurrentCount FROM (
   			 	  SELECT `Channel`, Score AS TotalCount FROM tt_CurrentEmailChannelcampaignDtl
                     UNION ALL
   				  SELECT `Channel`, Score AS TotalCount FROM tt_CurrentSMSChannelcampaignDtl
                     UNION ALL
                     SELECT `Channel`, Score AS TotalCount FROM tt_CurrentWhatsappChannelcampaignDtl
                     UNION ALL
                     SELECT `Channel`, Score AS TotalCount FROM tt_CurrentWebPushChannelcampaignDtl
                     UNION ALL
                     SELECT `Channel`, Score AS TotalCount FROM tt_CurrentAppPushChannelcampaignDtl
                     UNION ALL
                     SELECT 'InApp' AS `Channel`, 0.0 AS TotalCount
            ) tt;
            
             SELECT ROUND(SUM(TotalCount),2)INTO v_PastCount FROM (
   			 	  SELECT `Channel`, Score AS TotalCount FROM tt_PastEmailChannelcampaignDtl
                     UNION ALL
   				  SELECT `Channel`, Score AS TotalCount FROM tt_PastSMSChannelcampaignDtl
                     UNION ALL
                     SELECT `Channel`, Score AS TotalCount FROM tt_PastWhatsappChannelcampaignDtl
                     UNION ALL
                     SELECT `Channel`, Score AS TotalCount FROM tt_PastWebPushChannelcampaignDtl
                     UNION ALL
                     SELECT `Channel`, Score AS TotalCount FROM tt_PastAppPushChannelcampaignDtl
                     UNION ALL
                     SELECT 'InApp' AS `Channel`, 0.0 AS TotalCount
            ) tt;
            
            SELECT v_CurrentCount AS CurrentCount, v_PastCount AS PastCount;
            
   		SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_get_analytics_channel_performance_metrics` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_get_analytics_channel_performance_metrics`(
      	p_domainId		INT
      )
BEGIN
      			
      	 	DECLARE v_totalEmailContact 					INT DEFAULT 0;
              DECLARE v_totalWhatsappContact 					INT DEFAULT 0;
              DECLARE v_totalSMSContact	 					INT DEFAULT 0;
              DECLARE v_totalWebPushContact 					INT DEFAULT 0;
              DECLARE v_totalAppPushContact 					INT DEFAULT 0;
              DECLARE v_totalInAppContact 					INT DEFAULT 0;
      		
              
      		DECLARE v_fromDate								DATE;
      		DECLARE v_toDate								DATE DEFAULT NOW();
              
              
              
              
                SELECT DATE_SUB( DATE(NOW()) , INTERVAL 6 DAY) INTO v_fromDate;
                
                SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
                
               
          
      	 	SELECT IFNULL(SUM(IFNULL(JSON_LENGTH(contactDtls), 0)),0) INTO v_totalSMSContact
      			FROM sc_campaign_master_dtl WHERE domainId = p_domainId AND (DATE(createdDate) >= v_fromDate AND DATE(createdDate) <= v_toDate);	
                  
         
          
          
          
      		DROP TEMPORARY TABLE IF EXISTS tt_EmailChannelcampaignDtl;	
      		CREATE TEMPORARY TABLE tt_EmailChannelcampaignDtl
          
      			WITH cte1 AS(
      				SELECT 
      						t1.campaignChatId,
      						t1.campaignId,
      						IFNULL(t2.uniqueOpenCount,0) 		AS uniqueOpenRate, 
      						IFNULL(t2.uniqueClickCount, 0)		AS uniqueClickRate
      					FROM ec_email_campaign_master_dtl 			t1	
      					LEFT JOIN ec_campaign_HistoryDtl						t2	ON t1.campaignId = t2.campaignId
      					WHERE t1.domainId = p_domainId		AND 	(DATE(t1.createdate) >= v_fromDate  AND DATE(t1.createdate) <= v_toDate )
      				),
      				cte2 AS(
      				SELECT campaignId,
      						COUNT(id) AS CountOfDelivery
      					FROM ec_campaign_contacts_dtl
      				WHERE domainId = p_domainId AND isSent = 1
      				GROUP BY campaignId
      				)
      				SELECT 'Email' as`Channel`, SUM(t1.uniqueOpenRate) AS OpenRate, SUM(t1.uniqueClickRate) as ClickRate, 
      								SUM(IFNULL(t2.CountOfDelivery,0)) as CountOfDelivery  
      				, IFNULL((SUM(t1.uniqueOpenRate)*100)/ SUM(IFNULL(t2.CountOfDelivery,0)),0) 
      				+ IFNULL((SUM(t1.uniqueClickRate)*100)/ SUM(IFNULL(t2.CountOfDelivery,0)),0)		AS 'Score'
      				FROM cte1 t1
      				LEFT JOIN cte2 t2 ON t1.campaignId = t2.campaignId
      				;
              
               
              
      	
              
          
      	DROP TEMPORARY TABLE IF EXISTS tt_SMSChannelcampaignDtl;	
      	CREATE TEMPORARY TABLE tt_SMSChannelcampaignDtl
          
          WITH cte1 AS(
      			SELECT
      				COUNT(t2.status) 			AS 	'CampaignStatus'
      			FROM sc_campaign_master_dtl  t1
      				LEFT JOIN sc_SMS_sent_status_details t2 ON t1.campaignchatid = t2.campaignChatId
      			WHERE t1.domainId = p_domainId AND t2.status = 'DELIVERED' 
      				AND	(DATE(t1.createdDate)  >= v_fromDate  AND DATE(t1.createdDate) <= v_toDate )
      					
              )
              SELECT "SMS" as `Channel`, 
              CASE WHEN v_totalSMSContact !=0 THEN IFNULL(((CampaignStatus * 100)/ v_totalSMSContact)*0.5,0) ELSE 0 END AS 'Score'from cte1;
              
      	
             
              
            
      	DROP TEMPORARY TABLE IF EXISTS tt_WhatsappChannelcampaignDtl;	
      	CREATE TEMPORARY TABLE tt_WhatsappChannelcampaignDtl
             WITH cte AS(
      		SELECT 
      			IFNULL(SUM(case when t2.`status` = 'DELIVERY' AND t2.`status` = 'read' THEN  1 ELSE 0 END),0) AS 'Sent',
      			IFNULL(SUM(case when t2.`status` = 'read'		THEN 1 ELSE 0 END ),0)AS 'Read' 
      		FROM wc_campaign_master_dtl t1
      		LEFT JOIN wc_analytics_history_dtl t2 ON t1.campaignchatId = t2.campaignchatId
      		WHERE t1.domainId = p_domainId AND (DATE(t1.createdDate)  >= v_fromDate  AND DATE(t1.createdDate) <= v_toDate )
      		)
      			SELECT 'Whatsapp' AS `Channel`, 
      			CASE WHEN `Read` !=0 AND Sent != 0 THEN (((`Read`*100)/Sent) * 0.6) + (0 * 0.4) ELSE 0 END AS 'Score'  FROM cte;
              
            
             
             
         
              
      	DROP TEMPORARY TABLE IF EXISTS tt_WebPushChannelcampaignDtl;	
      	CREATE TEMPORARY TABLE tt_WebPushChannelcampaignDtl
      				with cte01 as(
      					SELECT IFNULL(SUM(CASE WHEN t2.`status` = 'DELIVERY' AND t2.`status` = 'OPEN' THEN 1 ELSE 0 END),0)  As DeliveryRate, 
      							IFNULL(SUM(CASE WHEN t2.`status` = 'OPEN' THEN 1 ELSE 0 END),0) AS OpenRate
      					FROM  webpush_masterCampaignDtl					t1
      					LEFT JOIN   webpush_sent_status_details			t2	ON t1.campaignChatId = t2.campaignChatId
      						WHERE t1.domainId = p_domainId AND (DATE(t1.createdOn )>= v_fromDate  AND DATE(t1.createdOn) <= v_toDate)
                              )
                              SELECT 'WebPush' as `Channel`, 
      							CASE WHEN OpenRate !=0 AND DeliveryRate !=0 THEN (((OpenRate*100)/DeliveryRate)*1.0) ELSE 0 END AS 'Score'     
      						FROM cte01;
                     
      		
              
              
      		DROP TEMPORARY TABLE IF EXISTS tt_AppPushChannelcampaignDtl;	
      		CREATE TEMPORARY TABLE tt_AppPushChannelcampaignDtl	
                      WITH cte01 AS(
      						SELECT IFNULL(SUM(case when t2.status = 'DELIVERY' AND t2.status = 'OPEN' THEN 1 ELSE 0 END), 0) AS DeliveryRate,
      								IFNULL(SUM(case when t2.status = 'OPEN' THEN 1 ELSE 0 END), 0) AS OpenRate
      					FROM AppPush_campaign_master_dtl t1
      					LEFT JOIN AppPush_tb_openRate_history_dtl  t2 ON t1.campaignChatId = t2.campaignChatId
      					WHERE t1.domainId = p_domainId AND(DATE(t1.createdOn) >= v_fromDate  AND DATE(t1.createdOn) <= v_toDate) 
                      )
      				SELECT  'AppPush' as `Channel`,  
                      CASE WHEN OpenRate !=0 AND DeliveryRate !=0 THEN  IFNULL(((OpenRate*100)/DeliveryRate),0) * 1.0 ELSE 0 END 	AS 'Score' FROM cte01;
       
      			
      				SELECT `Channel`, ROUND(Score,1) AS TotalCount FROM tt_EmailChannelcampaignDtl
                      UNION ALL
      				SELECT `Channel`, ROUND(Score,1) AS TotalCount FROM tt_SMSChannelcampaignDtl
                      UNION ALL
                      SELECT `Channel`, ROUND(Score,1) AS TotalCount FROM tt_WhatsappChannelcampaignDtl
                      UNION ALL
                      SELECT `Channel`, ROUND(Score,1) AS TotalCount FROM tt_WebPushChannelcampaignDtl
                      UNION ALL
                      SELECT `Channel`, ROUND(Score,1) AS TotalCount FROM tt_AppPushChannelcampaignDtl
                      UNION ALL
                      SELECT 'InApp' AS `Channel`, 0.0 AS TotalCount
                      ;
                     
              
      	
              DROP TEMPORARY TABLE tt_EmailChannelcampaignDtl;
              DROP TEMPORARY TABLE tt_SMSChannelcampaignDtl;
              DROP TEMPORARY TABLE tt_WhatsappChannelcampaignDtl;
              DROP TEMPORARY TABLE tt_AppPushChannelcampaignDtl;
              DROP  TEMPORARY TABLE tt_WebPushChannelcampaignDtl;
              
              
               SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ ;
      end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_get_analytics_history_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_get_analytics_history_dtl`(
 		p_domainId				INT
        
 )
BEGIN
 		 
         SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;  
          
         SELECT 
 				id ,domainId ,campaignchatId ,campaignId ,fromNo ,toNo ,messageId ,`status` ,createdOn        
         FROM wc_analytics_history_dtl WHERE domainId = p_domainId;
          
          SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
          
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_get_analytics_Top_Performing_Campaigns` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_get_analytics_Top_Performing_Campaigns`(
       	p_domainId			INT
       )
BEGIN
       			
       	 	   DECLARE v_totalEmailContact 					INT DEFAULT 0;
               DECLARE v_totalWhatsappContact 					INT DEFAULT 0;
               DECLARE v_totalSMSContact	 					INT DEFAULT 0;
               DECLARE v_totalWebPushContact 					INT DEFAULT 0;
               DECLARE v_totalAppPushContact 					INT DEFAULT 0;
               DECLARE v_totalInAppContact 					INT DEFAULT 0;
       		
               
       		DECLARE v_fromDate								DATE;
       		DECLARE v_toDate								DATE DEFAULT NOW();
               
               SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
               
               
                 SELECT DATE_SUB( DATE(NOW()) , INTERVAL 6 DAY) INTO v_fromDate;
                 
                 
               
       		
           
       		SELECT IFNULL(SUM(IFNULL(JSON_LENGTH(contactList), 0)),0) INTO v_totalWhatsappContact
       			FROM wc_campaign_master_dtl WHERE domainId = p_domainId AND DATE(createdDate) BETWEEN v_fromDate AND v_toDate ;
       
       	
       
               
       
       
               
               SELECT IFNULL(SUM(IFNULL(JSON_LENGTH(contactDtl), 0)),0)	INTO v_totalAppPushContact
       			FROM AppPush_campaign_master_dtl WHERE domainId = p_domainId AND DATE(createdOn) BETWEEN v_fromDate AND v_toDate;
               
       		SELECT IFNULL(SUM(IFNULL(JSON_LENGTH(contactDtl),0)),0)	INTO v_totalWebPushContact
       			FROM webpush_masterCampaignDtl	WHERE domainId = p_domainId AND DATE(createdOn) BETWEEN  v_fromDate AND v_toDate;
       		
       		SELECT IFNULL(SUM(IFNULL(JSON_LENGTH(contactDtl), 0)),0)	INTO v_totalInAppContact
       			FROM  inApp_campaign_master_dtl	WHERE domainId	= p_domainId AND DATE(createdOn) BETWEEN v_fromDate AND v_toDate;
                   
       		
            
           
           
           
       		DROP TEMPORARY TABLE IF EXISTS tt_EmailcampaignDtl;	
       		CREATE TEMPORARY TABLE tt_EmailcampaignDtl
           
           WITH cte1 AS(
       		SELECT 	t1.campaignChatId , 
       				t1.campaignId, 
                       t1.`Name`,
                       IFNULL(t2.uniqueOpenCount,0) 		AS uniqueOpenRate, 
                       IFNULL(t2.uniqueClickCount, 0) 		AS uniqueClickRate
       			FROM ec_email_campaign_master_dtl 			t1	
       		LEFT JOIN ec_campaign_HistoryDtl						t2	ON t1.campaignId = t2.campaignId
       			WHERE t1.domainId = p_domainId		AND 	(DATE(t1.createdate) >= v_fromDate AND DATE(t1.createdate) <= v_toDate )
               ),
       		cte2 AS(
       		SELECT campaignId , 
                       COUNT(id) AS CountOfDelivery
       			FROM ec_campaign_contacts_dtl
       		WHERE domainId = p_domainId AND isSent = 1
       			GROUP BY domainId, campaignId 
       		)
               SELECT 
       			  
       				t1.campaignChatId		AS 'CampaignChatId',  
                       t1.`Name`				AS 'CampaignName',
                     
                    
                     
                     
       			
       				IFNULL((((t1.uniqueOpenRate * 100)/t2.CountOfDelivery) * 0.6),0)
       					+ IFNULL((((t1.uniqueClickRate * 100)/ t2.CountOfDelivery)* 0.4),0) AS EmailTotalRate
       			FROM cte1 t1
       			LEFT JOIN cte2 t2	
       				ON t1.campaignId = t2.campaignId ;
               
             
               
               
               
               
       		DROP TEMPORARY TABLE IF EXISTS tt_SMScampaignDtl;	
       		CREATE TEMPORARY TABLE tt_SMScampaignDtl
               
               WITH cte01 AS(
       			SELECT 	t1.`name` 					AS  'CampaignName',
                           t1.campaignChatId  			AS  'CampaignChatId',
                           COUNT(t2.status) 			AS 	'CampaignStatus',
                           JSON_LENGTH(t1.contactDtls) AS 	 'CustomerCount'
       				FROM sc_campaign_master_dtl  t1
       				LEFT JOIN sc_SMS_sent_status_details t2 ON t1.campaignchatid = t2.campaignChatId
       			WHERE t1.domainId = p_domainId AND t2.status = 'DELIVERED' AND
       					(DATE(t1.createdDate) >= v_fromDate AND DATE(t1.createdDate) <= v_toDate )
       					GROUP BY t1.name, t1.campaignChatId
               )
               SELECT CampaignChatId,  
               CampaignName, case when CampaignStatus !=0 AND CustomerCount !=0 THEN 
               (((CampaignStatus*100)/CustomerCount)* 0.5) +(0 * 0.5) ELSE 0 END AS SMSTotalRate from cte01;
               
               
             
               
               
               
               DROP TEMPORARY TABLE IF EXISTS tt_WhatsappCampaignDtl;	
       		CREATE TEMPORARY TABLE tt_WhatsappCampaignDtl
       			with cte01 as(
       				select 	t1.campaignchatId		AS  'CampaignChatId',
       						t1.campName 			AS  'CampaignName',
       						SUM(JSON_LENGTH(t1.contactList)),
       						SUM(CASE WHEN t2.`status` = 'DELIVERY' OR t2.`status` = 'read'	THEN 1 ELSE 0 END) AS TotalDelivery,
       						SUM(CASE WHEN t2.`status` = 'read'	THEN 1 ELSE 0 END	) AS TotalRead
       				FROM wc_campaign_master_dtl t1
       				LEFT JOIN wc_analytics_history_dtl t2 ON t1.campaignchatId = t2.campaignchatId
       				WHERE t1.domainId = p_domainId AND (DATE(t1.createdDate) >= v_fromDate AND DATE(t1.createdDate) <= v_toDate) 
       				GROUP BY t1.campaignchatId, t1.campName)
       						SELECT CampaignChatId, CampaignName, 
       							 CASE WHEN TotalRead !=0 AND TotalDelivery !=0   THEN 
        								IFNULL((((TotalRead * 100)/ TotalDelivery) * 0.6),0)+ IFNULL((((1 * 100)/ TotalDelivery) * 0.4),0) ELSE 0 END  As  WhatsappTotalRate
       							FROM cte01 WHERE CampaignChatId is not null;
               
    		 
               
               
       				 DROP TEMPORARY TABLE IF EXISTS tt_WebPushCampaignDtl;	
       				CREATE TEMPORARY TABLE tt_WebPushCampaignDtl
       						WITH cte01 as(
       						SELECT t1.campaignChatId 			AS  'CampaignChatId',
       								t1.campaignName				AS  'CampaignName',
                                       SUM(CASE WHEN t2.`status`  = 'DELIVERY' OR t2.`status`  = 'OPEN' THEN 1 ELSE 0 END) 			AS SendCount,
                                       SUM(CASE WHEN t2.`status`  = 'OPEN' THEN 1 ELSE 0 END)				AS ClickRateCount
                               FROM webpush_masterCampaignDtl t1
       						LEFT JOIN webpush_sent_status_details t2
       							ON t1.campaignChatId = t2.campaignChatId
       						WHERE t1.domainId = p_domainId AND t1.campaignChatId IS NOT NULL AND (DATE(t1.createdOn) >= v_fromDate AND DATE(t1.createdOn) <= v_toDate) 
                               GROUP BY  t1.campaignChatId,t1.campaignName
                       )
       			SELECT CampaignChatId, CampaignName, CASE WHEN ClickRateCount !=0 AND SendCount !=0 THEN (((ClickRateCount * 100)/SendCount)*1.0) ELSE 0 END AS WebPushTotalRate FROM cte01;
                       
       		
               
               with finalResult as(
               SELECT CampaignChatId, CampaignName AS 'Name', ROUND(IFNULL(SUM(Count),0)) AS 'Total' FROM 
               (
       				SELECT CampaignChatId, CampaignName,  EmailTotalRate * 0.3 as `Count` FROM tt_EmailcampaignDtl
                       UNION ALL
                       SELECT  CampaignChatId, CampaignName, SMSTotalRate * 0.15 as `Count` FROM tt_SMScampaignDtl
                       UNION ALL
                       SELECT CampaignChatId, CampaignName, WhatsappTotalRate * 0.25 as `Count` FROM tt_WhatsappCampaignDtl
                       UNION ALL
                       SELECT CampaignChatId, CampaignName, WebPushTotalRate * 0.15 as `Count` FROM tt_WebPushCampaignDtl
               )tt
               GROUP BY CampaignChatId,CampaignName
               ORDER BY Total DESC
               LIMIT 06
               )
               SELECT `Name`, Total FROM finalResult
               ;
               
               
    			DROP TEMPORARY TABLE tt_EmailcampaignDtl;
               DROP TEMPORARY TABLE tt_SMScampaignDtl;
               DROP TEMPORARY TABLE tt_WhatsappCampaignDtl;
               DROP TEMPORARY TABLE tt_WebPushCampaignDtl;
               
                           SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
       end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_get_analytics_weekly_campaign_summary` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_get_analytics_weekly_campaign_summary`(
     	p_domainId			INT
     )
BEGIN
     			
     	
             DECLARE v_totalWhatsappContact 					INT DEFAULT 0;
             DECLARE v_totalSMSContact	 					INT DEFAULT 0;
             DECLARE v_totalWebPushContact 					INT DEFAULT 0;
             DECLARE v_totalAppPushContact 					INT DEFAULT 0;
             DECLARE v_totalInAppContact 					INT DEFAULT 0;
     		
             
     		DECLARE v_fromDate								DATE;
     		DECLARE v_toDate								DATE DEFAULT NOW();
             
   		
           SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;   
             
             
               SELECT DATE_SUB( DATE(NOW()) , INTERVAL 6 DAY) INTO v_fromDate;
               
              
             
     		
         
     		SELECT IFNULL(SUM(IFNULL(JSON_LENGTH(contactList), 0)),0) INTO v_totalWhatsappContact
     			FROM wc_campaign_master_dtl WHERE domainId = p_domainId AND DATE(createdDate) BETWEEN v_fromDate AND v_toDate ;
     
     	
     
             
     
     
             
             SELECT IFNULL(SUM(IFNULL(JSON_LENGTH(contactDtl), 0)),0)	INTO v_totalAppPushContact
     			FROM AppPush_campaign_master_dtl WHERE domainId = p_domainId AND DATE(createdOn) BETWEEN v_fromDate AND v_toDate;
             
     		SELECT IFNULL(SUM(IFNULL(JSON_LENGTH(contactDtl),0)),0)	INTO v_totalWebPushContact
     			FROM webpush_masterCampaignDtl	WHERE domainId = p_domainId AND DATE(createdOn) BETWEEN  v_fromDate AND v_toDate;
     		
     		SELECT IFNULL(SUM(IFNULL(JSON_LENGTH(contactDtl), 0)),0)	INTO v_totalInAppContact
     			FROM  inApp_campaign_master_dtl	WHERE domainId	= p_domainId AND DATE(createdOn) BETWEEN v_fromDate AND v_toDate;
                 
     		
          
         
         
         
     		DROP TEMPORARY TABLE IF EXISTS tt_EmailcampaignDtl;	
     		CREATE TEMPORARY TABLE tt_EmailcampaignDtl
         
         WITH cte1 AS(
     		SELECT 	t1.campaignChatId , 
     				t1.campaignId, 
                     t1.`Name`,
                     IFNULL(t2.uniqueOpenCount,0) 		AS uniqueOpenRate, 
                     IFNULL(t2.uniqueClickCount, 0) 		AS uniqueClickRate
     			FROM ec_email_campaign_master_dtl 			t1	
     		LEFT JOIN ec_campaign_HistoryDtl						t2	ON t1.campaignId = t2.campaignId
     			WHERE t1.domainId = p_domainId		AND 	(DATE(t1.createdate) >= v_fromDate AND DATE(t1.createdate) <= v_toDate )
             ),
     		cte2 AS(
     		SELECT campaignId , 
                     COUNT(id) AS CountOfDelivery
     			FROM ec_campaign_contacts_dtl
     		WHERE domainId = p_domainId AND isSent = 1
     			GROUP BY domainId, campaignId 
     		)
             SELECT 
     			  
     				t1.campaignChatId		AS 'CampaignChatId',  
                     t1.`Name`				AS 'CampaignName',
                   
                  
                   
                   
     			
     				IFNULL((((t1.uniqueOpenRate * 100)/t2.CountOfDelivery) * 0.6),0)
     					+ IFNULL((((t1.uniqueClickRate * 100)/ t2.CountOfDelivery)* 0.4),0) AS EmailTotalRate
     			FROM cte1 t1
     			LEFT JOIN cte2 t2	
     				ON t1.campaignId = t2.campaignId ;
             
             
             
             
             
             
     		DROP TEMPORARY TABLE IF EXISTS tt_SMScampaignDtl;	
     		CREATE TEMPORARY TABLE tt_SMScampaignDtl
             
             WITH cte01 AS(
     			SELECT 	t1.`name` 					AS  'CampaignName',
                         t1.campaignChatId  			AS  'CampaignChatId',
                         COUNT(t2.`status`) 			AS 	'CampaignStatus',
                         JSON_LENGTH(t1.contactDtls) AS 	 'CustomerCount'
     				FROM sc_campaign_master_dtl  t1
     				LEFT JOIN sc_SMS_sent_status_details t2 ON t1.campaignchatid = t2.campaignChatId
     			WHERE t1.domainId = p_domainId AND t2.status = 'DELIVERED' AND
     					(DATE(t1.createdDate) >= v_fromDate AND DATE(t1.createdDate) <= v_toDate )
     					GROUP BY t1.name, t1.campaignChatId
             )
             SELECT CampaignChatId,  CampaignName, 
             CASE WHEN CustomerCount !=0 AND CampaignStatus !=0 THEN
             (((CampaignStatus*100)/CustomerCount)* 0.5) +(0 * 0.5) else 0 END AS SMSTotalRate from cte01;
             
             
             
             
             
             
   		DROP TEMPORARY TABLE IF EXISTS tt_WhatsappCampaignDtl;	
     		CREATE TEMPORARY TABLE tt_WhatsappCampaignDtl
     			with cte01 as(
     				select 	t1.campaignchatId		AS  'CampaignChatId',
     						t1.campName 			AS  'CampaignName',
     						SUM(JSON_LENGTH(t1.contactList)),
     						SUM(CASE WHEN t2.`status` = 'DELIVERY' OR t2.`status` = 'read'	THEN 1 ELSE 0 END) AS TotalDelivery,
     						SUM(CASE WHEN t2.`status` = 'read'	THEN 1 ELSE 0 END	) AS TotalRead
     				FROM wc_campaign_master_dtl t1
     				LEFT JOIN wc_analytics_history_dtl t2 ON t1.campaignchatId = t2.campaignchatId
     				WHERE t1.domainId = p_domainId AND (DATE(t1.createdDate) >= v_fromDate AND DATE(t1.createdDate) <= v_toDate) 
     				GROUP BY t1.campaignchatId, t1.campName)
     						SELECT CampaignChatId, CampaignName, 
     							 CASE WHEN TotalRead !=0 AND TotalDelivery !=0   THEN 
      								IFNULL((((TotalRead * 100)/ TotalDelivery) * 0.6),0)+ IFNULL((((1 * 100)/ TotalDelivery) * 0.4),0) ELSE 0 END  As  WhatsappTotalRate
     							FROM cte01 WHERE CampaignChatId is not null;
             
            
             
             
     				
                   DROP TEMPORARY TABLE IF EXISTS tt_WebPushCampaignDtl;	
     				CREATE TEMPORARY TABLE tt_WebPushCampaignDtl
     						WITH cte01 as(
     						SELECT t1.campaignChatId 			AS  'CampaignChatId',
     								t1.campaignName				AS  'CampaignName',
                                     SUM(CASE WHEN t2.`status`  = 'DELIVERY' OR t2.`status`  = 'OPEN'  THEN 1 ELSE 0 END) 		AS SendCount,
                                     SUM(CASE WHEN t2.`status`  = 'OPEN' THEN 1 ELSE 0 END)									AS ClickRateCount
                             FROM webpush_masterCampaignDtl t1
     						LEFT JOIN webpush_sent_status_details t2
     							ON t1.campaignChatId = t2.campaignChatId
     						WHERE t1.domainId = p_domainId AND t1.campaignChatId IS NOT NULL AND (DATE(t1.createdOn) >= v_fromDate AND DATE(t1.createdOn) <= v_toDate) 
                             GROUP BY  t1.campaignChatId,t1.campaignName
                     )
     			SELECT CampaignChatId, 
   					CampaignName, 
                       CASE WHEN ClickRateCount !=0 AND SendCount !=0 THEN 
   						(((ClickRateCount * 100)/SendCount)*1.0) ELSE 0 END AS WebPushTotalRate FROM cte01;
                     
     		 	
             
             with finalResult as(
             SELECT CampaignChatId, CampaignName AS 'Name', ROUND(IFNULL(SUM(Count),0)) AS 'Total' FROM 
             (
     				SELECT CampaignChatId, CampaignName,  EmailTotalRate * 0.3 as `Count` FROM tt_EmailcampaignDtl
                     UNION ALL
                     SELECT  CampaignChatId, CampaignName, SMSTotalRate * 0.15 as `Count` FROM tt_SMScampaignDtl
                     UNION ALL
                     SELECT CampaignChatId, CampaignName, WhatsappTotalRate * 0.25 as `Count` FROM tt_WhatsappCampaignDtl
                     UNION ALL
                     SELECT CampaignChatId, CampaignName, WebPushTotalRate * 0.15 as `Count` FROM tt_WebPushCampaignDtl
             )tt
             GROUP BY CampaignChatId,CampaignName
             )
             SELECT `Name`, Total FROM finalResult;
             
            
             
           DROP TEMPORARY TABLE tt_EmailcampaignDtl;
   		DROP TEMPORARY TABLE tt_SMScampaignDtl;
   		DROP TEMPORARY TABLE tt_WhatsappCampaignDtl;
   		DROP TEMPORARY TABLE tt_WebPushCampaignDtl;
           
            SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
     end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_get_analytics_weekly_campaign_summary_NLP_analysis` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_get_analytics_weekly_campaign_summary_NLP_analysis`(
   		p_domainId		INT
   )
BEGIN
   		DECLARE v_fromDate		DATE;
           DECLARE v_toDate		DATE DEFAULT NOW();
           
           SELECT date_sub( DATE(now()) , interval 6 day) INTO v_fromDate;
           
         
           
   		
           
           DROP TEMPORARY TABLE IF EXISTS tt_emailCampaign_main_dtl;
           
           CREATE TEMPORARY TABLE tt_emailCampaign_main_dtl
           WITH cte1 AS(
   			SELECT t1.campaignId, t1.campaignchatid, t1.`Name`, t1.createdate,
                   (IFNULL(t2.uniqueOpenCount,0) * 0.4) + (IFNULL(t2.uniqueClickCount,0) * 0.4) as Total
           FROM 
   			ec_email_campaign_master_dtl 			AS t1
   			LEFT JOIN ec_campaign_HistoryDtl 		AS t2 ON t1.campaignId = t2.campaignId
   			WHERE t1.domainId = p_domainId AND DATE(t1.createdate) BETWEEN v_fromDate AND v_toDate
   			)
   				SELECT  t1.campaignchatid AS 'ChatId', t1.`Name` AS `Name`, t1.Total + (COUNT(isSent) * 0.2) AS TotalCount  FROM cte1 as t1
   				LEFT JOIN ec_campaign_contacts_dtl AS t2 ON t1.campaignId = t2.campaignId AND t2.domainId = p_domainId AND isSent = 1
   				GROUP BY t1.campaignchatid,  t1.`Name`, t1.Total;
           
           
           
           
           
           
       DROP TEMPORARY TABLE IF EXISTS tt_smsCampaign_main_dtl;
           
           CREATE TEMPORARY TABLE tt_smsCampaign_main_dtl
            WITH cte1 AS(
   			SELECT t1.campaignchatid, t1.createdDate, t1.`name`, t2.`status` 
           FROM 
   			sc_campaign_master_dtl 			AS t1
   			LEFT JOIN sc_SMS_sent_status_details 		AS t2 ON t1.campaignChatId = t2.campaignChatId
   			WHERE t1.domainId = p_domainId and t2.`status` = 'DELIVERED' AND
               DATE(t1.createdDate) BETWEEN v_fromDate AND v_toDate
   			)
               SELECT  campaignchatid AS 'ChatId', `name` AS 'Name', (0 * 0.5)+(COUNT(`status`) * 0.5) as TotalCount  FROM cte1
               GROUP BY   campaignchatid, `name`;
   
   		
           
           
   			
               DROP TEMPORARY TABLE IF EXISTS tt_WhatsappCampaign_main_dtl;
           
   			CREATE TEMPORARY TABLE tt_WhatsappCampaign_main_dtl
              WITH cte1 as(
   				SELECT t1.campaignchatId, t1.campName, 
   				CASE WHEN status = 'read' THEN 1 ELSE 0 END AS `Status`
   				FROM 
   					wc_campaign_master_dtl t1
   					LEFT JOIN wc_analytics_history_dtl t2
   					ON t1.campaignchatId = t2.campaignchatId
   					WHERE t1.domainId = p_domainId
                        AND DATE(t1.createdDate) BETWEEN v_fromDate AND v_toDate
                       )
   				SELECT campaignchatId AS 'ChatId', campName  AS 'Name', (0 * 0.6) + (SUM(`Status`) * 0.4) as TotalCount  FROM cte1
   					GROUP BY  campaignchatId, campName; 
               
   			
               
   		
           
           DROP TEMPORARY TABLE IF EXISTS tt_WebPushCampaign_main_dtl;
           
           CREATE TEMPORARY TABLE tt_WebPushCampaign_main_dtl
   			WITH cte1 AS(
   				SELECT t1.campaignChatId, t1.campaignName, 
   				CASE WHEN t2.status = 'OPEN' THEN 1 ELSE 0 END AS `Open`
   				FROM webpush_masterCampaignDtl t1
   				LEFT JOIN webpush_sent_status_details t2
   				ON t1.campaignChatId = t2.campaignChatId
   				WHERE t2.domainId = p_domainId AND DATE(t1.createdOn) BETWEEN v_fromDate AND v_toDate
   				) 
   			SELECT campaignChatId AS 'ChatId',  campaignName AS 'Name', (COUNT(1)*0.4)+(SUM(`Open`)*0.6) AS TotalCount FROM
   			cte1
   			GROUP BY  campaignChatId, campaignName;
                   
   		
           
           
           
           
            DROP TEMPORARY TABLE IF EXISTS tt_AppPushCampaign_main_dtl;
           
           CREATE TEMPORARY TABLE tt_AppPushCampaign_main_dtl
   			WITH cte1 AS(
   				SELECT t1.campaignChatId, t1.campaignName, 
   				CASE WHEN t2.status = 'OPEN' THEN 1 ELSE 0 END AS `Open`
   				FROM AppPush_campaign_master_dtl t1
   				LEFT JOIN AppPush_tb_openRate_history_dtl t2
   				ON t1.campaignChatId = t2.campaignChatId
   				WHERE t2.domainId = p_domainId
                   AND DATE(t1.createdOn) BETWEEN v_fromDate AND v_toDate 
   				) 
   			SELECT campaignChatId AS 'ChatId', campaignName AS 'Name', (COUNT(1)*0.4)+(SUM(`Open`)*0.6) AS TotalCount FROM
   			cte1
   			GROUP BY  campaignChatId, campaignName;
           
          
           
            
   		
   		DROP TEMPORARY TABLE IF EXISTS tt_inAppCampaign_main_dtl;
           
           CREATE TEMPORARY TABLE tt_inAppCampaign_main_dtl
            WITH cte1 AS(
   			SELECT t1.id , t1.campaignChatId, t1.campaignName, isSent FROM 
   			inApp_campaign_master_dtl t1
   			LEFT JOIN inApp_campaign_contacts_dtl t2
   			ON t1.id = t2.campaignId
   			WHERE t1.domainId = p_domainId  AND t2.isSent = 1
               AND DATE(t1.createdOn) BETWEEN v_fromDate AND v_toDate
   			)
   			SELECT campaignChatId AS 'ChatId', campaignName AS 'Name', (0 * 0.5)+COUNT(isSent * 0.5) AS TotalCount FROM cte1
   			GROUP BY  campaignChatId, campaignName;
   			
          
              
              
              SELECT  tt.ChatId, tt.`Name`,  SUM(tt.TotalCount) AS Total
   			FROM (
   					SELECT * FROM tt_emailCampaign_main_dtl
                       UNION ALL
                       SELECT  * FROM tt_smsCampaign_main_dtl
                       UNION ALL
                       SELECT * FROM tt_WhatsappCampaign_main_dtl 
                       UNION ALL
                       SELECT * FROM tt_WebPushCampaign_main_dtl
                       UNION ALL
   					SELECT * FROM tt_AppPushCampaign_main_dtl
                       UNION ALL
                       SELECT * FROM tt_inAppCampaign_main_dtl
               ) as tt
               WHERE ChatId IS NOT NULL
              GROUP BY  ChatId, tt.`Name`
              ORDER BY 3 DESC
              
              ;
              
   END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_get_appPush_open_click_contact_dtl_nlp` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_get_appPush_open_click_contact_dtl_nlp`(
	p_domainId					INT,
    p_campaignChatId			VARCHAR(300)
)
BEGIN
		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        
        SELECT t1.domainId, t1.campaignChatId, t1.actionId, t2.id, t2.firstName, t2.lastName, t2.deviceId, t2.deviceOS, t2.pushNotificationId
			FROM AppPush_tb_indiv_user_click_open_cnt_dtl			t1
			JOIN wc_user_contact_dtl							t2	ON t1.userID = t2.id
		WHERE t1.campaignChatId = p_campaignChatId and t1.domainId = p_domainId and t1.actionId in (3, 4);
        
        
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;


end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_get_business_meta_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_get_business_meta_details`(
	p_domainId			INT,
	p_mobileNumber		VARCHAR(30)
)
BEGIN
			SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
            
            IF EXISTS(SELECT 1 FROM wc_business_configuration where domainId = p_domainId and (mobileNumber = p_mobileNumber OR IFNULL(p_mobileNumber, '') = ''))
            THEN
            
            SELECT mobileNumber, authToken,phoneNumberId,wabaId, businessId
				FROM wc_business_configuration
             where domainId = p_domainId and (mobileNumber = p_mobileNumber OR IFNULL(p_mobileNumber, '') = '');
             
             ELSE
             
             SELECT -1 as errCode	,"No Data Found" as errMsg;
             
             END IF;
            
            SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_get_campaign_bell_notification` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_get_campaign_bell_notification`(
    	p_domainId					INT,
  	p_limit  int,
  	p_offset int
    
    )
BEGIN
     	DECLARE V_offset int;
   	set V_offset = p_offset * p_limit;
  	
    		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
            
  		  update wc_overall_campaign_bell_notification
  		  set isNotification_Sent=1
  		  where domainId = p_domainId and deliveryTime <= now();
  		  
    			
    				SELECT id, channelType, title, message, isRead, `status` ,createdOn ,isNotification_Sent, campaignchatId
   					FROM wc_overall_campaign_bell_notification
   						WHERE domainId = p_domainId and isNotification_Sent=1
   						ORDER BY updatedOn desc limit V_offset,p_limit;
    			
    		  
            SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
    
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_get_campaign_bell_notification_bkp_2026_02_13` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_get_campaign_bell_notification_bkp_2026_02_13`(
   	p_domainId					INT
   
   )
BEGIN
   
   		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
           
   			
   				SELECT id, channelType, title, message, isRead, `status` ,createdOn 
  					FROM wc_overall_campaign_bell_notification
  						WHERE domainId = p_domainId
  						ORDER BY createdOn desc limit 10 ;
   			
   		  
           SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   
   END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_get_campaign_chat_draft_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_get_campaign_chat_draft_dtl`(	
	p_domainId			INT,
	p_campaignChatId	VARCHAR(300)
   
)
BEGIN
		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        
        SELECT domainId, campaignChatId, payLoad
			FROM wc_tb_campaign_chat_draft_dtl WHERE campaignChatId = p_campaignChatId
            AND domainId = p_domainId
            ;
        
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_get_campaign_contact_file` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_get_campaign_contact_file`(
 	p_domainId		INT,
	p_limit			INT,
    p_offset		INT
 )
BEGIN
			DECLARE v_offset INT;
            
           SET  v_offset = p_limit * p_offset;
 
 		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
 			
             SELECT 
 					fileId
 					,domainId	
 					,fileName
 					,filePath
 					,status
 					,records
 					,createdOn
 					,updatedOn
 			FROM tb_campaignContactFileHistory
             WHERE domainId = p_domainId
             ORDER BY createdOn DESC
             limit v_offset, p_limit;
             
 		SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_get_campaign_dlt_using_chatId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_get_campaign_dlt_using_chatId`( 
      	p_domainId		INT
      )
BEGIN
   	SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
 	
     
     DROP TEMPORARY TABLE IF EXISTS tt_campaign_details;
     CREATE TEMPORARY TABLE tt_campaign_details
   	SELECT 	domainId, id as 'CampaignId', campaignchatid  AS 'CampaignChatId', `name` AS 'CampaignName', 'SMS' as 'ChannelName', date_format(createdDate, '%Y-%m-%d %H:%i') as createdate
   	FROM 	sc_campaign_master_dtl 
   	WHERE 	domainId = p_domainId 
   	UNION ALL  
   	SELECT 	domainId, campaignId as 'CampaignId', campaignchatid  AS 'CampaignChatId', `Name` AS 'CampaignName', 'Email' as 'ChannelName', date_format(createdate, '%Y-%m-%d %H:%i') as createdate
   	FROM 	ec_email_campaign_master_dtl 
   	WHERE 	domainId = p_domainId and isIndivCamp NOT IN (1)
     UNION ALL
 	SELECT 	domainId, id as 'CampaignId', campaignchatid  AS 'CampaignChatId', campName AS 'CampaignName', 'Whatsapp' as 'ChannelName', date_format(createdDate, '%Y-%m-%d %H:%i') as createdate
   	FROM 	wc_campaign_master_dtl 
   	WHERE 	domainId = p_domainId
     UNION ALL
     SELECT 	domainId, id as 'CampaignId', campaignChatId  AS 'CampaignChatId', campaignName AS 'CampaignName', 'AppPush' as 'ChannelName', date_format(createdOn, '%Y-%m-%d %H:%i') as createdate
   	FROM 	AppPush_campaign_master_dtl 
   	WHERE 	domainId = p_domainId
     UNION ALL
     SELECT 	domainId, id as 'CampaignId', campaignChatId  AS 'CampaignChatId', campaignName AS 'CampaignName', 'WebPush' as 'ChannelName', date_format(createdOn, '%Y-%m-%d %H:%i') as createdate
   	FROM 	webpush_masterCampaignDtl 
   	WHERE 	domainId = p_domainId
     UNION ALL
	SELECT 	domainId, 0 as 'CampaignId', "Hubspot@123"  AS 'CampaignChatId', 'Hubspot' AS 'CampaignName', 'IndivCampaign' as 'ChannelName', date_format(createdate, '%Y-%m-%d %H:%i') as createdate
   	FROM 	ec_email_campaign_master_dtl 
   	WHERE 	domainId = p_domainId and isIndivCamp IN (1);
    
	-- =========================================== 
			-- grouping the result
	-- ===========================================
    
    WITH cte01 AS
    (
		SELECT CampaignId, CampaignChatId, CampaignName,ChannelName, createdate,  MIN(createdate) OVER(PARTITION BY CampaignChatId, CampaignName) AS 'mincreated'
		FROM tt_campaign_details
    )
    SELECT  CampaignChatId, JSON_arrayagg(JSON_OBJECT('CampaignId', CampaignId,'ChannelName', ChannelName,'CampaignName', CampaignName)) AS 'campaign_Details', mincreated
    FROM cte01
    GROUP BY CampaignChatId, mincreated
    ORDER BY mincreated DESC;
		
        
    
   	SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
     
 		
   
      END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_get_campaign_knowledge_base_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_get_campaign_knowledge_base_dtl`(
   	p_domainId		INT
   )
BEGIN
   		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
           
   			SELECT 	kbCampId ,domainId ,companyName	,url, industrial_type, contact_info, product_info ,
            filename ,mimetype ,size ,uploadUrl , pdf_info
				FROM tb_campaign_knowledge_base_dtl WHERE domainId = p_domainId;					
   
           SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   
   END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_get_ccaas_customer_chat_history_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_get_ccaas_customer_chat_history_dtl`(p_domainId 		INT
 ,p_campaignChatId 	VARCHAR(50)
 ,p_limit			SMALLINT
 )
BEGIN
 		IF p_limit IS NOT NULL THEN 
 				SELECT chatId,domainId ,campaignChatId ,ccaasMessage ,createdOn
                 FROM wc_tb_campaign_customer_chat_conversation_History
 				WHERE domainId = p_domainId AND campaignChatId = p_campaignChatId
 				ORDER BY createdOn DESC
                 LIMIT p_limit;
         ELSE
 				SELECT chatId,domainId ,campaignChatId ,ccaasMessage ,createdOn
                 FROM wc_tb_campaign_customer_chat_conversation_History
 				WHERE domainId = p_domainId AND campaignChatId = p_campaignChatId
 				ORDER BY createdOn DESC;
         END IF;
         
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_get_contact_information_dtl_based_on_email` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_get_contact_information_dtl_based_on_email`(
 	p_domainId		INT,
     p_email			VARCHAR(200)
 )
begin
 			SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
             
             SELECT id
 				, domainId
 				, firstName
 				, lastName
 				, whatsappNumber
 				, phoneNumber
 				, email
 				, customerType
 				, tags
 				, location
 				, city
 				, address
 				, state
 				, country
 				, postCode
 				, createdAt
 				, updatedAt
 				, source
 				, deviceId
 				, sip_log_id
 				, extension
 				, lifeCycleStage
             FROM wc_user_contact_dtl WHERE domainId = p_domainId and email like CONCAT('%',p_email,'%');
 			
             
             SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
             
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_get_cron_newSchedule` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_get_cron_newSchedule`()
BEGIN
			DECLARE v_currentTime   			DATETIME;			DECLARE v_id		  				INT;
            DECLARE v_domainId					INT;				DECLARE v_reportId					INT;
            DECLARE v_reportResultStartDate		DATE; 				DECLARE v_reportResultEndDate  		DATE;
            DECLARE v_recurrenceType			TINYINT;			DECLARE v_repeatEvery				INT;
            DECLARE v_DateNo					INT;				DECLARE v_maxWeek					TINYINT;
			DECLARE v_UTC_startTime				DATETIME;			DECLARE v_UTC_startTime_weekday		INT;
            DECLARE v_isSunday 					TINYINT;			DECLARE v_isMonday					TINYINT; 
            DECLARE v_isTueday					TINYINT;			DECLARE v_isWednesday				TINYINT;
            DECLARE v_isThursday				TINYINT;			DECLARE v_isFriday					TINYINT;
            DECLARE v_isSaturday				TINYINT;			DECLARE v_nextWeek					TINYINT;
            DECLARE v_UTC_startTime_week		INT;				DECLARE v_resultDate				DATETIME;
			DECLARE v_minWeek					TINYINT;
            
            SET v_currentTime = DATE_FORMAT(NOW(), '%Y-%m-%d %H:%i:00');		
            
            -- ===============================================================================================================================   
			DROP TEMPORARY TABLE IF EXISTS tt_least_record;
            CREATE TEMPORARY TABLE tt_least_record
				(recId						INT,  		domainId					INT,  	 		reportId					INT, 
				recurrenceType 				INT, 		reportResultStartDate		DATE, 	 		reportResultEndDate			DATE, 
				fileTypeIsPDF				TINYINT, 	fileTypeIsCSV				TINYINT, 		fileTypeIsXLS				TINYINT, 
				fileTypeIsXLSL				TINYINT, 	emailId						VARCHAR(90), 	`subject`					VARCHAR(500), 
				message						TEXT, 		id							INT, 			 UTC_startTime				DATETIME, 
				repeatEvery 				INT, 		DateNo						INT,			 maxWeek						TINYINT,
                minWeek						TINYINT,	isSunday					TINYINT,		 isMonday					TINYINT,
				isTueday					TINYINT,	isWednesday 				TINYINT,		 isThursday 					TINYINT,
				isFriday 					TINYINT,	isSaturday 					TINYINT);
                
             -- ===============================================================================================================================   
            INSERT INTO tt_least_record ( recId , domainId , reportId, recurrenceType , reportResultStartDate 
						, reportResultEndDate, fileTypeIsPDF, fileTypeIsCSV	, fileTypeIsXLS	, fileTypeIsXLSL			
						, emailId , `subject`, message , id	, UTC_startTime	, repeatEvery )
				SELECT t1.recId, t1.domainId, t1.reportId, t1.recurrenceType, t1.reportResultStartDate, t1.reportResultEndDate, t1.fileTypeIsPDF, t1.fileTypeIsCSV, 
						t1.fileTypeIsXLS, t1.fileTypeIsXLSL, t1.emailId, t1.`subject`, t1.message, t2.id, t2.UTC_startTime, NULL 
				FROM wc_tb_recurrence_new_schedule 	t1
					JOIN wc_tb_recurrence_new_schedule_Once 		t2 ON t1.recId =t2.FK_recId
				WHERE UTC_startTime <= v_currentTime AND isCompleted = 0 AND isStop = 0 
				ORDER BY  t2.UTC_startTime LIMIT 20;
												
                                                -- ************************* Daily *************************
			INSERT INTO tt_least_record ( recId , domainId , reportId, recurrenceType , reportResultStartDate 
						, reportResultEndDate, fileTypeIsPDF, fileTypeIsCSV	, fileTypeIsXLS	, fileTypeIsXLSL			
						, emailId , `subject`, message , id	, UTC_startTime	, repeatEvery )		
				SELECT t1.recId, t1.domainId, t1.reportId, t1.recurrenceType, t1.reportResultStartDate, t1.reportResultEndDate, t1.fileTypeIsPDF, t1.fileTypeIsCSV, 
						t1.fileTypeIsXLS, t1.fileTypeIsXLSL, t1.emailId, t1.`subject`, t1.message, t2.id, t2.UTC_startTime, t2.repeatEvery
				FROM wc_tb_recurrence_new_schedule 	t1
					JOIN wc_tb_recurrence_new_schedule_Daily 		t2 ON t1.recId =t2.FK_recId
				WHERE UTC_startTime <= v_currentTime AND isCompleted = 0 AND isStop = 0 
				ORDER BY  t2.UTC_startTime LIMIT 10;
            
													-- ************************* Monthly *************************
            INSERT INTO tt_least_record ( recId , domainId , reportId, recurrenceType , reportResultStartDate 
						, reportResultEndDate, fileTypeIsPDF, fileTypeIsCSV	, fileTypeIsXLS	, fileTypeIsXLSL			
						, emailId , `subject`, message , id	, UTC_startTime	, repeatEvery , DateNo)		
				SELECT t1.recId, t1.domainId, t1.reportId, t1.recurrenceType, t1.reportResultStartDate, t1.reportResultEndDate, t1.fileTypeIsPDF, t1.fileTypeIsCSV, 
						t1.fileTypeIsXLS, t1.fileTypeIsXLSL, t1.emailId, t1.`subject`, t1.message, t2.id, t2.UTC_startTime, t2.repeatEvery , t2.DateNo
				FROM wc_tb_recurrence_new_schedule 	t1
					JOIN wc_tb_recurrence_new_schedule_Monthly 		t2 ON t1.recId =t2.FK_recId
				WHERE UTC_startTime <= v_currentTime AND isCompleted = 0 AND isStop = 0  
				ORDER BY  t2.UTC_startTime  LIMIT 10;
                
													-- ************************* Weekly *************************
                INSERT INTO tt_least_record ( recId , domainId , reportId, recurrenceType , reportResultStartDate 
						, reportResultEndDate, fileTypeIsPDF, fileTypeIsCSV	, fileTypeIsXLS	, fileTypeIsXLSL			
						, emailId , `subject`, message , id	, UTC_startTime	, repeatEvery ,maxWeek, minWeek , isSunday , isMonday,
							isTueday, isWednesday, isThursday, isFriday, isSaturday	
                        )		
				SELECT t1.recId, t1.domainId, t1.reportId, t1.recurrenceType, t1.reportResultStartDate, t1.reportResultEndDate, t1.fileTypeIsPDF, t1.fileTypeIsCSV, 
						t1.fileTypeIsXLS, t1.fileTypeIsXLSL, t1.emailId, t1.`subject`, t1.message, t2.id, t2.UTC_startTime, t2.repeatEvery, t2.maxWeek , t2.minWeek, t2.isSunday , 
                        t2.isMonday, t2.isTueday, t2.isWednesday, t2.isThursday, t2.isFriday, t2.isSaturday
				FROM wc_tb_recurrence_new_schedule 	t1
					JOIN wc_tb_recurrence_new_schedule_Weekly 		t2 ON t1.recId =t2.FK_recId
				WHERE UTC_startTime <= v_currentTime AND isCompleted = 0 AND isStop = 0  
				ORDER BY  t2.UTC_startTime  LIMIT 10;
                
            -- ============================================================================================================================
			-- SELECT *	FROM tt_least_record;
            
			SELECT 	recId, domainId, reportId, reportResultStartDate, reportResultEndDate,recurrenceType ,fileTypeIsPDF, fileTypeIsCSV, fileTypeIsXLS, fileTypeIsXLSL, 
					emailId, `subject`, message	FROM tt_least_record 
            ORDER BY UTC_startTime;

            
			DROP TEMPORARY TABLE IF EXISTS tt_least_record;	
            DROP TEMPORARY TABLE IF EXISTS tt_week_choosen;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_get_customer_contact_custom_field` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_get_customer_contact_custom_field`(	p_domainId		INT
    )
BEGIN
    
        
        DECLARE v_tableName		VARCHAR(100);
        SET v_tableName = concat("customer_contact_",p_domainid);
        
        SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        
        SELECT 	id
 			,	columName
 			,	columnLabel
 			,	columnType
 			,	columnValue
 			,	columnCategory
 			,	placeHolder
 			,	isMandatory
 			,	errMsg
 			,	isDisplay
        FROM 	wc_customer_contact_column_properties
        WHERE 	tableName	= v_tableName;
        
        
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_get_email_open_click_contact_dtl_nlp` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_get_email_open_click_contact_dtl_nlp`(
	p_domainId					INT,
    p_campaignChatId			VARCHAR(300)
)
BEGIN
		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        
        SELECT t1.domainId, t1.campaignChatId, t1.actionId, t2.id, t2.firstName, t2.lastName, t2.email 
			FROM Email_tb_indiv_user_click_open_cnt_dtl			t1
			JOIN wc_user_contact_dtl							t2	ON t1.userID = t2.id
		WHERE t1.campaignChatId = p_campaignChatId and t1.domainId = p_domainId and t1.actionId in (3, 4);
        
        
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;


end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_get_individual_analytics_for_open_click_and_delivery` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_get_individual_analytics_for_open_click_and_delivery`(	
	p_domainId	  			INT,
  	p_campaignChatId		VARCHAR(300)
  )
BEGIN
  		
          DECLARE v_emailCampaignId				INT;
          DECLARE v_emailuniqueOpenRate			INT DEFAULT 0;
          DECLARE v_emailuniqueClickRate		INT	DEFAULT 0;
          DECLARE v_emaildeliveryRate			INT	DEFAULT 0;
          DECLARE v_emailCustomerCount			INT	DEFAULT 0;
          
          DECLARE v_smsdeliveryRate				INT	DEFAULT 0;
          DECLARE v_smsCustomerCount			INT	DEFAULT 0;
          
          DECLARE v_webpushClickRate			INT DEFAULT 0;
          DECLARE v_webpushDeliveryRate			INT DEFAULT 0;
          DECLARE v_webpushCustomerCount		INT DEFAULT 0;
          
          
          DECLARE v_apppushClickRate			INT DEFAULT 0;
          DECLARE v_apppushDeliveryRate			INT DEFAULT 0;
          DECLARE v_apppushCustomerCount		INT DEFAULT 0;
          
          DECLARE v_inAppCampaignId				INT;
          DECLARE v_inAppClickRate				INT DEFAULT 0;
          DECLARE v_inAppCustomerCount			INT DEFAULT 0;
          
          DECLARE v_whatsappOpenRate			INT	DEFAULT 0;
          DECLARE v_whatsappDeliveryRate		INT	DEFAULT 0;
           DECLARE v_whatsappCustomerCount		INT	DEFAULT 0;
          
          SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
          
          SELECT campaignId, IFNULL(JSON_LENGTH(contactslist),0) 
 			INTO v_emailCampaignId , v_emailCustomerCount
          FROM ec_email_campaign_master_dtl where domainId = p_domainId and campaignchatid = p_campaignChatId and isIndivCamp != 2;
          
        /*  		====================== recorrected on 29-11-2025 ====================
        
          SELECT IFNULL(uniqueOpenCount, 0), IFNULL(uniqueClickCount, 0) 
 			INTO  v_emailuniqueOpenRate, v_emailuniqueClickRate
 		FROM ec_campaign_HistoryDtl WHERE domainId =  p_domainId and campaignId = v_emailCampaignId;
        
					=========================================================================
          */		
          
          -- ============================ Email ================================
          -- ====================================================================
          
         IF  p_campaignChatId IN ("Hubspot@123") THEN 
        
				SELECT COUNT(DISTINCT(t1.userID)) INTO  v_emailuniqueOpenRate 
					FROM Email_tb_indiv_user_click_open_cnt_dtl t1 
						JOIN ec_email_campaign_master_dtl t2	On t1.domainId = t2.domainId AND t1.campaignChatId = t2.campaignchatid
                    WHERE t1.domainId = p_domainId AND t2.isIndivCamp = 1 AND t1.actionId = 3; 
                    
				SELECT COUNT(DISTINCT(t1.userID)) INTO  v_emailuniqueClickRate 
					FROM Email_tb_indiv_user_click_open_cnt_dtl t1
						JOIN ec_email_campaign_master_dtl t2	ON t1.domainId = t2.domainId AND t1.campaignChatId = t2.campaignchatid
                    WHERE t1.domainId = p_domainId AND t2.isIndivCamp = 1 AND t1.actionId = 4; 
          
				SELECT COUNT(t1.isSent)  INTO v_emaildeliveryRate 
					FROM ec_campaign_contacts_dtl t1
						JOIN ec_email_campaign_master_dtl t2	On t1.domainId = t2.domainId AND t1.campaignId = t2.campaignId
					WHERE t1.domainId = p_domainId  AND t2.isIndivCamp = 1 AND isSent = 1; 
          
          ELSE
					
				SELECT COUNT(DISTINCT(userID)) INTO  v_emailuniqueOpenRate FROM Email_tb_indiv_user_click_open_cnt_dtl 
					WHERE campaignChatId = p_campaignChatId AND domainId = p_domainId AND actionId = 3; 
                
				SELECT COUNT(DISTINCT(userID)) INTO  v_emailuniqueClickRate FROM Email_tb_indiv_user_click_open_cnt_dtl 
					WHERE campaignChatId = p_campaignChatId AND domainId = p_domainId AND actionId = 4; 
          
				SELECT COUNT(isSent)  INTO v_emaildeliveryRate FROM ec_campaign_contacts_dtl 
					WHERE domainId = p_domainId AND campaignId = v_emailCampaignId AND isSent = 1; 
          
			END IF;	
          
				SELECT v_emailuniqueOpenRate as emailuniqueOpenRate, v_emailuniqueClickRate as emailuniqueClickRate, 
					v_emaildeliveryRate as emaildeliveryRate , v_emailCustomerCount as emailCustomerCount;
          
         
			-- ============================ SMS ================================
            -- ==================================================================
 		
         SELECT IFNULL(JSON_LENGTH(contactDtls),0)	INTO v_smsCustomerCount FROM sc_campaign_master_dtl WHERE domainId = p_domainId AND campaignchatid = p_campaignChatId ;
  
  		SELECT count(id) INTO  v_smsdeliveryRate FROM sc_SMS_sent_status_details WHERE `status` = 'DELIVERED' AND domainId = p_domainId AND campaignChatId = p_campaignChatId ;
  		
          SELECT v_smsdeliveryRate as smsdeliveryRate , v_smsCustomerCount as smsCustomerCount;
          
          
		 -- ================================ Web Push =================================================
         -- ===========================================================================================
  			
  		SELECT count(id) INTO  v_webpushClickRate FROM webpush_sent_status_details WHERE domainId = p_domainId AND campaignChatId = p_campaignChatId AND `status` = 'OPEN';
          
          SELECT count(id) INTO  v_webpushDeliveryRate FROM webpush_sent_status_details WHERE domainId = p_domainId AND campaignChatId = p_campaignChatId;
          
          select IFNULL(JSON_LENGTH(contactDtl),0)  INTO v_webpushCustomerCount FROM webpush_masterCampaignDtl WHERE domainId	 = p_domainId
          AND campaignChatId = p_campaignChatId
          ;
          
          SELECT v_webpushClickRate AS webpushClickRate , v_webpushDeliveryRate AS webpushDeliveryRate, v_webpushCustomerCount AS webpushCustomerCount;
  
  
		 -- ================================ App Push =================================================
         -- ===========================================================================================
          
           SELECT COUNT(id) INTO v_apppushClickRate FROM AppPush_tb_openRate_history_dtl where domainId = p_domainId AND campaignChatId = p_campaignChatId AND `status` = 'OPEN';
          
  		 SELECT COUNT(id) INTO v_apppushDeliveryRate FROM AppPush_tb_openRate_history_dtl where domainId = p_domainId AND campaignChatId = p_campaignChatId;
           
          SELECT IFNULL(JSON_LENGTH(contactDtl),0) INTO v_apppushCustomerCount FROM  AppPush_campaign_master_dtl WHERE domainId = p_domainId AND campaignChatId = p_campaignChatId;
           
           SELECT v_apppushClickRate AS apppushClickRate, v_apppushDeliveryRate AS apppushDeliveryRate, v_apppushCustomerCount AS apppushCustomerCount;
           
           
 		 -- ================================ inApp Push =================================================
         -- ===========================================================================================          
          
          SELECT id , JSON_LENGTH(contactDtl) INTO v_inAppCampaignId, v_inAppCustomerCount FROM inApp_campaign_master_dtl WHERE domainId = p_domainId AND campaignChatId = p_campaignChatId;
          
          SELECT COUNT(id) INTO v_inAppClickRate FROM inApp_campaign_contacts_dtl where campaignId =  v_inAppCampaignId AND domainId = p_domainId AND isSent = 1;
          
          SELECT v_inAppClickRate AS inAppClickRate , v_inAppCustomerCount AS inAppCustomerCount;
          
          
          -- ================================ Whatsapp =================================================
         -- ===========================================================================================          
          
          SELECT COUNT(id) INTO v_whatsappOpenRate 
  			FROM wc_analytics_history_dtl WHERE domainId = p_domainId and campaignchatId = p_campaignChatId and `status` = 'read';
              
           SELECT COUNT(id) INTO v_whatsappDeliveryRate 
  			FROM wc_analytics_history_dtl WHERE domainId = p_domainId and campaignchatId = p_campaignChatId;    
             
		  
          SELECT JSON_LENGTH(contactList)  INTO v_whatsappCustomerCount FROM wc_campaign_master_dtl WHERE domainId = p_domainId and campaignchatId = p_campaignChatId;    
              
  		
          SELECT v_whatsappDeliveryRate as whatsappDeliveryRate, v_whatsappOpenRate AS whatsappOpenRate, v_whatsappCustomerCount AS whatsappCustomerCount;
          
          SELECT 
          (v_whatsappDeliveryRate + v_emaildeliveryRate + v_smsdeliveryRate + v_webpushDeliveryRate + v_apppushDeliveryRate ) AS TotalDeliveryCount, 
          (v_whatsappOpenRate + v_emailuniqueOpenRate) 																		  AS TotalOpenRate,
  		(v_inAppClickRate+ v_apppushClickRate+ v_apppushClickRate+ v_webpushClickRate+ v_emailuniqueClickRate) 				  AS TotalClickRate,
         (v_emailCustomerCount+ v_smsCustomerCount + v_webpushCustomerCount + v_apppushCustomerCount + v_inAppCustomerCount + v_whatsappCustomerCount)
																															  AS TotalCustomerCount;
          
  		
          
          SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
                  
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_get_knowledge_base_pdf_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_get_knowledge_base_pdf_dtl`(
p_domainId		INT,
p_uniqueId		varchar(50)
)
begin
		set session transaction isolation level read uncommitted;
	
		SELECT id ,domainId ,uniqueId ,companyName ,industrial_type ,filename ,minetype ,uploadUrl ,size ,pdf_info ,createdOn ,updatedOn
			FROM wc_tb_knowledge_base_pdf_dtl	
         WHERE domainId = p_domainId AND  (IFNULL(p_uniqueId, '')= '' OR uniqueId = p_uniqueId) ;
    
		set session transaction isolation level repeatable read;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_get_knowledge_base_website_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_get_knowledge_base_website_dtl`(
p_domainId		INT
)
begin
		set session transaction isolation level read uncommitted;
	
		SELECT id, domainId, companyName, industrialType, websideUrl, productInfo, contactInfo, createdOn, updatedOn
         from wc_tb_knowledge_base_website_dtl
         WHERE domainId = p_domainId;
    
		set session transaction isolation level repeatable read;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_get_live_schedule_campaign` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_get_live_schedule_campaign`(
 	p_domainId				INT,
 	p_CampaignChatId		VARCHAR(300)
 )
BEGIN		
 			DECLARE v_totalDelivered int default 0;
             
               SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;   
 		
 			DROP TEMPORARY TABLE IF EXISTS tt_campaign_for_all_channel;		
 			CREATE TEMPORARY TABLE tt_campaign_for_all_channel
             
 					SELECT campaignchatid AS 'CampaignChatId', domainId AS 'DomainId','Email' AS 'Channel', `Name` AS 'CampaignName', -- JSON_LENGTH(contactslist) AS 'CustomerCount', 
                     createdate FROM ec_email_campaign_master_dtl WHERE campaignchatid = p_CampaignChatId and domainId = p_domainId
 						UNION ALL
 							SELECT campaignchatid, domainId , 'SMS', `name`, -- JSON_LENGTH(contactDtls), 
                             createdDate FROM sc_campaign_master_dtl WHERE campaignchatid = p_CampaignChatId AND domainId = p_domainId
 						UNION ALL
 							SELECT campaignchatid, domainId, 'Whatsapp', campName, -- JSON_LENGTH(contactList), 
                             createdDate from wc_campaign_master_dtl where campaignchatid = p_CampaignChatId  AND domainId = p_domainId
 						UNION ALL
 							SELECT campaignChatId , domainId, 'AppPush', campaignName, -- JSON_LENGTH(contactDtl), 
                             createdOn from AppPush_campaign_master_dtl  where campaignChatId = p_CampaignChatId  AND domainId = p_domainId
 						UNION ALL
 							SELECT campaignChatId, domainId, 'WebPush', campaignName, -- JSON_LENGTH(contactDtl), 
                             createdOn from webpush_masterCampaignDtl where campaignChatId = p_CampaignChatId  AND domainId = p_domainId
 						UNION ALL
 							SELECT campaignChatId, domainId, 'inApp', campaignName, -- JSON_LENGTH(contactDtl), 
                             createdOn From inApp_campaign_master_dtl  where campaignChatId = p_CampaignChatId  AND domainId = p_domainId;	
 							
 			
 			
 			DROP TEMPORARY TABLE IF EXISTS tt_campaignAction_for_all_channel;			-- ********************** Storing unique sent, open and click count ***********************
 			CREATE TEMPORARY TABLE tt_campaignAction_for_all_channel
             
 				SELECT   distinct campaignChatId,  count(distinct userID) as userCount , 'Email' as 'channel',  'Open'as 'action' FROM Email_tb_indiv_user_click_open_cnt_dtl 
 												WHERE campaignChatId = p_CampaignChatId and domainId = p_domainId and actionId IN (3)
                                                 group by campaignChatId
 				UNION ALL
                 SELECT   distinct campaignChatId, count(distinct userID ), 'Email',  'Click' FROM Email_tb_indiv_user_click_open_cnt_dtl 
 												WHERE campaignChatId = p_CampaignChatId and domainId = p_domainId and actionId IN (4)
                                                  group by campaignChatId
 				UNION ALL
                 SELECT  distinct b.campaignChatId, count(distinct a.isSent) ,  'Email' , 'Delivery'  FROM ec_campaign_contacts_dtl a join ec_email_campaign_master_dtl b on a.campaignId = b.campaignId and a.domainId = b.domainId  WHERE b.campaignchatid = p_CampaignChatId and a.domainId = p_domainId and a.isSent IN (1) group by b.campaignChatId
                                                  
 				UNION ALL			
 				SELECT   campaignChatId,  count(distinct userID) , 'SMS' , 'Delivery'  FROM sms_tb_indiv_user_click_open_cnt_dtl 
 												WHERE campaignChatId = p_CampaignChatId and domainId = p_domainId and actionId IN (1)
                                                  group by campaignChatId
 				UNION ALL
                 SELECT   campaignChatId,  count(distinct userID) , 'SMS' , 'Click'  FROM sms_tb_indiv_user_click_open_cnt_dtl 
 												WHERE campaignChatId = p_CampaignChatId AND domainId = p_domainId AND actionId IN (4)
                                                  group by campaignChatId
                                                 
 				UNION ALL			
 				SELECT  campaignChatId, count(distinct userID) , 'Whatsapp' , "Delivery"  FROM whatsapp_tb_indiv_user_click_open_cnt_dtl 
 												WHERE campaignChatId = p_CampaignChatId AND domainId = p_domainId AND actionId IN (2)
                                                  group by campaignChatId
                 UNION ALL
 				SELECT  campaignChatId, count(distinct userID) , 'Whatsapp' , 'Open'  FROM whatsapp_tb_indiv_user_click_open_cnt_dtl 
 												WHERE campaignChatId = p_CampaignChatId AND domainId = p_domainId AND actionId IN (3)
                                                  group by campaignChatId
 				UNION ALL
 				SELECT  campaignChatId, count(distinct userID) , 'Whatsapp' , "Click"  FROM whatsapp_tb_indiv_user_click_open_cnt_dtl 
 												WHERE campaignChatId = p_CampaignChatId AND domainId = p_domainId AND actionId IN (4)
                                                  group by campaignChatId
                                                 
 				UNION ALL			
 				SELECT  campaignChatId,  count(distinct userID) , 'AppPush' , "Delivery"  FROM AppPush_tb_indiv_user_click_open_cnt_dtl 
 												WHERE campaignChatId = p_CampaignChatId and domainId = p_domainId and actionId IN (2)
                                                  group by campaignChatId
 				UNION ALL
 				SELECT  campaignChatId,  count(distinct userID) , 'AppPush' , 'Open'  FROM AppPush_tb_indiv_user_click_open_cnt_dtl 
 												WHERE campaignChatId = p_CampaignChatId and domainId = p_domainId and actionId IN (3)
                                                  group by campaignChatId
                                                 
 				UNION ALL			
 				SELECT  campaignChatId,  count(distinct userID) , 'WebPush' , "Delivery"  FROM webPush_tb_indiv_user_click_open_cnt_dtl 
 												WHERE campaignChatId = p_CampaignChatId and domainId = p_domainId and actionId IN (2)
                                                  group by campaignChatId
 				UNION ALL
                 SELECT  campaignChatId,  count(distinct userID) , 'WebPush' , "Click"  FROM webPush_tb_indiv_user_click_open_cnt_dtl 
 												WHERE campaignChatId = p_CampaignChatId and domainId = p_domainId and actionId IN (4)
                                                  group by campaignChatId;
 				
 			select SUM(userCount) INTO v_totalDelivered FROM tt_campaignAction_for_all_channel where action  = "Delivery";
             
             -- ============================= Email =======================================
             
 		DROP TEMPORARY TABLE IF EXISTS tt_group_campaignAction_for_all_channel;
         CREATE TEMPORARY TABLE tt_group_campaignAction_for_all_channel
         
 	 		SELECT campaignChatId,  `channel`,
  					 SUM(CASE WHEN `action`  = "Delivery" 		THEN    userCount END) AS DeliveryCount,
                      SUM(CASE WHEN `action`  = "Open" 			THEN   	userCount END) AS OpenCount,
                      SUM(CASE WHEN `action`  = "Click" 			THEN   	userCount END) AS ClickCount
  			FROM tt_campaignAction_for_all_channel 
 				GROUP BY campaignChatId,  `channel`;
                 
                 
 
 			SELECT  t2.campaignChatId 					AS 'campaignChatId',
 					p_domainId 							AS 'domainId',
                     t2.campaignName 					AS 'CampaignName', 
                     IFNULL(t1.OpenCount,0)				AS 'OpenCount', 
                     IFNULL(t1.ClickCount,0) 			AS 'ClickCount',
                     IFNULL(t1.DeliveryCount,0)			AS 'SentCount', 
 					t2.`Channel`						AS 'Channel', 
                     IFNULL(t1.OpenRate,0)				AS 'OpenRate', 
                     IFNULL(t1.ClickRate,0)				AS 'ClickRate', 			
                     IFNULL(t1.EngagementScore,0) 		AS 'EngagementScore'
                     FROM (
 					SELECT  t1.campaignChatId, t1.OpenCount, t1.ClickCount, t1.DeliveryCount, t1.`channel`, 
 							CASE WHEN IFNULL(t1.DeliveryCount,0) != 0 THEN  ((t1.OpenCount*100)/t1.DeliveryCount)  END AS OpenRate,  
 							CASE WHEN IFNULL(t1.DeliveryCount,0) != 0 THEN  ((t1.ClickCount*100)/t1.DeliveryCount) END AS ClickRate,
 							CASE WHEN IFNULL(t1.DeliveryCount,0) != 0 THEN	 (((t1.OpenCount*100)/t1.DeliveryCount) * 0.4) + (((t1.ClickCount*100)/t1.DeliveryCount) * 0.6) * (t1.DeliveryCount/v_totalDelivered) END AS "EngagementScore"
 					FROM tt_group_campaignAction_for_all_channel t1 
                     -- group by  t1.campaignChatId, p_domainId, t1.OpenCount, t1.ClickCount, t1.DeliveryCount, t1.`channel`
                 ) as t1
                 RIGHT JOIN tt_campaign_for_all_channel t2 ON t1.campaignChatId = t2.campaignChatId and t1.`channel` = t2.`Channel`;
                 
                 
                 SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
             -- ======================================================= 
 			
 			DROP TEMPORARY TABLE IF EXISTS tt_campaign_for_all_channel;
 			DROP TEMPORARY TABLE IF EXISTS tt_campaignAction_for_all_channel;
             DROP TEMPORARY TABLE IF EXISTS tt_group_campaignAction_for_all_channel;
     
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_get_live_schedule_campaign_ttt` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_get_live_schedule_campaign_ttt`(
 	p_domainId				INT,
 	p_CampaignChatId		VARCHAR(300)
 )
BEGIN		
 			DECLARE v_totalDelivered int default 0;
             
               SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;   
 		
 			DROP TEMPORARY TABLE IF EXISTS tt_campaign_for_all_channel;		
 			CREATE TEMPORARY TABLE tt_campaign_for_all_channel
             
 					SELECT campaignchatid AS 'CampaignChatId', domainId AS 'DomainId','Email' AS 'Channel', `Name` AS 'CampaignName', -- JSON_LENGTH(contactslist) AS 'CustomerCount', 
                     createdate FROM ec_email_campaign_master_dtl WHERE campaignchatid = p_CampaignChatId and domainId = p_domainId
 						UNION ALL
 							SELECT campaignchatid, domainId , 'SMS', `name`, -- JSON_LENGTH(contactDtls), 
                             createdDate FROM sc_campaign_master_dtl WHERE campaignchatid = p_CampaignChatId AND domainId = p_domainId
 						UNION ALL
 							SELECT campaignchatid, domainId, 'Whatsapp', campName, -- JSON_LENGTH(contactList), 
                             createdDate from wc_campaign_master_dtl where campaignchatid = p_CampaignChatId  AND domainId = p_domainId
 						UNION ALL
 							SELECT campaignChatId , domainId, 'AppPush', campaignName, -- JSON_LENGTH(contactDtl), 
                             createdOn from AppPush_campaign_master_dtl  where campaignChatId = p_CampaignChatId  AND domainId = p_domainId
 						UNION ALL
 							SELECT campaignChatId, domainId, 'WebPush', campaignName, -- JSON_LENGTH(contactDtl), 
                             createdOn from webpush_masterCampaignDtl where campaignChatId = p_CampaignChatId  AND domainId = p_domainId
 						UNION ALL
 							SELECT campaignChatId, domainId, 'inApp', campaignName, -- JSON_LENGTH(contactDtl), 
                             createdOn From inApp_campaign_master_dtl  where campaignChatId = p_CampaignChatId  AND domainId = p_domainId;	
 							
 			
 			
 			DROP TEMPORARY TABLE IF EXISTS tt_campaignAction_for_all_channel;			-- ********************** Storing unique sent, open and click count ***********************
 			CREATE TEMPORARY TABLE tt_campaignAction_for_all_channel
             
 				SELECT   distinct campaignChatId,  count(distinct userID) as userCount , 'Email' as 'channel',  'Open'as 'action' FROM Email_tb_indiv_user_click_open_cnt_dtl 
 												WHERE campaignChatId = p_CampaignChatId and domainId = p_domainId and actionId IN (3)
                                                 group by campaignChatId
 				UNION ALL
                 SELECT   distinct campaignChatId, count(distinct userID ), 'Email',  'Click' FROM Email_tb_indiv_user_click_open_cnt_dtl 
 												WHERE campaignChatId = p_CampaignChatId and domainId = p_domainId and actionId IN (4)
                                                  group by campaignChatId
 				UNION ALL
                 SELECT   distinct campaignChatId,  count(distinct userID) , 'Email' ,  'Delivery' FROM Email_tb_indiv_user_click_open_cnt_dtl 
 												WHERE campaignChatId = p_CampaignChatId and domainId = p_domainId and actionId IN (1)
                                                 group by campaignChatId
                                                  
 				UNION ALL			
 				SELECT   campaignChatId,  count(distinct userID) , 'SMS' , 'Delivery'  FROM sms_tb_indiv_user_click_open_cnt_dtl 
 												WHERE campaignChatId = p_CampaignChatId and domainId = p_domainId and actionId IN (1)
                                                  group by campaignChatId
 				UNION ALL
                 SELECT   campaignChatId,  count(distinct userID) , 'SMS' , 'Click'  FROM sms_tb_indiv_user_click_open_cnt_dtl 
 												WHERE campaignChatId = p_CampaignChatId AND domainId = p_domainId AND actionId IN (4)
                                                  group by campaignChatId
                                                 
 				UNION ALL			
 				SELECT  campaignChatId, count(distinct userID) , 'Whatsapp' , "Delivery"  FROM whatsapp_tb_indiv_user_click_open_cnt_dtl 
 												WHERE campaignChatId = p_CampaignChatId AND domainId = p_domainId AND actionId IN (2)
                                                  group by campaignChatId
                 UNION ALL
 				SELECT  campaignChatId, count(distinct userID) , 'Whatsapp' , 'Open'  FROM whatsapp_tb_indiv_user_click_open_cnt_dtl 
 												WHERE campaignChatId = p_CampaignChatId AND domainId = p_domainId AND actionId IN (3)
                                                  group by campaignChatId
 				UNION ALL
 				SELECT  campaignChatId, count(distinct userID) , 'Whatsapp' , "Click"  FROM whatsapp_tb_indiv_user_click_open_cnt_dtl 
 												WHERE campaignChatId = p_CampaignChatId AND domainId = p_domainId AND actionId IN (4)
                                                  group by campaignChatId
                                                 
 				UNION ALL			
 				SELECT  campaignChatId,  count(distinct userID) , 'AppPush' , "Delivery"  FROM AppPush_tb_indiv_user_click_open_cnt_dtl 
 												WHERE campaignChatId = p_CampaignChatId and domainId = p_domainId and actionId IN (2)
                                                  group by campaignChatId
 				UNION ALL
 				SELECT  campaignChatId,  count(distinct userID) , 'AppPush' , 'Open'  FROM AppPush_tb_indiv_user_click_open_cnt_dtl 
 												WHERE campaignChatId = p_CampaignChatId and domainId = p_domainId and actionId IN (3)
                                                  group by campaignChatId
                                                 
 				UNION ALL			
 				SELECT  campaignChatId,  count(distinct userID) , 'WebPush' , "Delivery"  FROM webPush_tb_indiv_user_click_open_cnt_dtl 
 												WHERE campaignChatId = p_CampaignChatId and domainId = p_domainId and actionId IN (2)
                                                  group by campaignChatId
 				UNION ALL
                 SELECT  campaignChatId,  count(distinct userID) , 'WebPush' , "Click"  FROM webPush_tb_indiv_user_click_open_cnt_dtl 
 												WHERE campaignChatId = p_CampaignChatId and domainId = p_domainId and actionId IN (4)
                                                  group by campaignChatId;
 				
 			select SUM(userCount) INTO v_totalDelivered FROM tt_campaignAction_for_all_channel where action  = "Delivery";
             
             -- ============================= Email =======================================
             
 		DROP TEMPORARY TABLE IF EXISTS tt_group_campaignAction_for_all_channel;
         CREATE TEMPORARY TABLE tt_group_campaignAction_for_all_channel
         
 	 		SELECT campaignChatId,  `channel`,
  					 SUM(CASE WHEN `action`  = "Delivery" 		THEN    userCount END) AS DeliveryCount,
                      SUM(CASE WHEN `action`  = "Open" 			THEN   	userCount END) AS OpenCount,
                      SUM(CASE WHEN `action`  = "Click" 			THEN   	userCount END) AS ClickCount
  			FROM tt_campaignAction_for_all_channel 
 				GROUP BY campaignChatId,  `channel`;
                 
                 
 
 			SELECT  t2.campaignChatId 					AS 'campaignChatId',
 					p_domainId 							AS 'domainId',
                     t2.campaignName 					AS 'CampaignName', 
                     IFNULL(t1.OpenCount,0)				AS 'OpenCount', 
                     IFNULL(t1.ClickCount,0) 			AS 'ClickCount',
                     IFNULL(t1.DeliveryCount,0)			AS 'SentCount', 
 					t2.`Channel`						AS 'Channel', 
                     IFNULL(t1.OpenRate,0)				AS 'OpenRate', 
                     IFNULL(t1.ClickRate,0)				AS 'ClickRate', 			
                     IFNULL(t1.EngagementScore,0) 		AS 'EngagementScore'
                     FROM (
 					SELECT  t1.campaignChatId, t1.OpenCount, t1.ClickCount, t1.DeliveryCount, t1.`channel`, 
 							CASE WHEN IFNULL(t1.DeliveryCount,0) != 0 THEN  ((t1.OpenCount*100)/t1.DeliveryCount)  END AS OpenRate,  
 							CASE WHEN IFNULL(t1.DeliveryCount,0) != 0 THEN  ((t1.ClickCount*100)/t1.DeliveryCount) END AS ClickRate,
 							CASE WHEN IFNULL(t1.DeliveryCount,0) != 0 THEN	 (((t1.OpenCount*100)/t1.DeliveryCount) * 0.4) + (((t1.ClickCount*100)/t1.DeliveryCount) * 0.6) * (t1.DeliveryCount/v_totalDelivered) END AS "EngagementScore"
 					FROM tt_group_campaignAction_for_all_channel t1 
                     -- group by  t1.campaignChatId, p_domainId, t1.OpenCount, t1.ClickCount, t1.DeliveryCount, t1.`channel`
                 ) as t1
                 RIGHT JOIN tt_campaign_for_all_channel t2 ON t1.campaignChatId = t2.campaignChatId and t1.`channel` = t2.`Channel`;
                 
                 
                 SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
             -- ======================================================= 
 			
 			DROP TEMPORARY TABLE IF EXISTS tt_campaign_for_all_channel;
 			DROP TEMPORARY TABLE IF EXISTS tt_campaignAction_for_all_channel;
             DROP TEMPORARY TABLE IF EXISTS tt_group_campaignAction_for_all_channel;
     
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_get_live_schedule_campaign_tttt` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_get_live_schedule_campaign_tttt`(
 	p_domainId				INT,
 	p_CampaignChatId		VARCHAR(300)
 )
BEGIN		
 			DECLARE v_totalDelivered int default 0;
             
               SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;   
 		
 			DROP TEMPORARY TABLE IF EXISTS tt_campaign_for_all_channel;		
 			CREATE TEMPORARY TABLE tt_campaign_for_all_channel
             
 					SELECT campaignchatid AS 'CampaignChatId', domainId AS 'DomainId','Email' AS 'Channel', `Name` AS 'CampaignName', -- JSON_LENGTH(contactslist) AS 'CustomerCount', 
                     createdate FROM ec_email_campaign_master_dtl WHERE campaignchatid = p_CampaignChatId and domainId = p_domainId
 						UNION ALL
 							SELECT campaignchatid, domainId , 'SMS', `name`, -- JSON_LENGTH(contactDtls), 
                             createdDate FROM sc_campaign_master_dtl WHERE campaignchatid = p_CampaignChatId AND domainId = p_domainId
 						UNION ALL
 							SELECT campaignchatid, domainId, 'Whatsapp', campName, -- JSON_LENGTH(contactList), 
                             createdDate from wc_campaign_master_dtl where campaignchatid = p_CampaignChatId  AND domainId = p_domainId
 						UNION ALL
 							SELECT campaignChatId , domainId, 'AppPush', campaignName, -- JSON_LENGTH(contactDtl), 
                             createdOn from AppPush_campaign_master_dtl  where campaignChatId = p_CampaignChatId  AND domainId = p_domainId
 						UNION ALL
 							SELECT campaignChatId, domainId, 'WebPush', campaignName, -- JSON_LENGTH(contactDtl), 
                             createdOn from webpush_masterCampaignDtl where campaignChatId = p_CampaignChatId  AND domainId = p_domainId
 						UNION ALL
 							SELECT campaignChatId, domainId, 'inApp', campaignName, -- JSON_LENGTH(contactDtl), 
                             createdOn From inApp_campaign_master_dtl  where campaignChatId = p_CampaignChatId  AND domainId = p_domainId;	
 							
 			
 			
 			DROP TEMPORARY TABLE IF EXISTS tt_campaignAction_for_all_channel;			-- ********************** Storing unique sent, open and click count ***********************
 			CREATE TEMPORARY TABLE tt_campaignAction_for_all_channel
             
 				SELECT   distinct campaignChatId,  count(distinct userID) as userCount , 'Email' as 'channel',  'Open'as 'action' FROM Email_tb_indiv_user_click_open_cnt_dtl 
 												WHERE campaignChatId = p_CampaignChatId and domainId = p_domainId and actionId IN (3)
                                                 group by campaignChatId
 				UNION ALL
                 SELECT   distinct campaignChatId, count(distinct userID ), 'Email',  'Click' FROM Email_tb_indiv_user_click_open_cnt_dtl 
 												WHERE campaignChatId = p_CampaignChatId and domainId = p_domainId and actionId IN (4)
                                                  group by campaignChatId
 				UNION ALL
                 SELECT   distinct campaignChatId,  count(distinct userID) , 'Email' ,  'Delivery' FROM ec_email_campaign_master_dtl 
 												WHERE campaignchatid = p_CampaignChatId and domainId = p_domainId and emailDelivery IN (1)
                                                 group by campaignChatId
                                                  
 				UNION ALL			
 				SELECT   campaignChatId,  count(distinct userID) , 'SMS' , 'Delivery'  FROM sms_tb_indiv_user_click_open_cnt_dtl 
 												WHERE campaignChatId = p_CampaignChatId and domainId = p_domainId and actionId IN (1)
                                                  group by campaignChatId
 				UNION ALL
                 SELECT   campaignChatId,  count(distinct userID) , 'SMS' , 'Click'  FROM sms_tb_indiv_user_click_open_cnt_dtl 
 												WHERE campaignChatId = p_CampaignChatId AND domainId = p_domainId AND actionId IN (4)
                                                  group by campaignChatId
                                                 
 				UNION ALL			
 				SELECT  campaignChatId, count(distinct userID) , 'Whatsapp' , "Delivery"  FROM whatsapp_tb_indiv_user_click_open_cnt_dtl 
 												WHERE campaignChatId = p_CampaignChatId AND domainId = p_domainId AND actionId IN (2)
                                                  group by campaignChatId
                 UNION ALL
 				SELECT  campaignChatId, count(distinct userID) , 'Whatsapp' , 'Open'  FROM whatsapp_tb_indiv_user_click_open_cnt_dtl 
 												WHERE campaignChatId = p_CampaignChatId AND domainId = p_domainId AND actionId IN (3)
                                                  group by campaignChatId
 				UNION ALL
 				SELECT  campaignChatId, count(distinct userID) , 'Whatsapp' , "Click"  FROM whatsapp_tb_indiv_user_click_open_cnt_dtl 
 												WHERE campaignChatId = p_CampaignChatId AND domainId = p_domainId AND actionId IN (4)
                                                  group by campaignChatId
                                                 
 				UNION ALL			
 				SELECT  campaignChatId,  count(distinct userID) , 'AppPush' , "Delivery"  FROM AppPush_tb_indiv_user_click_open_cnt_dtl 
 												WHERE campaignChatId = p_CampaignChatId and domainId = p_domainId and actionId IN (2)
                                                  group by campaignChatId
 				UNION ALL
 				SELECT  campaignChatId,  count(distinct userID) , 'AppPush' , 'Open'  FROM AppPush_tb_indiv_user_click_open_cnt_dtl 
 												WHERE campaignChatId = p_CampaignChatId and domainId = p_domainId and actionId IN (3)
                                                  group by campaignChatId
                                                 
 				UNION ALL			
 				SELECT  campaignChatId,  count(distinct userID) , 'WebPush' , "Delivery"  FROM webPush_tb_indiv_user_click_open_cnt_dtl 
 												WHERE campaignChatId = p_CampaignChatId and domainId = p_domainId and actionId IN (2)
                                                  group by campaignChatId
 				UNION ALL
                 SELECT  campaignChatId,  count(distinct userID) , 'WebPush' , "Click"  FROM webPush_tb_indiv_user_click_open_cnt_dtl 
 												WHERE campaignChatId = p_CampaignChatId and domainId = p_domainId and actionId IN (4)
                                                  group by campaignChatId;
 				
 			select SUM(userCount) INTO v_totalDelivered FROM tt_campaignAction_for_all_channel where action  = "Delivery";
             
             -- ============================= Email =======================================
             
 		DROP TEMPORARY TABLE IF EXISTS tt_group_campaignAction_for_all_channel;
         CREATE TEMPORARY TABLE tt_group_campaignAction_for_all_channel
         
 	 		SELECT campaignChatId,  `channel`,
  					 SUM(CASE WHEN `action`  = "Delivery" 		THEN    userCount END) AS DeliveryCount,
                      SUM(CASE WHEN `action`  = "Open" 			THEN   	userCount END) AS OpenCount,
                      SUM(CASE WHEN `action`  = "Click" 			THEN   	userCount END) AS ClickCount
  			FROM tt_campaignAction_for_all_channel 
 				GROUP BY campaignChatId,  `channel`;
                 
                 
 
 			SELECT  t2.campaignChatId 					AS 'campaignChatId',
 					p_domainId 							AS 'domainId',
                     t2.campaignName 					AS 'CampaignName', 
                     IFNULL(t1.OpenCount,0)				AS 'OpenCount', 
                     IFNULL(t1.ClickCount,0) 			AS 'ClickCount',
                     IFNULL(t1.DeliveryCount,0)			AS 'SentCount', 
 					t2.`Channel`						AS 'Channel', 
                     IFNULL(t1.OpenRate,0)				AS 'OpenRate', 
                     IFNULL(t1.ClickRate,0)				AS 'ClickRate', 			
                     IFNULL(t1.EngagementScore,0) 		AS 'EngagementScore'
                     FROM (
 					SELECT  t1.campaignChatId, t1.OpenCount, t1.ClickCount, t1.DeliveryCount, t1.`channel`, 
 							CASE WHEN IFNULL(t1.DeliveryCount,0) != 0 THEN  ((t1.OpenCount*100)/t1.DeliveryCount)  END AS OpenRate,  
 							CASE WHEN IFNULL(t1.DeliveryCount,0) != 0 THEN  ((t1.ClickCount*100)/t1.DeliveryCount) END AS ClickRate,
 							CASE WHEN IFNULL(t1.DeliveryCount,0) != 0 THEN	 (((t1.OpenCount*100)/t1.DeliveryCount) * 0.4) + (((t1.ClickCount*100)/t1.DeliveryCount) * 0.6) * (t1.DeliveryCount/v_totalDelivered) END AS "EngagementScore"
 					FROM tt_group_campaignAction_for_all_channel t1 
                     -- group by  t1.campaignChatId, p_domainId, t1.OpenCount, t1.ClickCount, t1.DeliveryCount, t1.`channel`
                 ) as t1
                 RIGHT JOIN tt_campaign_for_all_channel t2 ON t1.campaignChatId = t2.campaignChatId and t1.`channel` = t2.`Channel`;
                 
                 
                 SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
             -- ======================================================= 
 			
 			DROP TEMPORARY TABLE IF EXISTS tt_campaign_for_all_channel;
 			DROP TEMPORARY TABLE IF EXISTS tt_campaignAction_for_all_channel;
             DROP TEMPORARY TABLE IF EXISTS tt_group_campaignAction_for_all_channel;
     
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_get_live_schedule_campaign_ttttt` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_get_live_schedule_campaign_ttttt`(
 	p_domainId				INT,
 	p_CampaignChatId		VARCHAR(300)
 )
BEGIN		
 			DECLARE v_totalDelivered int default 0;
             
               SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;   
 		
 			DROP TEMPORARY TABLE IF EXISTS tt_campaign_for_all_channel;		
 			CREATE TEMPORARY TABLE tt_campaign_for_all_channel
             
 					SELECT campaignchatid AS 'CampaignChatId', domainId AS 'DomainId','Email' AS 'Channel', `Name` AS 'CampaignName', -- JSON_LENGTH(contactslist) AS 'CustomerCount', 
                     createdate FROM ec_email_campaign_master_dtl WHERE campaignchatid = p_CampaignChatId and domainId = p_domainId
 						UNION ALL
 							SELECT campaignchatid, domainId , 'SMS', `name`, -- JSON_LENGTH(contactDtls), 
                             createdDate FROM sc_campaign_master_dtl WHERE campaignchatid = p_CampaignChatId AND domainId = p_domainId
 						UNION ALL
 							SELECT campaignchatid, domainId, 'Whatsapp', campName, -- JSON_LENGTH(contactList), 
                             createdDate from wc_campaign_master_dtl where campaignchatid = p_CampaignChatId  AND domainId = p_domainId
 						UNION ALL
 							SELECT campaignChatId , domainId, 'AppPush', campaignName, -- JSON_LENGTH(contactDtl), 
                             createdOn from AppPush_campaign_master_dtl  where campaignChatId = p_CampaignChatId  AND domainId = p_domainId
 						UNION ALL
 							SELECT campaignChatId, domainId, 'WebPush', campaignName, -- JSON_LENGTH(contactDtl), 
                             createdOn from webpush_masterCampaignDtl where campaignChatId = p_CampaignChatId  AND domainId = p_domainId
 						UNION ALL
 							SELECT campaignChatId, domainId, 'inApp', campaignName, -- JSON_LENGTH(contactDtl), 
                             createdOn From inApp_campaign_master_dtl  where campaignChatId = p_CampaignChatId  AND domainId = p_domainId;	
 							
 			
 			
 			DROP TEMPORARY TABLE IF EXISTS tt_campaignAction_for_all_channel;			-- ********************** Storing unique sent, open and click count ***********************
 			CREATE TEMPORARY TABLE tt_campaignAction_for_all_channel
             
 				SELECT   distinct campaignChatId,  count(distinct userID) as userCount , 'Email' as 'channel',  'Open'as 'action' FROM Email_tb_indiv_user_click_open_cnt_dtl 
 												WHERE campaignChatId = p_CampaignChatId and domainId = p_domainId and actionId IN (3)
                                                 group by campaignChatId
 				UNION ALL
                 SELECT   distinct campaignChatId, count(distinct userID ), 'Email',  'Click' FROM Email_tb_indiv_user_click_open_cnt_dtl 
 												WHERE campaignChatId = p_CampaignChatId and domainId = p_domainId and actionId IN (4)
                                                  group by campaignChatId
 				UNION ALL
                 SELECT   distinct campaignChatId,  count(1) , 'Email' ,  'Delivery' FROM ec_email_campaign_master_dtl 
 												WHERE campaignchatid = p_CampaignChatId and domainId = p_domainId and emailDelivery IN (1)
                                                 group by campaignChatId
                                                  
 				UNION ALL			
 				SELECT   campaignChatId,  count(distinct userID) , 'SMS' , 'Delivery'  FROM sms_tb_indiv_user_click_open_cnt_dtl 
 												WHERE campaignChatId = p_CampaignChatId and domainId = p_domainId and actionId IN (1)
                                                  group by campaignChatId
 				UNION ALL
                 SELECT   campaignChatId,  count(distinct userID) , 'SMS' , 'Click'  FROM sms_tb_indiv_user_click_open_cnt_dtl 
 												WHERE campaignChatId = p_CampaignChatId AND domainId = p_domainId AND actionId IN (4)
                                                  group by campaignChatId
                                                 
 				UNION ALL			
 				SELECT  campaignChatId, count(distinct userID) , 'Whatsapp' , "Delivery"  FROM whatsapp_tb_indiv_user_click_open_cnt_dtl 
 												WHERE campaignChatId = p_CampaignChatId AND domainId = p_domainId AND actionId IN (2)
                                                  group by campaignChatId
                 UNION ALL
 				SELECT  campaignChatId, count(distinct userID) , 'Whatsapp' , 'Open'  FROM whatsapp_tb_indiv_user_click_open_cnt_dtl 
 												WHERE campaignChatId = p_CampaignChatId AND domainId = p_domainId AND actionId IN (3)
                                                  group by campaignChatId
 				UNION ALL
 				SELECT  campaignChatId, count(distinct userID) , 'Whatsapp' , "Click"  FROM whatsapp_tb_indiv_user_click_open_cnt_dtl 
 												WHERE campaignChatId = p_CampaignChatId AND domainId = p_domainId AND actionId IN (4)
                                                  group by campaignChatId
                                                 
 				UNION ALL			
 				SELECT  campaignChatId,  count(distinct userID) , 'AppPush' , "Delivery"  FROM AppPush_tb_indiv_user_click_open_cnt_dtl 
 												WHERE campaignChatId = p_CampaignChatId and domainId = p_domainId and actionId IN (2)
                                                  group by campaignChatId
 				UNION ALL
 				SELECT  campaignChatId,  count(distinct userID) , 'AppPush' , 'Open'  FROM AppPush_tb_indiv_user_click_open_cnt_dtl 
 												WHERE campaignChatId = p_CampaignChatId and domainId = p_domainId and actionId IN (3)
                                                  group by campaignChatId
                                                 
 				UNION ALL			
 				SELECT  campaignChatId,  count(distinct userID) , 'WebPush' , "Delivery"  FROM webPush_tb_indiv_user_click_open_cnt_dtl 
 												WHERE campaignChatId = p_CampaignChatId and domainId = p_domainId and actionId IN (2)
                                                  group by campaignChatId
 				UNION ALL
                 SELECT  campaignChatId,  count(distinct userID) , 'WebPush' , "Click"  FROM webPush_tb_indiv_user_click_open_cnt_dtl 
 												WHERE campaignChatId = p_CampaignChatId and domainId = p_domainId and actionId IN (4)
                                                  group by campaignChatId;
 				
 			select SUM(userCount) INTO v_totalDelivered FROM tt_campaignAction_for_all_channel where action  = "Delivery";
             
             -- ============================= Email =======================================
             
 		DROP TEMPORARY TABLE IF EXISTS tt_group_campaignAction_for_all_channel;
         CREATE TEMPORARY TABLE tt_group_campaignAction_for_all_channel
         
 	 		SELECT campaignChatId,  `channel`,
  					 SUM(CASE WHEN `action`  = "Delivery" 		THEN    userCount END) AS DeliveryCount,
                      SUM(CASE WHEN `action`  = "Open" 			THEN   	userCount END) AS OpenCount,
                      SUM(CASE WHEN `action`  = "Click" 			THEN   	userCount END) AS ClickCount
  			FROM tt_campaignAction_for_all_channel 
 				GROUP BY campaignChatId,  `channel`;
                 
                 
 
 			SELECT  t2.campaignChatId 					AS 'campaignChatId',
 					p_domainId 							AS 'domainId',
                     t2.campaignName 					AS 'CampaignName', 
                     IFNULL(t1.OpenCount,0)				AS 'OpenCount', 
                     IFNULL(t1.ClickCount,0) 			AS 'ClickCount',
                     IFNULL(t1.DeliveryCount,0)			AS 'SentCount', 
 					t2.`Channel`						AS 'Channel', 
                     IFNULL(t1.OpenRate,0)				AS 'OpenRate', 
                     IFNULL(t1.ClickRate,0)				AS 'ClickRate', 			
                     IFNULL(t1.EngagementScore,0) 		AS 'EngagementScore'
                     FROM (
 					SELECT  t1.campaignChatId, t1.OpenCount, t1.ClickCount, t1.DeliveryCount, t1.`channel`, 
 							CASE WHEN IFNULL(t1.DeliveryCount,0) != 0 THEN  ((t1.OpenCount*100)/t1.DeliveryCount)  END AS OpenRate,  
 							CASE WHEN IFNULL(t1.DeliveryCount,0) != 0 THEN  ((t1.ClickCount*100)/t1.DeliveryCount) END AS ClickRate,
 							CASE WHEN IFNULL(t1.DeliveryCount,0) != 0 THEN	 (((t1.OpenCount*100)/t1.DeliveryCount) * 0.4) + (((t1.ClickCount*100)/t1.DeliveryCount) * 0.6) * (t1.DeliveryCount/v_totalDelivered) END AS "EngagementScore"
 					FROM tt_group_campaignAction_for_all_channel t1 
                     -- group by  t1.campaignChatId, p_domainId, t1.OpenCount, t1.ClickCount, t1.DeliveryCount, t1.`channel`
                 ) as t1
                 RIGHT JOIN tt_campaign_for_all_channel t2 ON t1.campaignChatId = t2.campaignChatId and t1.`channel` = t2.`Channel`;
                 
                 
                 SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
             -- ======================================================= 
 			
 			DROP TEMPORARY TABLE IF EXISTS tt_campaign_for_all_channel;
 			DROP TEMPORARY TABLE IF EXISTS tt_campaignAction_for_all_channel;
             DROP TEMPORARY TABLE IF EXISTS tt_group_campaignAction_for_all_channel;
     
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_get_nlp_all_open_and_click_count` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_get_nlp_all_open_and_click_count`(
	p_domainId				INT
)
BEGIN
			declare v_totalEmailDelivered		INT default 0;
            declare v_totalWhatsappDelivered	INT default 0;
            declare v_totalWebPushDelivered		INT default 0;
            declare v_totalAppPushDelivered		INT default 0;
            declare v_totalSMSDelivered			INT default 0;
            
            
				DROP TEMPORARY TABLE IF EXISTS tt_all_master_details_01;			-- ********* Extracting the details from the master table *************
				CREATE TEMPORARY TABLE tt_all_master_details_01
				
				WITH cte01 AS(
				SELECT 		campaignchatid							AS 'campaignChatId',
							`Name`									AS 'campaignName',
							createdate								AS 'createdOn',	
							-- TargetAud							AS 'TargetAudience',
							'Email'									AS 'Channel',
							json_length(contactslist)				AS 'contactslist',
							case when emailDelivery = 1 then 1
								when emailDelivery  = 2  then datediff(emailDeliveryEndtime, emailDeliveryStarttime)  end as 'Campaign_Duration'
				FROM ec_email_campaign_master_dtl WHERE domainId = p_domainId  AND DATE(createdate) < date(now())
				
				UNION ALL
				SELECT 		t1.campaignchatId 														AS 'Campaign_ChatId',
							t1.campName																AS 'Campaign_Name', 
							t1.createdDate															AS 'Created_On',
							'Whatsapp'																AS 'Channel',
							JSON_LENGTH(t1.contactList) 											AS 'No_Audience_Targeted',
							case when t1.triggerType = 0 then 1 
								when t1.triggerType != 0 then datediff(t1.scheduleDate ,t1.createdDate)			END AS 'Campaign_Duration'
				FROM 	wc_campaign_master_dtl  				t1
							WHERE t1.domainId = p_domainId	 AND 	DATE(t1.createdDate)  < date(now())
				
				UNION ALL																		
				SELECT		t1.campaignchatid , 
							t1.`name` 										AS "Campaign_Name", 
							t1.createdDate									AS "Created_Date", 
							'SMS'											AS  `Channel`,
							json_length(t1.contactDtls)  					AS "Total_Audience",
							CASE WHEN t1.triggerType = 0 THEN 1 
								WHEN t1.triggerType = 1 THEN datediff(t2.schedulefromDate ,t1.createdDate)
								ELSE datediff(t2.scheduletoDate, t2.schedulefromDate) END AS 'Campaign_Duration'
				FROM sc_campaign_master_dtl					t1
					JOIN sc_campaign_master_schedule_dtl 		t2		ON t1.id = t2.campaignId
				WHERE t1.domainId = p_domainId AND DATE(t1.createdDate) < date(now())
								
				UNION ALL
					SELECT 	t1.campaignChatId , 
							t1.campaignName									AS "Campaign_Name", 
							t1.createdOn									AS "Created_Date", 
							'AppPush'										AS "Channel",
							json_length(t1.contactDtl)  					AS "Total_Audience",
							case WHEN t2.scheduleType = 0 THEN  1 
								WHEN t2.schedulefromDate = 1 THEN DATEDIFF(schedulefromDate, t1.createdOn)
								WHEN t2.schedulefromDate = 2 THEN DATEDIFF(scheduletoDate, schedulefromDate) END AS "Campaign_duration"
					FROM AppPush_campaign_master_dtl			t1
						JOIN Apppush_campaign_schedule_dtl	t2		ON t1.id = t2.campaignId
					WHERE t1.domainId = p_domainId AND DATE(t1.createdOn) < date(now())
                    
				UNION ALL
						SELECT 		t1.campaignChatId , 
									t1.campaignName									AS "Campaign_Name", 
									t1.createdOn									AS "Created_Date", 
									'WebPush'										AS 'Channel',
									json_length(t1.contactDtl)  					AS "Total_Audience",
									case when t2.scheduleType =0      then 1 
										when t2.scheduleType = 1 		THEN datediff(t2.schedulefromDate, t1.createdOn)
										when t2.scheduleType = 2 		THEN datediff(t2.scheduletoDate, t2.schedulefromDate)
										end as 'Campaign_Duration'
						FROM webpush_masterCampaignDtl			t1
						JOIN webpush_campaign_schedule_dtl 		t2 			ON 	t1.id  = t2.campaignId
						WHERE t1.domainId = p_domainId AND DATE(t1.createdOn) < date(now())
				)
				SELECT 
						campaignChatId, 
						campaignName, 
						MIN(createdOn) as 'createdOn', 
						GROUP_CONCAT(`Channel` separator ', ') as 'Channel', 
						SUM(contactslist) as contactlist, 
						MIN(Campaign_Duration) as min_Campaign_Duration, 
						MAX(Campaign_Duration) as max_Campaign_Duration
				FROM cte01
						GROUP BY campaignChatId, campaignName;
				
				-- SELECT  * FROM tt_all_master_details_01;
                
			-- ==========================================================================================================================

			DROP TEMPORARY TABLE IF EXISTS tt_campaignAction_for_all_channel_02;			-- ********* Extracting the open and click rate details *************
            CREATE TEMPORARY TABLE tt_campaignAction_for_all_channel_02
																-- ************* Email **************							
            
					SELECT    campaignChatId,  count(distinct userID) as userCount , 'Email' as 'channel',  'Open'as 'action' 
					FROM Email_tb_indiv_user_click_open_cnt_dtl	 
					WHERE  actionId = 3 AND CampaignChatId IN (SELECT campaignchatid  FROM ec_email_campaign_master_dtl 
																	WHERE domainId = p_domainId AND DATE(createdate) < date(now()))
					GROUP BY campaignChatId
			UNION ALL
                 SELECT campaignChatId, count(distinct userID ), 'Email',  'Click' 
						FROM Email_tb_indiv_user_click_open_cnt_dtl 
						WHERE actionId = 4 AND campaignChatId	IN ( SELECT campaignchatid  FROM ec_email_campaign_master_dtl 
														WHERE domainId = p_domainId AND DATE(createdate) < date(now())) 
						GROUP BY campaignChatId
		   UNION ALL
                SELECT campaignChatId, count(distinct userID) , 'Email' ,  'Delivery' 
						FROM Email_tb_indiv_user_click_open_cnt_dtl 
						WHERE actionId = 1 
							 AND campaignChatId IN (SELECT campaignchatid  FROM ec_email_campaign_master_dtl 
																	WHERE domainId = p_domainId AND  DATE(createdate) < date(now())) 
						GROUP BY campaignChatId
			 UNION ALL
                SELECT campaignChatId, count(distinct userID) , 'Email' ,  'Bounced' 
						FROM Email_tb_indiv_user_click_open_cnt_dtl 
						WHERE actionId = 6
							AND campaignChatId IN (SELECT campaignchatid  FROM ec_email_campaign_master_dtl 
                        WHERE domainId = p_domainId AND  DATE(createdate) < date(now())) 
                                                GROUP BY campaignChatId  
           UNION ALL
				SELECT campaignchatid, count(distinct emailId) , 'Email',  'UnSubscribe'
						FROM ec_email_unsubscribe_dtl
                        WHERE campaignchatid IN (SELECT campaignchatid  FROM ec_email_campaign_master_dtl 
													WHERE domainId = p_domainId AND  DATE(createdate) < date(now()))
						GROUP BY campaignchatid
                        
		  UNION ALL					-- ************* Whatsapp **************
				SELECT  campaignChatId, count(distinct userID) , 'Whatsapp' , "Delivery" 
						FROM whatsapp_tb_indiv_user_click_open_cnt_dtl 
						WHERE	actionId = 2 
							AND campaignChatId IN (SELECT campaignchatid FROM wc_campaign_master_dtl WHERE domainId = p_domainId AND  DATE(createdDate) < date(now()))
						GROUP BY campaignChatId
		  UNION ALL
 				SELECT  campaignChatId, count(distinct userID) , 'Whatsapp' , 'Open'  
						FROM whatsapp_tb_indiv_user_click_open_cnt_dtl 
						WHERE actionId = 3 
							AND campaignChatId IN (SELECT campaignchatid FROM wc_campaign_master_dtl WHERE domainId = p_domainId AND  DATE(createdDate)  < date(now()))
						GROUP BY campaignChatId
		  UNION ALL
 				SELECT  campaignChatId, count(distinct userID) , 'Whatsapp' , "Click"  
						FROM whatsapp_tb_indiv_user_click_open_cnt_dtl 
						WHERE actionId = 4
							AND campaignChatId IN (SELECT campaignchatid FROM wc_campaign_master_dtl WHERE domainId = p_domainId AND  DATE(createdDate)  < date(now())) 
						GROUP BY campaignChatId
                                                  
		UNION ALL					-- ************* SMS **************
			SELECT   campaignChatId,  count(DISTINCT userID), 'SMS'  , 'Delivery'  
					FROM sms_tb_indiv_user_click_open_cnt_dtl 
					WHERE  actionId = 2 AND campaignChatId IN (SELECT  campaignchatid 
						FROM sc_campaign_master_dtl  t1
						JOIN sc_campaign_master_schedule_dtl  t2  ON  t1.id = t2.campaignId  AND t1.domainId = t2.domainId	 
						WHERE   t1.domainId = p_domainId 
							AND DATE(t1.createdDate) < date(now()))
					GROUP BY campaignChatId
			UNION ALL
				SELECT   campaignChatId,  count(distinct userID) , 'SMS' , 'Click'  
					FROM sms_tb_indiv_user_click_open_cnt_dtl 
					WHERE actionId = 4 AND campaignChatId IN (
													SELECT  campaignchatid 
														FROM sc_campaign_master_dtl  t1
														JOIN sc_campaign_master_schedule_dtl  t2  ON  t1.id = t2.campaignId  AND t1.domainId = t2.domainId	 
														WHERE   t1.domainId = p_domainId 
															AND DATE(t1.createdDate) < date(now())) 
					GROUP BY campaignChatId
                    
           UNION ALL   		-- ************* App Push **************      
					SELECT  campaignChatId,  count(DISTINCT userID), 'AppPush' , "Delivery"   FROM AppPush_tb_indiv_user_click_open_cnt_dtl 
 												WHERE  actionId = 2
                                                AND campaignChatId IN (SELECT t1.campaignChatId  FROM AppPush_campaign_master_dtl t1
																	JOIN Apppush_campaign_schedule_dtl	t2		ON t1.id = t2.campaignId AND t1.domainId = t2.domainId
																	WHERE t1.domainId = p_domainId AND  DATE(t1.createdOn) < date(now())) 
												GROUP BY campaignChatId
 				UNION ALL
 				SELECT  campaignChatId,  count(DISTINCT userID) , 'AppPush' , 'Open'  FROM AppPush_tb_indiv_user_click_open_cnt_dtl 
 												WHERE actionId = 3 AND
													campaignChatId IN (SELECT t1.campaignChatId  FROM AppPush_campaign_master_dtl t1
																	JOIN Apppush_campaign_schedule_dtl	t2		ON t1.id = t2.campaignId AND t1.domainId = t2.domainId
																	WHERE t1.domainId = p_domainId AND  DATE(t1.createdOn) < date(now()))  
                                                  GROUP BY campaignChatId
                                                  
			UNION ALL		-- ************* Web Push **************   
					SELECT  campaignChatId,  count(DISTINCT userID) , 'WebPush' , "Delivery"   FROM webPush_tb_indiv_user_click_open_cnt_dtl 
 												WHERE  actionId = 2 AND  
													campaignChatId IN (SELECT t1.campaignChatId 
																			FROM webpush_masterCampaignDtl	t1
																	JOIN webpush_campaign_schedule_dtl		t2		ON 		t1.id = t2.campaignId  AND t1.domainId = t2.domainId
																		WHERE t1.domainId = p_domainId AND DATE(t1.createdOn) < date(now()))
                                                  GROUP BY campaignChatId
				UNION ALL
                SELECT  campaignChatId,  count(DISTINCT userID) , 'WebPush' , "Click"  FROM webPush_tb_indiv_user_click_open_cnt_dtl 
												WHERE actionId = 4 AND 
												campaignChatId IN (SELECT t1.campaignChatId 
																			FROM webpush_masterCampaignDtl	t1
																	JOIN webpush_campaign_schedule_dtl		t2		ON 		t1.id = t2.campaignId  AND t1.domainId = t2.domainId
																		WHERE t1.domainId = p_domainId AND DATE(t1.createdOn) < date(now())) 	
                                                 GROUP BY campaignChatId;
            
            -- select * FROM tt_campaignAction_for_all_channel_02;
		-- ==========================================================================================================================
		DROP TEMPORARY TABLE IF EXISTS tt_group_campaignAction_for_all_channel_02;
        CREATE TEMPORARY TABLE tt_group_campaignAction_for_all_channel_02
        
	 		SELECT campaignChatId,  `channel`,
 					 SUM(CASE WHEN `action`  = "Delivery" 		THEN    IFNULL(userCount,0) END) AS DeliveryCount,
                     SUM(CASE WHEN `action`  = "Open" 			THEN   	IFNULL(userCount,0) END) AS OpenCount,
                     SUM(CASE WHEN `action`  = "Click" 			THEN   	IFNULL(userCount,0) END) AS ClickCount,
                     SUM(CASE WHEN `action`  = "UnSubscribe" 	THEN   	IFNULL(userCount,0) END) AS UnSubscribeCount,
                     SUM(CASE WHEN `action`  = "Bounced" 		THEN   	userCount END) AS BouncedCount
 			FROM tt_campaignAction_for_all_channel_02 
				GROUP BY campaignChatId,  `channel`;
                
			-- select * FROM tt_group_campaignAction_for_all_channel_02;
          -- =================================================================
		select 
				
				t2.campaignChatId																						AS 'Campaign_Chat_Id',
                t2.campaignName																							AS 'Campaign_Name'	,
                t2.`Channel`																							AS 'Targeted_Channels',
				ROUND(SUM(IFNULL(case when t1.`channel` = 'Email' then t1.OpenCount					END, 0)),2) 		AS EmailOpenCount,
                ROUND(SUM(IFNULL(case when t1.`channel` = 'Email' then t1.ClickCount 				END, 0)),2) 		AS EmailClickCount,
                
				ROUND(SUM(IFNULL(case when t1.`channel` = 'SMS' then t1.ClickCount 					END,0)),2) 			AS SMSClickCount,
                
				ROUND(SUM(IFNULL(case when t1.`channel` = 'Whatsapp' then t1.OpenCount 				END, 0)),2) 		AS WhatsappOpenCount,
                ROUND(SUM(IFNULL(case when t1.`channel` = 'Whatsapp' then t1.ClickCount 			END, 0)),2) 		AS WhatsappClickCount,
				
                ROUND(SUM(IFNULL(case when t1.`channel` = 'AppPush' then t1.OpenCount 				END, 0)),2) 		AS AppPushOpenCount,
                
                ROUND(SUM(IFNULL(case when t1.`channel` = 'WebPush' then t1.ClickCount				END, 0)),2) 		AS WebPushClickCount
		FROM (
            SELECT  t1.campaignChatId, 
					IFNULL(t1.OpenCount,0) AS 'OpenCount', 
                    IFNULL(t1.ClickCount,0) AS 'ClickCount', 
                    t1.`channel`
			FROM tt_group_campaignAction_for_all_channel_02 t1 
			) as t1
			RIGHT JOIN tt_all_master_details_01 t2 ON t1.campaignChatId = t2.campaignChatId 
			GROUP BY t2.campaignChatId,   t2.campaignName	,  t2.`Channel`;		
          
          DROP TEMPORARY TABLE IF EXISTS tt_all_master_details_01;
          DROP TEMPORARY TABLE IF EXISTS tt_campaignAction_for_all_channel_02;
          DROP TEMPORARY TABLE IF EXISTS tt_group_campaignAction_for_all_channel_02;
 
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_get_nlp_customer_chat_history_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_get_nlp_customer_chat_history_dtl`(p_domainId 		INT
 ,p_campaignChatId 	VARCHAR(50)
 ,p_limit			SMALLINT
 )
BEGIN
 		IF p_limit IS NOT NULL THEN 
 				SELECT chatId,domainId ,campaignChatId ,nlpMessage ,createdOn
                 FROM wc_tb_campaign_customer_chat_conversation_History
 				WHERE domainId = p_domainId AND campaignChatId = p_campaignChatId
 				ORDER BY createdOn DESC
                 LIMIT p_limit;
         ELSE
 				SELECT chatId,domainId ,campaignChatId ,nlpMessage ,createdOn
                 FROM wc_tb_campaign_customer_chat_conversation_History
 				WHERE domainId = p_domainId AND campaignChatId = p_campaignChatId
 				ORDER BY createdOn DESC;
         END IF;
         
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_get_oauthDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_get_oauthDtl`(
	p_domainID INT
)
BEGIN
		
        SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        
        SELECT  `id`, `domainID`, `tokenID`, `createdOn`,`updatedOn`
			FROM wc_oauthDtl WHERE domainID =  p_domainID;
            
		SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_get_onboard_completion_percentage_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_get_onboard_completion_percentage_dtl`(
 p_domainId		INT
 )
begin
 
 declare cnt_ec int ;
 declare cnt_web int ;
 declare cnt_app int ;
 declare cnt_sc int ;
 declare cnt_wc int ;
 declare cnt_kb int ;

 
 
 		set session transaction isolation level read uncommitted;
 
		  
select case when count(*) > 0 then 10 else 0 end into cnt_ec from ec_email_campaign_config_dtl WHERE domainId = p_domainId;
									 
select case when count(*) > 0 then 10 else 0 end into cnt_web from webPush_tb_configuration WHERE domainId = p_domainId;
									 
select case when count(*) > 0 then 10 else 0 end into cnt_app from AppPush_main_config WHERE domainId = p_domainId;
									 
select case when count(*) > 0 then 10 else 0 end into cnt_sc from sc_SMSConfigDtl WHERE domainId = p_domainId;
									 
select case when count(*) > 0 then 10 else 0 end into cnt_wc from wc_business_configuration WHERE domainId = p_domainId;
									 
select case when count(*) > 0 then 50 else 0 end into cnt_kb from wc_tb_knowledge_base_website_dtl WHERE domainId = p_domainId;
									 

select cnt_ec+cnt_web+cnt_app+cnt_sc+cnt_wc+cnt_kb as onboard_completion_percentage;

     
 		set session transaction isolation level repeatable read;
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_get_open_click_totcnt_last7days` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_get_open_click_totcnt_last7days`(p_domainId			INT)
BEGIN
  			DECLARE v_fromDate		DATE;
              DECLARE v_toDate		DATE;
              
              SET v_toDate		= DATE(NOW()); 	
              SET v_fromDate 		= DATE(subdate(now() , interval 6 day));
              
  			
  			SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
              
              SELECT 'Email' 												AS ChannelType, 
  					SUM(IFNULL(uniqueOpenCount,0))	 					AS OpenCount, 
                      SUM(IFNULL(uniqueClickCount, 0)) 					AS ClickCount 
  			FROM ec_campaign_HistoryDtl	
  				WHERE domainId = p_domainId AND (DATE(createdAt) >= v_fromDate AND DATE(createdAt) <= v_toDate)
              
              UNION ALL
              
              SELECT 'Whatsapp' 														AS ChannelType, 
  					SUM(case when `status` = 'read' THEN  1 ELSE 0 END) 			AS OpenRate,
                      NULL															AS ClickRate
  			FROM wc_analytics_history_dtl WHERE domainId = p_domainId
  				AND (DATE(updatedOn) >= v_fromDate AND DATE(updatedOn) <= v_toDate)
              
              UNION ALL
              
              SELECT  'SMS'															AS ChannelType, 
  					NULL															AS OpenRate,	
  					NULL															AS ClickRate	
                      
              
              UNION ALL
              
              SELECT 'AppPush'														AS ChannelType,
  					SUM(CASE WHEN `status` = 'OPEN' THEN 1 ELSE 0 END)  			AS OpenRate,
                      NULL															AS ClickRate		
                      
  				FROM AppPush_tb_openRate_history_dtl WHERE domainId = p_domainId AND (DATE(createdOn) >= v_fromDate AND DATE(createdOn) <= v_toDate)
                  
  			UNION ALL
              SELECT 'WebPush'														AS ChannelType,
  					Null															AS OpenRate,
  					SUM(CASE WHEN `status` = 'OPEN' THEN 1 ELSE 0 END)  			AS ClickRate
  					
  				FROM webpush_sent_status_details WHERE domainId = p_domainId AND (DATE(createdOn) >= v_fromDate AND DATE(createdOn) <= v_toDate)
               
  			UNION ALL
              
              SELECT 'inApp'   														AS ChannelType,
  					Null															AS OpenRate,
  					NULL															AS ClickRate;
                  
                  
              SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_get_recurrence_new_schedule` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_get_recurrence_new_schedule`(
	p_domainId				INT
)
begin
		
	 with cte01 as(
			SELECT 
						t1.recId																AS 'Id',		
						CASE WHEN	t1.recurrenceType = 1 THEN 'Once'
							 WHEN	t1.recurrenceType = 2 THEN 'Daily'
							 WHEN 	t1.recurrenceType = 3 THEN 'Weekly'
							 WHEN 	t1.recurrenceType = 4 THEN	'Monthly' END 					AS 'Type',
                        t1.reportId														AS 'ReportName',
						concat(t1.reportResultStartDate,' - ',t1.reportResultEndDate )			AS 'Report_Start_Date',
						t1.timeZone																AS 'TimeZone',
						t1.createdOn	
			FROM wc_tb_recurrence_new_schedule 		t1
            JOIN wc_tb_recurrence_new_schedule_Once			t2		ON t2.FK_recId = t1.recId
            WHERE	t1.domainId =  p_domainId
            
            UNION ALL
            
            SELECT 		t1.recId																AS 'Id',
						CASE WHEN	t1.recurrenceType = 1 THEN 'Once'
							 WHEN	t1.recurrenceType = 2 THEN 'Daily'
							 WHEN 	t1.recurrenceType = 3 THEN 'Weekly'
							 WHEN 	t1.recurrenceType = 4 THEN	'Monthly' END 						AS 'Type',
						t1.reportId														AS 'ReportName',
						concat(t1.reportResultStartDate,' - ',t1.reportResultEndDate )			AS 'Report_Start_Date',
					t1.timeZone																	AS 'TimeZone',
                    t1.createdOn
			FROM wc_tb_recurrence_new_schedule 		t1
            JOIN wc_tb_recurrence_new_schedule_Daily			t2		ON t2.FK_recId = t1.recId
            WHERE	t1.domainId =  p_domainId
            
             UNION ALL
            
            SELECT 
						t1.recId																AS 'Id',
						CASE WHEN	t1.recurrenceType = 1 THEN 'Once'
							 WHEN	t1.recurrenceType = 2 THEN 'Daily'
							 WHEN 	t1.recurrenceType = 3 THEN 'Weekly'
							 WHEN 	t1.recurrenceType = 4 THEN	'Monthly' END 					AS 'Type',
						t1.reportId														AS 'ReportName',
							concat(t1.reportResultStartDate,' - ',t1.reportResultEndDate )		AS 'Report_Start_Date',
					t1.timeZone																	AS 'TimeZone',
                    t1.createdOn
			FROM wc_tb_recurrence_new_schedule 		t1
            JOIN wc_tb_recurrence_new_schedule_Weekly			t2		ON t2.FK_recId = t1.recId
            WHERE	t1.domainId =  p_domainId
            
             UNION ALL
            
            SELECT 		t1.recId																AS 'Id',
						CASE WHEN	t1.recurrenceType = 1 THEN 'Once'
							 WHEN	t1.recurrenceType = 2 THEN 'Daily'
							 WHEN 	t1.recurrenceType = 3 THEN 'Weekly'
							 WHEN 	t1.recurrenceType = 4 THEN	'Monthly' END 					AS 'Type',
						t1.reportId														AS 'ReportName',
							concat(t1.reportResultStartDate,' - ',t1.reportResultEndDate )		AS 'Report_Start_Date',
					t1.timeZone																	AS 'TimeZone',
                    t1.createdOn
			FROM wc_tb_recurrence_new_schedule 		t1
            JOIN wc_tb_recurrence_new_schedule_Monthly			t2		ON t2.FK_recId = t1.recId
            WHERE	t1.domainId =  p_domainId
            
     )
     SELECT Id, `Type`, ReportName, Report_Start_Date, TimeZone  FROM cte01 order by createdOn desc;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_get_recurrence_schedule_by_id` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_get_recurrence_schedule_by_id`(
 	p_domainId				INT,
    p_recId					INT
 )
BEGIN
 		DECLARE v_recurrenceType		INT;
        
        SELECT recurrenceType INTO v_recurrenceType FROM wc_tb_recurrence_new_schedule WHERE domainId = p_domainId AND recId = p_recId;
                        
		IF	v_recurrenceType = 1 then 
				
                SELECT *
				FROM wc_tb_recurrence_new_schedule 		t1
				JOIN wc_tb_recurrence_new_schedule_Once			t2		ON t2.FK_recId = t1.recId
				WHERE	t1.domainId =  p_domainId and t2.FK_recId = p_recId;
                
		ELSEIF v_recurrenceType = 2 then
				
                SELECT 	*
			FROM wc_tb_recurrence_new_schedule 		t1
            JOIN wc_tb_recurrence_new_schedule_Daily			t2		ON t2.FK_recId = t1.recId
            WHERE	t1.domainId =  p_domainId	and  t2.FK_recId = p_recId;
            
		ELSEIF v_recurrenceType = 3 then
        
			 SELECT *
			FROM wc_tb_recurrence_new_schedule 		t1
            JOIN wc_tb_recurrence_new_schedule_Weekly			t2		ON t2.FK_recId = t1.recId
            WHERE	t1.domainId =  p_domainId and t2.FK_recId = p_recId;
		
        ELSEIF v_recurrenceType = 4 then
				
                 SELECT *
			FROM wc_tb_recurrence_new_schedule 		t1
            JOIN wc_tb_recurrence_new_schedule_Monthly			t2		ON t2.FK_recId = t1.recId
            WHERE	t1.domainId =  p_domainId and t2.FK_recId = p_recId;
            
		END IF;
 
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_get_schedule_report_name_AllChannel` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_get_schedule_report_name_AllChannel`(
  	p_domainId				INT,
      p_startDate				date,
      p_endDate				date
  )
BEGIN
  			declare v_totalEmailDelivered		INT default 0;
              declare v_totalWhatsappDelivered	INT default 0;
              declare v_totalWebPushDelivered		INT default 0;
              declare v_totalAppPushDelivered		INT default 0;
              declare v_totalSMSDelivered			INT default 0;
              
              
  				DROP TEMPORARY TABLE IF EXISTS tt_all_master_details;			-- ********* Extracting the details from the master table *************
  				CREATE TEMPORARY TABLE tt_all_master_details
  				
  				WITH cte01 AS(
  				SELECT 		campaignchatid							AS 'campaignChatId',
  							`Name`									AS 'campaignName',
  							createdate								AS 'createdOn',	
  							-- TargetAud							AS 'TargetAudience',
  							'Email'									AS 'Channel',
  							json_length(contactslist)				AS 'contactslist',
  							case when emailDelivery = 1 then 1
  								when emailDelivery  = 2  then datediff(emailDeliveryEndtime, emailDeliveryStarttime)  end as 'Campaign_Duration'
  				FROM ec_email_campaign_master_dtl WHERE domainId = p_domainId  AND DATE(createdate) between p_startDate AND p_endDate
 						AND isIndivCamp != 2
  				UNION ALL
  				SELECT 		t1.campaignchatId 														AS 'Campaign_ChatId',
  							t1.campName																AS 'Campaign_Name', 
  							t1.createdDate															AS 'Created_On',
  							'Whatsapp'																AS 'Channel',
  							JSON_LENGTH(t1.contactList) 											AS 'No_Audience_Targeted',
  							case when t1.triggerType = 0 then 1 
  								when t1.triggerType != 0 then datediff(t1.scheduleDate ,t1.createdDate)			END AS 'Campaign_Duration'
  				FROM 	wc_campaign_master_dtl  				t1
  							WHERE t1.domainId = p_domainId	 AND 	DATE(t1.createdDate)  between p_startDate AND p_endDate
  				
  				UNION ALL																		
  				SELECT		t1.campaignchatid , 
  							t1.`name` 										AS "Campaign_Name", 
  							t1.createdDate									AS "Created_Date", 
  							'SMS'											AS  `Channel`,
  							json_length(t1.contactDtls)  					AS "Total_Audience",
  							CASE WHEN t1.triggerType = 0 THEN 1 
  								WHEN t1.triggerType = 1 THEN datediff(t2.schedulefromDate ,t1.createdDate)
  								ELSE datediff(t2.scheduletoDate, t2.schedulefromDate) END AS 'Campaign_Duration'
  				FROM sc_campaign_master_dtl					t1
  					JOIN sc_campaign_master_schedule_dtl 		t2		ON t1.id = t2.campaignId
  				WHERE t1.domainId = p_domainId AND DATE(t1.createdDate) between p_startDate AND p_endDate
  								
  				UNION ALL
  					SELECT 	t1.campaignChatId , 
  							t1.campaignName									AS "Campaign_Name", 
  							t1.createdOn									AS "Created_Date", 
  							'AppPush'										AS "Channel",
  							json_length(t1.contactDtl)  					AS "Total_Audience",
  							case WHEN t2.scheduleType = 0 THEN  1 
  								WHEN t2.schedulefromDate = 1 THEN DATEDIFF(schedulefromDate, t1.createdOn)
  								WHEN t2.schedulefromDate = 2 THEN DATEDIFF(scheduletoDate, schedulefromDate) END AS "Campaign_duration"
  					FROM AppPush_campaign_master_dtl			t1
  						JOIN Apppush_campaign_schedule_dtl	t2		ON t1.id = t2.campaignId
  					WHERE t1.domainId = p_domainId AND DATE(t1.createdOn) BETWEEN p_startDate AND p_endDate
                      
  				UNION ALL
  						SELECT 		t1.campaignChatId , 
  									t1.campaignName									AS "Campaign_Name", 
  									t1.createdOn									AS "Created_Date", 
  									'WebPush'										AS 'Channel',
  									json_length(t1.contactDtl)  					AS "Total_Audience",
  									case when t2.scheduleType =0      then 1 
  										when t2.scheduleType = 1 		THEN datediff(t2.schedulefromDate, t1.createdOn)
  										when t2.scheduleType = 2 		THEN datediff(t2.scheduletoDate, t2.schedulefromDate)
  										end as 'Campaign_Duration'
  						FROM webpush_masterCampaignDtl			t1
  						JOIN webpush_campaign_schedule_dtl 		t2 			ON 	t1.id  = t2.campaignId
  						WHERE t1.domainId = p_domainId AND DATE(t1.createdOn) BETWEEN p_startDate AND p_endDate
  				)
  				SELECT 
  						campaignChatId, 
  						campaignName, 
  						MIN(createdOn) as 'createdOn', 
  						GROUP_CONCAT(`Channel` separator ', ') as 'Channel', 
  						SUM(contactslist) as contactlist, 
  						MIN(Campaign_Duration) as min_Campaign_Duration, 
  						MAX(Campaign_Duration) as max_Campaign_Duration
  				FROM cte01
  						GROUP BY campaignChatId, campaignName;
  				
  				-- SELECT  * FROM tt_all_master_details;
                  
  			-- ==========================================================================================================================
  
  			DROP TEMPORARY TABLE IF EXISTS tt_campaignAction_for_all_channel_01;			-- ********* Extracting the open and click rate details *************
              CREATE TEMPORARY TABLE tt_campaignAction_for_all_channel_01
  																-- ************* Email **************							
              
  					SELECT    campaignChatId,  count(distinct userID) as userCount , 'Email' as 'channel',  'Open'as 'action' 
  					FROM Email_tb_indiv_user_click_open_cnt_dtl	 
  					WHERE  actionId = 3 AND CampaignChatId IN (SELECT campaignchatid  FROM ec_email_campaign_master_dtl 
  																	WHERE domainId = p_domainId AND isIndivCamp != 2 AND DATE(createdate) BETWEEN p_startDate AND p_endDate)
  					GROUP BY campaignChatId
  			UNION ALL
                   SELECT campaignChatId, count(distinct userID ), 'Email',  'Click' 
  						FROM Email_tb_indiv_user_click_open_cnt_dtl 
  						WHERE actionId = 4 AND campaignChatId	IN ( SELECT campaignchatid  FROM ec_email_campaign_master_dtl 
  														WHERE domainId = p_domainId AND isIndivCamp != 2 AND DATE(createdate) BETWEEN p_startDate AND p_endDate) 
  						GROUP BY campaignChatId
  		   UNION ALL
                  SELECT campaignChatId, count(distinct userID) , 'Email' ,  'Delivery' 
  						FROM Email_tb_indiv_user_click_open_cnt_dtl 
  						WHERE actionId = 1 AND campaignChatId IN (SELECT campaignchatid  FROM ec_email_campaign_master_dtl 
  																	WHERE domainId = p_domainId AND isIndivCamp != 2 AND  DATE(createdate) BETWEEN p_startDate AND p_endDate) 
  						GROUP BY campaignChatId
             UNION ALL
  				SELECT campaignchatid, count(distinct emailId) , 'Email',  'UnSubscribe'
  						FROM ec_email_unsubscribe_dtl
                          WHERE campaignchatid IN (SELECT campaignchatid  FROM ec_email_campaign_master_dtl 
  													WHERE domainId = p_domainId AND isIndivCamp != 2 AND  DATE(createdate) BETWEEN p_startDate AND p_endDate)
  						GROUP BY campaignchatid
                          
  		  UNION ALL					-- ************* Whatsapp **************
  				SELECT  campaignChatId, count(distinct userID) , 'Whatsapp' , "Delivery" 
  						FROM whatsapp_tb_indiv_user_click_open_cnt_dtl 
  						WHERE	actionId = 2 
  							AND campaignChatId IN (SELECT campaignchatid FROM wc_campaign_master_dtl WHERE domainId = p_domainId  AND   DATE(createdDate)  BETWEEN 	p_startDate and p_endDate)
  						GROUP BY campaignChatId
  		  UNION ALL
   				SELECT  campaignChatId, count(distinct userID) , 'Whatsapp' , 'Open'  
  						FROM whatsapp_tb_indiv_user_click_open_cnt_dtl 
  						WHERE actionId = 3 
  							AND campaignChatId IN (SELECT campaignchatid FROM wc_campaign_master_dtl WHERE domainId = p_domainId AND  DATE(createdDate)  BETWEEN 	p_startDate and p_endDate)
  						GROUP BY campaignChatId
  		  UNION ALL
   				SELECT  campaignChatId, count(distinct userID) , 'Whatsapp' , "Click"  
  						FROM whatsapp_tb_indiv_user_click_open_cnt_dtl 
  						WHERE actionId = 4
  							AND campaignChatId IN (SELECT campaignchatid FROM wc_campaign_master_dtl WHERE domainId = p_domainId AND  DATE(createdDate)  BETWEEN 	p_startDate and p_endDate) 
  						GROUP BY campaignChatId
                                                    
  		UNION ALL					-- ************* SMS **************
  			SELECT   campaignChatId,  count(DISTINCT userID), 'SMS'  , 'Delivery'  
  					FROM sms_tb_indiv_user_click_open_cnt_dtl 
  					WHERE  actionId = 2 AND campaignChatId IN (SELECT  campaignchatid 
  						FROM sc_campaign_master_dtl  t1
  						JOIN sc_campaign_master_schedule_dtl  t2  ON  t1.id = t2.campaignId  AND t1.domainId = t2.domainId	 
  						WHERE   t1.domainId = p_domainId 
  							AND DATE(t1.createdDate) BETWEEN p_startDate AND p_endDate)
  					GROUP BY campaignChatId
  			UNION ALL
  				SELECT   campaignChatId,  count(distinct userID) , 'SMS' , 'Click'  
  					FROM sms_tb_indiv_user_click_open_cnt_dtl 
  					WHERE actionId = 4 AND campaignChatId IN (
  													SELECT  campaignchatid 
  														FROM sc_campaign_master_dtl  t1
  														JOIN sc_campaign_master_schedule_dtl  t2  ON  t1.id = t2.campaignId  AND t1.domainId = t2.domainId	 
  														WHERE   t1.domainId = p_domainId 
  															AND DATE(t1.createdDate) BETWEEN p_startDate AND p_endDate) 
  					GROUP BY campaignChatId
                      
             UNION ALL   		-- ************* App Push **************      
  					SELECT  campaignChatId,  count(DISTINCT userID), 'AppPush' , "Delivery"   FROM AppPush_tb_indiv_user_click_open_cnt_dtl 
   												WHERE  actionId = 2
                                                  AND campaignChatId IN (SELECT t1.campaignChatId  FROM AppPush_campaign_master_dtl t1
  																	JOIN Apppush_campaign_schedule_dtl	t2		ON t1.id = t2.campaignId AND t1.domainId = t2.domainId
  																	WHERE t1.domainId = p_domainId AND  DATE(t1.createdOn) BETWEEN p_startDate AND p_endDate) 
  												GROUP BY campaignChatId
   				UNION ALL
   				SELECT  campaignChatId,  count(DISTINCT userID) , 'AppPush' , 'Open'  FROM AppPush_tb_indiv_user_click_open_cnt_dtl 
   												WHERE actionId = 3 AND
  													campaignChatId IN (SELECT t1.campaignChatId  FROM AppPush_campaign_master_dtl t1
  																	JOIN Apppush_campaign_schedule_dtl	t2		ON t1.id = t2.campaignId AND t1.domainId = t2.domainId
  																	WHERE t1.domainId = p_domainId AND  DATE(t1.createdOn) BETWEEN p_startDate AND p_endDate)  
                                                    GROUP BY campaignChatId
                                                    
  			UNION ALL		-- ************* Web Push **************   
  					SELECT  campaignChatId,  count(distinct userID) , 'WebPush' , "Delivery"   FROM webPush_tb_indiv_user_click_open_cnt_dtl 
   												WHERE  actionId = 2 AND  
  													campaignChatId IN (SELECT t1.campaignChatId 
  																			FROM webpush_masterCampaignDtl	t1
  																	JOIN webpush_campaign_schedule_dtl		t2		ON 		t1.id = t2.campaignId  AND t1.domainId = t2.domainId
  																		WHERE t1.domainId = p_domainId AND DATE(t1.createdOn) BETWEEN p_startDate AND p_endDate)
                                                    GROUP BY campaignChatId
  				UNION ALL
                  SELECT  campaignChatId,  count(DISTINCT userID) , 'WebPush' , "Click"  FROM webPush_tb_indiv_user_click_open_cnt_dtl 
  												WHERE actionId = 4 AND 
  												campaignChatId IN (SELECT t1.campaignChatId 
  																			FROM webpush_masterCampaignDtl	t1
  																	JOIN webpush_campaign_schedule_dtl		t2		ON 		t1.id = t2.campaignId  AND t1.domainId = t2.domainId
  																		WHERE t1.domainId = p_domainId AND DATE(t1.createdOn) BETWEEN p_startDate AND p_endDate) 	
                                                   GROUP BY campaignChatId;
              
  			-- select * FROM tt_campaignAction_for_all_channel_01;	
              
              -- ============================================== holding the overall delivery value =========================
              
              -- SELECT SUM(userCount) INTO v_totalEmailDelivered FROM tt_campaignAction_for_all_channel_01 where `action`  = "Delivery" and `channel` = 'Email';   
  --             SELECT SUM(userCount) INTO v_totalWhatsappDelivered FROM tt_campaignAction_for_all_channel_01 WHERE `action`  = "Delivery" and `channel` = 'Whatsapp';
  -- 			SELECT SUM(userCount) INTO v_totalWebPushDelivered FROM tt_campaignAction_for_all_channel_01 WHERE `action`  = "Delivery" and `channel` = 'WebPush';
  -- 			SELECT SUM(userCount) INTO v_totalAppPushDelivered FROM tt_campaignAction_for_all_channel_01 WHERE `action`  = "Delivery" and `channel` = 'AppPush';
  -- 			SELECT SUM(userCount) INTO v_totalSMSDelivered FROM tt_campaignAction_for_all_channel_01 WHERE `action`  = "Delivery" and `channel` = 'SMS';
            -- ==========================================================================================================================
              
  		DROP TEMPORARY TABLE IF EXISTS tt_group_campaignAction_for_all_channel_01;
          CREATE TEMPORARY TABLE tt_group_campaignAction_for_all_channel_01
          
  	 		SELECT campaignChatId,  `channel`,
   					 SUM(CASE WHEN `action`  = "Delivery" 		THEN    IFNULL(userCount,0) END) AS DeliveryCount,
                       SUM(CASE WHEN `action`  = "Open" 			THEN   	IFNULL(userCount,0) END) AS OpenCount,
                       SUM(CASE WHEN `action`  = "Click" 			THEN   	IFNULL(userCount,0) END) AS ClickCount,
                       SUM(CASE WHEN `action`  = "UnSubscribe" 	THEN   	IFNULL(userCount,0) END) AS UnSubscribeCount
   			FROM tt_campaignAction_for_all_channel_01 
  				GROUP BY campaignChatId,  `channel`;
                  
  		
  
  			-- select * FROM tt_group_campaignAction_for_all_channel_01;
            -- =================================================================
  		select 
  				row_number() over(order by t2.createdOn )																AS Sno,
  			-- 	t2.campaignChatId																						AS 'Campaign_Chat_Id',
                  t2.campaignName																							AS 'Campaign_Name'	,
                  t2.createdOn																							AS 'Created_Date',	
                  t2.`Channel`																							AS 'Targeted_Channels',
  				t2.contactlist																							AS 'No_of_audience_targeted',
                  
  				SUM(IFNULL(t1.DeliveryCount, 0))																		AS 'Overall_Delivery',
  				ROUND(SUM(IFNULL(t1.OpenRate, 0)),2)																	AS 'Overall_Openrate',
  				ROUND(SUM(IFNULL(t1.ClickRate, 0)),2)																	AS 'Overall_Clickrate',
  	
  				ROUND(SUM(IFNULL(case when t1.`channel` = 'Email' then t1.DeliveryCount 				END, 0)),2) 				AS EmailDelivery,
  				ROUND(SUM(IFNULL(case when t1.`channel` = 'Email' then t1.OpenRate					END, 0)),2) 					AS EmailOpenRate,
                  ROUND(SUM(IFNULL(case when t1.`channel` = 'Email' then t1.ClickRate 					END, 0)),2) 				AS EmailClickRate,
                  ROUND(SUM(IFNULL(case when t1.`channel` = 'Email' then t1.UnSubscribeCount 			END, 0)),2) 					AS EmailUnsubscribeRate,
                  
                  ROUND(SUM(IFNULL(case when t1.`channel` = 'SMS' then t1.DeliveryCount 				END, 0)),2) 					AS SMSDelivery,
  --                 case when t1.`channel` = 'SMS' then t1.OpenRate 					END AS SMSOpenRate,
  --                 case when t1.`channel` = 'SMS' then t1.ClickRate 					END AS SMSClickRate,
                  
                  ROUND(SUM(IFNULL(case when t1.`channel` = 'Whatsapp' then t1.DeliveryCount			END, 0)),2) 				AS WhatsappDelivery,
  				ROUND(SUM(IFNULL(case when t1.`channel` = 'Whatsapp' then t1.OpenRate 				END, 0)),2) 				AS WhatsappOpenRate,
                  ROUND(SUM(IFNULL(case when t1.`channel` = 'Whatsapp' then t1.ClickRate 				END, 0)),2) 				AS WhatsappClickRate,
  				
                  ROUND(SUM(IFNULL(case when t1.`channel` = 'AppPush' then t1.DeliveryCount 			END, 0)),2) 				AS AppPushDelivery,
                  ROUND(SUM(IFNULL(case when t1.`channel` = 'AppPush' then t1.OpenRate 				END, 0)),2) 				AS AppPushOpenRate,
                  
                  ROUND(SUM(IFNULL(case when t1.`channel` = 'WebPush' then t1.DeliveryCount			END, 0)),2) 				AS WebPushDelivery,
                  ROUND(SUM(IFNULL(case when t1.`channel` = 'WebPush' then t1.ClickRate				END, 0)),2) 				AS WebPushClickRate
                  
  		FROM (
              SELECT  t1.campaignChatId, 
  					IFNULL(t1.OpenCount,0) AS 'OpenCount', 
                      IFNULL(t1.ClickCount,0) AS 'ClickCount', 
                      t1.DeliveryCount, 
                      t1.`channel`, 
                      t1.UnSubscribeCount,
  					CASE WHEN IFNULL(t1.DeliveryCount,0) != 0 THEN  ((IFNULL(t1.OpenCount,0)*100)/t1.DeliveryCount) ELSE 0  END AS OpenRate,  
  					CASE WHEN IFNULL(t1.DeliveryCount,0) != 0 THEN  ((IFNULL(t1.ClickCount,0)*100)/t1.DeliveryCount) ELSE 0 END AS ClickRate
  				-- 	,CASE WHEN IFNULL(t1.DeliveryCount,0) != 0 THEN	 (((t1.OpenCount*100)/t1.DeliveryCount) * 0.4) + (((t1.ClickCount*100)/t1.DeliveryCount) * 0.6) * (t1.DeliveryCount/v_totalDelivered) ELSE 0 END AS "EngagementScore"
  					FROM tt_group_campaignAction_for_all_channel_01 t1 
  			) as t1
  			RIGHT JOIN tt_all_master_details t2 ON t1.campaignChatId = t2.campaignChatId 
  			GROUP BY t2.campaignChatId,   t2.campaignName	,	 t2.createdOn	,   t2.`Channel`, t2.contactlist
              order by  t2.createdOn desc
              ;		
            
            DROP TEMPORARY TABLE IF EXISTS tt_all_master_details;
            DROP TEMPORARY TABLE IF EXISTS tt_campaignAction_for_all_channel_01;
            DROP TEMPORARY TABLE IF EXISTS tt_group_campaignAction_for_all_channel_01;
   
  end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_get_schedule_report_name_AllChannel_bkp_2026_02_11` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_get_schedule_report_name_AllChannel_bkp_2026_02_11`(
 	p_domainId				INT,
     p_startDate				date,
     p_endDate				date
 )
BEGIN
 			declare v_totalEmailDelivered		INT default 0;
             declare v_totalWhatsappDelivered	INT default 0;
             declare v_totalWebPushDelivered		INT default 0;
             declare v_totalAppPushDelivered		INT default 0;
             declare v_totalSMSDelivered			INT default 0;
             
             
 				DROP TEMPORARY TABLE IF EXISTS tt_all_master_details;			-- ********* Extracting the details from the master table *************
 				CREATE TEMPORARY TABLE tt_all_master_details
 				
 				WITH cte01 AS(
 				SELECT 		campaignchatid							AS 'campaignChatId',
 							`Name`									AS 'campaignName',
 							createdate								AS 'createdOn',	
 							-- TargetAud							AS 'TargetAudience',
 							'Email'									AS 'Channel',
 							json_length(contactslist)				AS 'contactslist',
 							case when emailDelivery = 1 then 1
 								when emailDelivery  = 2  then datediff(emailDeliveryEndtime, emailDeliveryStarttime)  end as 'Campaign_Duration'
 				FROM ec_email_campaign_master_dtl WHERE domainId = p_domainId AND isIndivCamp != 2  AND DATE(createdate) between p_startDate AND p_endDate
 				
 				UNION ALL
 				SELECT 		t1.campaignchatId 														AS 'Campaign_ChatId',
 							t1.campName																AS 'Campaign_Name', 
 							t1.createdDate															AS 'Created_On',
 							'Whatsapp'																AS 'Channel',
 							JSON_LENGTH(t1.contactList) 											AS 'No_Audience_Targeted',
 							case when t1.triggerType = 0 then 1 
 								when t1.triggerType != 0 then datediff(t1.scheduleDate ,t1.createdDate)			END AS 'Campaign_Duration'
 				FROM 	wc_campaign_master_dtl  				t1
 							WHERE t1.domainId = p_domainId	 AND 	DATE(t1.createdDate)  between p_startDate AND p_endDate
 				
 				UNION ALL																		
 				SELECT		t1.campaignchatid , 
 							t1.`name` 										AS "Campaign_Name", 
 							t1.createdDate									AS "Created_Date", 
 							'SMS'											AS  `Channel`,
 							json_length(t1.contactDtls)  					AS "Total_Audience",
 							CASE WHEN t1.triggerType = 0 THEN 1 
 								WHEN t1.triggerType = 1 THEN datediff(t2.schedulefromDate ,t1.createdDate)
 								ELSE datediff(t2.scheduletoDate, t2.schedulefromDate) END AS 'Campaign_Duration'
 				FROM sc_campaign_master_dtl					t1
 					JOIN sc_campaign_master_schedule_dtl 		t2		ON t1.id = t2.campaignId
 				WHERE t1.domainId = p_domainId AND DATE(t1.createdDate) between p_startDate AND p_endDate
 								
 				UNION ALL
 					SELECT 	t1.campaignChatId , 
 							t1.campaignName									AS "Campaign_Name", 
 							t1.createdOn									AS "Created_Date", 
 							'AppPush'										AS "Channel",
 							json_length(t1.contactDtl)  					AS "Total_Audience",
 							case WHEN t2.scheduleType = 0 THEN  1 
 								WHEN t2.schedulefromDate = 1 THEN DATEDIFF(schedulefromDate, t1.createdOn)
 								WHEN t2.schedulefromDate = 2 THEN DATEDIFF(scheduletoDate, schedulefromDate) END AS "Campaign_duration"
 					FROM AppPush_campaign_master_dtl			t1
 						JOIN Apppush_campaign_schedule_dtl	t2		ON t1.id = t2.campaignId
 					WHERE t1.domainId = p_domainId AND DATE(t1.createdOn) BETWEEN p_startDate AND p_endDate
                     
 				UNION ALL
 						SELECT 		t1.campaignChatId , 
 									t1.campaignName									AS "Campaign_Name", 
 									t1.createdOn									AS "Created_Date", 
 									'WebPush'										AS 'Channel',
 									json_length(t1.contactDtl)  					AS "Total_Audience",
 									case when t2.scheduleType =0      then 1 
 										when t2.scheduleType = 1 		THEN datediff(t2.schedulefromDate, t1.createdOn)
 										when t2.scheduleType = 2 		THEN datediff(t2.scheduletoDate, t2.schedulefromDate)
 										end as 'Campaign_Duration'
 						FROM webpush_masterCampaignDtl			t1
 						JOIN webpush_campaign_schedule_dtl 		t2 			ON 	t1.id  = t2.campaignId
 						WHERE t1.domainId = p_domainId AND DATE(t1.createdOn) BETWEEN p_startDate AND p_endDate
 				)
 				SELECT 
 						campaignChatId, 
 						campaignName, 
 						MIN(createdOn) as 'createdOn', 
 						GROUP_CONCAT(`Channel` separator ', ') as 'Channel', 
 						SUM(contactslist) as contactlist, 
 						MIN(Campaign_Duration) as min_Campaign_Duration, 
 						MAX(Campaign_Duration) as max_Campaign_Duration
 				FROM cte01
 						GROUP BY campaignChatId, campaignName;
 				
 				-- SELECT  * FROM tt_all_master_details;
                 
 			-- ==========================================================================================================================
 
 			DROP TEMPORARY TABLE IF EXISTS tt_campaignAction_for_all_channel_01;			-- ********* Extracting the open and click rate details *************
             CREATE TEMPORARY TABLE tt_campaignAction_for_all_channel_01
 																-- ************* Email **************							
             
 					SELECT    campaignChatId,  count(distinct userID) as userCount , 'Email' as 'channel',  'Open'as 'action' 
 					FROM Email_tb_indiv_user_click_open_cnt_dtl	 
 					WHERE  actionId = 3 AND CampaignChatId IN (SELECT campaignchatid  FROM ec_email_campaign_master_dtl 
 																	WHERE domainId = p_domainId AND isIndivCamp != 2 AND DATE(createdate) BETWEEN p_startDate AND p_endDate)
 					GROUP BY campaignChatId
 			UNION ALL
                  SELECT campaignChatId, count(distinct userID ), 'Email',  'Click' 
 						FROM Email_tb_indiv_user_click_open_cnt_dtl 
 						WHERE actionId = 4 AND campaignChatId	IN ( SELECT campaignchatid  FROM ec_email_campaign_master_dtl 
 														WHERE domainId = p_domainId AND isIndivCamp != 2 AND DATE(createdate) BETWEEN p_startDate AND p_endDate) 
 						GROUP BY campaignChatId
 		   UNION ALL
                 SELECT campaignChatId, count(distinct userID) , 'Email' ,  'Delivery' 
 						FROM Email_tb_indiv_user_click_open_cnt_dtl 
 						WHERE actionId = 1 
 							 AND campaignChatId IN (SELECT campaignchatid  FROM ec_email_campaign_master_dtl 
 																	WHERE domainId = p_domainId AND isIndivCamp != 2 AND  DATE(createdate) BETWEEN p_startDate AND p_endDate) 
 						GROUP BY campaignChatId
 			 UNION ALL
                 SELECT campaignChatId, count(distinct userID) , 'Email' ,  'Bounced' 
 						FROM Email_tb_indiv_user_click_open_cnt_dtl 
 						WHERE actionId = 6
 							AND campaignChatId IN (SELECT campaignchatid  FROM ec_email_campaign_master_dtl 
                         WHERE domainId = p_domainId AND isIndivCamp != 2 AND  DATE(createdate) BETWEEN p_startDate AND p_endDate) 
                                                 GROUP BY campaignChatId  
            UNION ALL
 				SELECT campaignchatid, count(distinct emailId) , 'Email',  'UnSubscribe'
 						FROM ec_email_unsubscribe_dtl
                         WHERE campaignchatid IN (SELECT campaignchatid  FROM ec_email_campaign_master_dtl 
 													WHERE domainId = p_domainId AND isIndivCamp != 2 AND  DATE(createdate) BETWEEN p_startDate AND p_endDate)
 						GROUP BY campaignchatid
                         
 		  UNION ALL					-- ************* Whatsapp **************
 				SELECT  campaignChatId, count(distinct userID) , 'Whatsapp' , "Delivery" 
 						FROM whatsapp_tb_indiv_user_click_open_cnt_dtl 
 						WHERE	actionId = 2 
 							AND campaignChatId IN (SELECT campaignchatid FROM wc_campaign_master_dtl WHERE domainId = p_domainId AND  DATE(createdDate)  BETWEEN 	p_startDate and p_endDate)
 						GROUP BY campaignChatId
 		  UNION ALL
  				SELECT  campaignChatId, count(distinct userID) , 'Whatsapp' , 'Open'  
 						FROM whatsapp_tb_indiv_user_click_open_cnt_dtl 
 						WHERE actionId = 3 
 							AND campaignChatId IN (SELECT campaignchatid FROM wc_campaign_master_dtl WHERE domainId = p_domainId AND  DATE(createdDate)  BETWEEN 	p_startDate and p_endDate)
 						GROUP BY campaignChatId
 		  UNION ALL
  				SELECT  campaignChatId, count(distinct userID) , 'Whatsapp' , "Click"  
 						FROM whatsapp_tb_indiv_user_click_open_cnt_dtl 
 						WHERE actionId = 4
 							AND campaignChatId IN (SELECT campaignchatid FROM wc_campaign_master_dtl WHERE domainId = p_domainId AND  DATE(createdDate)  BETWEEN 	p_startDate and p_endDate) 
 						GROUP BY campaignChatId
                                                   
 		UNION ALL					-- ************* SMS **************
 			SELECT   campaignChatId,  count(DISTINCT userID), 'SMS'  , 'Delivery'  
 					FROM sms_tb_indiv_user_click_open_cnt_dtl 
 					WHERE  actionId = 2 AND campaignChatId IN (SELECT  campaignchatid 
 						FROM sc_campaign_master_dtl  t1
 						JOIN sc_campaign_master_schedule_dtl  t2  ON  t1.id = t2.campaignId  AND t1.domainId = t2.domainId	 
 						WHERE   t1.domainId = p_domainId 
 							AND DATE(t1.createdDate) BETWEEN p_startDate AND p_endDate)
 					GROUP BY campaignChatId
 			UNION ALL
 				SELECT   campaignChatId,  count(distinct userID) , 'SMS' , 'Click'  
 					FROM sms_tb_indiv_user_click_open_cnt_dtl 
 					WHERE actionId = 4 AND campaignChatId IN (
 													SELECT  campaignchatid 
 														FROM sc_campaign_master_dtl  t1
 														JOIN sc_campaign_master_schedule_dtl  t2  ON  t1.id = t2.campaignId  AND t1.domainId = t2.domainId	 
 														WHERE   t1.domainId = p_domainId 
 															AND DATE(t1.createdDate) BETWEEN p_startDate AND p_endDate) 
 					GROUP BY campaignChatId
                     
            UNION ALL   		-- ************* App Push **************      
 					SELECT  campaignChatId,  count(DISTINCT userID), 'AppPush' , "Delivery"   FROM AppPush_tb_indiv_user_click_open_cnt_dtl 
  												WHERE  actionId = 2
                                                 AND campaignChatId IN (SELECT t1.campaignChatId  FROM AppPush_campaign_master_dtl t1
 																	JOIN Apppush_campaign_schedule_dtl	t2		ON t1.id = t2.campaignId AND t1.domainId = t2.domainId
 																	WHERE t1.domainId = p_domainId AND  DATE(t1.createdOn) BETWEEN p_startDate AND p_endDate) 
 												GROUP BY campaignChatId
  				UNION ALL
  				SELECT  campaignChatId,  count(DISTINCT userID) , 'AppPush' , 'Open'  FROM AppPush_tb_indiv_user_click_open_cnt_dtl 
  												WHERE actionId = 3 AND
 													campaignChatId IN (SELECT t1.campaignChatId  FROM AppPush_campaign_master_dtl t1
 																	JOIN Apppush_campaign_schedule_dtl	t2		ON t1.id = t2.campaignId AND t1.domainId = t2.domainId
 																	WHERE t1.domainId = p_domainId AND  DATE(t1.createdOn) BETWEEN p_startDate AND p_endDate)  
                                                   GROUP BY campaignChatId
                                                   
 			UNION ALL		-- ************* Web Push **************   
 					SELECT  campaignChatId,  count(distinct userID) , 'WebPush' , "Delivery"   FROM webPush_tb_indiv_user_click_open_cnt_dtl 
  												WHERE  actionId = 2 AND  
 													campaignChatId IN (SELECT t1.campaignChatId 
 																			FROM webpush_masterCampaignDtl	t1
 																	JOIN webpush_campaign_schedule_dtl		t2		ON 		t1.id = t2.campaignId  AND t1.domainId = t2.domainId
 																		WHERE t1.domainId = p_domainId AND DATE(t1.createdOn) BETWEEN p_startDate AND p_endDate)
                                                   GROUP BY campaignChatId
 				UNION ALL
                 SELECT  campaignChatId,  count(DISTINCT userID) , 'WebPush' , "Click"  FROM webPush_tb_indiv_user_click_open_cnt_dtl 
 												WHERE actionId = 4 AND 
 												campaignChatId IN (SELECT t1.campaignChatId 
 																			FROM webpush_masterCampaignDtl	t1
 																	JOIN webpush_campaign_schedule_dtl		t2		ON 		t1.id = t2.campaignId  AND t1.domainId = t2.domainId
 																		WHERE t1.domainId = p_domainId AND DATE(t1.createdOn) BETWEEN p_startDate AND p_endDate) 	
                                                  GROUP BY campaignChatId;
             
 			-- select * FROM tt_campaignAction_for_all_channel_01;	
             
             -- ============================================== holding the overall delivery value =========================
             
             -- SELECT SUM(userCount) INTO v_totalEmailDelivered FROM tt_campaignAction_for_all_channel_01 where `action`  = "Delivery" and `channel` = 'Email';   
 --             SELECT SUM(userCount) INTO v_totalWhatsappDelivered FROM tt_campaignAction_for_all_channel_01 WHERE `action`  = "Delivery" and `channel` = 'Whatsapp';
 -- 			SELECT SUM(userCount) INTO v_totalWebPushDelivered FROM tt_campaignAction_for_all_channel_01 WHERE `action`  = "Delivery" and `channel` = 'WebPush';
 -- 			SELECT SUM(userCount) INTO v_totalAppPushDelivered FROM tt_campaignAction_for_all_channel_01 WHERE `action`  = "Delivery" and `channel` = 'AppPush';
 -- 			SELECT SUM(userCount) INTO v_totalSMSDelivered FROM tt_campaignAction_for_all_channel_01 WHERE `action`  = "Delivery" and `channel` = 'SMS';
           -- ==========================================================================================================================
             
 		DROP TEMPORARY TABLE IF EXISTS tt_group_campaignAction_for_all_channel_01;
         CREATE TEMPORARY TABLE tt_group_campaignAction_for_all_channel_01
         
 	 		SELECT campaignChatId,  `channel`,
  					 SUM(CASE WHEN `action`  = "Delivery" 		THEN    IFNULL(userCount,0) END) AS DeliveryCount,
                      SUM(CASE WHEN `action`  = "Open" 			THEN   	IFNULL(userCount,0) END) AS OpenCount,
                      SUM(CASE WHEN `action`  = "Click" 			THEN   	IFNULL(userCount,0) END) AS ClickCount,
                      SUM(CASE WHEN `action`  = "UnSubscribe" 	THEN   	IFNULL(userCount,0) END) AS UnSubscribeCount,
                      SUM(CASE WHEN `action`  = "Bounced" 		THEN   	userCount END) AS BouncedCount
  			FROM tt_campaignAction_for_all_channel_01 
 				GROUP BY campaignChatId,  `channel`;
                 
 		
 
 			-- select * FROM tt_group_campaignAction_for_all_channel_01;
           -- =================================================================
 		select 
 				row_number() over(order by t2.createdOn )																AS Sno,
 			-- 	t2.campaignChatId																						AS 'Campaign_Chat_Id',
                 t2.campaignName																							AS 'Campaign_Name'	,
                 t2.createdOn																							AS 'Created_Date',	
                 t2.`Channel`																							AS 'Targeted_Channels',
 				t2.contactlist																							AS 'No_of_audience_targeted',
                 
 				SUM(IFNULL(t1.DeliveryCount, 0))																		AS 'Overall_Delivery',
 				ROUND(SUM(IFNULL(t1.OpenRate, 0)),2)																	AS 'Overall_Openrate',
 				ROUND(SUM(IFNULL(t1.ClickRate, 0)),2)																	AS 'Overall_Clickrate',
 	
 				ROUND(SUM(IFNULL(case when t1.`channel` = 'Email' then t1.DeliveryCount 				END, 0)),2) 	AS EmailDelivery,
 				ROUND(SUM(IFNULL(case when t1.`channel` = 'Email' then t1.OpenRate						END, 0)),2) 	AS EmailOpenRate,
                 ROUND(SUM(IFNULL(case when t1.`channel` = 'Email' then t1.ClickRate 					END, 0)),2) 	AS EmailClickRate,
                 ROUND(SUM(IFNULL(case when t1.`channel` = 'Email' then t1.UnSubscribeCount 				END, 0)),2) 	AS EmailUnsubscribeRate,
                 ROUND(SUM(IFNULL(case when t1.`channel` = 'Email' then t1.BouncedCount 					END, 0)),2)		AS EmailBouncedCount,
                 
                 ROUND(SUM(IFNULL(case when t1.`channel` = 'SMS' then t1.DeliveryCount 				END, 0)),2) 		AS SMSDelivery,
 --                 case when t1.`channel` = 'SMS' then t1.OpenRate 					END AS SMSOpenRate,
 --                 case when t1.`channel` = 'SMS' then t1.ClickRate 					END AS SMSClickRate,
                 
                 ROUND(SUM(IFNULL(case when t1.`channel` = 'Whatsapp' then t1.DeliveryCount			END, 0)),2) 				AS WhatsappDelivery,
 				ROUND(SUM(IFNULL(case when t1.`channel` = 'Whatsapp' then t1.OpenRate 				END, 0)),2) 				AS WhatsappOpenRate,
                 ROUND(SUM(IFNULL(case when t1.`channel` = 'Whatsapp' then t1.ClickRate 				END, 0)),2) 				AS WhatsappClickRate,
 				
                 ROUND(SUM(IFNULL(case when t1.`channel` = 'AppPush' then t1.DeliveryCount 			END, 0)),2) 				AS AppPushDelivery,
                 ROUND(SUM(IFNULL(case when t1.`channel` = 'AppPush' then t1.OpenRate 				END, 0)),2) 				AS AppPushOpenRate,
                 
                 ROUND(SUM(IFNULL(case when t1.`channel` = 'WebPush' then t1.DeliveryCount			END, 0)),2) 				AS WebPushDelivery,
                 ROUND(SUM(IFNULL(case when t1.`channel` = 'WebPush' then t1.ClickRate				END, 0)),2) 				AS WebPushClickRate
                 
 		FROM (
             SELECT  t1.campaignChatId, 
 					IFNULL(t1.OpenCount,0) AS 'OpenCount', 
                     IFNULL(t1.ClickCount,0) AS 'ClickCount', 
                     t1.DeliveryCount, 
                     t1.`channel`, 
                     t1.UnSubscribeCount,
                     t1.BouncedCount,
 					CASE WHEN IFNULL(t1.DeliveryCount,0) != 0 THEN  ((IFNULL(t1.OpenCount,0)*100)/t1.DeliveryCount) ELSE 0  END AS OpenRate,  
 					CASE WHEN IFNULL(t1.DeliveryCount,0) != 0 THEN  ((IFNULL(t1.ClickCount,0)*100)/t1.DeliveryCount) ELSE 0 END AS ClickRate
 				-- 	,CASE WHEN IFNULL(t1.DeliveryCount,0) != 0 THEN	 (((t1.OpenCount*100)/t1.DeliveryCount) * 0.4) + (((t1.ClickCount*100)/t1.DeliveryCount) * 0.6) * (t1.DeliveryCount/v_totalDelivered) ELSE 0 END AS "EngagementScore"
 					FROM tt_group_campaignAction_for_all_channel_01 t1 
 			) as t1
 			RIGHT JOIN tt_all_master_details t2 ON t1.campaignChatId = t2.campaignChatId 
 			GROUP BY t2.campaignChatId,   t2.campaignName	,	 t2.createdOn	,   t2.`Channel`, t2.contactlist
             order by  t2.createdOn desc
             ;		
           
           DROP TEMPORARY TABLE IF EXISTS tt_all_master_details;
           DROP TEMPORARY TABLE IF EXISTS tt_campaignAction_for_all_channel_01;
           DROP TEMPORARY TABLE IF EXISTS tt_group_campaignAction_for_all_channel_01;
  
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_get_schedule_report_name_AppPush` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_get_schedule_report_name_AppPush`(
	p_domainId		INT,
    p_startDate		DATE,
    p_endDate		DATE
)
BEGIN
		declare v_totalDelivered int;
        
		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;		
        
        DROP TEMPORARY TABLE IF EXISTS tt_AppPush_Master_Dtl;
        CREATE TEMPORARY TABLE tt_AppPush_Master_Dtl
				SELECT 
					t1.campaignChatId , 
					t1.domainId, 
					t1.campaignName									AS "Campaign_Name", 
					t1.createdOn									AS "Created_Date", 
					json_length(t1.contactDtl)  					AS "Total_Audience",
					t1.scheduleType,
					'AppPush'										AS "Channel",
                    case WHEN t2.scheduleType = 0 THEN  1 
						WHEN t2.scheduleType = 1 THEN DATEDIFF(schedulefromDate, t1.createdOn)
                        WHEN t2.scheduleType = 2 THEN DATEDIFF(scheduletoDate, schedulefromDate) END AS "Campaign_duration"
				FROM AppPush_campaign_master_dtl			t1
                JOIN Apppush_campaign_schedule_dtl	t2		ON t1.id = t2.campaignId
				WHERE t1.domainId = p_domainId AND DATE(t1.createdOn) BETWEEN p_startDate AND p_endDate;
                
           
         
		DROP TEMPORARY TABLE IF EXISTS tt_campaignAction_for_all_channel_01;		-- ******************** Extracting the delivery **************************
        CREATE TEMPORARY TABLE tt_campaignAction_for_all_channel_01
				SELECT  campaignChatId,  count(DISTINCT userID) as userCount, 'AppPush' as 'channel', "Delivery" as 'action'  FROM AppPush_tb_indiv_user_click_open_cnt_dtl 
 												WHERE  actionId = 2
                                                AND campaignChatId IN (SELECT t1.campaignChatId  FROM AppPush_campaign_master_dtl t1
																	JOIN Apppush_campaign_schedule_dtl	t2		ON t1.id = t2.campaignId AND t1.domainId = t2.domainId
																	WHERE t1.domainId = p_domainId AND  DATE(t1.createdOn) BETWEEN p_startDate AND p_endDate) 
												GROUP BY campaignChatId
 				UNION ALL
 				SELECT  campaignChatId,  count(DISTINCT userID) , 'AppPush' , 'Open'  FROM AppPush_tb_indiv_user_click_open_cnt_dtl 
 												WHERE actionId = 3 AND
													campaignChatId IN (SELECT t1.campaignChatId  FROM AppPush_campaign_master_dtl t1
																	JOIN Apppush_campaign_schedule_dtl	t2		ON t1.id = t2.campaignId AND t1.domainId = t2.domainId
																	WHERE t1.domainId = p_domainId AND  DATE(t1.createdOn) BETWEEN p_startDate AND p_endDate)  
                                                  GROUP BY campaignChatId;
                
             
                
		select SUM(userCount) INTO v_totalDelivered FROM tt_campaignAction_for_all_channel_01 where action  = "Delivery";
            
		DROP TEMPORARY TABLE IF EXISTS tt_group_campaignAction_for_all_channel_01;
        CREATE TEMPORARY TABLE tt_group_campaignAction_for_all_channel_01
        
	 		SELECT campaignChatId,  `channel`,
 					 SUM(CASE WHEN `action`  = "Delivery" 		THEN    userCount END) AS DeliveryCount,
                     SUM(CASE WHEN `action`  = "Open" 			THEN   	userCount END) AS OpenCount,
                     SUM(CASE WHEN `action`  = "Click" 			THEN   	userCount END) AS ClickCount
 			FROM tt_campaignAction_for_all_channel_01 
				GROUP BY campaignChatId,  `channel`;
         
		
          -- SELECT * FROM tt_AppPush_Master_Open_Dtl;
         
         SELECT row_number() over() 										AS 'Sno',	
				t2.Campaign_Name											AS "Campaign_Name", 
				t2.Created_Date 											AS "Created_Date",
				t2.Campaign_duration										AS "Campaign_duration",
                IFNULL(t2.Total_Audience,0)									AS "No_of_audience_targeted", 
				IFNULL(t1.DeliveryCount,0) 									AS "App_Push_Delivery",
				ROUND(IFNULL(t1.OpenRate,0),2)										AS "App_Push_Openrate"
         FROM (
					SELECT  t1.campaignChatId, t1.OpenCount, t1.ClickCount, t1.DeliveryCount, t1.`channel`, 
							CASE WHEN IFNULL(t1.DeliveryCount,0) != 0 THEN  ((t1.OpenCount*100)/t1.DeliveryCount) ELSE 0  END AS OpenRate,  
							CASE WHEN IFNULL(t1.DeliveryCount,0) != 0 THEN  ((t1.ClickCount*100)/t1.DeliveryCount) ELSE 0 END AS ClickRate,
							CASE WHEN IFNULL(t1.DeliveryCount,0) != 0 THEN	 (((t1.OpenCount*100)/t1.DeliveryCount) * 0.4) + (((t1.ClickCount*100)/t1.DeliveryCount) * 0.6) * (t1.DeliveryCount/v_totalDelivered) ELSE 0 END AS "EngagementScore"
					FROM tt_group_campaignAction_for_all_channel_01 t1 
                    -- group by  t1.campaignChatId, p_domainId, t1.OpenCount, t1.ClickCount, t1.DeliveryCount, t1.`channel`
            
			) AS t1
         RIGHT JOIN tt_AppPush_Master_Dtl t2 ON t1.campaignChatId = t2.campaignchatid and t1.`channel` = t2.`Channel`
         order by t2.Created_Date desc;
         
		SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
        
        DROP TEMPORARY TABLE tt_AppPush_Master_Dtl;
        DROP TEMPORARY TABLE tt_campaignAction_for_all_channel_01;
        DROP TEMPORARY TABLE tt_group_campaignAction_for_all_channel_01;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_get_schedule_report_name_email` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_get_schedule_report_name_email`(
 	p_domainId				INT,
     p_startDate				date,
     p_endDate				date
 )
BEGIN
 			declare v_totalDelivered int default 0;
 			SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
             
             DROP TEMPORARY TABLE IF EXISTS tt_email_master_details;
             CREATE TEMPORARY TABLE tt_email_master_details
 					SELECT campaignId,
 							campaignchatid,
 							createdate,
 							`Name`,
 							TargetAud,
                             'Email'									AS `Channel`,
 							json_length(contactslist)				AS contactslist,
                             case when emailDelivery = 1 then 1
 								when emailDelivery  = 2  then datediff(emailDeliveryEndtime, emailDeliveryStarttime)  end as 'Campaign_Duration'
                             
 					FROM ec_email_campaign_master_dtl WHERE domainId = p_domainId AND isIndivCamp !=2 AND DATE(createdate) BETWEEN p_startDate AND p_endDate ;
                     
 			 -- SELECT * FROM tt_email_master_details;  -- ****************************************************************************************************************
             
             DROP TEMPORARY TABLE IF EXISTS tt_campaignAction_for_all_channel_01;
             CREATE TEMPORARY TABLE tt_campaignAction_for_all_channel_01
 									SELECT    campaignChatId,  count(distinct userID) as userCount , 'Email' as 'channel',  'Open'as 'action' 
 					FROM Email_tb_indiv_user_click_open_cnt_dtl	 
 					WHERE  actionId = 3 and CampaignChatId IN 
                     (SELECT campaignchatid  
 						FROM ec_email_campaign_master_dtl 
                         WHERE domainId = p_domainId AND isIndivCamp !=2 AND DATE(createdate) BETWEEN p_startDate AND p_endDate)
 					GROUP BY campaignChatId
 			UNION ALL
                  SELECT campaignChatId, count(distinct userID ), 'Email',  'Click' 
 						FROM Email_tb_indiv_user_click_open_cnt_dtl 
 										WHERE actionId = 4 and 
 								campaignChatId	IN ( SELECT campaignchatid  FROM ec_email_campaign_master_dtl 
                         WHERE domainId = p_domainId AND isIndivCamp !=2 AND DATE(createdate) BETWEEN p_startDate AND p_endDate) 
  												GROUP BY campaignChatId
 		   UNION ALL
                 SELECT campaignChatId, count(distinct userID) , 'Email' ,  'Delivery' 
 						FROM Email_tb_indiv_user_click_open_cnt_dtl 
 						WHERE actionId = 1
 							AND campaignChatId IN (SELECT campaignchatid  FROM ec_email_campaign_master_dtl 
                         WHERE domainId = p_domainId AND isIndivCamp !=2 AND  DATE(createdate) BETWEEN p_startDate AND p_endDate) 
                                                 GROUP BY campaignChatId
            UNION ALL
 				SELECT campaignchatid, count(distinct emailId) , 'Email',  'UnSubscribe'
 						FROM ec_email_unsubscribe_dtl
                         where campaignchatid IN (SELECT campaignchatid  FROM ec_email_campaign_master_dtl 
                         WHERE domainId = p_domainId AND isIndivCamp !=2 AND  DATE(createdate) BETWEEN p_startDate AND p_endDate)
 										GROUP BY campaignchatid;
 			
             -- SELECT * FROM tt_email_master_click_open_details;	 -- ***********************************************************************************
             
             select SUM(userCount) INTO v_totalDelivered FROM tt_campaignAction_for_all_channel_01 where action  = "Delivery";
             
 		DROP TEMPORARY TABLE IF EXISTS tt_group_campaignAction_for_all_channel_01;
         CREATE TEMPORARY TABLE tt_group_campaignAction_for_all_channel_01
         
 	 		SELECT campaignChatId,  `channel`,
  					 SUM(CASE WHEN `action`  = "Delivery" 		THEN    userCount END) AS DeliveryCount,
                      SUM(CASE WHEN `action`  = "Open" 			THEN   	userCount END) AS OpenCount,
                      SUM(CASE WHEN `action`  = "Click" 			THEN   	userCount END) AS ClickCount,
                      SUM(CASE WHEN `action`  = "UnSubscribe" 	THEN   	userCount END) AS UnSubscribeCount
  			FROM tt_campaignAction_for_all_channel_01 
 				GROUP BY campaignChatId,  `channel`;				-- ***********************************************************************************
 		
         
             select 
 					row_number() over(order by createdate)					AS 'Sno',
 					`Name`													AS 'Campaign_Name',
                     createdate												AS 'Created_Date',
                     Campaign_Duration										AS 'Campaign_Duration',
 					TargetAud												AS 'Targeted_Audience',
 					contactslist											AS 'No_of_audience_targeted',
 					IFNULL(DeliveryCount,0)									AS 'Email_Delivery',
 					ROUND(IFNULL(OpenRate,0),2) 							AS 'Email_Openrate',
                     ROUND(IFNULL(ClickRate,0),2)							AS 'Email_Clickrate',
                     IFNULL(UnSubscribeCount, 0)							    AS 'Email_Unsubscribe_Rate'
             FROM (SELECT  t1.campaignChatId, t1.OpenCount, t1.ClickCount, t1.DeliveryCount, t1.`channel`, UnSubscribeCount,
 							CASE WHEN IFNULL(t1.DeliveryCount,0) != 0 THEN  ((t1.OpenCount*100)/t1.DeliveryCount) ELSE 0  END AS OpenRate,  
 							CASE WHEN IFNULL(t1.DeliveryCount,0) != 0 THEN  ((t1.ClickCount*100)/t1.DeliveryCount) ELSE 0 END AS ClickRate,
 							CASE WHEN IFNULL(t1.DeliveryCount,0) != 0 THEN	 (((t1.OpenCount*100)/t1.DeliveryCount) * 0.4) + (((t1.ClickCount*100)/t1.DeliveryCount) * 0.6) * (t1.DeliveryCount/v_totalDelivered) ELSE 0 END AS "EngagementScore"
 					FROM tt_group_campaignAction_for_all_channel_01 t1 
                     -- group by  t1.campaignChatId, p_domainId, t1.OpenCount, t1.ClickCount, t1.DeliveryCount, t1.`channel`
                 ) as t1
                 RIGHT JOIN tt_email_master_details t2 ON t1.campaignChatId = t2.campaignchatid and t1.`channel` = t2.`Channel`
                 order by createdate desc;
             
             SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
         
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_get_schedule_report_name_email_bkp_2026_02_11` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_get_schedule_report_name_email_bkp_2026_02_11`(
 	p_domainId				INT,
     p_startDate				date,
     p_endDate				date
 )
BEGIN
 			declare v_totalDelivered int default 0;
 			SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
             
             DROP TEMPORARY TABLE IF EXISTS tt_email_master_details;
             CREATE TEMPORARY TABLE tt_email_master_details
 					SELECT campaignId,
 							campaignchatid,
 							createdate,
 							`Name`,
 							TargetAud,
                             'Email'									AS `Channel`,
 							json_length(contactslist)				AS contactslist,
                             case when emailDelivery = 1 then 1
 								when emailDelivery  = 2  then datediff(emailDeliveryEndtime, emailDeliveryStarttime)  end as 'Campaign_Duration'
                             
 					FROM ec_email_campaign_master_dtl WHERE domainId = p_domainId AND isIndivCamp !=2 AND DATE(createdate) BETWEEN p_startDate AND p_endDate;
                     
 			 -- SELECT * FROM tt_email_master_details;  -- ****************************************************************************************************************
             
             DROP TEMPORARY TABLE IF EXISTS tt_campaignAction_for_all_channel_01;
             CREATE TEMPORARY TABLE tt_campaignAction_for_all_channel_01
 									SELECT    campaignChatId,  count(distinct userID) as userCount , 'Email' as 'channel',  'Open'as 'action' 
 					FROM Email_tb_indiv_user_click_open_cnt_dtl	 
 					WHERE  actionId = 3 and CampaignChatId IN 
                     (SELECT campaignchatid  
 						FROM ec_email_campaign_master_dtl 
                         WHERE domainId = p_domainId AND isIndivCamp !=2 AND DATE(createdate) BETWEEN p_startDate AND p_endDate)
 					GROUP BY campaignChatId
 			UNION ALL
                  SELECT campaignChatId, count(distinct userID ), 'Email',  'Click' 
 						FROM Email_tb_indiv_user_click_open_cnt_dtl 
 										WHERE actionId = 4 and 
 								campaignChatId	IN ( SELECT campaignchatid  FROM ec_email_campaign_master_dtl 
                         WHERE domainId = p_domainId AND isIndivCamp !=2 AND DATE(createdate) BETWEEN p_startDate AND p_endDate) 
  												GROUP BY campaignChatId
 		   UNION ALL
                 SELECT campaignChatId, count(distinct userID) , 'Email' ,  'Delivery' 
 						FROM Email_tb_indiv_user_click_open_cnt_dtl 
 						WHERE actionId = 2
 							AND campaignChatId IN (SELECT campaignchatid  FROM ec_email_campaign_master_dtl 
                         WHERE domainId = p_domainId AND isIndivCamp !=2 AND  DATE(createdate) BETWEEN p_startDate AND p_endDate) 
                                                 GROUP BY campaignChatId
             UNION ALL
                 SELECT campaignChatId, count(distinct userID) , 'Email' ,  'Bounced' 
 						FROM Email_tb_indiv_user_click_open_cnt_dtl 
 						WHERE actionId = 6
 							AND campaignChatId IN (SELECT campaignchatid  FROM ec_email_campaign_master_dtl 
                         WHERE domainId = p_domainId AND isIndivCamp !=2 AND  DATE(createdate) BETWEEN p_startDate AND p_endDate) 
                                                 GROUP BY campaignChatId                                    
            UNION ALL
 				SELECT campaignchatid, count(distinct emailId) , 'Email',  'UnSubscribe'
 						FROM ec_email_unsubscribe_dtl
                         where campaignchatid IN (SELECT campaignchatid  FROM ec_email_campaign_master_dtl 
                         WHERE domainId = p_domainId AND isIndivCamp !=2 AND  DATE(createdate) BETWEEN p_startDate AND p_endDate)
 										GROUP BY campaignchatid;
 			
             -- SELECT * FROM tt_email_master_click_open_details;	 -- ***********************************************************************************
             
             select SUM(userCount) INTO v_totalDelivered FROM tt_campaignAction_for_all_channel_01 where action  = "Delivery";
             
 		DROP TEMPORARY TABLE IF EXISTS tt_group_campaignAction_for_all_channel_01;
         CREATE TEMPORARY TABLE tt_group_campaignAction_for_all_channel_01
         
 	 		SELECT campaignChatId,  `channel`,
  					 SUM(CASE WHEN `action`  = "Delivery" 		THEN    userCount END) AS DeliveryCount,
                      SUM(CASE WHEN `action`  = "Open" 			THEN   	userCount END) AS OpenCount,
                      SUM(CASE WHEN `action`  = "Click" 			THEN   	userCount END) AS ClickCount,
                      SUM(CASE WHEN `action`  = "UnSubscribe" 	THEN   	userCount END) AS UnSubscribeCount,
                      SUM(CASE WHEN `action`  = "Bounced" 		THEN   	userCount END) AS BouncedCount
  			FROM tt_campaignAction_for_all_channel_01 
 				GROUP BY campaignChatId,  `channel`;				-- ***********************************************************************************
 		
         
             select 
 					row_number() over(order by createdate)					AS 'Sno',
 					`Name`													AS 'Campaign_Name',
                     createdate												AS 'Created_Date',
                     Campaign_Duration										AS 'Campaign_Duration',
 					TargetAud												AS 'Targeted_Audience',
 					contactslist											AS 'No_of_audience_targeted',
 					IFNULL(DeliveryCount,0)									AS 'Email_Delivery',
 					ROUND(IFNULL(OpenRate,0),2) 							AS 'Email_Openrate',
                     ROUND(IFNULL(ClickRate,0),2)							AS 'Email_Clickrate',
                     IFNULL(BouncedCount, 0)									AS 'Email Bouncerate',
                     IFNULL(UnSubscribeCount, 0)							    AS 'Email_Unsubscribe_Rate'
             FROM (SELECT  t1.campaignChatId, t1.OpenCount, t1.ClickCount, t1.DeliveryCount, t1.`channel`, UnSubscribeCount, BouncedCount,
 							CASE WHEN IFNULL(t1.DeliveryCount,0) != 0 THEN  ((t1.OpenCount*100)/t1.DeliveryCount) ELSE 0  END AS OpenRate,  
 							CASE WHEN IFNULL(t1.DeliveryCount,0) != 0 THEN  ((t1.ClickCount*100)/t1.DeliveryCount) ELSE 0 END AS ClickRate,
 							CASE WHEN IFNULL(t1.DeliveryCount,0) != 0 THEN	 (((t1.OpenCount*100)/t1.DeliveryCount) * 0.4) + (((t1.ClickCount*100)/t1.DeliveryCount) * 0.6) * (t1.DeliveryCount/v_totalDelivered) ELSE 0 END AS "EngagementScore"
 					FROM tt_group_campaignAction_for_all_channel_01 t1 
                     -- group by  t1.campaignChatId, p_domainId, t1.OpenCount, t1.ClickCount, t1.DeliveryCount, t1.`channel`
                 ) as t1
                 RIGHT JOIN tt_email_master_details t2 ON t1.campaignChatId = t2.campaignchatid and t1.`channel` = t2.`Channel`
                 order by createdate desc;
             
             SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
         
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_get_schedule_report_name_SMS` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_get_schedule_report_name_SMS`(
	p_domainId		INT,
    p_startDate		DATE,
    p_endDate		DATE
)
BEGIN
		DECLARE v_totalDelivered		INT;
        
		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;		
        
        DROP TEMPORARY TABLE IF EXISTS tt_SMS_Master_Dtl;
        CREATE TEMPORARY TABLE tt_SMS_Master_Dtl
				SELECT
					t1.id,
					t1.campaignchatid , 
					t1.domainId, 
					t1.`name` 										AS "Campaign_Name", 
					t1.createdDate									AS "Created_Date", 
					json_length(t1.contactDtls)  					AS "Total_Audience",
					t1.triggerType,
					'SMS'												AS  `Channel`,
                    CASE WHEN t1.triggerType = 0 THEN 1 
						 WHEN t1.triggerType = 1 THEN datediff(t2.schedulefromDate ,t1.createdDate)
                         ELSE datediff(t2.scheduletoDate, t2.schedulefromDate) END AS 'Campaign_Duration'
				FROM sc_campaign_master_dtl					t1
                JOIN sc_campaign_master_schedule_dtl 		t2		ON t1.id = t2.campaignId
				WHERE t1.domainId = p_domainId AND DATE(t1.createdDate) BETWEEN p_startDate AND p_endDate;
                
         
         
		DROP TEMPORARY TABLE IF EXISTS tt_campaignAction_for_all_channel_01;
		CREATE TEMPORARY TABLE tt_campaignAction_for_all_channel_01						
			SELECT   campaignChatId,  count(DISTINCT userID) as userCount, 'SMS'  as 'channel', 'Delivery'  as 'action' 
					FROM sms_tb_indiv_user_click_open_cnt_dtl 
					WHERE  actionId = 2 AND campaignChatId IN (SELECT  campaignchatid 
						FROM sc_campaign_master_dtl  t1
						JOIN sc_campaign_master_schedule_dtl  t2  ON  t1.id = t2.campaignId  AND t1.domainId = t2.domainId	 
						WHERE   t1.domainId = p_domainId 
							AND DATE(t1.createdDate) BETWEEN p_startDate AND p_endDate)
					GROUP BY campaignChatId
			UNION ALL
				SELECT   campaignChatId,  count(distinct userID) , 'SMS' , 'Click'  
					FROM sms_tb_indiv_user_click_open_cnt_dtl 
					WHERE actionId = 4 AND campaignChatId IN (
													SELECT  campaignchatid 
														FROM sc_campaign_master_dtl  t1
														JOIN sc_campaign_master_schedule_dtl  t2  ON  t1.id = t2.campaignId  AND t1.domainId = t2.domainId	 
														WHERE   t1.domainId = p_domainId 
															AND DATE(t1.createdDate) BETWEEN p_startDate AND p_endDate) 
					GROUP BY campaignChatId;
                        
                    
                 select SUM(userCount) INTO v_totalDelivered FROM tt_campaignAction_for_all_channel_01 where action  = "Delivery";    
                    
				DROP TEMPORARY TABLE IF EXISTS tt_group_campaignAction_for_all_channel_01;
				CREATE TEMPORARY TABLE tt_group_campaignAction_for_all_channel_01
				
					SELECT campaignChatId,  `channel`,
							SUM(CASE WHEN `action`  = "Delivery" 		THEN    userCount END) AS DeliveryCount,
							SUM(CASE WHEN `action`  = "Open" 			THEN   	userCount END) AS OpenCount,
							SUM(CASE WHEN `action`  = "Click" 			THEN   	userCount END) AS ClickCount
					FROM tt_campaignAction_for_all_channel_01 
						GROUP BY campaignChatId,  `channel`; 
		
         
         SELECT row_number() over(order by t2.Created_Date)																					As 'Sno',	
				t2.Campaign_Name																											AS "Campaign_Name", 
				t2.Created_Date 																											AS "Created_Date",
                t2.Campaign_Duration																										AS 'Campaign_Duration',
				t2.Total_Audience																											AS "No_of_audience_targeted", 
				t1.DeliveryCount 																											AS "SMS_Delivery"
         FROM (
			SELECT  t1.campaignChatId, t1.OpenCount, t1.ClickCount, t1.DeliveryCount, t1.`channel`, 
							CASE WHEN IFNULL(t1.DeliveryCount,0) != 0 THEN  ((t1.OpenCount*100)/t1.DeliveryCount) ELSE 0  END AS OpenRate,  
							CASE WHEN IFNULL(t1.DeliveryCount,0) != 0 THEN  ((t1.ClickCount*100)/t1.DeliveryCount) ELSE 0 END AS ClickRate,
							CASE WHEN IFNULL(t1.DeliveryCount,0) != 0 THEN	 (((t1.OpenCount*100)/t1.DeliveryCount) * 0.4) + (((t1.ClickCount*100)/t1.DeliveryCount) * 0.6) * (t1.DeliveryCount/v_totalDelivered) ELSE 0 END AS "EngagementScore"
					FROM tt_group_campaignAction_for_all_channel_01 t1 
                    -- group by  t1.campaignChatId, p_domainId, t1.OpenCount, t1.ClickCount, t1.DeliveryCount, t1.`channel`
			) AS t1
         RIGHT JOIN tt_SMS_Master_Dtl t2 ON t1.campaignChatId = t2.campaignchatid and t1.`channel` = t2.`Channel`
         ORDER BY t2.Created_Date DESC;
         
		SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
        
        DROP TEMPORARY TABLE tt_SMS_Master_Dtl;
        DROP TEMPORARY TABLE IF EXISTS tt_campaignAction_for_all_channel_01;
        DROP TEMPORARY TABLE IF EXISTS tt_group_campaignAction_for_all_channel_01;
 
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_get_schedule_report_name_WebPush` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_get_schedule_report_name_WebPush`(
	p_domainId		INT,
    p_startDate		DATE,
    p_endDate		DATE
)
BEGIN
		declare v_totalDelivered int ;

		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;		
        
        DROP TEMPORARY TABLE IF EXISTS tt_WebPush_Master_Dtl;
        CREATE TEMPORARY TABLE tt_WebPush_Master_Dtl
				SELECT 
					t1.campaignChatId , 
					t1.domainId, 
					t1.campaignName									AS "Campaign_Name", 
					t1.createdOn									AS "Created_Date", 
					json_length(t1.contactDtl)  					AS "Total_Audience",
					case when t2.scheduleType  = 0  then 1 
						when t2.scheduleType = 1 		THEN datediff(t2.schedulefromDate, t1.createdOn)
                        when t2.scheduleType = 2 		THEN datediff(t2.scheduletoDate, t2.schedulefromDate)
                        end as 'Campaign_Duration',
                    'WebPush'										AS 'Channel'
		FROM webpush_masterCampaignDtl			t1
          JOIN webpush_campaign_schedule_dtl 		t2 			ON 	t1.id  = t2.campaignId
		WHERE t1.domainId = p_domainId AND DATE(t1.createdOn) BETWEEN p_startDate AND p_endDate;
                
           -- SELECT * FROM tt_WebPush_Master_Dtl;      
         
		DROP TEMPORARY TABLE IF EXISTS tt_campaignAction_for_all_channel_01;
            CREATE TEMPORARY TABLE tt_campaignAction_for_all_channel_01			
            
				SELECT  campaignChatId,  count(distinct userID) as userCount , 'WebPush' as 'channel', "Delivery" as 'action'  FROM webPush_tb_indiv_user_click_open_cnt_dtl 
 												WHERE  actionId = 2 AND  
													campaignChatId IN (SELECT t1.campaignChatId 
																			FROM webpush_masterCampaignDtl	t1
																	JOIN webpush_campaign_schedule_dtl		t2		ON 		t1.id = t2.campaignId  AND t1.domainId = t2.domainId
																		WHERE t1.domainId = p_domainId AND DATE(t1.createdOn) BETWEEN p_startDate AND p_endDate)
                                                  GROUP BY campaignChatId
				UNION ALL
                SELECT  campaignChatId,  count(DISTINCT userID) , 'WebPush' , "Click"  FROM webPush_tb_indiv_user_click_open_cnt_dtl 
												WHERE actionId = 4 AND 
												campaignChatId IN (SELECT t1.campaignChatId 
																			FROM webpush_masterCampaignDtl	t1
																	JOIN webpush_campaign_schedule_dtl		t2		ON 		t1.id = t2.campaignId  AND t1.domainId = t2.domainId
																		WHERE t1.domainId = p_domainId AND DATE(t1.createdOn) BETWEEN p_startDate AND p_endDate) 	
                                                 GROUP BY campaignChatId;
		  -- select * from tt_WebPush_Master_Delivery_Dtl;
                
                
                 select SUM(userCount) INTO v_totalDelivered FROM tt_campaignAction_for_all_channel_01 where action  = "Delivery";
            
		DROP TEMPORARY TABLE IF EXISTS tt_group_campaignAction_for_all_channel_01;
        CREATE TEMPORARY TABLE tt_group_campaignAction_for_all_channel_01
        
	 		SELECT campaignChatId,  `channel`,
 					 SUM(CASE WHEN `action`  = "Delivery" 		THEN    userCount END) AS DeliveryCount,
                     SUM(CASE WHEN `action`  = "Open" 			THEN   	userCount END) AS OpenCount,
                     SUM(CASE WHEN `action`  = "Click" 			THEN   	userCount END) AS ClickCount
 			FROM tt_campaignAction_for_all_channel_01 
				GROUP BY campaignChatId,  `channel`;	
			
         
          -- SELECT * FROM tt_WebPush_Master_Open_Dtl;
         
         SELECT row_number() over()																								AS 'Sno',
				t2.Campaign_Name																								AS "Campaign_Name", 
				t2.Created_Date 																								AS "Created_Date",
                t2.Campaign_Duration																							AS "Campaign_Duration",											
				t2.Total_Audience																								AS "No_of_audience_targeted", 
                IFNULL(t1.DeliveryCount,0) 																						AS "Web_Push_Delivery",
				ROUND(IFNULL(t1.OpenRate,0),2)																							AS "Web_Push_Openrate"
         FROM (
			SELECT  t1.campaignChatId, t1.OpenCount, t1.ClickCount, t1.DeliveryCount, t1.`channel`, 
							CASE WHEN IFNULL(t1.DeliveryCount,0) != 0 THEN  ((t1.OpenCount*100)/t1.DeliveryCount) ELSE 0  END AS OpenRate  
							 ,CASE WHEN IFNULL(t1.DeliveryCount,0) != 0 THEN  ((t1.ClickCount*100)/t1.DeliveryCount) ELSE 0 END AS ClickRate
							 ,CASE WHEN IFNULL(t1.DeliveryCount,0) != 0 THEN	 (((t1.OpenCount*100)/t1.DeliveryCount) * 0.4) + (((t1.ClickCount*100)/t1.DeliveryCount) * 0.6) * (t1.DeliveryCount/v_totalDelivered) ELSE 0 END AS "EngagementScore"
					FROM tt_group_campaignAction_for_all_channel_01 t1 
                    -- group by  t1.campaignChatId, p_domainId, t1.OpenCount, t1.ClickCount, t1.DeliveryCount, t1.`channel`
			) AS t1
          RIGHT JOIN tt_WebPush_Master_Dtl t2 ON t1.campaignChatId = t2.campaignchatid and t1.`channel` = t2.`Channel`
          order by t2.Created_Date 		desc
          ;
         
		SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
        
        DROP TEMPORARY TABLE tt_WebPush_Master_Dtl;
        DROP TEMPORARY TABLE tt_campaignAction_for_all_channel_01;
        DROP TEMPORARY TABLE tt_group_campaignAction_for_all_channel_01;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_get_schedule_report_name_whatsapp` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_get_schedule_report_name_whatsapp`(
		p_domainId			INT,
        p_startDate			DATE,
        p_endDate			DATE
)
BEGIN
			DECLARE v_totalDelivered INT DEFAULT 0;
            
			SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
            
            DROP TEMPORARY TABLE IF EXISTS tt_Whatsapp_Master_Dtl;
            CREATE TEMPORARY TABLE tt_Whatsapp_Master_Dtl
            SELECT 			t1.domainId																	AS 'Domain_Id', 
								t1.campaignchatId 														AS 'Campaign_ChatId',
								t1.campName																AS 'Campaign_Name', 
								t1.createdDate															AS 'Created_On',
								JSON_LENGTH(t1.contactList) 											AS 'No_Audience_Targeted',
                                'Whatsapp'																AS 'Channel',
					case when t1.triggerType = 0 then 1 
						when t1.triggerType != 0 then datediff(t1.scheduleDate ,t1.createdDate)			END AS 'Campaign_Duration'
            FROM 	wc_campaign_master_dtl  				t1
			WHERE t1.domainId = p_domainId	 AND 	DATE(t1.createdDate)  BETWEEN 	p_startDate and p_endDate;
            
            
            -- SELECT * FROM tt_Whatsapp_Master_Dtl;
            
			DROP TEMPORARY TABLE IF EXISTS tt_campaignAction_for_all_channel_01;
            CREATE TEMPORARY TABLE tt_campaignAction_for_all_channel_01
            
				SELECT  campaignChatId, count(distinct userID) as userCount, 'Whatsapp' as 'channel', "Delivery"  as 'action' 
						FROM whatsapp_tb_indiv_user_click_open_cnt_dtl 
						WHERE	actionId = 2 
							AND campaignChatId IN (SELECT campaignchatid FROM wc_campaign_master_dtl WHERE domainId = p_domainId AND  DATE(createdDate)  BETWEEN 	p_startDate and p_endDate)
						GROUP BY campaignChatId
				UNION ALL
 				SELECT  campaignChatId, count(distinct userID) , 'Whatsapp' , 'Open'  
						FROM whatsapp_tb_indiv_user_click_open_cnt_dtl 
						WHERE actionId = 3 
							AND campaignChatId IN (SELECT campaignchatid FROM wc_campaign_master_dtl WHERE domainId = p_domainId AND  DATE(createdDate)  BETWEEN 	p_startDate and p_endDate)
						GROUP BY campaignChatId
 				UNION ALL
 				SELECT  campaignChatId, count(distinct userID) , 'Whatsapp' , "Click"  FROM whatsapp_tb_indiv_user_click_open_cnt_dtl 
 												WHERE actionId = 4
													AND campaignChatId IN (SELECT campaignchatid FROM wc_campaign_master_dtl WHERE domainId = p_domainId AND  DATE(createdDate)  BETWEEN 	p_startDate and p_endDate) 
                                                  GROUP BY campaignChatId;
                                                  
				SELECT SUM(userCount) INTO v_totalDelivered FROM tt_campaignAction_for_all_channel_01 WHERE action  = "Delivery";
		
			-- SELECT * FROM tt_Whatsapp_Master_Open_Click_Dtl;
            
            DROP TEMPORARY TABLE IF EXISTS tt_group_campaignAction_for_all_channel_01;
			CREATE TEMPORARY TABLE tt_group_campaignAction_for_all_channel_01
        
	 		SELECT campaignChatId,  `channel`,
 					 SUM(CASE WHEN `action`  = "Delivery" 		THEN    userCount END) AS DeliveryCount,
                     SUM(CASE WHEN `action`  = "Open" 			THEN   	userCount END) AS OpenCount,
                     SUM(CASE WHEN `action`  = "Click" 			THEN   	userCount END) AS ClickCount
 			FROM tt_campaignAction_for_all_channel_01 
				GROUP BY campaignChatId,  `channel`;
                
                
            
			SELECT 	row_number() over(order by t2.Created_On)		AS 'Sno',	
					t2.Campaign_Name								AS "Campaign_Name",
					t2.Created_On									AS "Created_Date",  
                    t2.Campaign_Duration							AS "Campaign_Duration",
					t2.No_Audience_Targeted							AS "No_of_audience_targeted", 
                    IFNULL(t1.deliveryCount,0)						AS "WhatsApp_Delivery", 			
					ROUND(IFNULL(t1.OpenRate,0),2)					AS "Whatsapp_Openrate"
                    FROM ( SELECT  t1.campaignChatId, t1.OpenCount, t1.ClickCount, t1.DeliveryCount, t1.`channel`, 
							CASE WHEN IFNULL(t1.DeliveryCount,0) != 0 THEN  ((t1.OpenCount*100)/t1.DeliveryCount) ELSE 0  END AS OpenRate,  
							CASE WHEN IFNULL(t1.DeliveryCount,0) != 0 THEN  ((t1.ClickCount*100)/t1.DeliveryCount) ELSE 0 END AS ClickRate,
							CASE WHEN IFNULL(t1.DeliveryCount,0) != 0 THEN	 (((t1.OpenCount*100)/t1.DeliveryCount) * 0.4) + (((t1.ClickCount*100)/t1.DeliveryCount) * 0.6) * (t1.DeliveryCount/v_totalDelivered) ELSE 0 END AS "EngagementScore"
					FROM tt_group_campaignAction_for_all_channel_01 t1 
                    -- group by  t1.campaignChatId, p_domainId, t1.OpenCount, t1.ClickCount, t1.DeliveryCount, t1.`channel`
						) as t1
						RIGHT JOIN tt_Whatsapp_Master_Dtl t2 ON t1.campaignChatId = t2.Campaign_ChatId and t1.`channel` = t2.`Channel`
                        order by t2.Created_On desc	
                        ;
        
			
            SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
			
            DROP TEMPORARY TABLE IF EXISTS tt_Whatsapp_Master_Dtl;
            DROP TEMPORARY TABLE IF EXISTS tt_campaignAction_for_all_channel_01;
            DROP TEMPORARY TABLE IF EXISTS tt_group_campaignAction_for_all_channel_01;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_get_sms_open_click_contact_dtl_nlp` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_get_sms_open_click_contact_dtl_nlp`(
	p_domainId					INT,
    p_campaignChatId			VARCHAR(300)
)
BEGIN
		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        
        SELECT t1.domainId, t1.campaignChatId, t1.actionId, t2.id, t2.firstName, t2.lastName, t2.whatsappNumber, t2.phoneNumber 
			FROM sms_tb_indiv_user_click_open_cnt_dtl			t1
			JOIN wc_user_contact_dtl							t2	ON t1.userID = t2.id
		WHERE t1.campaignChatId = p_campaignChatId and t1.domainId = p_domainId and t1.actionId in (3, 4);
        
        
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;


end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_get_template_chat_memory` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_get_template_chat_memory`(
	
        p_domainId				INT ,
        p_templateId		VARCHAR(300),
        p_team					INT,
        p_channel				VARCHAR(50)	,
        p_campaignChatId		VARCHAR(300)
)
BEGIN
		
        SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
					
			SELECT 
						id ,domainId ,campaignChatId ,templateId ,`channel` ,conversation ,template , team, createdOn ,updatedOn
            FROM wc_tb_template_chat_memory
            WHERE domainId = p_domainId AND team = p_team AND `channel` = p_channel AND campaignChatId = p_campaignChatId AND (IFNULL(p_templateId, '') = '' OR templateId = p_templateId );
                    
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;        

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_get_template_chat_memory_ccaass` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_get_template_chat_memory_ccaass`(		
p_domainId		INT,	
p_templateId	VARCHAR(300)
)
begin
		set session transaction isolation level read uncommitted;
		
				SELECT 
						id, domainId, campaignChatId, templateId, `channel`, conversation, template, team, createdOn, updatedOn
                FROM wc_tb_template_chat_memory WHERE p_domainId = domainId AND templateId = p_templateId and team = 1;

		set session transaction isolation level repeatable read;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_get_topPerformingCampaign` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_get_topPerformingCampaign`(
		p_domainId									INT
)
BEGIN
			
             DECLARE v_fromDate						DATE DEFAULT NOW();
             DECLARE v_totalDelivered 				INT DEFAULT 0;
            
              SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;   
		
			DROP TEMPORARY TABLE IF EXISTS tt_campaign_for_all_channel_01;		
			CREATE TEMPORARY TABLE tt_campaign_for_all_channel_01
            
					SELECT campaignchatid AS 'CampaignChatId', domainId AS 'DomainId','Email' AS 'Channel', `Name` AS 'CampaignName', createdate 
						FROM ec_email_campaign_master_dtl WHERE domainId = p_domainId AND  v_fromDate >= emailDeliveryStarttime AND v_fromDate<= emailDeliveryEndtime
					
                    UNION ALL
					SELECT  t1.campaignchatid, t1.domainId , 'SMS', t1.`name`, t1.createdDate
                            FROM sc_campaign_master_dtl  t1
							JOIN sc_campaign_master_schedule_dtl  t2  ON  t1.id = t2.campaignId  AND t1.domainId = t2.domainId	 
							WHERE   t1.domainId = p_domainId 
								AND CASE WHEN t2.scheduletoDate IS NULL THEN schedulefromDate = v_fromDate ELSE v_fromDate >= schedulefromDate AND v_fromDate <=scheduletoDate END
						
					UNION ALL
					SELECT campaignchatid, domainId, 'Whatsapp', campName, 
							createdDate 
                            FROM wc_campaign_master_dtl WHERE domainId = p_domainId AND  DATE(scheduleDate) = v_fromDate
                            
					UNION ALL
					SELECT t1.campaignChatId , t1.domainId, 'AppPush', t1.campaignName,
                            t1.createdOn FROM AppPush_campaign_master_dtl t1
							JOIN Apppush_campaign_schedule_dtl	t2		ON t1.id = t2.campaignId		AND t1.domainId = t2.domainId
                            WHERE t1.domainId = p_domainId AND  DATE(t2.schedulefromDate) =  v_fromDate
					
                    UNION ALL
					SELECT t1.campaignChatId, t1.domainId, 'WebPush', t1.campaignName,
                            t1.createdOn 
							FROM webpush_masterCampaignDtl			t1
							JOIN webpush_campaign_schedule_dtl		t2		ON 		t1.id = t2.campaignId  AND t1.domainId = t2.domainId
                            WHERE t1.domainId = p_domainId AND DATE(t2.schedulefromDate) = v_fromDate;
					
                   --  UNION ALL
-- 					SELECT campaignChatId, domainId, 'inApp', campaignName, -- JSON_LENGTH(contactDtl), 
--                             createdOn From inApp_campaign_master_dtl  where campaignChatId = p_CampaignChatId  AND domainId = p_domainId;	

            

			DROP TEMPORARY TABLE IF EXISTS tt_campaignAction_for_all_channel_01;			-- ********************** Storing unique sent, open and click count ***********************
			CREATE TEMPORARY TABLE tt_campaignAction_for_all_channel_01
            
				SELECT    campaignChatId,  count(distinct userID) as userCount , 'Email' as 'channel',  'Open'as 'action' 
					FROM Email_tb_indiv_user_click_open_cnt_dtl	 
					WHERE  actionId = 3 and CampaignChatId IN 
                    (SELECT campaignchatid  
						FROM ec_email_campaign_master_dtl 
                        WHERE domainId = p_domainId AND  v_fromDate >= emailDeliveryStarttime AND v_fromDate<= emailDeliveryEndtime)
					GROUP BY campaignChatId
			UNION ALL
                 SELECT campaignChatId, count(distinct userID ), 'Email',  'Click' 
						FROM Email_tb_indiv_user_click_open_cnt_dtl 
										WHERE actionId = 4 and 
								campaignChatId	IN ( SELECT campaignchatid  FROM ec_email_campaign_master_dtl 
                        WHERE domainId = p_domainId AND  v_fromDate >= emailDeliveryStarttime AND v_fromDate<= emailDeliveryEndtime) 
 												GROUP BY campaignChatId
		   UNION ALL
                SELECT campaignChatId, count(distinct userID) , 'Email' ,  'Delivery' 
						FROM Email_tb_indiv_user_click_open_cnt_dtl 
						WHERE actionId = 1
							AND campaignChatId IN (SELECT campaignchatid  FROM ec_email_campaign_master_dtl 
                        WHERE domainId = p_domainId AND  v_fromDate >= emailDeliveryStarttime AND v_fromDate<= emailDeliveryEndtime) 
                                                GROUP BY campaignChatId
		    UNION ALL			
            
            
 				SELECT   campaignChatId,  count(DISTINCT userID) , 'SMS' , 'Delivery'  
						FROM sms_tb_indiv_user_click_open_cnt_dtl 
						WHERE  actionId = 1 AND campaignChatId IN (SELECT  campaignchatid 
                            FROM sc_campaign_master_dtl  t1
							JOIN sc_campaign_master_schedule_dtl  t2  ON  t1.id = t2.campaignId  AND t1.domainId = t2.domainId	 
							WHERE   t1.domainId = p_domainId 
								AND CASE WHEN t2.scheduletoDate IS NULL THEN schedulefromDate = v_fromDate ELSE v_fromDate >= schedulefromDate AND v_fromDate <=scheduletoDate END)
						GROUP BY campaignChatId
 				UNION ALL
                 SELECT   campaignChatId,  count(distinct userID) , 'SMS' , 'Click'  
						FROM sms_tb_indiv_user_click_open_cnt_dtl 
						WHERE actionId = 4 AND campaignChatId IN (
														SELECT  campaignchatid 
															FROM sc_campaign_master_dtl  t1
															JOIN sc_campaign_master_schedule_dtl  t2  ON  t1.id = t2.campaignId  AND t1.domainId = t2.domainId	 
															WHERE   t1.domainId = p_domainId 
																AND CASE WHEN t2.scheduletoDate IS NULL THEN schedulefromDate = v_fromDate 
																	ELSE v_fromDate >= schedulefromDate AND v_fromDate <=scheduletoDate END) 
						GROUP BY campaignChatId
                        
                        
 				UNION ALL			
 				SELECT  campaignChatId, count(distinct userID) , 'Whatsapp' , "Delivery"  
						FROM whatsapp_tb_indiv_user_click_open_cnt_dtl 
						WHERE	actionId = 2 
							AND campaignChatId IN (SELECT campaignchatid FROM wc_campaign_master_dtl WHERE domainId = p_domainId AND  DATE(scheduleDate) = v_fromDate)
						GROUP BY campaignChatId
				UNION ALL
 				SELECT  campaignChatId, count(distinct userID) , 'Whatsapp' , 'Open'  
						FROM whatsapp_tb_indiv_user_click_open_cnt_dtl 
						WHERE actionId = 3 
							AND campaignChatId IN (SELECT campaignchatid FROM wc_campaign_master_dtl WHERE domainId = p_domainId AND  DATE(scheduleDate) = v_fromDate)
						GROUP BY campaignChatId
 				UNION ALL
 				SELECT  campaignChatId, count(distinct userID) , 'Whatsapp' , "Click"  FROM whatsapp_tb_indiv_user_click_open_cnt_dtl 
 												WHERE actionId = 4
													AND campaignChatId IN (SELECT campaignchatid FROM wc_campaign_master_dtl WHERE domainId = p_domainId AND  DATE(scheduleDate) = v_fromDate) 
                                                  GROUP BY campaignChatId
						
                        
 				UNION ALL			
 				SELECT  campaignChatId,  count(DISTINCT userID) , 'AppPush' , "Delivery"  FROM AppPush_tb_indiv_user_click_open_cnt_dtl 
 												WHERE  actionId = 2
                                                AND campaignChatId IN (SELECT t1.campaignChatId  FROM AppPush_campaign_master_dtl t1
																	JOIN Apppush_campaign_schedule_dtl	t2		ON t1.id = t2.campaignId AND t1.domainId = t2.domainId
																	WHERE t1.domainId = p_domainId AND  DATE(t2.schedulefromDate) =  v_fromDate) 
												GROUP BY campaignChatId
 				UNION ALL
 				SELECT  campaignChatId,  count(DISTINCT userID) , 'AppPush' , 'Open'  FROM AppPush_tb_indiv_user_click_open_cnt_dtl 
 												WHERE actionId = 3 AND
													campaignChatId IN (SELECT t1.campaignChatId  FROM AppPush_campaign_master_dtl t1
																	JOIN Apppush_campaign_schedule_dtl	t2		ON t1.id = t2.campaignId AND t1.domainId = t2.domainId
																	WHERE t1.domainId = p_domainId AND  DATE(t2.schedulefromDate) =  v_fromDate)  
                                                  GROUP BY campaignChatId
                                                  
                                                 
 				UNION ALL			
 				SELECT  campaignChatId,  count(distinct userID) , 'WebPush' , "Delivery"  FROM webPush_tb_indiv_user_click_open_cnt_dtl 
 												WHERE  actionId = 2 AND  
													campaignChatId IN (SELECT t1.campaignChatId 
																			FROM webpush_masterCampaignDtl	t1
																	JOIN webpush_campaign_schedule_dtl		t2		ON 		t1.id = t2.campaignId  AND t1.domainId = t2.domainId
																		WHERE t1.domainId = p_domainId AND DATE(t2.schedulefromDate) = v_fromDate)
                                                  GROUP BY campaignChatId
				UNION ALL
                SELECT  campaignChatId,  count(DISTINCT userID) , 'WebPush' , "Click"  FROM webPush_tb_indiv_user_click_open_cnt_dtl 
												WHERE actionId = 4 AND 
												campaignChatId IN (SELECT t1.campaignChatId 
																			FROM webpush_masterCampaignDtl	t1
																	JOIN webpush_campaign_schedule_dtl		t2		ON 		t1.id = t2.campaignId  AND t1.domainId = t2.domainId
																		WHERE t1.domainId = p_domainId AND DATE(t2.schedulefromDate) = v_fromDate) 	
                                                 GROUP BY campaignChatId;
							
            
            select SUM(userCount) INTO v_totalDelivered FROM tt_campaignAction_for_all_channel_01 where action  = "Delivery";
            
            DROP TEMPORARY TABLE IF EXISTS tt_group_campaignAction_for_all_channel_01;
        CREATE TEMPORARY TABLE tt_group_campaignAction_for_all_channel_01
        
	 		SELECT campaignChatId,  `channel`,
 					 SUM(CASE WHEN `action`  = "Delivery" 		THEN    userCount END) AS DeliveryCount,
                     SUM(CASE WHEN `action`  = "Open" 			THEN   	userCount END) AS OpenCount,
                     SUM(CASE WHEN `action`  = "Click" 			THEN   	userCount END) AS ClickCount
 			FROM tt_campaignAction_for_all_channel_01 
				GROUP BY campaignChatId,  `channel`;
			
            
            SELECT  t2.campaignChatId 					AS 'campaignChatId',
					p_domainId 							AS 'domainId',
                    t2.campaignName 					AS 'CampaignName', 
                    IFNULL(t1.OpenCount,0)				AS 'OpenCount', 
                    IFNULL(t1.ClickCount,0) 			AS 'ClickCount',
                    IFNULL(t1.DeliveryCount,0)			AS 'SentCount', 
					t2.`Channel`						AS 'Channel', 
                    IFNULL(t1.OpenRate,0)				AS 'OpenRate', 
                    IFNULL(t1.ClickRate,0)				AS 'ClickRate', 			
                    IFNULL(t1.EngagementScore,0) 		AS 'EngagementScore'
                    FROM (
					SELECT  t1.campaignChatId, t1.OpenCount, t1.ClickCount, t1.DeliveryCount, t1.`channel`, 
							CASE WHEN IFNULL(t1.DeliveryCount,0) != 0 THEN  ((t1.OpenCount*100)/t1.DeliveryCount)  END AS OpenRate,  
							CASE WHEN IFNULL(t1.DeliveryCount,0) != 0 THEN  ((t1.ClickCount*100)/t1.DeliveryCount) END AS ClickRate,
							CASE WHEN IFNULL(t1.DeliveryCount,0) != 0 THEN	 (((t1.OpenCount*100)/t1.DeliveryCount) * 0.4) + (((t1.ClickCount*100)/t1.DeliveryCount) * 0.6) * (t1.DeliveryCount/v_totalDelivered) END AS "EngagementScore"
					FROM tt_group_campaignAction_for_all_channel_01 t1 
                    -- group by  t1.campaignChatId, p_domainId, t1.OpenCount, t1.ClickCount, t1.DeliveryCount, t1.`channel`
                ) as t1
                RIGHT JOIN tt_campaign_for_all_channel_01 t2 ON t1.campaignChatId = t2.campaignChatId and t1.`channel` = t2.`Channel`;
                
             SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;   
             
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_get_user_dlt_by_location_or_lifecycle` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_get_user_dlt_by_location_or_lifecycle`(
 		p_domainId			INT,
 		p_country			VARCHAR(100),
 		p_lifeCycleStage	VARCHAR(50),
 		p_city				VARCHAR(100),
		p_industryType		VARCHAR(250),
		p_jobTitle			VARCHAR(250),
		p_companyName		VARCHAR(250)
   )
BEGIN
 
   			SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
 
  				 SELECT id , domainId , firstName , lastName , whatsappNumber , phoneNumber , email
   					, customerType , tags , location , city , address , state , country , postCode
   					, createdAt , updatedAt , `source` , deviceId , sip_log_id , extension , lifeCycleStage,
                     isUnSub_Whatsapp ,isUnSub_SMS ,isUnSub_Email ,isUnSub_AppPush ,isUnSub_WebPush ,isUnSub_InApp
   					FROM wc_user_contact_dtl 
					WHERE domainId = p_domainId
					AND (IFNULL(p_country,'') = '' OR country = p_country)
					AND (IFNULL(p_lifeCycleStage,'') = '' OR lifeCycleStage = p_lifeCycleStage)
					AND (IFNULL(p_city,'') = '' OR city = p_city)
					AND (IFNULL(p_industryType,'') = '' OR industryType = p_industryType)
					AND (IFNULL(p_jobTitle,'') = '' OR jobTitle = p_jobTitle)
					AND (IFNULL(p_companyName,'') = '' OR companyName = p_companyName)
					;

               SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_get_webPush_open_click_contact_dtl_nlp` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_get_webPush_open_click_contact_dtl_nlp`(
	p_domainId					INT,
    p_campaignChatId			VARCHAR(300)
)
BEGIN
		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        
        SELECT t1.domainId, t1.campaignChatId, t1.actionId, t2.id, t2.firstName, t2.lastName, t2.deviceId, t2.deviceOS, t2.pushNotificationId
			FROM webPush_tb_indiv_user_click_open_cnt_dtl			t1
			JOIN wc_user_contact_dtl							t2	ON t1.userID = t2.id
		WHERE t1.campaignChatId = p_campaignChatId and t1.domainId = p_domainId and t1.actionId in (3, 4);
        
        
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;


end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_get_whatsapp_earlier_config_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_get_whatsapp_earlier_config_dtl`(
   p_campaingChatId		VARCHAR(300)
   )
BEGIN
   		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
           
           SELECT domainId, `status`, template FROM wc_whatsapp_earlier_config_dtl
           WHERE campaingChatId = p_campaingChatId;
           
           SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   
   end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_get_whatsapp_earlier_config_status_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_get_whatsapp_earlier_config_status_dtl`(
   p_status		varchar(50)
   )
BEGIN
   		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
           
           SELECT domainId, campaingChatId, `status`, template, payloadDtl FROM wc_whatsapp_earlier_config_dtl
           WHERE `status` = p_status;
           
           SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   
   end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_get_whatsapp_open_click_contact_dtl_nlp` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_get_whatsapp_open_click_contact_dtl_nlp`(
	p_domainId					INT,
    p_campaignChatId			VARCHAR(300)
)
BEGIN
		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        
        SELECT t1.domainId, t1.campaignChatId, t1.actionId, t2.id, t2.firstName, t2.lastName, t2.whatsappNumber, t2.phoneNumber 
			FROM whatsapp_tb_indiv_user_click_open_cnt_dtl			t1
			JOIN wc_user_contact_dtl							t2	ON t1.userID = t2.id
		WHERE t1.campaignChatId = p_campaignChatId and t1.domainId = p_domainId and t1.actionId in (3, 4);
        
        
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;


end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_InsertCloneTemplateDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_InsertCloneTemplateDtl`(			
 p_cloneId			INT,
 p_domainId			INT,
 p_templateName		VARCHAR(150)
 )
BEGIN
 	
     DECLARE v_checkDtl				INT DEFAULT 0;
     DECLARE v_errCode				INT DEFAULT -1;
     DECLARE v_errMsg				VARCHAR(100) DEFAULT "Failed";
     DECLARE v_lastId				INT DEFAULT 0;
    
 	SELECt 1 INTO v_checkDtl FROM wc_template_master_dtl
     WHERE id = p_cloneId AND domainId = p_domainId;
     
     IF v_checkDtl = 1 THEN
 		
         DROP TEMPORARY TABLE IF EXISTS tt_templateDtl;
         CREATE TEMPORARY TABLE tt_templateDtl
         SELECT * FROM wc_template_master_dtl WHERE id = p_cloneId AND domainId = p_domainId;
 	
         INSERT INTO wc_template_master_dtl ( domainId, templateName, whatsappAccount, category, `language`, headerType
          , headerValue, message, footer, buttonType, `status`, variable, clonedfrom)
         SELECT  domainId, p_templateName, whatsappAccount, category, `language`, headerType
          , headerValue, message, footer, buttonType, "DRAFT", variable ,p_cloneId
          FROM tt_templateDtl WHERE id = p_cloneId; 
          
          SELECT LAST_INSERT_ID() INTO v_lastId;
         
         IF ROW_COUNT() > 0 THEN
         
 			SET v_errCode = 1;
             SET v_errMsg = "Inserted Successfully";
 		
         END IF;
         
     END IF;
     
     SELECT v_errCode AS "errCode",  v_errMsg AS "errMsg" , v_lastId ;
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_insertTempContactInformationDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_insertTempContactInformationDtl`(
   		    p_id 						INT,
              p_domainId 					INT,
              p_firstName					VARCHAR(100),
              p_lastName					VARCHAR(100),
              p_whatsappNumber			VARCHAR(30),
     		    p_phoneNumber				VARCHAR(30),
   		    p_email						VARCHAR(200),
              p_customerType				VARCHAR(100),
              p_tags						VARCHAR(100),
   		    p_location					VARCHAR(100),
              p_city						VARCHAR(100),
              p_address					TEXT,
              p_state						VARCHAR(100),
              p_country					VARCHAR(100),
              p_postCode					VARCHAR(50),
              p_source					VARCHAR(100),
              p_lifeCycleStage			VARCHAR(50),
  			p_deviceId					VARCHAR(150),
              p_deviceOS					VARCHAR(50),
              p_pushNotificationId		VARCHAR(3000),
              p_sip_log_id				BIGINT,
              p_extension					INT,
              p_istempCustomer			VARCHAR(300),
              p_industryType 				VARCHAR(250),
              p_jobTitle 					VARCHAR(250),
              p_companyName 				VARCHAR(250)
          )
SP:BEGIN
           
        		   DECLARE v_check				INT DEFAULT 0;
                   DECLARE v_checkUpdate		INT DEFAULT 0;
                   DECLARE v_errCode			INT DEFAULT 0;
                   DECLARE v_insertId			INT DEFAULT 0;
                   DECLARE v_errMsg				VARCHAR(100) DEFAULT "Failed";
                   
   
        		   SELECT id INTO v_check FROM wc_user_contact_dtl WHERE domainId = p_domainId AND email = p_email;
          	
           			IF v_check = 0 THEN
       						
                               IF(p_domainId IS NULL OR p_firstName IS NULL OR p_email IS NULL OR p_istempCustomer = 0 ) THEN
   									SELECT v_errCode as errCode, 'Please enter the mandatory field name' as errMsg;
   									LEAVE SP;
       						END IF;
                       
                           INSERT INTO wc_user_contact_dtl (domainId ,firstName, lastName, whatsappNumber, phoneNumber,
        						email,	customerType,	tags,	location,	city,	address,	state,	country, postCode, `source`, lifeCycleStage, deviceId, 
                               deviceOS, pushNotificationId, sip_log_id, extension, istempCustomer, industryType, jobTitle, companyName)
        				   VALUES( p_domainId ,p_firstName, p_lastName, trim(p_whatsappNumber), trim(p_phoneNumber),p_email,	p_customerType,	p_tags,	p_location,	p_city,	p_address,	
        						p_state, p_country, p_postCode, p_source ,IFNULL(p_lifeCycleStage, 'Lead'), p_deviceId, 
                               p_deviceOS, p_pushNotificationId, p_sip_log_id, p_extension, p_istempCustomer, p_industryType, p_jobTitle, p_companyName);
                               
          					IF ROW_COUNT() > 0 THEN
          						SET  v_errCode = 1;
          						SET  v_errMsg  = "Inserted Successfully";
          						SET	 v_insertId = last_insert_id();
          					END IF;
                           
 						  	if not exists (select 1 from wc_user_contact_dtl where domainId=p_domainId) THEN
 							
 							insert into user_contact_dtl(domainId) values(p_domainId);
 							
 							end if;
 							
 							
   				ELSE
                           
           					UPDATE wc_user_contact_dtl SET 
        								firstName = IFNULL(p_firstName, firstName)
                                       , lastName= IFNULL(p_lastName, lastName)
                                       , phoneNumber = IFNULL(trim(p_phoneNumber), phoneNumber)
                                       , whatsappNumber = IFNULL(trim(p_whatsappNumber), whatsappNumber)
                                       , customerType = IFNULL(p_customerType, customerType)
                                       , tags = IFNULL(p_tags, tags)
                                       , location = IFNULL(p_location, location)
                                       , city =	IFNULL(p_city, city)
                                       , address = IFNULL(p_address,address)
                                       , state = IFNULL(p_state, p_state)
                                       , country = IFNULL(p_country, country)
                                       , postCode = IFNULL(p_postCode, postCode)
                                       , `source` = IFNULL(p_source, `source`)
                                       , lifeCycleStage = IFNULL(p_lifeCycleStage, lifeCycleStage)
                                       , deviceId = IFNULL(p_deviceId, deviceId)
                                       , deviceOS = IFNULL(p_deviceOS, deviceOS)
                                       , pushNotificationId = IFNULL(p_pushNotificationId, pushNotificationId)
                                       , sip_log_id = IFNULL(p_sip_log_id, sip_log_id)
                                       , extension	= IFNULL(p_extension, extension)
                                       , istempCustomer = IFNULL(p_istempCustomer, istempCustomer)
  									 , industryType	= IFNULL(p_industryType, industryType)
                                       , jobTitle	= IFNULL(p_jobTitle, jobTitle)
                                       , companyName	= IFNULL(p_companyName, companyName)
                                       , updatedAt	= now()
           							WHERE domainId = p_domainId AND email = p_email AND  id = v_check;
                                       
                                       IF ROW_COUNT() > 0 THEN 
           								SET  v_errCode = 2;
           								SET  v_errMsg  = "Updated Successfully";
           							END IF;
                           END IF;
                           
                   SELECT v_errCode AS errCode, v_errMsg As errMsg, v_insertId  ;
           
           END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_insertUpdateAdvancefilterCondDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_insertUpdateAdvancefilterCondDtl`(	
	p_listId		INT,
	p_cid 			INT,
	p_domainId 		INT,
    p_filterCond	JSON,   
    p_UIFilterCond	JSON     
)
BEGIN
		DECLARE v_errCode INT DEFAULT -1;
        DECLARE v_errMsg VARCHAR(100) DEFAULT "Failed";
        DECLARE v_conId INT;
        
        
        

		IF p_cid IS NULL OR p_cid = 0 THEN 
			
            INSERT INTO wc_contact_list_condition_dtl (domainId, filterCond, UIFilterCond, createdAt)
            VALUES(p_domainId, p_filterCond, p_UIFilterCond, current_timestamp());
            
            SET v_conId = LAST_INSERT_ID();
            
            IF EXISTS (SELECt 1 FROM wc_contact_list_master_dtl WHERE  id = p_listId AND domainId = p_domainId ) THEN
				UPDATE wc_contact_list_master_dtl
					SET conditionId =  v_conId
                 WHERE  id = p_listId AND domainId = p_domainId;
			END IF;
            
            IF v_conId IS NOT NULL THEN
			IF ROW_COUNT()> 0 THEN 
				SET v_errCode = 0;
                SET v_errMsg = "Inserted Successfully";
			END IF;
            END IF;
            
            
        ELSE 
			 IF EXISTS (SELECT 1 FROM wc_contact_list_condition_dtl WHERE cid = p_cid AND domainId = p_domainId) THEN 
             
					UPDATE wc_contact_list_condition_dtl
						SET filterCond = p_filterCond,
							UIFilterCond = p_UIFilterCond,
                            updatedAt = current_timestamp()
					WHERE cid = p_cid AND domainId = p_domainId;
                    
					IF ROW_COUNT()> 0 THEN 
						SET v_conId = p_cid;
						SET v_errCode = 1;
						SET v_errMsg = "Updated Successfully";
					END IF;
                    
                    
                    
			 END IF;
			
        END IF;
        
        SELECT v_errCode AS errCode, v_errMsg AS errMsg, v_conId AS InsertedId;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_InsertUpdateBusinessAccountInfo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_InsertUpdateBusinessAccountInfo`(
	p_domainId 				INT
	, p_mobileNumber		VARCHAR(30)
	, p_businessName		VARCHAR(100)
	, p_status				varchar(30)
	, p_isactive			TINYINT
	, p_messageLimit		INT
    , p_appId 				VARCHAR(200)
	, p_appSecret 			VARCHAR(200)
	, p_authToken 			VARCHAR(500)
    , p_whatsappId 			VARCHAR(200)
	, p_wabaId 				VARCHAR(200)
	, p_businessId			VARCHAR(200)
 )
SP: BEGIN
		
        DECLARE v_check		INT DEFAULT -1;
        DECLARE v_errMsg	varchar(50) DEFAULT 'Failed';
        DECLARE v_errCode	TINYINT DEFAULT 0;
        declare v_id int;
	
			IF (p_mobileNumber IS NULL OR trim(p_mobileNumber) = "")
            THEN 
				SELECT "Mobile Number is mandatory" AS errMsg;
            LEAVE SP;
            END IF;
            
		  select id into v_id from wc_business_configuration where domainId = p_domainId and mobileNumber= p_mobileNumber;
    
		If v_id IS NULL THEN 
			
            INSERT INTO wc_business_configuration(domainId, businessName, mobileNumber, `status`, messageLimit, 
            appId, appSecret ,authToken, phoneNumberId, wabaId , businessId )
            VALUES(p_domainId, p_businessName, p_mobileNumber, p_status,  p_messageLimit, p_appId, p_appSecret ,
            p_authToken, p_whatsappId, p_wabaId , p_businessId);
            
            set v_id = last_insert_id ();
            
            if row_count()>0 then
				set v_errMsg = 'Inserted';
                set v_errCode = 0;
            End if;
			
		ELSE 
			
				UPDATE wc_business_configuration 
                SET isactive = ifnull(p_isactive, isactive),
					`status` = ifnull(p_status,status),
					updateddate = now(),
                    businessName = ifnull(p_businessName,businessName),
                    messageLimit = ifnull(p_messageLimit,messageLimit),
                     appId = IFNULL(p_appId, appId), 
                     appSecret = IFNULL(p_appSecret, appSecret) ,
                     authToken = IFNULL(p_authToken, authToken), 
                     phoneNumberId = IFNULL(p_whatsappId, phoneNumberId), 
                     wabaId = IFNULL(p_wabaId, wabaId),
                     businessId = IFNULL(p_businessId, businessId)
                WHERE  domainId = p_domainId AND mobileNumber = p_mobileNumber;
                
                IF ROW_count() > 0 then
					set v_errMsg = 'Updated';
					set v_errCode = 1;
				END IF;
         
         END IF;
         SELECT v_errCode AS errCode, v_errMsg  AS errMsg,ifnull(v_id,0) as id;
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_InsertUpdateCampaignDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_InsertUpdateCampaignDtl`(
	   p_id INT, 						
	   p_domainId INT,
       p_campName VARCHAR(255),
       p_campType VARCHAR(255),
       p_contactList JSON,
       p_template VARCHAR(150),
       p_triggerType INT, 				
	   p_scheduleDate VARCHAR(20),
       p_templateData JSON,
       p_optimalType TINYINT, 			
       p_tags VARCHAR(100),
       p_campaignStatus varchar(50),
  	   p_campaignchatId	varchar(300)
   )
SP:BEGIN
 	  DECLARE v_templateId 			INT;
       DECLARE v_checkCamp 			TINYINT DEFAULT 0;
       DECLARE v_checkId 			TINYINT DEFAULT 0;
       DECLARE v_errCode 			INT DEFAULT -1;
       DECLARE v_errMsg 			VARCHAR(100) DEFAULT "Failed";
       DECLARE v_oldtags 			VARCHAR(200);
       DECLARE v_newInserted		INT DEFAULT -1;
       
       DECLARE EXIT HANDLER FOR SQLEXCEPTION
       BEGIN
				SELECT v_errCode AS errCode, v_errMsg AS errMsg;
                ROLLBACK;
       END;
       
      
      IF p_campaignchatId IS NULL THEN
      
 		SELECT v_errCode as errCode, v_errMsg AS errMsg;
 		LEAVE SP;
      
      END IF;
      
      
       CALL split(p_tags, ",");
      
       DROP TEMPORARY TABLE IF EXISTS tt_wc_Addtags;
       CREATE TEMPORARY TABLE tt_wc_Addtags AS
       SELECT items FROM tt_Split_temptable;
      
   	
      
       IF p_triggerType = 0 THEN
			SET p_scheduleDate = IFNULL(p_scheduleDate, now());
		END IF;
      
      START TRANSACTION;
      
       IF p_id IS NULL THEN
       
          
   		
          
   				 SELECT id INTO v_templateId FROM wc_template_master_dtl WHERE domainId = p_domainId AND templateName = p_template;  
                  
                  
   				INSERT INTO wc_campaign_master_dtl (domainId, campName, campType, contactList, template, triggerType, scheduleDate, templateId, templateData, optimalType, tags, campaignStatus, campaignchatId)
                   VALUES(p_domainId, p_campName, p_campType, p_contactList, p_template, p_triggerType, p_scheduleDate, v_templateId,  p_templateData, p_optimalType, p_tags, p_campaignStatus, p_campaignchatId);
                  
                   IF ROW_COUNT() > 0 THEN
   					SET v_newInserted = last_insert_id();
   					SET v_errCode = 0;
                       SET v_errMsg = "Inserted Successfully";
                      
                      
   				INSERT INTO wc_campaignTagDtl(domainId, Tags)
   				SELECT p_domainId, t2.items FROM tt_wc_Addtags t2
   				LEFT JOIN wc_campaignTagDtl t1 ON t1.Tags = t2.items AND t1.domainId = p_domainId 
                   WHERE t1.Tags IS NULL ;
                   
                   
                    INSERT INTO wc_TagCampMapping(TagId, Campaignid)
                    SELECT TagId, v_newInserted FROM wc_campaignTagDtl
                   WHERE domainId = p_domainId AND Tags IN (SELECT items FROM tt_wc_Addtags) ;
                    
   			END IF;
          
         
             
       ELSE
   
           SELECT 1, tags INTO v_checkId, v_oldtags FROM wc_campaign_master_dtl WHERE id = p_id AND domainId = p_domainId;
          
           IF v_checkId = 1 THEN
   
               SELECT id INTO v_templateId FROM wc_template_master_dtl WHERE domainId = p_domainId AND templateName = p_template;   
   			
   			
               
               IF p_tags IS NOT NULL THEN
                 IF EXISTS(SELECT 1 FROM wc_TagCampMapping WHERE Campaignid = p_id) THEN
                 
                 DROP TEMPORARY TABLE IF EXISTS tt_wc_droptags;
   				CREATE TEMPORARY TABLE tt_wc_droptags AS
   				SELECT TM_no FROM wc_TagCampMapping WHERE Campaignid=  p_id;
   				
                   DELETE FROM wc_TagCampMapping WHERE TM_no IN (SELECT * FROM tt_wc_droptags) ;  
   			  
                 END IF;
   			END IF;
              
   
              
               UPDATE wc_campaign_master_dtl
               SET
               campName 			= 			IFNULL(p_campName, campName),
               campType   			= 			IFNULL(p_campType, campType),
               contactList 		= 				IFNULL(p_contactList, contactList),  
               template	 		= 				IFNULL(p_template, template),
               templateId 			= 			IFNULL(v_templateId, templateId),
               triggerType 		= 				IFNULL(p_triggerType, triggerType),
               scheduleDate 		= 			IFNULL(p_scheduleDate,scheduleDate),
               templateData 		= 			IFNULL(p_templateData, templateData),
               cloneStatus 		= 				0,
               lastRecurrentDate 	= 			NULL,
   			optimalType 		= 				IFNULL(p_optimalType, optimalType),
               tags 				= 			IFNULL(p_tags, tags),
               campaignStatus		= 			IFNULL(p_campaignStatus, campaignStatus),
               campaignchatId     = 			IFNULL(p_campaignchatId, campaignchatId)
   				WHERE id = p_id  AND domainId = p_domainId ;
                   
   
   
   
               IF ROW_COUNT() > 0 THEN
   					SET v_errCode = 1;
                       SET v_errMsg = "Updated Successfully";
                       
                       INSERT INTO wc_campaignTagDtl(domainId, Tags)
   						SELECT p_domainId, t2.items FROM tt_wc_Addtags t2
   						LEFT JOIN wc_campaignTagDtl t1 ON t1.Tags = t2.items AND t1.domainId = p_domainId 
   						WHERE t1.Tags IS NULL ;
                       
                       INSERT INTO wc_TagCampMapping(TagId, Campaignid)
   						SELECT TagId, p_id FROM wc_campaignTagDtl
   						WHERE domainId = p_domainId AND Tags IN (SELECT items FROM tt_wc_Addtags) ;
                       
   			END IF;
              
   		END IF;
          
       END IF;
      
      COMMIT;
      
      SELECT v_errCode AS "errCode" , v_errMsg AS "errMsg";
   			
   END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_insertUpdateContactInformationDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_insertUpdateContactInformationDtl`(
   		    p_id 						INT,
              p_domainId 					INT,
              p_firstName					VARCHAR(100),
              p_lastName					VARCHAR(100),
              p_whatsappNumber			VARCHAR(30),
     		    p_phoneNumber				VARCHAR(30),
   		    p_email						VARCHAR(200),
              p_customerType				VARCHAR(100),
              p_tags						VARCHAR(100),
   		    p_location					VARCHAR(100),
              p_city						VARCHAR(100),
              p_address					TEXT,
              p_state						VARCHAR(100),
              p_country					VARCHAR(100),
              p_postCode					VARCHAR(50),
              p_source					VARCHAR(100),
              p_lifeCycleStage			VARCHAR(50),
  			p_deviceId					VARCHAR(150),
              p_deviceOS					VARCHAR(50),
              p_pushNotificationId		VARCHAR(3000),
              p_sip_log_id				BIGINT,
              p_extension					INT,
			  p_istempCustomer			VARCHAR(300),
              p_industryType 				VARCHAR(250),
              p_jobTitle 					VARCHAR(250),
              p_companyName 				VARCHAR(250)
          )
SP:BEGIN
          
       		   DECLARE v_check				INT DEFAULT 0;
                  DECLARE v_checkUpdate		INT DEFAULT 0;
                  DECLARE v_errCode			INT DEFAULT 0;
                  DECLARE v_insertId			INT DEFAULT 0;
                  DECLARE v_errMsg				VARCHAR(100) DEFAULT "Failed";
   
       		   SELECT id INTO v_check FROM wc_user_contact_dtl WHERE domainId = p_domainId AND email = p_email;
     
          			IF v_check = 0 THEN
      						
                              IF(p_domainId IS NULL OR p_firstName IS NULL OR p_email IS NULL or p_istempCustomer = 1 ) THEN
       				
      							SELECT v_errCode as errCode, 'Please enter the mandatory field name' as errMsg;
                       
      							LEAVE SP;
                   
      						END IF;
       
	   
                          INSERT INTO wc_user_contact_dtl (domainId ,firstName, lastName, whatsappNumber, phoneNumber, email,	customerType,	tags,	location,	city,	address,	state,	country, postCode, `source`
  														, lifeCycleStage, deviceId, deviceOS, pushNotificationId, sip_log_id, extension,istempCustomer, industryType, jobTitle, companyName)
       				   VALUES( p_domainId ,p_firstName, p_lastName, trim(p_whatsappNumber), trim(p_phoneNumber),p_email,	p_customerType,	p_tags,	p_location,	p_city,	p_address, p_state, p_country, p_postCode, p_source 
  														,IFNULL(p_lifeCycleStage, 'Lead'), p_deviceId, p_deviceOS, p_pushNotificationId, p_sip_log_id, p_extension,p_istempCustomer, p_industryType, p_jobTitle, p_companyName);
                              
         					IF ROW_COUNT() > 0 THEN
         						SET  v_errCode = 1;
         						SET  v_errMsg  = "Inserted Successfully";
         						SET	 v_insertId = last_insert_id();
         					END IF;
							
						if not exists (select 1 from wc_user_contact_dtl where domainId=p_domainId) THEN
							
							insert into user_contact_dtl(domainId) values(p_domainId);
							
							end if;
							
                          
         			ELSE
                          
          					UPDATE wc_user_contact_dtl SET 
       								firstName = IFNULL(p_firstName, firstName)
                                      , lastName= IFNULL(p_lastName, lastName)
                                      ,whatsappNumber = IFNULL(trim(p_whatsappNumber), whatsappNumber)
                                      , phoneNumber = IFNULL(trim(p_phoneNumber), phoneNumber)
                                      , customerType = IFNULL(p_customerType, customerType)
                                      , tags = IFNULL(p_tags, tags)
                                      , location = IFNULL(p_location, location)
                                      , city =	IFNULL(p_city, city)
                                      , address = IFNULL(p_address,address)
                                      , state = IFNULL(p_state, p_state)
                                      , country = IFNULL(p_country, country)
                                      , postCode = IFNULL(p_postCode, postCode)
                                      , `source` = IFNULL(p_source, `source`)
                                      , lifeCycleStage = IFNULL(p_lifeCycleStage, lifeCycleStage)
                                      , deviceId = IFNULL(p_deviceId, deviceId)
                                      , deviceOS = IFNULL(p_deviceOS, deviceOS)
                                      , pushNotificationId = IFNULL(p_pushNotificationId, pushNotificationId)
                                      , sip_log_id = IFNULL(p_sip_log_id, sip_log_id)
                                      , extension	= IFNULL(p_extension, extension)
									  , istempCustomer = IFNULL(p_istempCustomer, istempCustomer)
                                      , industryType	= IFNULL(p_industryType, industryType)
                                      , jobTitle	= IFNULL(p_jobTitle, jobTitle)
                                      , companyName	= IFNULL(p_companyName, companyName)
                                      , updatedAt	= now()
          							WHERE domainId = p_domainId AND email = p_email AND  id = v_check;
                                      
                                      IF ROW_COUNT() > 0 THEN 
          								SET  v_errCode = 2;
          								SET  v_errMsg  = "Updated Successfully";
          							END IF;
                          END IF;
          		
                  SELECT v_errCode AS errCode, v_errMsg As errMsg, v_insertId  ;
          
          END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_insertUpdateCustomerTagDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_insertUpdateCustomerTagDtl`(
	p_ctgid			INT,
    p_ctgName		VARCHAR(50),
    p_ctgDesc		VARCHAR(500),
    p_ctgStatus		TINYINT,
    p_domainId		INT
)
SP:BEGIN
		DECLARE v_errCode		INT DEFAULT -1;
        DECLARE v_errMsg		VARCHAR(50) DEFAULT "Failed";
       
        
		IF p_ctgid IS NULL THEN 
			
            IF EXISTS (SELECT 1 FROM wc_customerTag WHERE ctgName = p_ctgName AND domainId = p_domainId) THEN
				SELECT "-1" as errCode, "Name already exists" as errMsg;
				LEAVE SP;
			ELSE
				INSERT INTO wc_customerTag(ctgName, ctgDesc, ctgStatus, domainId) VALUES(p_ctgName, p_ctgDesc, p_ctgStatus, p_domainId);
				
                IF row_count() > 0 THEN
					SET v_errCode	= 1;
                    SET v_errMsg	= "Inserted Successfully";
				END IF;
            
            END IF;
		
        ELSE
					UPDATE wc_customerTag SET 
                    ctgName = IFNULL(p_ctgName, ctgName),
                    ctgDesc	= IFNULL(p_ctgDesc , ctgDesc),
                    ctgStatus = IFNULL(p_ctgStatus ,ctgStatus)
                    WHERE ctgid = p_ctgid
                    AND domainId = p_domainId
                    ;
                    
                     IF row_count() > 0 THEN
					SET v_errCode	= 2;
                    SET v_errMsg	= "Updated Successfully";
				END IF;
		END IF;
        
        SELECT v_errCode AS errCode, v_errMsg AS errMsg;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_insertUpdateCustomerTypeDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_insertUpdateCustomerTypeDtl`(
	p_ctid			INT,
    p_ctName		VARCHAR(50),
    p_ctDesc		VARCHAR(500),
    p_ctStatus		TINYINT,
    p_domainId		INT
)
SP:BEGIN
		DECLARE v_errCode		INT DEFAULT -1;
        DECLARE v_errMsg		VARCHAR(50) DEFAULT "Failed";
       
        
		IF p_ctid IS NULL THEN 
			
            IF EXISTS (SELECT 1 FROM wc_customerType WHERE ctName = p_ctName AND domainId = p_domainId) THEN
				SELECT "-1" as errCode, "Name already exists" as errMsg;
				LEAVE SP;
			ELSE
				INSERT INTO wc_customerType(ctName, ctDesc, ctStatus, domainId) VALUES(p_ctName, p_ctDesc, p_ctStatus, p_domainId);
				
                IF row_count() > 0 THEN
					SET v_errCode	= 1;
                    SET v_errMsg	= "Inserted Successfully";
				END IF;
            
            END IF;
		
        ELSE
					UPDATE wc_customerType SET 
                    ctName = IFNULL(p_ctName, ctName),
                    ctDesc	= IFNULL(p_ctDesc , ctDesc),
                    ctStatus = IFNULL(p_ctStatus ,ctStatus)
                    WHERE ctid = p_ctid AND domainId = p_domainId;
                    
                     IF row_count() > 0 THEN
					SET v_errCode	= 2;
                    SET v_errMsg	= "Updated Successfully";
				END IF;
		END IF;
        
        SELECT v_errCode AS errCode, v_errMsg AS errMsg;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_insertUpdateListDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_insertUpdateListDtl`(
	p_id		INT,
	p_domainId 	INT ,
	p_baseType 	TINYINT ,			
	p_listName 	VARCHAR(250) ,
	p_listType 	TINYINT,			
	p_conditionId INT,
	p_contactList JSON ,
	p_creatorId 	INT,
	p_createdBy 	VARCHAR(200)
)
BEGIN
	
    DECLARE v_errCode		INT DEFAULT -1;
    DECLARE v_errMsg		VARCHAR(100) DEFAULT "Failed";
    
    IF p_id IS NULL THEN
    
		INSERT INTO wc_contact_list_master_dtl (domainId, baseType, listName, listType, conditionId, contactList, creatorId,
				createdBy, createdAt)VALUES(p_domainId, p_baseType, p_listName, p_listType, p_conditionId, p_contactList, p_creatorId,
				p_createdBy, current_timestamp());
         
         IF ROW_COUNT()> 0 THEN
			SET v_errCode = 0;
			SET v_errMsg = "Inserted Successfully";
         END IF;
	
	ELSE 
		 
         IF EXISTS(SELECT 1 FROM wc_contact_list_master_dtl WHERE id = p_id AND domainId = p_domainId)
         THEN
				UPDATE wc_contact_list_master_dtl SET 
					baseType = IFNULL(p_baseType, baseType)
					,listName = IFNULL(p_listName, listName)
                    ,listType = IFNULL(p_listType , listType)
                    ,conditionId = IFNULL(p_conditionId, conditionId)
                    ,contactList = IFNULL(p_contactList, contactList)
                    ,creatorId = IFNULL(p_creatorId, creatorId)
                    ,createdBy = IFNULL(p_createdBy, createdBy)
                    ,updateAt = current_timestamp()
				WHERE domainId = p_domainId AND id = p_id;
            
            IF ROW_COUNT()> 0 THEN
				SET v_errCode = 1;
				SET v_errMsg = "Updated Successfully";
            END IF;
            
         END IF;
         
	END IF;
    
    SELECT v_errCode AS errCode , v_errMsg AS errMsg;
        
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_insertUpdateOauthTokentDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_insertUpdateOauthTokentDtl`(
	p_domainID  INT,
	p_tokenID	VARCHAR(100)
)
BEGIN
		DECLARE v_errMsg VARCHAR(50) DEFAULT "Failed";
        DECLARE v_errCode INT DEFAULT -1;
        
		IF EXISTS (SELECT 1 FROM wc_oauthDtl WHERE domainID = p_domainID)
			THEN 
					UPDATE wc_oauthDtl
						SET tokenID = p_tokenID
                        WHERE domainID = p_domainID;
                        
					IF ROW_COUNT() > 0 THEN
						SET v_errMsg = "Updated Successfully";
                        SET	v_errCode = 1;
					END IF;
						
		ELSE
			 INSERT INTO wc_oauthDtl(domainID, tokenID)
				VALUES(p_domainID, p_tokenID);
                
                IF ROW_COUNT() > 0 THEN
						SET v_errMsg = "Inserted Successfully";
                        SET	v_errCode = 0;
				END IF;
		END IF;
        
        SELECT v_errCode as errCode, v_errMsg as errMsg;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_InsertUpdateTemplateDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_InsertUpdateTemplateDtl`(
p_id				INT,
p_domainId			INT,
p_templateName		VARCHAR(150),
p_category			VARCHAR(100),
p_language			VARCHAR(100),

 p_headerType		VARCHAR(200),
p_headerValue		TEXT,
p_message			TEXT,
p_footer			TEXT,
p_buttonType		JSON,
p_status			VARCHAR(30),

p_whatsappAccount	VARCHAR(200),
p_templateId		BIGINT
)
SP:BEGIN
		DECLARE	v_checkTemp 		TINYINT  DEFAULT  0;
		DECLARE	v_errMsg			VARCHAR(100) DEFAULT "Failed";
        DECLARE	v_errCode			TINYINT DEFAULT -1;
        
		SELECT 1 INTO v_checkTemp 
		FROM wc_template_master_dtl
		WHERE domainId = p_domainId AND templateName = p_templateName
		AND whatsappAccount = p_whatsappAccount AND  category = p_category;

		sp_exit:begin
			IF (v_checkTemp != 1) THEN
                    INSERT INTO wc_template_master_dtl (domainId, templateName, whatsappAccount, category, `language`, headerType,
														headerValue, message, footer, buttonType, `status`,  templateId)
						VALUES(p_domainId, p_templateName, p_whatsappAccount, p_category, p_language,  p_headerType, p_headerValue, p_message,
								p_footer,	p_buttonType, p_status,  p_templateId);
                                
                        
					IF ROW_COUNT() >0 THEN 
						SET v_errCode = 1;
                        SET v_errMsg = "Inserted Successfully";
					END IF;
		ELSE
        
			if not exists(select 1 from wc_template_master_dtl where id = p_id limit 1) then
				SET v_errCode = 0;
				SET v_errMsg = "Record not found"; 
                leave sp_exit;
            End if;
               
				UPDATE wc_template_master_dtl SET 
                     headerType = IFNULL(p_headerType,headerType)
                    ,headerValue= IFNULL(p_headerValue, headerValue)
                    , message = IFNULL(p_message,message) 
					,footer = IFNULL(p_footer, footer)
                    , buttonType = IFNULL(p_buttonType, buttonType)
                    , `status` = IFNULL(p_status, `status`)
                    , updatedAt = now()
					WHERE domainId = p_domainId AND templateName = p_templateName
                    AND id = p_id;
                    
                    IF ROW_COUNT() > 0 THEN
						SET v_errCode = 2;
                        SET v_errMsg = "Updated Successfully";
					END IF;
        
		END IF;

        End ;
        SELECT v_errCode AS errCode, v_errMsg AS errMsg;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_insertUpdateworktualConnectorCcaas` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_insertUpdateworktualConnectorCcaas`(
	p_domainID  INT,
	p_clientId		VARCHAR(150),
    p_clientSecret	VARCHAR(150)
)
BEGIN
		DECLARE v_errMsg VARCHAR(50) DEFAULT "Failed";
        DECLARE v_errCode INT DEFAULT -1;
        
		IF EXISTS (SELECT 1 FROM wc_worktualConnectorCcaas WHERE domainId = p_domainID)
			THEN 
					UPDATE wc_worktualConnectorCcaas
						SET clientId = p_clientId,
							clientSecret = p_clientSecret
                        WHERE domainID = p_domainID;
                        
					IF ROW_COUNT() > 0 THEN
						SET v_errMsg = "Updated Successfully";
                        SET	v_errCode = 1;
					END IF;
						
		ELSE
			 INSERT INTO wc_worktualConnectorCcaas(domainID, clientId, clientSecret)
				VALUES(p_domainID, p_clientId, p_clientSecret);
                
                IF ROW_COUNT() > 0 THEN
						SET v_errMsg = "Inserted Successfully";
                        SET	v_errCode = 0;
				END IF;
		END IF;
        
        SELECT v_errCode as errCode, v_errMsg as errMsg;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_insertUpdate_whatsapp_earlier_config_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_insertUpdate_whatsapp_earlier_config_dtl`(
   p_campaingChatId			VARCHAR(300),
   p_status					VARCHAR(50),
   p_template				VARCHAR(500),
   p_domainId				INT,
   p_payloadDtl				JSON
   )
BEGIN
   			DECLARE v_errMsg	VARCHAR(50) DEFAULT 'failed';
               DECLARE v_errCode	TINYINT DEFAULT -1;
   	
   			
               IF NOT EXISTS(SELECT 1 FROM wc_whatsapp_earlier_config_dtl WHERE campaingChatId = p_campaingChatId AND domainId = p_domainId) THEN 
               
   					INSERT INTO wc_whatsapp_earlier_config_dtl
                       (domainId,  campaingChatId, `status`, template, payloadDtl)
   					VALUES(p_domainId, p_campaingChatId, p_status, p_template, p_payloadDtl);
   				
                   IF ROW_COUNT() > 0 THEN 
   					SET v_errMsg = "Inserted Successfully";
                       SET v_errCode = 0;
                   END IF;
   			
               ELSE
   					UPDATE wc_whatsapp_earlier_config_dtl
   						SET  `status` = IFNULL(p_status, `status`)
                        
   					WHERE campaingChatId = p_campaingChatId AND domainId = p_domainId;
                       
                        IF row_count() > 0 THEN 
   						SET v_errMsg = "Updated Successfully";
   						SET v_errCode = 1;
   					END IF;
   			END IF;
               
               SELECT v_errCode as errCode , v_errMsg as errMsg;
   
   END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_insert_admin_approve_or_reject_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_insert_admin_approve_or_reject_dtl`(
	p_domainId			INT,
    p_campaignChatId	INT,
    p_emailId			VARCHAR(50),
    p_action			TINYINT					-- 7 -> for Approve , 8 -> for Reject
)
BEGIN
		DECLARE v_id					INT;
        DECLARE v_currentDate			DATETIME DEFAULT now();	
        DECLARE v_errCode				TINYINT DEFAULT -1;
        DECLARE v_errMsg				VARCHAR(50) DEFAULT 'failed';
        
        
		SELECT id INTO v_id FROM wc_user_contact_dtl WHERE domainId = p_domainId AND email = p_emailId; 
        
        IF EXISTS(select 1 from ec_email_campaign_master_dtl where campaignchatid = p_campaignChatId and domainId = p_domainId and isIndivCamp = 2) THEN
        
			IF p_action = 7 then 
        
				INSERT INTO Email_tb_indiv_admin_action_dtl(domainId, campaignChatId, userID, actionId, createdOn) 
					VALUES(p_domainId, p_campaignChatId, v_id, p_action, v_currentDate);

						IF ROW_COUNT() > 0 THEN 
							SET v_errCode = 0, v_errMsg = 'Inserted Successfully';
                        END IF;
                        
			ELSEIF	p_action = 8 THEN
						
                        INSERT INTO Email_tb_indiv_admin_action_dtl(domainId, campaignChatId, userID, actionId, createdOn) 
					VALUES(p_domainId, p_campaignChatId, v_id, p_action, v_currentDate);

						IF ROW_COUNT() > 0 THEN 
							SET v_errCode = 0, v_errMsg = 'Inserted Successfully';
                        END IF;
                        
            END IF;
		END IF;
        
        SELECT v_errCode As v_errCode, v_errMsg As v_errMsg;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_insert_AI_recommendation_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`crmdev`@`%` PROCEDURE `wc_insert_AI_recommendation_dtl`(
 	p_domainId					INT,
     p_recommendation			TEXT
 )
BEGIN
 
 		DECLARE v_errCode		INT DEFAULT -1;
         DECLARE v_errMsg		VARCHAR(50) DEFAULT "Failed";
 		
         INSERT INTO wc_AI_recommmendation_dtl
         (domainId, recommendation) VALUES(p_domainId, p_recommendation);
 		
         IF ROW_COUNT() > 0 THEN 
 			SET v_errCode = 0;
             SET v_errMsg = "Inserted";
 		END IF;
         
         SELECT v_errCode as errCode, v_errMsg as errMsg;
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_insert_analytics_history_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_insert_analytics_history_dtl`(
      		p_domainId				INT
  			,p_campaignchatId		VARCHAR(300)
      		,p_fromNo				VARCHAR(30)
      		,p_toNo					VARCHAR(30)
      		,p_messageId			VARCHAR(500)
      		,p_status				VARCHAR(50)
      )
BEGIN
      		DECLARE 	v_campaignId		INT;
      		DECLARE 	v_errMsg			VARCHAR(50) DEFAULT 'failed';
    		DECLARE 	v_errCode			INT DEFAULT -1;
            DECLARE		v_userID			INT;
            DECLARE 	v_actionId			INT	DEFAULT 5;
            DECLARE 	v_currentDate		DATETIME DEFAULT NOW();
      		 
     		DECLARE EXIT HANDLER FOR SQLEXCEPTION
    		 BEGIN	
    				SELECT v_errCode as errCode, v_errMsg as errMsg;
    				ROLLBACK;
             END;
    				
                    -- =======================================================
					-- 				Extracting the User Id
                    -- =======================================================
                    
                    SELECT id INTO v_userID FROM wc_user_contact_dtl WHERE domainId = p_domainId AND whatsappNumber = p_toNo;
                    
                    -- ============================================================
		
                    IF  p_status =  "DELIVERY" THEN
    					SET v_actionId = 2;
    				ELSEIF	p_status	= "sent" THEN
    					SET v_actionId = 1;
    				ELSEIF	p_status	= "read" THEN
    					SET v_actionId = 3;
                     END IF;
                    
    				START TRANSACTION;
					
                    -- ==========================================
                    
				IF EXISTS(SELECT 1 FROM wc_campaign_master_dtl WHERE campaignchatid = p_campaignchatId AND domainId = p_domainId) THEN
               
      				INSERT INTO wc_analytics_history_dtl(domainId, campaignchatId,campaignId, fromNo, toNo, messageId, `status`, createdOn)
      					VALUES(p_domainId, p_campaignchatId,v_campaignId, p_fromNo, p_toNo, p_messageId, p_status, v_currentDate);
                        
					IF ROW_COUNT() > 0 THEN 
    								
    								SET v_errCode = 0;
    								SET v_errMsg = "Inserted Successfully";
			
					END IF;
				END IF;
                
                
                     IF (v_userID IS NOT NULL ) THEN 
    						
                            INSERT INTO whatsapp_tb_indiv_user_click_open_cnt_dtl(domainId, campaignChatId, userID, actionId, createdOn)
                            VALUES(p_domainId, p_campaignchatId, v_userID, v_actionId, v_currentDate);
      			
					END IF;
                    
                    COMMIT;
                    
                  SELECT v_errCode as errCode, v_errMsg as errMsg;
               
      END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_insert_campaign_chat_draft_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_insert_campaign_chat_draft_dtl`(
 	p_domainId			INT,
 	p_campaignChatId	VARCHAR(300),
     p_payLoad			JSON
 )
BEGIN
 			DECLARE  v_errMsg		VARCHAR(50) DEFAULT 'failed';
             DECLARE v_errCode		SMALLINT	 DEFAULT -1;
             
 
 		IF (p_domainId IS NOT NULL AND p_campaignChatId IS NOT NULL AND p_payLoad IS NOT NULL) THEN 
 				
                 INSERT INTO wc_tb_campaign_chat_draft_dtl (domainId, campaignChatId, payLoad) 
                 VALUES(p_domainId, p_campaignChatId, p_payLoad);
 				
                 IF ROW_COUNT() > 0 THEN
 					
                     SET v_errMsg = "Inserted Successfully";
 					SET v_errCode = 0;
                     
                 END IF;
                 
         END IF;
         
 		SELECT v_errCode AS errCode , v_errMsg AS errMsg;
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_insert_campaign_knowledge_base_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_insert_campaign_knowledge_base_dtl`(
    	p_domainId					INT,					
 	p_filename					VARCHAR(100),
 	p_mimetype					VARCHAR(100),
 	p_size						INT,
 	p_uploadUrl					VARCHAR(250),
 	p_companyName				VARCHAR(50),
 	p_url						VARCHAR(300),
 	p_industrial_type			VARCHAR(70),
 	p_contact_info				JSON,
 	p_product_info				JSON,
     p_pdf_info					JSON,
     p_uniqueId					VARCHAR(50)					-- new parameter added on 05-12-2025
    )
BEGIN
    			DECLARE v_errMsg		VARCHAR(50) DEFAULT 'Failed';
                DECLARE	v_errCode		TINYINT	DEFAULT '-1';
                
                DECLARE EXIT HANDLER FOR SQLEXCEPTION
                BEGIN
						ROLLBACK;
						SELECT 	v_errCode as errCode, v_errMsg as errMsg;
                END;
                
                START TRANSACTION ;
                
                IF NOT EXISTS(SELECT 1 FROM tb_campaign_knowledge_base_dtl WHERE domainId = p_domainId)
                THEN
            
    					INSERT INTO tb_campaign_knowledge_base_dtl(domainId, filename, mimetype, size, uploadUrl ,companyName, url, industrial_type, contact_info, product_info, pdf_info)
    					VALUES(p_domainId, p_filename, p_mimetype, p_size, p_uploadUrl ,p_companyName, p_url, p_industrial_type, p_contact_info, p_product_info, p_pdf_info);
    					
    					IF ROW_COUNT() > 0 THEN 
							
                            INSERT INTO wc_tb_campaign_knowledgeBase_file_details (domainId, unique_id, filename, minetype ,size, uploadUrl)
										VALUES(p_domainId, p_uniqueId, p_filename, p_mimetype, p_size, p_uploadUrl);
							
                            IF ROW_COUNT() > 0 THEN 
								COMMIT;
								SET v_errCode = 0;
								SET v_errMsg = "Inserted Successfully";
							ELSE
								ROLLBACK; 
							END IF;
                            
    					END IF;
                
                END IF;
                
                SELECT v_errCode as errCode , v_errMsg as errMsg;
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_insert_channel_wise_campaign_bell_notification` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_insert_channel_wise_campaign_bell_notification`(
   )
begin		
        DECLARE done INT DEFAULT 0;
        DECLARE p_domainId INT;
  
       DECLARE insert_cursor CURSOR FOR SELECT domainId FROM user_contact_dtl order by createdAt DESC;
    
        DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;
    
        START TRANSACTION;
    
      DROP TEMPORARY TABLE IF EXISTS tt_timeConvert;
  
      CREATE TEMPORARY TABLE tt_timeConvert (
          id INT NOT NULL AUTO_INCREMENT,
          domainId INT NOT NULL,
          channelType VARCHAR(50) NOT NULL DEFAULT '',
          title VARCHAR(100) NOT NULL DEFAULT '',
          status VARCHAR(100) NOT NULL DEFAULT '',
          message VARCHAR(255) NOT NULL,
          campaignchatId VARCHAR(300) NOT NULL,
  		`deliveryTime` datetime DEFAULT NULL,
          PRIMARY KEY (id)
      );
  	
 	OPEN insert_cursor;
 	read_loop: LOOP
 	FETCH insert_cursor INTO p_domainId;
    
            IF done = 1 THEN
                LEAVE read_loop;
            END IF;
 		   
  				 insert into tt_timeConvert (domainId,channelType,title,status,message,campaignchatId,deliveryTime) 
                   select domainId,'Whatsapp'    as channelType,campName as title,'Approved' as status , 'campaign is published' as message,campaignchatId,scheduleDate as deliveryTime		from wc_campaign_master_dtl 			where domainId = p_domainId and triggerType   = 1 and date(scheduleDate)=date(now());
  				 
  				 insert into tt_timeConvert (domainId,channelType,title,status,message,campaignchatId,deliveryTime) 
  				 select a.domainId,'Apppush'   as channelType,b.campaignName as title,'Approved' as status , 'campaign is published' as message,a.campaignchatId,a.schedulefromDate as deliveryTime from Apppush_campaign_schedule_dtl   a join AppPush_campaign_master_dtl  b on a.campaignChatId=b.campaignChatId where a.domainId = p_domainId and a.scheduleType   = 1 and date(a.schedulefromDate)	=date(now());
  				 
  				 insert into tt_timeConvert (domainId,channelType,title,status,message,campaignchatId,deliveryTime) 
  				 select a.domainId,'Webpush'   as channelType,b.campaignName as title,'Approved' as status , 'campaign is published' as message,a.campaignchatId,a.schedulefromDate as deliveryTime from webpush_campaign_schedule_dtl   a join webpush_masterCampaignDtl    b on a.campaignChatId=b.campaignChatId where a.domainId = p_domainId and a.scheduleType   = 1 and date(a.schedulefromDate)	=date(now());
  				 
  				 insert into tt_timeConvert (domainId,channelType,title,status,message,campaignchatId,deliveryTime) 
  				 select a.domainId,'Sms'       as channelType,b.name as title,'Approved' as status , 'campaign is published' as message,campaignchatId,a.schedulefromDate as deliveryTime from sc_campaign_master_schedule_dtl a join sc_campaign_master_dtl       b on a.campaignId=b.id					where a.domainId = p_domainId and b.triggerType    = 1 and date(a.schedulefromDate)	=date(now());
  				 
  				 insert into tt_timeConvert (domainId,channelType,title,status,message,campaignchatId,deliveryTime) 
  				 select a.domainId,'Email'     as channelType,b.Name as title,'Approved' as status , 'campaign is published' as message, campaignchatId,a.deliveryTime as deliveryTime from ec_campaign_contacts_dtl        a join ec_email_campaign_master_dtl b on a.campaignId=b.campaignId			where a.domainId = p_domainId and b.emailDelivery  = 2 and date(a.deliveryTime)		=date(now());
    
   
 
  
        END LOOP;
        CLOSE insert_cursor;
 
   insert into wc_overall_campaign_bell_notification(domainId ,channelType ,title ,message ,status ,campaignchatId,deliveryTime)
  SELECT DISTINCT domainId, channelType, title, message ,status ,campaignchatId,deliveryTime FROM tt_timeConvert;
  
  
  COMMIT;
 	   
   end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_insert_contact_file_history` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_insert_contact_file_history`(
 	p_domainId		INT,
     p_fileName		VARCHAR(150),
     p_filePath		VARCHAR(300),
     P_status		VARCHAR(50),
     p_records		INT
 )
BEGIN
 			DECLARE v_errMsg	VARCHAR(50) DEFAULT 'Failed';
             DECLARE v_errCode	INT DEFAULT -1;
             
 
 		 INSERT INTO tb_campaignContactFileHistory
 			(domainId, fileName, filePath, `status`, records) 
          VALUES(p_domainId, p_fileName, p_filePath, P_status,  p_records);
          
          IF ROW_COUNT() > 0 THEN
 			SET v_errCode = 0;
             SET v_errMsg  = "Inserted Successfully";
          END IF;
          
          SELECT v_errCode AS errCode, v_errMsg AS errMsg;
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_insert_customer_chat_history_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_insert_customer_chat_history_dtl`(p_domainId 		INT
 ,p_campaignChatId 	VARCHAR(50)
 ,p_ccaasMessage 	JSON
 ,p_nlpMessage 		JSON
 )
SP:BEGIN
 		DECLARE v_errMsg		VARCHAR(50) DEFAULT "Failed";
         DECLARE v_errCode		SMALLINT DEFAULT -1;
         
         
         
         IF(p_domainId IS NULL OR p_campaignChatId IS NULL ) THEN
 
 				SELECT v_errCode as errCode, v_errMsg as errMsg;
 
 				LEAVE SP;
 		ELSE
 			INSERT INTO wc_tb_campaign_customer_chat_conversation_History
 			(domainId ,campaignChatId ,ccaasMessage ,nlpMessage)
 			VALUES(p_domainId ,p_campaignChatId ,p_ccaasMessage ,p_nlpMessage);
         
 				IF ROW_COUNT() > 0 THEN 
 						SET v_errMsg = "Inserted Successfully";
 						SET v_errCode	= 0;
 				END IF;
         
         END IF;
         SELECT v_errCode as errCode, v_errMsg as errMsg;
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_insert_knowledge_base_pdf_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_insert_knowledge_base_pdf_dtl`(
	p_domainId				int
,p_uniqueId				varchar(50)
,p_companyName			varchar(50)
,p_industrialType		varchar(70)
,p_filename				varchar(100)
,p_minetype				varchar(100)
,p_uploadUrl			varchar(250)
,p_size					int
,p_pdf_info				json
)
begin
		declare v_errMsg	varchar(50) default 'Failed';
        declare v_errCode	smallint 	default  -1;
        
		declare exit handler for sqlexception
        begin
				rollback;
                select v_errCode as errCode, v_errMsg as errMsg;
        end;
        
        start transaction;
        
        INSERT INTO wc_tb_knowledge_base_pdf_dtl
        (domainId, uniqueId, companyName , industrial_type ,filename ,minetype ,uploadUrl ,size,pdf_info) 
        values(p_domainId, p_uniqueId, p_companyName, p_industrialType, p_filename, p_minetype, p_uploadUrl, p_size, p_pdf_info);
            
            IF ROW_COUNT() > 0 THEN
					
                    set v_errCode = 0;
                    set v_errMsg = "Inserted Successfully";
                    
                    COMMIT;
			ELSE
					ROLLBACK;
            
            END IF;
            
        select v_errCode as errCode, v_errMsg as v_errMsg;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_insert_knowledge_base_website_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_insert_knowledge_base_website_dtl`(
	p_domainId				int
,p_companyName			varchar(50)
,p_industrialType		varchar(70)
,p_websideUrl			varchar(250)
,p_productInfo			json
,p_contactInfo			json
)
begin
		declare v_errMsg	varchar(50) default 'Failed';
        declare v_errCode	smallint 	default  -1;
        
		declare exit handler for sqlexception
        begin
				rollback;
                select v_errCode as errCode, v_errMsg as errMsg;
        end;
        
        
        start transaction;
 
            INSERT INTO wc_tb_knowledge_base_website_dtl
            (domainId, companyName, industrialType, websideUrl, productInfo, contactInfo)
            VALUES(p_domainId, p_companyName, p_industrialType, p_websideUrl, p_productInfo, p_contactInfo);
            
            IF ROW_COUNT() > 0 THEN
					
                    set v_errCode = 0;
                    set v_errMsg = "Inserted Successfully";
                    
                    COMMIT;
			ELSE
					ROLLBACK;
		
        END IF;
        
        select v_errCode as errCode, v_errMsg as v_errMsg;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_insert_recurrence_new_schedule` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_insert_recurrence_new_schedule`(
	p_domainId						INT
	,p_reportId						INT		
	,p_recurrenceType				TINYINT		-- ================ 1 - Once, 2 - Daily, 3 - Weekly, 4 - Monthly ==================
	,p_reportResultStartDate		DATE
	,p_reportResultEndDate			DATE
	,p_timeZone						VARCHAR(50)
	,p_fileTypeIsPDF				TINYINT
	,p_fileTypeIsCSV				TINYINT
	,p_fileTypeIsXLS				TINYINT
	,p_fileTypeIsXLSL				TINYINT
	,p_emailId						VARCHAR(90)
	,p_subject						VARCHAR(500)
	,p_message						TEXT
	-- ============================================================  Once ===============================================
	,p_Date					DATE
    ,p_TimeHour				INT
	,p_TimeMinute			INT
    -- ============================================================ Daily , Weekly , Monthly =============================
	,p_repeatEvery			INT
	-- ============================================================ Monthly ==============================================
    , p_DateNo				INT
	, p_ordinalNumber		INT			-- 0 -> On, 1 -> First, 2 -> Second, 3 -> Third, 4 -> Fourth  
    , p_weekDays			INT			-- 1 -> SUNDAY, 2 -> MONDAY, 3 -> TUESDAY, 4 -> WEDNESDAY , 5 -> THURSDAY, 6 -> FRIDAY, 7 -> SATURDAY
    -- ============================================================ Weekly ==============================================
    ,p_isSunday				TINYINT 
    ,p_isMonday				TINYINT 
	,p_isTueday				TINYINT 
    ,p_isWednesday			TINYINT 
    ,p_isThursday			TINYINT 
    ,p_isFriday				TINYINT 
    ,p_isSaturday			TINYINT 
    
)
SP:BEGIN
		DECLARE v_errMsg				VARCHAR(50) 	DEFAULT "Failed";
        DECLARE v_errCode				SMALLINT 		DEFAULT -1;
        DECLARE v_InsertId				INT				;
        DECLARE v_numericTimeZone		VARCHAR(10)		DEFAULT "+00:00";
        DECLARE v_createdOn				DATETIME		DEFAULT NOW();
	
		DECLARE EXIT HANDLER FOR SQLEXCEPTION
		BEGIN
				SELECT v_errCode AS errCode, v_errMsg AS errMsg;
				ROLLBACK;
		END;
		
     IF (p_recurrenceType NOT BETWEEN 1 and 4) AND (p_reportId NOT BETWEEN 1 and 6) THEN  -- *************** Checking the input for Recurrence Type and Report Id ***********
			SELECT v_errCode AS errCode, v_errMsg AS errMsg;
            LEAVE SP;
     END IF;
     
     IF p_timeZone IS NOT NULL THEN 
		SET v_numericTimeZone = right(p_timeZone,6);   -- ************** getting the numberic time zone *************** 
     END IF;
     
		
		START TRANSACTION;
        
        INSERT INTO wc_tb_recurrence_new_schedule(
				domainId, reportId ,recurrenceType, reportResultStartDate, reportResultEndDate, timeZone,		
				 fileTypeIsPDF, fileTypeIsCSV, fileTypeIsXLS, fileTypeIsXLSL, emailId, `subject`, message,
                createdOn)
		VALUES( p_domainId, p_reportId , p_recurrenceType, p_reportResultStartDate, p_reportResultEndDate, p_timeZone 		
				, IFNULL(p_fileTypeIsPDF,0), IFNULL(p_fileTypeIsCSV,0), IFNULL(p_fileTypeIsXLS ,0), IFNULL(p_fileTypeIsXLSL,0), p_emailId
                , p_subject, p_message,v_createdOn);
	
			IF ROW_COUNT() > 0 THEN
                SET v_InsertId = LAST_INSERT_ID();			-- ********************* getting the insert id ***********************
			
               IF p_recurrenceType = 1 THEN  	-- ************************** for Once Recurssion *********************************
					call wc_tt_sp_insert_recurrence_new_schedule_once(@OutResult, v_InsertId, p_domainId, v_numericTimeZone, v_createdOn, p_TimeHour, p_TimeMinute, p_Date);
	
                    IF @OutResult = 1 THEN 
							COMMIT;
							SET v_errMsg	= "Inserted Successfully";	
							SET v_errCode	= 0;
					ELSE 
							ROLLBACK;
					END IF;
               END IF;  
			
			IF p_recurrenceType = 2 THEN   		-- ************************** for Daily Recurssion *********************************
					call wc_tt_sp_insert_recurrence_new_schedule_daily(@OutResult,v_InsertId, p_domainId, v_numericTimeZone, v_createdOn, p_TimeHour, p_TimeMinute, p_repeatEvery);
	
                    IF @OutResult = 1 THEN 
							COMMIT;
							SET v_errMsg	= "Inserted Successfully";	
							SET v_errCode	= 0;
					ELSE 
							ROLLBACK;
					END IF;
               END IF;
               
               IF p_recurrenceType = 3 THEN 		-- ************************** for Weekly Recurssion *********************************
					call wc_tt_sp_insert_recurrence_new_schedule_weekly(@OutResult, v_InsertId, p_domainId, v_numericTimeZone, v_createdOn, p_TimeHour, p_TimeMinute, p_repeatEvery, p_isSunday ,p_isMonday, p_isTueday, p_isWednesday, p_isThursday, p_isFriday, p_isSaturday);
	
                    IF @OutResult = 1 THEN 
							COMMIT;
							SET v_errMsg	= "Inserted Successfully";	
							SET v_errCode	= 0;
					ELSE 
							ROLLBACK;
					END IF;
            END IF;
               
			IF p_recurrenceType = 4 THEN 		-- ************************** for Month Recurssion *********************************
					call wc_tt_sp_insert_recurrence_new_schedule_monthly(@OutResult,v_InsertId, p_domainId, v_numericTimeZone, v_createdOn, p_TimeHour, p_TimeMinute, p_repeatEvery , p_DateNo, p_ordinalNumber, p_weekDays);
	
                    IF @OutResult = 1 THEN 
							COMMIT;
							SET v_errMsg	= "Inserted Successfully";	
							SET v_errCode	= 0;
					ELSE 
							ROLLBACK;
					END IF;
                    
               END IF;
            END IF;
            
            SELECT v_errCode AS errCode, v_errMsg AS errMsg;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_insert_revert_status_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_insert_revert_status_details`(
 			p_domainId					INT,
             p_campaignchatId			VARCHAR(300)
  )
BEGIN
 				DECLARE v_errCode	TINYINT DEFAULT -1;
                 DECLARE v_errMsg	VARCHAR(50) DEFAULT 'failed';
  
  
  
 			IF NOT EXISTS( SELECT 1 FROM wc_master_revert_status_details WHERE domainId = p_domainId AND campaignchatId = p_campaignchatId)
             THEN 
 				INSERT INTO wc_master_revert_status_details(campaignchatId, domainId, isReverted)
                 VALUES(p_campaignchatId, p_domainId, 1);
 			
 					IF ROW_COUNT() > 0 THEN 
 						
                         SET v_errCode = 0;
                         SET v_errMsg = "Inserted";
                     END IF;
             
             END IF;
                 
             SELECT v_errCode as errCode, v_errMsg as v_errMsg;
             
             
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_insert_update_AI_convertation_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_insert_update_AI_convertation_details`(
 	   p_domainId						INT,
        p_campaignchatid				VARCHAR(300),
        p_conversationName			VARCHAR(300),
        p_conversation				JSON,
        p_status						VARCHAR(50),
        p_team						SMALLINT,
		p_uploadedImages			JSON,
        p_campaignPayload			JSON
    )
BEGIN
 			DECLARE v_errMsg		VARCHAR(50) DEFAULT "Failed";
            DECLARE v_errCode		SMALLINT DEFAULT -1;
            DECLARE v_id			INT DEFAULT 0;
             
             SELECT id INTO v_id FROM wc_AI_convertation_master_details WHERE campaignchatid = p_campaignchatid AND team = p_team;
             
 		IF v_id = 0
            THEN
            IF p_conversation IS NOT NULL THEN
 				INSERT INTO wc_AI_convertation_master_details(domainId, campaignchatid, conversationName, conversation, `status`, team , uploadedImages, campaignPayload) 
 				VALUES(p_domainId, p_campaignchatid,p_conversationName,  p_conversation, IFNULL(p_status, 'DRAFT'), p_team , p_uploadedImages, p_campaignPayload);
    				
                    IF ROW_COUNT() > 0 THEN 
 						SET v_errCode = 0;
 						SET v_errMsg = "Inserted";
 					END IF;
 			END IF;
             
 		ELSE
 			IF p_conversation IS NOT NULL THEN
 				UPDATE wc_AI_convertation_master_details
 				SET conversation = JSON_ARRAY_APPEND(conversation, '$', p_conversation)
 					,`status`= IFNULL(p_status, `status`)
 					, conversationName = IFNULL(p_conversationName, conversationName)
                    , uploadedImages = IFNULL( p_uploadedImages, uploadedImages)
                    , campaignPayload = IFNULL(p_campaignPayload, campaignPayload)
 				WHERE id = v_id;
                 
                 IF ROW_COUNT() > 0 THEN 
    					SET v_errCode = 1;
                        SET v_errMsg = "Updated Successfully";
    				END IF;
 			
             ELSE
 				
                 UPDATE wc_AI_convertation_master_details
 				SET `status`= IFNULL(p_status, `status`)
 					, conversationName = IFNULL(p_conversationName, conversationName)
                    , uploadedImages = IFNULL( p_uploadedImages, uploadedImages)
                    ,campaignPayload = IFNULL(p_campaignPayload, campaignPayload)
 				WHERE id = v_id;
    
 				IF ROW_COUNT() > 0 THEN 
    					SET v_errCode = 1;
                        SET v_errMsg = "Updated Successfully";
    				END IF;
    		END IF;
      END IF;   
         SELECT v_errCode AS  errCode, v_errMsg AS errMsg;
    
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_insert_update_campaign_bell_notification` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_insert_update_campaign_bell_notification`(
  	p_id						INT,
   	p_domainId					INT,
      p_channelType				VARCHAR(50),
  	p_title						VARCHAR(500),
   	p_message					TEXT,
      p_isRead					TINYINT,
      p_status					VARCHAR(50)
   )
BEGIN
   		DECLARE v_errCode	INT DEFAULT -1;
  		DECLARE v_errMsg	VARCHAR(50) DEFAULT "Failed";
           
           
         IF p_id IS NULL THEN   
         
           INSERT INTO wc_overall_campaign_bell_notification
           (domainId, title, message, channelType, isRead, `status`)VALUES(p_domainId, p_title, p_message, p_channelType, IFNULL(p_isRead, 0), p_status);
           
  			 IF ROW_COUNT() > 0 THEN
  
  				SET v_errCode = 0;
  				 SET v_errMsg = "Inserted Successfully";
  			 
  			 END IF;
               
  		ELSE
          
  			UPDATE wc_overall_campaign_bell_notification
  				SET isRead = p_isRead
                  WHERE id = p_id and domainId = p_domainId;
  			
  				 IF ROW_COUNT() > 0 THEN
  					SET v_errCode = 0;
  					SET v_errMsg = "Updated Successfully";
  				 END IF;
           
           END IF;
           
           SELECT v_errCode as errCode, v_errMsg as errMsg;
   
   END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_insert_update_template_chat_memory` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_insert_update_template_chat_memory`(
         p_domainId				INT ,
         p_campaignChatId  		VARCHAR(300),
         p_templateId			VARCHAR(300),
         p_channel				VARCHAR(50),
         p_conversation			JSON,
         p_template				TEXT,
         p_team					INT
 )
BEGIN
 		DECLARE v_errMsg	VARCHAR(50) DEFAULT "failed";
         DECLARE v_errCode	TINYINT 	DEFAULT -1;
		 DECLARE v_id 		INT 		default 0;
		
			SELECT id INTO v_id FROM wc_tb_template_chat_memory WHERE templateId = p_templateId and team = p_team  ;
 
 			IF v_id = 0  THEN 
 					
                     INSERT INTO wc_tb_template_chat_memory(domainId, campaignChatId, templateId, `channel`, conversation,  template, team)
                     VALUES(p_domainId, p_campaignChatId, p_templateId, p_channel, p_conversation,  p_template, p_team);
                     
                     IF ROW_COUNT() > 0 THEN 
 						SET v_errCode = 0;
                         SET v_errMsg = "Inserted Successfully";
                     END IF;
 				
             ELSE
 					UPDATE wc_tb_template_chat_memory
 							set domainId = IFNULL(p_domainId, domainId), 
 								campaignChatId = IFNULL(p_campaignChatId, campaignChatId),
                                 templateId = IFNULL(p_templateId, templateId), 
                                 `channel` = IFNULL(p_channel,`channel`), 
                                 conversation= JSON_ARRAY_APPEND(conversation, '$', p_conversation),  
                                 template = IFNULL(p_template, template)
 					WHERE  id = v_id  ;
                     
                      IF ROW_COUNT() > 0 THEN 
 						SET v_errCode = 0;
                         SET v_errMsg = "Updated Successfully";
                     END IF;
                     
                     
             END IF;
             
 				SELECT v_errCode AS errCode, v_errMsg AS errMsg;
 
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_nlp_BA_historyemail` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_nlp_BA_historyemail`(
 		p_domainId			int
 		,p_campaignId	int
 ,p_campaignChatId	varchar(300)
 ,p_campaignType	varchar(20)
 ,p_totalOpenRate	int
 ,p_totalClickRate	int
 ,p_uniqueOpenRate	int
 ,p_uniqueClickRate	int
 ,p_createdAt	datetime
 
 
 
 )
BEGIN
 			DECLARE v_errMsg 	VARCHAR(50) DEFAULT 'failed';	
 			DECLARE v_errCode	TINYINT	DEFAULT -1;
 
 				INSERT INTO ec_campaign_HistoryDtl(
                 domainId ,campaignId	,campaignChatId	,campaignType	,totalOpenRate	,totalClickRate	,uniqueOpenRate	
 				,uniqueClickRate,createdAt)
 				VALUES(
 							p_domainId ,p_campaignId,p_campaignChatId ,p_campaignType ,p_totalOpenRate ,p_totalClickRate	
 							,p_uniqueOpenRate ,p_uniqueClickRate ,p_createdAt	
                 );
 				
                 
                 IF ROW_COUNT() > 0 THEN 
                 
 					set v_errMsg = "Inserted";
                     set v_errCode = 0;
                 
                 END IF;
				
                SELECT v_errCode, v_errMsg;
 			
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_nlp_BA_insert_click_rate_history` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_nlp_BA_insert_click_rate_history`(
		p_domainId					int
		,p_campaignId				int
		,p_emailId					int
		,p_uniqueClickA				int
		,p_uniqueClickB				int
		,p_CreatedOn				datetime

)
BEGIN
			DECLARE v_errMsg 	VARCHAR(50) DEFAULT 'failed';	
			DECLARE v_errCode	TINYINT	DEFAULT -1;

				INSERT INTO ec_campaign_clickRate_history_dtl(
                domainId ,campaignId ,emailId ,uniqueClickA	,uniqueClickB ,CreatedOn)
				VALUES(p_domainId ,p_campaignId	,p_emailId	,p_uniqueClickA	 ,p_uniqueClickB ,p_CreatedOn);
				
                
                IF ROW_COUNT() > 0 THEN 
                
					set v_errMsg = "Inserted";
                    set v_errCode = 0;
                
                END IF;
                
			
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_nlp_BA_overallopenrate` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_nlp_BA_overallopenrate`(
 		p_domainId				int
 ,p_campaignId					int
 ,p_campaignType					varchar(20)
 ,p_openRateCount				int
 ,p_emailId						varchar(500)
 ,p_uniqueOpenA					int
 ,p_uniqueOpenB					int
 ,p_ratedOn						date
 ,p_createdAt					datetime
 
 )
BEGIN
 			DECLARE v_errMsg 	VARCHAR(50) DEFAULT 'failed';	
 			DECLARE v_errCode	TINYINT	DEFAULT -1;
 
 				INSERT INTO ec_OverallOpenRateDtl(
                 domainId		
 				,campaignId	
 				,campaignType	
 				,openRateCount	
 				,emailId			
 				,uniqueOpenA		
 				,uniqueOpenB		
 				,ratedOn			
 				,createdAt		
              )
 				VALUES(
 							p_domainId		
 							,p_campaignId	
 							,p_campaignType	
 							,p_openRateCount	
 							,p_emailId			
 							,p_uniqueOpenA		
 							,p_uniqueOpenB		
 							,p_ratedOn			
 							,p_createdAt
                 );
 				
                 
                 IF ROW_COUNT() > 0 THEN 
                 
 					set v_errMsg = "Inserted";
                     set v_errCode = 0;
                 
                 END IF;
                 
 			SELECT v_errCode, v_errMsg;
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_nlp_BA_syntheticemailcampaign` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_nlp_BA_syntheticemailcampaign`(
		p_campaignId	int
,p_campaignchatid	varchar(300)
,p_createdate	datetime
,p_domainId	int
,p_Name	text
,p_Goal	text
,p_Type	varchar(100)
,p_TargetAud	varchar(100)
,p_Objective	text
,p_AB_testing	tinyint
,p_AItemplateA	json
,p_AItemplateB	json
,p_contactslist	json
,p_emailDelivery	int
,p_emailDeliveryAt	date
,p_emailDeliveryStarttime	date
,p_emailDeliveryEndtime	date
,p_createdBy	varchar(100)
,p_status	varchar(50)


)
BEGIN
			DECLARE v_errMsg 	VARCHAR(50) DEFAULT 'failed';	
			DECLARE v_errCode	TINYINT	DEFAULT -1;

				INSERT INTO ec_email_campaign_master_dtl(
                campaignId	
				,campaignchatid	
				,createdate	
				,domainId	
				,`Name`	
				,Goal	
				,`Type`
				,TargetAud	
				,Objective	
				,AB_testing	
				,AItemplateA	
				,AItemplateB	
				,contactslist	
				,emailDelivery	
				,emailDeliveryAt	
				,emailDeliveryStarttime	
				,emailDeliveryEndtime	
				,createdBy	
				,`status`	
             )
				VALUES(
							p_campaignId	
							,p_campaignchatid	
							,p_createdate	
							,p_domainId	
							,p_Name	
							,p_Goal	
							,p_Type
							,p_TargetAud	
							,p_Objective	
							,p_AB_testing	
							,p_AItemplateA	
							,p_AItemplateB	
							,p_contactslist	
							,p_emailDelivery	
							,p_emailDeliveryAt	
							,p_emailDeliveryStarttime	
							,p_emailDeliveryEndtime	
							,p_createdBy	
							,p_status	
                );
				
                
                IF ROW_COUNT() > 0 THEN 
                
					set v_errMsg = "Inserted";
                    set v_errCode = 0;
                
                END IF;
                
			SELECT v_errCode , v_errMsg;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_nlp_get_live_campaign_summary` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_nlp_get_live_campaign_summary`(
	p_domainId			int		
)
BEGIN
			DECLARE v_currentDate 			DATE DEFAULT now();
            DECLARE v_Active_Campaigns		INT DEFAULT 0;
            DECLARE v_Engagement_Rate		FLOAT DEFAULT 0;	
			DECLARE v_Total_Reach			INT DEFAULT 0;
            DECLARE v_Total_Impressions		INT DEFAULT 0;
            
            SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
            
		-- ===================================================================================================================================================
		-- 																	Active_Campaigns
		-- ===================================================================================================================================================          
            
            with cte01 AS(			-- ******************************** 01. SMS ********************************
			SELECT t1.campaignchatid  AS 'CampaignChatId', t1.domainId AS 'domainId'
					FROM sc_campaign_master_dtl t1 
						JOIN sc_campaign_master_schedule_dtl t2 		ON t1.id = t2.campaignId AND t1.domainId = t2.domainId 
					WHERE t1.domainId = p_domainId 
					AND (CAST(t2.schedulefromDate AS DATE) = v_currentDate OR (v_currentDate BETWEEN CAST(t2.schedulefromDate AS DATE) AND  CAST(t2.scheduletoDate AS DATE)))
			UNION ALL			-- ******************************** 02. Whatsapp ********************************
			SELECT campaignchatid AS 'CampaignChatId',domainId AS 'domainId'
					FROM wc_campaign_master_dtl 
						WHERE domainId = p_domainId 
						AND DATE(scheduleDate) =  v_currentDate
            UNION ALL	-- ******************************** 03. Email ********************************
			SELECT campaignchatid AS 'CampaignChatId', domainId AS 'domainId'
					FROM ec_email_campaign_master_dtl 
						WHERE domainId = p_domainId 
						AND (DATE(createdate) = v_currentDate OR (v_currentDate BETWEEN  DATE(emailDeliveryStarttime) AND DATE(emailDeliveryEndtime) ))
			UNION ALL	-- ******************************** 04. AppPush ********************************
			SELECT m.campaignChatId AS 'CampaignChatId', m.domainId AS 'domainId'
					FROM AppPush_campaign_master_dtl 		m
					JOIN Apppush_campaign_schedule_dtl		s		ON m.id = s.campaignId		AND m.domainId = s.domainId
						WHERE m.domainId = p_domainId 
						AND (DATE(createdOn) =v_currentDate 
						OR CASE WHEN s.scheduleType  = 0 									THEN v_currentDate = DATE(s.schedulefromDate)
								WHEN s.scheduleType  IN(1) AND scheduletoDate IS NULL 		THEN v_currentDate = DATE(s.schedulefromDate)
								WHEN s.scheduleType  IN(1) AND scheduletoDate IS NOT NULL 	THEN  v_currentDate BETWEEN DATE(s.schedulefromDate) AND  DATE(s.scheduletoDate)
                      END)
			UNION ALL	-- ******************************** WebPush ********************************
			SELECT  m.campaignChatId AS 'CampaignChatId',m.domainId AS 'domainId' 
                 FROM webpush_masterCampaignDtl			m
                 JOIN webpush_campaign_schedule_dtl		s		ON 		m.id = s.campaignId  AND m.domainId = s.domainId
					WHERE m.domainId = p_domainId 
					AND (DATE(m.createdOn) =  v_currentDate 
					OR	CASE WHEN s.scheduleType = 0 							THEN 			DATE(s.schedulefromDate) =  v_currentDate
							 WHEN s.scheduleType IN (1) AND s.scheduletoDate IS NULL 	THEN 			DATE(s.schedulefromDate) =  v_currentDate
							 WHEN s.scheduleType IN (1) AND s.scheduletoDate IS NOT NULL THEN 		 ( v_currentDate BETWEEN DATE(s.schedulefromDate) AND DATE(s.scheduletoDate) ) 
                END))
               SELECT COUNT(DISTINCT CampaignChatId) INTO v_Active_Campaigns  FROM cte01;  
               
		-- ===================================================================================================================================================
		-- 															Engagement Rate														
        -- ===================================================================================================================================================
        DROP TEMPORARY TABLE IF EXISTS tt_All_Channel_Engagement_Rate;
        CREATE temporary table tt_All_Channel_Engagement_Rate(CampaignChatId varchar(300), domainId int, CampaignName varchar(150),`Channel` char(10), EngagementScore decimal(8,4));
        
        insert into tt_All_Channel_Engagement_Rate(CampaignChatId , domainId, CampaignName ,`Channel` , EngagementScore)
       
			 WITH cte1 AS(				 -- ********************************************** Email *************************************************
     		SELECT 	distinct t1.campaignChatId AS 'CampaignChatId', t1.domainId, t1.`Name` AS 'CampaignName', t2.userID,						
						case when t2.actionId = 3 THEN 1 else 0			 end AS 	OpenRate,
						case when t2.actionId = 4 THEN 1 else 0			 end AS 	ClickRate,
						case when t2.actionId = 1 THEN 1 else 0			 end AS 	SentRate
     			FROM ec_email_campaign_master_dtl 					t1	
				LEFT JOIN Email_tb_indiv_user_click_open_cnt_dtl			t2	
					ON t1.campaignchatid = t2.campaignChatId  AND t1.domainId = t2.domainId
					WHERE t1.campaignChatId IN(SELECT campaignchatid 
													FROM ec_email_campaign_master_dtl 
														WHERE domainId = p_domainId 
														AND (DATE(createdate) = v_currentDate 
														OR (v_currentDate BETWEEN  DATE(emailDeliveryStarttime) AND DATE(emailDeliveryEndtime) ))))
		,cte2 as(
             SELECT 	campaignChatId , domainId,  CampaignName, SUM(OpenRate) as OpenRate, SUM(SentRate) as SentRate , SUM(ClickRate) as ClickRate
             from cte1
             group by campaignChatId , domainId,  CampaignName
             )
           select campaignChatId ,  domainId,  CampaignName, 'Email' as `Channel`,
					CASE WHEN  SentRate =0 THEN 0 ELSE (IFNULL((((OpenRate * 100)/SentRate) * 0.6),0) + IFNULL((((ClickRate * 100)/ SentRate)* 0.4),0) ) 
             END as EngagementScore from cte2;
				
         insert into tt_All_Channel_Engagement_Rate(CampaignChatId , domainId, CampaignName ,`Channel` , EngagementScore)
         
        with cte01 as(			-- ********************** SMS ***********************
				select distinct t1.campaignChatId 				AS 'CampaignChatId', 
								t1.domainId						AS 'domainId',			
								t1.`Name`						AS 'CampaignName',
                                JSON_length(t1.contactDtls)		AS 'CustomerCount',
								t2.userID,	
								case when t2.actionId = 2 then 1 ELSE 0 end as deliveryCount
					from sc_campaign_master_dtl t1
						 LEFT JOIN sms_tb_indiv_user_click_open_cnt_dtl t2 ON t1.campaignchatid = t2.campaignChatId AND t1.domainId = t2.domainId
					WHERE  t1.campaignChatId  IN (
											SELECT t1.campaignchatid 					
                                            FROM sc_campaign_master_dtl t1 
						JOIN sc_campaign_master_schedule_dtl t2 		ON t1.id = t2.campaignId AND t1.domainId = t2.domainId 
					WHERE t1.domainId = p_domainId 
						AND (CAST(t2.schedulefromDate AS DATE) = v_currentDate OR (v_currentDate BETWEEN CAST(t2.schedulefromDate AS DATE) AND  CAST(t2.scheduletoDate AS DATE)))
                    )
				), cte02 as(
						select CampaignChatId,  domainId, CampaignName, CustomerCount, SUM(deliveryCount) as SentCount FROM cte01
							group by CampaignChatId,  domainId, CampaignName
				)
				select CampaignChatId,  
						domainId, 
                        CampaignName, 
                        'SMS' 		as `Channel`,
                case when CustomerCount = 0 THEN 0 ELSE  (((SentCount*100)/ CustomerCount )*0.5)+(0*0.5) END AS EngagementScore
                FROM cte02;
                
                -- ************************************* Whatsapp ***********************************
                
				insert into tt_All_Channel_Engagement_Rate(CampaignChatId , domainId, CampaignName ,`Channel` , EngagementScore)
                with cte01 as 
			(
					select 	t1.campaignchatId		AS  'CampaignChatId',
							t1.domainId				AS  'domainId',
     						t1.campName 			AS  'CampaignName',
                            t2.userID				,
     						SUM(CASE WHEN t2.actionId = 2 OR t2.actionId = 3  THEN 1 ELSE 0 END) AS TotalDelivery,
     						SUM(CASE WHEN t2.actionId = 3 THEN 1 ELSE 0 END	) AS TotalRead
     				FROM wc_campaign_master_dtl t1
                    LEFT JOIN whatsapp_tb_indiv_user_click_open_cnt_dtl t2 ON  t1.campaignchatId = t2.campaignChatId AND t1.domainId = t2.domainId
                    WHERE t1.campaignchatId IN ( 
												SELECT campaignchatid FROM wc_campaign_master_dtl 
												WHERE domainId = p_domainId AND DATE(scheduleDate) =  v_currentDate
												)
                    GROUP BY t1.campaignchatId, t1.campName,t2.userID	
				)
				SELECT
						CampaignChatId, 
                        domainId, 
                        CampaignName, 
						'Whatsapp'as `Channel`,
						CASE WHEN TotalDelivery = 0 then 0 else IFNULL(((TotalRead * 100)/TotalDelivery)*0.6,0) + IFNULL(((0 * 100)/TotalDelivery)*0.4,0)  END AS 'EngagementScore'
					FROM cte01
				;
					
                    -- ************************************* AppPush ***********************************
                    
                     insert into tt_All_Channel_Engagement_Rate(CampaignChatId , domainId, CampaignName ,`Channel` , EngagementScore)
                    with cte01 as(
				select t1.campaignChatId AS CampaignChatId, 
						t1.domainId			AS domainId, 
						t1.campaignName		as CampaignName, 
						SUM(case when t2.actionId = 2 then 1 else 0 end )as SentCount,
						SUM(case when t2.actionId = 3 then 1 else 0 end )as OpenCount
				FROM 
				AppPush_campaign_master_dtl t1
				left join AppPush_tb_indiv_user_click_open_cnt_dtl t2 ON t1.campaignChatId = t2.campaignChatId and t1.domainId = t2.domainId
				where t1.campaignChatId IN (
								SELECT m.campaignChatId 
						FROM AppPush_campaign_master_dtl 		m
							JOIN Apppush_campaign_schedule_dtl		s		ON m.id = s.campaignId		AND m.domainId = s.domainId
						WHERE m.domainId = p_domainId 
							AND (DATE(createdOn) =v_currentDate 
									OR CASE WHEN s.scheduleType  = 0 									THEN v_currentDate = DATE(s.schedulefromDate)
										WHEN s.scheduleType  IN(1) AND scheduletoDate IS NULL 		THEN v_currentDate = DATE(s.schedulefromDate)
										WHEN s.scheduleType  IN(1) AND scheduletoDate IS NOT NULL 	THEN  v_currentDate BETWEEN DATE(s.schedulefromDate) AND  DATE(s.scheduletoDate)
									END)
                )
				group by t1.campaignChatId, t1.domainId, t1.campaignName
				) 
					select CampaignChatId, 
                    domainId, 
                    CampaignName, 
                    'AppPush' as `Channel`, 
					CASE WHEN SentCount = 0 then 0 else IFNULL(((OpenCount*100)/SentCount)*1.0, 0) end as EngagementScore     
					FROM cte01;
 
                    -- ************************************* WebPush ***********************************
                    
                     insert into tt_All_Channel_Engagement_Rate(CampaignChatId , domainId, CampaignName ,`Channel` , EngagementScore)
                    with cte01 as(
				select t1.campaignChatId AS CampaignChatId, 
						t1.domainId			AS domainId, 
						t1.campaignName		as CampaignName, 
						SUM(case when t2.actionId = 2 then 1 else 0 end )as SentCount,
						SUM(case when t2.actionId = 3 then 1 else 0 end )as ClickCount
				FROM 
				webpush_masterCampaignDtl t1
				left join webPush_tb_indiv_user_click_open_cnt_dtl t2 ON t1.campaignChatId = t2.campaignChatId and t1.domainId = t2.domainId
				where t1.campaignChatId IN(
							SELECT  m.campaignChatId
						FROM webpush_masterCampaignDtl			m
						JOIN webpush_campaign_schedule_dtl		s		ON 		m.id = s.campaignId  AND m.domainId = s.domainId
					WHERE m.domainId = p_domainId 
				AND (DATE(m.createdOn) =  v_currentDate 
				OR	CASE WHEN s.scheduleType = 0 							THEN 			DATE(s.schedulefromDate) =  v_currentDate
				WHEN s.scheduleType IN (1) AND s.scheduletoDate IS NULL 	THEN 			DATE(s.schedulefromDate) =  v_currentDate
 				WHEN s.scheduleType IN (1) AND s.scheduletoDate IS NOT NULL THEN 		 ( v_currentDate BETWEEN DATE(s.schedulefromDate) AND DATE(s.scheduletoDate) ) 
                END)
                )
				group by t1.campaignChatId, t1.domainId, t1.campaignName
				) 
				select CampaignChatId, 
				domainId, 
				CampaignName, 
				'WebPush' as `Channel`, 
				CASE WHEN SentCount = 0 then 0 else IFNULL(((ClickCount*100)/SentCount)*1.0, 0) end as EngagementScore     
				FROM cte01;
                    
              select  sum(EngagementScore) /count(CampaignChatId) INTO v_Engagement_Rate FROM(      
				select CampaignChatId, domainId, CampaignName, SUM(EngagementScore) AS EngagementScore
					from tt_All_Channel_Engagement_Rate
					group by CampaignChatId, domainId, CampaignName) as subq;
                
		-- ===================================================================================================================================================
		-- 																Total Reach
		-- ===================================================================================================================================================
            
            with Total_Reach as(	-- ******************************** 01.  whatsaspp ********************************
				   SELECT COUNT(id) as Total FROM wc_analytics_history_dtl 
						WHERE domainId = p_domainId AND CAST(createdOn as date) = v_currentDate AND `status` in('read', 'sent')
				   UNION ALL    -- ******************************** 02.  AppPush ********************************
				   SELECT COUNT(id) as Total FROM AppPush_tb_openRate_history_dtl 
						WHERE domainId = p_domainId AND cast(createdOn as date) = v_currentDate AND `status` in('DELIVERY') 
                   UNION ALL -- ******************************** 03.  WebPush ********************************
                   SELECT COUNT(id) as Total FROM webPush_tb_indiv_user_click_open_cnt_dtl
						WHERE domainId =  p_domainId AND cast(createdOn as date) = v_currentDate
				   UNION ALL -- ******************************** 04.  SMS ********************************      
                   SELECT count(id) as Total FROM sc_SMS_sent_status_details
						WHERE domainId = p_domainId AND `status` = 'DELIVERED' AND CAST(createdOn as date) = v_currentDate
				   UNION ALL -- ******************************** 05. Email ********************************   
				   SELECT COUNT(id) as Total FROM Email_tb_indiv_user_click_open_cnt_dtl
						WHERE domainId = p_domainId AND actionId = 1 AND CAST(createdOn AS DATE) = v_currentDate)
                    
                    SELECT SUM(Total) INTO v_Total_Reach FROM Total_Reach;
                    
            -- ===================================================================================================================================================
																-- Total Impression
			-- ===================================================================================================================================================

						WITH cte01 AS(
						SELECT COUNT(id) as Total FROM Email_tb_indiv_user_click_open_cnt_dtl 
							WHERE domainId = p_domainId AND  actionId = 3 AND CAST(createdOn AS DATE) = v_currentDate
                        UNION ALL
						SELECT COUNT(id) as Total FROM wc_analytics_history_dtl 
							WHERE domainId = p_domainId AND CAST(createdOn as date) = v_currentDate AND `status` in('read'))
                    SELECT SUM(Total) INTO v_Total_Impressions FROM cte01;
                    
            -- ===================================================================================================================================================
            -- 															Final Result
            -- ===================================================================================================================================================

                SELECT IFNULL(v_Active_Campaigns,0) AS Active_Campaigns, IFNULL(v_Engagement_Rate,0) as Engagement_Rate, IFNULL(v_Total_Reach,0) AS Total_Reach,
                IFNULL(v_Total_Impressions, 0) AS Total_Impressions;
			
				SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_nlp_get_live_campaign_summary_tttt` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_nlp_get_live_campaign_summary_tttt`(
 	p_domainId			int		
 )
BEGIN
 			DECLARE v_currentDate 			DATE DEFAULT now();
             DECLARE v_Active_Campaigns		INT DEFAULT 0;
             DECLARE v_Engagement_Rate		FLOAT DEFAULT 0;	
 			DECLARE v_Total_Reach			INT DEFAULT 0;
             DECLARE v_Total_Impressions		INT DEFAULT 0;
             
             SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
             
 		-- ===================================================================================================================================================
 		-- 																	Active_Campaigns
 		-- ===================================================================================================================================================          
             
             with cte01 AS(			-- ******************************** 01. SMS ********************************
 			SELECT t1.campaignchatid  AS 'CampaignChatId', t1.domainId AS 'domainId'
 					FROM sc_campaign_master_dtl t1 
 						JOIN sc_campaign_master_schedule_dtl t2 		ON t1.id = t2.campaignId AND t1.domainId = t2.domainId 
 					WHERE t1.domainId = p_domainId 
 					AND (CAST(t2.schedulefromDate AS DATE) = v_currentDate OR (v_currentDate BETWEEN CAST(t2.schedulefromDate AS DATE) AND  CAST(t2.scheduletoDate AS DATE)))
 			UNION ALL			-- ******************************** 02. Whatsapp ********************************
 			SELECT campaignchatid AS 'CampaignChatId',domainId AS 'domainId'
 					FROM wc_campaign_master_dtl 
 						WHERE domainId = p_domainId 
 						AND DATE(scheduleDate) =  v_currentDate
             UNION ALL	-- ******************************** 03. Email ********************************
 			SELECT campaignchatid AS 'CampaignChatId', domainId AS 'domainId'
 					FROM ec_email_campaign_master_dtl 
 						WHERE domainId = p_domainId 
 						AND (DATE(createdate) = v_currentDate OR (v_currentDate BETWEEN  DATE(emailDeliveryStarttime) AND DATE(emailDeliveryEndtime) ))
 			UNION ALL	-- ******************************** 04. AppPush ********************************
 			SELECT m.campaignChatId AS 'CampaignChatId', m.domainId AS 'domainId'
 					FROM AppPush_campaign_master_dtl 		m
 					JOIN Apppush_campaign_schedule_dtl		s		ON m.id = s.campaignId		AND m.domainId = s.domainId
 						WHERE m.domainId = p_domainId 
 						AND (DATE(createdOn) =v_currentDate 
 						OR CASE WHEN s.scheduleType  = 0 									THEN v_currentDate = DATE(s.schedulefromDate)
 								WHEN s.scheduleType  IN(1) AND scheduletoDate IS NULL 		THEN v_currentDate = DATE(s.schedulefromDate)
 								WHEN s.scheduleType  IN(1) AND scheduletoDate IS NOT NULL 	THEN  v_currentDate BETWEEN DATE(s.schedulefromDate) AND  DATE(s.scheduletoDate)
                       END)
 			UNION ALL	-- ******************************** WebPush ********************************
 			SELECT  m.campaignChatId AS 'CampaignChatId',m.domainId AS 'domainId' 
                  FROM webpush_masterCampaignDtl			m
                  JOIN webpush_campaign_schedule_dtl		s		ON 		m.id = s.campaignId  AND m.domainId = s.domainId
 					WHERE m.domainId = p_domainId 
 					AND (DATE(m.createdOn) =  v_currentDate 
 					OR	CASE WHEN s.scheduleType = 0 							THEN 			DATE(s.schedulefromDate) =  v_currentDate
 							 WHEN s.scheduleType IN (1) AND s.scheduletoDate IS NULL 	THEN 			DATE(s.schedulefromDate) =  v_currentDate
 							 WHEN s.scheduleType IN (1) AND s.scheduletoDate IS NOT NULL THEN 		 ( v_currentDate BETWEEN DATE(s.schedulefromDate) AND DATE(s.scheduletoDate) ) 
                 END))
                SELECT COUNT(DISTINCT CampaignChatId) INTO v_Active_Campaigns  FROM cte01;  
                
 		-- ===================================================================================================================================================
 		-- 															Engagement Rate														
         -- ===================================================================================================================================================
         DROP TEMPORARY TABLE IF EXISTS tt_All_Channel_Engagement_Rate;
         CREATE temporary table tt_All_Channel_Engagement_Rate(CampaignChatId varchar(300), domainId int, CampaignName varchar(150),`Channel` char(10), EngagementScore decimal(8,4));
         
         insert into tt_All_Channel_Engagement_Rate(CampaignChatId , domainId, CampaignName ,`Channel` , EngagementScore)
        
 			 WITH cte1 AS(				 -- ********************************************** Email *************************************************
      		SELECT 	distinct t1.campaignChatId AS 'CampaignChatId', t1.domainId, t1.`Name` AS 'CampaignName', t2.userID,						
 						case when t2.actionId = 3 THEN 1 else 0			 end AS 	OpenRate,
 						case when t2.actionId = 4 THEN 1 else 0			 end AS 	ClickRate,
 						case when t2.actionId = 1 THEN 1 else 0			 end AS 	SentRate
      			FROM ec_email_campaign_master_dtl 					t1	
 				LEFT JOIN Email_tb_indiv_user_click_open_cnt_dtl			t2	
 					ON t1.campaignchatid = t2.campaignChatId  AND t1.domainId = t2.domainId
 					WHERE t1.campaignChatId IN(SELECT campaignchatid 
 													FROM ec_email_campaign_master_dtl 
 														WHERE domainId = p_domainId 
 														AND (DATE(createdate) = v_currentDate 
 														OR (v_currentDate BETWEEN  DATE(emailDeliveryStarttime) AND DATE(emailDeliveryEndtime) ))))
 		,cte2 as(
              SELECT 	campaignChatId , domainId,  CampaignName, SUM(OpenRate) as OpenRate, SUM(SentRate) as SentRate , SUM(ClickRate) as ClickRate
              from cte1
              group by campaignChatId , domainId,  CampaignName
              )
            select campaignChatId ,  domainId,  CampaignName, 'Email' as `Channel`,
 					CASE WHEN  SentRate =0 THEN 0 ELSE (IFNULL((((OpenRate * 100)/SentRate) * 0.6),0) + IFNULL((((ClickRate * 100)/ SentRate)* 0.4),0) ) 
              END as EngagementScore from cte2;
 				
          insert into tt_All_Channel_Engagement_Rate(CampaignChatId , domainId, CampaignName ,`Channel` , EngagementScore)
          
         with cte01 as(			-- ********************** SMS ***********************
 				select distinct t1.campaignChatId 				AS 'CampaignChatId', 
 								t1.domainId						AS 'domainId',			
 								t1.`Name`						AS 'CampaignName',
                                 JSON_length(t1.contactDtls)		AS 'CustomerCount',
 								t2.userID,	
 								case when t2.actionId = 2 then 1 ELSE 0 end as deliveryCount
 					from sc_campaign_master_dtl t1
 						 LEFT JOIN sms_tb_indiv_user_click_open_cnt_dtl t2 ON t1.campaignchatid = t2.campaignChatId AND t1.domainId = t2.domainId
 					WHERE  t1.campaignChatId  IN (
 											SELECT t1.campaignchatid 					
                                             FROM sc_campaign_master_dtl t1 
 						JOIN sc_campaign_master_schedule_dtl t2 		ON t1.id = t2.campaignId AND t1.domainId = t2.domainId 
 					WHERE t1.domainId = p_domainId 
 						AND (CAST(t2.schedulefromDate AS DATE) = v_currentDate OR (v_currentDate BETWEEN CAST(t2.schedulefromDate AS DATE) AND  CAST(t2.scheduletoDate AS DATE)))
                     )
 				), cte02 as(
 						select CampaignChatId,  domainId, CampaignName, CustomerCount, SUM(deliveryCount) as SentCount FROM cte01
 							group by CampaignChatId,  domainId, CampaignName
 				)
 				select CampaignChatId,  
 						domainId, 
                         CampaignName, 
                         'SMS' 		as `Channel`,
                 case when CustomerCount = 0 THEN 0 ELSE  (((SentCount*100)/ CustomerCount )*0.5)+(0*0.5) END AS EngagementScore
                 FROM cte02;
                 
                 -- ************************************* Whatsapp ***********************************
                 
 				insert into tt_All_Channel_Engagement_Rate(CampaignChatId , domainId, CampaignName ,`Channel` , EngagementScore)
                 with cte01 as 
 			(
 					select 	t1.campaignchatId		AS  'CampaignChatId',
 							t1.domainId				AS  'domainId',
      						t1.campName 			AS  'CampaignName',
                             t2.userID				,
      						SUM(CASE WHEN t2.actionId = 2 OR t2.actionId = 3  THEN 1 ELSE 0 END) AS TotalDelivery,
      						SUM(CASE WHEN t2.actionId = 3 THEN 1 ELSE 0 END	) AS TotalRead
      				FROM wc_campaign_master_dtl t1
                     LEFT JOIN whatsapp_tb_indiv_user_click_open_cnt_dtl t2 ON  t1.campaignchatId = t2.campaignChatId AND t1.domainId = t2.domainId
                     WHERE t1.campaignchatId IN ( 
 												SELECT campaignchatid FROM wc_campaign_master_dtl 
 												WHERE domainId = p_domainId AND DATE(scheduleDate) =  v_currentDate
 												)
                     GROUP BY t1.campaignchatId, t1.campName,t2.userID	
 				)
 				SELECT
 						CampaignChatId, 
                         domainId, 
                         CampaignName, 
 						'Whatsapp'as `Channel`,
 						CASE WHEN TotalDelivery = 0 then 0 else IFNULL(((TotalRead * 100)/TotalDelivery)*0.6,0) + IFNULL(((0 * 100)/TotalDelivery)*0.4,0)  END AS 'EngagementScore'
 					FROM cte01
 				;
 					
                     -- ************************************* AppPush ***********************************
                     
                      insert into tt_All_Channel_Engagement_Rate(CampaignChatId , domainId, CampaignName ,`Channel` , EngagementScore)
                     with cte01 as(
 				select t1.campaignChatId AS CampaignChatId, 
 						t1.domainId			AS domainId, 
 						t1.campaignName		as CampaignName, 
 						SUM(case when t2.actionId = 2 then 1 else 0 end )as SentCount,
 						SUM(case when t2.actionId = 3 then 1 else 0 end )as OpenCount
 				FROM 
 				AppPush_campaign_master_dtl t1
 				left join AppPush_tb_indiv_user_click_open_cnt_dtl t2 ON t1.campaignChatId = t2.campaignChatId and t1.domainId = t2.domainId
 				where t1.campaignChatId IN (
 								SELECT m.campaignChatId 
 						FROM AppPush_campaign_master_dtl 		m
 							JOIN Apppush_campaign_schedule_dtl		s		ON m.id = s.campaignId		AND m.domainId = s.domainId
 						WHERE m.domainId = p_domainId 
 							AND (DATE(createdOn) =v_currentDate 
 									OR CASE WHEN s.scheduleType  = 0 									THEN v_currentDate = DATE(s.schedulefromDate)
 										WHEN s.scheduleType  IN(1) AND scheduletoDate IS NULL 		THEN v_currentDate = DATE(s.schedulefromDate)
 										WHEN s.scheduleType  IN(1) AND scheduletoDate IS NOT NULL 	THEN  v_currentDate BETWEEN DATE(s.schedulefromDate) AND  DATE(s.scheduletoDate)
 									END)
                 )
 				group by t1.campaignChatId, t1.domainId, t1.campaignName
 				) 
 					select CampaignChatId, 
                     domainId, 
                     CampaignName, 
                     'AppPush' as `Channel`, 
 					CASE WHEN SentCount = 0 then 0 else IFNULL(((OpenCount*100)/SentCount)*1.0, 0) end as EngagementScore     
 					FROM cte01;
  
                     -- ************************************* WebPush ***********************************
                     
                      insert into tt_All_Channel_Engagement_Rate(CampaignChatId , domainId, CampaignName ,`Channel` , EngagementScore)
                     with cte01 as(
 				select t1.campaignChatId AS CampaignChatId, 
 						t1.domainId			AS domainId, 
 						t1.campaignName		as CampaignName, 
 						SUM(case when t2.actionId = 2 then 1 else 0 end )as SentCount,
 						SUM(case when t2.actionId = 3 then 1 else 0 end )as ClickCount
 				FROM 
 				webpush_masterCampaignDtl t1
 				left join webPush_tb_indiv_user_click_open_cnt_dtl t2 ON t1.campaignChatId = t2.campaignChatId and t1.domainId = t2.domainId
 				where t1.campaignChatId IN(
 							SELECT  m.campaignChatId
 						FROM webpush_masterCampaignDtl			m
 						JOIN webpush_campaign_schedule_dtl		s		ON 		m.id = s.campaignId  AND m.domainId = s.domainId
 					WHERE m.domainId = p_domainId 
 				AND (DATE(m.createdOn) =  v_currentDate 
 				OR	CASE WHEN s.scheduleType = 0 							THEN 			DATE(s.schedulefromDate) =  v_currentDate
 				WHEN s.scheduleType IN (1) AND s.scheduletoDate IS NULL 	THEN 			DATE(s.schedulefromDate) =  v_currentDate
  				WHEN s.scheduleType IN (1) AND s.scheduletoDate IS NOT NULL THEN 		 ( v_currentDate BETWEEN DATE(s.schedulefromDate) AND DATE(s.scheduletoDate) ) 
                 END)
                 )
 				group by t1.campaignChatId, t1.domainId, t1.campaignName
 				) 
 				select CampaignChatId, 
 				domainId, 
 				CampaignName, 
 				'WebPush' as `Channel`, 
 				CASE WHEN SentCount = 0 then 0 else IFNULL(((ClickCount*100)/SentCount)*1.0, 0) end as EngagementScore     
 				FROM cte01;
                     
					 
					 
               select  sum(EngagementScore) /count(CampaignChatId) INTO v_Engagement_Rate FROM(      
 				select CampaignChatId, domainId, CampaignName, SUM(EngagementScore) AS EngagementScore
 					from tt_All_Channel_Engagement_Rate
 					group by CampaignChatId, domainId, CampaignName) as subq;
                 
				 					 select *,1 from tt_All_Channel_Engagement_Rate;




 		-- ===================================================================================================================================================
 		-- 																Total Reach
 		-- ===================================================================================================================================================
             
             with Total_Reach as(	-- ******************************** 01.  whatsaspp ********************************
 				   SELECT COUNT(id) as Total FROM wc_analytics_history_dtl 
 						WHERE domainId = p_domainId AND CAST(createdOn as date) = v_currentDate AND `status` in('read', 'sent')
 				   UNION ALL    -- ******************************** 02.  AppPush ********************************
 				   SELECT COUNT(id) as Total FROM AppPush_tb_openRate_history_dtl 
 						WHERE domainId = p_domainId AND cast(createdOn as date) = v_currentDate AND `status` in('DELIVERY') 
                    UNION ALL -- ******************************** 03.  WebPush ********************************
                    SELECT COUNT(id) as Total FROM webPush_tb_indiv_user_click_open_cnt_dtl
 						WHERE domainId =  p_domainId AND cast(createdOn as date) = v_currentDate
 				   UNION ALL -- ******************************** 04.  SMS ********************************      
                    SELECT count(id) as Total FROM sc_SMS_sent_status_details
 						WHERE domainId = p_domainId AND `status` = 'DELIVERED' AND CAST(createdOn as date) = v_currentDate
 				   UNION ALL -- ******************************** 05. Email ********************************   
 				   SELECT COUNT(id) as Total FROM Email_tb_indiv_user_click_open_cnt_dtl
 						WHERE domainId = p_domainId AND actionId = 1 AND CAST(createdOn AS DATE) = v_currentDate)
                     SELECT SUM(Total) INTO v_Total_Reach FROM Total_Reach;
					 
					 
					 SELECT COUNT(id) as Total FROM wc_analytics_history_dtl 
 						WHERE domainId = p_domainId AND CAST(createdOn as date) = v_currentDate AND `status` in('read', 'sent')
 				   UNION ALL    -- ******************************** 02.  AppPush ********************************
 				   SELECT COUNT(id) as Total FROM AppPush_tb_openRate_history_dtl 
 						WHERE domainId = p_domainId AND cast(createdOn as date) = v_currentDate AND `status` in('DELIVERY') 
                    UNION ALL -- ******************************** 03.  WebPush ********************************
                    SELECT COUNT(id) as Total FROM webPush_tb_indiv_user_click_open_cnt_dtl
 						WHERE domainId =  p_domainId AND cast(createdOn as date) = v_currentDate
 				   UNION ALL -- ******************************** 04.  SMS ********************************      
                    SELECT count(id) as Total FROM sc_SMS_sent_status_details
 						WHERE domainId = p_domainId AND `status` = 'DELIVERED' AND CAST(createdOn as date) = v_currentDate
 				   UNION ALL -- ******************************** 05. Email ********************************   
 				   SELECT COUNT(id) as Total FROM Email_tb_indiv_user_click_open_cnt_dtl
 						WHERE domainId = p_domainId AND actionId = 1 AND CAST(createdOn AS DATE) = v_currentDate;



                     
             -- ===================================================================================================================================================
 																-- Total Impression
 			-- ===================================================================================================================================================
 
 						WITH cte01 AS(
 						SELECT COUNT(id) as Total FROM Email_tb_indiv_user_click_open_cnt_dtl 
 							WHERE domainId = p_domainId AND  actionId = 3 AND CAST(createdOn AS DATE) = v_currentDate
                         UNION ALL
 						SELECT COUNT(id) as Total FROM wc_analytics_history_dtl 
 							WHERE domainId = p_domainId AND CAST(createdOn as date) = v_currentDate AND `status` in('read'))
                     SELECT SUM(Total) INTO v_Total_Impressions FROM cte01;
					 
					 
					
 						SELECT COUNT(id) as Total FROM Email_tb_indiv_user_click_open_cnt_dtl 
 							WHERE domainId = p_domainId AND  actionId = 3 AND CAST(createdOn AS DATE) = v_currentDate
                         UNION ALL
 						SELECT COUNT(id) as Total FROM wc_analytics_history_dtl 
 							WHERE domainId = p_domainId AND CAST(createdOn as date) = v_currentDate AND `status` in('read');
                     
             -- ===================================================================================================================================================
             -- 															Final Result
             -- ===================================================================================================================================================
 
                 SELECT IFNULL(v_Active_Campaigns,0) AS Active_Campaigns, IFNULL(v_Engagement_Rate,0) as Engagement_Rate, IFNULL(v_Total_Reach,0) AS Total_Reach,
                 IFNULL(v_Total_Impressions, 0) AS Total_Impressions;
 			
 				SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_tt_sp_insert_recurrence_new_schedule_daily` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_tt_sp_insert_recurrence_new_schedule_daily`(	OUT OutResult			TINYINT,
    p_FK_recId				INT,
	p_domainId				INT,
	p_numbericTimeZone		VARCHAR(20),
    p_createdOn				DATETIME,
    p_TimeHour				INT,
    p_TimeMinute			INT,
    p_repeatEvery			INT
)
BEGIN
		DECLARE v_userSetTime				DATETIME;
        DECLARE v_convertToUTC				DATETIME;
        DECLARE v_convertToUTCResult		DATETIME;
        
        DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
				ROLLBACK;
                SET OutResult =0;
        END;
        
        -- ====================================
        
        SET v_userSetTime = ADDDATE(ADDDATE(CONCAT(DATE(NOW()), " 00:00:00"), INTERVAL p_TimeHour HOUR),INTERVAL p_TimeMinute MINUTE);
        
        -- =========================================
        
				IF INSTR(p_numbericTimeZone, '+00:00') = 0 THEN
					SET v_convertToUTC = CONVERT_TZ(v_userSetTime, p_numbericTimeZone, '+00:00');
				ELSE
					SET v_convertToUTC = v_userSetTime;
				END IF;
        
        
				SET v_convertToUTCResult = ADDDATE(v_convertToUTC, INTERVAL p_repeatEvery DAY);
         -- =========================================
        
        START TRANSACTION;
        
		INSERT INTO  wc_tb_recurrence_new_schedule_Daily (FK_recId, domainId, numbericTimeZone, repeatEvery,  frequenceHour, frequenceMinute, userSysTime, convertToUTC, UTC_startTime, createdOn)
									VALUES(p_FK_recId, p_domainId, p_numbericTimeZone, p_repeatEvery, p_TimeHour, p_TimeMinute, v_userSetTime, v_convertToUTC, v_convertToUTCResult, p_createdOn);
                                    
		IF ROW_COUNT() > 0 THEN 
			COMMIT;
			SET OutResult = 1;
		ELSE
			SET OutResult = 0;
		END IF;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_tt_sp_insert_recurrence_new_schedule_monthly` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_tt_sp_insert_recurrence_new_schedule_monthly`(	
	OUT OutResult			TINYINT,
    p_FK_recId				INT,
	p_domainId				INT,
	p_numbericTimeZone		VARCHAR(20),
    p_createdOn				DATETIME,
    p_TimeHour				INT,
    p_TimeMinute			INT,
    p_repeatEvery			INT,
    p_DateNo				INT,
    p_ordinalNumber			INT, 
    p_weekDays				INT
)
BEGIN
		DECLARE v_userSetTime		DATETIME;
        DECLARE v_convertToUTC		DATETIME;
        
		DECLARE v_dateMonth			INT;
		DECLARE v_newDate			DATETIME;
        DECLARE v_newConvertToUTC	DATETIME;
        
        DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
				ROLLBACK;
                SET OutResult =0;
        END;
        
        -- ====================================
        
        SET v_userSetTime = ADDDATE(ADDDATE(CONCAT(DATE(NOW()), " 00:00:00"), INTERVAL p_TimeHour HOUR),INTERVAL p_TimeMinute MINUTE);
        
        -- =========================================		converting the different timezone to UTC
        
				IF INSTR(p_numbericTimeZone, '+00:00') = 0 THEN
					SET v_convertToUTC = CONVERT_TZ(v_userSetTime, p_numbericTimeZone, '+00:00');
				ELSE
					SET v_convertToUTC = v_userSetTime;
				END IF;

         -- ========================================		
        
		IF IFNULL(p_ordinalNumber, 0) != 0 THEN 
							
				SET v_newConvertToUTC = adddate(v_convertToUTC, interval p_repeatEvery MONTH);
                SET v_dateMonth = MONTH(v_newConvertToUTC);
				SET v_newDate = date_format(v_newConvertToUTC, '%Y-%m-01 %h:%i:%s');
                
				WITH RECURSIVE cte_01 AS (
					SELECT CAST(v_newDate AS DATETIME) AS dateno , DAYOFWEEK(CAST(v_newDate AS DATETIME)) AS dateweek
						UNION ALL
					SELECT ADDDATE(dateno, INTERVAL 1 DAY) AS dateno ,  DAYOFWEEK(ADDDATE(dateno, INTERVAL 1 DAY)) FROM cte_01 
					WHERE MONTH(dateno) = v_dateMonth
				),
				cte_02 as(
					SELECT ROW_NUMBER() OVER() AS rn, t1.* FROM cte_01 t1 WHERE dateweek = p_weekDays AND MONTH(dateno) = v_dateMonth
				)
					SELECT dateno INTO v_newConvertToUTC FROM cte_02 WHERE rn = p_ordinalNumber;
                
		ELSE
	
				IF CAST(DATE_FORMAT(ADDDATE(v_convertToUTC, INTERVAL p_repeatEvery MONTH), CONCAT('%Y-%m-',p_DateNo,' %h:%i:%s')) AS DATETIME) IS NOT NULL THEN 
                
						SET v_newConvertToUTC = CAST(DATE_FORMAT(ADDDATE(v_convertToUTC, INTERVAL p_repeatEvery MONTH), CONCAT('%Y-%m-',p_DateNo,' %h:%i:%s')) AS DATETIME);
                ELSE    
						SET  v_newConvertToUTC = cast(DATE_FORMAT(last_day(ADDDATE(v_convertToUTC, INTERVAL p_repeatEvery MONTH)), CONCAT('%Y-%m-%d ',p_TimeHour,':',p_TimeMinute,':00')) as datetime);
                END IF;
                 
        END IF;
	
        -- ==========================================
        
        START TRANSACTION;
        
		INSERT INTO  wc_tb_recurrence_new_schedule_Monthly (FK_recId,  domainId,  numbericTimeZone,  repeatEvery, DateNo,   frequenceHour, frequenceMinute, userSetTime, convertToUTC, UTC_startTime, createdOn, ordinalNumber, weekDays)
													VALUES(p_FK_recId, p_domainId,  p_numbericTimeZone, p_repeatEvery, p_DateNo ,p_TimeHour, p_TimeMinute, v_userSetTime, v_convertToUTC, v_newConvertToUTC, p_createdOn, p_ordinalNumber, p_weekDays);
                                    
		IF ROW_COUNT() > 0 THEN 
			COMMIT;
			SET OutResult = 1;
		ELSE
			SET OutResult = 0;
		END IF;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_tt_sp_insert_recurrence_new_schedule_once` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_tt_sp_insert_recurrence_new_schedule_once`(	OUT OutResult			TINYINT,
    p_FK_recId				INT,
	p_domainId				INT,
	p_numbericTimeZone		VARCHAR(20),
    p_createdOn				DATETIME,
    p_TimeHour				INT,
    p_TimeMinute			INT,
    p_Date					DATE
)
BEGIN
		DECLARE v_userSetTime		DATETIME;
        DECLARE v_convertToUTC		DATETIME;
        
        DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
				ROLLBACK;
                SET OutResult =0;
        END;
        
        -- ====================================
        
        SET v_userSetTime = ADDDATE(ADDDATE(CONCAT(p_Date, " 00:00:00"), INTERVAL p_TimeHour HOUR),INTERVAL p_TimeMinute MINUTE);
        
        -- =========================================
        
				IF INSTR(p_numbericTimeZone, '+00:00') = 0 THEN
					SET v_convertToUTC = CONVERT_TZ(v_userSetTime, p_numbericTimeZone, '+00:00');
				ELSE
					SET v_convertToUTC = v_userSetTime;
				END IF;
        
         -- =========================================
        
        START TRANSACTION;
        
		INSERT INTO  wc_tb_recurrence_new_schedule_Once(FK_recId, domainId, numbericTimeZone, TimeHour, TimeMinute, userSetTime, convertToUTC, UTC_startTime, createdOn)
									VALUES(p_FK_recId, p_domainId, p_numbericTimeZone, p_TimeHour, p_TimeMinute, v_userSetTime, v_convertToUTC, v_convertToUTC, p_createdOn);
                                    
		IF ROW_COUNT() > 0 THEN 
			COMMIT;
			SET OutResult = 1;
		ELSE
			SET OutResult = 0;
		END IF;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_tt_sp_insert_recurrence_new_schedule_weekly` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_tt_sp_insert_recurrence_new_schedule_weekly`(	
	OUT OutResult			TINYINT, 
    p_FK_recId				INT,
	p_domainId				INT,
	p_numbericTimeZone		VARCHAR(20),
    p_createdOn				DATETIME,
    p_TimeHour				INT,
    p_TimeMinute			INT,
    p_repeatEvery			INT,
    -- =======================================
    p_isSunday				TINYINT, 
    p_isMonday				TINYINT, 
    p_isTueday				TINYINT, 
    p_isWednesday			TINYINT, 
    p_isThursday			TINYINT, 
    p_isFriday				TINYINT, 
    p_isSaturday			TINYINT 
)
BEGIN
		DECLARE v_userSetTime		DATETIME;
        DECLARE v_convertToUTC		DATETIME;
        DECLARE v_maxWeek			TINYINT;
        DECLARE v_minWeek			TINYINT;
        DECLARE v_upcomingWeek		TINYINT;
        DECLARE v_Weekday			TINYINT;
        DECLARE v_startDay			DATETIME;
        
        DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
				ROLLBACK;
                SET OutResult =0;
        END;
        -- ===================================================================================================
			SET v_maxWeek =  GREATEST(IFNULL(p_isSunday,0), IFNULL(p_isMonday,0),  IFNULL(p_isTueday,0), IFNULL(p_isWednesday,0), IFNULL(p_isThursday,0), IFNULL(p_isFriday,0), IFNULL(p_isSaturday,0));
            
            SET v_minWeek =  LEAST(IFNULL(p_isSunday,100), IFNULL(p_isMonday,100),  IFNULL(p_isTueday,100), IFNULL(p_isWednesday,100), IFNULL(p_isThursday,100), IFNULL(p_isFriday,100), IFNULL(p_isSaturday,100));
        -- ===================================================================================================
        
        SET v_userSetTime = ADDDATE(ADDDATE(ADDDATE(CONCAT(DATE(NOW()), " 00:00:00"), INTERVAL p_TimeHour HOUR),INTERVAL p_TimeMinute MINUTE), INTERVAL p_repeatEvery WEEK) ;
        
        SET v_Weekday = WEEK(v_userSetTime);
        
        SET v_startDay =  DATE_SUB(v_userSetTime, INTERVAL (DAYOFWEEK(v_userSetTime) - 1) DAY);
        
        -- select v_userSetTime, v_Weekday, v_startDay;
        -- ===========================================	
        
			WITH RECURSIVE cte01 as
			(
					SELECT	(v_startDay) as dateOfWeek, DAYOFWEEK(v_startDay) as WeekDtl
					UNION ALL
					SELECT  ADDDATE(dateOfWeek, INTERVAL 1 DAY), DAYOFWEEK(ADDDATE(dateOfWeek, INTERVAL 1 DAY)) from cte01
						WHERE  week(dateOfWeek) = v_Weekday 
			)
				SELECT dateOfWeek INTO v_userSetTime
				FROM cte01 where week(dateOfWeek) = v_Weekday 
                and WeekDtl in (p_isSunday, p_isMonday,  p_isTueday, p_isWednesday, p_isThursday, p_isFriday, p_isSaturday) limit 1;
			
        -- =========================================
        
				IF INSTR(p_numbericTimeZone, '+00:00') = 0 THEN
					SET v_convertToUTC = CONVERT_TZ(v_userSetTime, p_numbericTimeZone, '+00:00');
				ELSE
					SET v_convertToUTC = v_userSetTime;
				END IF;
	
		-- ===========================================
        
        START TRANSACTION;
        
		INSERT INTO wc_tb_recurrence_new_schedule_Weekly (FK_recId,  domainId,  numbericTimeZone,  repeatEvery, isSunday, isMonday, isTueday, isWednesday, isThursday, isFriday, isSaturday ,   
        frequenceHour, frequenceMinute, userSysTime, convertToUTC, UTC_startTime, createdOn, maxWeek, minWeek)
		VALUES(p_FK_recId, p_domainId,  p_numbericTimeZone, p_repeatEvery, p_isSunday, p_isMonday, p_isTueday, p_isWednesday, p_isThursday, p_isFriday, p_isSaturday , 
        p_TimeHour, p_TimeMinute, v_userSetTime, v_convertToUTC, v_convertToUTC, p_createdOn, v_maxWeek , v_minWeek);
                                    
		IF ROW_COUNT() > 0 THEN 
			COMMIT;
			SET OutResult = 1;
		ELSE
			SET OutResult = 0;
		END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_tt_sp_update_recurrence_new_schedule_daily` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_tt_sp_update_recurrence_new_schedule_daily`(	
	OUT OutResult			TINYINT,
    p_FK_recId				INT,
	p_domainId				INT,
	p_numbericTimeZone		VARCHAR(20),
    p_TimeHour				INT,
    p_TimeMinute			INT,
    p_repeatEvery			INT
)
BEGIN
		DECLARE v_userSetTime				DATETIME;
        DECLARE v_convertToUTC				DATETIME;
        DECLARE v_convertToUTCResult		DATETIME;
        
        DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
				ROLLBACK;
                SET OutResult =0;
        END;
        
        -- ====================================
        
        SET v_userSetTime = ADDDATE(ADDDATE(CONCAT(DATE(NOW()), " 00:00:00"), INTERVAL p_TimeHour HOUR),INTERVAL p_TimeMinute MINUTE);
        
        -- =========================================
        
				IF INSTR(p_numbericTimeZone, '+00:00') = 0 THEN
					SET v_convertToUTC = CONVERT_TZ(v_userSetTime, p_numbericTimeZone, '+00:00');
				ELSE
					SET v_convertToUTC = v_userSetTime;
				END IF;
        
        
				SET v_convertToUTCResult = ADDDATE(v_convertToUTC, INTERVAL p_repeatEvery DAY);
         -- =========================================
        
        START TRANSACTION;
             
           UPDATE	wc_tb_recurrence_new_schedule_Daily
				SET numbericTimeZone 			= p_numbericTimeZone,
					repeatEvery 				= p_repeatEvery,
                    frequenceHour 				= p_TimeHour,
                    frequenceMinute 			= p_TimeMinute,
                    userSysTime					= v_userSetTime,
                    convertToUTC				= v_convertToUTC,
                    UTC_startTime				= v_convertToUTCResult
				WHERE 	domainId = p_domainId	AND FK_recId = p_FK_recId;
             
		IF ROW_COUNT() > 0 THEN 
			COMMIT;
			SET OutResult = 1;
		ELSE
			SET OutResult = 0;
		END IF;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_tt_sp_update_recurrence_new_schedule_monthly` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_tt_sp_update_recurrence_new_schedule_monthly`(	
	OUT OutResult			TINYINT,
    p_FK_recId				INT,
	p_domainId				INT,
	p_numbericTimeZone		VARCHAR(20),
    p_TimeHour				INT,
    p_TimeMinute			INT,
    p_repeatEvery			INT,
    p_DateNo				INT,
    p_ordinalNumber			INT, 
    p_weekDays				INT
)
BEGIN
		DECLARE v_userSetTime		DATETIME;
        DECLARE v_convertToUTC		DATETIME;
        
		DECLARE v_dateMonth			INT;
		DECLARE v_newDate			DATETIME;
        DECLARE v_newConvertToUTC	DATETIME;
        
        DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
				ROLLBACK;
                SET OutResult =0;
        END;
        
        -- ====================================
        
        SET v_userSetTime = ADDDATE(ADDDATE(CONCAT(DATE(NOW()), " 00:00:00"), INTERVAL p_TimeHour HOUR),INTERVAL p_TimeMinute MINUTE);
        
        -- =========================================		converting the different timezone to UTC
        
				IF INSTR(p_numbericTimeZone, '+00:00') = 0 THEN
					SET v_convertToUTC = CONVERT_TZ(v_userSetTime, p_numbericTimeZone, '+00:00');
				ELSE
					SET v_convertToUTC = v_userSetTime;
				END IF;

         -- ========================================		
        
		IF IFNULL(p_ordinalNumber, 0) != 0 THEN 
							
				SET v_newConvertToUTC = adddate(v_convertToUTC, interval p_repeatEvery MONTH);
                SET v_dateMonth = MONTH(v_newConvertToUTC);
				SET v_newDate = date_format(v_newConvertToUTC, '%Y-%m-01 %h:%i:%s');
                
				WITH RECURSIVE cte_01 AS (
					SELECT CAST(v_newDate AS DATETIME) AS dateno , DAYOFWEEK(CAST(v_newDate AS DATETIME)) AS dateweek
						UNION ALL
					SELECT ADDDATE(dateno, INTERVAL 1 DAY) AS dateno ,  DAYOFWEEK(ADDDATE(dateno, INTERVAL 1 DAY)) FROM cte_01 
					WHERE MONTH(dateno) = v_dateMonth
				),
				cte_02 as(
					SELECT ROW_NUMBER() OVER() AS rn, t1.* FROM cte_01 t1 WHERE dateweek = p_weekDays AND MONTH(dateno) = v_dateMonth
				)
					SELECT dateno INTO v_newConvertToUTC FROM cte_02 WHERE rn = p_ordinalNumber;
                
		ELSE
	
				IF CAST(DATE_FORMAT(ADDDATE(v_convertToUTC, INTERVAL p_repeatEvery MONTH), CONCAT('%Y-%m-',p_DateNo,' %h:%i:%s')) AS DATETIME) IS NOT NULL THEN 
                
						SET v_newConvertToUTC = CAST(DATE_FORMAT(ADDDATE(v_convertToUTC, INTERVAL p_repeatEvery MONTH), CONCAT('%Y-%m-',p_DateNo,' %h:%i:%s')) AS DATETIME);
                ELSE    
						SET  v_newConvertToUTC = cast(DATE_FORMAT(last_day(ADDDATE(v_convertToUTC, INTERVAL p_repeatEvery MONTH)), CONCAT('%Y-%m-%d ',p_TimeHour,':',p_TimeMinute,':00')) as datetime);
                END IF;
                 
        END IF;
	
        -- ==========================================
        
        START TRANSACTION;
        
        
        UPDATE wc_tb_recurrence_new_schedule_Monthly
				SET numbericTimeZone		= p_numbericTimeZone,
					repeatEvery				= p_repeatEvery,
                    DateNo					= p_DateNo,
                    frequenceHour			= p_TimeHour,
                    frequenceMinute			= p_TimeMinute,
                    userSetTime				= v_userSetTime,
                    convertToUTC			= v_convertToUTC,
                    UTC_startTime			= v_newConvertToUTC,
                    ordinalNumber			= p_ordinalNumber,
                    weekDays				= p_weekDays
		WHERE FK_recId = p_FK_recId and domainId = p_domainId;
        
        
		IF ROW_COUNT() > 0 THEN 
			COMMIT;
			SET OutResult = 1;
		ELSE
			SET OutResult = 0;
		END IF;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_tt_sp_update_recurrence_new_schedule_once` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_tt_sp_update_recurrence_new_schedule_once`(	
	OUT OutResult			TINYINT,
    p_FK_recId				INT,
	p_domainId				INT,
	p_numbericTimeZone		VARCHAR(20),
    p_TimeHour				INT,
    p_TimeMinute			INT,
    p_Date					DATE
)
BEGIN
		DECLARE v_userSetTime		DATETIME;
        DECLARE v_convertToUTC		DATETIME;
        
        DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
				ROLLBACK;
                SET OutResult =0;
        END;
        
        -- ====================================
        
        SET v_userSetTime = ADDDATE(ADDDATE(CONCAT(p_Date, " 00:00:00"), INTERVAL p_TimeHour HOUR),INTERVAL p_TimeMinute MINUTE);
        
        -- =========================================
        
				IF INSTR(p_numbericTimeZone, '+00:00') = 0 THEN
					SET v_convertToUTC = CONVERT_TZ(v_userSetTime, p_numbericTimeZone, '+00:00');
				ELSE
					SET v_convertToUTC = v_userSetTime;
				END IF;
        
         -- =========================================
        
        START TRANSACTION;
        
			UPDATE wc_tb_recurrence_new_schedule_Once
				SET numbericTimeZone 		= p_numbericTimeZone,
					TimeHour 				= p_TimeHour,
                    TimeMinute	 			= p_TimeMinute,
                    userSetTime				= v_userSetTime,
                    convertToUTC			= v_convertToUTC,
                    UTC_startTime			= v_convertToUTC
                WHERE domainId = p_domainId AND FK_recId = p_FK_recId;
                                    
		IF ROW_COUNT() > 0 THEN 
			COMMIT;
			SET OutResult = 1;
		ELSE
			SET OutResult = 0;
		END IF;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_tt_sp_update_recurrence_new_schedule_weekly` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_tt_sp_update_recurrence_new_schedule_weekly`(	
	OUT OutResult			TINYINT, 
    p_FK_recId				INT,
	p_domainId				INT,
	p_numbericTimeZone		VARCHAR(20),
    p_TimeHour				INT,
    p_TimeMinute			INT,
    p_repeatEvery			INT,
    -- =======================================
    p_isSunday				TINYINT, 
    p_isMonday				TINYINT, 
    p_isTueday				TINYINT, 
    p_isWednesday			TINYINT, 
    p_isThursday			TINYINT, 
    p_isFriday				TINYINT, 
    p_isSaturday			TINYINT 
)
BEGIN
		DECLARE v_userSetTime		DATETIME;
        DECLARE v_convertToUTC		DATETIME;
        DECLARE v_maxWeek			TINYINT;
        DECLARE v_minWeek			TINYINT;
        DECLARE v_upcomingWeek		TINYINT;
        DECLARE v_Weekday			TINYINT;
        DECLARE v_startDay			DATETIME;
        
        DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
				ROLLBACK;
                SET OutResult =0;
        END;
        -- ===================================================================================================
			SET v_maxWeek =  GREATEST(IFNULL(p_isSunday,0), IFNULL(p_isMonday,0),  IFNULL(p_isTueday,0), IFNULL(p_isWednesday,0), IFNULL(p_isThursday,0), IFNULL(p_isFriday,0), IFNULL(p_isSaturday,0));
            
            SET v_minWeek =  LEAST(IFNULL(p_isSunday,100), IFNULL(p_isMonday,100),  IFNULL(p_isTueday,100), IFNULL(p_isWednesday,100), IFNULL(p_isThursday,100), IFNULL(p_isFriday,100), IFNULL(p_isSaturday,100));
        -- ===================================================================================================
        
        SET v_userSetTime = ADDDATE(ADDDATE(ADDDATE(CONCAT(DATE(NOW()), " 00:00:00"), INTERVAL p_TimeHour HOUR),INTERVAL p_TimeMinute MINUTE), INTERVAL p_repeatEvery WEEK) ;
        
        SET v_Weekday = WEEK(v_userSetTime);
        
        SET v_startDay =  DATE_SUB(v_userSetTime, INTERVAL (DAYOFWEEK(v_userSetTime) - 1) DAY);
        
        -- select v_userSetTime, v_Weekday, v_startDay;
        -- ===========================================	
        
			WITH RECURSIVE cte01 as
			(
					SELECT	(v_startDay) as dateOfWeek, DAYOFWEEK(v_startDay) as WeekDtl
					UNION ALL
					SELECT  ADDDATE(dateOfWeek, INTERVAL 1 DAY), DAYOFWEEK(ADDDATE(dateOfWeek, INTERVAL 1 DAY)) from cte01
						WHERE  week(dateOfWeek) = v_Weekday 
			)
				SELECT dateOfWeek INTO v_userSetTime
				FROM cte01 where week(dateOfWeek) = v_Weekday 
                and WeekDtl in (p_isSunday, p_isMonday,  p_isTueday, p_isWednesday, p_isThursday, p_isFriday, p_isSaturday) limit 1;
			
        -- =========================================
        
				IF INSTR(p_numbericTimeZone, '+00:00') = 0 THEN
					SET v_convertToUTC = CONVERT_TZ(v_userSetTime, p_numbericTimeZone, '+00:00');
				ELSE
					SET v_convertToUTC = v_userSetTime;
				END IF;
	
		-- ===========================================
        
        START TRANSACTION;
        
        UPDATE wc_tb_recurrence_new_schedule_Weekly
			SET numbericTimeZone	= p_numbericTimeZone,
				repeatEvery			= p_repeatEvery,
                isSunday			= p_isSunday,
                isMonday			= p_isMonday,
                isTueday			= p_isTueday,
                isWednesday			= p_isWednesday,
                isThursday			= p_isThursday,
                isFriday			= p_isFriday,
                isSaturday			= p_isSaturday,
                frequenceHour		= p_TimeHour,
                frequenceMinute		= p_TimeMinute,
                userSysTime			= v_userSetTime,
                convertToUTC		= v_convertToUTC,
                UTC_startTime		= v_convertToUTC,
                maxWeek				= v_maxWeek,
                minWeek				= v_minWeek
			WHERE FK_recId = p_FK_recId AND domainId = p_domainId;
                                    
		IF ROW_COUNT() > 0 THEN 
			COMMIT;
			SET OutResult = 1;
		ELSE
			SET OutResult = 0;
		END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_updateBussinessConfigurationToggleAction` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_updateBussinessConfigurationToggleAction`(
	p_domainId			INT,
    p_mobileNumber		VARCHAR(30)	
 )
BEGIN
		DECLARE v_getActionDtl		TINYINT;
        DECLARE v_errCode			INT DEFAULT -1;
        DECLARE v_errMsg			VARCHAR(100) DEFAULT "Failed";
        
        IF EXISTS(SELECT 1 FROM wc_business_configuration WHERE domainId = p_domainId AND mobileNumber = p_mobileNumber)
        THEN
			SELECT isactive INTO v_getActionDtl 
				FROM wc_business_configuration 
                WHERE domainId = p_domainId AND mobileNumber = p_mobileNumber;
            
			IF v_getActionDtl = 0 THEN
            
				UPDATE wc_business_configuration 
					SET isactive = 1 WHERE domainId = p_domainId AND mobileNumber = p_mobileNumber;
                    
				IF row_count() > 0 THEN
					SET v_errCode = 1;
                    SET v_errMsg = "Updated Successfully";
				END IF;
                
			ELSEIF v_getActionDtl = 1 THEN
            
				UPDATE wc_business_configuration 
					SET isactive = 0 WHERE domainId = p_domainId AND mobileNumber = p_mobileNumber;
                    
				IF row_count() > 0 THEN
					SET v_errCode = 1;
                    SET v_errMsg = "Updated Successfully";
				END IF;
        END IF;
        
        END IF;
        
	SELECT v_errCode AS errCode, v_errMsg AS errMsg;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_UpdateTemplateStatus` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_UpdateTemplateStatus`(
p_templateId		BIGINT,
p_status			VARCHAR(30)
)
Begin
	
    	DECLARE	v_errMsg			VARCHAR(100) DEFAULT "Failed";
        DECLARE	v_errCode			TINYINT DEFAULT -1;
		DECLARE v_id				INT;				
    
    sp_exit:BEGIN
		IF NOT EXISTS(SELECT 1 FROM wc_template_master_dtl WHERE templateId = p_templateId LIMIT 1) THEN
			
            SET v_errCode = -2;
			SET v_errMsg = "Record not found"; 
			LEAVE sp_exit;
            
		END IF;
        
		SELECT id INTO v_id FROM wc_template_master_dtl WHERE templateId = p_templateId;   
        
        UPDATE wc_template_master_dtl
        SET `status` = p_status
        WHERE templateId = p_templateId 
        AND id = v_id;						
		
		IF ROW_COUNT() > 0 THEN				
		
			SET v_errCode = 1;
			SET v_errMsg = "Updated Successfully";
	
        END IF;
        
    END;
    
    SELECT v_errCode AS errCode, v_errMsg AS errMsg;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_update_AI_chat_archive_dtl_for_ccaas_CMPGN` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_update_AI_chat_archive_dtl_for_ccaas_CMPGN`(
	p_id			INT,
	p_domainId		INT 
)
BEGIN
		
        DECLARE v_errMsg	VARCHAR(50) 	DEFAULT "Failed";
        DECLARE v_errCode	TINYINT 		DEFAULT -1;
		
        IF EXISTS (SELECT 1 FROM wc_AI_convertation_master_details WHERE id = p_id AND  domainId = p_domainId AND team =1) THEN 
				
                UPDATE wc_AI_convertation_master_details
					SET isArchieve = CASE WHEN isArchieve =1 THEN 0 ELSE 1 END
                 WHERE id = p_id AND  domainId = p_domainId AND team =1 AND `status` = "DRAFT";    
					
				IF ROW_COUNT() > 0 THEN
					SET v_errMsg = "Updated Successfully";
                    SET v_errCode = 1;
				END IF;
                
        END IF;
        
        SELECT v_errCode AS errCode, v_errMsg AS errMsg;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_update_bussiness_configuration_isBot_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_update_bussiness_configuration_isBot_dtl`(
 	p_domainId			INT,
 	p_mobileNumber		VARCHAR(30)
 )
BEGIN
 			DECLARE v_isBot		TINYINT;
             DECLARE v_id		INT;
             DECLARE v_errMsg	VARCHAR(20) DEFAULT 'failed';
             DECLARE v_errCode	TINYINT DEFAULT -1;
 	
 			IF EXISTS(SELECT 1 FROM wc_business_configuration WHERE domainId = p_domainId AND mobileNumber = p_mobileNumber) THEN
 				
                 SELECT isBot, id  INTO v_isBot, v_id FROM wc_business_configuration WHERE domainId = p_domainId 
 																				AND mobileNumber = p_mobileNumber;
                                                                                 
 
                 
                 IF v_isBot =1 THEN
 						UPDATE wc_business_configuration 
 							SET isBot = 0
 							WHERE id = v_id;
 						
                         IF row_count() > 0 THEN 
 							SET v_errMsg	= "Updated";
                             SET v_errCode	= 1;
 						END IF;
 				ELSE
 						UPDATE wc_business_configuration 
 							SET isBot = 1
 							WHERE id = v_id;
 						
                         IF row_count() > 0 THEN 
 							SET v_errMsg	= "Updated";
                             SET v_errCode	= 1;
 						END IF;
 				
                 END IF;
                 
 			END IF;
             
             SELECT v_errCode as errCode, v_errMsg as errMsg;
         
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_update_campaign_bell_notification_all_isReadCol` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_update_campaign_bell_notification_all_isReadCol`(
  	p_domainId					INT
  )
BEGIN
  		DECLARE v_errCode	INT DEFAULT -1;
 		DECLARE v_errMsg	VARCHAR(50) DEFAULT "Failed";
          
		set session sql_safe_updates = 0;
        
        IF EXISTS(SELECT 1 FROM wc_overall_campaign_bell_notification where domainId = p_domainId AND isRead = 0) THEN 
 			UPDATE wc_overall_campaign_bell_notification SET isRead = 1
                 WHERE domainId = p_domainId and isRead = 0;
 			
 				 IF ROW_COUNT() > 0 THEN
 					SET v_errCode = 0;
 					SET v_errMsg = "Updated Successfully";
 				 END IF;
	
          END IF;
          SELECT v_errCode as errCode, v_errMsg as errMsg;
  
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_update_campaign_knowledge_base_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_update_campaign_knowledge_base_dtl`(
    	p_domainId				INT,
        p_companyName			VARCHAR(50),
        p_url					VARCHAR(300),
        p_industrial_type		varchar(70),
        p_contact_info			JSON,
        p_product_info			JSON,
        p_filename 				VARCHAR(100),
        p_mimetype				VARCHAR(100),
        p_size					INT,
        p_uploadUrl				VARCHAR(250),
        p_pdf_info				JSON
    )
BEGIN
   			 DECLARE v_errMsg		VARCHAR(50) DEFAULT 'Failed';
                DECLARE v_errCode		TINYINT	DEFAULT '-1';
                DECLARE v_id			INT DEFAULT 0;
                
                
                SELECT kbCampId INTO v_id FROM tb_campaign_knowledge_base_dtl WHERE domainId = p_domainId;
                
   
                IF v_id != 0
                THEN
   					UPDATE tb_campaign_knowledge_base_dtl
   						SET companyName 			= IFNULL(p_companyName, companyName),
   							url 					= IFNULL(p_url, url),
 							industrial_type 		= IFNULL(p_industrial_type, industrial_type),
 							contact_info			= IFNULL(p_contact_info, contact_info),
  							product_info			= IFNULL(p_product_info, product_info),
                             filename				= IFNULL(p_filename, filename),
                             mimetype				= IFNULL(p_mimetype, mimetype),
                             size					= IFNULL(p_size, size),
                             uploadUrl				= IFNULL(p_uploadUrl, uploadUrl),
                             pdf_info				= IFNULL(p_pdf_info, pdf_info)
   					WHERE domainId = p_domainId;
                       
                       IF row_count() > 0 THEN 
   						SET v_errMsg = "Updated Successfully";
                           SET v_errCode = 1;
   					END IF;	
                END IF;
                
                SELECT v_errCode as errCode, v_errMsg as errMsg;
   END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_update_ccaas_AI_convo_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_update_ccaas_AI_convo_dtl`(
 	p_campaignchatid		VARCHAR(300),
     p_domainId				INT,
     p_conversation			JSON
 )
BEGIN
 		DECLARE v_errCode		TINYINT			DEFAULT -1;
         DECLARE v_errMsg		VARCHAR(20)		DEFAULT "Failed";
         
         IF EXISTS(SELECT 1 FROM wc_AI_convertation_master_details WHERE campaignchatid = p_campaignchatid AND domainId = p_domainId AND team = 1) THEN
 				
                 UPDATE wc_AI_convertation_master_details
 					SET conversation = IFNULL(p_conversation, conversation)
 				WHERE campaignchatid = p_campaignchatid AND domainId = p_domainId AND team = 1;
                 
                 IF ROW_COUNT() > 0 THEN 
 					SET v_errCode = 1;
                     SET v_errMsg = "Updated Successfully";
 				END IF;
                 
         END IF;
         
         SELECT v_errCode AS errCode, v_errMsg AS errMsg;
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_update_custom_field_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_update_custom_field_info`(	 
  p_id						INT
 ,p_domainId 				INT	 
 ,p_field_type 				VARCHAR(50) 	
 ,p_field_label 			VARCHAR(50) 	
 ,p_field_value 			VARCHAR(2000)	
 ,p_isMandatory 			TINYINT 
 ,p_placeHolder 			VARCHAR(300) 
 ,p_errMsg 					VARCHAR(300) 
 ,p_isDisplay				TINYINT 
 )
BEGIN	
 	DECLARE v_errcode 	INT	DEFAULT 0;
 	DECLARE v_errmsg 	VARCHAR(50) DEFAULT 'Failed';    
         
     SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;     
    
    UPDATE wc_customer_contact_column_properties
     SET 	columnLabel		= p_field_label
 		,	placeHolder		= p_placeHolder
 		,	errMsg			= p_errMsg
 		,	columnType		= p_field_type
 		,	isMandatory		= p_isMandatory
 		,	isDisplay		= p_isDisplay
 		,	columnValue		= p_field_value
 	WHERE 	id				= p_id;
     
     IF ROW_COUNT() > 0
     THEN
 		SET v_errcode 	= 1
 		,	v_errmsg	= 'Updated Successfully';
     END IF;
     
     SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
     
     SELECT v_errcode AS errcode, v_errmsg AS errmsg;
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_update_knowledge_base_pdf_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_update_knowledge_base_pdf_dtl`(
	p_domainId			INT,
    p_uniqueId			varchar(50),
    p_companyName		varchar(50),
	p_industrial_type	varchar(70),
	p_filename			varchar(100),
	p_minetype			varchar(100),
	p_uploadUrl			varchar(250),
	p_size				int,
	p_pdf_info			json
)
begin
		declare v_errMsg		varchar(50) default 'failed';
        declare v_errCode		smallint default -1;
        declare v_id			int default 0;
        
       SELECT id into v_id FROM wc_tb_knowledge_base_pdf_dtl where  domainId = p_domainId AND uniqueId = p_uniqueId;

	  if v_id != 0 then
		
        update wc_tb_knowledge_base_pdf_dtl
			set companyName 				= IFNULL(p_companyName, companyName)
				,industrial_type 			= IFNULL(p_industrial_type, industrial_type)
                ,filename 					= IFNULL(p_filename, filename) 
                ,minetype 					= IFNULL(p_minetype, minetype)
                ,uploadUrl 					= IFNULL(p_uploadUrl, uploadUrl)
                ,size						=IFNULL(p_size, size)
                ,pdf_info					= IFNULL(p_pdf_info, pdf_info)
			WHERE id = v_id;
            
            if row_count() > 0 THEN 
				set v_errMsg	= "Updated Successfully";
                set v_errCode	= 1;
			end if;
            
       end if;   
       
            select v_errCode as errCode, v_errMsg as errMsg;
            
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_update_knowledge_base_website_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_update_knowledge_base_website_dtl`(
	p_domainId			INT,
    p_companyName		varchar(50),
	p_industrial_type	varchar(70),
	p_websideUrl		varchar(250),
    p_productInfo		json,
	p_contactInfo		json
)
begin
		declare v_errMsg		varchar(50) default 'failed';
        declare v_errCode		smallint default -1;
        declare v_id			int default 0;
        
       SELECT id into v_id FROM wc_tb_knowledge_base_website_dtl where  domainId = p_domainId ;

	  if v_id != 0 then
		
        update wc_tb_knowledge_base_website_dtl
			set  companyName 				= IFNULL(p_companyName, companyName)
				,industrialType 			= IFNULL(p_industrial_type, industrialType)
                ,websideUrl 					= IFNULL(p_websideUrl, websideUrl) 
                ,productInfo 					= IFNULL(p_productInfo, productInfo)
                ,contactInfo 					= IFNULL(p_contactInfo, contactInfo)
			WHERE id = v_id;
            
            if row_count() > 0 THEN 
				set v_errMsg	= "Updated Successfully";
                set v_errCode	= 1;
			end if;
            
       end if;   
       
            select v_errCode as errCode, v_errMsg as errMsg;
            
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_update_recurrence_new_schedule` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_update_recurrence_new_schedule`(
	 p_recId							INT
	,p_domainId							INT
	,p_reportId							INT		
	,p_recurrenceType					TINYINT		-- ================ 1 - Once, 2 - Daily, 3 - Weekly, 4 - Monthly ==================
	,p_reportResultStartDate			DATE
	,p_reportResultEndDate				DATE
	,p_timeZone							VARCHAR(50)
	,p_fileTypeIsPDF					TINYINT
	,p_fileTypeIsCSV					TINYINT
	,p_fileTypeIsXLS					TINYINT
	,p_fileTypeIsXLSL					TINYINT
	,p_emailId							VARCHAR(90)
	,p_subject							VARCHAR(500)
	,p_message							TEXT
	-- ============================================================  Once ===============================================
	,p_Date								DATE
    ,p_TimeHour							INT
	,p_TimeMinute						INT
    -- ============================================================ Daily , Weekly , Monthly =============================
	,p_repeatEvery						INT
	-- ============================================================ Monthly ==============================================
    , p_DateNo							INT
	, p_ordinalNumber					INT			-- 0 -> On, 1 -> First, 2 -> Second, 3 -> Third, 4 -> Fourth  
    , p_weekDays						INT			-- 1 -> SUNDAY, 2 -> MONDAY, 3 -> TUESDAY, 4 -> WEDNESDAY , 5 -> THURSDAY, 6 -> FRIDAY, 7 -> SATURDAY
    -- ============================================================ Weekly ==============================================
    ,p_isSunday							TINYINT 
    ,p_isMonday							TINYINT 
	,p_isTueday							TINYINT 
    ,p_isWednesday						TINYINT 
    ,p_isThursday						TINYINT 
    ,p_isFriday							TINYINT 
    ,p_isSaturday						TINYINT 
    
)
SP:BEGIN
		DECLARE v_errMsg				VARCHAR(50) 	DEFAULT "Failed";
        DECLARE v_errCode				SMALLINT 		DEFAULT -1;
        DECLARE v_InsertId				INT				;
        DECLARE v_numericTimeZone		VARCHAR(10)		DEFAULT "+00:00";
        DECLARE v_createdOn				DATETIME		DEFAULT NOW();
	
		DECLARE EXIT HANDLER FOR SQLEXCEPTION
		BEGIN
				SELECT v_errCode AS errCode, v_errMsg AS errMsg;
				ROLLBACK;
		END;
		
     IF (p_recurrenceType NOT BETWEEN 1 and 4) AND (p_reportId NOT BETWEEN 1 and 6) THEN  -- *************** Checking the input for Recurrence Type and Report Id ***********
			SELECT v_errCode AS errCode, v_errMsg AS errMsg;
            LEAVE SP;
     END IF;
     
     IF p_timeZone IS NOT NULL THEN 
		SET v_numericTimeZone = right(p_timeZone,6);   -- ************** getting the numberic time zone *************** 
     END IF;
     
		
		START TRANSACTION;
        
        update wc_tb_recurrence_new_schedule
              set  reportId 					= p_reportId,	
                recurrenceType				= p_recurrenceType, 
                reportResultStartDate		= p_reportResultStartDate, 
                reportResultEndDate			= p_reportResultEndDate, 
                timeZone					= p_timeZone,		
				 fileTypeIsPDF				= IFNULL(p_fileTypeIsPDF,0), 
                 fileTypeIsCSV				= IFNULL(p_fileTypeIsCSV,0), 	
                 fileTypeIsXLS				= IFNULL(p_fileTypeIsXLS ,0), 
                 fileTypeIsXLSL				= IFNULL(p_fileTypeIsXLSL,0),  
                 emailId					= p_emailId, 
                 `subject`					= p_subject, 
                 message					= p_message
		WHERE domainId = p_domainId AND recId = p_recId;
	
			IF ROW_COUNT() > 0 THEN
                SET v_InsertId = p_recId;			-- ********************* getting the insert id ***********************
			
               IF p_recurrenceType = 1 THEN  	-- ************************** for Once Recurssion *********************************
					call wc_tt_sp_update_recurrence_new_schedule_once(@OutResult, v_InsertId, p_domainId, v_numericTimeZone, p_TimeHour, p_TimeMinute, p_Date);
	
                    IF @OutResult = 1 THEN 
							COMMIT;
							SET v_errMsg	= "Updated Successfully";	
							SET v_errCode	= 1;
					ELSE 
							ROLLBACK;
					END IF;
               END IF;  
			
			IF p_recurrenceType = 2 THEN   		-- ************************** for Daily Recurssion *********************************
					call wc_tt_sp_update_recurrence_new_schedule_daily(@OutResult,v_InsertId, p_domainId, v_numericTimeZone, p_TimeHour, p_TimeMinute, p_repeatEvery);
	
                    IF @OutResult = 1 THEN 
							COMMIT;
							SET v_errMsg	= "Updated Successfully";	
							SET v_errCode	= 1;
					ELSE 
							ROLLBACK;
					END IF;
               END IF;
               
               IF p_recurrenceType = 3 THEN 		-- ************************** for Weekly Recurssion *********************************
					call wc_tt_sp_update_recurrence_new_schedule_weekly(@OutResult, v_InsertId, p_domainId, v_numericTimeZone, p_TimeHour, p_TimeMinute, p_repeatEvery, p_isSunday ,p_isMonday, p_isTueday, p_isWednesday, p_isThursday, p_isFriday, p_isSaturday);
	
                    IF @OutResult = 1 THEN 
							COMMIT;
							SET v_errMsg	= "Updated Successfully";	
							SET v_errCode	= 1;
					ELSE 
							ROLLBACK;
					END IF;
            END IF;
               
			IF p_recurrenceType = 4 THEN 		-- ************************** for Month Recurssion *********************************
					call wc_tt_sp_update_recurrence_new_schedule_monthly(@OutResult,v_InsertId, p_domainId, v_numericTimeZone, p_TimeHour, p_TimeMinute, p_repeatEvery , p_DateNo, p_ordinalNumber, p_weekDays);
	
                    IF @OutResult = 1 THEN 
							COMMIT;
							SET v_errMsg	= "Updated Successfully";	
							SET v_errCode	= 1;
					ELSE 
							ROLLBACK;
					END IF;
                    
               END IF;
            END IF;
            
            SELECT v_errCode AS errCode, v_errMsg AS errMsg;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_update_Schedule_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_update_Schedule_dtl`(
	p_recId						INT, 
	p_domainId					INT,
    p_recurrenceType			INT
)
begin
			DECLARE v_errMsg					VARCHAR(50) DEFAULT 'failed';
            DECLARE v_errCode					TINYINT DEFAULT -1;
            DECLARE v_id						INT;
            DECLARE v_repeatEvery				INT;
            DECLARE v_UTC_startTime				DATETIME;
            
			-- ***************** for weekly ***************
            DECLARE v_UTC_startTime_weekday		INT; 
            DECLARE v_minWeek					INT;  
            DECLARE v_maxWeek					INT;
            DECLARE v_UTC_startTime_week		INT;
            DECLARE v_nextWeek					INT;
            DECLARE v_resultDate				DATETIME;
            
            DECLARE v_isSunday					TINYINT;
            DECLARE v_isMonday					TINYINT;
            DECLARE v_isTueday					TINYINT;
            DECLARE v_isWednesday				TINYINT;	 
            DECLARE v_isThursday				TINYINT; 
            DECLARE v_isFriday					TINYINT;
            DECLARE v_isSaturday				TINYINT;
            
            -- ****************** for month **************
            DECLARE v_ordinalNumber				INT;
            DECLARE v_newConvertToUTC			DATETIME;
            DECLARE v_dateMonth					INT;
            DECLARE v_newDate					DATETIME;
            DECLARE v_weekDays					INT;
            DECLARE v_DateNo					INT;
            DECLARE v_TimeHour					INT;
            DECLARE v_TimeMinute				INT;
			
		
	
			IF p_recurrenceType = 1 THEN 				-- ************************** Once **************************
            
					SELECT id INTO v_id FROM wc_tb_recurrence_new_schedule_Once where domainId = p_domainId and FK_recId = p_recId;	
					
					UPDATE wc_tb_recurrence_new_schedule_Once
						SET isCompleted = 1
					WHERE id = v_id;
					
					IF ROW_COUNT() > 0 THEN 
						SET v_errMsg = "Updated Successfully";
						SET v_errCode = 1;
					END IF;
                
            ELSEIF   p_recurrenceType = 2 THEN 			-- ************************** Daily **************************
            
					SELECT id, repeatEvery, UTC_startTime INTO v_id , v_repeatEvery, v_UTC_startTime 
									FROM wc_tb_recurrence_new_schedule_Daily WHERE domainId = p_domainId AND FK_recId = p_recId;	
					
					UPDATE wc_tb_recurrence_new_schedule_Daily
						SET UTC_startTime = DATE_ADD(v_UTC_startTime, INTERVAL v_repeatEvery DAY)
					WHERE id = v_id;
					
					IF ROW_COUNT() > 0 THEN 
						SET v_errMsg = "Updated Successfully";
						SET v_errCode = 1;
					END IF;
                    
			ELSEIF	p_recurrenceType = 3	THEN			-- ************************** Weekly **************************
				
					SELECT id, repeatEvery, UTC_startTime, dayofweek(UTC_startTime), minWeek, maxWeek, WEEK(UTC_startTime),isSunday, isMonday, isTueday, isWednesday, isThursday, isFriday, isSaturday
					INTO v_id, v_repeatEvery, v_UTC_startTime, v_UTC_startTime_weekday, v_minWeek,  v_maxWeek, v_UTC_startTime_week,v_isSunday, v_isMonday, v_isTueday, v_isWednesday, v_isThursday, v_isFriday, v_isSaturday 
					FROM wc_tb_recurrence_new_schedule_Weekly where FK_recId =  p_recId AND domainId = p_domainId;
                    
	
					DROP TEMPORARY TABLE IF EXISTS tt_week_choosen;					-- ************** to find the next day **************
					CREATE TEMPORARY TABLE tt_week_choosen( weekDays int);
                    
						INSERT INTO tt_week_choosen(weekDays)values(v_isSunday),(v_isMonday),(v_isTueday),(v_isWednesday),(v_isThursday),(v_isFriday),(v_isSaturday);
					
					SELECT  weekDays INTO v_nextWeek 
						FROM	tt_week_choosen
					WHERE weekDays IS NOT NULL AND weekDays > v_UTC_startTime_weekday LIMIT 1;
					
                    
                     IF v_nextWeek <= v_maxWeek THEN
								WITH RECURSIVE cte01 as(
									SELECT(v_UTC_startTime) as dateOfWeek, DAYOFWEEK((v_UTC_startTime)) as WeekDtl
										UNION ALL
									SELECT  ADDDATE(dateOfWeek, INTERVAL 1 DAY), DAYOFWEEK(ADDDATE(dateOfWeek, INTERVAL 1 DAY)) FROM cte01 WHERE WEEK(dateOfWeek) = v_UTC_startTime_week 
									)
								SELECT dateOfWeek INTO v_resultDate 
									FROM cte01 
								WHERE WEEK(dateOfWeek) = v_UTC_startTime_week  AND WeekDtl IN (v_nextWeek) AND dateOfWeek > v_UTC_startTime LIMIT 01;
								
							UPDATE wc_tb_recurrence_new_schedule_Weekly SET  UTC_startTime = v_resultDate WHERE id = v_id;
                            
                            IF ROW_COUNT() > 0 THEN 
								SET v_errMsg = "Updated Successfully";
								SET v_errCode = 1;
							END IF;
                        
                        -- ========================================================================================================
					 ELSEIF	v_nextWeek IS NULL THEN 
 							SET v_UTC_startTime = ADDDATE(v_UTC_startTime, INTERVAL v_repeatEvery WEEK);   								-- *************** adding the week ************
							
                            SELECT SUBDATE(v_UTC_startTime, INTERVAL (DAYOFWEEK(v_UTC_startTime) -1 ) DAY) INTO v_UTC_startTime;	 	-- ******* getting the 1th day of the particular week ******* 
                            
                            SELECT week(v_UTC_startTime) INTO v_UTC_startTime_week;														-- *************** extracting the week ****************  
                            
                            
                            
							WITH RECURSIVE cte01 as(
								SELECT(v_UTC_startTime) as dateOfWeek, DAYOFWEEK((v_UTC_startTime)) as WeekDtl
									UNION ALL
								SELECT  ADDDATE(dateOfWeek, INTERVAL 1 DAY), DAYOFWEEK(ADDDATE(dateOfWeek, INTERVAL 1 DAY)) FROM cte01 WHERE WEEK(dateOfWeek) = v_UTC_startTime_week 
									)
									SELECT dateOfWeek INTO v_resultDate 
										FROM cte01 
									WHERE WEEK(dateOfWeek) = v_UTC_startTime_week  AND WeekDtl IN (v_minWeek) LIMIT 01;
                                    
                               
                            
                            UPDATE wc_tb_recurrence_new_schedule_Weekly SET  UTC_startTime = v_resultDate WHERE id = v_id;
                            
							IF ROW_COUNT() > 0 THEN 
								SET v_errMsg = "Updated Successfully";
								SET v_errCode = 1;
							END IF;	
                            
						END IF;
                        
			ELSEIF   p_recurrenceType = 4 THEN 						-- ************************** Monthly **************************
            
					SELECT id, ordinalNumber, UTC_startTime, repeatEvery, weekDays ,DateNo, frequenceHour , frequenceMinute
						INTO v_id,  v_ordinalNumber, v_UTC_startTime, v_repeatEvery, v_weekDays, v_DateNo, v_TimeHour,  v_TimeMinute
					FROM wc_tb_recurrence_new_schedule_Monthly WHERE domainId = p_domainId AND FK_recId = p_recId;
            
					IF IFNULL(v_ordinalNumber, 0) != 0 THEN 
									
							SET v_newConvertToUTC = adddate(v_UTC_startTime, interval v_repeatEvery MONTH);
							SET v_dateMonth = MONTH(v_newConvertToUTC);
							SET v_newDate = date_format(v_newConvertToUTC, '%Y-%m-01 %h:%i:%s');
							
							WITH RECURSIVE cte_01 AS (
								SELECT CAST(v_newDate AS DATETIME) AS dateno , DAYOFWEEK(CAST(v_newDate AS DATETIME)) AS dateweek
									UNION ALL
								SELECT ADDDATE(dateno, INTERVAL 1 DAY) AS dateno ,  DAYOFWEEK(ADDDATE(dateno, INTERVAL 1 DAY)) FROM cte_01 
								WHERE MONTH(dateno) = v_dateMonth
							),
							cte_02 as(
								SELECT ROW_NUMBER() OVER() AS rn, t1.* FROM cte_01 t1 WHERE dateweek = v_weekDays AND MONTH(dateno) = v_dateMonth
							)
								SELECT dateno INTO v_newConvertToUTC FROM cte_02 WHERE rn = v_ordinalNumber;
                                
					ELSE
							
                            IF CAST(DATE_FORMAT(ADDDATE(v_newConvertToUTC, INTERVAL v_repeatEvery MONTH), CONCAT('%Y-%m-',v_DateNo,' %h:%i:%s')) AS DATETIME) IS NOT NULL THEN 
							
									SET v_newConvertToUTC = CAST(DATE_FORMAT(ADDDATE(v_UTC_startTime, INTERVAL v_repeatEvery MONTH), CONCAT('%Y-%m-',v_DateNo,' %h:%i:%s')) AS DATETIME);
							ELSE    
									SET  v_newConvertToUTC = CAST(DATE_FORMAT(last_day(ADDDATE(v_UTC_startTime, INTERVAL v_repeatEvery MONTH)), CONCAT('%Y-%m-%d ',v_TimeHour,':',v_TimeMinute,':00')) as datetime);
							END IF;
					END IF;
                    
                    UPDATE wc_tb_recurrence_new_schedule_Monthly
							SET UTC_startTime = v_newConvertToUTC
					WHERE id = v_id AND domainId = p_domainId;
                    
                    IF ROW_COUNT() > 0 THEN 
								SET v_errMsg = "Updated Successfully";
								SET v_errCode = 1;
							END IF;	
            
            END IF;
            
            SELECT v_errCode as errCode, v_errMsg as errMsg; 
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_update_stop_recurrence_new_schedule` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_update_stop_recurrence_new_schedule`(
	p_domainId			INT,
    p_recId				INT
)
BEGIN
			declare v_errCode			tinyint default -1;
            declare v_errMsg			varchar(50) default 'Failed';
            declare v_recurrenceType	int;	
            
			SELECT recurrenceType into v_recurrenceType FROM wc_tb_recurrence_new_schedule where domainId = p_domainId and recId = p_recId;
            
            IF v_recurrenceType = 1 THEN
				update wc_tb_recurrence_new_schedule_Once
					SET isStop = 1
				where FK_recId = p_recId and domainId = p_domainId;
                
                IF row_count() > 0 then 
					set v_errCode = 1, v_errMsg= 'Updated Successfully';
                end if;
            
            ELSEIF v_recurrenceType = 2 THEN
				update wc_tb_recurrence_new_schedule_Daily
					SET isStop = 1
				where FK_recId = p_recId and domainId = p_domainId;
                
                IF row_count() > 0 then 
					set v_errCode = 1, v_errMsg= 'Updated Successfully';
                end if;
		
            ELSEIF v_recurrenceType = 3 THEN
				update wc_tb_recurrence_new_schedule_Weekly
					SET isStop = 1
				where FK_recId = p_recId and domainId = p_domainId;
                
                IF row_count() > 0 then 
					set v_errCode = 1, v_errMsg= 'Updated Successfully';
                end if;
        
            ELSEIF v_recurrenceType = 4 THEN
				update wc_tb_recurrence_new_schedule_Monthly
					SET isStop = 1
				where FK_recId = p_recId and domainId = p_domainId;
                
                IF row_count() > 0 then 
					set v_errCode = 1, v_errMsg= 'Updated Successfully';
                end if;
                
			END IF;
            
            SELECT v_errCode AS errCode, v_errMsg as errMsg;
            
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `wc_update_user_channel_unsub` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `wc_update_user_channel_unsub`(
	p_email			VARCHAR(200),
    p_domainId		INT,
    p_channelType	VARCHAR(20) 	
)
BEGIN
			DECLARE v_errMsg		varchar(50) default "Failed";
            DECLARE v_errCode		smallint 	default -1;
            
		
			IF EXISTS(SELECT 1 FROM wc_user_contact_dtl WHERE domainId = p_domainId and email = p_email) THEN
            
				IF 	p_channelType = "WHATSAPP" THEN
                    
                    UPDATE wc_user_contact_dtl
							SET isUnSub_Whatsapp = 1
					WHERE domainId = p_domainId AND email = p_email;
                    
                    IF ROW_COUNT() > 0 THEN 
						SET v_errCode = 1;
                        SET v_errMsg = "Updated";
					END IF;
                
                ELSEIF	p_channelType = "SMS" THEN
                    
                    UPDATE wc_user_contact_dtl
							SET isUnSub_SMS = 1
					WHERE domainId = p_domainId AND email = p_email;
                    
                      IF ROW_COUNT() > 0 THEN 
						SET v_errCode = 1;
                        SET v_errMsg = "Updated";
					END IF;
					
                 ELSEIF	p_channelType = "APPPUSH" THEN
                    
                    UPDATE wc_user_contact_dtl
							SET isUnSub_AppPush = 1
					WHERE domainId = p_domainId AND email = p_email;   
                    
                      IF ROW_COUNT() > 0 THEN 
						SET v_errCode = 1;
                        SET v_errMsg = "Updated";
					END IF;
                    
				 ELSEIF	p_channelType = "WEBPUSH" THEN
                    
                    UPDATE wc_user_contact_dtl
							SET isUnSub_WebPush = 1
					WHERE domainId = p_domainId AND email = p_email;
                    
                      IF ROW_COUNT() > 0 THEN 
						SET v_errCode = 1;
                        SET v_errMsg = "Updated";
					END IF;
                
				 ELSEIF	p_channelType = "INAPP" THEN
                 
                    UPDATE wc_user_contact_dtl
							SET isUnSub_InApp = 1
					WHERE domainId = p_domainId AND email = p_email;	
                    
                     IF ROW_COUNT() > 0 THEN 
						SET v_errCode = 1;
                        SET v_errMsg = "Updated";
					END IF;
                    
				END IF;
    
			END IF;	
            
            SELECT v_errCode AS errCode, v_errMsg AS errMsg;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `webpush_delete_configuration` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `webpush_delete_configuration`(
  p_config_id		INT
  ,p_domainId		INT
  )
BEGIN
 		DECLARE v_errMsg	VARCHAR(50) DEFAULT 'Failed';
         DECLARE v_errCode	TINYINT DEFAULT -1;
  
  	DELETE FROM webPush_tb_configuration 	
      WHERE 	config_id	= p_config_id
      AND 	domainId 	= p_domainId;
      
      IF ROW_COUNT() > 0 THEN 
 		
         SET v_errCode = 0;
 		SET v_errMsg = 'Deleted Successfully';
         
      END IF;
  
 		SELECT v_errCode as errCode, v_errMsg as errMsg;
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `webpush_getCronDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `webpush_getCronDtl`()
BEGIN
 		
         DECLARE v_currentDate		DATETIME;
         
         
         SET v_currentDate	=  cast(CONVERT_TZ(NOW(), "+00:00", "+05:30") as datetime);
         
        
        
        DROP TEMPORARY TABLE IF EXISTS tt_webAppCroneDtl;
 		CREATE TEMPORARY TABLE tt_webAppCroneDtl
        
        SELECT t1.* , t2.id as "scheduleId"
 		FROM webpush_masterCampaignDtl t1
         JOIN webpush_campaign_schedule_dtl t2 ON t1.id = t2.campaignId
         LEFT JOIN wc_master_revert_status_details	t3 ON t1.campaignChatId = t3.campaignchatId	 
         WHERE t2.scheduleType != 0
         AND t2.cronStatus = 0
         AND t3.campaignchatId IS NULL
         AND cast(date_format(t2.scheduleFromDate, "%Y-%m-%d %H:%i:00") as datetime) <= v_currentDate;
         
         
         SELECT * FROM tt_webAppCroneDtl;
         
          UPDATE tt_webAppCroneDtl t1 
         JOIN webpush_campaign_schedule_dtl t2 ON t1.id = t2.campaignId
         SET t2.cronStatus = 1
         WHERE 1 =1;
 			
         DROP TEMPORARY TABLE tt_webAppCroneDtl;
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `webpush_getMasterCampaignDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `webpush_getMasterCampaignDtl`(
	p_domainId								INT
)
BEGIN
		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        
        SELECT t1.campaignName, t1.`status`, t1.createdOn, t2.schedulefromDate as publishDate 
			FROM webpush_masterCampaignDtl t1
			JOIN webpush_campaign_schedule_dtl t2 ON t1.id = t2.campaignId
			WHERE t1.domainId = p_domainId
            ORDER BY t1.createdOn desc  
            ;
        
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
        
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `webpush_getSearchHistoryDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `webpush_getSearchHistoryDtl`(
		p_domainId			INT
)
BEGIN

		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        
			SELECT domainId, searchDetails 
				FROM webpush_searchHistoryDtl WHERE domainId = p_domainId;
                
                
		SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `webpush_getTokenDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `webpush_getTokenDtl`(
	p_domainId			INT
)
BEGIN
		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        
        SELECT domainId, userId, userName, TokenId, browser, emailId FROM webpush_TokenDtl WHERE domainId = p_domainId;
        
        SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
        
              
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `webpush_get_configuration` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `webpush_get_configuration`(
 p_domainId	INT
 )
BEGIN
 	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
 	SELECT 	config_id
 		,	webUrl
 		,	logoUrl
     FROM	webPush_tb_configuration 	
     WHERE 	domainId = p_domainId;
     SET TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `webPush_get_configuration_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `webPush_get_configuration_dtl`(
	p_domainId			INT
)
BEGIN
			
            SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
            
            SELECT 
					config_id
					, domainId
					, webUrl
					, logoUrl
					, createdAt
					, updatedAt
            FROM webPush_tb_configuration
            WHERE domainId = p_domainId;
            
            
            SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;


END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `webpush_get_sent_status_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `webpush_get_sent_status_details`(	
  	p_domainId						INT		,
   	p_campaignChatId				VARCHAR(300)
  )
BEGIN
 			
  
  
  		SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
  			
              
              SELECT id, domainId, campaignChatId, `status`, sentAt, `description`, token
              FROM webpush_sent_status_details 
  				WHERE domainId = p_domainId AND campaignChatId = p_campaignChatId;
  
  		SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `webpush_insertTokenDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `webpush_insertTokenDtl`(
 	p_domainId			INT,
     p_userId	    	INT,
     p_userName			VARCHAR(200),
     p_TokenId			VARCHAR(800),
     p_browser			VARCHAR(500),
     p_emailId			VARCHAR(250)
     
 )
BEGIN
			 DECLARE v_errMsg		VARCHAR(50) DEFAULT "Failed to Insert";
             DECLARE v_errCode		INT DEFAULT -1;
             DECLARE v_insertedId	INT DEFAULT 0;
         
			IF NOT EXISTS(SELECT 1 FROM webpush_TokenDtl WHERE domainId = p_domainId AND emailId =  p_emailId) THEN
         
 				INSERT INTO webpush_TokenDtl(domainId, userId, userName, TokenId, browser,  emailId)
 					VALUES(p_domainId, p_userId, p_userName, p_TokenId, p_browser, p_emailId);
                     
                IF ROW_COUNT() > 0 THEN
 					
                     SET v_errCode = 0;
                     SET v_errMsg = "Inserted Successfully";
                     SET v_insertedId	= last_insert_id();
                     
 				END IF;
 			ELSE
					UPDATE webpush_TokenDtl 
						SET TokenId 	= 		IFNULL(p_TokenId, TokenId),
							userId 		= 		IFNULL(p_userId, userId),
                            userName 	= 		IFNULL(p_userName, userName),
                            browser 	= 		IFNULL(p_browser, browser)
					WHERE domainId = p_domainId 
						AND emailId = p_emailId ;
                    
                    
                    IF ROW_COUNT() > 0 THEN
 					
                     SET v_errCode = 1;
                     SET v_errMsg = "Updated Successfully";
                     SET v_insertedId	= last_insert_id();
                     
					END IF;
            
            END IF;
            
 			SELECT v_errCode as errCode, v_errMsg AS errMsg, v_insertedId as insertedId;
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `webpush_InsertUpdateMasterCampaignDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `webpush_InsertUpdateMasterCampaignDtl`(
   	
   	p_domainId								INT,
   	p_campaignName							VARCHAR(250),
       p_campaignGoal							VARCHAR(250),
       p_industryType							VARCHAR(100),
       p_objective								VARCHAR(400),
       p_urlDtl								VARCHAR(250),
       p_scheduleType							SMALLINT,			
       p_schedulefromDate						DATETIME, 
       p_scheduletoDate						DATETIME,
       p_targetAudienceType					INT,				
       p_contactDtl							JSON,	
       p_TemplateDtl							TEXT,
       p_status								VARCHAR(50),
       p_deviceDtl								JSON,
       p_imageUrl								VARCHAR(300),
       p_sourceDtl								VARCHAR(15),
       p_campaignChatId							varchar(300)
   )
SP:BEGIN
				DECLARE v_errCode			INT DEFAULT -1;
               DECLARE v_errMsg			VARCHAR(50) DEFAULT "Failed to Insert";
               DECLARE v_lastInsertId		INT;
	
				
               DECLARE EXIT HANDLER FOR SQLEXCEPTION
               BEGIN
   						ROLLBACK;
                           SELECT -1 AS errCode, "Failed To Insert" AS errMsg;
               END;
            
				IF p_campaignChatId IS NULL THEN 
					SELECT v_errCode as errCode, v_errMsg AS errMsg;
					LEAVE SP;
                END IF;
            
   			START TRANSACTION;
               
                   INSERT INTO webpush_masterCampaignDtl
   				(domainId, campaignName , goal, industryType, objective, urlDtl, scheduleType, targetAudienceType, contactDtl, 
                   TemplateDtl, `Status`, deviceDtl, imageUrl, sourceDtl, campaignChatId)
   				VALUES
   				(p_domainId, p_campaignName , p_campaignGoal, p_industryType, p_objective, p_urlDtl, p_scheduleType, p_targetAudienceType,
   					p_contactDtl, p_TemplateDtl,   p_status, p_deviceDtl , p_imageUrl, p_sourceDtl, p_campaignChatId);
   		
   				IF ROW_COUNT() > 0 THEN
                   
   					SET v_lastInsertId = last_insert_id();
                       
   
   							INSERT INTO webpush_campaign_schedule_dtl(domainId, campaignId, scheduleType ,schedulefromDate, scheduletoDate, campaignChatId) 
   							VALUES(p_domainId, v_lastInsertId, p_scheduleType, IFNULL(p_schedulefromDate, now()), p_scheduletoDate, p_campaignChatId);
   
   
   
                           IF ROW_COUNT() > 0 THEN
   							SET v_errCode = 0;
   							SET v_errMsg = "Inserted Successfully";
   							COMMIT;
   						END IF;
                       
   				END IF;
                   
               SELECT v_errCode AS errCode, v_errMsg AS errMsg;
   END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `webpush_insertUpdateSearchHistoryDtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `webpush_insertUpdateSearchHistoryDtl`(
		p_domainId			INT,
        p_searchDetails		LONGTEXT
)
BEGIN
				DECLARE v_errCode		SMALLINT DEFAULT -1;
                DECLARE v_errMsg		VARCHAR(50) DEFAULT "Failed";
                DECLARE v_id			INT;
			
			IF NOT EXISTS(SELECT 1 FROM webpush_searchHistoryDtl WHERE domainId = p_domainId) THEN
				
               INSERT INTO webpush_searchHistoryDtl(domainId, searchDetails) VALUES(p_domainId, p_searchDetails);
               
               IF ROW_COUNT() > 0 THEN 
					SET v_errCode = 0;
                    SET v_errMsg = "Inserted Successfully";
               END IF;
               
            ELSE
					SELECT id INTO v_id FROM webpush_searchHistoryDtl WHERE domainId = p_domainId;
                    
                    UPDATE webpush_searchHistoryDtl
                    SET searchDetails = p_searchDetails
                    WHERE id = v_id and domainId = p_domainId;
                    
                    IF ROW_COUNT() > 0 THEN 
					
                    SET v_errCode = 1;
                    SET v_errMsg = "Updated Successfully";
                    
					END IF;
                    
                    
            END IF; 
            
            SELECT v_errCode AS errCode , v_errMsg AS errMsg;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `webPush_insert_configuration` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `webPush_insert_configuration`(
	p_config_id			INT,
	p_domainId			INT,
	p_webUrl			VARCHAR(300),
	p_logoUrl			VARCHAR(300)
)
BEGIN
			DECLARE v_errMsg  	VARCHAR(50) DEFAULT 'failed';
            DECLARE v_errCode 	SMALLINT DEFAULT -1;
            

			IF NOT EXISTS(SELECT 1 FROM webPush_tb_configuration WHERE domainId = p_domainId) THEN
            
				INSERT INTO webPush_tb_configuration(domainId, webUrl, logoUrl)
				VALUES(p_domainId, p_webUrl, p_logoUrl);
            
				IF row_count() > 0 THEN
					SET v_errMsg	= "Inserted Successfully";
					SET v_errCode	= 0;
				
				END IF;
            
            ELSE
					IF EXISTS(SELECT 1 FROM webPush_tb_configuration WHERE domainId = p_domainId AND config_id = p_config_id) THEN
            
					UPDATE webPush_tb_configuration
                    SET webUrl = p_webUrl
                    , logoUrl = p_logoUrl
                    WHERE config_id = p_config_id;
            
					IF row_count() > 0 THEN
					SET v_errMsg	= "Updated Successfully";
					SET v_errCode	= 1;
				
					END IF;
                    END IF;
            END IF;
            
            SELECT v_errCode as errCode, v_errMsg as errMsg;
            
            
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `webpush_insert_sent_status_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `webpush_insert_sent_status_details`(	
          	p_domainId						INT,
           	p_campaignChatId				VARCHAR(300),
           	p_token							VARCHAR(500),			
           	p_status						VARCHAR(50),
       		p_description					VARCHAR(800)
           )
BEGIN
                   DECLARE  v_errCode			TINYINT  		DEFAULT -1;
                   DECLARE  v_errMsg			VARCHAR(50)  	DEFAULT "Failed";
                   DECLARE  v_userId			INT;	
                   DECLARE  v_actionId			INT				DEFAULT 5;
                   DECLARE  v_currentDate		DATETIME 		DEFAULT now();	
                   DECLARE 	v_InsertUpdateStatus TINYINT		DEFAULT 0;	
                   
                   DECLARE EXIT HANDLER FOR SQLEXCEPTION
                   BEGIN
                            SELECT v_errCode AS errCode, v_errMsg AS errMsg;
    						ROLLBACK;
                   END;
                   
                   -- ===================================================================
                   
                   SELECT id INTO v_userId 
    						FROM wc_user_contact_dtl
    				WHERE domainId = p_domainId AND pushNotificationId = p_token;
                   
                   -- ======================================================================
                   
                    IF p_status = 'OPEN' THEN					
                        SET v_actionId = 4;	
                    ELSEIF p_status = 'DELIVERY' THEN 
                        SET v_actionId = 2;	
                    END IF;
                   
                   START TRANSACTION;
           		
					 -- ======================================================================
                
          		IF NOT EXISTS(SELECT 1 FROM webpush_sent_status_details WHERE domainId = p_domainId AND campaignChatId = p_campaignChatId AND token = p_token) THEN 
                  
      					INSERT INTO webpush_sent_status_details(domainId, campaignChatId, token, `status`, `description`, sentAt)
      					VALUES(p_domainId, p_campaignChatId, p_token, p_status, p_description, v_currentDate);
                        
                        IF ROW_COUNT() > 0 THEN 
							SET v_InsertUpdateStatus = 1;
						END IF;
                   
    			ELSE
      				
                      UPDATE webpush_sent_status_details SET 
      						`status` = p_status,
                           updatedOn = v_currentDate
      					WHERE domainId = p_domainId AND campaignChatId = p_campaignChatId AND token = p_token;
                        
                        IF ROW_COUNT() > 0 THEN 
							SET v_InsertUpdateStatus = 2;
						END IF;
                        
      			END IF;		
                 -- ======================================================================
 
				
				IF v_InsertUpdateStatus != 0 THEN 
					
                    IF (v_actionId IS NOT NULL AND v_userId IS NOT NULL) THEN 
                        INSERT INTO webPush_tb_indiv_user_click_open_cnt_dtl(domainId, campaignChatId, userID, actionId, createdOn)
    						VALUES(p_domainId, p_campaignChatId, v_userId, v_actionId, v_currentDate);
                
					IF ROW_COUNT() > 0 THEN 
						COMMIT;
                        SET v_errCode = CASE WHEN v_InsertUpdateStatus = 1 THEN 0 ELSE 1 END;
                        SET v_errMsg = CASE WHEN v_InsertUpdateStatus = 1 THEN  "Inserted Successfully" ELSE "Updated Successfully" END;
                    END IF;
                    
				END IF;
                END IF;
                
                SELECT v_errCode AS errCode , v_errMsg AS errMsg;
                          		
           END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `web_create_email_campaign_master_dtl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `web_create_email_campaign_master_dtl`(
  p_domainId int,
  p_Name text,
  p_Goal text,
  p_Type varchar(100),
  p_TargetAud varchar(100),
  p_Objective text,
  p_AB_testing tinyint,
  p_AItemplateA json,
  p_AItemplateB json,
  p_contactEmail json,
  p_webDelivery int,
  p_webDeliveryAt date,
  p_webDeliveryStarttime date,
  p_webDeliveryEndtime date,
  p_AB_testtype int,
  p_AB_variant json,
  p_AB_variantDistribution json,
  p_AB_winningCriteria int,
  p_AB_testWindow int,
  p_AB_testWindowtype int,
  p_createdBy varchar(100)
  )
Begin
  
 	declare v_errcode 		int default - 1;
 	declare v_errmsg 		varchar(50) default 'Failure';
 	declare v_campaignId 	int;
     DECLARE v_A				SMALLINT;
     DECLARE v_B				SMALLINT;
     DECLARE v_TotalCount	INT;
     DECLARE v_CreateExamineTime		DATETIME;
      
      DECLARE EXIT HANDLER FOR SQLEXCEPTION                   
    		BEGIN
    			GET DIAGNOSTICS CONDITION 1 @st = RETURNED_SQLSTATE, @p2 =  MESSAGE_TEXT;
    			set v_errmsg =  CONCAT(@st, ' : ', @p2);
    			set  @st='';
    			select -1 as errcode, v_errmsg as errmsg;
    			ROLLBACK;
    		END;
          
    	START TRANSACTION;
  		sp_exit:begin
  			insert into web_campaignMasterDtl(domainId, Name, Goal, Type, TargetAud, Objective, AB_testing, AItemplateA, AItemplateB, contactslist, WebPushDelivery, createdBy, WebPushDeliveryAt, WebPushDeliveryStarttime, WebPushDeliveryEndtime)
  			values(p_domainId,p_Name,  p_Goal, p_Type,p_TargetAud,p_Objective,p_AB_testing,p_AItemplateA,p_AItemplateB,p_contactEmail,p_webDelivery,p_createdBy, p_webDeliveryAt, p_webDeliveryStarttime, p_webDeliveryEndtime);
              	
  			set v_campaignId = last_insert_id();
 					
                    
  			
  			if p_AB_testing = 1 then
 					
                     SET v_CreateExamineTime = (SELECT 
 												CASE WHEN p_AB_testWindowtype = 1 THEN date_add(now(), interval p_AB_testWindow minute) 
 													WHEN p_AB_testWindowtype = 2 THEN  date_add(now(), interval p_AB_testWindow hour)
                                                      END );
                                                      
                     
  				insert into web_campaignABTestingDtl (campaignId, testtype, variant, variantDistribution, winningCriteria, AB_testWindow, AB_testWindowtype, examineTime)
  				values(v_campaignId, p_AB_testtype, p_AB_variant, p_AB_variantDistribution, p_AB_winningCriteria, p_AB_testWindow, p_AB_testWindowtype, v_CreateExamineTime);
  			End if;
  			
  			if  json_valid(p_contactEmail)=0 then
  				set v_errcode = -1;
  				set v_errmsg = 'Invalid json object';
  				leave sp_exit;
  			Else
  				
                 DROP TEMPORARY TABLE IF EXISTS tt_contactWeb;
                 CREATE TEMPORARY TABLE tt_contactWeb(SlNo SMALLINT AUTO_INCREMENT PRIMARY KEY,contactEmail VARCHAR(150), deliveryTime DATETIME, Template	VARCHAR(2));
                 
                 INSERT INTO tt_contactWeb(contactEmail, deliveryTime)
 				select 	tm.contactEmail 
 					,	tm.deliveryTime
 				from json_table(p_contactEmail, '$[*]' columns(
 					contactEmail varchar(100) path '$.contactEmail',
 					deliveryTime datetime PATH '$.deliveryTime'
  				)) as tm;
                 
                 IF p_AB_testing = 1 THEN
 					SELECT 	MAX(SlNo)
 					INTO	v_TotalCount
 					FROM 	tt_contactWeb;
 						
 					SET v_A	= v_TotalCount * json_extract(p_AB_variantDistribution,'$.A') / 100
 					, 	v_B = v_A + (v_TotalCount * json_extract(p_AB_variantDistribution,'$.B') / 100);
 					
 					UPDATE 	tt_contactWeb
 					SET 	Template	= 'A'
 					WHERE 	SlNo 		<= v_A;
 					
 					UPDATE 	tt_contactWeb
 					SET 	Template	= 'B'
 					WHERE 	SlNo 		> v_A AND SlNo <= v_B ;                
 				 
 					insert into  web_campaign_contacts_dtl(domainId, campaignId, contactEmail,deliveryTime,Template)
 					select 	p_domainId,v_campaignId,CE.contactEmail,CE.deliveryTime,CE.Template 
 					from	tt_contactWeb CE;
 				ELSE
 					insert into  web_campaign_contacts_dtl(domainId, campaignId, contactEmail,deliveryTime,Template)
 					select 	p_domainId,v_campaignId,CE.contactEmail,CE.deliveryTime,'A'
 					from	tt_contactWeb CE;                    
 				END IF;
  			End if;
  			
  			if row_Count()>0 then
  				set v_errcode = 0;
  				set v_errmsg = 'Campaign Created';
  			End if;
          
  		End sp_exit;
      COMMIT;
      
      DROP TEMPORARY TABLE IF EXISTS tt_contactWeb;
      
 	select v_campaignId as campaignId,v_errcode as errcode, v_errmsg as errmsg;
  End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-21  9:31:18
