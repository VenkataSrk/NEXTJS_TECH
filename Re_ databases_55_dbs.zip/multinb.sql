-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: multinb
-- ------------------------------------------------------
-- Server version	8.0.44-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `multinb`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `multinb` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `multinb`;

--
-- Table structure for table `LLOM_Recycle_log`
--

DROP TABLE IF EXISTS `LLOM_Recycle_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `LLOM_Recycle_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `mobileno` varchar(20) DEFAULT NULL,
  `llom_number` varchar(20) DEFAULT NULL,
  `recycle_date` datetime(3) DEFAULT NULL,
  `reg_sitecode` varchar(10) DEFAULT NULL,
  `exp_date` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `multi_number_pool`
--

DROP TABLE IF EXISTS `multi_number_pool`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `multi_number_pool` (
  `normalized_number` varchar(30) NOT NULL,
  `number` varchar(20) NOT NULL,
  `number_type` int DEFAULT NULL,
  `country_name` varchar(20) NOT NULL,
  `country_code` varchar(5) NOT NULL,
  `area_name` varchar(30) NOT NULL,
  `area_code` varchar(6) NOT NULL,
  `status` int NOT NULL,
  `reg_sitecode` varchar(3) DEFAULT NULL,
  `reg_acctype` int DEFAULT NULL,
  `reg_accountid` varchar(20) DEFAULT NULL,
  `reg_custcode` varchar(8) DEFAULT NULL,
  `reg_batchcode` int DEFAULT NULL,
  `reg_serialcode` int DEFAULT NULL,
  `reg_date` datetime(3) DEFAULT NULL,
  `reg_by` varchar(20) DEFAULT NULL,
  `lastupdate` datetime(3) DEFAULT NULL,
  `number_operator` varchar(30) DEFAULT NULL,
  `id` int NOT NULL AUTO_INCREMENT,
  `createdate` datetime(3) DEFAULT NULL,
  `stateid` int DEFAULT NULL,
  PRIMARY KEY (`normalized_number`),
  UNIQUE KEY `id` (`id`),
  UNIQUE KEY `multi_number_pool_idx1` (`country_code`,`area_code`,`number`),
  KEY `multi_number_pool_idx2` (`reg_sitecode`,`reg_acctype`,`reg_accountid`),
  KEY `multi_number_pool_idx3` (`reg_custcode`,`reg_batchcode`,`reg_serialcode`),
  KEY `multi_number_pool_idx4` (`country_code`,`number_type`),
  KEY `multi_number_pool_idx5` (`country_name`),
  KEY `multi_number_pool_idx6` (`area_name`),
  KEY `multi_number_pool_idx7` (`reg_sitecode`,`reg_acctype`,`reg_accountid`,`country_code`),
  KEY `multi_number_pool_idx8` (`lastupdate`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping events for database 'multinb'
--

--
-- Dumping routines for database 'multinb'
--
/*!50003 DROP PROCEDURE IF EXISTS `LLOM_number_get_recycle_number` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `LLOM_number_get_recycle_number`()
BEGIN

   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   SELECT mobileno,llom_number,recycle_date,exp_date,'LLOM'  AS Product FROM LLOM_Recycle_log
   union
   select acountid,did,insert_Date,exp_date,'DELIGHCALLING' AS Product
   from DIDPORTAL.dcapp_recycle_log
   UNION
   select CASE WHEN company_id IS NULL THEN '-' ELSE CAST(company_id as CHAR(30)) end as acountid,did,currentdate as insert_Date,
  TIMESTAMPADD(DAY,-1,recycle_startdate)  AS exp_date,'UNIFIEDRING' AS Product
   from DIDPORTAL.didportal_unifiedring_recycle_master_log_details;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Updating_Status_sp` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `Updating_Status_sp`(llomNumber VARCHAR(30))
BEGIN

  
  
   DECLARE v_errCode INT;  
   DECLARE v_errMsg VARCHAR(200);  
  
   IF EXISTS(SELECT 1 FROM multi_number_pool a WHERE a.normalized_number = llomNumber) then

      update multi_number_pool b
      set status = 0
      where status = 2
      and  b.normalized_number = llomNumber;
      Set v_errCode = 0;
      Set v_errMsg = 'Success';
   Else
      Set v_errCode = -1;
      Set v_errMsg = 'Failure';
   end if;          
  
   SELECT llomNumber LLOM_Number,v_errCode errcode,v_errMsg errmsg;  
  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-21  9:51:34
