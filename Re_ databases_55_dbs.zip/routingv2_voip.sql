-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: routingv2_voip
-- ------------------------------------------------------
-- Server version	8.0.44-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `CENTRAL_109216_routingv2`
--

DROP TABLE IF EXISTS `CENTRAL_109216_routingv2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CENTRAL_109216_routingv2` (
  `sitecode` varchar(3) DEFAULT NULL,
  `switchcode` char(3) DEFAULT NULL,
  `tgroup` varchar(15) DEFAULT NULL,
  `operator` varchar(15) DEFAULT NULL,
  `interface` varchar(50) DEFAULT NULL,
  `prefix` varchar(20) DEFAULT NULL,
  `xlatpfx` varchar(15) DEFAULT NULL,
  `numbertype` int DEFAULT NULL,
  `complaw` int DEFAULT NULL,
  `nbplan` int DEFAULT NULL,
  `signaddress` varchar(16) DEFAULT NULL,
  `callingnb` varchar(15) DEFAULT NULL,
  `callingcat` int DEFAULT NULL,
  `callingnbtype` int DEFAULT NULL,
  `isactive` int NOT NULL,
  `did_len` int DEFAULT NULL,
  `callingscreening` int DEFAULT NULL,
  `presentation` int DEFAULT NULL,
  `comment` varchar(30) DEFAULT NULL,
  `mindidlen` int DEFAULT NULL,
  `conntype` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=90 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `CENT_109216_routingv2`
--

DROP TABLE IF EXISTS `CENT_109216_routingv2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CENT_109216_routingv2` (
  `sitecode` varchar(3) DEFAULT NULL,
  `switchcode` char(3) DEFAULT NULL,
  `tgroup` varchar(15) DEFAULT NULL,
  `operator` varchar(15) DEFAULT NULL,
  `interface` varchar(50) DEFAULT NULL,
  `prefix` varchar(20) DEFAULT NULL,
  `xlatpfx` varchar(15) DEFAULT NULL,
  `numbertype` int DEFAULT NULL,
  `complaw` int DEFAULT NULL,
  `nbplan` int DEFAULT NULL,
  `signaddress` varchar(16) DEFAULT NULL,
  `callingnb` varchar(15) DEFAULT NULL,
  `callingcat` int DEFAULT NULL,
  `callingnbtype` int DEFAULT NULL,
  `isactive` int NOT NULL,
  `did_len` int DEFAULT NULL,
  `callingscreening` int DEFAULT NULL,
  `presentation` int DEFAULT NULL,
  `comment` varchar(30) DEFAULT NULL,
  `mindidlen` int DEFAULT NULL,
  `conntype` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=304 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `MSreplication_objects`
--

DROP TABLE IF EXISTS `MSreplication_objects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MSreplication_objects` (
  `publisher` varchar(160) DEFAULT NULL,
  `publisher_db` varchar(160) DEFAULT NULL,
  `publication` varchar(160) DEFAULT NULL,
  `object_name` varchar(160) NOT NULL,
  `object_type` char(2) NOT NULL,
  `article` varchar(160) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`),
  KEY `ucMSreplication_objects` (`object_name`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `MSreplication_subscriptions`
--

DROP TABLE IF EXISTS `MSreplication_subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MSreplication_subscriptions` (
  `publisher` varchar(160) NOT NULL,
  `publisher_db` varchar(160) DEFAULT NULL,
  `publication` varchar(160) DEFAULT NULL,
  `independent_agent` tinyint(1) NOT NULL,
  `subscription_type` int NOT NULL,
  `distribution_agent` varchar(160) DEFAULT NULL,
  `time` datetime NOT NULL,
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `transaction_timestamp` varbinary(16) NOT NULL,
  `update_mode` tinyint unsigned NOT NULL,
  `agent_id` binary(16) DEFAULT NULL,
  `subscription_guid` binary(16) DEFAULT NULL,
  `subid` binary(16) DEFAULT NULL,
  `immediate_sync` tinyint(1) NOT NULL DEFAULT '1',
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`),
  UNIQUE KEY `uc1MSReplication_subscriptions` (`publisher`,`publisher_db`,`publication`,`subscription_type`,`transaction_timestamp`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `MSsavedforeignkeycolumns`
--

DROP TABLE IF EXISTS `MSsavedforeignkeycolumns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MSsavedforeignkeycolumns` (
  `program_name` varchar(160) NOT NULL,
  `constraint_name` varchar(160) NOT NULL,
  `parent_schema` varchar(160) NOT NULL,
  `constraint_column_id` int NOT NULL,
  `referencing_column_name` varchar(160) NOT NULL,
  `referenced_column_name` varchar(160) NOT NULL,
  `timestamp` datetime(6) NOT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`),
  KEY `ci_MSsavedforeignkeycolumns` (`program_name`,`constraint_name`,`parent_schema`,`constraint_column_id`),
  KEY `nci_MSsavedforeignkeycolumns_timestamp` (`timestamp`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `MSsavedforeignkeyextendedproperties`
--

DROP TABLE IF EXISTS `MSsavedforeignkeyextendedproperties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MSsavedforeignkeyextendedproperties` (
  `program_name` varchar(160) NOT NULL,
  `constraint_name` varchar(160) NOT NULL,
  `parent_schema` varchar(160) NOT NULL,
  `property_name` varchar(160) NOT NULL,
  `property_value` text,
  `timestamp` datetime(6) NOT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`),
  KEY `ci_MSsavedforeignkeyextendedproperties` (`program_name`,`constraint_name`,`parent_schema`),
  KEY `nci_MSsavedforeignkeyextendedproperties_timestamp` (`timestamp`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `MSsavedforeignkeys`
--

DROP TABLE IF EXISTS `MSsavedforeignkeys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MSsavedforeignkeys` (
  `program_name` varchar(160) NOT NULL,
  `constraint_name` varchar(160) NOT NULL,
  `parent_schema` varchar(160) NOT NULL,
  `parent_name` varchar(160) NOT NULL,
  `referenced_object_schema` varchar(160) NOT NULL,
  `referenced_object_name` varchar(160) NOT NULL,
  `is_disabled` tinyint(1) NOT NULL,
  `is_not_for_replication` tinyint(1) NOT NULL,
  `is_not_trusted` tinyint(1) NOT NULL,
  `delete_referential_action` tinyint unsigned NOT NULL,
  `update_referential_action` tinyint unsigned NOT NULL,
  `timestamp` datetime(6) NOT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`),
  KEY `ci_MSsavedforeignkeys` (`program_name`,`constraint_name`,`parent_schema`),
  KEY `nci_MSsavedforeignkeys_timestamp` (`timestamp`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `MSsnapshotdeliveryprogress`
--

DROP TABLE IF EXISTS `MSsnapshotdeliveryprogress`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MSsnapshotdeliveryprogress` (
  `session_token` varchar(260) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `progress_token_hash` int NOT NULL,
  `progress_token` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `progress_timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`),
  KEY `ci_MSsnapshotdeliveryprogress_progress_token_hash` (`progress_token_hash`),
  KEY `nci_MSsnapshotdeliveryprogress_session_token` (`session_token`(255))
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `MSsubscription_agents`
--

DROP TABLE IF EXISTS `MSsubscription_agents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MSsubscription_agents` (
  `id` int NOT NULL,
  `publisher` varchar(160) NOT NULL,
  `publisher_db` varchar(160) NOT NULL,
  `publication` varchar(160) NOT NULL,
  `subscription_type` int NOT NULL,
  `queue_id` varchar(160) DEFAULT NULL,
  `update_mode` tinyint unsigned NOT NULL DEFAULT '0',
  `failover_mode` tinyint(1) NOT NULL DEFAULT '0',
  `spid` int NOT NULL,
  `login_time` datetime(6) NOT NULL,
  `allow_subscription_copy` tinyint(1) NOT NULL DEFAULT '0',
  `attach_state` int NOT NULL DEFAULT '0',
  `attach_version` binary(16) NOT NULL,
  `last_sync_status` int DEFAULT NULL,
  `last_sync_summary` varchar(160) DEFAULT NULL,
  `last_sync_time` datetime(6) DEFAULT NULL,
  `queue_server` varchar(160) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`),
  UNIQUE KEY `ucMSsubscription_agents` (`publisher`,`publisher_db`,`publication`,`subscription_type`),
  KEY `ucMSsubscription_agents_id` (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `R20_route01`
--

DROP TABLE IF EXISTS `R20_route01`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `R20_route01` (
  `id` int NOT NULL,
  `parentId` int DEFAULT NULL,
  `state` int NOT NULL,
  `reason` int DEFAULT NULL,
  `routeCls` int NOT NULL,
  `oprId` int NOT NULL,
  `pc` varchar(2) NOT NULL,
  `prefixCode` varchar(16) NOT NULL,
  `prefixLen` int NOT NULL,
  `destCode` varchar(32) DEFAULT NULL,
  `clsOrg` varchar(2) NOT NULL,
  `cls` varchar(2) NOT NULL,
  `costOrgCurr` varchar(4) NOT NULL,
  `costOrg` double NOT NULL,
  `cost` double NOT NULL,
  `priority` double NOT NULL,
  `access` int NOT NULL,
  `quality` double DEFAULT NULL,
  `rating` int DEFAULT NULL,
  `flag` int NOT NULL,
  `ext` int DEFAULT NULL,
  `exception` int DEFAULT NULL,
  `exceptionCls` int DEFAULT NULL,
  UNIQUE KEY `pk_r20_route01` (`id`),
  KEY `idx1` (`routeCls`,`oprId`,`pc`,`cls`),
  KEY `idx_list` (`routeCls`,`pc`,`prefixCode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `R20_route02`
--

DROP TABLE IF EXISTS `R20_route02`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `R20_route02` (
  `id` int NOT NULL,
  `parentId` int DEFAULT NULL,
  `state` int NOT NULL,
  `reason` int DEFAULT NULL,
  `routeCls` int NOT NULL,
  `oprId` int NOT NULL,
  `pc` varchar(2) NOT NULL,
  `prefixCode` varchar(16) NOT NULL,
  `prefixLen` int NOT NULL,
  `destCode` varchar(32) DEFAULT NULL,
  `clsOrg` varchar(2) NOT NULL,
  `cls` varchar(2) NOT NULL,
  `costOrgCurr` varchar(4) NOT NULL,
  `costOrg` double NOT NULL,
  `cost` double NOT NULL,
  `priority` double NOT NULL,
  `access` int NOT NULL,
  `quality` double DEFAULT NULL,
  `rating` int DEFAULT NULL,
  `flag` int NOT NULL,
  `ext` int DEFAULT NULL,
  `exception` int DEFAULT NULL,
  `exceptionCls` int DEFAULT NULL,
  UNIQUE KEY `pk_r20_route02` (`id`),
  KEY `idx1` (`routeCls`,`oprId`,`pc`,`cls`),
  KEY `idx_list` (`routeCls`,`pc`,`prefixCode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `R20_route03`
--

DROP TABLE IF EXISTS `R20_route03`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `R20_route03` (
  `id` int NOT NULL,
  `parentId` int DEFAULT NULL,
  `state` int NOT NULL,
  `reason` int DEFAULT NULL,
  `routeCls` int NOT NULL,
  `oprId` int NOT NULL,
  `pc` varchar(2) NOT NULL,
  `prefixCode` varchar(16) NOT NULL,
  `prefixLen` int NOT NULL,
  `destCode` varchar(32) DEFAULT NULL,
  `clsOrg` varchar(2) NOT NULL,
  `cls` varchar(2) NOT NULL,
  `costOrgCurr` varchar(4) NOT NULL,
  `costOrg` double NOT NULL,
  `cost` double NOT NULL,
  `priority` double NOT NULL,
  `access` int NOT NULL,
  `quality` double DEFAULT NULL,
  `rating` int DEFAULT NULL,
  `flag` int NOT NULL,
  `ext` int DEFAULT NULL,
  `exception` int DEFAULT NULL,
  `exceptionCls` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`),
  UNIQUE KEY `pk_R20_ROUTE03` (`id`),
  KEY `idx1` (`routeCls`,`oprId`,`pc`,`cls`),
  KEY `idx_list` (`routeCls`,`pc`,`prefixCode`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=611515 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `R20_route10`
--

DROP TABLE IF EXISTS `R20_route10`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `R20_route10` (
  `id` int NOT NULL,
  `parentId` int DEFAULT NULL,
  `state` int NOT NULL,
  `reason` int DEFAULT NULL,
  `routeCls` int NOT NULL,
  `oprId` int NOT NULL,
  `pc` varchar(2) NOT NULL,
  `prefixCode` varchar(16) NOT NULL,
  `prefixLen` int NOT NULL,
  `destCode` varchar(32) DEFAULT NULL,
  `clsOrg` varchar(2) NOT NULL,
  `cls` varchar(2) NOT NULL,
  `costOrgCurr` varchar(4) NOT NULL,
  `costOrg` double NOT NULL,
  `cost` double NOT NULL,
  `priority` double NOT NULL,
  `access` int NOT NULL,
  `quality` double DEFAULT NULL,
  `rating` int DEFAULT NULL,
  `flag` int NOT NULL,
  `ext` int DEFAULT NULL,
  `exception` int DEFAULT NULL,
  `exceptionCls` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`),
  UNIQUE KEY `pk_r20_route10` (`id`),
  KEY `idx1` (`routeCls`,`oprId`,`pc`,`cls`),
  KEY `idx_list` (`routeCls`,`pc`,`prefixCode`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=454683 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `R20_route12`
--

DROP TABLE IF EXISTS `R20_route12`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `R20_route12` (
  `id` int NOT NULL,
  `parentId` int DEFAULT NULL,
  `state` int NOT NULL,
  `reason` int DEFAULT NULL,
  `routeCls` int NOT NULL,
  `oprId` int NOT NULL,
  `pc` varchar(2) NOT NULL,
  `prefixCode` varchar(16) NOT NULL,
  `prefixLen` int NOT NULL,
  `destCode` varchar(32) DEFAULT NULL,
  `clsOrg` varchar(2) NOT NULL,
  `cls` varchar(2) NOT NULL,
  `costOrgCurr` varchar(4) NOT NULL,
  `costOrg` double NOT NULL,
  `cost` double NOT NULL,
  `priority` double NOT NULL,
  `access` int NOT NULL,
  `quality` double DEFAULT NULL,
  `rating` int DEFAULT NULL,
  `flag` int NOT NULL,
  `ext` int DEFAULT NULL,
  `exception` int DEFAULT NULL,
  `exceptionCls` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`),
  UNIQUE KEY `pk_r20_route12` (`id`),
  KEY `idx1` (`routeCls`,`oprId`,`pc`,`cls`),
  KEY `idx_list` (`routeCls`,`pc`,`prefixCode`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=609751 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `XlatInterDomain`
--

DROP TABLE IF EXISTS `XlatInterDomain`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `XlatInterDomain` (
  `sitecode_in` varchar(4) NOT NULL,
  `switchcode_in` varchar(4) NOT NULL,
  `sitecode_out` varchar(4) NOT NULL,
  `operator_out` varchar(15) NOT NULL,
  `prefix` varchar(20) NOT NULL,
  `xlatpfx` varchar(20) DEFAULT NULL,
  `prefixlen` int DEFAULT NULL,
  `comment` varchar(64) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`),
  UNIQUE KEY `PK_xlatinterdomain` (`sitecode_in`,`switchcode_in`,`sitecode_out`,`operator_out`,`prefix`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=124 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `blocked_ddi`
--

DROP TABLE IF EXISTS `blocked_ddi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blocked_ddi` (
  `ddi` varchar(20) NOT NULL,
  `blocker` varchar(32) DEFAULT NULL,
  `reason` varchar(32) DEFAULT NULL,
  `date` varchar(10) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`),
  UNIQUE KEY `PK__blocked_ddi__7C255952` (`ddi`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=1679 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `callout`
--

DROP TABLE IF EXISTS `callout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `callout` (
  `sitecode` varchar(3) DEFAULT NULL,
  `switchcode` char(3) DEFAULT NULL,
  `tgroup` varchar(15) DEFAULT NULL,
  `operator` varchar(15) DEFAULT NULL,
  `interface` varchar(50) DEFAULT NULL,
  `prefix` varchar(25) DEFAULT NULL,
  `xlatpfx` varchar(15) DEFAULT NULL,
  `numbertype` int DEFAULT NULL,
  `complaw` int DEFAULT NULL,
  `nbplan` int DEFAULT NULL,
  `signaddress` varchar(50) DEFAULT NULL,
  `callingnb` varchar(15) DEFAULT NULL,
  `callingcat` int DEFAULT NULL,
  `callingnbtype` int DEFAULT NULL,
  `isactive` int NOT NULL,
  `did_len` int DEFAULT NULL,
  `callingscreening` int DEFAULT NULL,
  `presentation` int DEFAULT NULL,
  `comment` varchar(30) DEFAULT NULL,
  `mindidlen` int DEFAULT NULL,
  `conntype` int DEFAULT NULL,
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`),
  KEY `idx_sitecode` (`sitecode`),
  KEY `idx_switchcode` (`switchcode`),
  KEY `idx_tgroup` (`tgroup`),
  KEY `idx_operator` (`operator`),
  KEY `idx_interface` (`interface`),
  KEY `idx_prefix` (`prefix`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=3764290 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `calloutTrunkIPCredentials`
--

DROP TABLE IF EXISTS `calloutTrunkIPCredentials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `calloutTrunkIPCredentials` (
  `id` int NOT NULL AUTO_INCREMENT,
  `trunkIP` varchar(50) DEFAULT NULL,
  `userName` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `callout_7vt666`
--

DROP TABLE IF EXISTS `callout_7vt666`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `callout_7vt666` (
  `sitecode` varchar(3) DEFAULT NULL,
  `switchcode` char(3) DEFAULT NULL,
  `tgroup` varchar(15) DEFAULT NULL,
  `operator` varchar(15) DEFAULT NULL,
  `interface` varchar(50) DEFAULT NULL,
  `prefix` varchar(20) DEFAULT NULL,
  `xlatpfx` varchar(15) DEFAULT NULL,
  `numbertype` int DEFAULT NULL,
  `complaw` int DEFAULT NULL,
  `nbplan` int DEFAULT NULL,
  `signaddress` varchar(16) DEFAULT NULL,
  `callingnb` varchar(15) DEFAULT NULL,
  `callingcat` int DEFAULT NULL,
  `callingnbtype` int DEFAULT NULL,
  `isactive` int NOT NULL,
  `did_len` int DEFAULT NULL,
  `callingscreening` int DEFAULT NULL,
  `presentation` int DEFAULT NULL,
  `comment` varchar(30) DEFAULT NULL,
  `mindidlen` int DEFAULT NULL,
  `conntype` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `callout_IP`
--

DROP TABLE IF EXISTS `callout_IP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `callout_IP` (
  `sitecode` varchar(3) DEFAULT NULL,
  `switchcode` char(3) DEFAULT NULL,
  `tgroup` varchar(15) DEFAULT NULL,
  `operator` varchar(15) DEFAULT NULL,
  `interface` varchar(50) DEFAULT NULL,
  `prefix` varchar(20) DEFAULT NULL,
  `xlatpfx` varchar(15) DEFAULT NULL,
  `numbertype` int DEFAULT NULL,
  `complaw` int DEFAULT NULL,
  `nbplan` int DEFAULT NULL,
  `signaddress` varchar(16) DEFAULT NULL,
  `callingnb` varchar(15) DEFAULT NULL,
  `callingcat` int DEFAULT NULL,
  `callingnbtype` int DEFAULT NULL,
  `isactive` int NOT NULL,
  `did_len` int DEFAULT NULL,
  `callingscreening` int DEFAULT NULL,
  `presentation` int DEFAULT NULL,
  `comment` varchar(30) DEFAULT NULL,
  `mindidlen` int DEFAULT NULL,
  `conntype` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `callout_upd`
--

DROP TABLE IF EXISTS `callout_upd`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `callout_upd` (
  `sitecode` varchar(3) DEFAULT NULL,
  `switchcode` char(3) DEFAULT NULL,
  `tgroup` varchar(15) DEFAULT NULL,
  `operator` varchar(15) DEFAULT NULL,
  `interface` varchar(50) DEFAULT NULL,
  `prefix` varchar(25) DEFAULT NULL,
  `xlatpfx` varchar(15) DEFAULT NULL,
  `numbertype` int DEFAULT NULL,
  `complaw` int DEFAULT NULL,
  `nbplan` int DEFAULT NULL,
  `signaddress` varchar(50) DEFAULT NULL,
  `callingnb` varchar(15) DEFAULT NULL,
  `callingcat` int DEFAULT NULL,
  `callingnbtype` int DEFAULT NULL,
  `isactive` int NOT NULL,
  `did_len` int DEFAULT NULL,
  `callingscreening` int DEFAULT NULL,
  `presentation` int DEFAULT NULL,
  `comment` varchar(30) DEFAULT NULL,
  `mindidlen` int DEFAULT NULL,
  `conntype` int DEFAULT NULL,
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=104502 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `causecode`
--

DROP TABLE IF EXISTS `causecode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `causecode` (
  `domain` varchar(8) NOT NULL,
  `operator` varchar(32) NOT NULL,
  `code` int NOT NULL,
  `name` varchar(32) DEFAULT NULL,
  `next` int DEFAULT NULL,
  `counter` int DEFAULT NULL,
  `duration` int DEFAULT NULL,
  `reserved` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cswitch_config`
--

DROP TABLE IF EXISTS `cswitch_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cswitch_config` (
  `operator` varchar(15) NOT NULL,
  `prefix` varchar(20) NOT NULL,
  `alert_timeout` int NOT NULL,
  `listen_delay` int NOT NULL,
  `connect_delay` int NOT NULL,
  `alert_delay` int NOT NULL,
  `vox_callsetup` varchar(25) NOT NULL,
  `ismonitor` int DEFAULT NULL,
  `monperiod` varchar(2) DEFAULT NULL,
  `randomcli` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dtproperties`
--

DROP TABLE IF EXISTS `dtproperties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dtproperties` (
  `id` int NOT NULL,
  `objectid` int DEFAULT NULL,
  `property` varchar(64) NOT NULL,
  `value` varchar(255) DEFAULT NULL,
  `uvalue` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `lvalue` longblob,
  `version` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`,`property`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `inter_xgate_bridge`
--

DROP TABLE IF EXISTS `inter_xgate_bridge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inter_xgate_bridge` (
  `domain_from` varchar(4) NOT NULL,
  `domain_to` varchar(4) NOT NULL,
  `bridge_idx` int NOT NULL,
  `bridge_group` varchar(8) NOT NULL,
  `bridge_domain` varchar(4) NOT NULL,
  `bridge_hint` varchar(30) NOT NULL,
  `comment` varchar(64) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`),
  UNIQUE KEY `PK__inter_xgate_brid__75644A4B` (`domain_from`,`domain_to`,`bridge_idx`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=519 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `inter_xgate_media`
--

DROP TABLE IF EXISTS `inter_xgate_media`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inter_xgate_media` (
  `ip_address` varchar(16) NOT NULL,
  `switchcode` varchar(3) NOT NULL,
  `machine_id` varchar(3) NOT NULL,
  `sitecode` varchar(3) NOT NULL,
  `ip` tinyint unsigned NOT NULL,
  `atm` tinyint unsigned NOT NULL,
  `ip_interface` varchar(16) DEFAULT NULL,
  `atm_interface` varchar(16) DEFAULT NULL,
  `signalling_type` varchar(10) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`),
  UNIQUE KEY `PK__inter_xgate_medi__76586E84` (`ip_address`),
  UNIQUE KEY `inter_xgate_media_idx1` (`switchcode`),
  UNIQUE KEY `inter_xgate_media_idx2` (`machine_id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `jsondataout`
--

DROP TABLE IF EXISTS `jsondataout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jsondataout` (
  `id` int NOT NULL,
  `jsonv` json DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `jsonvalue`
--

DROP TABLE IF EXISTS `jsonvalue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jsonvalue` (
  `id` int NOT NULL,
  `jsonvalue` json DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `level`
--

DROP TABLE IF EXISTS `level`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `level` (
  `sitecode` varchar(3) DEFAULT NULL,
  `switchcode` char(3) DEFAULT NULL,
  `tgroup` varchar(15) DEFAULT NULL,
  `operator` varchar(15) DEFAULT NULL,
  `interface` varchar(50) DEFAULT NULL,
  `prefix` varchar(20) DEFAULT NULL,
  `xlatpfx` varchar(15) DEFAULT NULL,
  `numbertype` int DEFAULT NULL,
  `complaw` int DEFAULT NULL,
  `nbplan` int DEFAULT NULL,
  `signaddress` varchar(16) DEFAULT NULL,
  `callingnb` varchar(15) DEFAULT NULL,
  `callingcat` int DEFAULT NULL,
  `callingnbtype` int DEFAULT NULL,
  `isactive` int NOT NULL,
  `did_len` int DEFAULT NULL,
  `callingscreening` int DEFAULT NULL,
  `presentation` int DEFAULT NULL,
  `comment` varchar(30) DEFAULT NULL,
  `mindidlen` int DEFAULT NULL,
  `conntype` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `monitor`
--

DROP TABLE IF EXISTS `monitor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `monitor` (
  `id` int NOT NULL,
  `calldate` varchar(10) DEFAULT NULL,
  `switchcode` varchar(8) DEFAULT NULL,
  `operator` varchar(16) DEFAULT NULL,
  `channel` varchar(8) DEFAULT NULL,
  `talktime_sec` int DEFAULT NULL,
  `talktime_min` int DEFAULT NULL,
  `costb` double DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=333 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `r20_route04`
--

DROP TABLE IF EXISTS `r20_route04`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `r20_route04` (
  `id` int NOT NULL,
  `parentId` int DEFAULT NULL,
  `state` int NOT NULL,
  `reason` int DEFAULT NULL,
  `routeCls` int NOT NULL,
  `oprId` int NOT NULL,
  `pc` varchar(2) NOT NULL,
  `prefixCode` varchar(16) NOT NULL,
  `prefixLen` int NOT NULL,
  `destCode` varchar(32) DEFAULT NULL,
  `clsOrg` varchar(2) NOT NULL,
  `cls` varchar(2) NOT NULL,
  `costOrgCurr` varchar(4) NOT NULL,
  `costOrg` double NOT NULL,
  `cost` double NOT NULL,
  `priority` double NOT NULL,
  `access` int NOT NULL,
  `quality` double DEFAULT NULL,
  `rating` int DEFAULT NULL,
  `flag` int NOT NULL,
  `ext` int DEFAULT NULL,
  `exception` int DEFAULT NULL,
  `exceptionCls` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`),
  UNIQUE KEY `pk_R20_ROUTE04` (`id`),
  KEY `idx1` (`routeCls`,`oprId`,`pc`,`cls`),
  KEY `idx_list` (`routeCls`,`pc`,`prefixCode`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=727781 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `r20_route05`
--

DROP TABLE IF EXISTS `r20_route05`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `r20_route05` (
  `id` int NOT NULL,
  `parentId` int DEFAULT NULL,
  `state` int NOT NULL,
  `reason` int DEFAULT NULL,
  `routeCls` int NOT NULL,
  `oprId` int NOT NULL,
  `pc` varchar(2) NOT NULL,
  `prefixCode` varchar(16) NOT NULL,
  `prefixLen` int NOT NULL,
  `destCode` varchar(32) DEFAULT NULL,
  `clsOrg` varchar(2) NOT NULL,
  `cls` varchar(2) NOT NULL,
  `costOrgCurr` varchar(4) NOT NULL,
  `costOrg` double NOT NULL,
  `cost` double NOT NULL,
  `priority` double NOT NULL,
  `access` int NOT NULL,
  `quality` double DEFAULT NULL,
  `rating` int DEFAULT NULL,
  `flag` int NOT NULL,
  `ext` int DEFAULT NULL,
  `exception` int DEFAULT NULL,
  `exceptionCls` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`),
  UNIQUE KEY `pk_R20_ROUTE05` (`id`),
  KEY `idx1` (`routeCls`,`oprId`,`pc`,`cls`),
  KEY `idx_list` (`routeCls`,`pc`,`prefixCode`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=640003 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `r20_route06`
--

DROP TABLE IF EXISTS `r20_route06`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `r20_route06` (
  `id` int NOT NULL,
  `parentId` int DEFAULT NULL,
  `state` int NOT NULL,
  `reason` int DEFAULT NULL,
  `routeCls` int NOT NULL,
  `oprId` int NOT NULL,
  `pc` varchar(2) NOT NULL,
  `prefixCode` varchar(16) NOT NULL,
  `prefixLen` int NOT NULL,
  `destCode` varchar(32) DEFAULT NULL,
  `clsOrg` varchar(2) NOT NULL,
  `cls` varchar(2) NOT NULL,
  `costOrgCurr` varchar(4) NOT NULL,
  `costOrg` double NOT NULL,
  `cost` double NOT NULL,
  `priority` double NOT NULL,
  `access` int NOT NULL,
  `quality` double DEFAULT NULL,
  `rating` int DEFAULT NULL,
  `flag` int NOT NULL,
  `ext` int DEFAULT NULL,
  `exception` int DEFAULT NULL,
  `exceptionCls` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`),
  UNIQUE KEY `pk_R20_ROUTE06` (`id`),
  KEY `idx1` (`routeCls`,`oprId`,`pc`,`cls`),
  KEY `idx_list` (`routeCls`,`pc`,`prefixCode`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=520003 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `r20_route07`
--

DROP TABLE IF EXISTS `r20_route07`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `r20_route07` (
  `id` int NOT NULL,
  `parentId` int DEFAULT NULL,
  `state` int NOT NULL,
  `reason` int DEFAULT NULL,
  `routeCls` int NOT NULL,
  `oprId` int NOT NULL,
  `pc` varchar(2) NOT NULL,
  `prefixCode` varchar(16) NOT NULL,
  `prefixLen` int NOT NULL,
  `destCode` varchar(32) DEFAULT NULL,
  `clsOrg` varchar(2) NOT NULL,
  `cls` varchar(2) NOT NULL,
  `costOrgCurr` varchar(4) NOT NULL,
  `costOrg` double NOT NULL,
  `cost` double NOT NULL,
  `priority` double NOT NULL,
  `access` int NOT NULL,
  `quality` double DEFAULT NULL,
  `rating` int DEFAULT NULL,
  `flag` int NOT NULL,
  `ext` int DEFAULT NULL,
  `exception` int DEFAULT NULL,
  `exceptionCls` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`),
  UNIQUE KEY `pk_R20_ROUTE07` (`id`),
  KEY `idx1` (`routeCls`,`oprId`,`pc`,`cls`),
  KEY `idx_list` (`routeCls`,`pc`,`prefixCode`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=740373 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `r20_route08`
--

DROP TABLE IF EXISTS `r20_route08`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `r20_route08` (
  `id` int NOT NULL,
  `parentId` int DEFAULT NULL,
  `state` int NOT NULL,
  `reason` int DEFAULT NULL,
  `routeCls` int NOT NULL,
  `oprId` int NOT NULL,
  `pc` varchar(2) NOT NULL,
  `prefixCode` varchar(16) NOT NULL,
  `prefixLen` int NOT NULL,
  `destCode` varchar(32) DEFAULT NULL,
  `clsOrg` varchar(2) NOT NULL,
  `cls` varchar(2) NOT NULL,
  `costOrgCurr` varchar(4) NOT NULL,
  `costOrg` double NOT NULL,
  `cost` double NOT NULL,
  `priority` double NOT NULL,
  `access` int NOT NULL,
  `quality` double DEFAULT NULL,
  `rating` int DEFAULT NULL,
  `flag` int NOT NULL,
  `ext` int DEFAULT NULL,
  `exception` int DEFAULT NULL,
  `exceptionCls` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`),
  UNIQUE KEY `pk_R20_ROUTE08` (`id`),
  KEY `idx1` (`routeCls`,`oprId`,`pc`,`cls`),
  KEY `idx_list` (`routeCls`,`pc`,`prefixCode`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=763617 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `r20_route09`
--

DROP TABLE IF EXISTS `r20_route09`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `r20_route09` (
  `id` int NOT NULL,
  `parentId` int DEFAULT NULL,
  `state` int NOT NULL,
  `reason` int DEFAULT NULL,
  `routeCls` int NOT NULL,
  `oprId` int NOT NULL,
  `pc` varchar(2) NOT NULL,
  `prefixCode` varchar(16) NOT NULL,
  `prefixLen` int NOT NULL,
  `destCode` varchar(32) DEFAULT NULL,
  `clsOrg` varchar(2) NOT NULL,
  `cls` varchar(2) NOT NULL,
  `costOrgCurr` varchar(4) NOT NULL,
  `costOrg` double NOT NULL,
  `cost` double NOT NULL,
  `priority` double NOT NULL,
  `access` int NOT NULL,
  `quality` double DEFAULT NULL,
  `rating` int DEFAULT NULL,
  `flag` int NOT NULL,
  `ext` int DEFAULT NULL,
  `exception` int DEFAULT NULL,
  `exceptionCls` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`),
  UNIQUE KEY `pk_R20_route09` (`id`),
  KEY `idx1` (`routeCls`,`oprId`,`pc`,`cls`),
  KEY `idx_list` (`routeCls`,`pc`,`prefixCode`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `r20_route11`
--

DROP TABLE IF EXISTS `r20_route11`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `r20_route11` (
  `id` int NOT NULL,
  `parentId` int DEFAULT NULL,
  `state` int NOT NULL,
  `reason` int DEFAULT NULL,
  `routeCls` int NOT NULL,
  `oprId` int NOT NULL,
  `pc` varchar(2) NOT NULL,
  `prefixCode` varchar(16) NOT NULL,
  `prefixLen` int NOT NULL,
  `destCode` varchar(32) DEFAULT NULL,
  `clsOrg` varchar(2) NOT NULL,
  `cls` varchar(2) NOT NULL,
  `costOrgCurr` varchar(4) NOT NULL,
  `costOrg` double NOT NULL,
  `cost` double NOT NULL,
  `priority` double NOT NULL,
  `access` int NOT NULL,
  `quality` double DEFAULT NULL,
  `rating` int DEFAULT NULL,
  `flag` int NOT NULL,
  `ext` int DEFAULT NULL,
  `exception` int DEFAULT NULL,
  `exceptionCls` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`),
  UNIQUE KEY `pk_r20_route11` (`id`),
  KEY `idx1` (`routeCls`,`oprId`,`pc`,`cls`),
  KEY `idx_list` (`routeCls`,`pc`,`prefixCode`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=458074 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `r20_route_timecls`
--

DROP TABLE IF EXISTS `r20_route_timecls`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `r20_route_timecls` (
  `id` int NOT NULL,
  `routecls` int NOT NULL,
  `oprId` int NOT NULL,
  `cls` varchar(1) NOT NULL,
  `pc` varchar(2) NOT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`),
  UNIQUE KEY `idx1` (`routecls`,`oprId`,`cls`,`pc`),
  UNIQUE KEY `PK_r20_route_timecls` (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=5453 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `r21_except`
--

DROP TABLE IF EXISTS `r21_except`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `r21_except` (
  `id` int NOT NULL,
  `routeSet` varchar(16) NOT NULL,
  `state` int NOT NULL,
  `leftPrefix` varchar(16) NOT NULL,
  `rightPrefix` varchar(16) NOT NULL,
  `oprId` int NOT NULL,
  `timecls` varchar(2) NOT NULL,
  `cost` double NOT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`),
  UNIQUE KEY `idx_1` (`routeSet`,`leftPrefix`,`rightPrefix`,`oprId`,`timecls`),
  UNIQUE KEY `PK_r21_except` (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `r_Oprprefix_ref`
--

DROP TABLE IF EXISTS `r_Oprprefix_ref`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `r_Oprprefix_ref` (
  `operator` varchar(30) NOT NULL,
  `domain` varchar(10) NOT NULL,
  `oprfullname` varchar(40) DEFAULT NULL,
  `prefixcode` varchar(40) NOT NULL,
  `startdate` datetime(6) DEFAULT NULL,
  `interval` int DEFAULT NULL,
  PRIMARY KEY (`operator`,`domain`,`prefixcode`),
  KEY `idx_oprpfxref_1` (`prefixcode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `r_daycode`
--

DROP TABLE IF EXISTS `r_daycode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `r_daycode` (
  `id` int NOT NULL,
  `d1` int NOT NULL,
  `d2` int NOT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`),
  UNIQUE KEY `PK_r_daycode` (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `r_domain`
--

DROP TABLE IF EXISTS `r_domain`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `r_domain` (
  `state` char(1) NOT NULL,
  `universe` varchar(8) NOT NULL,
  `name` varchar(8) NOT NULL,
  `longname` varchar(32) NOT NULL,
  `userinfo` varchar(128) DEFAULT NULL,
  `timezone` int NOT NULL,
  `reserved` varchar(64) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`),
  UNIQUE KEY `PK_r_domain` (`universe`,`name`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `r_holiday`
--

DROP TABLE IF EXISTS `r_holiday`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `r_holiday` (
  `domain` varchar(8) NOT NULL,
  `date` varchar(10) NOT NULL,
  `dayofyear` int NOT NULL,
  `comment` varchar(64) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`),
  UNIQUE KEY `PK__r_holiday__7E37BEF6` (`domain`,`date`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `r_info`
--

DROP TABLE IF EXISTS `r_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `r_info` (
  `timezone` int NOT NULL,
  `universe` varchar(8) DEFAULT NULL,
  `domain` varchar(32) DEFAULT NULL,
  `is_emergency` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `r_interface`
--

DROP TABLE IF EXISTS `r_interface`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `r_interface` (
  `id` int NOT NULL,
  `state` char(1) NOT NULL,
  `universe` varchar(8) NOT NULL,
  `domain` varchar(8) NOT NULL,
  `pdomain` varchar(8) DEFAULT NULL,
  `name` varchar(32) NOT NULL,
  `group` varchar(16) NOT NULL,
  `hint` varchar(128) DEFAULT NULL,
  `routecls` int NOT NULL,
  `allowloop` int NOT NULL,
  `intcls` int DEFAULT NULL,
  `userinfo` varchar(64) DEFAULT NULL,
  `reserved` varchar(64) DEFAULT NULL,
  `prefixcls` int DEFAULT NULL,
  `type` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`),
  UNIQUE KEY `PK_r_interface` (`id`),
  KEY `idx1` (`reserved`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=443 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `r_interfaceGroup`
--

DROP TABLE IF EXISTS `r_interfaceGroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `r_interfaceGroup` (
  `tintid` int NOT NULL,
  `IntGroupID` int NOT NULL,
  `flag` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`),
  UNIQUE KEY `PK_r_interfaceGroup` (`tintid`,`IntGroupID`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=3461 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `r_operatorset`
--

DROP TABLE IF EXISTS `r_operatorset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `r_operatorset` (
  `operatorset_id` int NOT NULL,
  `oprid` int NOT NULL,
  `state` tinyint unsigned DEFAULT NULL,
  `flag` tinyint unsigned DEFAULT NULL,
  `cost` double DEFAULT NULL,
  `quality` double DEFAULT NULL,
  `rating` int DEFAULT NULL,
  `priority` int DEFAULT NULL,
  `comment` varchar(128) DEFAULT NULL,
  `domain` varchar(8) DEFAULT NULL,
  `group` varchar(16) DEFAULT NULL,
  `interface` varchar(16) DEFAULT NULL,
  `userinfo` varchar(64) DEFAULT NULL,
  `oprtype` int DEFAULT NULL,
  `universe` varchar(8) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`),
  UNIQUE KEY `r_operatorset_idx1` (`operatorset_id`,`priority`),
  UNIQUE KEY `r_operatorset_idx` (`operatorset_id`,`oprid`,`domain`,`group`,`interface`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `r_prefix2`
--

DROP TABLE IF EXISTS `r_prefix2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `r_prefix2` (
  `state` varchar(1) NOT NULL,
  `pc` varchar(2) NOT NULL,
  `prefixcode` varchar(17) NOT NULL,
  `prefixlen` int NOT NULL,
  `destcode` varchar(32) NOT NULL,
  `prefixreg` varchar(8) DEFAULT NULL,
  `prefixcls` int DEFAULT NULL,
  `reserved` varchar(64) DEFAULT NULL,
  `routecls` int DEFAULT NULL,
  `interfacecls` int DEFAULT NULL,
  `local_mroute` int DEFAULT NULL,
  `local_mcost` double DEFAULT NULL,
  `tollfree_mroute` int DEFAULT NULL,
  `tollfree_mcost` double DEFAULT NULL,
  `mobile_mroute` int DEFAULT NULL,
  `mobile_mcost` double DEFAULT NULL,
  `payphone_mroute` int DEFAULT NULL,
  `payphone_mcost` double DEFAULT NULL,
  `countrycode` varchar(32) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`),
  UNIQUE KEY `PK_r_prefix2` (`prefixcode`),
  KEY `idx1` (`pc`,`prefixlen`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=190689 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `r_prefix_ref`
--

DROP TABLE IF EXISTS `r_prefix_ref`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `r_prefix_ref` (
  `prefixcode` varchar(17) NOT NULL,
  `Destcode` varchar(32) DEFAULT NULL,
  `oldDestcode` varchar(32) DEFAULT NULL,
  `Country` varchar(100) DEFAULT NULL,
  `Type` int DEFAULT NULL,
  `operator` varchar(100) DEFAULT NULL,
  `prefixlen` int DEFAULT NULL,
  PRIMARY KEY (`prefixcode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `r_rating`
--

DROP TABLE IF EXISTS `r_rating`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `r_rating` (
  `tintid` int NOT NULL,
  `prefixcode` varchar(17) NOT NULL,
  `rating` int DEFAULT NULL,
  `varInt` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`),
  UNIQUE KEY `PK__r_rating__3C3FDE67` (`tintid`,`prefixcode`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `r_timecls`
--

DROP TABLE IF EXISTS `r_timecls`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `r_timecls` (
  `id` int NOT NULL,
  `state` varchar(1) NOT NULL,
  `tintid` int NOT NULL,
  `cls` varchar(1) NOT NULL,
  `dc` int NOT NULL,
  `tc` int NOT NULL,
  `sc` int NOT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`),
  UNIQUE KEY `idx1` (`tintid`,`cls`,`dc`,`tc`,`sc`),
  UNIQUE KEY `PK_r_timecls` (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=5755 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `r_timecode`
--

DROP TABLE IF EXISTS `r_timecode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `r_timecode` (
  `id` int NOT NULL,
  `h1` int NOT NULL,
  `h2` int NOT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`),
  UNIQUE KEY `PK_r_timecode` (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=104 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `random_cli`
--

DROP TABLE IF EXISTS `random_cli`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `random_cli` (
  `operator` varchar(32) NOT NULL,
  `idx` int NOT NULL,
  `cli` varchar(20) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=10002 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `rls_info`
--

DROP TABLE IF EXISTS `rls_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rls_info` (
  `sitecode` varchar(3) NOT NULL,
  `interface` varchar(25) NOT NULL,
  `ir_group` varchar(25) NOT NULL,
  `cccount` int DEFAULT NULL,
  `call_direction` int DEFAULT NULL,
  `tgroup` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`sitecode`,`interface`,`ir_group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `rls_interface`
--

DROP TABLE IF EXISTS `rls_interface`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rls_interface` (
  `sitecode` text,
  `interface` text,
  `ir_group` text,
  `cccount` text,
  `call_direction` text,
  `tgroup` text,
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `temp1`
--

DROP TABLE IF EXISTS `temp1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `temp1` (
  `sitecode` varchar(3) DEFAULT NULL,
  `switchcode` char(3) DEFAULT NULL,
  `tgroup` varchar(15) DEFAULT NULL,
  `operator` varchar(15) DEFAULT NULL,
  `interface` varchar(50) DEFAULT NULL,
  `prefix` varchar(20) DEFAULT NULL,
  `xlatpfx` varchar(15) DEFAULT NULL,
  `numbertype` int DEFAULT NULL,
  `complaw` int DEFAULT NULL,
  `nbplan` int DEFAULT NULL,
  `signaddress` varchar(16) DEFAULT NULL,
  `callingnb` varchar(15) DEFAULT NULL,
  `callingcat` int DEFAULT NULL,
  `callingnbtype` int DEFAULT NULL,
  `isactive` int NOT NULL,
  `did_len` int DEFAULT NULL,
  `callingscreening` int DEFAULT NULL,
  `presentation` int DEFAULT NULL,
  `comment` varchar(30) DEFAULT NULL,
  `mindidlen` int DEFAULT NULL,
  `conntype` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `temp_109216_routingv2`
--

DROP TABLE IF EXISTS `temp_109216_routingv2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `temp_109216_routingv2` (
  `sitecode` varchar(3) DEFAULT NULL,
  `switchcode` char(3) DEFAULT NULL,
  `tgroup` varchar(15) DEFAULT NULL,
  `operator` varchar(15) DEFAULT NULL,
  `interface` varchar(50) DEFAULT NULL,
  `prefix` varchar(20) DEFAULT NULL,
  `xlatpfx` varchar(15) DEFAULT NULL,
  `numbertype` int DEFAULT NULL,
  `complaw` int DEFAULT NULL,
  `nbplan` int DEFAULT NULL,
  `signaddress` varchar(16) DEFAULT NULL,
  `callingnb` varchar(15) DEFAULT NULL,
  `callingcat` int DEFAULT NULL,
  `callingnbtype` int DEFAULT NULL,
  `isactive` int NOT NULL,
  `did_len` int DEFAULT NULL,
  `callingscreening` int DEFAULT NULL,
  `presentation` int DEFAULT NULL,
  `comment` varchar(30) DEFAULT NULL,
  `mindidlen` int DEFAULT NULL,
  `conntype` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=61689 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `temp_oni`
--

DROP TABLE IF EXISTS `temp_oni`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `temp_oni` (
  `sitecode` varchar(3) DEFAULT NULL,
  `switchcode` char(3) DEFAULT NULL,
  `tgroup` varchar(15) DEFAULT NULL,
  `operator` varchar(15) DEFAULT NULL,
  `interface` varchar(50) DEFAULT NULL,
  `prefix` varchar(20) DEFAULT NULL,
  `xlatpfx` varchar(15) DEFAULT NULL,
  `numbertype` int DEFAULT NULL,
  `complaw` int DEFAULT NULL,
  `nbplan` int DEFAULT NULL,
  `signaddress` varchar(16) DEFAULT NULL,
  `callingnb` varchar(15) DEFAULT NULL,
  `callingcat` int DEFAULT NULL,
  `callingnbtype` int DEFAULT NULL,
  `isactive` int NOT NULL,
  `did_len` int DEFAULT NULL,
  `callingscreening` int DEFAULT NULL,
  `presentation` int DEFAULT NULL,
  `comment` varchar(30) DEFAULT NULL,
  `mindidlen` int DEFAULT NULL,
  `conntype` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tempcallout`
--

DROP TABLE IF EXISTS `tempcallout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tempcallout` (
  `sitecode` varchar(3) DEFAULT NULL,
  `switchcode` char(3) DEFAULT NULL,
  `tgroup` varchar(15) DEFAULT NULL,
  `operator` varchar(15) DEFAULT NULL,
  `interface` varchar(50) DEFAULT NULL,
  `prefix` varchar(20) DEFAULT NULL,
  `xlatpfx` varchar(15) DEFAULT NULL,
  `numbertype` int DEFAULT NULL,
  `complaw` int DEFAULT NULL,
  `nbplan` int DEFAULT NULL,
  `signaddress` varchar(16) DEFAULT NULL,
  `callingnb` varchar(15) DEFAULT NULL,
  `callingcat` int DEFAULT NULL,
  `callingnbtype` int DEFAULT NULL,
  `isactive` int NOT NULL,
  `did_len` int DEFAULT NULL,
  `callingscreening` int DEFAULT NULL,
  `presentation` int DEFAULT NULL,
  `comment` varchar(30) DEFAULT NULL,
  `mindidlen` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=1642 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tempdata_callout_bm3`
--

DROP TABLE IF EXISTS `tempdata_callout_bm3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tempdata_callout_bm3` (
  `sitecode` varchar(3) DEFAULT NULL,
  `switchcode` char(3) DEFAULT NULL,
  `tgroup` varchar(15) DEFAULT NULL,
  `operator` varchar(15) DEFAULT NULL,
  `interface` varchar(50) DEFAULT NULL,
  `prefix` varchar(25) DEFAULT NULL,
  `xlatpfx` varchar(15) DEFAULT NULL,
  `numbertype` int DEFAULT NULL,
  `complaw` int DEFAULT NULL,
  `nbplan` int DEFAULT NULL,
  `signaddress` varchar(50) DEFAULT NULL,
  `callingnb` varchar(15) DEFAULT NULL,
  `callingcat` int DEFAULT NULL,
  `callingnbtype` int DEFAULT NULL,
  `isactive` int DEFAULT NULL,
  `did_len` int DEFAULT NULL,
  `callingscreening` int DEFAULT NULL,
  `presentation` int DEFAULT NULL,
  `comment` varchar(30) DEFAULT NULL,
  `mindidlen` int DEFAULT NULL,
  `conntype` int DEFAULT NULL,
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=19292 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tempxlat`
--

DROP TABLE IF EXISTS `tempxlat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tempxlat` (
  `sitecode` varchar(3) NOT NULL,
  `switchcode` varchar(3) NOT NULL,
  `prefix` varchar(15) NOT NULL,
  `trunkcode` varchar(8) NOT NULL,
  `direction` int DEFAULT NULL,
  `xlatpfx` varchar(20) DEFAULT NULL,
  `prefixlen` int DEFAULT NULL,
  `pc` char(2) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=95 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tempxlatt`
--

DROP TABLE IF EXISTS `tempxlatt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tempxlatt` (
  `sitecode` varchar(3) NOT NULL,
  `switchcode` varchar(3) NOT NULL,
  `prefix` varchar(15) NOT NULL,
  `trunkcode` varchar(8) NOT NULL,
  `direction` int DEFAULT NULL,
  `xlatpfx` varchar(20) DEFAULT NULL,
  `prefixlen` int DEFAULT NULL,
  `pc` char(2) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `test_bcp`
--

DROP TABLE IF EXISTS `test_bcp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `test_bcp` (
  `sitecode` varchar(3) DEFAULT NULL,
  `switchcode` char(3) DEFAULT NULL,
  `tgroup` varchar(15) DEFAULT NULL,
  `operator` varchar(15) DEFAULT NULL,
  `interface` varchar(50) DEFAULT NULL,
  `prefix` varchar(20) DEFAULT NULL,
  `xlatpfx` varchar(15) DEFAULT NULL,
  `numbertype` int DEFAULT NULL,
  `complaw` int DEFAULT NULL,
  `nbplan` int DEFAULT NULL,
  `signaddress` varchar(16) DEFAULT NULL,
  `callingnb` varchar(15) DEFAULT NULL,
  `callingcat` int DEFAULT NULL,
  `callingnbtype` int DEFAULT NULL,
  `isactive` int NOT NULL,
  `did_len` int DEFAULT NULL,
  `callingscreening` int DEFAULT NULL,
  `presentation` int DEFAULT NULL,
  `comment` varchar(30) DEFAULT NULL,
  `mindidlen` int DEFAULT NULL,
  `conntype` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=41772 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `xlat`
--

DROP TABLE IF EXISTS `xlat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `xlat` (
  `sitecode` varchar(3) DEFAULT NULL,
  `switchcode` varchar(3) DEFAULT NULL,
  `prefix` varchar(20) DEFAULT NULL,
  `trunkcode` varchar(16) DEFAULT NULL,
  `direction` int DEFAULT NULL,
  `xlatpfx` varchar(20) DEFAULT NULL,
  `prefixlen` int DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB AUTO_INCREMENT=657 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `xlatout`
--

DROP TABLE IF EXISTS `xlatout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `xlatout` (
  `sitecode` varchar(3) NOT NULL,
  `switchcode` varchar(3) NOT NULL,
  `trunkcode` varchar(8) NOT NULL,
  `mode` int NOT NULL,
  `prefix` varchar(20) NOT NULL,
  `nbtype` int NOT NULL,
  `xlatpfx` varchar(30) NOT NULL,
  `xlatNBtype` int NOT NULL,
  `comment` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`sitecode`,`switchcode`,`trunkcode`,`mode`,`prefix`,`nbtype`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping events for database 'routingv2_voip'
--

--
-- Dumping routines for database 'routingv2_voip'
--
/*!50003 DROP PROCEDURE IF EXISTS `cls00_get_route` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `cls00_get_route`(v_pDDI            VARCHAR(32)
   ,v_pDate          DATETIME(3)
   ,v_pSrcInt        VARCHAR(7)    
   ,v_pSrcIntGroup   VARCHAR(64)   
   ,v_pSrcIntDom     VARCHAR(64)   
   ,v_pCLI           VARCHAR(32))
begin


   DECLARE v_cls INT;
   DECLARE v_sql VARCHAR(1024);
   IF v_pCLI is null then
      set v_pCLI = '';
   END IF;
   select   intcls INTO v_cls from r_interface where name = v_pSrcInt and `domain` = v_pSrcIntDom;
   if v_cls is null then
   
      set v_cls = 11;
   end if;
   set v_sql = 'exec cls' || ltrim(v_cls) || '_get_route';
   set v_sql = v_sql || ' ''' || v_pDDI || '''';
   set v_sql = v_sql || ',''' || DATE_FORMAT(v_pDate,'%Y-%m-%d %T') || '''';
   set v_sql = v_sql || ',''' || v_pSrcInt || '''';
   set v_sql = v_sql || ',''' || v_pSrcIntGroup || '''';
   set v_sql = v_sql || ',''' || v_pSrcIntDom || '''';
   set v_sql = v_sql || ', ''' || v_pCLI || '''';   
   SET @SWV_Stmt = v_sql;
   PREPARE SWT_Stmt FROM @SWV_Stmt;
   EXECUTE SWT_Stmt;
   DEALLOCATE PREPARE SWT_Stmt;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `cls11_get_route_debug` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `cls11_get_route_debug`(v_pDDI            VARCHAR(32)
   ,v_pDate          DATETIME(3)
   ,v_pSrcInt        VARCHAR(7)    
   ,v_pSrcIntGroup   VARCHAR(64)   
   ,v_pSrcIntDom     VARCHAR(64)   
   ,v_pRouteCls      INT 
   ,v_pCLI           VARCHAR(32))
begin

   
   IF v_pRouteCls is null then
      set v_pRouteCls = 0;
   END IF;
   IF v_pCLI is null then
      set v_pCLI = '';
   END IF;
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select isactive, routecls, dprefixcode prefixcode, universe, `domain`, pdomain, `group`, interface, userinfo, hint, timecls, priority, cost, flag
   from(select x.isactive, x.routecls, x.dprefixcode, ty.universe, ty.`domain` `domain`, ty.pdomain pdomain, ty.`group` `group`, ty.name interface,
   ty.hint, ty.userinfo, x.cls timecls, x.priority, x.cost, x.flag
      from(select a.* from r01_route a 
         where (a.dpc = SUBSTR(v_pDDI,1,2))
         and a.dprefixcode =(select  prefixcode
            from r_prefix1 
            where (pc = SUBSTR(v_pDDI,1,2))
            and state = 'I'
            and v_pDDI like CONCAT(prefixcode,'%')
            order by prefixlen desc LIMIT 1)
         and sc = 0) x, r_interface ty,
   r_domain d,
   r_timecode t, r_daycode td,
   r_info curr 
      where x.tintid = ty.id and ty.state = 'I'
      and (v_pSrcInt = '' or (x.sintid = 0) or (x.sintid =(select  id from r_interface  where name = v_pSrcInt and `domain` = v_pSrcIntDom LIMIT 1)))
      and ty.`domain` = d.name
      and x.dc = td.id
      and td.d1 <= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
      and td.d2 >= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
      and x.tc = t.id
      and t.h1 <=(((24+EXTRACT(HOUR FROM v_pDate)+d.timezone -curr.timezone)%24)*100+EXTRACT(MONTH FROM v_pDate))
      and t.h2 >(((24+EXTRACT(HOUR FROM v_pDate)+d.timezone -curr.timezone)%24)*100+EXTRACT(MONTH FROM v_pDate))) z
   order by z.priority;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `cr_get_operatorset` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `cr_get_operatorset`(id INT)
begin
 
 
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select z.* from(select y.universe, y.`domain`, y.pdomain,y.`group`, y.name interface, y.userinfo,
 		y.hint, IFNULL(y.type,1) oprtype,
 		x.cost, x.flag, x.rating, x.quality, x.priority
       from r_operatorset x, r_interface y 
       where
       x.operatorset_id = id and x.state = 1 and
       x.oprId = y.id
       union
       select universe, `domain`, `domain` pdomain, `group`, interface, userinfo,
 		null hint, IFNULL(oprtype,1) oprtype,
 		cost, flag, rating, quality, priority
       from r_operatorset
       where
       operatorset_id = id and oprid = -1) z
    order by z.priority;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;	
 
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `cr_get_operatorset_old` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `cr_get_operatorset_old`(v_id INT)
begin


   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select * from r_operatorset_old  where operatorset_id = v_id order by priority;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `cs_get_xlatout` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `cs_get_xlatout`(v_sitecode CHAR(8),
v_switchcode CHAR(3),
v_trunkcode CHAR(16),
v_prefix CHAR(30),
v_nbtype INT,
v_mode INT)
begin

      
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select * from xlatout 
   where sitecode = v_sitecode
   and (switchcode = v_switchcode or switchcode = '*')
   and (trunkcode = v_trunkcode  or trunkcode = '*')
   and mode = v_mode
   and SUBSTRING(v_prefix,1, CHAR_LENGTH(prefix)) = prefix
   and nbtype = v_nbtype
   order by switchcode desc,trunkcode desc, CHAR_LENGTH(prefix) desc LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `emg_get_route` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `emg_get_route`(v_pDDI VARCHAR(32),                        
   v_pDate DATETIME(3),                        
   v_pSrcInt VARCHAR(7),                        
   v_pSrcIntGroup VARCHAR(64),                        
   v_pSrcIntDom VARCHAR(64),                        
   v_routeclass INT  ,                    
   v_pCLI VARCHAR(32),                        
   v_pOperatorGroup INT)
begin

 


   DECLARE v_longestPrefixcode VARCHAR(16);                        
   DECLARE v_longestCls INT;
   DECLARE v_nearestTime VARCHAR(17);                        


                                     
   IF v_routeclass is null then
      set v_routeclass = 0;
   END IF;
   IF v_pCLI is null then
      set v_pCLI = '';
   END IF;
   IF v_pOperatorGroup is null then
      set v_pOperatorGroup = 0;
   END IF;
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   prefixcode, prefixCls INTO v_longestPrefixcode,v_longestCls from r_prefix2  where pc = left(v_pDDI,2) and v_pDDI like CONCAT_WS('',prefixcode,'%')   order by prefixlen desc LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

   if v_longestCls is null then 
      set v_longestCls = 0;
   end if;

   CALL r22_routeGetNearestTime(v_pDate,v_nearestTime);
   if v_longestCls in(3,4) then
      CALL r24_routeSpecialGetCache(v_longestPrefixcode,v_pDate,v_pSrcInt,v_pSrcIntGroup,v_pSrcIntDom,v_routeclass,
      v_pCLI,v_pOperatorGroup);
   else
      CALL emg_routeGetCache(v_longestPrefixcode,v_longestCls,v_pDate,v_pSrcInt,v_pSrcIntGroup,v_pSrcIntDom,
      v_routeclass,v_pCLI,v_pOperatorGroup,0);
   end if;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `emg_routeGetCache` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `emg_routeGetCache`(v_pLongest VARCHAR(32),                                    
   v_pLongestCls INT,            
   v_pDate DATETIME(3),                                    
   v_pSrcInt VARCHAR(7),                                    
   v_pSrcIntGroup VARCHAR(64),                                    
   v_pSrcIntDom VARCHAR(64),                                    
   v_routeclass INT  ,                                
   v_pCLI VARCHAR(32),                                    
   v_pOperatorGroup INT    ,      
   v_isgrade INT)
begin

   DECLARE v_pc VARCHAR(2);                                    
   DECLARE v_dd INT;      
   DECLARE v_hh INT;      
   DECLARE v_mm INT;   
   DECLARE v_dadomain VARCHAR(100);   
   DECLARE v_gmt DATETIME(3);  
                                   

   IF v_routeclass is null then
      set v_routeclass = 0;
   END IF;
   IF v_pCLI is null then
      set v_pCLI = '';
   END IF;
   IF v_pOperatorGroup is null then
      set v_pOperatorGroup = 0;
   END IF;
   IF v_isgrade is null then
      set v_isgrade = 0;
   END IF;
   set v_pc = left(v_pLongest,2);  


                                  
   set v_dd = 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7;      
   select   `domain`, (EXTRACT(HOUR FROM v_pDate) -timezone) INTO v_dadomain,v_hh from r_info;       
   set v_mm = EXTRACT(MINUTE FROM v_pDate);      
                            
      

   DROP TEMPORARY TABLE IF EXISTS tt_operator_selected;      
   CREATE TEMPORARY TABLE tt_operator_selected 
   (
      routecls INT NOT NULL,
      oprId INT NOT NULL,
      cls VARCHAR(1) NOT NULL,
      pc VARCHAR(2) NOT NULL
   );      
      
   CREATE  UNIQUE  INDEX idx1 ON tt_operator_selected
   (routecls, 
   oprId, 
   cls, 
   pc);      
      
      
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   insert into tt_operator_selected(routecls,oprid,cls,pc)
   select x.routecls,x.oprid,x.cls,x.pc  from r20_route_timecls x, r_TimeCls y, r_interface tit,
r_timecode tco, r_daycode dco 
   where x.routecls = 0
   and tit.id = x.oprid and tit.state = 'I'
   and y.tintid = x.oprid and y.cls = x.cls
   and y.dc = dco.id and y.tc = tco.id and y.sc = 0
   and v_dd between dco.d1 and dco.d2
   and((24+v_hh+IFNULL(tit.prefixcls,0))%24)*100+v_mm between tco.h1 and tco.h2 -1
   and x.pc = v_pc        and tit.`domain` = v_dadomain;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;     
      
      
   DROP TEMPORARY TABLE IF EXISTS tt_timecls_selected;     
      
   CREATE TEMPORARY TABLE tt_timecls_selected 
   (
      routecls INT NOT NULL,
      oprId INT NOT NULL,
      pc VARCHAR(2) NOT NULL,
      prefixcode VARCHAR(50) NOT NULL,
      cnt INT,
      clsA INT,
      clsP INT,
      clsO INT,
      clsW INT,
      cls VARCHAR(1) NOT NULL
   );       
      
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   insert into tt_timecls_selected(routecls,oprid,pc,prefixcode,cnt,clsA,clsP,clsO,clsW,cls)
   select a.routecls, a.oprid, a.pc, max(a.prefixCode) prefixCode,
 count(*) cnt,
 sum(case when a.cls = 'A' then 1 else 0 end) clsA,
 sum(case when a.cls = 'P' then 1 else 0 end) clsP,
 sum(case when a.cls = 'O' then 1 else 0 end) clsO,
 sum(case when a.cls = 'W' then 1 else 0 end) clsW, 'Z' cls
   from r20_route07 a, tt_operator_selected b
   where a.routeCls = b.routeCls and a.oprId = b.oprId and a.cls = b.cls and a.pc = b.pc
   and left(v_pLongest,prefixLen) = a.prefixcode
   group by a.routecls,a.oprid,a.pc;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;        
     
   update tt_timecls_selected
   set cls =(case when (clsW > 0) and (cnt = clsW) then 'W'
   when (clsO > 0) and (cnt = clsO) then 'O'
   when (clsP > 0) and (cnt = clsP) then 'P'
   when (clsA > 0) and (cnt = clsA) then 'A'
   else 'Z' end);      
      
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   update tt_timecls_selected
   set cls =(select max(a.cls) from r20_route07 a 
   where a.routecls = tt_timecls_selected.routecls
   and a.oprid = tt_timecls_selected.oprId
   and a.pc = tt_timecls_selected.pc
   and a.prefixCode = tt_timecls_selected.prefixCode
   and ((a.cls = 'A' and tt_timecls_selected.clsA <> 0) or
          (a.cls = 'P' and tt_timecls_selected.clsP <> 0) or
          (a.cls = 'O' and tt_timecls_selected.clsO <> 0) or
          (a.cls = 'W' and tt_timecls_selected.clsW <> 0)))
   where cls = 'Z';
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;      
      
   DROP TEMPORARY TABLE IF EXISTS tt_route;      
      
   CREATE TEMPORARY TABLE tt_route 
   (
      seqno INT   AUTO_INCREMENT PRIMARY KEY,
      priority INT,
      id INT,
      isactive INT,
      reason INT,
      `exception` INT,
      calcexception INT,
      ext INT,
      oprid INT,
      parentid INT,
      routecls INT,
      prefixcode VARCHAR(50),
      universe VARCHAR(5),
      `domain` VARCHAR(5),
      pdomain VARCHAR(5),
      `group` VARCHAR(40),
      interface VARCHAR(40),
      userinfo VARCHAR(40),
      hint VARCHAR(100),
      clsorg CHAR(1),
      cls CHAR(1),
      cost FLOAT,
      flag INT,
      rating INT,
      access VARCHAR(10),
      redlist INT,
      quality FLOAT,
      exceptioncls INT
   )  AUTO_INCREMENT = 10;      
      
      
   if v_isgrade = 0 then

      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      insert into tt_route(isactive,reason,`exception`,calcexception,id,parentid,routecls,oprid,prefixcode,clsorg,cls,cost,
priority,rating,flag,ext,quality,exceptioncls)
      select
      x.state isactive, x.reason,
  IFNULL(x.`exception`,0) `exception`,
  case
      when ((IFNULL(x.`exception`,0) = 0)) then 0
      when x.`exception` > 0 then cast((x.`exception`+0.5)*10 as SIGNED INTEGER)
      else cast((x.`exception` -0.5)*10 as SIGNED INTEGER)
      end calcException,
  x.id, x.parentId, x.routeCls, x.oprId, x.prefixCode, x.clsOrg, x.cls,
  x.cost, x.priority, rating, x.flag, x.ext,x.quality,x.exceptioncls
      from r20_route07 x, tt_timecls_selected b
      where x.routecls = b.routecls and x.oprid = b.oprid and x.pc = b.pc and x.prefixcode = b.prefixcode and x.cls = b.cls
      order by x.cost;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   else
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      insert into tt_route(isactive,reason,`exception`,calcexception,id,parentid,routecls,oprid,prefixcode,clsorg,cls,cost,
priority,rating,flag,ext,quality,exceptioncls)
      select
      x.state isactive, x.reason,
  IFNULL(x.`exception`,0) `exception`,
  case
      when ((IFNULL(x.`exception`,0) = 0)) then 0
      when x.`exception` > 0 then cast((x.`exception`+0.5)*10 as SIGNED INTEGER)
      else cast((x.`exception` -0.5)*10 as SIGNED INTEGER)
      end calcException,
  x.id, x.parentId, x.routeCls, x.oprId, x.prefixCode, x.clsOrg, x.cls,
  x.cost, x.priority, rating, x.flag, x.ext,x.quality,x.exceptioncls
      from r20_route07 x, tt_timecls_selected b
      where x.routecls = b.routecls and x.oprid = b.oprid and x.pc = b.pc and x.prefixcode = b.prefixcode and x.cls = b.cls
      order by x.quality,x.cost;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   end if;      
      
          
          
                            
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select
   'r20_route07' routeset,
   x.seqno priority, x.id, x.isactive, x.reason, x.`exception`, IFNULL(x.ext,0) ext,
  x.routecls, x.prefixcode, y.universe, y.`domain`, y.pdomain,
    y.`group`, y.name interface, y.userinfo, y.hint, x.clsOrg, x.cls timecls, x.cost, x.flag, x.rating,
 '11111' access, 0 redlist,x.quality grade,IFNULL(y.intcls,0) intcls,x.exceptioncls capability, IFNULL(y.type,1) oprtype
   from tt_route x, r_interface y, r_interfaceGroup ig 
   where x.oprId = y.id and ig.tintid = x.oprId and ig.intgroupid = v_pOperatorGroup and ig.flag = 1 and x.isactive = 1
   and v_pLongest like CONCAT(x.prefixcode,'%')
   order by seqno+calcException;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;                            
  
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es05_get_ceilcost` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `es05_get_ceilcost`(v_sitecode VARCHAR(5),
  v_switchcode VARCHAR(5),
  v_prefix VARCHAR(12))
begin


   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select  'ALL' sitecode, 'ALL' swichcode, b.prefixcode prefix, b.destcode, a.ccost ceilingcost, a.eccost emergencycost, 0 emergency, 0 autoroute
   from rs01_cost a, r_prefix1 b 
   where a.prefixcode = b.prefixcode
   and v_prefix like CONCAT(b.prefixcode,'%')
   order by b.prefixlen desc LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es05_get_timecode` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `es05_get_timecode`(v_pDate   DATETIME(3))
begin


   if v_pDate is null then 
      set v_pDate = CURRENT_TIMESTAMP;
   end if;
   select id code from r_timecode
   where h1 <=(EXTRACT(HOUR FROM v_pDate)*100+EXTRACT(MONTH FROM v_pDate))
   and h2 >(EXTRACT(HOUR FROM v_pDate)*100+EXTRACT(MONTH FROM v_pDate));
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es07_get_route0` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `es07_get_route0`(v_pDDI            VARCHAR(32)
   ,v_pDate          DATETIME(3)
   ,v_pSrcInt        VARCHAR(7)    
   ,v_pSrcIntGroup   VARCHAR(64)   
   ,v_pSrcIntDom     VARCHAR(64)   
   ,v_pCLI           VARCHAR(32))
begin

   
   IF v_pCLI is null then
      set v_pCLI = '';
   END IF;
   CALL cls00_get_route(v_pDDI,v_pDate,v_pSrcInt,v_pSrcIntGroup,v_pSrcIntDom,v_pCLI);
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es3_get_xlat` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `es3_get_xlat`(v_sitecode VARCHAR(3),
 v_prefix VARCHAR(30),  
 v_trunkcode VARCHAR(16),  
 v_direction INT,   
 v_switchcode VARCHAR(3))
begin

    
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select * from xlat 
   where sitecode = v_sitecode
   and prefix = left(v_prefix,prefixlen)
   and trunkcode = v_trunkcode
   and direction = v_direction
   and (switchcode = v_switchcode or switchcode = 'ALL')
   order by switchcode,prefix desc;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;    
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es4_get_prefix` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `es4_get_prefix`(v_dialednum CHAR(30))
begin

    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select * from r_prefix1 
    where pc = SUBSTRING(v_dialednum,1,2)
    and prefixcode = SUBSTRING(v_dialednum,1,prefixlen)
    order by prefixlen desc LIMIT 1;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es4_get_xlat` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `es4_get_xlat`(v_sitecode VARCHAR(3),v_prefix VARCHAR(30),v_trunkcode VARCHAR(16),v_direction INT, v_switchcode VARCHAR(3))
begin


   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select * from xlat 
   where sitecode = v_sitecode
   and prefix = left(v_prefix,prefixlen)
   and trunkcode = v_trunkcode
   and direction = v_direction
   and (switchcode = v_switchcode or switchcode = 'ALL')
   order by switchcode,prefix desc;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es5_get_config` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `es5_get_config`(v_opr VARCHAR(16),
v_pfx VARCHAR(20))
begin


   select * from cswitch_config
   where (operator = v_opr or operator = '*')
   and   (left(v_pfx, CHAR_LENGTH(prefix)) = prefix  or prefix = '*')
   order by operator desc,prefix desc; 
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es5_xlat_callout` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `es5_xlat_callout`(v_sitecode VARCHAR(3), v_switchcode CHAR(3), v_prefix VARCHAR(30),v_group VARCHAR(16),v_operator VARCHAR(16),v_interface VARCHAR(10))
SWL_return:
 begin
 
   declare v_found int;
 
    if v_prefix like '%MBE%' then
   
       SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
       select * from callout 
       where sitecode = v_sitecode
       and (switchcode = v_switchcode or switchcode = 'ALL')
       and v_prefix like CONCAT_WS('',prefix,'%')
       and (tgroup = v_group or tgroup = '')
       and (operator = v_operator or operator = '')
       and (interface = v_interface or interface = '')
       order by switchcode,operator desc,interface desc, CHAR_LENGTH(prefix) desc;
       SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
       LEAVE SWL_return;
    end if;
 
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    
    set v_found  = 0 ;
    
    SELECT 1 into v_found FROM  callout  where sitecode = v_sitecode
    and (switchcode = v_switchcode or switchcode = 'ALL')
    and v_prefix like CONCAT_WS('',prefix,'%')
    and (tgroup = v_group or tgroup = '')
    and (operator = v_operator or operator = '')
    and (interface = v_interface or interface = '') limit 1;

	if v_found=0 then 
		select * from callout 
		where sitecode = v_sitecode
		and (switchcode = v_switchcode or switchcode = 'ALL')
		and (tgroup = v_group or tgroup = '')
		and (operator = v_operator or operator = '')
		and (interface = v_interface or interface = '')
		order by switchcode,operator desc,interface desc,prefix desc;
        
        leave SWL_return;
    end if;

	select * from callout 
    where sitecode = v_sitecode
    and (switchcode = v_switchcode or switchcode = 'ALL')
    and v_prefix like CONCAT_WS('',prefix,'%')
    and (tgroup = v_group or tgroup = '')
    and (operator = v_operator or operator = '')
    and (interface = v_interface or interface = '')
    order by switchcode,operator desc,interface desc,prefix desc;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es5_xlat_callout_backup_20230616` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `es5_xlat_callout_backup_20230616`(v_sitecode VARCHAR(3), v_switchcode CHAR(3), v_prefix VARCHAR(30),v_group VARCHAR(16),v_operator VARCHAR(16),v_interface VARCHAR(10))
SWL_return:
 begin
 
   
 
    if v_prefix like '%MBE%' then
   
       SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
       select * from callout 
       where sitecode = v_sitecode
       and (switchcode = v_switchcode or switchcode = 'ALL')
       and v_prefix like CONCAT_WS('',prefix,'%')
       and (tgroup = v_group or tgroup = '')
       and (operator = v_operator or operator = '')
       and (interface = v_interface or interface = '')
       order by switchcode,operator desc,interface desc, CHAR_LENGTH(prefix) desc;
       SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
       LEAVE SWL_return;
    end if;
 
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select * from callout 
    where sitecode = v_sitecode
    and (switchcode = v_switchcode or switchcode = 'ALL')
    and v_prefix like CONCAT_WS('',prefix,'%')
    and (tgroup = v_group or tgroup = '')
    and (operator = v_operator or operator = '')
    and (interface = v_interface or interface = '')
    order by switchcode,operator desc,interface desc,prefix desc;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `es5_xlat_callout_logu` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `es5_xlat_callout_logu`(v_sitecode VARCHAR(3), v_switchcode CHAR(3), v_prefix VARCHAR(30),v_group VARCHAR(16),v_operator VARCHAR(16),v_interface VARCHAR(10))
SWL_return:
 begin
 
   declare v_found int;
 
    if v_prefix like '%MBE%' then
   
       SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
       select * from callout 
       where sitecode = v_sitecode
       and (switchcode = v_switchcode or switchcode = 'ALL')
       and v_prefix like CONCAT_WS('',prefix,'%')
       and (tgroup = v_group or tgroup = '')
       and (operator = v_operator or operator = '')
       and (interface = v_interface or interface = '')
       order by switchcode,operator desc,interface desc, CHAR_LENGTH(prefix) desc;
       SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
       LEAVE SWL_return;
    end if;
 
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    
    set v_found  = 0 ;
    
    SELECT 1 into v_found FROM  callout  where sitecode = v_sitecode
    and (switchcode = v_switchcode or switchcode = 'ALL')
    and v_prefix like CONCAT_WS('',prefix,'%')
    and (tgroup = v_group or tgroup = '')
    and (operator = v_operator or operator = '')
    and (interface = v_interface or interface = '') limit 1;

	if v_found=0 then 
		select * from callout 
		where sitecode = v_sitecode
		and (switchcode = v_switchcode or switchcode = 'ALL')
		and (tgroup = v_group or tgroup = '')
		and (operator = v_operator or operator = '')
		and (interface = v_interface or interface = '')
		order by switchcode,operator desc,interface desc,prefix desc;
        
        leave SWL_return;
    end if;

	select * from callout 
    where sitecode = v_sitecode
    and (switchcode = v_switchcode or switchcode = 'ALL')
    and v_prefix like CONCAT_WS('',prefix,'%')
    and (tgroup = v_group or tgroup = '')
    and (operator = v_operator or operator = '')
    and (interface = v_interface or interface = '')
    order by switchcode,operator desc,interface desc,prefix desc;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `esp_getxlat_in` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `esp_getxlat_in`(v_site VARCHAR(3),  
v_machid VARCHAR(3),  
v_trunkin VARCHAR(8),  
v_phone VARCHAR(20),  
v_type INT)
begin

  
   if left(v_phone,3) = 'LYC' then 
      select  '' xlatin, 'LYC' prefix;
   else 
      select  '*' xlatin, '*' prefix;
   end if;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `esp_getxlat_in2` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `esp_getxlat_in2`(v_site VARCHAR(3),  
v_machid VARCHAR(3),  
v_trunkin VARCHAR(8),  
v_phone VARCHAR(20),  
v_type INT)
begin

  
   if left(v_phone,3) = 'LYC' then 
      select  'LYC' xlatin, '' prefix;
   else 
      select  '*' xlatin, '*' prefix;
   end if;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `esp_getxlat_interdomain` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `esp_getxlat_interdomain`(v_sitein VARCHAR(4),
v_switchin VARCHAR(4),
v_siteout VARCHAR(4),
v_operatorout VARCHAR(15),
v_phone VARCHAR(30))
begin


   select * from XlatInterDomain where
 (sitecode_in = v_sitein or sitecode_in = '*') and
 (switchcode_in = v_switchin or switchcode_in = '*') and
 (sitecode_out = v_siteout) and
 (operator_out = v_operatorout or operator_out = '*') and
 (prefix = left(v_phone,prefixlen) or prefix = '*')
   order by prefixlen desc,sitecode_in desc,switchcode_in desc,sitecode_out,operator_out desc LIMIT 1; 
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `esp_getxlat_out` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `esp_getxlat_out`(v_site VARCHAR(3),
v_machid VARCHAR(3),
v_trunkout VARCHAR(8),
v_phone VARCHAR(20),
v_interface VARCHAR(20))
begin


   IF v_interface is null then
      set v_interface = '';
   END IF;
   select  xlatpfx xlatout, prefix,numbertype nbtype,
            complaw,nbplan,signaddress,callingnb,
    callingcat,callingnbtype, did_len, mindidlen,
    callingscreening, presentation, conntype, isactive,
    callingnb
   from callout
   where sitecode = v_site
   and (switchcode = v_machid or switchcode = 'ALL')
   and v_phone like CONCAT_WS('',prefix,'%')
   and tgroup = v_trunkout
   and (operator = v_trunkout or operator = '')
   and (interface = v_interface or interface = '')
   order by switchcode,operator desc,interface desc,prefix desc LIMIT 1; 
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `esp_get_operator` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `esp_get_operator`(v_site VARCHAR(3),
  v_machid VARCHAR(3),
  v_trunk VARCHAR(8))
begin


   select 1 islogged;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getcalloutTrunkCredentials` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `getcalloutTrunkCredentials`(ptrunkIP varchar(50))
BEgin
 select trunkIP, userName, password from routingv2_voip.calloutTrunkIPCredentials where trunkIP = ptrunkIP;
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetOperatorCostSum` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `GetOperatorCostSum`(v_whatopr VARCHAR(10))
begin


   DECLARE v_cdate VARCHAR(10);
   DECLARE v_comment VARCHAR(64);
   DECLARE v_currcostb FLOAT;
   set v_cdate = DATE_FORMAT(CURRENT_TIMESTAMP,'%Y-%m-%d');    

   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   IFNULL(sum(costb),0) INTO v_currcostb from monitor  where calldate = v_cdate and operator = v_whatopr;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

   set v_comment = CONCAT_WS('',v_whatopr,' - ',convert(v_currcostb,CHAR(14)));

   insert into gocs_log(`date`, comment) values(CURRENT_TIMESTAMP, v_comment);
 
 
   select v_currcostb;
      
 
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_callcause` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `get_callcause`(v_cause INT,
   v_oper VARCHAR(16))
begin


   
   if v_oper is null then    
      set v_oper = 'all';
   end if;
   select * from causecode
   where code = v_cause
   and (operator = v_oper or operator = '*' or operator = 'ALL')
   order by operator desc;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_callcause_message` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `get_callcause_message`(v_cause INT,
   v_oper VARCHAR(16))
begin

   if v_oper is null then 
      set v_oper = 'all';
   end if;
   select causecode.*, SUBSTRING(name,4, CHAR_LENGTH(name) -3) message from causecode
   where code = v_cause
   and (operator = v_oper or operator = '*')
   order by operator desc;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_monitor` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `get_monitor`(v_cdate VARCHAR(10),
 v_swc VARCHAR(5),
 v_chnl VARCHAR(8))
begin


   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select id from monitor 
   where calldate   = v_cdate
   and   switchcode = v_swc
   and   channel    = v_chnl;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_randomcli` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `get_randomcli`(v_opr VARCHAR(16),
v_idx INT)
begin


  
   select idx,cli from random_cli
   where operator = v_opr
   and idx = v_idx*(select max(idx) from random_cli)/100;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_randomcli_byidx` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `get_randomcli_byidx`(v_opr VARCHAR(16),
v_idx INT)
begin


  
   select idx,cli from random_cli
   where operator = v_opr
   and idx = v_idx;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_redlist` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `get_redlist`(v_dom VARCHAR(3),  
v_opr VARCHAR(12),  
v_prefix VARCHAR(20))
Begin

  
   select v_prefix prefixcode,0 destblock; 



End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `insert_monitor` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `insert_monitor`(v_cdate VARCHAR(10),
 v_swc VARCHAR(5),
 v_opr VARCHAR(16),
 v_chnl VARCHAR(8),
 v_tt INT,
 v_costb FLOAT)
begin


   insert into monitor(calldate,switchcode,operator,channel,talktime_sec,talktime_min,costb)
   values(v_cdate, v_swc, v_opr, v_chnl, v_tt, round(v_tt/60+0.5,0), v_costb);
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `insert_oprtraffic_A` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `insert_oprtraffic_A`(v_domain VARCHAR(8), v_operator VARCHAR(32), v_prefixcode VARCHAR(32), v_nbattempts INT,
v_nbconnected INT, v_legatime INT, v_legbtime INT)
begin


   update r_oprtraffic
   set
   nbattempts = nbattempts+v_nbattempts,nbconnected = nbconnected+v_nbconnected,
   legatime = legatime+v_legatime,legbtime = legbtime+v_legbtime
   where `domain` = v_domain and operator = v_operator and prefixcode = v_prefixcode;

   if ROW_COUNT() = 0 then
      insert into r_oprtraffic(`domain`, operator, prefixcode, nbattempts, nbconnected, legatime, legbtime)
                values(v_domain, v_operator, v_prefixcode, v_nbattempts, v_nbconnected, v_legatime, v_legbtime);
   end if;

   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select * from r_oprtraffic  where `domain` = v_domain and operator = v_operator and prefixcode =
   v_prefixcode LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `insert_oprtraffic_B` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `insert_oprtraffic_B`(v_domain VARCHAR(8), v_operator VARCHAR(32), v_prefixcode VARCHAR(32), v_nbattempts INT,
v_nbconnected INT, v_legatime INT, v_legbtime INT)
begin


   update r_oprtraffic2
   set
   nbattempts = nbattempts+v_nbattempts,nbconnected = nbconnected+v_nbconnected,
   legatime = legatime+v_legatime,legbtime = legbtime+v_legbtime
   where `domain` = v_domain and operator = v_operator and prefixcode = v_prefixcode;

   if ROW_COUNT() = 0 then
      insert into r_oprtraffic2(`domain`, operator, prefixcode, nbattempts, nbconnected, legatime, legbtime)
                values(v_domain, v_operator, v_prefixcode, v_nbattempts, v_nbconnected, v_legatime, v_legbtime);
   end if;

   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select * from r_oprtraffic2  where `domain` = v_domain and operator = v_operator and prefixcode
   = v_prefixcode LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `insert_oprtraffic_X` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `insert_oprtraffic_X`(v_domain VARCHAR(8), v_operator VARCHAR(32), v_prefixcode VARCHAR(32), v_nbattempts INT,
v_nbconnected INT, v_legatime INT, v_legbtime INT)
SWL_return:
begin


   DECLARE v_curr_tab VARCHAR(64);
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   IFNULL(tblname,'r_oprtraffic') INTO v_curr_tab from r_curr_oprtraffic;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

        
   if v_curr_tab = 'r_oprtraffic' then
        
      CALL insert_oprtraffic_A(v_domain,v_operator,v_prefixcode,v_nbattempts,v_nbconnected,v_legatime,
      v_legbtime);
      LEAVE SWL_return;
   end if;

        
   if v_curr_tab = 'r_oprtraffic2' then
        
      CALL insert_oprtraffic_B(v_domain,v_operator,v_prefixcode,v_nbattempts,v_nbconnected,v_legatime,
      v_legbtime);
      LEAVE SWL_return;
   end if;

        
   CALL insert_oprtraffic_A(v_domain,v_operator,v_prefixcode,v_nbattempts,v_nbconnected,v_legatime,
   v_legbtime);
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `mswicth_getRLsInterface` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `mswicth_getRLsInterface`(ir_group varchar(100))
BEGIN
	
	
	select sitecode,interface,cccount,call_direction from rls_info
	where ir_group =ir_group;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `p_bru_custserv_toBrussels` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `p_bru_custserv_toBrussels`()
BEGIN

   update xlat set xlatpfx = 'cx_bru' where prefix in('087711','24449746','24449748');
   update xlat set xlatpfx = '31204489069' where prefix in('087711');
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `p_bru_custserv_toLondon` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `p_bru_custserv_toLondon`()
BEGIN

   update xlat set xlatpfx = 'cx_bru' where prefix in('087711','24449746','24449748');
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r01_get_pfxref_opr` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `r01_get_pfxref_opr`(v_prefixcode VARCHAR(32))
begin


   select operator,`domain` sitecode,oprfullname,prefixcode prefix_ref, `interval`, startdate from r_Oprprefix_ref where prefixcode = v_prefixcode;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r01_get_prefix` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `r01_get_prefix`(v_pfx VARCHAR(16))
begin

  
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select interfacecls as rna_timeout ,local_mroute,local_mcost,tollfree_mroute,tollfree_mcost,mobile_mroute,mobile_mcost,payphone_mroute,payphone_mcost, cast(null as SIGNED INTEGER) callback_mroute,cast(null as DECIMAL(15,15)) callback_mcost
   from r_prefix2 
   where pc = left(v_pfx,2) and prefixcode = v_pfx;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r01_get_prefix_ref` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `r01_get_prefix_ref`(v_dialednumb VARCHAR(100))
begin


   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select  prefixcode prefix_ref
   from r_prefix2 
   where pc = left(v_dialednumb,2) and v_dialednumb like CONCAT_WS('',prefixcode,'%') order by prefixlen desc LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `R01_GET_ROUTE` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `R01_GET_ROUTE`(v_pDDI            VARCHAR(32)          
   ,v_pDate          DATETIME(3)          
   ,v_pSrcInt        VARCHAR(7)    
   ,v_pSrcIntGroup   VARCHAR(64)   
   ,v_pSrcIntDom     VARCHAR(64)   
   ,v_proutecls      INT          
   ,v_pCLI           VARCHAR(32)             
   ,v_pOperatorGroup    INT      
   ,v_isgrade INT)
begin

             
   IF v_proutecls is null then
      set v_proutecls = 0;
   END IF;
   IF v_pCLI is null then
      set v_pCLI = '';
   END IF;
   IF v_pOperatorGroup is null then
      set v_pOperatorGroup = 0;
   END IF;
   IF v_isgrade is null then
      set v_isgrade = 0;
   END IF;
   set v_proutecls = 0;
     
   if v_proutecls = 0 then
      CALL r21_get_route(v_pDDI,v_pDate,v_pSrcInt,v_pSrcIntGroup,v_pSrcIntDom,v_proutecls,v_pCLI,
      v_pOperatorGroup,v_isgrade);
   else
      if v_proutecls = 1 then
         CALL r21_get_route(v_pDDI,v_pDate,v_pSrcInt,v_pSrcIntGroup,v_pSrcIntDom,0,v_pCLI,v_pOperatorGroup,
         v_isgrade);
      else
         if v_proutecls = 2 then
            CALL r21_get_route(v_pDDI,v_pDate,v_pSrcInt,v_pSrcIntGroup,v_pSrcIntDom,0,v_pCLI,v_pOperatorGroup,
            v_isgrade);
         else
            if v_proutecls = 3 then
               CALL routecls3_get_route(v_pDDI,v_pDate,v_pSrcInt,v_pSrcIntGroup,v_pSrcIntDom,v_proutecls,v_pCLI,
               v_pOperatorGroup);
            else
               if v_proutecls = 4 then
                  CALL routecls4_get_route(v_pDDI,v_pDate,v_pSrcInt,v_pSrcIntGroup,v_pSrcIntDom,v_proutecls,v_pCLI,
                  v_pOperatorGroup);
               else
                  if v_proutecls = 5 then
                     CALL routecls5_get_route(v_pDDI,v_pDate,v_pSrcInt,v_pSrcIntGroup,v_pSrcIntDom,v_proutecls,v_pCLI,
                     v_pOperatorGroup);
                  else
                     if v_proutecls = 6 then
                        CALL routecls6_get_route(v_pDDI,v_pDate,v_pSrcInt,v_pSrcIntGroup,v_pSrcIntDom,v_proutecls,v_pCLI,
                        v_pOperatorGroup);
                     else
                        if v_proutecls = 7 then
                           CALL routecls7_get_route(v_pDDI,v_pDate,v_pSrcInt,v_pSrcIntGroup,v_pSrcIntDom,v_proutecls,v_pCLI,
                           v_pOperatorGroup);
                        else
                           if v_proutecls = 8 then
                              CALL r21_get_route(v_pDDI,v_pDate,v_pSrcInt,v_pSrcIntGroup,v_pSrcIntDom,0,v_pCLI,v_pOperatorGroup,
                              0);
                           else
                              if v_proutecls = 9 then
                                 CALL routecls9_get_route(v_pDDI,v_pDate,v_pSrcInt,v_pSrcIntGroup,v_pSrcIntDom,v_proutecls,v_pCLI,
                                 v_pOperatorGroup);
                              else
                                 if v_proutecls = 10 then
                                    CALL routecls10_get_route(v_pDDI,v_pDate,v_pSrcInt,v_pSrcIntGroup,v_pSrcIntDom,v_proutecls,v_pCLI,
                                    v_pOperatorGroup);
                                 else
                                    if v_proutecls = 11 then
                                       CALL routecls11_get_route(v_pDDI,v_pDate,v_pSrcInt,v_pSrcIntGroup,v_pSrcIntDom,v_proutecls,v_pCLI,
                                       v_pOperatorGroup);
                                    else
                                       if v_proutecls = 13 then
                                          CALL routecls13_get_route(v_pDDI,v_pDate,v_pSrcInt,v_pSrcIntGroup,v_pSrcIntDom,v_proutecls,v_pCLI,
                                          v_pOperatorGroup);
                                       else
                                          if v_proutecls = 102 then
                                             CALL routecls102_get_route(v_pDDI,v_pDate,v_pSrcInt,v_pSrcIntGroup,v_pSrcIntDom,v_proutecls,v_pCLI,
                                             v_pOperatorGroup);
                                          else
                                             if v_proutecls = 103 then
                                                CALL routecls103_get_route(v_pDDI,v_pDate,v_pSrcInt,v_pSrcIntGroup,v_pSrcIntDom,v_proutecls,v_pCLI,
                                                v_pOperatorGroup);
                                             else
                                                if v_proutecls = 104 then
                                                   CALL routecls104_get_route(v_pDDI,v_pDate,v_pSrcInt,v_pSrcIntGroup,v_pSrcIntDom,v_proutecls,v_pCLI,
                                                   v_pOperatorGroup);
                                                else
                                                   if v_proutecls = 105 then
                                                      CALL routecls105_get_route(v_pDDI,v_pDate,v_pSrcInt,v_pSrcIntGroup,v_pSrcIntDom,v_proutecls,v_pCLI,
                                                      v_pOperatorGroup);
                                                   else
                                                      if v_proutecls = 201 then
                                                         CALL routecls201_get_route(v_pDDI,v_pDate,v_pSrcInt,v_pSrcIntGroup,v_pSrcIntDom,v_proutecls,v_pCLI,
                                                         v_pOperatorGroup);
                                                      else
                                                         if v_proutecls = 202 then
                                                            CALL routecls202_get_route(v_pDDI,v_pDate,v_pSrcInt,v_pSrcIntGroup,v_pSrcIntDom,v_proutecls,v_pCLI,
                                                            v_pOperatorGroup);
                                                         else
                                                            if v_proutecls = 81 then
                                                               CALL routecls81_get_route(v_pDDI,v_pDate,v_pSrcInt,v_pSrcIntGroup,v_pSrcIntDom,v_proutecls,v_pCLI,
                                                               v_pOperatorGroup);
                                                            else
                                                               if v_proutecls = 82 then
                                                                  CALL routecls82_get_route(v_pDDI,v_pDate,v_pSrcInt,v_pSrcIntGroup,v_pSrcIntDom,v_proutecls,v_pCLI,
                                                                  v_pOperatorGroup);
                                                               else
                                                                  CALL r21_get_route(v_pDDI,v_pDate,v_pSrcInt,v_pSrcIntGroup,v_pSrcIntDom,v_proutecls,v_pCLI,
                                                                  v_pOperatorGroup,v_isgrade);
                                                               end if;
                                                            end if;
                                                         end if;
                                                      end if;
                                                   end if;
                                                end if;
                                             end if;
                                          end if;
                                       end if;
                                    end if;
                                 end if;
                              end if;
                           end if;
                        end if;
                     end if;
                  end if;
               end if;
            end if;
         end if;
      end if;
   end if;        
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `R01_GET_ROUTE_GRADE` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `R01_GET_ROUTE_GRADE`(v_pDDI            VARCHAR(32)          
   ,v_pDate          DATETIME(3)          
   ,v_pSrcInt        VARCHAR(7)    
   ,v_pSrcIntGroup   VARCHAR(64)   
   ,v_pSrcIntDom     VARCHAR(64)   
   ,v_proutecls      INT          
   ,v_pCLI           VARCHAR(32)             
   ,v_pOperatorGroup    INT      
   ,v_isgrade INT)
begin

             
     
   IF v_proutecls is null then
      set v_proutecls = 0;
   END IF;
   IF v_pCLI is null then
      set v_pCLI = '';
   END IF;
   IF v_pOperatorGroup is null then
      set v_pOperatorGroup = 0;
   END IF;
   IF v_isgrade is null then
      set v_isgrade = 0;
   END IF;
   if v_proutecls = 0 then
      CALL r21_get_route(v_pDDI,v_pDate,v_pSrcInt,v_pSrcIntGroup,v_pSrcIntDom,v_proutecls,v_pCLI,
      v_pOperatorGroup,v_isgrade);
   else
      if v_proutecls = 1 then
         CALL r21_get_route(v_pDDI,v_pDate,v_pSrcInt,v_pSrcIntGroup,v_pSrcIntDom,0,v_pCLI,v_pOperatorGroup,
         v_isgrade);
      else
         if v_proutecls = 2 then
            CALL r21_get_route(v_pDDI,v_pDate,v_pSrcInt,v_pSrcIntGroup,v_pSrcIntDom,0,v_pCLI,v_pOperatorGroup,
            v_isgrade);
         else
            if v_proutecls = 3 then
               CALL routecls3_get_route(v_pDDI,v_pDate,v_pSrcInt,v_pSrcIntGroup,v_pSrcIntDom,v_proutecls,v_pCLI,
               v_pOperatorGroup);
            else
               if v_proutecls = 4 then
                  CALL routecls4_get_route(v_pDDI,v_pDate,v_pSrcInt,v_pSrcIntGroup,v_pSrcIntDom,v_proutecls,v_pCLI,
                  v_pOperatorGroup);
               else
                  if v_proutecls = 5 then
                     CALL routecls5_get_route(v_pDDI,v_pDate,v_pSrcInt,v_pSrcIntGroup,v_pSrcIntDom,v_proutecls,v_pCLI,
                     v_pOperatorGroup);
                  else
                     if v_proutecls = 6 then
                        CALL routecls6_get_route(v_pDDI,v_pDate,v_pSrcInt,v_pSrcIntGroup,v_pSrcIntDom,v_proutecls,v_pCLI,
                        v_pOperatorGroup);
                     else
                        if v_proutecls = 7 then
                           CALL routecls7_get_route(v_pDDI,v_pDate,v_pSrcInt,v_pSrcIntGroup,v_pSrcIntDom,v_proutecls,v_pCLI,
                           v_pOperatorGroup);
                        else
                           if v_proutecls = 8 then
                              CALL r21_get_route(v_pDDI,v_pDate,v_pSrcInt,v_pSrcIntGroup,v_pSrcIntDom,0,v_pCLI,v_pOperatorGroup,
                              0);
                           else
                              if v_proutecls = 9 then
                                 CALL routecls9_get_route(v_pDDI,v_pDate,v_pSrcInt,v_pSrcIntGroup,v_pSrcIntDom,v_proutecls,v_pCLI,
                                 v_pOperatorGroup);
                              else
                                 if v_proutecls = 10 then
                                    CALL routecls10_get_route(v_pDDI,v_pDate,v_pSrcInt,v_pSrcIntGroup,v_pSrcIntDom,v_proutecls,v_pCLI,
                                    v_pOperatorGroup);
                                 else
                                    if v_proutecls = 11 then
                                       CALL routecls11_get_route(v_pDDI,v_pDate,v_pSrcInt,v_pSrcIntGroup,v_pSrcIntDom,v_proutecls,v_pCLI,
                                       v_pOperatorGroup);
                                    else
                                       if v_proutecls = 13 then
                                          CALL routecls13_get_route(v_pDDI,v_pDate,v_pSrcInt,v_pSrcIntGroup,v_pSrcIntDom,v_proutecls,v_pCLI,
                                          v_pOperatorGroup);
                                       else
                                          if v_proutecls = 102 then
                                             CALL routecls102_get_route(v_pDDI,v_pDate,v_pSrcInt,v_pSrcIntGroup,v_pSrcIntDom,v_proutecls,v_pCLI,
                                             v_pOperatorGroup);
                                          else
                                             if v_proutecls = 103 then
                                                CALL routecls103_get_route(v_pDDI,v_pDate,v_pSrcInt,v_pSrcIntGroup,v_pSrcIntDom,v_proutecls,v_pCLI,
                                                v_pOperatorGroup);
                                             else
                                                if v_proutecls = 104 then
                                                   CALL routecls104_get_route(v_pDDI,v_pDate,v_pSrcInt,v_pSrcIntGroup,v_pSrcIntDom,v_proutecls,v_pCLI,
                                                   v_pOperatorGroup);
                                                else
                                                   if v_proutecls = 105 then
                                                      CALL routecls105_get_route(v_pDDI,v_pDate,v_pSrcInt,v_pSrcIntGroup,v_pSrcIntDom,v_proutecls,v_pCLI,
                                                      v_pOperatorGroup);
                                                   else
                                                      if v_proutecls = 201 then
                                                         CALL routecls201_get_route(v_pDDI,v_pDate,v_pSrcInt,v_pSrcIntGroup,v_pSrcIntDom,v_proutecls,v_pCLI,
                                                         v_pOperatorGroup);
                                                      else
                                                         if v_proutecls = 202 then
                                                            CALL routecls202_get_route(v_pDDI,v_pDate,v_pSrcInt,v_pSrcIntGroup,v_pSrcIntDom,v_proutecls,v_pCLI,
                                                            v_pOperatorGroup);
                                                         else
                                                            if v_proutecls = 81 then
                                                               CALL routecls81_get_route(v_pDDI,v_pDate,v_pSrcInt,v_pSrcIntGroup,v_pSrcIntDom,v_proutecls,v_pCLI,
                                                               v_pOperatorGroup);
                                                            else
                                                               if v_proutecls = 82 then
                                                                  CALL routecls82_get_route(v_pDDI,v_pDate,v_pSrcInt,v_pSrcIntGroup,v_pSrcIntDom,v_proutecls,v_pCLI,
                                                                  v_pOperatorGroup);
                                                               else
                                                                  CALL r21_get_route(v_pDDI,v_pDate,v_pSrcInt,v_pSrcIntGroup,v_pSrcIntDom,v_proutecls,v_pCLI,
                                                                  v_pOperatorGroup,v_isgrade);
                                                               end if;
                                                            end if;
                                                         end if;
                                                      end if;
                                                   end if;
                                                end if;
                                             end if;
                                          end if;
                                       end if;
                                    end if;
                                 end if;
                              end if;
                           end if;
                        end if;
                     end if;
                  end if;
               end if;
            end if;
         end if;
      end if;
   end if;        
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `R20_Get_Route` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `R20_Get_Route`(v_pDDI VARCHAR(32),        
   v_pDate DATETIME(3),        
   v_pSrcInt VARCHAR(7),        
   v_pSrcIntGroup VARCHAR(64),        
   v_pSrcIntDom VARCHAR(64),        
   v_routeclass INT  ,    
   v_pCLI VARCHAR(32),        
   v_pOperatorGroup INT)
begin

        
   DECLARE v_pc VARCHAR(2);        
   DECLARE v_prefixcode VARCHAR(16);        
       
   IF v_routeclass is null then
      set v_routeclass = 0;
   END IF;
   IF v_pCLI is null then
      set v_pCLI = '';
   END IF;
   IF v_pOperatorGroup is null then
      set v_pOperatorGroup = 0;
   END IF;
   set v_prefixcode = v_pDDI;        
   set v_pc = left(v_prefixcode,2);        



   DROP TEMPORARY TABLE IF EXISTS tt_1;        



   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   CREATE TEMPORARY TABLE tt_1
   (
      seqno INT AUTO_INCREMENT UNIQUE
   ) AS select zzz.* from(select  x.`except`, 'R05' routeset, x.id, x.state isactive, x.routeCls, x.prefixCode,
  tdo.universe, tit.`domain` `domain`, tit.pdomain pdomain, tit.`group` `group`,
  tit.name interface, tit.userinfo, tit.hint, x.cls timecls, x.priority, x.cost, x.flag, 0 redlist,
  CONCAT('1',(case when access & 0x8 = 0 then '0' else '1' end),(case when access & 0x4 = 0 then '0' else '1' end),
      (case when access & 0x2 = 0 then '0' else '1' end),
      (case when access & 0x1 = 0 then '0' else '1' end)) access,x.rating
      from(select routeCls, oprid, pc, max(prefixCode) prefixcode,cls
         from r20_route05
         where routeCls = v_routeclass and pc = v_pc and v_prefixcode like CONCAT_WS('',prefixCode,'%')
         group by routeCls,oprid,pc,cls) a,
r20_route05 x,
r_timecls y,
r_interface tit,
r_domain tdo,
r_timecode ttc,
r_daycode tdc,
r_interfaceGroup ig,
r_info tif 
      where  x.routeCls = a.routecls and x.pc = v_pc and x.prefixCode = a.prefixcode and x.oprid = a.oprid  and x.cls = a.cls 
      and tit.id = x.oprid and tit.state = 'I'
      and tit.`domain` = tdo.name
      and  y.tintid = x.oprid and y.cls = x.cls
      and y.dc = tdc.id
      and y.tc = ttc.id
      and y.sc = 0
      and tdc.d1 <= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
      and tdc.d2 >= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
      and ttc.h1 <=(((24+EXTRACT(HOUR FROM v_pDate)+tdo.timezone -tif.timezone)%24)*100+EXTRACT(MINUTE FROM v_pDate))
      and ttc.h2 >(((24+EXTRACT(HOUR FROM v_pDate)+tdo.timezone -tif.timezone)%24)*100+EXTRACT(MINUTE FROM v_pDate))
      and ig.tintid = tit.id and ig.IntGroupID = v_pOperatorGroup and ig.flag = 1
      order by x.cost LIMIT 20) zzz WHERE 1 = 0;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   INSERT INTO tt_1  select zzz.* from(select  x.`except`, 'R05' routeset, x.id, x.state isactive, x.routeCls, x.prefixCode,
  tdo.universe, tit.`domain` `domain`, tit.pdomain pdomain, tit.`group` `group`,
  tit.name interface, tit.userinfo, tit.hint, x.cls timecls, x.priority, x.cost, x.flag, 0 redlist,
  CONCAT('1',(case when access & 0x8 = 0 then '0' else '1' end),(case when access & 0x4 = 0 then '0' else '1' end),
      (case when access & 0x2 = 0 then '0' else '1' end),
      (case when access & 0x1 = 0 then '0' else '1' end)) access,x.rating
      from(select routeCls, oprid, pc, max(prefixCode) prefixcode,cls
         from r20_route05
         where routeCls = v_routeclass and pc = v_pc and v_prefixcode like CONCAT_WS('',prefixCode,'%')
         group by routeCls,oprid,pc,cls) a,
r20_route05 x,
r_timecls y,
r_interface tit,
r_domain tdo,
r_timecode ttc,
r_daycode tdc,
r_interfaceGroup ig,
r_info tif 
      where  x.routeCls = a.routecls and x.pc = v_pc and x.prefixCode = a.prefixcode and x.oprid = a.oprid  and x.cls = a.cls 
      and tit.id = x.oprid and tit.state = 'I'
      and tit.`domain` = tdo.name
      and  y.tintid = x.oprid and y.cls = x.cls
      and y.dc = tdc.id
      and y.tc = ttc.id
      and y.sc = 0
      and tdc.d1 <= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
      and tdc.d2 >= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
      and ttc.h1 <=(((24+EXTRACT(HOUR FROM v_pDate)+tdo.timezone -tif.timezone)%24)*100+EXTRACT(MINUTE FROM v_pDate))
      and ttc.h2 >(((24+EXTRACT(HOUR FROM v_pDate)+tdo.timezone -tif.timezone)%24)*100+EXTRACT(MINUTE FROM v_pDate))
      and ig.tintid = tit.id and ig.IntGroupID = v_pOperatorGroup and ig.flag = 1
      order by x.cost LIMIT 20) zzz;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;


   select * from tt_1 where isactive > 0 order by seqno -`except`;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r21_get_route` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `r21_get_route`(v_pDDI VARCHAR(32),                          
   v_pDate DATETIME(3),                          
   v_pSrcInt VARCHAR(7),                          
   v_pSrcIntGroup VARCHAR(64),                          
   v_pSrcIntDom VARCHAR(64),                          
   v_routeclass INT  ,                      
   v_pCLI VARCHAR(32),                          
   v_pOperatorGroup INT  ,
   v_isgrade INT)
begin

   


   DECLARE v_longestPrefixcode VARCHAR(16);                          
   DECLARE v_longestCls INT;  
   DECLARE v_nearestTime VARCHAR(17);                          
  
  
                                       
   IF v_routeclass is null then
      set v_routeclass = 0;
   END IF;
   IF v_pCLI is null then
      set v_pCLI = '';
   END IF;
   IF v_pOperatorGroup is null then
      set v_pOperatorGroup = 0;
   END IF;
   IF v_isgrade is null then
      set v_isgrade = 0;
   END IF;
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   prefixcode, prefixCls INTO v_longestPrefixcode,v_longestCls from r_prefix2  where pc = left(v_pDDI,2) and v_pDDI like CONCAT_WS('',prefixcode,'%')   order by prefixlen desc LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
  
   if v_longestCls is null then 
      set v_longestCls = 0;
   end if;  
  
   CALL r22_routeGetNearestTime(v_pDate,v_nearestTime);  
   if v_longestCls in(3,4) then
      CALL r24_routeSpecialGetCache(v_longestPrefixcode,v_pDate,v_pSrcInt,v_pSrcIntGroup,v_pSrcIntDom,v_routeclass,
      v_pCLI,v_pOperatorGroup);
   else
      CALL r24_routeGetCache(v_longestPrefixcode,v_longestCls,v_pDate,v_pSrcInt,v_pSrcIntGroup,v_pSrcIntDom,
      v_routeclass,v_pCLI,v_pOperatorGroup,v_isgrade);
   end if;  
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r21_get_route_grade` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `r21_get_route_grade`(v_pDDI VARCHAR(32),                            
   v_pDate DATETIME(3),                            
   v_pSrcInt VARCHAR(7),                            
   v_pSrcIntGroup VARCHAR(64),                            
   v_pSrcIntDom VARCHAR(64),                            
   v_routeclass INT  ,                        
   v_pCLI VARCHAR(32),                            
   v_pOperatorGroup INT  ,  
   v_isgrade INT)
begin

     


   DECLARE v_longestPrefixcode VARCHAR(16);                            
   DECLARE v_longestCls INT;    
   DECLARE v_nearestTime VARCHAR(17);                            
    
    
                                         
   IF v_routeclass is null then
      set v_routeclass = 0;
   END IF;
   IF v_pCLI is null then
      set v_pCLI = '';
   END IF;
   IF v_pOperatorGroup is null then
      set v_pOperatorGroup = 0;
   END IF;
   IF v_isgrade is null then
      set v_isgrade = 0;
   END IF;
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   prefixcode, prefixCls INTO v_longestPrefixcode,v_longestCls from r_prefix2  where pc = left(v_pDDI,2) and v_pDDI like CONCAT_WS('',prefixcode,'%')   order by prefixlen desc LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;    
    
   if v_longestCls is null then 
      set v_longestCls = 0;
   end if;    
    
   CALL r22_routeGetNearestTime(v_pDate,v_nearestTime);    
   if v_longestCls in(3,4) then
      CALL r24_routeSpecialGetCache(v_longestPrefixcode,v_pDate,v_pSrcInt,v_pSrcIntGroup,v_pSrcIntDom,v_routeclass,
      v_pCLI,v_pOperatorGroup);
   else
      CALL r24_routeGetCache(v_longestPrefixcode,v_longestCls,v_pDate,v_pSrcInt,v_pSrcIntGroup,v_pSrcIntDom,
      v_routeclass,v_pCLI,v_pOperatorGroup,v_isgrade);
   end if;    
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r22_routeGetCache` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `r22_routeGetCache`(v_pLongest VARCHAR(32),                        
   v_pLongestCls INT,
   v_pDate DATETIME(3),                        
   v_pSrcInt VARCHAR(7),                        
   v_pSrcIntGroup VARCHAR(64),                        
   v_pSrcIntDom VARCHAR(64),                        
   v_routeclass INT  ,                    
   v_pCLI VARCHAR(32),                        
   v_pOperatorGroup INT)
begin

                        
   DECLARE v_pc VARCHAR(2);                        
                       
   IF v_routeclass is null then
      set v_routeclass = 0;
   END IF;
   IF v_pCLI is null then
      set v_pCLI = '';
   END IF;
   IF v_pOperatorGroup is null then
      set v_pOperatorGroup = 0;
   END IF;
   set v_pc = left(v_pLongest,2);                        
                
                
                
   DROP TEMPORARY TABLE IF EXISTS tt_routes;                        
                
                
                
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   CREATE TEMPORARY TABLE tt_routes AS select * from(select  x.id, x.state isactive, x.routeCls, x.prefixCode,
        tdo.universe, tit.`domain` `domain`, tit.pdomain pdomain, tit.`group` `group`, tit.id tintid,
        tit.name interface, tit.userinfo, tit.hint, x.cls timecls, x.priority, x.cost, x.flag, 0 redlist,
        '11111' access,x.rating,IFNULL(x.reason,0) reason, clsorg clsorg,x.`exception`,x.ext
         from(select routeCls, oprid, pc, max(prefixCode) prefixcode, cls
            from r20_route06
            where routeCls = v_routeclass and pc = v_pc and v_pLongest like CONCAT_WS('',prefixCode,'%')
            group by routeCls,oprid,pc,cls) nearest,
    r20_route06 x,
    r_timecls y, r_interface tit, r_timecode ttc, r_daycode tdc, r_domain tdo,
    r_info tif 
         where  x.routeCls = nearest.routecls and x.pc = v_pc and x.prefixCode = nearest.prefixcode and x.oprid = nearest.oprid  and x.cls = nearest.cls
         and (v_pLongestCls not in(3,4) or x.priority = 1)
         and tit.id = x.oprid and tit.state = 'I'
         and tit.`domain` = tdo.name
         and  y.tintid = x.oprid and y.cls = x.cls
         and y.dc = tdc.id and y.tc = ttc.id and y.sc = 0
         and tdc.d1 <= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
         and tdc.d2 >= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
         and ttc.h1 <=(((24+EXTRACT(HOUR FROM v_pDate)+tdo.timezone -tif.timezone)%24)*100+EXTRACT(MINUTE FROM v_pDate))
         and ttc.h2 >(((24+EXTRACT(HOUR FROM v_pDate)+tdo.timezone -tif.timezone)%24)*100+EXTRACT(MINUTE FROM v_pDate))
         order by x.cost LIMIT 20) routes;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;          
          
          

          
   DROP TEMPORARY TABLE IF EXISTS tt_longest;
   CREATE TEMPORARY TABLE tt_longest AS select tintid, max(prefixcode) prefixcode

      from tt_routes group by tintid;          
          
   DROP TEMPORARY TABLE IF EXISTS tt_1;          
          
   CREATE TEMPORARY TABLE tt_1
   (
      seqno INT AUTO_INCREMENT UNIQUE
   ) AS select selected.*, case
      when ((IFNULL(`exception`,0) = 0) or (prefixcode <> v_pLongest)) then 0.
      when `exception` > 0 then `exception`+0.5 else `exception` -0.5
      end `except` from(select tt_routes.* from(select tt_routes.tintid, max(timecls) timecls
         from tt_routes, tt_longest
         where tt_routes.tintid = tt_longest.tintid and tt_routes.prefixcode = tt_longest.prefixcode
         group by tt_routes.tintid) tt_selected, tt_routes
      where tt_selected.tintid = tt_routes.tintid and tt_selected.timecls = tt_routes.timecls)
      selected WHERE 1 = 0;
   INSERT INTO tt_1(`except`) select selected.*, case
   when ((IFNULL(`exception`,0) = 0) or (prefixcode <> v_pLongest)) then 0.
   when `exception` > 0 then `exception`+0.5 else `exception` -0.5
   end `except`

   from(select tt_routes.* from(select tt_routes.tintid, max(timecls) timecls
         from tt_routes, tt_longest
         where tt_routes.tintid = tt_longest.tintid and tt_routes.prefixcode = tt_longest.prefixcode
         group by tt_routes.tintid) tt_selected, tt_routes
      where tt_selected.tintid = tt_routes.tintid and tt_selected.timecls = tt_routes.timecls)
   selected;          
          

                
                
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select routeset,priority,id,isactive,routecls,prefixcode,universe,`domain`,pdomain,`group`,interface,userinfo,hint,
clsOrg,timecls,cost,flag,redlist,access,rating
   from(select 'R20_Route06' routeset,
 	x.seqno priority, x.id,
	case when x.isactive = 1 then 1
      when reason >= 20 and x.prefixcode <> v_pLongest then 1 else 0 end isactive,
	x.routecls, x.prefixcode, x.universe, x.`domain`, x.pdomain,
    x.`group`, x.interface, x.userinfo, x.hint, x.clsOrg, x.timecls, x.cost, x.flag, x.redlist, x.access, x.rating,
    x.reason,
	x.`except`,
	IFNULL(x.`exception`,0) `exception`,
	IFNULL(x.ext,0) ext
      from tt_1 x, r_interfaceGroup ig 
      where ig.tintid = x.tintid and ig.IntGroupID = v_pOperatorGroup and ig.flag = 1) x where isactive = 1

   order by priority+`except`;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;                
        
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r22_routeGetNearestTime` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `r22_routeGetNearestTime`(v_pDate DATETIME(3),
	INOUT v_sDate VARCHAR(17))
begin

   DECLARE v_m INT;	
	
   set v_m = EXTRACT(minute FROM v_pDate);
   if v_m < 30 then
      set v_sDate = CONCAT(DATE_FORMAT(v_pDate,'%Y-%m-%d %T'),'00');
   else
      set v_sDate = CONCAT(DATE_FORMAT(v_pDate,'%Y-%m-%d %T'),'30');
   end if;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r23_routeGetCache` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `r23_routeGetCache`(v_pLongest VARCHAR(32),                        
   v_pLongestCls INT,
   v_pDate DATETIME(3),                        
   v_pSrcInt VARCHAR(7),                        
   v_pSrcIntGroup VARCHAR(64),                        
   v_pSrcIntDom VARCHAR(64),                        
   v_routeclass INT  ,                    
   v_pCLI VARCHAR(32),                        
   v_pOperatorGroup INT)
begin

                        
   DECLARE v_pc VARCHAR(2);                        
                       
   IF v_routeclass is null then
      set v_routeclass = 0;
   END IF;
   IF v_pCLI is null then
      set v_pCLI = '';
   END IF;
   IF v_pOperatorGroup is null then
      set v_pOperatorGroup = 0;
   END IF;
   set v_pc = left(v_pLongest,2);                        
                
                
        
   DROP TEMPORARY TABLE IF EXISTS tt_nearest;                        
                
                
        
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   CREATE TEMPORARY TABLE tt_nearest AS select routecls, oprid, pc, max(prefixcode) prefixcode, cls

      from r20_route06
      where routecls = v_routeclass and pc = v_pc and v_pLongest like CONCAT_WS('',prefixcode,'%')
      group by routecls,oprid,pc,cls;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
        
   DROP TEMPORARY TABLE IF EXISTS tt_routes;
        
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   CREATE TEMPORARY TABLE tt_routes AS select * from(select  x.id, x.state isactive, x.routecls, x.prefixcode,
        tdo.universe, tit.`domain` `domain`, tit.pdomain pdomain, tit.`group` `group`, tit.id tintid,
        tit.name interface, tit.userinfo, tit.hint, x.cls timecls, x.priority, x.cost, x.flag, 0 redlist,
        '11111' access,x.rating,IFNULL(x.reason,0) reason, clsorg clsorg,x.`exception`,x.ext
         from tt_nearest,
    r20_route06 x,
    r_timecls y, r_interface tit, r_timecode ttc, r_daycode tdc, r_domain tdo,
    r_info tif 
         where  x.routecls = tt_nearest.routecls and x.pc = v_pc and x.prefixcode = tt_nearest.prefixcode and x.oprid = tt_nearest.oprid  and x.cls = tt_nearest.cls
         and (v_pLongestCls not in(3,4) or x.priority = 1)
         and tit.id = x.oprid and tit.state = 'I'
         and tit.`domain` = tdo.name
         and  y.tintid = x.oprid and y.cls = x.cls
         and y.dc = tdc.id and y.tc = ttc.id and y.sc = 0
         and tdc.d1 <= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
         and tdc.d2 >= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
         and ttc.h1 <=(((24+EXTRACT(HOUR FROM v_pDate)+tdo.timezone -tif.timezone)%24)*100+EXTRACT(MINUTE FROM v_pDate))
         and ttc.h2 >(((24+EXTRACT(HOUR FROM v_pDate)+tdo.timezone -tif.timezone)%24)*100+EXTRACT(MINUTE FROM v_pDate))
         order by x.cost LIMIT 20) routes;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;          
          
          

          
   DROP TEMPORARY TABLE IF EXISTS tt_longest;
   CREATE TEMPORARY TABLE tt_longest AS select tintid, max(prefixcode) prefixcode

      from tt_routes group by tintid;          
          
   DROP TEMPORARY TABLE IF EXISTS tt_1;          
          
   CREATE TEMPORARY TABLE tt_1
   (
      seqno INT AUTO_INCREMENT UNIQUE
   ) AS select selected.*, case
      when ((IFNULL(`exception`,0) = 0) or (prefixcode <> v_pLongest)) then 0.
      when `exception` > 0 then `exception`+0.5 else `exception` -0.5
      end `except` from(select tt_routes.* from(select tt_routes.tintid, max(timecls) timecls
         from tt_routes, tt_longest
         where tt_routes.tintid = tt_longest.tintid and tt_routes.prefixcode = tt_longest.prefixcode
         group by tt_routes.tintid) tt_selected, tt_routes
      where tt_selected.tintid = tt_routes.tintid and tt_selected.timecls = tt_routes.timecls)
      selected WHERE 1 = 0;
   INSERT INTO tt_1(`except`) select selected.*, case
   when ((IFNULL(`exception`,0) = 0) or (prefixcode <> v_pLongest)) then 0.
   when `exception` > 0 then `exception`+0.5 else `exception` -0.5
   end `except`

   from(select tt_routes.* from(select tt_routes.tintid, max(timecls) timecls
         from tt_routes, tt_longest
         where tt_routes.tintid = tt_longest.tintid and tt_routes.prefixcode = tt_longest.prefixcode
         group by tt_routes.tintid) tt_selected, tt_routes
      where tt_selected.tintid = tt_routes.tintid and tt_selected.timecls = tt_routes.timecls)
   selected;          
          

                
                
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select routeset,priority,id,isactive,routecls,prefixcode,universe,`domain`,pdomain,`group`,interface,userinfo,hint,
clsOrg,timecls,cost,flag,redlist,access,rating
   from(select 'R20_Route06' routeset,
 	x.seqno priority, x.id,
	case when x.isactive = 1 then 1
      when reason >= 20 and x.prefixcode <> v_pLongest then 1 else 0 end isactive,
	x.routecls, x.prefixcode, x.universe, x.`domain`, x.pdomain,
    x.`group`, x.interface, x.userinfo, x.hint, x.clsOrg, x.timecls, x.cost, x.flag, x.redlist, x.access, x.rating,
    x.reason,
	x.`except`,
	IFNULL(x.`exception`,0) `exception`,
	IFNULL(x.ext,0) ext
      from tt_1 x, r_interfaceGroup ig 
      where ig.tintid = x.tintid and ig.IntGroupID = v_pOperatorGroup and ig.flag = 1) x where isactive = 1

   order by priority+`except`;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;                
        
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r24_routeGetCache` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `r24_routeGetCache`(v_pLongest VARCHAR(32),  
   v_pLongestCls INT,  
   v_pDate DATETIME(3),  
   v_pSrcInt VARCHAR(7),  
   v_pSrcIntGroup VARCHAR(64),  
   v_pSrcIntDom VARCHAR(64),  
   v_routeclass INT,  
   v_pCLI VARCHAR(32),  
   v_pOperatorGroup INT ,  
   v_isgrade INT)
begin

  
   DECLARE v_pc VARCHAR(2);  
   DECLARE v_dd INT;  
   DECLARE v_hh INT;  
   DECLARE v_mm INT;  
   DECLARE v_gmt DATETIME(3);  
  
  
  
   IF v_routeclass is null then
      set v_routeclass = 0;
   END IF;
   IF v_pCLI is null then
      set v_pCLI = '';
   END IF;
   IF v_pOperatorGroup is null then
      set v_pOperatorGroup = 0;
   END IF;
   IF v_isgrade is null then
      set v_isgrade = 0;
   END IF;
   set v_pc = left(v_pLongest,2);  
   select(TIMESTAMPADD(HOUR,-timezone,v_pDate)) INTO v_gmt from r_info;  
   set v_dd = 1+(v_datefirst+DAYOFWEEK(v_gmt) -2)%7;  
   set v_hh = EXTRACT(HOUR FROM v_gmt);  
   set v_mm = EXTRACT(MINUTE FROM v_gmt);  
  



  
  

   DROP TEMPORARY TABLE IF EXISTS tt_operator_selected;
   CREATE TEMPORARY TABLE tt_operator_selected 
   (
      routecls INT NOT NULL,
      oprId INT NOT NULL,
      cls VARCHAR(1) NOT NULL,
      pc VARCHAR(2) NOT NULL
   );  
  
   CREATE  UNIQUE  INDEX idx1 ON `#operator_selected2`
   (routecls, 
   oprId, 
   cls, 
   pc);  
  
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   insert into tt_operator_selected(routecls,oprId,cls,pc)
   select x.routecls,x.oprId,x.cls,x.pc  from r20_route_timecls x, r_timecls y, r_interface tit,
r_timecode tco, r_daycode dco 
   where x.routecls = 0
   and tit.id = x.oprId and tit.state = 'I'
   and y.tintid = x.oprId and y.cls = x.cls
   and y.dc = dco.id and y.tc = tco.id and y.sc = 0
   and v_dd between dco.d1 and dco.d2
   and((24+v_hh+IFNULL(tit.prefixcls,0))%24)*100+v_mm between tco.h1 and tco.h2 -1
   and x.pc = v_pc;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
  
  
   DROP TEMPORARY TABLE IF EXISTS tt_timecls_selected;  
  
  
   CREATE TEMPORARY TABLE tt_timecls_selected 
   (
      routecls INT NOT NULL,
      oprId INT NOT NULL,
      pc VARCHAR(2) NOT NULL,
      prefixcode VARCHAR(50) NOT NULL,
      cnt INT,
      clsA INT,
      clsP INT,
      clsO INT,
      clsW INT,
      cls VARCHAR(1) NOT NULL
   );  
  
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   insert into tt_timecls_selected(routecls,oprid,pc,prefixcode,cnt,clsA,clsP,clsO,clsW,cls)
   select a.routeCls, a.oprId, a.pc, max(a.prefixCode) prefixCode,
 count(*) cnt,
 sum(case when a.cls = 'A' then 1 else 0 end) clsA,
 sum(case when a.cls = 'P' then 1 else 0 end) clsP,
 sum(case when a.cls = 'O' then 1 else 0 end) clsO,
 sum(case when a.cls = 'W' then 1 else 0 end) clsW, 'Z' cls
   from r20_route07 a, tt_operator_selected b
   where a.routeCls = b.routeCls and a.oprId = b.oprId and a.cls = b.cls and a.pc = b.pc
   and left(v_pLongest,prefixLen) = a.prefixCode
   group by a.routeCls,a.oprId,a.pc;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
  
   update tt_timecls_selected
   set cls =(case when (clsW > 0) and (cnt = clsW) then 'W'
   when (clsO > 0) and (cnt = clsO) then 'O'
   when (clsP > 0) and (cnt = clsP) then 'P'
   when (clsA > 0) and (cnt = clsA) then 'A'
   else 'Z' end);  
  
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   update tt_timecls_selected
   set cls =(select max(a.cls) from r20_route07 a 
   where a.routeCls = tt_timecls_selected2.routecls
   and a.oprId = tt_timecls_selected2.oprId
   and a.pc = tt_timecls_selected2.pc
   and a.prefixCode = tt_timecls_selected2.prefixCode
   and ((a.cls = 'A' and tt_timecls_selected2.clsA <> 0) or
          (a.cls = 'P' and tt_timecls_selected2.clsP <> 0) or
          (a.cls = 'O' and tt_timecls_selected2.clsO <> 0) or
          (a.cls = 'W' and tt_timecls_selected2.clsW <> 0)))
   where cls = 'Z';
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
  
   DROP TEMPORARY TABLE IF EXISTS tt_route;  
  
   CREATE TEMPORARY TABLE tt_route 
   (
      seqno INT   AUTO_INCREMENT PRIMARY KEY,
      priority INT,
      id INT,
      isactive INT,
      reason INT,
      `exception` INT,
      calcexception INT,
      ext INT,
      oprid INT,
      parentid INT,
      routecls INT,
      prefixcode VARCHAR(50),
      universe VARCHAR(5),
      `domain` VARCHAR(5),
      pdomain VARCHAR(5),
      `group` VARCHAR(40),
      interface VARCHAR(40),
      userinfo VARCHAR(40),
      hint VARCHAR(100),
      clsorg CHAR(1),
      cls CHAR(1),
      cost FLOAT,
      flag INT,
      rating INT,
      access VARCHAR(10),
      redlist INT,
      quality FLOAT,
      exceptioncls INT
   )  AUTO_INCREMENT = 10; 
  
  
   if v_isgrade = 0 then

      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      insert into tt_route(isactive,reason,`exception`,calcexception,id,parentid,routecls,oprid,prefixcode,clsorg,cls,cost,
priority,rating,flag,ext,quality,exceptioncls)  


      select
      x.state isactive, x.reason,
  IFNULL(x.`exception`,0) `exception`,
  case
      when ((IFNULL(x.`exception`,0) = 0)) then 0
      when x.`exception` > 0 then cast((x.`exception`+0.5)*10 as SIGNED INTEGER)
      else cast((x.`exception` -0.5)*10 as SIGNED INTEGER)
      end calcException,
  x.id, x.parentId, x.routeCls, x.oprId, x.prefixCode, x.clsOrg, x.cls,
  x.cost, x.priority, rating, x.flag, x.ext,x.quality,x.exceptionCls
      from r20_route07 x, tt_timecls_selected b
      where x.routeCls = b.routecls and x.oprId = b.oprid and x.pc = b.pc and x.prefixCode = b.prefixcode and x.cls = b.cls
      order by x.cost;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   else
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      insert into tt_route(isactive,reason,`exception`,calcexception,id,parentid,routecls,oprid,prefixcode,clsorg,cls,cost,
priority,rating,flag,ext,quality,exceptioncls)  


      select
      x.state isactive, x.reason,
  IFNULL(x.`exception`,0) `exception`,
  case
      when ((IFNULL(x.`exception`,0) = 0)) then 0
      when x.`exception` > 0 then cast((x.`exception`+0.5)*10 as SIGNED INTEGER)
      else cast((x.`exception` -0.5)*10 as SIGNED INTEGER)
      end calcException,
  x.id, x.parentId, x.routeCls, x.oprId, x.prefixCode, x.clsOrg, x.cls,
  x.cost, x.priority, rating, x.flag, x.ext,x.quality,x.exceptionCls
      from r20_route07 x, tt_timecls_selected b
      where x.routeCls = b.routecls and x.oprId = b.oprid and x.pc = b.pc and x.prefixCode = b.prefixcode and x.cls = b.cls
      order by x.quality,x.cost;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   end if;  

  




  
  
  
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select
   'r20_route07' routeset,
   x.seqno priority, x.id, x.isactive, x.reason, x.`exception`, IFNULL(x.ext,0) ext,
  x.routecls, x.prefixcode, y.universe, y.`domain`, y.pdomain,
    y.`group`, y.name interface, y.userinfo, y.hint, x.clsOrg, x.cls timecls, x.cost, x.flag, x.rating,
 '11111' access, 0 redlist,x.quality grade,IFNULL(y.intcls,0) intcls,x.exceptioncls capability, IFNULL(y.type,1) oprtype
   from tt_route x, r_interface y, r_interfaceGroup ig 
   where x.oprId = y.id and ig.tintid = x.oprId and ig.IntGroupID = v_pOperatorGroup and ig.flag = 1 and x.isactive = 1
   and v_pLongest like CONCAT_WS('',x.prefixcode,'%')
   order by seqno+calcException;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
  
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r24_routeGetCache_2` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `r24_routeGetCache_2`(v_pLongest VARCHAR(32),                              
   v_pLongestCls INT,      
   v_pDate DATETIME(3),                              
   v_pSrcInt VARCHAR(7),                              
   v_pSrcIntGroup VARCHAR(64),                              
   v_pSrcIntDom VARCHAR(64),                              
   v_routeclass INT  ,                          
   v_pCLI VARCHAR(32),                              
   v_pOperatorGroup INT)
begin

                              
   DECLARE v_pc VARCHAR(2);                              
   DECLARE v_dd INT;
   DECLARE v_hh INT;
   DECLARE v_mm INT;
                             
   IF v_routeclass is null then
      set v_routeclass = 0;
   END IF;
   IF v_pCLI is null then
      set v_pCLI = '';
   END IF;
   IF v_pOperatorGroup is null then
      set v_pOperatorGroup = 0;
   END IF;
   set v_pc = left(v_pLongest,2);                              
   set v_dd = 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7;
   select(EXTRACT(HOUR FROM v_pDate) -timezone) INTO v_hh from r_info;
   set v_mm = EXTRACT(MINUTE FROM v_pDate);
                      


   CREATE TEMPORARY TABLE tt_operator_selected 
   (
      routecls INT NOT NULL,
      oprId INT NOT NULL,
      cls VARCHAR(1) NOT NULL,
      pc VARCHAR(2) NOT NULL
   );

   CREATE  UNIQUE  INDEX idx1 ON `#operator_selected2`
   (routecls, 
   oprId, 
   cls, 
   pc);


   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   insert into tt_operator_selected(routecls,oprId,cls,pc)
   select x.routecls,x.oprId,x.cls,x.pc  from r20_route_timecls x, r_timecls y, r_interface tit,
r_timecode tco, r_daycode dco 
   where x.routecls = 0
   and tit.id = x.oprId and tit.state = 'I'
   and y.tintid = x.oprId and y.cls = x.cls
   and y.dc = dco.id and y.tc = tco.id and y.sc = 0
   and v_dd between dco.d1 and dco.d2
   and((24+v_hh+IFNULL(tit.prefixcls,0))%24)*100+v_mm between tco.h1 and tco.h2 -1
   and x.pc = v_pc;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;      


   CREATE TEMPORARY TABLE tt_timecls_selected 
   (
      routecls INT NOT NULL,
      oprId INT NOT NULL,
      pc VARCHAR(2) NOT NULL,
      prefixcode VARCHAR(50) NOT NULL,
      cnt INT,
      clsA INT,
      clsP INT,
      clsO INT,
      clsW INT,
      cls VARCHAR(1) NOT NULL
   ); 

   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   insert into tt_timecls_selected(routecls,oprid,pc,prefixcode,cnt,clsA,clsP,clsO,clsW,cls)
   select a.routeCls, a.oprId, a.pc, max(a.prefixCode) prefixCode,
	count(*) cnt,
	sum(case when a.cls = 'A' then 1 else 0 end) clsA,
	sum(case when a.cls = 'P' then 1 else 0 end) clsP,
	sum(case when a.cls = 'O' then 1 else 0 end) clsO,
	sum(case when a.cls = 'W' then 1 else 0 end) clsW, 'Z' cls
   from r20_route07 a, tt_operator_selected b
   where a.routeCls = b.routeCls and a.oprId = b.oprId and a.cls = b.cls and a.pc = b.pc
   and left(v_pLongest,prefixLen) = a.prefixCode
   group by a.routeCls,a.oprId,a.pc;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;   

   update tt_timecls_selected
   set cls =(case when (clsW > 0) and (cnt = clsW) then 'W'
   when (clsO > 0) and (cnt = clsO) then 'O'
   when (clsP > 0) and (cnt = clsP) then 'P'
   when (clsA > 0) and (cnt = clsA) then 'A'
   else 'Z' end);

   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   update tt_timecls_selected
   set cls =(select max(a.cls) from r20_route07 a 
   where a.routeCls = tt_timecls_selected2.routecls
   and a.oprId = tt_timecls_selected2.oprId
   and a.pc = tt_timecls_selected2.pc
   and a.prefixCode = tt_timecls_selected2.prefixCode
   and ((a.cls = 'A' and tt_timecls_selected2.clsA <> 0) or
		        (a.cls = 'P' and tt_timecls_selected2.clsP <> 0) or
		        (a.cls = 'O' and tt_timecls_selected2.clsO <> 0) or
		        (a.cls = 'W' and tt_timecls_selected2.clsW <> 0)))
   where cls = 'Z';
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

   CREATE TEMPORARY TABLE tt_route 
   (
      seqno INT   AUTO_INCREMENT PRIMARY KEY,
      priority INT,
      id INT,
      isactive INT,
      reason INT,
      `exception` INT,
      calcexception INT,
      ext INT,
      oprid INT,
      parentid INT,
      routecls INT,
      prefixcode VARCHAR(50),
      universe VARCHAR(5),
      `domain` VARCHAR(5),
      pdomain VARCHAR(5),
      `group` VARCHAR(40),
      interface VARCHAR(40),
      userinfo VARCHAR(40),
      hint VARCHAR(100),
      clsorg CHAR(1),
      cls CHAR(1),
      cost FLOAT,
      flag INT,
      rating INT,
      access VARCHAR(10),
      redlist INT 
   )  AUTO_INCREMENT = 10;



   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   insert into tt_route(isactive,reason,`exception`,calcexception,id,parentid,routecls,oprid,prefixcode,clsorg,cls,cost,
priority,rating,flag,ext)


   select
   x.state isactive, x.reason,
  IFNULL(x.`exception`,0) `exception`,
  case
   when ((IFNULL(x.`exception`,0) = 0) or (x.prefixCode <> v_pLongest)) then 0
   when x.`exception` > 0 then cast((x.`exception`+0.5)*10 as SIGNED INTEGER)
   else cast((x.`exception` -0.5)*10 as SIGNED INTEGER)
   end calcException,
  x.id, x.parentId, x.routeCls, x.oprId, x.prefixCode, x.clsOrg, x.cls,
  x.cost, x.priority, rating, x.flag, x.ext
   from r20_route07 x, tt_timecls_selected b
   where x.routeCls = b.routecls and x.oprId = b.oprid and x.pc = b.pc and x.prefixCode = b.prefixcode and x.cls = b.cls
   order by x.cost;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;    

    




    
    
                      
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select
   'r20_route07' routeset,
   x.seqno priority, x.id, x.isactive, x.reason, x.`exception`, IFNULL(x.ext,0) ext,
  x.routecls, x.prefixcode, y.universe, y.`domain`, y.pdomain,
    y.`group`, y.name interface, y.userinfo, y.hint, x.clsOrg, x.cls timecls, x.cost, x.flag, x.rating,
 '11111' access, 0 redlist
   from tt_route x, r_interface y, r_interfaceGroup ig 
   where x.oprId = y.id and ig.tintid = x.oprId and ig.IntGroupID = v_pOperatorGroup and ig.flag = 1 and x.isactive = 1
   and v_pLongest like CONCAT_WS('',x.prefixcode,'%')
   order by seqno+calcException;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;                      
 
   drop TEMPORARY table IF EXISTS tt_route;   
   drop TEMPORARY table IF EXISTS tt_timecls_selected; 
   drop TEMPORARY table IF EXISTS tt_operator_selected; 
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r24_routeGetCache_Grade` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `r24_routeGetCache_Grade`(v_pLongest VARCHAR(32),                              
   v_pLongestCls INT,      
   v_pDate DATETIME(3),                              
   v_pSrcInt VARCHAR(7),                              
   v_pSrcIntGroup VARCHAR(64),                              
   v_pSrcIntDom VARCHAR(64),                              
   v_routeclass INT  ,                          
   v_pCLI VARCHAR(32),                              
   v_pOperatorGroup INT    ,
   v_isgrade INT)
begin

                              
   DECLARE v_pc VARCHAR(2);                              
   DECLARE v_dd INT;
   DECLARE v_hh INT;
   DECLARE v_mm INT;
                             
   IF v_routeclass is null then
      set v_routeclass = 0;
   END IF;
   IF v_pCLI is null then
      set v_pCLI = '';
   END IF;
   IF v_pOperatorGroup is null then
      set v_pOperatorGroup = 0;
   END IF;
   IF v_isgrade is null then
      set v_isgrade = 0;
   END IF;
   set v_pc = left(v_pLongest,2);                              
   set v_dd = 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7;
   select(EXTRACT(HOUR FROM v_pDate) -timezone) INTO v_hh from r_info;
   set v_mm = EXTRACT(MINUTE FROM v_pDate);
                      


   CREATE TEMPORARY TABLE tt_operator_selected 
   (
      routecls INT NOT NULL,
      oprId INT NOT NULL,
      cls VARCHAR(1) NOT NULL,
      pc VARCHAR(2) NOT NULL
   );

   CREATE  UNIQUE  INDEX idx1 ON `#operator_selected2`
   (routecls, 
   oprId, 
   cls, 
   pc);


   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   insert into tt_operator_selected(routecls,oprId,cls,pc)
   select x.routecls,x.oprId,x.cls,x.pc  from r20_route_timecls x, r_timecls y, r_interface tit,
r_timecode tco, r_daycode dco 
   where x.routecls = 0
   and tit.id = x.oprId and tit.state = 'I'
   and y.tintid = x.oprId and y.cls = x.cls
   and y.dc = dco.id and y.tc = tco.id and y.sc = 0
   and v_dd between dco.d1 and dco.d2
   and((24+v_hh+IFNULL(tit.prefixcls,0))%24)*100+v_mm between tco.h1 and tco.h2 -1
   and x.pc = v_pc;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;      


   CREATE TEMPORARY TABLE tt_timecls_selected 
   (
      routecls INT NOT NULL,
      oprId INT NOT NULL,
      pc VARCHAR(2) NOT NULL,
      prefixcode VARCHAR(50) NOT NULL,
      cnt INT,
      clsA INT,
      clsP INT,
      clsO INT,
      clsW INT,
      cls VARCHAR(1) NOT NULL
   ); 

   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   insert into tt_timecls_selected(routecls,oprid,pc,prefixcode,cnt,clsA,clsP,clsO,clsW,cls)
   select a.routeCls, a.oprId, a.pc, max(a.prefixCode) prefixCode,
	count(*) cnt,
	sum(case when a.cls = 'A' then 1 else 0 end) clsA,
	sum(case when a.cls = 'P' then 1 else 0 end) clsP,
	sum(case when a.cls = 'O' then 1 else 0 end) clsO,
	sum(case when a.cls = 'W' then 1 else 0 end) clsW, 'Z' cls
   from r20_route07 a, tt_operator_selected b
   where a.routeCls = b.routeCls and a.oprId = b.oprId and a.cls = b.cls and a.pc = b.pc
   and left(v_pLongest,prefixLen) = a.prefixCode
   group by a.routeCls,a.oprId,a.pc;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;   

   update tt_timecls_selected
   set cls =(case when (clsW > 0) and (cnt = clsW) then 'W'
   when (clsO > 0) and (cnt = clsO) then 'O'
   when (clsP > 0) and (cnt = clsP) then 'P'
   when (clsA > 0) and (cnt = clsA) then 'A'
   else 'Z' end);

   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   update tt_timecls_selected
   set cls =(select max(a.cls) from r20_route07 a 
   where a.routeCls = tt_timecls_selected2.routecls
   and a.oprId = tt_timecls_selected2.oprId
   and a.pc = tt_timecls_selected2.pc
   and a.prefixCode = tt_timecls_selected2.prefixCode
   and ((a.cls = 'A' and tt_timecls_selected2.clsA <> 0) or
		        (a.cls = 'P' and tt_timecls_selected2.clsP <> 0) or
		        (a.cls = 'O' and tt_timecls_selected2.clsO <> 0) or
		        (a.cls = 'W' and tt_timecls_selected2.clsW <> 0)))
   where cls = 'Z';
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

   CREATE TEMPORARY TABLE tt_route 
   (
      seqno INT   AUTO_INCREMENT PRIMARY KEY,
      priority INT,
      id INT,
      isactive INT,
      reason INT,
      `exception` INT,
      calcexception INT,
      ext INT,
      oprid INT,
      parentid INT,
      routecls INT,
      prefixcode VARCHAR(50),
      universe VARCHAR(5),
      `domain` VARCHAR(5),
      pdomain VARCHAR(5),
      `group` VARCHAR(40),
      interface VARCHAR(40),
      userinfo VARCHAR(40),
      hint VARCHAR(100),
      clsorg CHAR(1),
      cls CHAR(1),
      cost FLOAT,
      flag INT,
      rating INT,
      access VARCHAR(10),
      redlist INT,
      quality FLOAT
   )  AUTO_INCREMENT = 10;


   if v_isgrade = 0 then

      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      insert into tt_route(isactive,reason,`exception`,calcexception,id,parentid,routecls,oprid,prefixcode,clsorg,cls,cost,
priority,rating,flag,ext,quality)


      select
      x.state isactive, x.reason,
  IFNULL(x.`exception`,0) `exception`,
  case
      when ((IFNULL(x.`exception`,0) = 0) or (x.prefixCode <> v_pLongest)) then 0
      when x.`exception` > 0 then cast((x.`exception`+0.5)*10 as SIGNED INTEGER)
      else cast((x.`exception` -0.5)*10 as SIGNED INTEGER)
      end calcException,
  x.id, x.parentId, x.routeCls, x.oprId, x.prefixCode, x.clsOrg, x.cls,
  x.cost, x.priority, rating, x.flag, x.ext,x.quality
      from r20_route07 x, tt_timecls_selected b
      where x.routeCls = b.routecls and x.oprId = b.oprid and x.pc = b.pc and x.prefixCode = b.prefixcode and x.cls = b.cls
      order by x.cost;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   else
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      insert into tt_route(isactive,reason,`exception`,calcexception,id,parentid,routecls,oprid,prefixcode,clsorg,cls,cost,
priority,rating,flag,ext,quality)


      select
      x.state isactive, x.reason,
  IFNULL(x.`exception`,0) `exception`,
  case
      when ((IFNULL(x.`exception`,0) = 0) or (x.prefixCode <> v_pLongest)) then 0
      when x.`exception` > 0 then cast((x.`exception`+0.5)*10 as SIGNED INTEGER)
      else cast((x.`exception` -0.5)*10 as SIGNED INTEGER)
      end calcException,
  x.id, x.parentId, x.routeCls, x.oprId, x.prefixCode, x.clsOrg, x.cls,
  x.cost, x.priority, rating, x.flag, x.ext,x.quality
      from r20_route07 x, tt_timecls_selected b
      where x.routeCls = b.routecls and x.oprId = b.oprid and x.pc = b.pc and x.prefixCode = b.prefixcode and x.cls = b.cls
      order by x.quality,x.cost;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   end if;

    




    
    
                      
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select
   'r20_route07' routeset,
   x.seqno priority, x.id, x.isactive, x.reason, x.`exception`, IFNULL(x.ext,0) ext,
  x.routecls, x.prefixcode, y.universe, y.`domain`, y.pdomain,
    y.`group`, y.name interface, y.userinfo, y.hint, x.clsOrg, x.cls timecls, x.cost, x.flag, x.rating,
 '11111' access, 0 redlist,x.quality grade
   from tt_route x, r_interface y, r_interfaceGroup ig 
   where x.oprId = y.id and ig.tintid = x.oprId and ig.IntGroupID = v_pOperatorGroup and ig.flag = 1 and x.isactive = 1
   and v_pLongest like CONCAT_WS('',x.prefixcode,'%')
   order by seqno+calcException;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;                      
 
   drop TEMPORARY table IF EXISTS tt_route;   
   drop TEMPORARY table IF EXISTS tt_timecls_selected; 
   drop TEMPORARY table IF EXISTS tt_operator_selected; 
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r24_routeGetCache_ORI` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `r24_routeGetCache_ORI`(v_pLongest VARCHAR(32),                                
   v_pLongestCls INT,        
   v_pDate DATETIME(3),                                
   v_pSrcInt VARCHAR(7),                                
   v_pSrcIntGroup VARCHAR(64),                                
   v_pSrcIntDom VARCHAR(64),                                
   v_routeclass INT  ,                            
   v_pCLI VARCHAR(32),                                
   v_pOperatorGroup INT)
begin

                                
   DECLARE v_pc VARCHAR(2);                                
   DECLARE v_dd INT;  
   DECLARE v_hh INT;  
   DECLARE v_mm INT;  
  
                        
                               
   IF v_routeclass is null then
      set v_routeclass = 0;
   END IF;
   IF v_pCLI is null then
      set v_pCLI = '';
   END IF;
   IF v_pOperatorGroup is null then
      set v_pOperatorGroup = 0;
   END IF;
   set v_pc = left(v_pLongest,2);                                
   set v_dd = 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7;  
   select(EXTRACT(HOUR FROM v_pDate) -timezone) INTO v_hh from r_info;  
   set v_mm = EXTRACT(MINUTE FROM v_pDate);  
  
   DROP TEMPORARY TABLE IF EXISTS tt_operator_selected;  
  
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   CREATE TEMPORARY TABLE tt_operator_selected AS select x.* from r20_route_timecls x, r_timecls y, r_interface tit,
r_timecode tco, r_daycode dco 
      where x.routecls = 0
      and tit.id = x.oprId and tit.state = 'I'
      and y.tintid = x.oprId and y.cls = x.cls
      and y.dc = dco.id and y.tc = tco.id and y.sc = 0
      and v_dd between dco.d1 and dco.d2
      and((24+v_hh+IFNULL(tit.prefixcls,0))%24)*100+v_mm between tco.h1 and tco.h2 -1
      and x.pc = v_pc;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;        
  
   DROP TEMPORARY TABLE IF EXISTS tt_timecls_selected;        
  
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   CREATE TEMPORARY TABLE tt_timecls_selected AS select a.routeCls, a.oprId, a.pc, max(a.prefixCode) prefixCode,
 count(*) cnt,
 sum(case when a.cls = 'A' then 1 else 0 end) clsA,
 sum(case when a.cls = 'P' then 1 else 0 end) clsP,
 sum(case when a.cls = 'O' then 1 else 0 end) clsO,
 sum(case when a.cls = 'W' then 1 else 0 end) clsW, 'Z' cls

      from r20_route07 a, tt_operator_selected b
      where a.routeCls = b.routeCls and a.oprId = b.oprId and a.cls = b.cls and a.pc = b.pc
      and left(v_pLongest,prefixLen) = a.prefixCode
      group by a.routeCls,a.oprId,a.pc;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;     
  
   update tt_timecls_selected
   set cls =(case when (clsW > 0) and (cnt = clsW) then 'W'
   when (clsO > 0) and (cnt = clsO) then 'O'
   when (clsP > 0) and (cnt = clsP) then 'P'
   when (clsA > 0) and (cnt = clsA) then 'A'
   else 'Z' end);  
  
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   update tt_timecls_selected
   set cls =(select max(a.cls) from r20_route07 a 
   where a.routeCls = tt_timecls_selected2.routecls
   and a.oprId = tt_timecls_selected2.oprId
   and a.pc = tt_timecls_selected2.pc
   and a.prefixCode = tt_timecls_selected2.prefixCode
   and ((a.cls = 'A' and tt_timecls_selected2.clsA <> 0) or
          (a.cls = 'P' and tt_timecls_selected2.clsP <> 0) or
          (a.cls = 'O' and tt_timecls_selected2.clsO <> 0) or
          (a.cls = 'W' and tt_timecls_selected2.clsW <> 0)))
   where cls = 'Z';
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
      
   DROP TEMPORARY TABLE IF EXISTS tt_routes;  
      
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   CREATE TEMPORARY TABLE tt_routes AS select * from(select
         x.state isactive, x.reason,
  IFNULL(x.`exception`,0) `exception`,
  case
         when ((IFNULL(x.`exception`,0) = 0) or (x.prefixCode <> v_pLongest)) then 0
         when x.`exception` > 0 then cast((x.`exception`+0.5)*10 as SIGNED INTEGER)
         else cast((x.`exception` -0.5)*10 as SIGNED INTEGER)
         end calcException,
  x.id, x.parentId, x.routeCls, x.oprId, x.prefixCode, x.clsOrg, x.cls,
  x.costOrgCurr, x.costOrg, x.cost, x.priority, rating, x.flag, x.ext,x.quality
         from r20_route07 x, tt_timecls_selected b
         where x.routeCls = b.routeCls and x.oprId = b.oprId and x.pc = b.pc and x.prefixCode = b.prefixCode and x.cls = b.cls) c order by cost;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;      
      
   DROP TEMPORARY TABLE IF EXISTS tt_1;      
      
   CREATE TEMPORARY TABLE tt_1
   (
      seqno INT AUTO_INCREMENT UNIQUE
   ) AS select tt_routes.* from tt_routes WHERE 1 = 0;
   INSERT INTO tt_1  select tt_routes.* from tt_routes;      
  
  
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select
   'r20_route07' routeset,
   x.seqno priority, x.id, x.isactive, x.reason, x.`exception`, IFNULL(x.ext,0) ext,
  x.routecls, x.prefixcode, y.universe, y.`domain`, y.pdomain,
    y.`group`, y.name interface, y.userinfo, y.hint, x.clsOrg, x.cls timecls, x.cost, x.flag, x.rating,
 '11111' access, 0 redlist,x.quality grade
   from tt_1 x, r_interface y, r_interfaceGroup ig 
   where x.oprId = y.id and ig.tintid = x.oprId and ig.IntGroupID = v_pOperatorGroup and ig.flag = 1 and x.isactive = 1
   and v_pLongest like CONCAT(x.prefixcode,'%')
   order by seqno+calcException;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;                        
      
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r24_routeSpecialGetCache` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `r24_routeSpecialGetCache`(v_pLongest VARCHAR(32),                                        
   v_pDate DATETIME(3),                                        
   v_pSrcInt VARCHAR(7),                                        
   v_pSrcIntGroup VARCHAR(64),                                        
   v_pSrcIntDom VARCHAR(64),                                        
   v_routeclass INT  ,                                    
   v_pCLI VARCHAR(32),                                        
   v_pOperatorGroup INT)
begin

            
            
   IF v_routeclass is null then
      set v_routeclass = 0;
   END IF;
   IF v_pCLI is null then
      set v_pCLI = '';
   END IF;
   IF v_pOperatorGroup is null then
      set v_pOperatorGroup = 0;
   END IF;
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select 'r20_route07' routeSet, 1 priority, a.id, a.state isactive, reason, 0 `exception`, 0 ext, a.routeCls,
 prefixCode, c.universe, b.`domain`, b.pdomain, b.`group`, b.name interface, b.userinfo, b.hint,
 clsOrg, cls timeCls, cost, flag, rating, '11111' access, 0 redList, 0 `except`,quality grade,IFNULL(b.intcls,0) intcls,
 exceptioncls capability,IFNULL(b.type,1) oprtype
   from r20_route07 a, r_interface b, r_domain c 
   where a.routeCls = 0 and a.pc = left(v_pLongest,2) and a.prefixCode = v_pLongest
   and a.oprId = b.id and b.`domain` = c.name and a.state = 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;        
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `recordCount` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `recordCount`(v_tablename VARCHAR(100))
begin


   DECLARE v_strquery VARCHAR(2000);
   set v_strquery =CONCAT( 'SELECT rows FROM sysindexes2 WHERE id = OBJECT_ID(''', v_tablename,  ''') AND indid < 2');
   SET @SWV_Stmt = v_strquery;
   PREPARE SWT_Stmt FROM @SWV_Stmt;
   EXECUTE SWT_Stmt;
   DEALLOCATE PREPARE SWT_Stmt;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `routecls0_get_route` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `routecls0_get_route`(v_pDDI            VARCHAR(32)  
   ,v_pDate          DATETIME(3)  
   ,v_pSrcInt        VARCHAR(7)    
   ,v_pSrcIntGroup   VARCHAR(64)   
   ,v_pSrcIntDom     VARCHAR(64)   
   ,v_pRouteCls      INT   
   ,v_pCLI           VARCHAR(32)     
   ,v_pOperatorGroup    INT)
begin

  
   DECLARE v_prefix1 VARCHAR(32);  
  
   IF v_pRouteCls is null then
      set v_pRouteCls = 0;
   END IF;
   IF v_pCLI is null then
      set v_pCLI = '';
   END IF;
   IF v_pOperatorGroup is null then
      set v_pOperatorGroup = 0;
   END IF;
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   prefixcode INTO v_prefix1 from r_prefix1  where left(v_pDDI,2) = pc and v_pDDI like CONCAT(prefixcode,'%')   order by prefixlen desc LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
  
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select 'r06' routeset, x.isactive, x.routecls, x.dprefixcode prefixcode,
       tdo.universe, tit.`domain` `domain`, tit.pdomain pdomain, tit.`group` `group`,
       tit.name interface, tit.userinfo, tit.hint, x.cls timecls, x.priority, x.cost, x.flag, 1 redlist,
       CONCAT('1',(case when access & 0x8 = 0 then '0' else '1' end),(case when access & 0x4 = 0 then '0' else '1' end),
   (case when access & 0x2 = 0 then '0' else '1' end),
   (case when access & 0x1 = 0 then '0' else '1' end)) access,rating
   from R06 x, r_TimeCls y,
     r_interface tit,
     r_domain tdo,
     r_timecode ttc,
     r_daycode tdc,
     r_interfacegroup ig,
     r_info tif 
   where x.routecls = 0 and x.dpc = left(v_pDDI,2) and x.dprefixcode = v_prefix1
   and x.tintid = tit.id and tit.state = 'I'
   and tit.`domain` = tdo.name
   and x.tintid = y.tintid and x.cls = y.cls
   and y.dc = tdc.id
   and tdc.d1 <= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
   and tdc.d2 >= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
   and y.tc = ttc.id
   and ttc.h1 <=(((24+EXTRACT(HOUR FROM v_pDate)+tdo.timezone -tif.timezone)%24)*100+EXTRACT(MINUTE FROM v_pDate))
   and ttc.h2 >(((24+EXTRACT(HOUR FROM v_pDate)+tdo.timezone -tif.timezone)%24)*100+EXTRACT(MINUTE FROM v_pDate))
   and y.sc = 0  and ig.tintid = tit.id and ig.intgroupid = v_pOperatorGroup
   order by x.priority,x.cost;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;    
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `routecls0_get_route_1` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `routecls0_get_route_1`(v_pDDI            VARCHAR(32)
   ,v_pDate          DATETIME(3)
   ,v_pSrcInt        VARCHAR(7)    
   ,v_pSrcIntGroup   VARCHAR(64)   
   ,v_pSrcIntDom     VARCHAR(64)   
   ,v_pRouteCls      INT 
   ,v_pCLI           VARCHAR(32))
begin


   DECLARE v_prefix1 VARCHAR(32);

   IF v_pRouteCls is null then
      set v_pRouteCls = 0;
   END IF;
   IF v_pCLI is null then
      set v_pCLI = '';
   END IF;
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   prefixcode INTO v_prefix1 from r_prefix1  where left(v_pDDI,2) = pc and v_pDDI like CONCAT(prefixcode,'%')   order by prefixlen desc LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select x.isactive, x.routecls, x.dprefixcode prefixcode,
       tdo.universe, tit.`domain` `domain`, tit.pdomain pdomain, tit.`group` `group`,
       tit.name interface, tit.userinfo, tit.hint, x.cls timecls, x.priority, x.cost, x.flag, 0 redlist,
       CONCAT('1',(case when access & 0x8 = 0 then '0' else '1' end),(case when access & 0x4 = 0 then '0' else '1' end),
   (case when access & 0x2 = 0 then '0' else '1' end),
   (case when access & 0x1 = 0 then '0' else '1' end)) access
   from R12 x, r_TimeCls y,
     r_interface tit,
     r_domain tdo,
     r_timecode ttc,
     r_daycode tdc,
     r_info tif 
   where x.routecls = 0 and x.dpc = left(v_pDDI,2) and x.dprefixcode = v_prefix1
   and x.tintid = tit.id and tit.state = 'I'
   and tit.`domain` = tdo.name
   and x.tintid = y.tintid and x.cls = y.cls
   and y.dc = tdc.id
   and tdc.d1 <= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
   and tdc.d2 >= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
   and y.tc = ttc.id
   and ttc.h1 <=(((24+EXTRACT(HOUR FROM v_pDate)+tdo.timezone -tif.timezone)%24)*100+EXTRACT(MINUTE FROM v_pDate))
   and ttc.h2 >(((24+EXTRACT(HOUR FROM v_pDate)+tdo.timezone -tif.timezone)%24)*100+EXTRACT(MINUTE FROM v_pDate))
   and y.sc = 0
   order by x.priority,x.cost;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `routecls0_get_route_BEFORE` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `routecls0_get_route_BEFORE`(v_pDDI            VARCHAR(32)    
   ,v_pDate          DATETIME(3)    
   ,v_pSrcInt        VARCHAR(7)    
   ,v_pSrcIntGroup   VARCHAR(64)   
   ,v_pSrcIntDom     VARCHAR(64)   
   ,v_pRouteCls      INT     
   ,v_pCLI           VARCHAR(32)      
   ,v_pOperatorGroup    INT)
begin

    
   DECLARE v_prefix1 VARCHAR(32);    
    
   IF v_pRouteCls is null then
      set v_pRouteCls = 0;
   END IF;
   IF v_pCLI is null then
      set v_pCLI = '';
   END IF;
   IF v_pOperatorGroup is null then
      set v_pOperatorGroup = 0;
   END IF;
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   prefixcode INTO v_prefix1 from r_prefix1  where left(v_pDDI,2) = pc and v_pDDI like CONCAT(prefixcode,'%')   order by prefixlen desc LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;    
    
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select 'r02' routeset, x.isactive, x.routecls, x.dprefixcode prefixcode,
       tdo.universe, tit.`domain` `domain`, tit.pdomain pdomain, tit.`group` `group`,
       tit.name interface, tit.userinfo, tit.hint, x.cls timecls, x.priority, x.cost, x.flag, 1 redlist,
       CONCAT('1',(case when access & 0x8 = 0 then '0' else '1' end),(case when access & 0x4 = 0 then '0' else '1' end),
   (case when access & 0x2 = 0 then '0' else '1' end),
   (case when access & 0x1 = 0 then '0' else '1' end)) access,rating
   from R02 x, r_TimeCls y,
     r_interface tit,
     r_domain tdo,
     r_timecode ttc,
     r_daycode tdc,
     r_interfacegroup ig,
     r_info tif 
   where x.routecls = 0 and x.dpc = left(v_pDDI,2) and x.dprefixcode = v_prefix1
   and x.tintid = tit.id and tit.state = 'I'
   and tit.`domain` = tdo.name
   and x.tintid = y.tintid and x.cls = y.cls
   and y.dc = tdc.id
   and tdc.d1 <= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
   and tdc.d2 >= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
   and y.tc = ttc.id
   and ttc.h1 <=(((24+EXTRACT(HOUR FROM v_pDate)+tdo.timezone -tif.timezone)%24)*100+EXTRACT(MINUTE FROM v_pDate))
   and ttc.h2 >(((24+EXTRACT(HOUR FROM v_pDate)+tdo.timezone -tif.timezone)%24)*100+EXTRACT(MINUTE FROM v_pDate))
   and y.sc = 0  and ig.tintid = tit.id and ig.intgroupid = v_pOperatorGroup
   order by x.priority,x.cost;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;    
    
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `routecls0_get_route_debug` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `routecls0_get_route_debug`(v_pDDI            VARCHAR(32)
   ,v_pDate          DATETIME(3)
   ,v_pSrcInt        VARCHAR(7)    
   ,v_pSrcIntGroup   VARCHAR(64)   
   ,v_pSrcIntDom     VARCHAR(64)   
   ,v_pRouteCls      INT 
   ,v_pCLI           VARCHAR(32))
begin

   
   IF v_pRouteCls is null then
      set v_pRouteCls = 0;
   END IF;
   IF v_pCLI is null then
      set v_pCLI = '';
   END IF;
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select isactive, routecls, dprefixcode prefixcode, universe, `domain`, pdomain, `group`, interface, userinfo, hint, timecls, priority, cost, flag
   from(select x.isactive, x.routecls, x.dprefixcode, ty.universe, ty.`domain` `domain`, ty.pdomain pdomain, ty.`group` `group`, ty.name interface,
   ty.hint, ty.userinfo, x.cls timecls, x.priority, x.cost, x.flag
      from(select a.* from r05_route a 
         where (a.dpc = SUBSTR(v_pDDI,1,2))
         and a.dprefixcode =(select  prefixcode
            from r_prefix1 
            where (pc = SUBSTR(v_pDDI,1,2))
            and state = 'I'
            and v_pDDI like CONCAT(prefixcode,'%')
            order by prefixlen desc LIMIT 1)
         and sc = 0) x, r_interface ty,
   r_domain d,
   r_timecode t, r_daycode td,
   r_info curr 
      where x.tintid = ty.id and ty.state = 'I'
      and (v_pSrcInt = '' or (x.sintid = 0) or (x.sintid =(select  id from r_interface  where name = v_pSrcInt and `domain` = v_pSrcIntDom LIMIT 1)))
      and ty.`domain` = d.name
      and x.dc = td.id
      and td.d1 <= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
      and td.d2 >= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
      and x.tc = t.id
      and t.h1 <=(((24+EXTRACT(HOUR FROM v_pDate)+d.timezone -curr.timezone)%24)*100+EXTRACT(MINUTE FROM v_pDate))
      and t.h2 >(((24+EXTRACT(HOUR FROM v_pDate)+d.timezone -curr.timezone)%24)*100+EXTRACT(MINUTE FROM v_pDate))) z
   order by z.priority;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `routecls0_get_route_ORI` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `routecls0_get_route_ORI`(v_pDDI            VARCHAR(32)  
   ,v_pDate          DATETIME(3)  
   ,v_pSrcInt        VARCHAR(7)    
   ,v_pSrcIntGroup   VARCHAR(64)   
   ,v_pSrcIntDom     VARCHAR(64)   
   ,v_pRouteCls      INT   
   ,v_pCLI           VARCHAR(32))
begin

  
   DECLARE v_prefix1 VARCHAR(32);  
  
   IF v_pRouteCls is null then
      set v_pRouteCls = 0;
   END IF;
   IF v_pCLI is null then
      set v_pCLI = '';
   END IF;
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   prefixcode INTO v_prefix1 from r_prefix1  where left(v_pDDI,2) = pc and v_pDDI like CONCAT(prefixcode,'%')   order by prefixlen desc LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
  
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select 'r01' routeset, x.isactive, x.routecls, x.dprefixcode prefixcode,
       tdo.universe, tit.`domain` `domain`, tit.pdomain pdomain, tit.`group` `group`,
       tit.name interface, tit.userinfo, tit.hint, x.cls timecls, x.priority, x.cost, x.flag, 1 redlist,
       CONCAT('1',(case when access & 0x8 = 0 then '0' else '1' end),(case when access & 0x4 = 0 then '0' else '1' end),
   (case when access & 0x2 = 0 then '0' else '1' end),
   (case when access & 0x1 = 0 then '0' else '1' end)) access,rating
   from R01 x, r_TimeCls y,
     r_interface tit,
     r_domain tdo,
     r_timecode ttc,
     r_daycode tdc,
     r_info tif 
   where x.routecls = 0 and x.dpc = left(v_pDDI,2) and x.dprefixcode = v_prefix1
   and x.tintid = tit.id and tit.state = 'I'
   and tit.`domain` = tdo.name
   and x.tintid = y.tintid and x.cls = y.cls
   and y.dc = tdc.id
   and tdc.d1 <= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
   and tdc.d2 >= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
   and y.tc = ttc.id
   and ttc.h1 <=(((24+EXTRACT(HOUR FROM v_pDate)+tdo.timezone -tif.timezone)%24)*100+EXTRACT(MINUTE FROM v_pDate))
   and ttc.h2 >(((24+EXTRACT(HOUR FROM v_pDate)+tdo.timezone -tif.timezone)%24)*100+EXTRACT(MINUTE FROM v_pDate))
   and y.sc = 0
   order by x.priority,x.cost;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
  
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `routecls0_get_route_test` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `routecls0_get_route_test`(v_pDDI            VARCHAR(32)
   ,v_pDate          DATETIME(3)
   ,v_pSrcInt        VARCHAR(7)    
   ,v_pSrcIntGroup   VARCHAR(64)   
   ,v_pSrcIntDom     VARCHAR(64)   
   ,v_pRouteCls      INT 
   ,v_pCLI           VARCHAR(32))
begin


   DECLARE v_prefix1 VARCHAR(32);

   IF v_pRouteCls is null then
      set v_pRouteCls = 0;
   END IF;
   IF v_pCLI is null then
      set v_pCLI = '';
   END IF;
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   prefixcode INTO v_prefix1 from r_prefix1  where left(v_pDDI,2) = pc and v_pDDI like CONCAT(prefixcode,'%')   order by prefixlen desc LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select 'r11' routeset, x.isactive, x.routecls, x.dprefixcode prefixcode,
       tdo.universe, tit.`domain` `domain`, tit.pdomain pdomain, tit.`group` `group`,
       tit.name interface, tit.userinfo, tit.hint, x.cls timecls, x.priority, x.cost, x.flag, 1 redlist,
       CONCAT('1',(case when access & 0x8 = 0 then '0' else '1' end),(case when access & 0x4 = 0 then '0' else '1' end),
   (case when access & 0x2 = 0 then '0' else '1' end),
   (case when access & 0x1 = 0 then '0' else '1' end)) access,rating
   from R11 x, r_TimeCls y,
     r_interface tit,
     r_domain tdo,
     r_timecode ttc,
     r_daycode tdc,
     r_info tif 
   where x.routecls = 0 and x.dpc = left(v_pDDI,2) and x.dprefixcode = v_prefix1
   and x.tintid = tit.id and tit.state = 'I'
   and tit.`domain` = tdo.name
   and x.tintid = y.tintid and x.cls = y.cls
   and y.dc = tdc.id
   and tdc.d1 <= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
   and tdc.d2 >= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
   and y.tc = ttc.id
   and ttc.h1 <=(((24+EXTRACT(HOUR FROM v_pDate)+tdo.timezone -tif.timezone)%24)*100+EXTRACT(MINUTE FROM v_pDate))
   and ttc.h2 >(((24+EXTRACT(HOUR FROM v_pDate)+tdo.timezone -tif.timezone)%24)*100+EXTRACT(MINUTE FROM v_pDate))
   and y.sc = 0
   order by x.priority,x.cost;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `routecls0_get_route_undo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `routecls0_get_route_undo`(v_pDDI            VARCHAR(32)
   ,v_pDate          DATETIME(3)
   ,v_pSrcInt        VARCHAR(7)    
   ,v_pSrcIntGroup   VARCHAR(64)   
   ,v_pSrcIntDom     VARCHAR(64)   
   ,v_pRouteCls      INT 
   ,v_pCLI           VARCHAR(32))
begin


   DECLARE v_prefix1 VARCHAR(32);

   IF v_pRouteCls is null then
      set v_pRouteCls = 0;
   END IF;
   IF v_pCLI is null then
      set v_pCLI = '';
   END IF;
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   prefixcode INTO v_prefix1 from r_prefix1  where left(v_pDDI,2) = pc and v_pDDI like CONCAT(prefixcode,'%')   order by prefixlen desc LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select 'r11' routeset, x.isactive, x.routecls, x.dprefixcode prefixcode,
       tdo.universe, tit.`domain` `domain`, tit.pdomain pdomain, tit.`group` `group`,
       tit.name interface, tit.userinfo, tit.hint, x.cls timecls, x.priority, x.cost, x.flag, 1 redlist,
       CONCAT('1',(case when access & 0x8 = 0 then '0' else '1' end),(case when access & 0x4 = 0 then '0' else '1' end),
   (case when access & 0x2 = 0 then '0' else '1' end),
   (case when access & 0x1 = 0 then '0' else '1' end)) access,rating
   from R11 x, r_TimeCls y,
     r_interface tit,
     r_domain tdo,
     r_timecode ttc,
     r_daycode tdc,
     r_info tif 
   where x.routecls = 0 and x.dpc = left(v_pDDI,2) and x.dprefixcode = v_prefix1
   and x.tintid = tit.id and tit.state = 'I'
   and tit.`domain` = tdo.name
   and x.tintid = y.tintid and x.cls = y.cls
   and y.dc = tdc.id
   and tdc.d1 <= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
   and tdc.d2 >= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
   and y.tc = ttc.id
   and ttc.h1 <=(((24+EXTRACT(HOUR FROM v_pDate)+tdo.timezone -tif.timezone)%24)*100+EXTRACT(MINUTE FROM v_pDate))
   and ttc.h2 >(((24+EXTRACT(HOUR FROM v_pDate)+tdo.timezone -tif.timezone)%24)*100+EXTRACT(MINUTE FROM v_pDate))
   and y.sc = 0
   order by x.priority,x.cost;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `routecls0_get_route_v2` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `routecls0_get_route_v2`(v_pDDI            VARCHAR(32)  
   ,v_pDate          DATETIME(3)  
   ,v_pSrcInt        VARCHAR(7)    
   ,v_pSrcIntGroup   VARCHAR(64)   
   ,v_pSrcIntDom     VARCHAR(64)   
   ,v_pRouteCls      INT   
   ,v_pCLI           VARCHAR(32)    
   ,v_pOperatorGroup    INT)
begin

  
   DECLARE v_prefix1 VARCHAR(32);  
  
   IF v_pRouteCls is null then
      set v_pRouteCls = 0;
   END IF;
   IF v_pCLI is null then
      set v_pCLI = '';
   END IF;
   IF v_pOperatorGroup is null then
      set v_pOperatorGroup = 0;
   END IF;
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   prefixcode INTO v_prefix1 from r_prefix1  where left(v_pDDI,2) = pc and v_pDDI like CONCAT(prefixcode,'%')   order by prefixlen desc LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
  
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select 'r01' routeset, x.isactive, x.routecls, x.dprefixcode prefixcode,
       tdo.universe, tit.`domain` `domain`, tit.pdomain pdomain, tit.`group` `group`,
       tit.name interface, tit.userinfo, tit.hint, x.cls timecls, x.priority, x.cost, x.flag, 1 redlist,
       CONCAT('1',(case when access & 0x8 = 0 then '0' else '1' end),(case when access & 0x4 = 0 then '0' else '1' end),
   (case when access & 0x2 = 0 then '0' else '1' end),
   (case when access & 0x1 = 0 then '0' else '1' end)) access,rating
   from R01 x, r_TimeCls y,
     r_interface tit,
     r_domain tdo,
     r_timecode ttc,
     r_daycode tdc,
     r_interfacegroup ig,
     r_info tif 
   where x.routecls = 0 and x.dpc = left(v_pDDI,2) and x.dprefixcode = v_prefix1
   and x.tintid = tit.id and tit.state = 'I'
   and tit.`domain` = tdo.name
   and x.tintid = y.tintid and x.cls = y.cls
   and y.dc = tdc.id
   and tdc.d1 <= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
   and tdc.d2 >= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
   and y.tc = ttc.id
   and ttc.h1 <=(((24+EXTRACT(HOUR FROM v_pDate)+tdo.timezone -tif.timezone)%24)*100+EXTRACT(MINUTE FROM v_pDate))
   and ttc.h2 >(((24+EXTRACT(HOUR FROM v_pDate)+tdo.timezone -tif.timezone)%24)*100+EXTRACT(MINUTE FROM v_pDate))
   and y.sc = 0  and ig.tintid = tit.id and ig.intgroupid = v_pOperatorGroup
   order by x.priority,x.cost;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
  
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `routecls102_get_route` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `routecls102_get_route`(v_pDDI            VARCHAR(32)
   ,v_pDate          DATETIME(3)
   ,v_pSrcInt        VARCHAR(7)    
   ,v_pSrcIntGroup   VARCHAR(64)   
   ,v_pSrcIntDom     VARCHAR(64)   
   ,v_pRouteCls      INT 
   ,v_pCLI           VARCHAR(32))
begin


   DECLARE v_prefix1 VARCHAR(32);

   IF v_pRouteCls is null then
      set v_pRouteCls = 0;
   END IF;
   IF v_pCLI is null then
      set v_pCLI = '';
   END IF;
   select   prefixcode INTO v_prefix1 from r_prefix1 where v_pDDI like CONCAT(prefixcode,'%')   order by prefixlen desc LIMIT 1;

   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select x.isactive, x.routecls, x.dprefixcode prefixcode,
       tdo.universe, tit.`domain` `domain`, tit.pdomain pdomain, tit.`group` `group`,
       tit.name interface, tit.userinfo, tit.hint, x.cls timecls, x.priority, x.cost, x.flag, 0 redlist
   from R10_Tollfree x, r_TimeCls y,
     r_interface tit,
     r_domain tdo,
     r_timecode ttc,
     r_daycode tdc,
     r_info tif 
   where x.routecls = 102 and x.dpc = left(v_pDDI,2) and x.dprefixcode = v_prefix1
   and x.tintid = tit.id and tit.state = 'I'
   and tit.`domain` = tdo.name
   and x.tintid = y.tintid and x.cls = y.cls
   and y.dc = tdc.id
   and tdc.d1 <= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
   and tdc.d2 >= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
   and y.tc = ttc.id
   and ttc.h1 <=(((24+EXTRACT(HOUR FROM v_pDate)+tdo.timezone -tif.timezone)%24)*100+EXTRACT(MINUTE FROM v_pDate))
   and ttc.h2 >(((24+EXTRACT(HOUR FROM v_pDate)+tdo.timezone -tif.timezone)%24)*100+EXTRACT(MINUTE FROM v_pDate))
   and y.sc = 0
   order by x.priority;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `routecls103_get_route` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `routecls103_get_route`(v_pDDI            VARCHAR(32)
   ,v_pDate          DATETIME(3)
   ,v_pSrcInt        VARCHAR(7)    
   ,v_pSrcIntGroup   VARCHAR(64)   
   ,v_pSrcIntDom     VARCHAR(64)   
   ,v_pRouteCls      INT 
   ,v_pCLI           VARCHAR(32))
begin


   DECLARE v_prefix1 VARCHAR(32);

   IF v_pRouteCls is null then
      set v_pRouteCls = 0;
   END IF;
   IF v_pCLI is null then
      set v_pCLI = '';
   END IF;
   select   prefixcode INTO v_prefix1 from r_prefix1 where v_pDDI like CONCAT(prefixcode,'%')   order by prefixlen desc LIMIT 1;

   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select x.isactive, x.routecls, x.dprefixcode prefixcode,
       tdo.universe, tit.`domain` `domain`, tit.pdomain pdomain, tit.`group` `group`,
       tit.name interface, tit.userinfo, tit.hint, x.cls timecls, x.priority, x.cost, x.flag, 0 redlist
   from R10_ITFS x, r_TimeCls y,
     r_interface tit,
     r_domain tdo,
     r_timecode ttc,
     r_daycode tdc,
     r_info tif 
   where x.routecls = 103 and x.dpc = left(v_pDDI,2) and x.dprefixcode = v_prefix1
   and x.tintid = tit.id and tit.state = 'I'
   and tit.`domain` = tdo.name
   and x.tintid = y.tintid and x.cls = y.cls
   and y.dc = tdc.id
   and tdc.d1 <= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
   and tdc.d2 >= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
   and y.tc = ttc.id
   and ttc.h1 <=(((24+EXTRACT(HOUR FROM v_pDate)+tdo.timezone -tif.timezone)%24)*100+EXTRACT(MINUTE FROM v_pDate))
   and ttc.h2 >(((24+EXTRACT(HOUR FROM v_pDate)+tdo.timezone -tif.timezone)%24)*100+EXTRACT(MINUTE FROM v_pDate))
   and y.sc = 0
   order by x.priority;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `routecls104_get_route` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `routecls104_get_route`(v_pDDI            VARCHAR(32)
   ,v_pDate          DATETIME(3)
   ,v_pSrcInt        VARCHAR(7)    
   ,v_pSrcIntGroup   VARCHAR(64)   
   ,v_pSrcIntDom     VARCHAR(64)   
   ,v_pRouteCls      INT 
   ,v_pCLI           VARCHAR(32))
begin


   DECLARE v_prefix1 VARCHAR(32);

   IF v_pRouteCls is null then
      set v_pRouteCls = 0;
   END IF;
   IF v_pCLI is null then
      set v_pCLI = '';
   END IF;
   select   prefixcode INTO v_prefix1 from r_prefix1 where v_pDDI like CONCAT(prefixcode,'%')   order by prefixlen desc LIMIT 1;

   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select x.isactive, x.routecls, x.dprefixcode prefixcode,
       tdo.universe, tit.`domain` `domain`, tit.pdomain pdomain, tit.`group` `group`,
       tit.name interface, tit.userinfo, tit.hint, x.cls timecls, x.priority, x.cost, x.flag, 0 redlist
   from R10_Mobile x, r_TimeCls y,
     r_interface tit,
     r_domain tdo,
     r_timecode ttc,
     r_daycode tdc,
     r_info tif 
   where x.routecls = 104 and x.dpc = left(v_pDDI,2) and x.dprefixcode = v_prefix1
   and x.tintid = tit.id and tit.state = 'I'
   and tit.`domain` = tdo.name
   and x.tintid = y.tintid and x.cls = y.cls
   and y.dc = tdc.id
   and tdc.d1 <= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
   and tdc.d2 >= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
   and y.tc = ttc.id
   and ttc.h1 <=(((24+EXTRACT(HOUR FROM v_pDate)+tdo.timezone -tif.timezone)%24)*100+EXTRACT(MINUTE FROM v_pDate))
   and ttc.h2 >(((24+EXTRACT(HOUR FROM v_pDate)+tdo.timezone -tif.timezone)%24)*100+EXTRACT(MINUTE FROM v_pDate))
   and y.sc = 0
   order by x.priority;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `routecls105_get_route` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `routecls105_get_route`(v_pDDI            VARCHAR(32)
   ,v_pDate          DATETIME(3)
   ,v_pSrcInt        VARCHAR(7)    
   ,v_pSrcIntGroup   VARCHAR(64)   
   ,v_pSrcIntDom     VARCHAR(64)   
   ,v_pRouteCls      INT 
   ,v_pCLI           VARCHAR(32))
begin


   DECLARE v_prefix1 VARCHAR(32);

   IF v_pRouteCls is null then
      set v_pRouteCls = 0;
   END IF;
   IF v_pCLI is null then
      set v_pCLI = '';
   END IF;
   select   prefixcode INTO v_prefix1 from r_prefix1 where v_pDDI like CONCAT(prefixcode,'%')   order by prefixlen desc LIMIT 1;

   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select x.isactive, x.routecls, x.dprefixcode prefixcode,
       tdo.universe, tit.`domain` `domain`, tit.pdomain pdomain, tit.`group` `group`,
       tit.name interface, tit.userinfo, tit.hint, x.cls timecls, x.priority, x.cost, x.flag, 0 redlist
   from R10_Payphone x, r_TimeCls y,
     r_interface tit,
     r_domain tdo,
     r_timecode ttc,
     r_daycode tdc,
     r_info tif 
   where x.routecls = 105 and x.dpc = left(v_pDDI,2) and x.dprefixcode = v_prefix1
   and x.tintid = tit.id and tit.state = 'I'
   and tit.`domain` = tdo.name
   and x.tintid = y.tintid and x.cls = y.cls
   and y.dc = tdc.id
   and tdc.d1 <= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
   and tdc.d2 >= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
   and y.tc = ttc.id
   and ttc.h1 <=(((24+EXTRACT(HOUR FROM v_pDate)+tdo.timezone -tif.timezone)%24)*100+EXTRACT(MINUTE FROM v_pDate))
   and ttc.h2 >(((24+EXTRACT(HOUR FROM v_pDate)+tdo.timezone -tif.timezone)%24)*100+EXTRACT(MINUTE FROM v_pDate))
   and y.sc = 0
   order by x.priority;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `routecls10_get_route` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `routecls10_get_route`(v_pDDI            VARCHAR(32)
   ,v_pDate          DATETIME(3)
   ,v_pSrcInt        VARCHAR(7)    
   ,v_pSrcIntGroup   VARCHAR(64)   
   ,v_pSrcIntDom     VARCHAR(64)   
   ,v_pRouteCls      INT 
   ,v_pCLI           VARCHAR(32))
begin

   
   IF v_pRouteCls is null then
      set v_pRouteCls = 0;
   END IF;
   IF v_pCLI is null then
      set v_pCLI = '';
   END IF;
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select isactive, routecls, dprefixcode prefixcode, universe, `domain`, pdomain, `group`, interface, userinfo, hint, timecls, priority, cost, flag, 0 redlist
   from(select x.isactive, x.routecls, x.dprefixcode, ty.universe, ty.`domain` `domain`, ty.pdomain pdomain, ty.`group` `group`, ty.name interface,
   ty.hint, ty.userinfo, x.cls timecls, x.priority, x.cost, x.flag
      from(select a.* from rWCom_01 a 
         where (a.dpc = SUBSTR(v_pDDI,1,2))
         and a.dprefixcode =(select  prefixcode
            from r_prefix1 
            where (pc = SUBSTR(v_pDDI,1,2))
            and state = 'I'
            and v_pDDI like CONCAT(prefixcode,'%')
            order by prefixlen desc LIMIT 1)
         and sc = 0) x, r_interface ty,
   r_domain d,
   r_timecode t, r_daycode td,
   r_info curr 
      where x.tintid = ty.id and ty.state = 'I'
      and (v_pSrcInt = '' or (x.sintid = 0) or (x.sintid =(select  id from r_interface  where name = v_pSrcInt and `domain` = v_pSrcIntDom LIMIT 1)))
      and ty.`domain` = d.name
      and x.dc = td.id
      and td.d1 <= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
      and td.d2 >= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
      and x.tc = t.id
      and t.h1 <=(((24+EXTRACT(HOUR FROM v_pDate)+d.timezone -curr.timezone)%24)*100+EXTRACT(MINUTE FROM v_pDate))
      and t.h2 >(((24+EXTRACT(HOUR FROM v_pDate)+d.timezone -curr.timezone)%24)*100+EXTRACT(MINUTE FROM v_pDate))) z
   order by z.priority;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `routecls11_get_route` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `routecls11_get_route`(v_pDDI            VARCHAR(32)
   ,v_pDate          DATETIME(3)
   ,v_pSrcInt        VARCHAR(7)    
   ,v_pSrcIntGroup   VARCHAR(64)   
   ,v_pSrcIntDom     VARCHAR(64)   
   ,v_pRouteCls      INT 
   ,v_pCLI           VARCHAR(32))
begin

   
   IF v_pRouteCls is null then
      set v_pRouteCls = 0;
   END IF;
   IF v_pCLI is null then
      set v_pCLI = '';
   END IF;
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select isactive, routecls, dprefixcode prefixcode, universe, `domain`, pdomain, `group`, interface, userinfo, hint, timecls, priority, cost, flag, 0 redlist
   from(select x.isactive, x.routecls, x.dprefixcode, ty.universe, ty.`domain` `domain`, ty.pdomain pdomain, ty.`group` `group`, ty.name interface,
   ty.hint, ty.userinfo, x.cls timecls, x.priority, x.cost, x.flag
      from(select a.* from rMilCallback_01 a 
         where (a.dpc = SUBSTR(v_pDDI,1,2))
         and a.dprefixcode =(select  prefixcode
            from r_prefix1 
            where (pc = SUBSTR(v_pDDI,1,2))
            and state = 'I'
            and v_pDDI like CONCAT(prefixcode,'%')
            order by prefixlen desc LIMIT 1)
         and sc = 0) x, r_interface ty,
   r_domain d,
   r_timecode t, r_daycode td,
   r_info curr 
      where x.tintid = ty.id and ty.state = 'I'
      and (v_pSrcInt = '' or (x.sintid = 0) or (x.sintid =(select  id from r_interface  where name = v_pSrcInt and `domain` = v_pSrcIntDom LIMIT 1)))
      and ty.`domain` = d.name
      and x.dc = td.id
      and td.d1 <= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
      and td.d2 >= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
      and x.tc = t.id
      and t.h1 <=(((24+EXTRACT(HOUR FROM v_pDate)+d.timezone -curr.timezone)%24)*100+EXTRACT(MINUTE FROM v_pDate))
      and t.h2 >(((24+EXTRACT(HOUR FROM v_pDate)+d.timezone -curr.timezone)%24)*100+EXTRACT(MINUTE FROM v_pDate))) z
   order by z.priority;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `routecls13_get_route` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `routecls13_get_route`(v_pDDI            VARCHAR(32)
   ,v_pDate          DATETIME(3)
   ,v_pSrcInt        VARCHAR(7)    
   ,v_pSrcIntGroup   VARCHAR(64)   
   ,v_pSrcIntDom     VARCHAR(64)   
   ,v_pRouteCls      INT 
   ,v_pCLI           VARCHAR(32))
begin


   DECLARE v_prefix1 VARCHAR(32);

   IF v_pRouteCls is null then
      set v_pRouteCls = 0;
   END IF;
   IF v_pCLI is null then
      set v_pCLI = '';
   END IF;
   select   prefixcode INTO v_prefix1 from r_prefix1 where v_pDDI like CONCAT(prefixcode,'%')   order by prefixlen desc LIMIT 1;

   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select x.isactive, x.routecls, x.dprefixcode prefixcode,
       tdo.universe, tit.`domain` `domain`, tit.pdomain pdomain, tit.`group` `group`,
       tit.name interface, tit.userinfo, tit.hint, x.cls timecls, x.priority, x.cost, x.flag, 0 redlist
   from r10_VIAG x, r_TimeCls y,
     r_interface tit,
     r_domain tdo,
     r_timecode ttc,
     r_daycode tdc,
     r_info tif 
   where x.routecls = 13 and x.dpc = left(v_pDDI,2) and x.dprefixcode = v_prefix1
   and x.tintid = tit.id and tit.state = 'I'
   and tit.`domain` = tdo.name
   and x.tintid = y.tintid and x.cls = y.cls
   and y.dc = tdc.id
   and tdc.d1 <= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
   and tdc.d2 >= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
   and y.tc = ttc.id
   and ttc.h1 <=(((24+EXTRACT(HOUR FROM v_pDate)+tdo.timezone -tif.timezone)%24)*100+EXTRACT(MINUTE FROM v_pDate))
   and ttc.h2 >(((24+EXTRACT(HOUR FROM v_pDate)+tdo.timezone -tif.timezone)%24)*100+EXTRACT(MINUTE FROM v_pDate))
   order by x.priority;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `routecls1_get_route` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `routecls1_get_route`(v_pDDI            VARCHAR(32)
   ,v_pDate          DATETIME(3)
   ,v_pSrcInt        VARCHAR(7)    
   ,v_pSrcIntGroup   VARCHAR(64)   
   ,v_pSrcIntDom     VARCHAR(64)   
   ,v_pRouteCls      INT 
   ,v_pCLI           VARCHAR(32))
begin


   DECLARE v_prefix1 VARCHAR(32);

   IF v_pRouteCls is null then
      set v_pRouteCls = 0;
   END IF;
   IF v_pCLI is null then
      set v_pCLI = '';
   END IF;
   select   prefixcode INTO v_prefix1 from r_prefix1 where v_pDDI like CONCAT(prefixcode,'%')   order by prefixlen desc LIMIT 1;

   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select x.isactive, x.routecls, x.dprefixcode prefixcode,
       tdo.universe, tit.`domain` `domain`, tit.pdomain pdomain, tit.`group` `group`,
       tit.name interface, tit.userinfo, tit.hint, x.cls timecls, x.priority, x.cost, x.flag, 0 redlist
   from R09_Belgacom x, r_TimeCls y,
     r_interface tit,
     r_domain tdo,
     r_timecode ttc,
     r_daycode tdc,
     r_info tif 
   where x.routecls = 1 and x.dpc = left(v_pDDI,2) and x.dprefixcode = v_prefix1
   and x.tintid = tit.id and tit.state = 'I'
   and tit.`domain` = tdo.name
   and x.tintid = y.tintid and x.cls = y.cls
   and y.dc = tdc.id
   and tdc.d1 <= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
   and tdc.d2 >= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
   and y.tc = ttc.id
   and ttc.h1 <=(((24+EXTRACT(HOUR FROM v_pDate)+tdo.timezone -tif.timezone)%24)*100+EXTRACT(MINUTE FROM v_pDate))
   and ttc.h2 >(((24+EXTRACT(HOUR FROM v_pDate)+tdo.timezone -tif.timezone)%24)*100+EXTRACT(MINUTE FROM v_pDate))
   order by x.priority;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `routecls201_get_route` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `routecls201_get_route`(v_pDDI            VARCHAR(32)
   ,v_pDate          DATETIME(3)
   ,v_pSrcInt        VARCHAR(7)    
   ,v_pSrcIntGroup   VARCHAR(64)   
   ,v_pSrcIntDom     VARCHAR(64)   
   ,v_pRouteCls      INT 
   ,v_pCLI           VARCHAR(32))
begin


   DECLARE v_prefix1 VARCHAR(32);

   IF v_pRouteCls is null then
      set v_pRouteCls = 0;
   END IF;
   IF v_pCLI is null then
      set v_pCLI = '';
   END IF;
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   prefixcode INTO v_prefix1 from r_prefix1  where left(v_pDDI,2) = pc and v_pDDI like CONCAT(prefixcode,'%')   order by prefixlen desc LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select x.isactive, x.routecls, x.dprefixcode prefixcode,
       tdo.universe, tit.`domain` `domain`, tit.pdomain pdomain, tit.`group` `group`,
       tit.name interface, tit.userinfo, tit.hint, x.cls timecls, x.priority, x.cost, x.flag, 1 redlist,
       CONCAT('1',(case when access & 0x8 = 0 then '0' else '1' end),(case when access & 0x4 = 0 then '0' else '1' end),
   (case when access & 0x2 = 0 then '0' else '1' end),
   (case when access & 0x1 = 0 then '0' else '1' end)) access,rating
   from R_callback_milan x, r_TimeCls y,
     r_interface tit,
     r_domain tdo,
     r_timecode ttc,
     r_daycode tdc,
     r_info tif 
   where x.routecls = v_pRouteCls and x.dpc = left(v_pDDI,2) and x.dprefixcode = v_prefix1
   and x.tintid = tit.id and tit.state = 'I'
   and tit.`domain` = tdo.name
   and x.tintid = y.tintid and x.cls = y.cls
   and y.dc = tdc.id
   and tdc.d1 <= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
   and tdc.d2 >= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
   and y.tc = ttc.id
   and ttc.h1 <=(((24+EXTRACT(HOUR FROM v_pDate)+tdo.timezone -tif.timezone)%24)*100+EXTRACT(MINUTE FROM v_pDate))
   and ttc.h2 >(((24+EXTRACT(HOUR FROM v_pDate)+tdo.timezone -tif.timezone)%24)*100+EXTRACT(MINUTE FROM v_pDate))
   and y.sc = 0
   order by x.priority,x.cost;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `routecls202_get_route` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `routecls202_get_route`(v_pDDI            VARCHAR(32)
   ,v_pDate          DATETIME(3)
   ,v_pSrcInt        VARCHAR(7)    
   ,v_pSrcIntGroup   VARCHAR(64)   
   ,v_pSrcIntDom     VARCHAR(64)   
   ,v_pRouteCls      INT 
   ,v_pCLI           VARCHAR(32))
begin


   DECLARE v_prefix1 VARCHAR(32);

   IF v_pRouteCls is null then
      set v_pRouteCls = 0;
   END IF;
   IF v_pCLI is null then
      set v_pCLI = '';
   END IF;
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   prefixcode INTO v_prefix1 from r_prefix1  where left(v_pDDI,2) = pc and v_pDDI like CONCAT(prefixcode,'%')   order by prefixlen desc LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select x.isactive, x.routecls, x.dprefixcode prefixcode,
       tdo.universe, tit.`domain` `domain`, tit.pdomain pdomain, tit.`group` `group`,
       tit.name interface, tit.userinfo, tit.hint, x.cls timecls, x.priority, x.cost, x.flag, 1 redlist,
       CONCAT('1',(case when access & 0x8 = 0 then '0' else '1' end),(case when access & 0x4 = 0 then '0' else '1' end),
   (case when access & 0x2 = 0 then '0' else '1' end),
   (case when access & 0x1 = 0 then '0' else '1' end)) access,rating
   from R_callback_ams x, r_TimeCls y,
     r_interface tit,
     r_domain tdo,
     r_timecode ttc,
     r_daycode tdc,
     r_info tif 
   where x.routecls = v_pRouteCls and x.dpc = left(v_pDDI,2) and x.dprefixcode = v_prefix1
   and x.tintid = tit.id and tit.state = 'I'
   and tit.`domain` = tdo.name
   and x.tintid = y.tintid and x.cls = y.cls
   and y.dc = tdc.id
   and tdc.d1 <= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
   and tdc.d2 >= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
   and y.tc = ttc.id
   and ttc.h1 <=(((24+EXTRACT(HOUR FROM v_pDate)+tdo.timezone -tif.timezone)%24)*100+EXTRACT(MINUTE FROM v_pDate))
   and ttc.h2 >(((24+EXTRACT(HOUR FROM v_pDate)+tdo.timezone -tif.timezone)%24)*100+EXTRACT(MINUTE FROM v_pDate))
   and y.sc = 0
   order by x.priority,x.cost;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `routecls2_get_route` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `routecls2_get_route`(v_pDDI            VARCHAR(32)
   ,v_pDate          DATETIME(3)
   ,v_pSrcInt        VARCHAR(7)    
   ,v_pSrcIntGroup   VARCHAR(64)   
   ,v_pSrcIntDom     VARCHAR(64)   
   ,v_pRouteCls      INT 
   ,v_pCLI           VARCHAR(32))
begin

   
   DECLARE v_id INT;
   DECLARE v_prefixcode1 VARCHAR(17);

   IF v_pRouteCls is null then
      set v_pRouteCls = 0;
   END IF;
   IF v_pCLI is null then
      set v_pCLI = '';
   END IF;
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   id INTO v_id from r_interface  where name = v_pSrcInt and `domain` = v_pSrcIntDom    LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   prefixcode INTO v_prefixcode1 from r_prefix1  where (pc = SUBSTR(v_pDDI,1,2))
   and state = 'I'
   and v_pDDI like CONCAT(prefixcode,'%')   order by prefixlen desc LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select isactive, routecls, dprefixcode prefixcode, universe, `domain`, pdomain, `group`, interface, userinfo, hint, timecls, priority, cost, flag, 0 redlist
   from(select x.isactive, x.routecls, x.dprefixcode,
	     tit.universe, tit.`domain` `domain`, tit.pdomain pdomain,
	     tit.`group` `group`, tit.name interface,
         tit.hint, tit.userinfo, x.cls timecls, x.priority, x.cost, x.flag
      from(select a.* from rAlbacom_01 a 
         where (a.dpc = SUBSTR(v_pDDI,1,2))
         and a.dprefixcode = v_prefixcode1
         and sc = 0) x, r_interface tit,
      r_domain tdo, r_timecode ttc, r_daycode tdc,
      r_info tif 
      where x.tintid = tit.id and tit.state = 'I'
      and (v_id is null or x.tintid <> v_id)
      and tit.`domain` = tdo.name
      and x.dc = tdc.id
      and tdc.d1 <= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
      and tdc.d2 >= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
      and x.tc = ttc.id
      and ttc.h1 <=(((24+EXTRACT(HOUR FROM v_pDate)+tdo.timezone -tif.timezone)%24)*100+EXTRACT(MINUTE FROM v_pDate))
      and ttc.h2 >(((24+EXTRACT(HOUR FROM v_pDate)+tdo.timezone -tif.timezone)%24)*100+EXTRACT(MINUTE FROM v_pDate))) z
   order by z.priority;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `routecls3_get_route` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `routecls3_get_route`(v_pDDI            VARCHAR(32)
   ,v_pDate          DATETIME(3)
   ,v_pSrcInt        VARCHAR(7)    
   ,v_pSrcIntGroup   VARCHAR(64)   
   ,v_pSrcIntDom     VARCHAR(64)   
   ,v_pRouteCls      INT 
   ,v_pCLI           VARCHAR(32))
begin


   DECLARE v_prefix1 VARCHAR(32);

   IF v_pRouteCls is null then
      set v_pRouteCls = 0;
   END IF;
   IF v_pCLI is null then
      set v_pCLI = '';
   END IF;
   select   prefixcode INTO v_prefix1 from r_prefix1 where v_pDDI like CONCAT(prefixcode,'%')   order by prefixlen desc LIMIT 1;

   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select x.isactive, x.routecls, x.dprefixcode prefixcode,
       tdo.universe, tit.`domain` `domain`, tit.pdomain pdomain, tit.`group` `group`,
       tit.name interface, tit.userinfo, tit.hint, x.cls timecls, x.priority, x.cost, x.flag, 0 redlist
   from R09_Belgacom x, r_TimeCls y,
     r_interface tit,
     r_domain tdo,
     r_timecode ttc,
     r_daycode tdc,
     r_info tif 
   where x.routecls = 1 and x.dpc = left(v_pDDI,2) and x.dprefixcode = v_prefix1
   and x.tintid = tit.id and tit.state = 'I'
   and tit.`domain` = tdo.name
   and x.tintid = y.tintid and x.cls = y.cls
   and y.dc = tdc.id
   and tdc.d1 <= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
   and tdc.d2 >= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
   and y.tc = ttc.id
   and ttc.h1 <=(((24+EXTRACT(HOUR FROM v_pDate)+tdo.timezone -tif.timezone)%24)*100+EXTRACT(MINUTE FROM v_pDate))
   and ttc.h2 >(((24+EXTRACT(HOUR FROM v_pDate)+tdo.timezone -tif.timezone)%24)*100+EXTRACT(MINUTE FROM v_pDate))
   order by x.priority;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `routecls4_get_route` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `routecls4_get_route`(v_pDDI            VARCHAR(32)
   ,v_pDate          DATETIME(3)
   ,v_pSrcInt        VARCHAR(7)    
   ,v_pSrcIntGroup   VARCHAR(64)   
   ,v_pSrcIntDom     VARCHAR(64)   
   ,v_pRouteCls      INT 
   ,v_pCLI           VARCHAR(32))
begin


   DECLARE v_prefix1 VARCHAR(32);

   IF v_pRouteCls is null then
      set v_pRouteCls = 0;
   END IF;
   IF v_pCLI is null then
      set v_pCLI = '';
   END IF;
   select   prefixcode INTO v_prefix1 from r_prefix1 where v_pDDI like CONCAT(prefixcode,'%')   order by prefixlen desc LIMIT 1;

   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select x.isactive, x.routecls, x.dprefixcode prefixcode,
       tdo.universe, tit.`domain` `domain`, tit.pdomain pdomain, tit.`group` `group`,
       tit.name interface, tit.userinfo, tit.hint, x.cls timecls, x.priority, x.cost, x.flag, 0 redlist
   from R09_Siris x, r_TimeCls y,
     r_interface tit,
     r_domain tdo,
     r_timecode ttc,
     r_daycode tdc,
     r_info tif 
   where x.routecls = 4 and x.dpc = left(v_pDDI,2) and x.dprefixcode = v_prefix1
   and x.tintid = tit.id and tit.state = 'I'
   and tit.`domain` = tdo.name
   and x.tintid = y.tintid and x.cls = y.cls
   and y.dc = tdc.id
   and tdc.d1 <= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
   and tdc.d2 >= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
   and y.tc = ttc.id
   and ttc.h1 <=(((24+EXTRACT(HOUR FROM v_pDate)+tdo.timezone -tif.timezone)%24)*100+EXTRACT(MINUTE FROM v_pDate))
   and ttc.h2 >(((24+EXTRACT(HOUR FROM v_pDate)+tdo.timezone -tif.timezone)%24)*100+EXTRACT(MINUTE FROM v_pDate))
   order by x.priority;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `routecls5_get_route` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `routecls5_get_route`(v_pDDI            VARCHAR(32)
   ,v_pDate          DATETIME(3)
   ,v_pSrcInt        VARCHAR(7)    
   ,v_pSrcIntGroup   VARCHAR(64)   
   ,v_pSrcIntDom     VARCHAR(64)   
   ,v_pRouteCls      INT 
   ,v_pCLI           VARCHAR(32))
begin


   DECLARE v_prefix1 VARCHAR(32);

   IF v_pRouteCls is null then
      set v_pRouteCls = 0;
   END IF;
   IF v_pCLI is null then
      set v_pCLI = '';
   END IF;
   select   prefixcode INTO v_prefix1 from r_prefix1 where v_pDDI like CONCAT(prefixcode,'%')   order by prefixlen desc LIMIT 1;

   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select x.isactive, x.routecls, x.dprefixcode prefixcode,
       tdo.universe, tit.`domain` `domain`, tit.pdomain pdomain, tit.`group` `group`,
       tit.name interface, tit.userinfo, tit.hint, x.cls timecls, x.priority, x.cost, x.flag, 1 redlist
   from R10_Vectone x, r_TimeCls y,
     r_interface tit,
     r_domain tdo,
     r_timecode ttc,
     r_daycode tdc,
     r_info tif 
   where x.routecls = v_pRouteCls and x.dpc = left(v_pDDI,2) and x.dprefixcode = v_prefix1
   and x.tintid = tit.id and tit.state = 'I'
   and tit.`domain` = tdo.name
   and x.tintid = y.tintid and x.cls = y.cls
   and y.dc = tdc.id
   and tdc.d1 <= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
   and tdc.d2 >= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
   and y.tc = ttc.id
   and ttc.h1 <=(((24+EXTRACT(HOUR FROM v_pDate)+tdo.timezone -tif.timezone)%24)*100+EXTRACT(MINUTE FROM v_pDate))
   and ttc.h2 >(((24+EXTRACT(HOUR FROM v_pDate)+tdo.timezone -tif.timezone)%24)*100+EXTRACT(MINUTE FROM v_pDate))
   order by x.priority;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `routecls6_get_route` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `routecls6_get_route`(v_pDDI            VARCHAR(32)
   ,v_pDate          DATETIME(3)
   ,v_pSrcInt        VARCHAR(7)    
   ,v_pSrcIntGroup   VARCHAR(64)   
   ,v_pSrcIntDom     VARCHAR(64)   
   ,v_pRouteCls      INT 
   ,v_pCLI           VARCHAR(32))
begin


   DECLARE v_prefix1 VARCHAR(32);

   IF v_pRouteCls is null then
      set v_pRouteCls = 0;
   END IF;
   IF v_pCLI is null then
      set v_pCLI = '';
   END IF;
   select   prefixcode INTO v_prefix1 from r_prefix1 where v_pDDI like CONCAT(prefixcode,'%')   order by prefixlen desc LIMIT 1;

   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select x.isactive, x.routecls, x.dprefixcode prefixcode,
       tdo.universe, tit.`domain` `domain`, tit.pdomain pdomain, tit.`group` `group`,
       tit.name interface, tit.userinfo, tit.hint, x.cls timecls, x.priority, x.cost, x.flag, 0 redlist
   from R09_Uni2 x, r_TimeCls y,
     r_interface tit,
     r_domain tdo,
     r_timecode ttc,
     r_daycode tdc,
     r_info tif 
   where x.routecls = 6 and x.dpc = left(v_pDDI,2) and x.dprefixcode = v_prefix1
   and x.tintid = tit.id and tit.state = 'I'
   and tit.`domain` = tdo.name
   and x.tintid = y.tintid and x.cls = y.cls
   and y.dc = tdc.id
   and tdc.d1 <= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
   and tdc.d2 >= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
   and y.tc = ttc.id
   and ttc.h1 <=(((24+EXTRACT(HOUR FROM v_pDate)+tdo.timezone -tif.timezone)%24)*100+EXTRACT(MINUTE FROM v_pDate))
   and ttc.h2 >(((24+EXTRACT(HOUR FROM v_pDate)+tdo.timezone -tif.timezone)%24)*100+EXTRACT(MINUTE FROM v_pDate))
   order by x.priority;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `routecls7_get_route` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `routecls7_get_route`(v_pDDI            VARCHAR(32)
   ,v_pDate          DATETIME(3)
   ,v_pSrcInt        VARCHAR(7)    
   ,v_pSrcIntGroup   VARCHAR(64)   
   ,v_pSrcIntDom     VARCHAR(64)   
   ,v_pRouteCls      INT 
   ,v_pCLI           VARCHAR(32))
begin


   DECLARE v_prefix1 VARCHAR(32);

   IF v_pRouteCls is null then
      set v_pRouteCls = 0;
   END IF;
   IF v_pCLI is null then
      set v_pCLI = '';
   END IF;
   select   prefixcode INTO v_prefix1 from r_prefix1 where v_pDDI like CONCAT(prefixcode,'%')   order by prefixlen desc LIMIT 1;

   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select x.isactive, x.routecls, x.dprefixcode prefixcode,
       tdo.universe, tit.`domain` `domain`, tit.pdomain pdomain, tit.`group` `group`,
       tit.name interface, tit.userinfo, tit.hint, x.cls timecls, x.priority, x.cost, x.flag, 0 redlist
   from R10_Scom x, r_TimeCls y,
     r_interface tit,
     r_domain tdo,
     r_timecode ttc,
     r_daycode tdc,
     r_info tif 
   where x.routecls = 7 and x.dpc = left(v_pDDI,2) and x.dprefixcode = v_prefix1
   and x.tintid = tit.id and tit.state = 'I'
   and tit.`domain` = tdo.name
   and x.tintid = y.tintid and x.cls = y.cls
   and y.dc = tdc.id
   and tdc.d1 <= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
   and tdc.d2 >= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
   and y.tc = ttc.id
   and ttc.h1 <=(((24+EXTRACT(HOUR FROM v_pDate)+tdo.timezone -tif.timezone)%24)*100+EXTRACT(MINUTE FROM v_pDate))
   and ttc.h2 >(((24+EXTRACT(HOUR FROM v_pDate)+tdo.timezone -tif.timezone)%24)*100+EXTRACT(MINUTE FROM v_pDate))
   and y.sc = 0
   order by x.priority;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `routecls81_get_route` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `routecls81_get_route`(v_pDDI            VARCHAR(32)
   ,v_pDate          DATETIME(3)
   ,v_pSrcInt        VARCHAR(7)    
   ,v_pSrcIntGroup   VARCHAR(64)   
   ,v_pSrcIntDom     VARCHAR(64)   
   ,v_pRouteCls      INT 
   ,v_pCLI           VARCHAR(32))
begin


   DECLARE v_prefix1 VARCHAR(32);

   IF v_pRouteCls is null then
      set v_pRouteCls = 0;
   END IF;
   IF v_pCLI is null then
      set v_pCLI = '';
   END IF;
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   prefixcode INTO v_prefix1 from r_prefix1  where left(v_pDDI,2) = pc and v_pDDI like CONCAT(prefixcode,'%')   order by prefixlen desc LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select x.isactive, x.routecls, x.dprefixcode prefixcode,
       tdo.universe, tit.`domain` `domain`, tit.pdomain pdomain, tit.`group` `group`,
       tit.name interface, tit.userinfo, tit.hint, x.cls timecls, x.priority, x.cost, x.flag, 1 redlist,
       CONCAT('1',(case when access & 0x8 = 0 then '0' else '1' end),(case when access & 0x4 = 0 then '0' else '1' end),
   (case when access & 0x2 = 0 then '0' else '1' end),
   (case when access & 0x1 = 0 then '0' else '1' end)) access,rating
   from R_callback_milan x, r_TimeCls y,
     r_interface tit,
     r_domain tdo,
     r_timecode ttc,
     r_daycode tdc,
     r_info tif 
   where x.routecls = 201 and x.dpc = left(v_pDDI,2) and x.dprefixcode = v_prefix1
   and x.tintid = tit.id and tit.state = 'I'
   and tit.`domain` = tdo.name
   and x.tintid = y.tintid and x.cls = y.cls
   and y.dc = tdc.id
   and tdc.d1 <= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
   and tdc.d2 >= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
   and y.tc = ttc.id
   and ttc.h1 <=(((24+EXTRACT(HOUR FROM v_pDate)+tdo.timezone -tif.timezone)%24)*100+EXTRACT(MINUTE FROM v_pDate))
   and ttc.h2 >(((24+EXTRACT(HOUR FROM v_pDate)+tdo.timezone -tif.timezone)%24)*100+EXTRACT(MINUTE FROM v_pDate))
   and y.sc = 0
   order by x.priority,x.cost;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `routecls82_get_route` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `routecls82_get_route`(v_pDDI            VARCHAR(32)
   ,v_pDate          DATETIME(3)
   ,v_pSrcInt        VARCHAR(7)    
   ,v_pSrcIntGroup   VARCHAR(64)   
   ,v_pSrcIntDom     VARCHAR(64)   
   ,v_pRouteCls      INT 
   ,v_pCLI           VARCHAR(32))
begin


   DECLARE v_prefix1 VARCHAR(32);

   IF v_pRouteCls is null then
      set v_pRouteCls = 0;
   END IF;
   IF v_pCLI is null then
      set v_pCLI = '';
   END IF;
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select   prefixcode INTO v_prefix1 from r_prefix1  where left(v_pDDI,2) = pc and v_pDDI like CONCAT(prefixcode,'%')   order by prefixlen desc LIMIT 1;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select x.isactive, x.routecls, x.dprefixcode prefixcode,
       tdo.universe, tit.`domain` `domain`, tit.pdomain pdomain, tit.`group` `group`,
       tit.name interface, tit.userinfo, tit.hint, x.cls timecls, x.priority, x.cost, x.flag, 1 redlist,
       CONCAT('1',(case when access & 0x8 = 0 then '0' else '1' end),(case when access & 0x4 = 0 then '0' else '1' end),
   (case when access & 0x2 = 0 then '0' else '1' end),
   (case when access & 0x1 = 0 then '0' else '1' end)) access,rating
   from R_callback_ams x, r_TimeCls y,
     r_interface tit,
     r_domain tdo,
     r_timecode ttc,
     r_daycode tdc,
     r_info tif 
   where x.routecls = 202 and x.dpc = left(v_pDDI,2) and x.dprefixcode = v_prefix1
   and x.tintid = tit.id and tit.state = 'I'
   and tit.`domain` = tdo.name
   and x.tintid = y.tintid and x.cls = y.cls
   and y.dc = tdc.id
   and tdc.d1 <= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
   and tdc.d2 >= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
   and y.tc = ttc.id
   and ttc.h1 <=(((24+EXTRACT(HOUR FROM v_pDate)+tdo.timezone -tif.timezone)%24)*100+EXTRACT(MINUTE FROM v_pDate))
   and ttc.h2 >(((24+EXTRACT(HOUR FROM v_pDate)+tdo.timezone -tif.timezone)%24)*100+EXTRACT(MINUTE FROM v_pDate))
   and y.sc = 0
   order by x.priority,x.cost;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `routecls8_get_route` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `routecls8_get_route`(v_pDDI            VARCHAR(32)
   ,v_pDate          DATETIME(3)
   ,v_pSrcInt        VARCHAR(7)    
   ,v_pSrcIntGroup   VARCHAR(64)   
   ,v_pSrcIntDom     VARCHAR(64)   
   ,v_pRouteCls      INT 
   ,v_pCLI           VARCHAR(32))
begin


   DECLARE v_prefix1 VARCHAR(32);

   IF v_pRouteCls is null then
      set v_pRouteCls = 0;
   END IF;
   IF v_pCLI is null then
      set v_pCLI = '';
   END IF;
   select   prefixcode INTO v_prefix1 from r_prefix1 where v_pDDI like CONCAT(prefixcode,'%')   order by prefixlen desc LIMIT 1;

   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select x.isactive, x.routecls, x.dprefixcode prefixcode,
       tdo.universe, tit.`domain` `domain`, tit.pdomain pdomain, tit.`group` `group`,
       tit.name interface, tit.userinfo, tit.hint, x.cls timecls, x.priority, x.cost, x.flag, 0 redlist
   from r09_callback x, r_TimeCls y,
     r_interface tit,
     r_domain tdo,
     r_timecode ttc,
     r_daycode tdc,
     r_info tif 
   where x.routecls = 8 and x.dpc = left(v_pDDI,2) and x.dprefixcode = v_prefix1
   and x.tintid = tit.id and tit.state = 'I'
   and tit.`domain` = tdo.name
   and x.tintid = y.tintid and x.cls = y.cls
   and y.dc = tdc.id
   and tdc.d1 <= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
   and tdc.d2 >= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
   and y.tc = ttc.id
   and ttc.h1 <=(((24+EXTRACT(HOUR FROM v_pDate)+tdo.timezone -tif.timezone)%24)*100+EXTRACT(MINUTE FROM v_pDate))
   and ttc.h2 >(((24+EXTRACT(HOUR FROM v_pDate)+tdo.timezone -tif.timezone)%24)*100+EXTRACT(MINUTE FROM v_pDate))
   order by x.priority;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `routecls9_get_route` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `routecls9_get_route`(v_pDDI            VARCHAR(32)
   ,v_pDate          DATETIME(3)
   ,v_pSrcInt        VARCHAR(7)    
   ,v_pSrcIntGroup   VARCHAR(64)   
   ,v_pSrcIntDom     VARCHAR(64)   
   ,v_pRouteCls      INT 
   ,v_pCLI           VARCHAR(32))
begin


   DECLARE v_prefix1 VARCHAR(32);

   IF v_pRouteCls is null then
      set v_pRouteCls = 0;
   END IF;
   IF v_pCLI is null then
      set v_pCLI = '';
   END IF;
   select   prefixcode INTO v_prefix1 from r_prefix1 where v_pDDI like CONCAT(prefixcode,'%')   order by prefixlen desc LIMIT 1;

   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select x.isactive, x.routecls, x.dprefixcode prefixcode,
       tdo.universe, tit.`domain` `domain`, tit.pdomain pdomain, tit.`group` `group`,
       tit.name interface, tit.userinfo, tit.hint, x.cls timecls, x.priority, x.cost, x.flag, 0 redlist
   from R09_Net2 x, r_TimeCls y,
     r_interface tit,
     r_domain tdo,
     r_timecode ttc,
     r_daycode tdc,
     r_info tif 
   where x.routecls = 9 and x.dpc = left(v_pDDI,2) and x.dprefixcode = v_prefix1
   and x.tintid = tit.id and tit.state = 'I'
   and tit.`domain` = tdo.name
   and x.tintid = y.tintid and x.cls = y.cls
   and y.dc = tdc.id
   and tdc.d1 <= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
   and tdc.d2 >= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
   and y.tc = ttc.id
   and ttc.h1 <=(((24+EXTRACT(HOUR FROM v_pDate)+tdo.timezone -tif.timezone)%24)*100+EXTRACT(MINUTE FROM v_pDate))
   and ttc.h2 >(((24+EXTRACT(HOUR FROM v_pDate)+tdo.timezone -tif.timezone)%24)*100+EXTRACT(MINUTE FROM v_pDate))
   order by x.priority;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `routeclsTest_get_route` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `routeclsTest_get_route`(v_pDDI            VARCHAR(32)
   ,v_pDate          DATETIME(3)
   ,v_pSrcInt        VARCHAR(7)    
   ,v_pSrcIntGroup   VARCHAR(64)   
   ,v_pSrcIntDom     VARCHAR(64)   
   ,v_pRouteCls      INT 
   ,v_pCLI           VARCHAR(32))
begin


   DECLARE v_prefix1 VARCHAR(32);

   IF v_pRouteCls is null then
      set v_pRouteCls = 0;
   END IF;
   IF v_pCLI is null then
      set v_pCLI = '';
   END IF;
   select   prefixcode INTO v_prefix1 from r_prefix1 where v_pDDI like CONCAT(prefixcode,'%')   order by prefixlen desc LIMIT 1;

   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select x.isactive, x.routecls, x.dprefixcode prefixcode,
       tdo.universe, tit.`domain` `domain`, tit.pdomain pdomain, tit.`group` `group`,
       tit.name interface, tit.userinfo, tit.hint, x.cls timecls, x.priority, x.cost, x.flag, 0 redlist,'11111' access,
       (select  rating from r_rating  where tintid = x.tintid and left(x.dprefixcode,varint) = prefixcode LIMIT 1) rating
   from R01 x, r_TimeCls y,
     r_interface tit,
     r_domain tdo,
     r_timecode ttc,
     r_daycode tdc,
     r_info tif 
   where x.routecls = 0 and x.dpc = left(v_pDDI,2) and x.dprefixcode = v_prefix1
   and x.tintid = tit.id and tit.state = 'I'
   and tit.`domain` = tdo.name
   and x.tintid = y.tintid and x.cls = y.cls
   and y.dc = tdc.id
   and tdc.d1 <= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
   and tdc.d2 >= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
   and y.tc = ttc.id
   and ttc.h1 <=(((24+EXTRACT(HOUR FROM v_pDate)+tdo.timezone -tif.timezone)%24)*100+EXTRACT(MINUTE FROM v_pDate))
   and ttc.h2 >(((24+EXTRACT(HOUR FROM v_pDate)+tdo.timezone -tif.timezone)%24)*100+EXTRACT(MINUTE FROM v_pDate))
   and sc = 0
   order by x.priority,x.cost;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `rset_select` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `rset_select`(v_pRouteSet VARCHAR(32))
SWL_return:
begin


   DECLARE v_pRouteTable VARCHAR(32);
   DECLARE v_sql VARCHAR(5000);

   select   route INTO v_pRouteTable from r_set where name = v_pRouteSet; 
   if v_pRouteTable is null then 
      LEAVE SWL_return;
   end if;
   START TRANSACTION;
   set v_sql = '
ALTER procedure es07_get_route0
   @pDDI            varchar(32)
   ,@pDate          datetime
   ,@pSrcInt        varchar(7)    -- e.g: DAC001
   ,@pSrcIntGroup   varchar(64)   -- e.g: 10.6.3.9   -- ignored
   ,@pSrcIntDom     varchar(64)   -- e.g: ZUR
   ,@pCLI           varchar(32)   =''''
   as
   begin   
   select routecls, dprefixcode prefixcode, universe, domain, "group", interface, '''' userinfo,
   hint, timecls, priority, cost, flag
   from (
   select x.routecls, x.cprefixcode cli, x.dprefixcode, ty.universe, ty.domain domain, ty."group" "group", ty.name interface, 
   ty.hint, x.cls timecls, 
   x.priority, x.cost, x.flag
   from (
      select a.* 
      from ' || v_pRouteTable || ' a with (nolock)
      where (@pCLI='''' or a.cprefixcode=@pCLI)
      and (a.dpc=substring(@pDDI, 1, 2))
      and a.dprefixcode=(
         select top 1 prefixcode 
         from r_prefix1 with (nolock)
         where (pc=substring(@pDDI, 1, 2))
         and @pDDI like prefixcode+''%''
         order by prefixlen desc
         )
      and sc=0
   ) x, r_interface ty with (nolock), 
   r_domain d with (nolock), 
   r_timecode t with (nolock), r_daycode td with (nolock),
   r_info curr with (nolock)
   where x.tintid = ty.id and ty.state = ''I'' 
   and (@pSrcInt='''' or (x.sintid=0) or (x.sintid=(select top 1 id from r_interface with (nolock) where name=@pSrcInt and domain=@pSrcIntDom)))
   and ty.domain = d.name
   and x.dc=td.id
   and td.d1<=1+(@@datefirst+datepart(dw,@pDate)-2)%7
   and td.d2>=1+(@@datefirst+datepart(dw,@pDate)-2)%7
   and x.tc=t.id
   and t.h1<=(((24+datepart(hh, @pDate)+d.timezone-curr.timezone)%24) * 100 + datepart(mm, @pDate)) 
   and t.h2>(((24+datepart(hh, @pDate)+d.timezone-curr.timezone)%24) * 100 + datepart(mm, @pDate))
   ) z
   order by z.priority
   end
';
   SET @SWV_Stmt = v_sql;
   PREPARE SWT_Stmt FROM @SWV_Stmt;
   EXECUTE SWT_Stmt;
   DEALLOCATE PREPARE SWT_Stmt;

   update r_set set curr = 0;
   update r_set set curr = 1 where name = v_pRouteSet;
   COMMIT;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r_get_oprtraffic` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `r_get_oprtraffic`()
begin


   DECLARE v_currtbl VARCHAR(24);
   DECLARE v_sql VARCHAR(2000);
   DECLARE v_nbattempts FLOAT;
   DECLARE v_ASR FLOAT;
   DECLARE v_legAtime FLOAT;
   DECLARE v_legBtime FLOAT;
   DECLARE v_A_B FLOAT;

 
 
   select   tblname INTO v_currtbl from r_curr_oprtraffic;
 
   if exists(select * from r_param_oprtraffic  LIMIT 1) then
 
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select   IFNULL(min_nbattempts,0), IFNULL(max_ASR,-1)/100., IFNULL(min_legAtime,0)*1.0, IFNULL(min_legBtime,0)*1.0, IFNULL(min_AB,0)*1.0 INTO v_nbattempts,v_ASR,v_legAtime,v_legBtime,v_A_B from r_param_oprtraffic;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   else
      set v_nbattempts = 0;
      set v_ASR = -1/100.;
      set v_legAtime = 0.0;
      set v_legBtime = 0.0;
      set v_A_B = 0.0;
   end if;

   update r_curr_oprtraffic set tblname =(case when tblname = 'r_oprtraffic'  then 'r_oprtraffic2'
   when tblname = 'r_oprtraffic2' then 'r_oprtraffic'
   else 'r_oprtraffic' end);
   truncate table r_dec_oprtraffic;
 
   set v_sql =CONCAT( 'insert into r_dec_oprtraffic(`domain`,operator,prefixcode,nbattempts,nbconnected,legAtime,legBtime)
 	   select `domain`,operator,prefixcode,nbattempts,nbconnected,legAtime,legBtime
 	   from ', v_currtbl, ' A 
	   where (A.nbattempts >', v_nbattempts, ') and 
		 ((A.nbconnected*1.00/A.nbattempts*1.00) < ', FORMAT(v_ASR,2), ') and
		 (A.legAtime/60. >', FORMAT(v_legAtime,4), ') and (A.legBtime/60. > ', FORMAT(v_legBtime,4), ') and 
		 ((A.legAtime -A.legBtime)/60. > ', FORMAT(v_A_B,4),  ')');
   SET @SWV_Stmt = v_sql;
   PREPARE SWT_Stmt FROM @SWV_Stmt;
   EXECUTE SWT_Stmt;
   DEALLOCATE PREPARE SWT_Stmt;
 
   set v_sql =CONCAT( 'truncate table ',  v_currtbl);
 
   SET @SWV_Stmt = v_sql;
   PREPARE SWT_Stmt FROM @SWV_Stmt;
   EXECUTE SWT_Stmt;
   DEALLOCATE PREPARE SWT_Stmt;
 
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r_interxgate_get_bridges` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `r_interxgate_get_bridges`(v_domainfr VARCHAR(4),  
v_domainto VARCHAR(4))
begin

  
   select * from inter_xgate_bridge
   where (domain_from = v_domainfr or domain_from = '*')
   and (domain_to = v_domainto or domain_to = '*')
   and bridge_idx >= 0
   order by domain_from desc,domain_to desc,bridge_idx LIMIT 1;    
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r_interxgate_get_media` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `r_interxgate_get_media`(v_mode INT,  
v_content VARCHAR(16))
begin

  
   
   if v_mode = 1 then  
  
      select * from inter_xgate_media where ip_address = v_content;
   else
      if v_mode = 2 then  
   
         select * from inter_xgate_media where switchcode = v_content;
      else  
   
         select * from inter_xgate_media where machine_id = v_content;
      end if;
   end if;  
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `r_interxgate_get_media_v2` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `r_interxgate_get_media_v2`(v_fr_switchcode VARCHAR(16),
v_to_address VARCHAR(16),
v_signalling_type VARCHAR(10))
begin



	
   DECLARE v_fr_ip INT; 
   DECLARE v_fr_atm INT; 
   DECLARE v_to_ip INT; 
   DECLARE v_to_atm INT;

   DECLARE v_fr_ip_interface VARCHAR(10);
   DECLARE v_fr_atm_interface VARCHAR(10);
   DECLARE v_interface VARCHAR(10);
	
   DECLARE v_fr_found INT; 
   DECLARE v_to_found INT;
		
   set v_fr_ip = 0;
   set	v_fr_atm = 0;
   set	v_to_ip = 0;
   set	v_to_atm = 0;
   set v_interface = '';
   set v_fr_ip_interface = '';
   set	v_fr_atm_interface = '';
	
   set v_fr_found = 0;
   set v_to_found = 0;
	
	
   select   1, IFNULL(ip,0), IFNULL(atm,0), IFNULL(ip_interface,''), IFNULL(atm_interface,'') INTO v_fr_found,v_fr_ip,v_fr_atm,v_fr_ip_interface,v_fr_atm_interface from inter_xgate_media where (switchcode = v_fr_switchcode or switchcode = '*')
   and (signalling_type = v_signalling_type or signalling_type = '')   order by switchcode desc,signalling_type desc LIMIT 1;
	
	
   select   1, IFNULL(ip,0), IFNULL(atm,0) INTO v_to_found,v_to_ip,v_to_atm from inter_xgate_media where (ip_address = v_to_address or ip_address = '*')
   and (signalling_type = v_signalling_type or signalling_type = '')   order by ip_address desc,signalling_type desc LIMIT 1;

   if v_fr_ip = 1 and v_to_ip = 1 then
      set v_interface = v_fr_ip_interface;
   else
      if v_fr_atm = 1 and v_to_atm = 1 then
         set v_interface = v_fr_atm_interface;
      end if;
   end if;		

   select v_fr_found as fr_found, v_fr_ip as fr_ip,v_fr_atm as fr_atm, v_to_found as to_found,v_to_ip as to_ip, v_to_atm as to_atm, v_interface as interface;
			
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sl_checkddiblocked` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sl_checkddiblocked`(v_ddi VARCHAR(20))
begin
 
 
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    select * from blocked_ddi  where ddi = ltrim(rtrim(v_ddi)) LIMIT 1;
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_executor` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_executor`(v_string VARCHAR(8000))
begin


   SET @SWV_Stmt = v_string;
   PREPARE SWT_Stmt FROM @SWV_Stmt;
   EXECUTE SWT_Stmt;
   DEALLOCATE PREPARE SWT_Stmt;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSdel_blocked_ddi` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSdel_blocked_ddi`(v_pkc1 VARCHAR(20))
BEGIN

   delete FROM blocked_ddi
   where ddi = v_pkc1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSdel_causecode` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSdel_causecode`(v_pkc1 INT)
BEGIN

   delete FROM causecode
   where code = v_pkc1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSdel_inter_xgate_bridge` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSdel_inter_xgate_bridge`(v_pkc1 VARCHAR(4),v_pkc2 VARCHAR(4),v_pkc3 INT)
BEGIN

   delete FROM inter_xgate_bridge
   where domain_from = v_pkc1 and domain_to = v_pkc2 and bridge_idx = v_pkc3;
   if ROW_COUNT() = 0 then
      if v_microsoftversion > 0x07320000 then
         CALL sp_MSreplraiserror(20598);
      end if;
   end if;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSdel_inter_xgate_media` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSdel_inter_xgate_media`(v_pkc1 VARCHAR(16))
BEGIN

   delete FROM inter_xgate_media
   where ip_address = v_pkc1;
   if ROW_COUNT() = 0 then
      if v_microsoftversion > 0x07320000 then
         CALL sp_MSreplraiserror(20598);
      end if;
   end if;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSdel_R20_route01` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSdel_R20_route01`(v_pkc1 INT)
BEGIN

   delete FROM R20_route01
   where id = v_pkc1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSdel_R20_route02` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSdel_R20_route02`(v_pkc1 INT)
BEGIN

   delete FROM R20_route02
   where id = v_pkc1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSdel_R20_route03` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSdel_R20_route03`(v_pkc1 INT)
BEGIN

   delete FROM R20_route03
   where id = v_pkc1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSdel_r20_route04` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSdel_r20_route04`(v_pkc1 INT)
BEGIN

   delete FROM r20_route04
   where id = v_pkc1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSdel_r20_route05` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSdel_r20_route05`(v_pkc1 INT)
BEGIN

   delete FROM r20_route05
   where id = v_pkc1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSdel_r20_route06` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSdel_r20_route06`(v_pkc1 INT)
BEGIN

   delete FROM r20_route06
   where id = v_pkc1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSdel_r20_route07` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSdel_r20_route07`(v_pkc1 INT)
BEGIN

   delete FROM r20_route07
   where id = v_pkc1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSdel_r20_route08` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSdel_r20_route08`(v_pkc1 INT)
BEGIN

   delete FROM r20_route08
   where id = v_pkc1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSdel_R20_route10` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSdel_R20_route10`(v_pkc1 INT)
BEGIN

   delete FROM R20_route10
   where id = v_pkc1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSdel_r20_route11` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSdel_r20_route11`(v_pkc1 INT)
BEGIN

   delete FROM r20_route11
   where id = v_pkc1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSdel_R20_route12` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSdel_R20_route12`(v_pkc1 INT)
BEGIN

   delete FROM R20_route12
   where id = v_pkc1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSdel_r20_route_timecls` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSdel_r20_route_timecls`(v_pkc1 INT)
BEGIN

   delete FROM r20_route_timecls
   where id = v_pkc1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSdel_r_daycode` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSdel_r_daycode`(v_pkc1 INT)
BEGIN

   delete FROM r_daycode
   where id = v_pkc1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSdel_r_domain` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSdel_r_domain`(v_pkc1 VARCHAR(8),v_pkc2 VARCHAR(8))
BEGIN

   delete FROM r_domain
   where universe = v_pkc1 and name = v_pkc2;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSdel_r_interface` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSdel_r_interface`(v_pkc1 INT)
BEGIN

   delete FROM r_interface
   where id = v_pkc1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSdel_r_interfaceGroup` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSdel_r_interfaceGroup`(v_pkc1 INT,v_pkc2 INT)
BEGIN

   delete FROM r_interfaceGroup
   where tintid = v_pkc1 and IntGroupID = v_pkc2;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSdel_r_operatorset` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSdel_r_operatorset`(v_pkc1 INT,v_pkc2 INT)
BEGIN

   delete FROM r_operatorset
   where operatorset_id = v_pkc1 and oprid = v_pkc2;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSdel_r_Oprprefix_ref` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSdel_r_Oprprefix_ref`(v_pkc1 VARCHAR(30),v_pkc2 VARCHAR(10),v_pkc3 VARCHAR(40))
BEGIN

   delete FROM r_Oprprefix_ref
   where operator = v_pkc1 and `domain` = v_pkc2 and prefixcode = v_pkc3;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSdel_r_prefix2` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSdel_r_prefix2`(v_pkc1 VARCHAR(17))
BEGIN

   delete FROM r_prefix2
   where prefixcode = v_pkc1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSdel_r_prefix_ref` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSdel_r_prefix_ref`(v_pkc1 VARCHAR(17))
BEGIN

   delete FROM r_prefix_ref
   where prefixcode = v_pkc1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSdel_r_timecls` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSdel_r_timecls`(v_pkc1 INT)
BEGIN

   delete FROM r_timecls
   where id = v_pkc1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSdel_r_timecode` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSdel_r_timecode`(v_pkc1 INT)
BEGIN

   delete FROM r_timecode
   where id = v_pkc1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSdel_XlatInterDomain` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSdel_XlatInterDomain`(v_pkc1 VARCHAR(4),v_pkc2 VARCHAR(4),v_pkc3 VARCHAR(4),v_pkc4 VARCHAR(15),v_pkc5 VARCHAR(20))
BEGIN

   delete FROM XlatInterDomain
   where sitecode_in = v_pkc1 and switchcode_in = v_pkc2 and sitecode_out = v_pkc3 and operator_out = v_pkc4 and prefix = v_pkc5;
   if ROW_COUNT() = 0 then
      if v_microsoftversion > 0x07320000 then
         CALL sp_MSreplraiserror(20598);
      end if;
   end if;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSins_blocked_ddi` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSins_blocked_ddi`(v_c1 VARCHAR(20),v_c2 VARCHAR(32),v_c3 VARCHAR(32),v_c4 VARCHAR(10))
BEGIN

   insert into blocked_ddi  values(v_c1,v_c2,v_c3,v_c4);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSins_causecode` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSins_causecode`(v_c1 VARCHAR(8),v_c2 VARCHAR(32),v_c3 INT,v_c4 VARCHAR(32),v_c5 INT,v_c6 INT,v_c7 INT,v_c8 VARCHAR(64))
BEGIN

   insert into causecode  values(v_c1,v_c2,v_c3,v_c4,v_c5,v_c6,v_c7,v_c8);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSins_inter_xgate_bridge` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSins_inter_xgate_bridge`(v_c1 VARCHAR(4),v_c2 VARCHAR(4),v_c3 INT,v_c4 VARCHAR(8),v_c5 VARCHAR(4),v_c6 VARCHAR(30),v_c7 VARCHAR(64))
BEGIN




   insert into inter_xgate_bridge(domain_from, domain_to, bridge_idx, bridge_group, bridge_domain, bridge_hint, comment)
values(v_c1, v_c2, v_c3, v_c4, v_c5, v_c6, v_c7);


END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSins_inter_xgate_media` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSins_inter_xgate_media`(v_c1 VARCHAR(16),v_c2 VARCHAR(3),v_c3 VARCHAR(3),v_c4 VARCHAR(3),v_c5 TINYINT UNSIGNED,v_c6 TINYINT UNSIGNED,v_c7 VARCHAR(16),v_c8 VARCHAR(16))
BEGIN




   insert into inter_xgate_media(ip_address, switchcode, machine_id, sitecode, ip, atm, ip_interface, atm_interface)
values(v_c1, v_c2, v_c3, v_c4, v_c5, v_c6, v_c7, v_c8);


END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSins_R20_route01` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSins_R20_route01`(v_c1 INT,v_c2 INT,v_c3 INT,v_c4 INT,v_c5 INT,v_c6 INT,v_c7 VARCHAR(2),v_c8 VARCHAR(16),v_c9 INT,v_c10 VARCHAR(32),v_c11 VARCHAR(2),v_c12 VARCHAR(2),v_c13 VARCHAR(4),v_c14 FLOAT,v_c15 FLOAT,v_c16 FLOAT,v_c17 INT,v_c18 FLOAT,v_c19 INT,v_c20 INT,v_c21 INT,v_c22 INT,v_c23 INT)
BEGIN

   insert into R20_route01  values(v_c1,v_c2,v_c3,v_c4,v_c5,v_c6,v_c7,v_c8,v_c9,v_c10,v_c11,v_c12,v_c13,v_c14,v_c15,v_c16,v_c17,v_c18,v_c19,v_c20,v_c21,v_c22,v_c23);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSins_R20_route02` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSins_R20_route02`(v_c1 INT,v_c2 INT,v_c3 INT,v_c4 INT,v_c5 INT,v_c6 INT,v_c7 VARCHAR(2),v_c8 VARCHAR(16),v_c9 INT,v_c10 VARCHAR(32),v_c11 VARCHAR(2),v_c12 VARCHAR(2),v_c13 VARCHAR(4),v_c14 FLOAT,v_c15 FLOAT,v_c16 FLOAT,v_c17 INT,v_c18 FLOAT,v_c19 INT,v_c20 INT,v_c21 INT,v_c22 INT,v_c23 INT)
BEGIN

   insert into R20_route02  values(v_c1,v_c2,v_c3,v_c4,v_c5,v_c6,v_c7,v_c8,v_c9,v_c10,v_c11,v_c12,v_c13,v_c14,v_c15,v_c16,v_c17,v_c18,v_c19,v_c20,v_c21,v_c22,v_c23);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSins_R20_route03` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSins_R20_route03`(v_c1 INT,v_c2 INT,v_c3 INT,v_c4 INT,v_c5 INT,v_c6 INT,v_c7 VARCHAR(2),v_c8 VARCHAR(16),v_c9 INT,v_c10 VARCHAR(32),v_c11 VARCHAR(2),v_c12 VARCHAR(2),v_c13 VARCHAR(4),v_c14 FLOAT,v_c15 FLOAT,v_c16 FLOAT,v_c17 INT,v_c18 FLOAT,v_c19 INT,v_c20 INT,v_c21 INT,v_c22 INT,v_c23 INT)
BEGIN

   insert into R20_route03  values(v_c1,v_c2,v_c3,v_c4,v_c5,v_c6,v_c7,v_c8,v_c9,v_c10,v_c11,v_c12,v_c13,v_c14,v_c15,v_c16,v_c17,v_c18,v_c19,v_c20,v_c21,v_c22,v_c23);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSins_r20_route04` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSins_r20_route04`(v_c1 INT,v_c2 INT,v_c3 INT,v_c4 INT,v_c5 INT,v_c6 INT,v_c7 VARCHAR(2),v_c8 VARCHAR(16),v_c9 INT,v_c10 VARCHAR(32),v_c11 VARCHAR(2),v_c12 VARCHAR(2),v_c13 VARCHAR(4),v_c14 FLOAT,v_c15 FLOAT,v_c16 FLOAT,v_c17 INT,v_c18 FLOAT,v_c19 INT,v_c20 INT,v_c21 INT,v_c22 INT,v_c23 INT)
BEGIN

   insert into r20_route04  values(v_c1,v_c2,v_c3,v_c4,v_c5,v_c6,v_c7,v_c8,v_c9,v_c10,v_c11,v_c12,v_c13,v_c14,v_c15,v_c16,v_c17,v_c18,v_c19,v_c20,v_c21,v_c22,v_c23);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSins_r20_route05` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSins_r20_route05`(v_c1 INT,v_c2 INT,v_c3 INT,v_c4 INT,v_c5 INT,v_c6 INT,v_c7 VARCHAR(2),v_c8 VARCHAR(16),v_c9 INT,v_c10 VARCHAR(32),v_c11 VARCHAR(2),v_c12 VARCHAR(2),v_c13 VARCHAR(4),v_c14 FLOAT,v_c15 FLOAT,v_c16 FLOAT,v_c17 INT,v_c18 FLOAT,v_c19 INT,v_c20 INT,v_c21 INT,v_c22 INT,v_c23 INT)
BEGIN

   insert into r20_route05  values(v_c1,v_c2,v_c3,v_c4,v_c5,v_c6,v_c7,v_c8,v_c9,v_c10,v_c11,v_c12,v_c13,v_c14,v_c15,v_c16,v_c17,v_c18,v_c19,v_c20,v_c21,v_c22,v_c23);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSins_r20_route06` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSins_r20_route06`(v_c1 INT,v_c2 INT,v_c3 INT,v_c4 INT,v_c5 INT,v_c6 INT,v_c7 VARCHAR(2),v_c8 VARCHAR(16),v_c9 INT,v_c10 VARCHAR(32),v_c11 VARCHAR(2),v_c12 VARCHAR(2),v_c13 VARCHAR(4),v_c14 FLOAT,v_c15 FLOAT,v_c16 FLOAT,v_c17 INT,v_c18 FLOAT,v_c19 INT,v_c20 INT,v_c21 INT,v_c22 INT,v_c23 INT)
BEGIN

   insert into r20_route06  values(v_c1,v_c2,v_c3,v_c4,v_c5,v_c6,v_c7,v_c8,v_c9,v_c10,v_c11,v_c12,v_c13,v_c14,v_c15,v_c16,v_c17,v_c18,v_c19,v_c20,v_c21,v_c22,v_c23);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSins_r20_route07` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSins_r20_route07`(v_c1 INT,v_c2 INT,v_c3 INT,v_c4 INT,v_c5 INT,v_c6 INT,v_c7 VARCHAR(2),v_c8 VARCHAR(16),v_c9 INT,v_c10 VARCHAR(32),v_c11 VARCHAR(2),v_c12 VARCHAR(2),v_c13 VARCHAR(4),v_c14 FLOAT,v_c15 FLOAT,v_c16 FLOAT,v_c17 INT,v_c18 FLOAT,v_c19 INT,v_c20 INT,v_c21 INT,v_c22 INT,v_c23 INT)
BEGIN

   insert into r20_route07  values(v_c1,v_c2,v_c3,v_c4,v_c5,v_c6,v_c7,v_c8,v_c9,v_c10,v_c11,v_c12,v_c13,v_c14,v_c15,v_c16,v_c17,v_c18,v_c19,v_c20,v_c21,v_c22,v_c23);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSins_r20_route08` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSins_r20_route08`(v_c1 INT,v_c2 INT,v_c3 INT,v_c4 INT,v_c5 INT,v_c6 INT,v_c7 VARCHAR(2),v_c8 VARCHAR(16),v_c9 INT,v_c10 VARCHAR(32),v_c11 VARCHAR(2),v_c12 VARCHAR(2),v_c13 VARCHAR(4),v_c14 FLOAT,v_c15 FLOAT,v_c16 FLOAT,v_c17 INT,v_c18 FLOAT,v_c19 INT,v_c20 INT,v_c21 INT,v_c22 INT,v_c23 INT)
BEGIN

   insert into r20_route08  values(v_c1,v_c2,v_c3,v_c4,v_c5,v_c6,v_c7,v_c8,v_c9,v_c10,v_c11,v_c12,v_c13,v_c14,v_c15,v_c16,v_c17,v_c18,v_c19,v_c20,v_c21,v_c22,v_c23);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSins_R20_route10` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSins_R20_route10`(v_c1 INT,v_c2 INT,v_c3 INT,v_c4 INT,v_c5 INT,v_c6 INT,v_c7 VARCHAR(2),v_c8 VARCHAR(16),v_c9 INT,v_c10 VARCHAR(32),v_c11 VARCHAR(2),v_c12 VARCHAR(2),v_c13 VARCHAR(4),v_c14 FLOAT,v_c15 FLOAT,v_c16 FLOAT,v_c17 INT,v_c18 FLOAT,v_c19 INT,v_c20 INT,v_c21 INT,v_c22 INT,v_c23 INT)
BEGIN

   insert into R20_route10  values(v_c1,v_c2,v_c3,v_c4,v_c5,v_c6,v_c7,v_c8,v_c9,v_c10,v_c11,v_c12,v_c13,v_c14,v_c15,v_c16,v_c17,v_c18,v_c19,v_c20,v_c21,v_c22,v_c23);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSins_r20_route11` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSins_r20_route11`(v_c1 INT,v_c2 INT,v_c3 INT,v_c4 INT,v_c5 INT,v_c6 INT,v_c7 VARCHAR(2),v_c8 VARCHAR(16),v_c9 INT,v_c10 VARCHAR(32),v_c11 VARCHAR(2),v_c12 VARCHAR(2),v_c13 VARCHAR(4),v_c14 FLOAT,v_c15 FLOAT,v_c16 FLOAT,v_c17 INT,v_c18 FLOAT,v_c19 INT,v_c20 INT,v_c21 INT,v_c22 INT,v_c23 INT)
BEGIN

   insert into r20_route11  values(v_c1,v_c2,v_c3,v_c4,v_c5,v_c6,v_c7,v_c8,v_c9,v_c10,v_c11,v_c12,v_c13,v_c14,v_c15,v_c16,v_c17,v_c18,v_c19,v_c20,v_c21,v_c22,v_c23);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSins_R20_route12` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSins_R20_route12`(v_c1 INT,v_c2 INT,v_c3 INT,v_c4 INT,v_c5 INT,v_c6 INT,v_c7 VARCHAR(2),v_c8 VARCHAR(16),v_c9 INT,v_c10 VARCHAR(32),v_c11 VARCHAR(2),v_c12 VARCHAR(2),v_c13 VARCHAR(4),v_c14 FLOAT,v_c15 FLOAT,v_c16 FLOAT,v_c17 INT,v_c18 FLOAT,v_c19 INT,v_c20 INT,v_c21 INT,v_c22 INT,v_c23 INT)
BEGIN

   insert into R20_route12  values(v_c1,v_c2,v_c3,v_c4,v_c5,v_c6,v_c7,v_c8,v_c9,v_c10,v_c11,v_c12,v_c13,v_c14,v_c15,v_c16,v_c17,v_c18,v_c19,v_c20,v_c21,v_c22,v_c23);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSins_r20_route_timecls` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSins_r20_route_timecls`(v_c1 INT,v_c2 INT,v_c3 INT,v_c4 VARCHAR(1),v_c5 VARCHAR(2))
BEGIN

   insert into r20_route_timecls  values(v_c1,v_c2,v_c3,v_c4,v_c5);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSins_r_daycode` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSins_r_daycode`(v_c1 INT,v_c2 INT,v_c3 INT)
BEGIN

   insert into r_daycode  values(v_c1,v_c2,v_c3);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSins_r_domain` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSins_r_domain`(v_c1 CHAR(1),v_c2 VARCHAR(8),v_c3 VARCHAR(8),v_c4 VARCHAR(32),v_c5 VARCHAR(128),v_c6 INT,v_c7 VARCHAR(64))
BEGIN

   insert into r_domain  values(v_c1,v_c2,v_c3,v_c4,v_c5,v_c6,v_c7);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSins_r_interface` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSins_r_interface`(v_c1 INT,v_c2 CHAR(1),v_c3 VARCHAR(8),v_c4 VARCHAR(8),v_c5 VARCHAR(8),v_c6 VARCHAR(32),v_c7 VARCHAR(16),v_c8 VARCHAR(128),v_c9 INT,v_c10 INT,v_c11 INT,v_c12 VARCHAR(64),v_c13 VARCHAR(64),v_c14 INT,v_c15 INT)
BEGIN

   insert into r_interface  values(v_c1,v_c2,v_c3,v_c4,v_c5,v_c6,v_c7,v_c8,v_c9,v_c10,v_c11,v_c12,v_c13,v_c14,v_c15);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSins_r_interfaceGroup` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSins_r_interfaceGroup`(v_c1 INT,v_c2 INT,v_c3 INT)
BEGIN

   insert into r_interfaceGroup  values(v_c1,v_c2,v_c3);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSins_r_operatorset` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSins_r_operatorset`(v_c1 INT,v_c2 INT,v_c3 TINYINT UNSIGNED,v_c4 TINYINT UNSIGNED,v_c5 FLOAT,v_c6 FLOAT,v_c7 INT,v_c8 INT,v_c9 VARCHAR(128))
BEGIN

   insert into r_operatorset  values(v_c1,v_c2,v_c3,v_c4,v_c5,v_c6,v_c7,v_c8,v_c9);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSins_r_Oprprefix_ref` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSins_r_Oprprefix_ref`(v_c1 VARCHAR(30),v_c2 VARCHAR(10),v_c3 VARCHAR(40),v_c4 VARCHAR(40),v_c5 DATETIME(3),v_c6 INT)
BEGIN

   insert into r_Oprprefix_ref  values(v_c1,v_c2,v_c3,v_c4,v_c5,v_c6);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSins_r_prefix2` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSins_r_prefix2`(v_c1 VARCHAR(1),v_c2 VARCHAR(2),v_c3 VARCHAR(17),v_c4 INT,v_c5 VARCHAR(32),v_c6 VARCHAR(8),v_c7 INT,v_c8 VARCHAR(64),v_c9 INT,v_c10 INT,v_c11 INT,v_c12 FLOAT,v_c13 INT,v_c14 FLOAT,v_c15 INT,v_c16 FLOAT,v_c17 INT,v_c18 FLOAT,v_c19 VARCHAR(32))
BEGIN

   insert into r_prefix2  values(v_c1,v_c2,v_c3,v_c4,v_c5,v_c6,v_c7,v_c8,v_c9,v_c10,v_c11,v_c12,v_c13,v_c14,v_c15,v_c16,v_c17,v_c18,v_c19);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSins_r_prefix_ref` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSins_r_prefix_ref`(v_c1 VARCHAR(17),v_c2 VARCHAR(32),v_c3 VARCHAR(32),v_c4 VARCHAR(100),v_c5 INT,v_c6 VARCHAR(100),v_c7 INT)
BEGIN

   insert into r_prefix_ref  values(v_c1,v_c2,v_c3,v_c4,v_c5,v_c6,v_c7);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSins_r_timecls` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSins_r_timecls`(v_c1 INT,v_c2 VARCHAR(1),v_c3 INT,v_c4 VARCHAR(1),v_c5 INT,v_c6 INT,v_c7 INT)
BEGIN

   insert into r_timecls  values(v_c1,v_c2,v_c3,v_c4,v_c5,v_c6,v_c7);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSins_r_timecode` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSins_r_timecode`(v_c1 INT,v_c2 INT,v_c3 INT)
BEGIN

   insert into r_timecode  values(v_c1,v_c2,v_c3);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSins_XlatInterDomain` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSins_XlatInterDomain`(v_c1 VARCHAR(4),v_c2 VARCHAR(4),v_c3 VARCHAR(4),v_c4 VARCHAR(15),v_c5 VARCHAR(20),v_c6 VARCHAR(20),v_c7 INT,v_c8 VARCHAR(64))
BEGIN




   insert into XlatInterDomain(sitecode_in, switchcode_in, sitecode_out, operator_out, prefix, xlatpfx, prefixlen, comment)
values(v_c1, v_c2, v_c3, v_c4, v_c5, v_c6, v_c7, v_c8);


END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSupd_blocked_ddi` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSupd_blocked_ddi`(v_c1 VARCHAR(20),v_c2 VARCHAR(32),v_c3 VARCHAR(32),v_c4 VARCHAR(10),v_pkc1 VARCHAR(20)
,v_bitmap BINARY(1))
BEGIN

   if SUBSTR(v_bitmap,1,1) & 1 = 1 then
      update blocked_ddi set
      ddi = case SUBSTR(v_bitmap,1,1) & 1 when 1 then v_c1 else ddi end,blocker = case SUBSTR(v_bitmap,1,1) & 2 when 2 then v_c2 else blocker end,
      reason = case SUBSTR(v_bitmap,1,1) & 4 when 4 then v_c3 else reason end,`date` = case SUBSTR(v_bitmap,1,1) & 8 when 8 then v_c4 else `date` end
      where ddi = v_pkc1;
   else
      update blocked_ddi set
      blocker = case SUBSTR(v_bitmap,1,1) & 2 when 2 then v_c2 else blocker end,reason = case SUBSTR(v_bitmap,1,1) & 4 when 4 then v_c3 else reason end,`date` = case SUBSTR(v_bitmap,1,1) & 8 when 8 then v_c4 else `date` end
      where ddi = v_pkc1;
   end if;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSupd_causecode` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSupd_causecode`(v_c1 VARCHAR(8),v_c2 VARCHAR(32),v_c3 INT,v_c4 VARCHAR(32),v_c5 INT,v_c6 INT,v_c7 INT,v_c8 VARCHAR(64),v_pkc1 INT
,v_bitmap BINARY(2))
BEGIN

   if SUBSTR(v_bitmap,1,1) & 4 = 4 then
      update causecode set
      `domain` = case SUBSTR(v_bitmap,1,1) & 1 when 1 then v_c1 else `domain` end,operator = case SUBSTR(v_bitmap,1,1) & 2 when 2 then v_c2 else operator end,code = case SUBSTR(v_bitmap,1,1) & 4 when 4 then v_c3 else code end,
      name = case SUBSTR(v_bitmap,1,1) & 8 when 8 then v_c4 else name end,
      `next` = case SUBSTR(v_bitmap,1,1) & 16 when 16 then v_c5 else `next` end,counter = case SUBSTR(v_bitmap,1,1) & 32 when 32 then v_c6 else counter end,duration = case SUBSTR(v_bitmap,1,1) & 64 when 64 then v_c7 else duration end,reserved = case SUBSTR(v_bitmap,1,1) & 128 when 128 then v_c8 else reserved end
      where code = v_pkc1;
   else
      update causecode set
      `domain` = case SUBSTR(v_bitmap,1,1) & 1 when 1 then v_c1 else `domain` end,operator = case SUBSTR(v_bitmap,1,1) & 2 when 2 then v_c2 else operator end,name = case SUBSTR(v_bitmap,1,1) & 8 when 8 then v_c4 else name end,
      `next` = case SUBSTR(v_bitmap,1,1) & 16 when 16 then v_c5 else `next` end,counter = case SUBSTR(v_bitmap,1,1) & 32 when 32 then v_c6 else counter end,duration = case SUBSTR(v_bitmap,1,1) & 64 when 64 then v_c7 else duration end,reserved = case SUBSTR(v_bitmap,1,1) & 128 when 128 then v_c8 else reserved end
      where code = v_pkc1;
   end if;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSupd_inter_xgate_bridge` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSupd_inter_xgate_bridge`(v_c1 VARCHAR(4),v_c2 VARCHAR(4),v_c3 INT,v_c4 VARCHAR(8),v_c5 VARCHAR(4),v_c6 VARCHAR(30),v_c7 VARCHAR(64),v_pkc1 VARCHAR(4),v_pkc2 VARCHAR(4),v_pkc3 INT
,v_bitmap BINARY(1))
BEGIN

   if SUBSTR(v_bitmap,1,1) & 1 = 1 or SUBSTR(v_bitmap,1,1) & 2 = 2 or SUBSTR(v_bitmap,1,1) & 4 = 4 then

      update inter_xgate_bridge set
      domain_from = case SUBSTR(v_bitmap,1,1) & 1 when 1 then v_c1 else domain_from end,domain_to = case SUBSTR(v_bitmap,1,1) & 2 when 2 then v_c2 else domain_to end,bridge_idx = case SUBSTR(v_bitmap,1,1) & 4 when 4 then v_c3 else bridge_idx end,bridge_group = case SUBSTR(v_bitmap,1,1) & 8 when 8 then v_c4 else bridge_group end,bridge_domain = case SUBSTR(v_bitmap,1,1) & 16 when 16 then v_c5 else bridge_domain end,bridge_hint = case SUBSTR(v_bitmap,1,1) & 32 when 32 then v_c6 else bridge_hint end,
      comment = case SUBSTR(v_bitmap,1,1) & 64 when 64 then v_c7 else comment end
      where domain_from = v_pkc1 and domain_to = v_pkc2 and bridge_idx = v_pkc3;
      if ROW_COUNT() = 0 then
         if v_microsoftversion > 0x07320000 then
            CALL sp_MSreplraiserror(20598);
         end if;
      end if;
   else
      update inter_xgate_bridge set
      bridge_group = case SUBSTR(v_bitmap,1,1) & 8 when 8 then v_c4 else bridge_group end,bridge_domain = case SUBSTR(v_bitmap,1,1) & 16 when 16 then v_c5 else bridge_domain end,bridge_hint = case SUBSTR(v_bitmap,1,1) & 32 when 32 then v_c6 else bridge_hint end,comment = case SUBSTR(v_bitmap,1,1) & 64 when 64 then v_c7 else comment end
      where domain_from = v_pkc1 and domain_to = v_pkc2 and bridge_idx = v_pkc3;
      if ROW_COUNT() = 0 then
         if v_microsoftversion > 0x07320000 then
            CALL sp_MSreplraiserror(20598);
         end if;
      end if;
   end if;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSupd_inter_xgate_media` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSupd_inter_xgate_media`(v_c1 VARCHAR(16),v_c2 VARCHAR(3),v_c3 VARCHAR(3),v_c4 VARCHAR(3),v_c5 TINYINT UNSIGNED,v_c6 TINYINT UNSIGNED,v_c7 VARCHAR(16),v_c8 VARCHAR(16),v_pkc1 VARCHAR(16)
,v_bitmap BINARY(2))
BEGIN

   if SUBSTR(v_bitmap,1,1) & 1 = 1 then

      update inter_xgate_media set
      ip_address = case SUBSTR(v_bitmap,1,1) & 1 when 1 then v_c1 else ip_address end,switchcode = case SUBSTR(v_bitmap,1,1) & 2 when 2 then v_c2 else switchcode end,machine_id = case SUBSTR(v_bitmap,1,1) & 4 when 4 then v_c3 else machine_id end,sitecode = case SUBSTR(v_bitmap,1,1) & 8 when 8 then v_c4 else sitecode end,ip = case SUBSTR(v_bitmap,1,1) & 16 when 16 then v_c5 else ip end,
      atm = case SUBSTR(v_bitmap,1,1) & 32 when 32 then v_c6 else atm end,
      ip_interface = case SUBSTR(v_bitmap,1,1) & 64 when 64 then v_c7 else ip_interface end,atm_interface = case SUBSTR(v_bitmap,1,1) & 128 when 128 then v_c8 else atm_interface end
      where ip_address = v_pkc1;
      if ROW_COUNT() = 0 then
         if v_microsoftversion > 0x07320000 then
            CALL sp_MSreplraiserror(20598);
         end if;
      end if;
   else
      update inter_xgate_media set
      switchcode = case SUBSTR(v_bitmap,1,1) & 2 when 2 then v_c2 else switchcode end,machine_id = case SUBSTR(v_bitmap,1,1) & 4 when 4 then v_c3 else machine_id end,sitecode = case SUBSTR(v_bitmap,1,1) & 8 when 8 then v_c4 else sitecode end,ip = case SUBSTR(v_bitmap,1,1) & 16 when 16 then v_c5 else ip end,
      atm = case SUBSTR(v_bitmap,1,1) & 32 when 32 then v_c6 else atm end,
      ip_interface = case SUBSTR(v_bitmap,1,1) & 64 when 64 then v_c7 else ip_interface end,atm_interface = case SUBSTR(v_bitmap,1,1) & 128 when 128 then v_c8 else atm_interface end
      where ip_address = v_pkc1;
      if ROW_COUNT() = 0 then
         if v_microsoftversion > 0x07320000 then
            CALL sp_MSreplraiserror(20598);
         end if;
      end if;
   end if;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSupd_R20_route01` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSupd_R20_route01`(v_c1 INT,v_c2 INT,v_c3 INT,v_c4 INT,v_c5 INT,v_c6 INT,v_c7 VARCHAR(2),v_c8 VARCHAR(16),v_c9 INT,v_c10 VARCHAR(32),v_c11 VARCHAR(2),v_c12 VARCHAR(2),v_c13 VARCHAR(4),v_c14 FLOAT,v_c15 FLOAT,v_c16 FLOAT,v_c17 INT,v_c18 FLOAT,v_c19 INT,v_c20 INT,v_c21 INT,v_c22 INT,v_c23 INT,v_pkc1 INT
,v_bitmap BINARY(3))
BEGIN

   if SUBSTR(v_bitmap,1,1) & 1 = 1 then
      update R20_route01 set
      id = case SUBSTR(v_bitmap,1,1) & 1 when 1 then v_c1 else id end,parentId = case SUBSTR(v_bitmap,1,1) & 2 when 2 then v_c2 else parentId end,
      state = case SUBSTR(v_bitmap,1,1) & 4 when 4 then v_c3 else state end,reason = case SUBSTR(v_bitmap,1,1) & 8 when 8 then v_c4 else reason end,routeCls = case SUBSTR(v_bitmap,1,1) & 16 when 16 then v_c5 else routeCls end,oprId = case SUBSTR(v_bitmap,1,1) & 32 when 32 then v_c6 else oprId end,pc = case SUBSTR(v_bitmap,1,1) & 64 when 64 then v_c7 else pc end,
      prefixCode = case SUBSTR(v_bitmap,1,1) & 128 when 128 then v_c8 else prefixCode end,prefixLen = case SUBSTR(v_bitmap,2,1) & 1 when 1 then v_c9 else prefixLen end,destCode = case SUBSTR(v_bitmap,2,1) & 2 when 2 then v_c10 else destCode end,clsOrg = case SUBSTR(v_bitmap,2,1) & 4 when 4 then v_c11 else clsOrg end,cls = case SUBSTR(v_bitmap,2,1) & 8 when 8 then v_c12 else cls end,
      costOrgCurr = case SUBSTR(v_bitmap,2,1) & 16 when 16 then v_c13 else costOrgCurr end,costOrg = case SUBSTR(v_bitmap,2,1) & 32 when 32 then v_c14 else costOrg end,cost = case SUBSTR(v_bitmap,2,1) & 64 when 64 then v_c15 else cost end,priority = case SUBSTR(v_bitmap,2,1) & 128 when 128 then v_c16 else priority end,
      access = case SUBSTR(v_bitmap,3,1) & 1 when 1 then v_c17 else access end,quality = case SUBSTR(v_bitmap,3,1) & 2 when 2 then v_c18 else quality end,rating = case SUBSTR(v_bitmap,3,1) & 4 when 4 then v_c19 else rating end,flag = case SUBSTR(v_bitmap,3,1) & 8 when 8 then v_c20 else flag end,
      ext = case SUBSTR(v_bitmap,3,1) & 16 when 16 then v_c21 else ext end,
      `exception` = case SUBSTR(v_bitmap,3,1) & 32 when 32 then v_c22 else `exception` end,exceptionCls = case SUBSTR(v_bitmap,3,1) & 64 when 64 then v_c23 else exceptionCls end
      where id = v_pkc1;
   else
      update R20_route01 set
      parentId = case SUBSTR(v_bitmap,1,1) & 2 when 2 then v_c2 else parentId end,state = case SUBSTR(v_bitmap,1,1) & 4 when 4 then v_c3 else state end,reason = case SUBSTR(v_bitmap,1,1) & 8 when 8 then v_c4 else reason end,routeCls = case SUBSTR(v_bitmap,1,1) & 16 when 16 then v_c5 else routeCls end,oprId = case SUBSTR(v_bitmap,1,1) & 32 when 32 then v_c6 else oprId end,pc = case SUBSTR(v_bitmap,1,1) & 64 when 64 then v_c7 else pc end,
      prefixCode = case SUBSTR(v_bitmap,1,1) & 128 when 128 then v_c8 else prefixCode end,prefixLen = case SUBSTR(v_bitmap,2,1) & 1 when 1 then v_c9 else prefixLen end,destCode = case SUBSTR(v_bitmap,2,1) & 2 when 2 then v_c10 else destCode end,clsOrg = case SUBSTR(v_bitmap,2,1) & 4 when 4 then v_c11 else clsOrg end,cls = case SUBSTR(v_bitmap,2,1) & 8 when 8 then v_c12 else cls end,
      costOrgCurr = case SUBSTR(v_bitmap,2,1) & 16 when 16 then v_c13 else costOrgCurr end,costOrg = case SUBSTR(v_bitmap,2,1) & 32 when 32 then v_c14 else costOrg end,cost = case SUBSTR(v_bitmap,2,1) & 64 when 64 then v_c15 else cost end,priority = case SUBSTR(v_bitmap,2,1) & 128 when 128 then v_c16 else priority end,
      access = case SUBSTR(v_bitmap,3,1) & 1 when 1 then v_c17 else access end,quality = case SUBSTR(v_bitmap,3,1) & 2 when 2 then v_c18 else quality end,rating = case SUBSTR(v_bitmap,3,1) & 4 when 4 then v_c19 else rating end,flag = case SUBSTR(v_bitmap,3,1) & 8 when 8 then v_c20 else flag end,
      ext = case SUBSTR(v_bitmap,3,1) & 16 when 16 then v_c21 else ext end,
      `exception` = case SUBSTR(v_bitmap,3,1) & 32 when 32 then v_c22 else `exception` end,exceptionCls = case SUBSTR(v_bitmap,3,1) & 64 when 64 then v_c23 else exceptionCls end
      where id = v_pkc1;
   end if;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSupd_R20_route02` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSupd_R20_route02`(v_c1 INT,v_c2 INT,v_c3 INT,v_c4 INT,v_c5 INT,v_c6 INT,v_c7 VARCHAR(2),v_c8 VARCHAR(16),v_c9 INT,v_c10 VARCHAR(32),v_c11 VARCHAR(2),v_c12 VARCHAR(2),v_c13 VARCHAR(4),v_c14 FLOAT,v_c15 FLOAT,v_c16 FLOAT,v_c17 INT,v_c18 FLOAT,v_c19 INT,v_c20 INT,v_c21 INT,v_c22 INT,v_c23 INT,v_pkc1 INT
,v_bitmap BINARY(3))
BEGIN

   if SUBSTR(v_bitmap,1,1) & 1 = 1 then
      update R20_route02 set
      id = case SUBSTR(v_bitmap,1,1) & 1 when 1 then v_c1 else id end,parentId = case SUBSTR(v_bitmap,1,1) & 2 when 2 then v_c2 else parentId end,
      state = case SUBSTR(v_bitmap,1,1) & 4 when 4 then v_c3 else state end,reason = case SUBSTR(v_bitmap,1,1) & 8 when 8 then v_c4 else reason end,routeCls = case SUBSTR(v_bitmap,1,1) & 16 when 16 then v_c5 else routeCls end,oprId = case SUBSTR(v_bitmap,1,1) & 32 when 32 then v_c6 else oprId end,pc = case SUBSTR(v_bitmap,1,1) & 64 when 64 then v_c7 else pc end,
      prefixCode = case SUBSTR(v_bitmap,1,1) & 128 when 128 then v_c8 else prefixCode end,prefixLen = case SUBSTR(v_bitmap,2,1) & 1 when 1 then v_c9 else prefixLen end,destCode = case SUBSTR(v_bitmap,2,1) & 2 when 2 then v_c10 else destCode end,clsOrg = case SUBSTR(v_bitmap,2,1) & 4 when 4 then v_c11 else clsOrg end,cls = case SUBSTR(v_bitmap,2,1) & 8 when 8 then v_c12 else cls end,
      costOrgCurr = case SUBSTR(v_bitmap,2,1) & 16 when 16 then v_c13 else costOrgCurr end,costOrg = case SUBSTR(v_bitmap,2,1) & 32 when 32 then v_c14 else costOrg end,cost = case SUBSTR(v_bitmap,2,1) & 64 when 64 then v_c15 else cost end,priority = case SUBSTR(v_bitmap,2,1) & 128 when 128 then v_c16 else priority end,
      access = case SUBSTR(v_bitmap,3,1) & 1 when 1 then v_c17 else access end,quality = case SUBSTR(v_bitmap,3,1) & 2 when 2 then v_c18 else quality end,rating = case SUBSTR(v_bitmap,3,1) & 4 when 4 then v_c19 else rating end,flag = case SUBSTR(v_bitmap,3,1) & 8 when 8 then v_c20 else flag end,
      ext = case SUBSTR(v_bitmap,3,1) & 16 when 16 then v_c21 else ext end,
      `exception` = case SUBSTR(v_bitmap,3,1) & 32 when 32 then v_c22 else `exception` end,exceptionCls = case SUBSTR(v_bitmap,3,1) & 64 when 64 then v_c23 else exceptionCls end
      where id = v_pkc1;
   else
      update R20_route02 set
      parentId = case SUBSTR(v_bitmap,1,1) & 2 when 2 then v_c2 else parentId end,state = case SUBSTR(v_bitmap,1,1) & 4 when 4 then v_c3 else state end,reason = case SUBSTR(v_bitmap,1,1) & 8 when 8 then v_c4 else reason end,routeCls = case SUBSTR(v_bitmap,1,1) & 16 when 16 then v_c5 else routeCls end,oprId = case SUBSTR(v_bitmap,1,1) & 32 when 32 then v_c6 else oprId end,pc = case SUBSTR(v_bitmap,1,1) & 64 when 64 then v_c7 else pc end,
      prefixCode = case SUBSTR(v_bitmap,1,1) & 128 when 128 then v_c8 else prefixCode end,prefixLen = case SUBSTR(v_bitmap,2,1) & 1 when 1 then v_c9 else prefixLen end,destCode = case SUBSTR(v_bitmap,2,1) & 2 when 2 then v_c10 else destCode end,clsOrg = case SUBSTR(v_bitmap,2,1) & 4 when 4 then v_c11 else clsOrg end,cls = case SUBSTR(v_bitmap,2,1) & 8 when 8 then v_c12 else cls end,
      costOrgCurr = case SUBSTR(v_bitmap,2,1) & 16 when 16 then v_c13 else costOrgCurr end,costOrg = case SUBSTR(v_bitmap,2,1) & 32 when 32 then v_c14 else costOrg end,cost = case SUBSTR(v_bitmap,2,1) & 64 when 64 then v_c15 else cost end,priority = case SUBSTR(v_bitmap,2,1) & 128 when 128 then v_c16 else priority end,
      access = case SUBSTR(v_bitmap,3,1) & 1 when 1 then v_c17 else access end,quality = case SUBSTR(v_bitmap,3,1) & 2 when 2 then v_c18 else quality end,rating = case SUBSTR(v_bitmap,3,1) & 4 when 4 then v_c19 else rating end,flag = case SUBSTR(v_bitmap,3,1) & 8 when 8 then v_c20 else flag end,
      ext = case SUBSTR(v_bitmap,3,1) & 16 when 16 then v_c21 else ext end,
      `exception` = case SUBSTR(v_bitmap,3,1) & 32 when 32 then v_c22 else `exception` end,exceptionCls = case SUBSTR(v_bitmap,3,1) & 64 when 64 then v_c23 else exceptionCls end
      where id = v_pkc1;
   end if;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSupd_R20_route03` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSupd_R20_route03`(v_c1 INT,v_c2 INT,v_c3 INT,v_c4 INT,v_c5 INT,v_c6 INT,v_c7 VARCHAR(2),v_c8 VARCHAR(16),v_c9 INT,v_c10 VARCHAR(32),v_c11 VARCHAR(2),v_c12 VARCHAR(2),v_c13 VARCHAR(4),v_c14 FLOAT,v_c15 FLOAT,v_c16 FLOAT,v_c17 INT,v_c18 FLOAT,v_c19 INT,v_c20 INT,v_c21 INT,v_c22 INT,v_c23 INT,v_pkc1 INT
,v_bitmap BINARY(3))
BEGIN

   if SUBSTR(v_bitmap,1,1) & 1 = 1 then
      update R20_route03 set
      id = case SUBSTR(v_bitmap,1,1) & 1 when 1 then v_c1 else id end,parentId = case SUBSTR(v_bitmap,1,1) & 2 when 2 then v_c2 else parentId end,
      state = case SUBSTR(v_bitmap,1,1) & 4 when 4 then v_c3 else state end,reason = case SUBSTR(v_bitmap,1,1) & 8 when 8 then v_c4 else reason end,routeCls = case SUBSTR(v_bitmap,1,1) & 16 when 16 then v_c5 else routeCls end,oprId = case SUBSTR(v_bitmap,1,1) & 32 when 32 then v_c6 else oprId end,pc = case SUBSTR(v_bitmap,1,1) & 64 when 64 then v_c7 else pc end,
      prefixCode = case SUBSTR(v_bitmap,1,1) & 128 when 128 then v_c8 else prefixCode end,prefixLen = case SUBSTR(v_bitmap,2,1) & 1 when 1 then v_c9 else prefixLen end,destCode = case SUBSTR(v_bitmap,2,1) & 2 when 2 then v_c10 else destCode end,clsOrg = case SUBSTR(v_bitmap,2,1) & 4 when 4 then v_c11 else clsOrg end,cls = case SUBSTR(v_bitmap,2,1) & 8 when 8 then v_c12 else cls end,
      costOrgCurr = case SUBSTR(v_bitmap,2,1) & 16 when 16 then v_c13 else costOrgCurr end,costOrg = case SUBSTR(v_bitmap,2,1) & 32 when 32 then v_c14 else costOrg end,cost = case SUBSTR(v_bitmap,2,1) & 64 when 64 then v_c15 else cost end,priority = case SUBSTR(v_bitmap,2,1) & 128 when 128 then v_c16 else priority end,
      access = case SUBSTR(v_bitmap,3,1) & 1 when 1 then v_c17 else access end,quality = case SUBSTR(v_bitmap,3,1) & 2 when 2 then v_c18 else quality end,rating = case SUBSTR(v_bitmap,3,1) & 4 when 4 then v_c19 else rating end,flag = case SUBSTR(v_bitmap,3,1) & 8 when 8 then v_c20 else flag end,
      ext = case SUBSTR(v_bitmap,3,1) & 16 when 16 then v_c21 else ext end,
      `exception` = case SUBSTR(v_bitmap,3,1) & 32 when 32 then v_c22 else `exception` end,exceptionCls = case SUBSTR(v_bitmap,3,1) & 64 when 64 then v_c23 else exceptionCls end
      where id = v_pkc1;
   else
      update R20_route03 set
      parentId = case SUBSTR(v_bitmap,1,1) & 2 when 2 then v_c2 else parentId end,state = case SUBSTR(v_bitmap,1,1) & 4 when 4 then v_c3 else state end,reason = case SUBSTR(v_bitmap,1,1) & 8 when 8 then v_c4 else reason end,routeCls = case SUBSTR(v_bitmap,1,1) & 16 when 16 then v_c5 else routeCls end,oprId = case SUBSTR(v_bitmap,1,1) & 32 when 32 then v_c6 else oprId end,pc = case SUBSTR(v_bitmap,1,1) & 64 when 64 then v_c7 else pc end,
      prefixCode = case SUBSTR(v_bitmap,1,1) & 128 when 128 then v_c8 else prefixCode end,prefixLen = case SUBSTR(v_bitmap,2,1) & 1 when 1 then v_c9 else prefixLen end,destCode = case SUBSTR(v_bitmap,2,1) & 2 when 2 then v_c10 else destCode end,clsOrg = case SUBSTR(v_bitmap,2,1) & 4 when 4 then v_c11 else clsOrg end,cls = case SUBSTR(v_bitmap,2,1) & 8 when 8 then v_c12 else cls end,
      costOrgCurr = case SUBSTR(v_bitmap,2,1) & 16 when 16 then v_c13 else costOrgCurr end,costOrg = case SUBSTR(v_bitmap,2,1) & 32 when 32 then v_c14 else costOrg end,cost = case SUBSTR(v_bitmap,2,1) & 64 when 64 then v_c15 else cost end,priority = case SUBSTR(v_bitmap,2,1) & 128 when 128 then v_c16 else priority end,
      access = case SUBSTR(v_bitmap,3,1) & 1 when 1 then v_c17 else access end,quality = case SUBSTR(v_bitmap,3,1) & 2 when 2 then v_c18 else quality end,rating = case SUBSTR(v_bitmap,3,1) & 4 when 4 then v_c19 else rating end,flag = case SUBSTR(v_bitmap,3,1) & 8 when 8 then v_c20 else flag end,
      ext = case SUBSTR(v_bitmap,3,1) & 16 when 16 then v_c21 else ext end,
      `exception` = case SUBSTR(v_bitmap,3,1) & 32 when 32 then v_c22 else `exception` end,exceptionCls = case SUBSTR(v_bitmap,3,1) & 64 when 64 then v_c23 else exceptionCls end
      where id = v_pkc1;
   end if;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSupd_r20_route04` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSupd_r20_route04`(v_c1 INT,v_c2 INT,v_c3 INT,v_c4 INT,v_c5 INT,v_c6 INT,v_c7 VARCHAR(2),v_c8 VARCHAR(16),v_c9 INT,v_c10 VARCHAR(32),v_c11 VARCHAR(2),v_c12 VARCHAR(2),v_c13 VARCHAR(4),v_c14 FLOAT,v_c15 FLOAT,v_c16 FLOAT,v_c17 INT,v_c18 FLOAT,v_c19 INT,v_c20 INT,v_c21 INT,v_c22 INT,v_c23 INT,v_pkc1 INT
,v_bitmap BINARY(3))
BEGIN

   if SUBSTR(v_bitmap,1,1) & 1 = 1 then
      update r20_route04 set
      id = case SUBSTR(v_bitmap,1,1) & 1 when 1 then v_c1 else id end,parentId = case SUBSTR(v_bitmap,1,1) & 2 when 2 then v_c2 else parentId end,
      state = case SUBSTR(v_bitmap,1,1) & 4 when 4 then v_c3 else state end,reason = case SUBSTR(v_bitmap,1,1) & 8 when 8 then v_c4 else reason end,routeCls = case SUBSTR(v_bitmap,1,1) & 16 when 16 then v_c5 else routeCls end,oprId = case SUBSTR(v_bitmap,1,1) & 32 when 32 then v_c6 else oprId end,pc = case SUBSTR(v_bitmap,1,1) & 64 when 64 then v_c7 else pc end,
      prefixCode = case SUBSTR(v_bitmap,1,1) & 128 when 128 then v_c8 else prefixCode end,prefixLen = case SUBSTR(v_bitmap,2,1) & 1 when 1 then v_c9 else prefixLen end,destCode = case SUBSTR(v_bitmap,2,1) & 2 when 2 then v_c10 else destCode end,clsOrg = case SUBSTR(v_bitmap,2,1) & 4 when 4 then v_c11 else clsOrg end,cls = case SUBSTR(v_bitmap,2,1) & 8 when 8 then v_c12 else cls end,
      costOrgCurr = case SUBSTR(v_bitmap,2,1) & 16 when 16 then v_c13 else costOrgCurr end,costOrg = case SUBSTR(v_bitmap,2,1) & 32 when 32 then v_c14 else costOrg end,cost = case SUBSTR(v_bitmap,2,1) & 64 when 64 then v_c15 else cost end,priority = case SUBSTR(v_bitmap,2,1) & 128 when 128 then v_c16 else priority end,
      access = case SUBSTR(v_bitmap,3,1) & 1 when 1 then v_c17 else access end,quality = case SUBSTR(v_bitmap,3,1) & 2 when 2 then v_c18 else quality end,rating = case SUBSTR(v_bitmap,3,1) & 4 when 4 then v_c19 else rating end,flag = case SUBSTR(v_bitmap,3,1) & 8 when 8 then v_c20 else flag end,
      ext = case SUBSTR(v_bitmap,3,1) & 16 when 16 then v_c21 else ext end,
      `exception` = case SUBSTR(v_bitmap,3,1) & 32 when 32 then v_c22 else `exception` end,exceptionCls = case SUBSTR(v_bitmap,3,1) & 64 when 64 then v_c23 else exceptionCls end
      where id = v_pkc1;
   else
      update r20_route04 set
      parentId = case SUBSTR(v_bitmap,1,1) & 2 when 2 then v_c2 else parentId end,state = case SUBSTR(v_bitmap,1,1) & 4 when 4 then v_c3 else state end,reason = case SUBSTR(v_bitmap,1,1) & 8 when 8 then v_c4 else reason end,routeCls = case SUBSTR(v_bitmap,1,1) & 16 when 16 then v_c5 else routeCls end,oprId = case SUBSTR(v_bitmap,1,1) & 32 when 32 then v_c6 else oprId end,pc = case SUBSTR(v_bitmap,1,1) & 64 when 64 then v_c7 else pc end,
      prefixCode = case SUBSTR(v_bitmap,1,1) & 128 when 128 then v_c8 else prefixCode end,prefixLen = case SUBSTR(v_bitmap,2,1) & 1 when 1 then v_c9 else prefixLen end,destCode = case SUBSTR(v_bitmap,2,1) & 2 when 2 then v_c10 else destCode end,clsOrg = case SUBSTR(v_bitmap,2,1) & 4 when 4 then v_c11 else clsOrg end,cls = case SUBSTR(v_bitmap,2,1) & 8 when 8 then v_c12 else cls end,
      costOrgCurr = case SUBSTR(v_bitmap,2,1) & 16 when 16 then v_c13 else costOrgCurr end,costOrg = case SUBSTR(v_bitmap,2,1) & 32 when 32 then v_c14 else costOrg end,cost = case SUBSTR(v_bitmap,2,1) & 64 when 64 then v_c15 else cost end,priority = case SUBSTR(v_bitmap,2,1) & 128 when 128 then v_c16 else priority end,
      access = case SUBSTR(v_bitmap,3,1) & 1 when 1 then v_c17 else access end,quality = case SUBSTR(v_bitmap,3,1) & 2 when 2 then v_c18 else quality end,rating = case SUBSTR(v_bitmap,3,1) & 4 when 4 then v_c19 else rating end,flag = case SUBSTR(v_bitmap,3,1) & 8 when 8 then v_c20 else flag end,
      ext = case SUBSTR(v_bitmap,3,1) & 16 when 16 then v_c21 else ext end,
      `exception` = case SUBSTR(v_bitmap,3,1) & 32 when 32 then v_c22 else `exception` end,exceptionCls = case SUBSTR(v_bitmap,3,1) & 64 when 64 then v_c23 else exceptionCls end
      where id = v_pkc1;
   end if;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSupd_r20_route05` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSupd_r20_route05`(v_c1 INT,v_c2 INT,v_c3 INT,v_c4 INT,v_c5 INT,v_c6 INT,v_c7 VARCHAR(2),v_c8 VARCHAR(16),v_c9 INT,v_c10 VARCHAR(32),v_c11 VARCHAR(2),v_c12 VARCHAR(2),v_c13 VARCHAR(4),v_c14 FLOAT,v_c15 FLOAT,v_c16 FLOAT,v_c17 INT,v_c18 FLOAT,v_c19 INT,v_c20 INT,v_c21 INT,v_c22 INT,v_c23 INT,v_pkc1 INT
,v_bitmap BINARY(3))
BEGIN

   if SUBSTR(v_bitmap,1,1) & 1 = 1 then
      update r20_route05 set
      id = case SUBSTR(v_bitmap,1,1) & 1 when 1 then v_c1 else id end,parentId = case SUBSTR(v_bitmap,1,1) & 2 when 2 then v_c2 else parentId end,
      state = case SUBSTR(v_bitmap,1,1) & 4 when 4 then v_c3 else state end,reason = case SUBSTR(v_bitmap,1,1) & 8 when 8 then v_c4 else reason end,routeCls = case SUBSTR(v_bitmap,1,1) & 16 when 16 then v_c5 else routeCls end,oprId = case SUBSTR(v_bitmap,1,1) & 32 when 32 then v_c6 else oprId end,pc = case SUBSTR(v_bitmap,1,1) & 64 when 64 then v_c7 else pc end,
      prefixCode = case SUBSTR(v_bitmap,1,1) & 128 when 128 then v_c8 else prefixCode end,prefixLen = case SUBSTR(v_bitmap,2,1) & 1 when 1 then v_c9 else prefixLen end,destCode = case SUBSTR(v_bitmap,2,1) & 2 when 2 then v_c10 else destCode end,clsOrg = case SUBSTR(v_bitmap,2,1) & 4 when 4 then v_c11 else clsOrg end,cls = case SUBSTR(v_bitmap,2,1) & 8 when 8 then v_c12 else cls end,
      costOrgCurr = case SUBSTR(v_bitmap,2,1) & 16 when 16 then v_c13 else costOrgCurr end,costOrg = case SUBSTR(v_bitmap,2,1) & 32 when 32 then v_c14 else costOrg end,cost = case SUBSTR(v_bitmap,2,1) & 64 when 64 then v_c15 else cost end,priority = case SUBSTR(v_bitmap,2,1) & 128 when 128 then v_c16 else priority end,
      access = case SUBSTR(v_bitmap,3,1) & 1 when 1 then v_c17 else access end,quality = case SUBSTR(v_bitmap,3,1) & 2 when 2 then v_c18 else quality end,rating = case SUBSTR(v_bitmap,3,1) & 4 when 4 then v_c19 else rating end,flag = case SUBSTR(v_bitmap,3,1) & 8 when 8 then v_c20 else flag end,
      ext = case SUBSTR(v_bitmap,3,1) & 16 when 16 then v_c21 else ext end,
      `exception` = case SUBSTR(v_bitmap,3,1) & 32 when 32 then v_c22 else `exception` end,exceptionCls = case SUBSTR(v_bitmap,3,1) & 64 when 64 then v_c23 else exceptionCls end
      where id = v_pkc1;
   else
      update r20_route05 set
      parentId = case SUBSTR(v_bitmap,1,1) & 2 when 2 then v_c2 else parentId end,state = case SUBSTR(v_bitmap,1,1) & 4 when 4 then v_c3 else state end,reason = case SUBSTR(v_bitmap,1,1) & 8 when 8 then v_c4 else reason end,routeCls = case SUBSTR(v_bitmap,1,1) & 16 when 16 then v_c5 else routeCls end,oprId = case SUBSTR(v_bitmap,1,1) & 32 when 32 then v_c6 else oprId end,pc = case SUBSTR(v_bitmap,1,1) & 64 when 64 then v_c7 else pc end,
      prefixCode = case SUBSTR(v_bitmap,1,1) & 128 when 128 then v_c8 else prefixCode end,prefixLen = case SUBSTR(v_bitmap,2,1) & 1 when 1 then v_c9 else prefixLen end,destCode = case SUBSTR(v_bitmap,2,1) & 2 when 2 then v_c10 else destCode end,clsOrg = case SUBSTR(v_bitmap,2,1) & 4 when 4 then v_c11 else clsOrg end,cls = case SUBSTR(v_bitmap,2,1) & 8 when 8 then v_c12 else cls end,
      costOrgCurr = case SUBSTR(v_bitmap,2,1) & 16 when 16 then v_c13 else costOrgCurr end,costOrg = case SUBSTR(v_bitmap,2,1) & 32 when 32 then v_c14 else costOrg end,cost = case SUBSTR(v_bitmap,2,1) & 64 when 64 then v_c15 else cost end,priority = case SUBSTR(v_bitmap,2,1) & 128 when 128 then v_c16 else priority end,
      access = case SUBSTR(v_bitmap,3,1) & 1 when 1 then v_c17 else access end,quality = case SUBSTR(v_bitmap,3,1) & 2 when 2 then v_c18 else quality end,rating = case SUBSTR(v_bitmap,3,1) & 4 when 4 then v_c19 else rating end,flag = case SUBSTR(v_bitmap,3,1) & 8 when 8 then v_c20 else flag end,
      ext = case SUBSTR(v_bitmap,3,1) & 16 when 16 then v_c21 else ext end,
      `exception` = case SUBSTR(v_bitmap,3,1) & 32 when 32 then v_c22 else `exception` end,exceptionCls = case SUBSTR(v_bitmap,3,1) & 64 when 64 then v_c23 else exceptionCls end
      where id = v_pkc1;
   end if;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSupd_r20_route06` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSupd_r20_route06`(v_c1 INT,v_c2 INT,v_c3 INT,v_c4 INT,v_c5 INT,v_c6 INT,v_c7 VARCHAR(2),v_c8 VARCHAR(16),v_c9 INT,v_c10 VARCHAR(32),v_c11 VARCHAR(2),v_c12 VARCHAR(2),v_c13 VARCHAR(4),v_c14 FLOAT,v_c15 FLOAT,v_c16 FLOAT,v_c17 INT,v_c18 FLOAT,v_c19 INT,v_c20 INT,v_c21 INT,v_c22 INT,v_c23 INT,v_pkc1 INT
,v_bitmap BINARY(3))
BEGIN

   if SUBSTR(v_bitmap,1,1) & 1 = 1 then
      update r20_route06 set
      id = case SUBSTR(v_bitmap,1,1) & 1 when 1 then v_c1 else id end,parentId = case SUBSTR(v_bitmap,1,1) & 2 when 2 then v_c2 else parentId end,
      state = case SUBSTR(v_bitmap,1,1) & 4 when 4 then v_c3 else state end,reason = case SUBSTR(v_bitmap,1,1) & 8 when 8 then v_c4 else reason end,routeCls = case SUBSTR(v_bitmap,1,1) & 16 when 16 then v_c5 else routeCls end,oprId = case SUBSTR(v_bitmap,1,1) & 32 when 32 then v_c6 else oprId end,pc = case SUBSTR(v_bitmap,1,1) & 64 when 64 then v_c7 else pc end,
      prefixCode = case SUBSTR(v_bitmap,1,1) & 128 when 128 then v_c8 else prefixCode end,prefixLen = case SUBSTR(v_bitmap,2,1) & 1 when 1 then v_c9 else prefixLen end,destCode = case SUBSTR(v_bitmap,2,1) & 2 when 2 then v_c10 else destCode end,clsOrg = case SUBSTR(v_bitmap,2,1) & 4 when 4 then v_c11 else clsOrg end,cls = case SUBSTR(v_bitmap,2,1) & 8 when 8 then v_c12 else cls end,
      costOrgCurr = case SUBSTR(v_bitmap,2,1) & 16 when 16 then v_c13 else costOrgCurr end,costOrg = case SUBSTR(v_bitmap,2,1) & 32 when 32 then v_c14 else costOrg end,cost = case SUBSTR(v_bitmap,2,1) & 64 when 64 then v_c15 else cost end,priority = case SUBSTR(v_bitmap,2,1) & 128 when 128 then v_c16 else priority end,
      access = case SUBSTR(v_bitmap,3,1) & 1 when 1 then v_c17 else access end,quality = case SUBSTR(v_bitmap,3,1) & 2 when 2 then v_c18 else quality end,rating = case SUBSTR(v_bitmap,3,1) & 4 when 4 then v_c19 else rating end,flag = case SUBSTR(v_bitmap,3,1) & 8 when 8 then v_c20 else flag end,
      ext = case SUBSTR(v_bitmap,3,1) & 16 when 16 then v_c21 else ext end,
      `exception` = case SUBSTR(v_bitmap,3,1) & 32 when 32 then v_c22 else `exception` end,exceptionCls = case SUBSTR(v_bitmap,3,1) & 64 when 64 then v_c23 else exceptionCls end
      where id = v_pkc1;
   else
      update r20_route06 set
      parentId = case SUBSTR(v_bitmap,1,1) & 2 when 2 then v_c2 else parentId end,state = case SUBSTR(v_bitmap,1,1) & 4 when 4 then v_c3 else state end,reason = case SUBSTR(v_bitmap,1,1) & 8 when 8 then v_c4 else reason end,routeCls = case SUBSTR(v_bitmap,1,1) & 16 when 16 then v_c5 else routeCls end,oprId = case SUBSTR(v_bitmap,1,1) & 32 when 32 then v_c6 else oprId end,pc = case SUBSTR(v_bitmap,1,1) & 64 when 64 then v_c7 else pc end,
      prefixCode = case SUBSTR(v_bitmap,1,1) & 128 when 128 then v_c8 else prefixCode end,prefixLen = case SUBSTR(v_bitmap,2,1) & 1 when 1 then v_c9 else prefixLen end,destCode = case SUBSTR(v_bitmap,2,1) & 2 when 2 then v_c10 else destCode end,clsOrg = case SUBSTR(v_bitmap,2,1) & 4 when 4 then v_c11 else clsOrg end,cls = case SUBSTR(v_bitmap,2,1) & 8 when 8 then v_c12 else cls end,
      costOrgCurr = case SUBSTR(v_bitmap,2,1) & 16 when 16 then v_c13 else costOrgCurr end,costOrg = case SUBSTR(v_bitmap,2,1) & 32 when 32 then v_c14 else costOrg end,cost = case SUBSTR(v_bitmap,2,1) & 64 when 64 then v_c15 else cost end,priority = case SUBSTR(v_bitmap,2,1) & 128 when 128 then v_c16 else priority end,
      access = case SUBSTR(v_bitmap,3,1) & 1 when 1 then v_c17 else access end,quality = case SUBSTR(v_bitmap,3,1) & 2 when 2 then v_c18 else quality end,rating = case SUBSTR(v_bitmap,3,1) & 4 when 4 then v_c19 else rating end,flag = case SUBSTR(v_bitmap,3,1) & 8 when 8 then v_c20 else flag end,
      ext = case SUBSTR(v_bitmap,3,1) & 16 when 16 then v_c21 else ext end,
      `exception` = case SUBSTR(v_bitmap,3,1) & 32 when 32 then v_c22 else `exception` end,exceptionCls = case SUBSTR(v_bitmap,3,1) & 64 when 64 then v_c23 else exceptionCls end
      where id = v_pkc1;
   end if;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSupd_r20_route07` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSupd_r20_route07`(v_c1 INT,v_c2 INT,v_c3 INT,v_c4 INT,v_c5 INT,v_c6 INT,v_c7 VARCHAR(2),v_c8 VARCHAR(16),v_c9 INT,v_c10 VARCHAR(32),v_c11 VARCHAR(2),v_c12 VARCHAR(2),v_c13 VARCHAR(4),v_c14 FLOAT,v_c15 FLOAT,v_c16 FLOAT,v_c17 INT,v_c18 FLOAT,v_c19 INT,v_c20 INT,v_c21 INT,v_c22 INT,v_c23 INT,v_pkc1 INT
,v_bitmap BINARY(3))
BEGIN

   if SUBSTR(v_bitmap,1,1) & 1 = 1 then
      update r20_route07 set
      id = case SUBSTR(v_bitmap,1,1) & 1 when 1 then v_c1 else id end,parentId = case SUBSTR(v_bitmap,1,1) & 2 when 2 then v_c2 else parentId end,
      state = case SUBSTR(v_bitmap,1,1) & 4 when 4 then v_c3 else state end,reason = case SUBSTR(v_bitmap,1,1) & 8 when 8 then v_c4 else reason end,routeCls = case SUBSTR(v_bitmap,1,1) & 16 when 16 then v_c5 else routeCls end,oprId = case SUBSTR(v_bitmap,1,1) & 32 when 32 then v_c6 else oprId end,pc = case SUBSTR(v_bitmap,1,1) & 64 when 64 then v_c7 else pc end,
      prefixCode = case SUBSTR(v_bitmap,1,1) & 128 when 128 then v_c8 else prefixCode end,prefixLen = case SUBSTR(v_bitmap,2,1) & 1 when 1 then v_c9 else prefixLen end,destCode = case SUBSTR(v_bitmap,2,1) & 2 when 2 then v_c10 else destCode end,clsOrg = case SUBSTR(v_bitmap,2,1) & 4 when 4 then v_c11 else clsOrg end,cls = case SUBSTR(v_bitmap,2,1) & 8 when 8 then v_c12 else cls end,
      costOrgCurr = case SUBSTR(v_bitmap,2,1) & 16 when 16 then v_c13 else costOrgCurr end,costOrg = case SUBSTR(v_bitmap,2,1) & 32 when 32 then v_c14 else costOrg end,cost = case SUBSTR(v_bitmap,2,1) & 64 when 64 then v_c15 else cost end,priority = case SUBSTR(v_bitmap,2,1) & 128 when 128 then v_c16 else priority end,
      access = case SUBSTR(v_bitmap,3,1) & 1 when 1 then v_c17 else access end,quality = case SUBSTR(v_bitmap,3,1) & 2 when 2 then v_c18 else quality end,rating = case SUBSTR(v_bitmap,3,1) & 4 when 4 then v_c19 else rating end,flag = case SUBSTR(v_bitmap,3,1) & 8 when 8 then v_c20 else flag end,
      ext = case SUBSTR(v_bitmap,3,1) & 16 when 16 then v_c21 else ext end,
      `exception` = case SUBSTR(v_bitmap,3,1) & 32 when 32 then v_c22 else `exception` end,exceptionCls = case SUBSTR(v_bitmap,3,1) & 64 when 64 then v_c23 else exceptionCls end
      where id = v_pkc1;
   else
      update r20_route07 set
      parentId = case SUBSTR(v_bitmap,1,1) & 2 when 2 then v_c2 else parentId end,state = case SUBSTR(v_bitmap,1,1) & 4 when 4 then v_c3 else state end,reason = case SUBSTR(v_bitmap,1,1) & 8 when 8 then v_c4 else reason end,routeCls = case SUBSTR(v_bitmap,1,1) & 16 when 16 then v_c5 else routeCls end,oprId = case SUBSTR(v_bitmap,1,1) & 32 when 32 then v_c6 else oprId end,pc = case SUBSTR(v_bitmap,1,1) & 64 when 64 then v_c7 else pc end,
      prefixCode = case SUBSTR(v_bitmap,1,1) & 128 when 128 then v_c8 else prefixCode end,prefixLen = case SUBSTR(v_bitmap,2,1) & 1 when 1 then v_c9 else prefixLen end,destCode = case SUBSTR(v_bitmap,2,1) & 2 when 2 then v_c10 else destCode end,clsOrg = case SUBSTR(v_bitmap,2,1) & 4 when 4 then v_c11 else clsOrg end,cls = case SUBSTR(v_bitmap,2,1) & 8 when 8 then v_c12 else cls end,
      costOrgCurr = case SUBSTR(v_bitmap,2,1) & 16 when 16 then v_c13 else costOrgCurr end,costOrg = case SUBSTR(v_bitmap,2,1) & 32 when 32 then v_c14 else costOrg end,cost = case SUBSTR(v_bitmap,2,1) & 64 when 64 then v_c15 else cost end,priority = case SUBSTR(v_bitmap,2,1) & 128 when 128 then v_c16 else priority end,
      access = case SUBSTR(v_bitmap,3,1) & 1 when 1 then v_c17 else access end,quality = case SUBSTR(v_bitmap,3,1) & 2 when 2 then v_c18 else quality end,rating = case SUBSTR(v_bitmap,3,1) & 4 when 4 then v_c19 else rating end,flag = case SUBSTR(v_bitmap,3,1) & 8 when 8 then v_c20 else flag end,
      ext = case SUBSTR(v_bitmap,3,1) & 16 when 16 then v_c21 else ext end,
      `exception` = case SUBSTR(v_bitmap,3,1) & 32 when 32 then v_c22 else `exception` end,exceptionCls = case SUBSTR(v_bitmap,3,1) & 64 when 64 then v_c23 else exceptionCls end
      where id = v_pkc1;
   end if;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSupd_r20_route08` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSupd_r20_route08`(v_c1 INT,v_c2 INT,v_c3 INT,v_c4 INT,v_c5 INT,v_c6 INT,v_c7 VARCHAR(2),v_c8 VARCHAR(16),v_c9 INT,v_c10 VARCHAR(32),v_c11 VARCHAR(2),v_c12 VARCHAR(2),v_c13 VARCHAR(4),v_c14 FLOAT,v_c15 FLOAT,v_c16 FLOAT,v_c17 INT,v_c18 FLOAT,v_c19 INT,v_c20 INT,v_c21 INT,v_c22 INT,v_c23 INT,v_pkc1 INT
,v_bitmap BINARY(3))
BEGIN

   if SUBSTR(v_bitmap,1,1) & 1 = 1 then
      update r20_route08 set
      id = case SUBSTR(v_bitmap,1,1) & 1 when 1 then v_c1 else id end,parentId = case SUBSTR(v_bitmap,1,1) & 2 when 2 then v_c2 else parentId end,
      state = case SUBSTR(v_bitmap,1,1) & 4 when 4 then v_c3 else state end,reason = case SUBSTR(v_bitmap,1,1) & 8 when 8 then v_c4 else reason end,routeCls = case SUBSTR(v_bitmap,1,1) & 16 when 16 then v_c5 else routeCls end,oprId = case SUBSTR(v_bitmap,1,1) & 32 when 32 then v_c6 else oprId end,pc = case SUBSTR(v_bitmap,1,1) & 64 when 64 then v_c7 else pc end,
      prefixCode = case SUBSTR(v_bitmap,1,1) & 128 when 128 then v_c8 else prefixCode end,prefixLen = case SUBSTR(v_bitmap,2,1) & 1 when 1 then v_c9 else prefixLen end,destCode = case SUBSTR(v_bitmap,2,1) & 2 when 2 then v_c10 else destCode end,clsOrg = case SUBSTR(v_bitmap,2,1) & 4 when 4 then v_c11 else clsOrg end,cls = case SUBSTR(v_bitmap,2,1) & 8 when 8 then v_c12 else cls end,
      costOrgCurr = case SUBSTR(v_bitmap,2,1) & 16 when 16 then v_c13 else costOrgCurr end,costOrg = case SUBSTR(v_bitmap,2,1) & 32 when 32 then v_c14 else costOrg end,cost = case SUBSTR(v_bitmap,2,1) & 64 when 64 then v_c15 else cost end,priority = case SUBSTR(v_bitmap,2,1) & 128 when 128 then v_c16 else priority end,
      access = case SUBSTR(v_bitmap,3,1) & 1 when 1 then v_c17 else access end,quality = case SUBSTR(v_bitmap,3,1) & 2 when 2 then v_c18 else quality end,rating = case SUBSTR(v_bitmap,3,1) & 4 when 4 then v_c19 else rating end,flag = case SUBSTR(v_bitmap,3,1) & 8 when 8 then v_c20 else flag end,
      ext = case SUBSTR(v_bitmap,3,1) & 16 when 16 then v_c21 else ext end,
      `exception` = case SUBSTR(v_bitmap,3,1) & 32 when 32 then v_c22 else `exception` end,exceptionCls = case SUBSTR(v_bitmap,3,1) & 64 when 64 then v_c23 else exceptionCls end
      where id = v_pkc1;
   else
      update r20_route08 set
      parentId = case SUBSTR(v_bitmap,1,1) & 2 when 2 then v_c2 else parentId end,state = case SUBSTR(v_bitmap,1,1) & 4 when 4 then v_c3 else state end,reason = case SUBSTR(v_bitmap,1,1) & 8 when 8 then v_c4 else reason end,routeCls = case SUBSTR(v_bitmap,1,1) & 16 when 16 then v_c5 else routeCls end,oprId = case SUBSTR(v_bitmap,1,1) & 32 when 32 then v_c6 else oprId end,pc = case SUBSTR(v_bitmap,1,1) & 64 when 64 then v_c7 else pc end,
      prefixCode = case SUBSTR(v_bitmap,1,1) & 128 when 128 then v_c8 else prefixCode end,prefixLen = case SUBSTR(v_bitmap,2,1) & 1 when 1 then v_c9 else prefixLen end,destCode = case SUBSTR(v_bitmap,2,1) & 2 when 2 then v_c10 else destCode end,clsOrg = case SUBSTR(v_bitmap,2,1) & 4 when 4 then v_c11 else clsOrg end,cls = case SUBSTR(v_bitmap,2,1) & 8 when 8 then v_c12 else cls end,
      costOrgCurr = case SUBSTR(v_bitmap,2,1) & 16 when 16 then v_c13 else costOrgCurr end,costOrg = case SUBSTR(v_bitmap,2,1) & 32 when 32 then v_c14 else costOrg end,cost = case SUBSTR(v_bitmap,2,1) & 64 when 64 then v_c15 else cost end,priority = case SUBSTR(v_bitmap,2,1) & 128 when 128 then v_c16 else priority end,
      access = case SUBSTR(v_bitmap,3,1) & 1 when 1 then v_c17 else access end,quality = case SUBSTR(v_bitmap,3,1) & 2 when 2 then v_c18 else quality end,rating = case SUBSTR(v_bitmap,3,1) & 4 when 4 then v_c19 else rating end,flag = case SUBSTR(v_bitmap,3,1) & 8 when 8 then v_c20 else flag end,
      ext = case SUBSTR(v_bitmap,3,1) & 16 when 16 then v_c21 else ext end,
      `exception` = case SUBSTR(v_bitmap,3,1) & 32 when 32 then v_c22 else `exception` end,exceptionCls = case SUBSTR(v_bitmap,3,1) & 64 when 64 then v_c23 else exceptionCls end
      where id = v_pkc1;
   end if;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSupd_R20_route10` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSupd_R20_route10`(v_c1 INT,v_c2 INT,v_c3 INT,v_c4 INT,v_c5 INT,v_c6 INT,v_c7 VARCHAR(2),v_c8 VARCHAR(16),v_c9 INT,v_c10 VARCHAR(32),v_c11 VARCHAR(2),v_c12 VARCHAR(2),v_c13 VARCHAR(4),v_c14 FLOAT,v_c15 FLOAT,v_c16 FLOAT,v_c17 INT,v_c18 FLOAT,v_c19 INT,v_c20 INT,v_c21 INT,v_c22 INT,v_c23 INT,v_pkc1 INT
,v_bitmap BINARY(3))
BEGIN

   if SUBSTR(v_bitmap,1,1) & 1 = 1 then
      update R20_route10 set
      id = case SUBSTR(v_bitmap,1,1) & 1 when 1 then v_c1 else id end,parentId = case SUBSTR(v_bitmap,1,1) & 2 when 2 then v_c2 else parentId end,
      state = case SUBSTR(v_bitmap,1,1) & 4 when 4 then v_c3 else state end,reason = case SUBSTR(v_bitmap,1,1) & 8 when 8 then v_c4 else reason end,routeCls = case SUBSTR(v_bitmap,1,1) & 16 when 16 then v_c5 else routeCls end,oprId = case SUBSTR(v_bitmap,1,1) & 32 when 32 then v_c6 else oprId end,pc = case SUBSTR(v_bitmap,1,1) & 64 when 64 then v_c7 else pc end,
      prefixCode = case SUBSTR(v_bitmap,1,1) & 128 when 128 then v_c8 else prefixCode end,prefixLen = case SUBSTR(v_bitmap,2,1) & 1 when 1 then v_c9 else prefixLen end,destCode = case SUBSTR(v_bitmap,2,1) & 2 when 2 then v_c10 else destCode end,clsOrg = case SUBSTR(v_bitmap,2,1) & 4 when 4 then v_c11 else clsOrg end,cls = case SUBSTR(v_bitmap,2,1) & 8 when 8 then v_c12 else cls end,
      costOrgCurr = case SUBSTR(v_bitmap,2,1) & 16 when 16 then v_c13 else costOrgCurr end,costOrg = case SUBSTR(v_bitmap,2,1) & 32 when 32 then v_c14 else costOrg end,cost = case SUBSTR(v_bitmap,2,1) & 64 when 64 then v_c15 else cost end,priority = case SUBSTR(v_bitmap,2,1) & 128 when 128 then v_c16 else priority end,
      access = case SUBSTR(v_bitmap,3,1) & 1 when 1 then v_c17 else access end,quality = case SUBSTR(v_bitmap,3,1) & 2 when 2 then v_c18 else quality end,rating = case SUBSTR(v_bitmap,3,1) & 4 when 4 then v_c19 else rating end,flag = case SUBSTR(v_bitmap,3,1) & 8 when 8 then v_c20 else flag end,
      ext = case SUBSTR(v_bitmap,3,1) & 16 when 16 then v_c21 else ext end,
      `exception` = case SUBSTR(v_bitmap,3,1) & 32 when 32 then v_c22 else `exception` end,exceptionCls = case SUBSTR(v_bitmap,3,1) & 64 when 64 then v_c23 else exceptionCls end
      where id = v_pkc1;
   else
      update R20_route10 set
      parentId = case SUBSTR(v_bitmap,1,1) & 2 when 2 then v_c2 else parentId end,state = case SUBSTR(v_bitmap,1,1) & 4 when 4 then v_c3 else state end,reason = case SUBSTR(v_bitmap,1,1) & 8 when 8 then v_c4 else reason end,routeCls = case SUBSTR(v_bitmap,1,1) & 16 when 16 then v_c5 else routeCls end,oprId = case SUBSTR(v_bitmap,1,1) & 32 when 32 then v_c6 else oprId end,pc = case SUBSTR(v_bitmap,1,1) & 64 when 64 then v_c7 else pc end,
      prefixCode = case SUBSTR(v_bitmap,1,1) & 128 when 128 then v_c8 else prefixCode end,prefixLen = case SUBSTR(v_bitmap,2,1) & 1 when 1 then v_c9 else prefixLen end,destCode = case SUBSTR(v_bitmap,2,1) & 2 when 2 then v_c10 else destCode end,clsOrg = case SUBSTR(v_bitmap,2,1) & 4 when 4 then v_c11 else clsOrg end,cls = case SUBSTR(v_bitmap,2,1) & 8 when 8 then v_c12 else cls end,
      costOrgCurr = case SUBSTR(v_bitmap,2,1) & 16 when 16 then v_c13 else costOrgCurr end,costOrg = case SUBSTR(v_bitmap,2,1) & 32 when 32 then v_c14 else costOrg end,cost = case SUBSTR(v_bitmap,2,1) & 64 when 64 then v_c15 else cost end,priority = case SUBSTR(v_bitmap,2,1) & 128 when 128 then v_c16 else priority end,
      access = case SUBSTR(v_bitmap,3,1) & 1 when 1 then v_c17 else access end,quality = case SUBSTR(v_bitmap,3,1) & 2 when 2 then v_c18 else quality end,rating = case SUBSTR(v_bitmap,3,1) & 4 when 4 then v_c19 else rating end,flag = case SUBSTR(v_bitmap,3,1) & 8 when 8 then v_c20 else flag end,
      ext = case SUBSTR(v_bitmap,3,1) & 16 when 16 then v_c21 else ext end,
      `exception` = case SUBSTR(v_bitmap,3,1) & 32 when 32 then v_c22 else `exception` end,exceptionCls = case SUBSTR(v_bitmap,3,1) & 64 when 64 then v_c23 else exceptionCls end
      where id = v_pkc1;
   end if;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSupd_r20_route11` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSupd_r20_route11`(v_c1 INT,v_c2 INT,v_c3 INT,v_c4 INT,v_c5 INT,v_c6 INT,v_c7 VARCHAR(2),v_c8 VARCHAR(16),v_c9 INT,v_c10 VARCHAR(32),v_c11 VARCHAR(2),v_c12 VARCHAR(2),v_c13 VARCHAR(4),v_c14 FLOAT,v_c15 FLOAT,v_c16 FLOAT,v_c17 INT,v_c18 FLOAT,v_c19 INT,v_c20 INT,v_c21 INT,v_c22 INT,v_c23 INT,v_pkc1 INT
,v_bitmap BINARY(3))
BEGIN

   if SUBSTR(v_bitmap,1,1) & 1 = 1 then
      update r20_route11 set
      id = case SUBSTR(v_bitmap,1,1) & 1 when 1 then v_c1 else id end,parentId = case SUBSTR(v_bitmap,1,1) & 2 when 2 then v_c2 else parentId end,
      state = case SUBSTR(v_bitmap,1,1) & 4 when 4 then v_c3 else state end,reason = case SUBSTR(v_bitmap,1,1) & 8 when 8 then v_c4 else reason end,routeCls = case SUBSTR(v_bitmap,1,1) & 16 when 16 then v_c5 else routeCls end,oprId = case SUBSTR(v_bitmap,1,1) & 32 when 32 then v_c6 else oprId end,pc = case SUBSTR(v_bitmap,1,1) & 64 when 64 then v_c7 else pc end,
      prefixCode = case SUBSTR(v_bitmap,1,1) & 128 when 128 then v_c8 else prefixCode end,prefixLen = case SUBSTR(v_bitmap,2,1) & 1 when 1 then v_c9 else prefixLen end,destCode = case SUBSTR(v_bitmap,2,1) & 2 when 2 then v_c10 else destCode end,clsOrg = case SUBSTR(v_bitmap,2,1) & 4 when 4 then v_c11 else clsOrg end,cls = case SUBSTR(v_bitmap,2,1) & 8 when 8 then v_c12 else cls end,
      costOrgCurr = case SUBSTR(v_bitmap,2,1) & 16 when 16 then v_c13 else costOrgCurr end,costOrg = case SUBSTR(v_bitmap,2,1) & 32 when 32 then v_c14 else costOrg end,cost = case SUBSTR(v_bitmap,2,1) & 64 when 64 then v_c15 else cost end,priority = case SUBSTR(v_bitmap,2,1) & 128 when 128 then v_c16 else priority end,
      access = case SUBSTR(v_bitmap,3,1) & 1 when 1 then v_c17 else access end,quality = case SUBSTR(v_bitmap,3,1) & 2 when 2 then v_c18 else quality end,rating = case SUBSTR(v_bitmap,3,1) & 4 when 4 then v_c19 else rating end,flag = case SUBSTR(v_bitmap,3,1) & 8 when 8 then v_c20 else flag end,
      ext = case SUBSTR(v_bitmap,3,1) & 16 when 16 then v_c21 else ext end,
      `exception` = case SUBSTR(v_bitmap,3,1) & 32 when 32 then v_c22 else `exception` end,exceptionCls = case SUBSTR(v_bitmap,3,1) & 64 when 64 then v_c23 else exceptionCls end
      where id = v_pkc1;
   else
      update r20_route11 set
      parentId = case SUBSTR(v_bitmap,1,1) & 2 when 2 then v_c2 else parentId end,state = case SUBSTR(v_bitmap,1,1) & 4 when 4 then v_c3 else state end,reason = case SUBSTR(v_bitmap,1,1) & 8 when 8 then v_c4 else reason end,routeCls = case SUBSTR(v_bitmap,1,1) & 16 when 16 then v_c5 else routeCls end,oprId = case SUBSTR(v_bitmap,1,1) & 32 when 32 then v_c6 else oprId end,pc = case SUBSTR(v_bitmap,1,1) & 64 when 64 then v_c7 else pc end,
      prefixCode = case SUBSTR(v_bitmap,1,1) & 128 when 128 then v_c8 else prefixCode end,prefixLen = case SUBSTR(v_bitmap,2,1) & 1 when 1 then v_c9 else prefixLen end,destCode = case SUBSTR(v_bitmap,2,1) & 2 when 2 then v_c10 else destCode end,clsOrg = case SUBSTR(v_bitmap,2,1) & 4 when 4 then v_c11 else clsOrg end,cls = case SUBSTR(v_bitmap,2,1) & 8 when 8 then v_c12 else cls end,
      costOrgCurr = case SUBSTR(v_bitmap,2,1) & 16 when 16 then v_c13 else costOrgCurr end,costOrg = case SUBSTR(v_bitmap,2,1) & 32 when 32 then v_c14 else costOrg end,cost = case SUBSTR(v_bitmap,2,1) & 64 when 64 then v_c15 else cost end,priority = case SUBSTR(v_bitmap,2,1) & 128 when 128 then v_c16 else priority end,
      access = case SUBSTR(v_bitmap,3,1) & 1 when 1 then v_c17 else access end,quality = case SUBSTR(v_bitmap,3,1) & 2 when 2 then v_c18 else quality end,rating = case SUBSTR(v_bitmap,3,1) & 4 when 4 then v_c19 else rating end,flag = case SUBSTR(v_bitmap,3,1) & 8 when 8 then v_c20 else flag end,
      ext = case SUBSTR(v_bitmap,3,1) & 16 when 16 then v_c21 else ext end,
      `exception` = case SUBSTR(v_bitmap,3,1) & 32 when 32 then v_c22 else `exception` end,exceptionCls = case SUBSTR(v_bitmap,3,1) & 64 when 64 then v_c23 else exceptionCls end
      where id = v_pkc1;
   end if;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSupd_R20_route12` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSupd_R20_route12`(v_c1 INT,v_c2 INT,v_c3 INT,v_c4 INT,v_c5 INT,v_c6 INT,v_c7 VARCHAR(2),v_c8 VARCHAR(16),v_c9 INT,v_c10 VARCHAR(32),v_c11 VARCHAR(2),v_c12 VARCHAR(2),v_c13 VARCHAR(4),v_c14 FLOAT,v_c15 FLOAT,v_c16 FLOAT,v_c17 INT,v_c18 FLOAT,v_c19 INT,v_c20 INT,v_c21 INT,v_c22 INT,v_c23 INT,v_pkc1 INT
,v_bitmap BINARY(3))
BEGIN

   if SUBSTR(v_bitmap,1,1) & 1 = 1 then
      update R20_route12 set
      id = case SUBSTR(v_bitmap,1,1) & 1 when 1 then v_c1 else id end,parentId = case SUBSTR(v_bitmap,1,1) & 2 when 2 then v_c2 else parentId end,
      state = case SUBSTR(v_bitmap,1,1) & 4 when 4 then v_c3 else state end,reason = case SUBSTR(v_bitmap,1,1) & 8 when 8 then v_c4 else reason end,routeCls = case SUBSTR(v_bitmap,1,1) & 16 when 16 then v_c5 else routeCls end,oprId = case SUBSTR(v_bitmap,1,1) & 32 when 32 then v_c6 else oprId end,pc = case SUBSTR(v_bitmap,1,1) & 64 when 64 then v_c7 else pc end,
      prefixCode = case SUBSTR(v_bitmap,1,1) & 128 when 128 then v_c8 else prefixCode end,prefixLen = case SUBSTR(v_bitmap,2,1) & 1 when 1 then v_c9 else prefixLen end,destCode = case SUBSTR(v_bitmap,2,1) & 2 when 2 then v_c10 else destCode end,clsOrg = case SUBSTR(v_bitmap,2,1) & 4 when 4 then v_c11 else clsOrg end,cls = case SUBSTR(v_bitmap,2,1) & 8 when 8 then v_c12 else cls end,
      costOrgCurr = case SUBSTR(v_bitmap,2,1) & 16 when 16 then v_c13 else costOrgCurr end,costOrg = case SUBSTR(v_bitmap,2,1) & 32 when 32 then v_c14 else costOrg end,cost = case SUBSTR(v_bitmap,2,1) & 64 when 64 then v_c15 else cost end,priority = case SUBSTR(v_bitmap,2,1) & 128 when 128 then v_c16 else priority end,
      access = case SUBSTR(v_bitmap,3,1) & 1 when 1 then v_c17 else access end,quality = case SUBSTR(v_bitmap,3,1) & 2 when 2 then v_c18 else quality end,rating = case SUBSTR(v_bitmap,3,1) & 4 when 4 then v_c19 else rating end,flag = case SUBSTR(v_bitmap,3,1) & 8 when 8 then v_c20 else flag end,
      ext = case SUBSTR(v_bitmap,3,1) & 16 when 16 then v_c21 else ext end,
      `exception` = case SUBSTR(v_bitmap,3,1) & 32 when 32 then v_c22 else `exception` end,exceptionCls = case SUBSTR(v_bitmap,3,1) & 64 when 64 then v_c23 else exceptionCls end
      where id = v_pkc1;
   else
      update R20_route12 set
      parentId = case SUBSTR(v_bitmap,1,1) & 2 when 2 then v_c2 else parentId end,state = case SUBSTR(v_bitmap,1,1) & 4 when 4 then v_c3 else state end,reason = case SUBSTR(v_bitmap,1,1) & 8 when 8 then v_c4 else reason end,routeCls = case SUBSTR(v_bitmap,1,1) & 16 when 16 then v_c5 else routeCls end,oprId = case SUBSTR(v_bitmap,1,1) & 32 when 32 then v_c6 else oprId end,pc = case SUBSTR(v_bitmap,1,1) & 64 when 64 then v_c7 else pc end,
      prefixCode = case SUBSTR(v_bitmap,1,1) & 128 when 128 then v_c8 else prefixCode end,prefixLen = case SUBSTR(v_bitmap,2,1) & 1 when 1 then v_c9 else prefixLen end,destCode = case SUBSTR(v_bitmap,2,1) & 2 when 2 then v_c10 else destCode end,clsOrg = case SUBSTR(v_bitmap,2,1) & 4 when 4 then v_c11 else clsOrg end,cls = case SUBSTR(v_bitmap,2,1) & 8 when 8 then v_c12 else cls end,
      costOrgCurr = case SUBSTR(v_bitmap,2,1) & 16 when 16 then v_c13 else costOrgCurr end,costOrg = case SUBSTR(v_bitmap,2,1) & 32 when 32 then v_c14 else costOrg end,cost = case SUBSTR(v_bitmap,2,1) & 64 when 64 then v_c15 else cost end,priority = case SUBSTR(v_bitmap,2,1) & 128 when 128 then v_c16 else priority end,
      access = case SUBSTR(v_bitmap,3,1) & 1 when 1 then v_c17 else access end,quality = case SUBSTR(v_bitmap,3,1) & 2 when 2 then v_c18 else quality end,rating = case SUBSTR(v_bitmap,3,1) & 4 when 4 then v_c19 else rating end,flag = case SUBSTR(v_bitmap,3,1) & 8 when 8 then v_c20 else flag end,
      ext = case SUBSTR(v_bitmap,3,1) & 16 when 16 then v_c21 else ext end,
      `exception` = case SUBSTR(v_bitmap,3,1) & 32 when 32 then v_c22 else `exception` end,exceptionCls = case SUBSTR(v_bitmap,3,1) & 64 when 64 then v_c23 else exceptionCls end
      where id = v_pkc1;
   end if;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSupd_r20_route_timecls` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSupd_r20_route_timecls`(v_c1 INT,v_c2 INT,v_c3 INT,v_c4 VARCHAR(1),v_c5 VARCHAR(2),v_pkc1 INT
,v_bitmap BINARY(1))
BEGIN

   if SUBSTR(v_bitmap,1,1) & 1 = 1 then
      update r20_route_timecls set
      id = case SUBSTR(v_bitmap,1,1) & 1 when 1 then v_c1 else id end,routecls = case SUBSTR(v_bitmap,1,1) & 2 when 2 then v_c2 else routecls end,
      oprId = case SUBSTR(v_bitmap,1,1) & 4 when 4 then v_c3 else oprId end,cls = case SUBSTR(v_bitmap,1,1) & 8 when 8 then v_c4 else cls end,pc = case SUBSTR(v_bitmap,1,1) & 16 when 16 then v_c5 else pc end
      where id = v_pkc1;
   else
      update r20_route_timecls set
      routecls = case SUBSTR(v_bitmap,1,1) & 2 when 2 then v_c2 else routecls end,oprId = case SUBSTR(v_bitmap,1,1) & 4 when 4 then v_c3 else oprId end,cls = case SUBSTR(v_bitmap,1,1) & 8 when 8 then v_c4 else cls end,
      pc = case SUBSTR(v_bitmap,1,1) & 16 when 16 then v_c5 else pc end
      where id = v_pkc1;
   end if;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSupd_r_daycode` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSupd_r_daycode`(v_c1 INT,v_c2 INT,v_c3 INT,v_pkc1 INT
,v_bitmap BINARY(1))
BEGIN

   if SUBSTR(v_bitmap,1,1) & 1 = 1 then
      update r_daycode set
      id = case SUBSTR(v_bitmap,1,1) & 1 when 1 then v_c1 else id end,d1 = case SUBSTR(v_bitmap,1,1) & 2 when 2 then v_c2 else d1 end,
      d2 = case SUBSTR(v_bitmap,1,1) & 4 when 4 then v_c3 else d2 end
      where id = v_pkc1;
   else
      update r_daycode set
      d1 = case SUBSTR(v_bitmap,1,1) & 2 when 2 then v_c2 else d1 end,d2 = case SUBSTR(v_bitmap,1,1) & 4 when 4 then v_c3 else d2 end
      where id = v_pkc1;
   end if;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSupd_r_domain` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSupd_r_domain`(v_c1 CHAR(1),v_c2 VARCHAR(8),v_c3 VARCHAR(8),v_c4 VARCHAR(32),v_c5 VARCHAR(128),v_c6 INT,v_c7 VARCHAR(64),v_pkc1 VARCHAR(8),v_pkc2 VARCHAR(8)
,v_bitmap BINARY(1))
BEGIN

   if SUBSTR(v_bitmap,1,1) & 2 = 2 or SUBSTR(v_bitmap,1,1) & 4 = 4 then
      update r_domain set
      state = case SUBSTR(v_bitmap,1,1) & 1 when 1 then v_c1 else state end,universe = case SUBSTR(v_bitmap,1,1) & 2 when 2 then v_c2 else universe end,name = case SUBSTR(v_bitmap,1,1) & 4 when 4 then v_c3 else name end,
      longname = case SUBSTR(v_bitmap,1,1) & 8 when 8 then v_c4 else longname end,userinfo = case SUBSTR(v_bitmap,1,1) & 16 when 16 then v_c5 else userinfo end,timezone = case SUBSTR(v_bitmap,1,1) & 32 when 32 then v_c6 else timezone end,reserved = case SUBSTR(v_bitmap,1,1) & 64 when 64 then v_c7 else reserved end
      where universe = v_pkc1 and name = v_pkc2;
   else
      update r_domain set
      state = case SUBSTR(v_bitmap,1,1) & 1 when 1 then v_c1 else state end,longname = case SUBSTR(v_bitmap,1,1) & 8 when 8 then v_c4 else longname end,userinfo = case SUBSTR(v_bitmap,1,1) & 16 when 16 then v_c5 else userinfo end,timezone = case SUBSTR(v_bitmap,1,1) & 32 when 32 then v_c6 else timezone end,reserved = case SUBSTR(v_bitmap,1,1) & 64 when 64 then v_c7 else reserved end
      where universe = v_pkc1 and name = v_pkc2;
   end if;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSupd_r_interface` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSupd_r_interface`(v_c1 INT,v_c2 CHAR(1),v_c3 VARCHAR(8),v_c4 VARCHAR(8),v_c5 VARCHAR(8),v_c6 VARCHAR(32),v_c7 VARCHAR(16),v_c8 VARCHAR(128),v_c9 INT,v_c10 INT,v_c11 INT,v_c12 VARCHAR(64),v_c13 VARCHAR(64),v_c14 INT,v_c15 INT,v_pkc1 INT
,v_bitmap BINARY(2))
BEGIN

   if SUBSTR(v_bitmap,1,1) & 1 = 1 then
      update r_interface set
      id = case SUBSTR(v_bitmap,1,1) & 1 when 1 then v_c1 else id end,state = case SUBSTR(v_bitmap,1,1) & 2 when 2 then v_c2 else state end,universe = case SUBSTR(v_bitmap,1,1) & 4 when 4 then v_c3 else universe end,
      `domain` = case SUBSTR(v_bitmap,1,1) & 8 when 8 then v_c4 else `domain` end,pdomain = case SUBSTR(v_bitmap,1,1) & 16 when 16 then v_c5 else pdomain end,name = case SUBSTR(v_bitmap,1,1) & 32 when 32 then v_c6 else name end,`group` = case SUBSTR(v_bitmap,1,1) & 64 when 64 then v_c7 else `group` end,hint = case SUBSTR(v_bitmap,1,1) & 128 when 128 then v_c8 else hint end,routecls = case SUBSTR(v_bitmap,2,1) & 1 when 1 then v_c9 else routecls end,allowloop = case SUBSTR(v_bitmap,2,1) & 2 when 2 then v_c10 else allowloop end,intcls = case SUBSTR(v_bitmap,2,1) & 4 when 4 then v_c11 else intcls end,userinfo = case SUBSTR(v_bitmap,2,1) & 8 when 8 then v_c12 else userinfo end,reserved = case SUBSTR(v_bitmap,2,1) & 16 when 16 then v_c13 else reserved end,prefixcls = case SUBSTR(v_bitmap,2,1) & 32 when 32 then v_c14 else prefixcls end,type = case SUBSTR(v_bitmap,2,1) & 64 when 64 then v_c15 else type end
      where id = v_pkc1;
   else
      update r_interface set
      state = case SUBSTR(v_bitmap,1,1) & 2 when 2 then v_c2 else state end,universe = case SUBSTR(v_bitmap,1,1) & 4 when 4 then v_c3 else universe end,`domain` = case SUBSTR(v_bitmap,1,1) & 8 when 8 then v_c4 else `domain` end,pdomain = case SUBSTR(v_bitmap,1,1) & 16 when 16 then v_c5 else pdomain end,name = case SUBSTR(v_bitmap,1,1) & 32 when 32 then v_c6 else name end,`group` = case SUBSTR(v_bitmap,1,1) & 64 when 64 then v_c7 else `group` end,hint = case SUBSTR(v_bitmap,1,1) & 128 when 128 then v_c8 else hint end,routecls = case SUBSTR(v_bitmap,2,1) & 1 when 1 then v_c9 else routecls end,allowloop = case SUBSTR(v_bitmap,2,1) & 2 when 2 then v_c10 else allowloop end,intcls = case SUBSTR(v_bitmap,2,1) & 4 when 4 then v_c11 else intcls end,userinfo = case SUBSTR(v_bitmap,2,1) & 8 when 8 then v_c12 else userinfo end,reserved = case SUBSTR(v_bitmap,2,1) & 16 when 16 then v_c13 else reserved end,prefixcls = case SUBSTR(v_bitmap,2,1) & 32 when 32 then v_c14 else prefixcls end,
      type = case SUBSTR(v_bitmap,2,1) & 64 when 64 then v_c15 else type end
      where id = v_pkc1;
   end if;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSupd_r_interfaceGroup` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSupd_r_interfaceGroup`(v_c1 INT,v_c2 INT,v_c3 INT,v_pkc1 INT,v_pkc2 INT
,v_bitmap BINARY(1))
BEGIN

   if SUBSTR(v_bitmap,1,1) & 1 = 1 or SUBSTR(v_bitmap,1,1) & 2 = 2 then
      update r_interfaceGroup set
      tintid = case SUBSTR(v_bitmap,1,1) & 1 when 1 then v_c1 else tintid end,IntGroupID = case SUBSTR(v_bitmap,1,1) & 2 when 2 then v_c2 else IntGroupID end,flag = case SUBSTR(v_bitmap,1,1) & 4 when 4 then v_c3 else flag end
      where tintid = v_pkc1 and IntGroupID = v_pkc2;
   else
      update r_interfaceGroup set
      flag = case SUBSTR(v_bitmap,1,1) & 4 when 4 then v_c3 else flag end
      where tintid = v_pkc1 and IntGroupID = v_pkc2;
   end if;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSupd_r_operatorset` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSupd_r_operatorset`(v_c1 INT,v_c2 INT,v_c3 TINYINT UNSIGNED,v_c4 TINYINT UNSIGNED,v_c5 FLOAT,v_c6 FLOAT,v_c7 INT,v_c8 INT,v_c9 VARCHAR(128),v_pkc1 INT,v_pkc2 INT
,v_bitmap BINARY(2))
BEGIN

   if SUBSTR(v_bitmap,1,1) & 1 = 1 or SUBSTR(v_bitmap,1,1) & 2 = 2 then
      update r_operatorset set
      operatorset_id = case SUBSTR(v_bitmap,1,1) & 1 when 1 then v_c1 else operatorset_id end,oprid = case SUBSTR(v_bitmap,1,1) & 2 when 2 then v_c2 else oprid end,state = case SUBSTR(v_bitmap,1,1) & 4 when 4 then v_c3 else state end,flag = case SUBSTR(v_bitmap,1,1) & 8 when 8 then v_c4 else flag end,
      cost = case SUBSTR(v_bitmap,1,1) & 16 when 16 then v_c5 else cost end,quality = case SUBSTR(v_bitmap,1,1) & 32 when 32 then v_c6 else quality end,rating = case SUBSTR(v_bitmap,1,1) & 64 when 64 then v_c7 else rating end,priority = case SUBSTR(v_bitmap,1,1) & 128 when 128 then v_c8 else priority end,comment = case SUBSTR(v_bitmap,2,1) & 1 when 1 then v_c9 else comment end
      where operatorset_id = v_pkc1 and oprid = v_pkc2;
   else
      update r_operatorset set
      state = case SUBSTR(v_bitmap,1,1) & 4 when 4 then v_c3 else state end,flag = case SUBSTR(v_bitmap,1,1) & 8 when 8 then v_c4 else flag end,cost = case SUBSTR(v_bitmap,1,1) & 16 when 16 then v_c5 else cost end,quality = case SUBSTR(v_bitmap,1,1) & 32 when 32 then v_c6 else quality end,
      rating = case SUBSTR(v_bitmap,1,1) & 64 when 64 then v_c7 else rating end,priority = case SUBSTR(v_bitmap,1,1) & 128 when 128 then v_c8 else priority end,comment = case SUBSTR(v_bitmap,2,1) & 1 when 1 then v_c9 else comment end
      where operatorset_id = v_pkc1 and oprid = v_pkc2;
   end if;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSupd_r_Oprprefix_ref` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSupd_r_Oprprefix_ref`(v_c1 VARCHAR(30),v_c2 VARCHAR(10),v_c3 VARCHAR(40),v_c4 VARCHAR(40),v_c5 DATETIME(3),v_c6 INT,v_pkc1 VARCHAR(30),v_pkc2 VARCHAR(10),v_pkc3 VARCHAR(40)
,v_bitmap BINARY(1))
BEGIN

   if SUBSTR(v_bitmap,1,1) & 1 = 1 or SUBSTR(v_bitmap,1,1) & 2 = 2 or SUBSTR(v_bitmap,1,1) & 8 = 8 then
      update r_Oprprefix_ref set
      operator = case SUBSTR(v_bitmap,1,1) & 1 when 1 then v_c1 else operator end,`domain` = case SUBSTR(v_bitmap,1,1) & 2 when 2 then v_c2 else `domain` end,oprfullname = case SUBSTR(v_bitmap,1,1) & 4 when 4 then v_c3 else oprfullname end,prefixcode = case SUBSTR(v_bitmap,1,1) & 8 when 8 then v_c4 else prefixcode end,startdate = case SUBSTR(v_bitmap,1,1) & 16 when 16 then v_c5 else startdate end,`interval` = case SUBSTR(v_bitmap,1,1) & 32 when 32 then v_c6 else `interval` end
      where operator = v_pkc1 and `domain` = v_pkc2 and prefixcode = v_pkc3;
   else
      update r_Oprprefix_ref set
      oprfullname = case SUBSTR(v_bitmap,1,1) & 4 when 4 then v_c3 else oprfullname end,startdate = case SUBSTR(v_bitmap,1,1) & 16 when 16 then v_c5 else startdate end,`interval` = case SUBSTR(v_bitmap,1,1) & 32 when 32 then v_c6 else `interval` end
      where operator = v_pkc1 and `domain` = v_pkc2 and prefixcode = v_pkc3;
   end if;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSupd_r_prefix2` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSupd_r_prefix2`(v_c1 VARCHAR(1),v_c2 VARCHAR(2),v_c3 VARCHAR(17),v_c4 INT,v_c5 VARCHAR(32),v_c6 VARCHAR(8),v_c7 INT,v_c8 VARCHAR(64),v_c9 INT,v_c10 INT,v_c11 INT,v_c12 FLOAT,v_c13 INT,v_c14 FLOAT,v_c15 INT,v_c16 FLOAT,v_c17 INT,v_c18 FLOAT,v_c19 VARCHAR(32),v_pkc1 VARCHAR(17)
,v_bitmap BINARY(3))
BEGIN

   if SUBSTR(v_bitmap,1,1) & 4 = 4 then
      update r_prefix2 set
      state = case SUBSTR(v_bitmap,1,1) & 1 when 1 then v_c1 else state end,pc = case SUBSTR(v_bitmap,1,1) & 2 when 2 then v_c2 else pc end,prefixcode = case SUBSTR(v_bitmap,1,1) & 4 when 4 then v_c3 else prefixcode end,
      prefixlen = case SUBSTR(v_bitmap,1,1) & 8 when 8 then v_c4 else prefixlen end,destcode = case SUBSTR(v_bitmap,1,1) & 16 when 16 then v_c5 else destcode end,prefixreg = case SUBSTR(v_bitmap,1,1) & 32 when 32 then v_c6 else prefixreg end,prefixcls = case SUBSTR(v_bitmap,1,1) & 64 when 64 then v_c7 else prefixcls end,reserved = case SUBSTR(v_bitmap,1,1) & 128 when 128 then v_c8 else reserved end,routecls = case SUBSTR(v_bitmap,2,1) & 1 when 1 then v_c9 else routecls end,interfacecls = case SUBSTR(v_bitmap,2,1) & 2 when 2 then v_c10 else interfacecls end,
      local_mroute = case SUBSTR(v_bitmap,2,1) & 4 when 4 then v_c11 else local_mroute end,local_mcost = case SUBSTR(v_bitmap,2,1) & 8 when 8 then v_c12 else local_mcost end,tollfree_mroute = case SUBSTR(v_bitmap,2,1) & 16 when 16 then v_c13 else tollfree_mroute end,tollfree_mcost = case SUBSTR(v_bitmap,2,1) & 32 when 32 then v_c14 else tollfree_mcost end,
      mobile_mroute = case SUBSTR(v_bitmap,2,1) & 64 when 64 then v_c15 else mobile_mroute end,mobile_mcost = case SUBSTR(v_bitmap,2,1) & 128 when 128 then v_c16 else mobile_mcost end,payphone_mroute = case SUBSTR(v_bitmap,3,1) & 1 when 1 then v_c17 else payphone_mroute end,payphone_mcost = case SUBSTR(v_bitmap,3,1) & 2 when 2 then v_c18 else payphone_mcost end,
      countrycode = case SUBSTR(v_bitmap,3,1) & 4 when 4 then v_c19 else countrycode end
      where prefixcode = v_pkc1;
   else
      update r_prefix2 set
      state = case SUBSTR(v_bitmap,1,1) & 1 when 1 then v_c1 else state end,pc = case SUBSTR(v_bitmap,1,1) & 2 when 2 then v_c2 else pc end,prefixlen = case SUBSTR(v_bitmap,1,1) & 8 when 8 then v_c4 else prefixlen end,
      destcode = case SUBSTR(v_bitmap,1,1) & 16 when 16 then v_c5 else destcode end,prefixreg = case SUBSTR(v_bitmap,1,1) & 32 when 32 then v_c6 else prefixreg end,prefixcls = case SUBSTR(v_bitmap,1,1) & 64 when 64 then v_c7 else prefixcls end,reserved = case SUBSTR(v_bitmap,1,1) & 128 when 128 then v_c8 else reserved end,routecls = case SUBSTR(v_bitmap,2,1) & 1 when 1 then v_c9 else routecls end,interfacecls = case SUBSTR(v_bitmap,2,1) & 2 when 2 then v_c10 else interfacecls end,local_mroute = case SUBSTR(v_bitmap,2,1) & 4 when 4 then v_c11 else local_mroute end,
      local_mcost = case SUBSTR(v_bitmap,2,1) & 8 when 8 then v_c12 else local_mcost end,tollfree_mroute = case SUBSTR(v_bitmap,2,1) & 16 when 16 then v_c13 else tollfree_mroute end,tollfree_mcost = case SUBSTR(v_bitmap,2,1) & 32 when 32 then v_c14 else tollfree_mcost end,mobile_mroute = case SUBSTR(v_bitmap,2,1) & 64 when 64 then v_c15 else mobile_mroute end,
      mobile_mcost = case SUBSTR(v_bitmap,2,1) & 128 when 128 then v_c16 else mobile_mcost end,payphone_mroute = case SUBSTR(v_bitmap,3,1) & 1 when 1 then v_c17 else payphone_mroute end,payphone_mcost = case SUBSTR(v_bitmap,3,1) & 2 when 2 then v_c18 else payphone_mcost end,
      countrycode = case SUBSTR(v_bitmap,3,1) & 4 when 4 then v_c19 else countrycode end
      where prefixcode = v_pkc1;
   end if;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSupd_r_prefix_ref` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSupd_r_prefix_ref`(v_c1 VARCHAR(17),v_c2 VARCHAR(32),v_c3 VARCHAR(32),v_c4 VARCHAR(100),v_c5 INT,v_c6 VARCHAR(100),v_c7 INT,v_pkc1 VARCHAR(17)
,v_bitmap BINARY(1))
BEGIN

   if SUBSTR(v_bitmap,1,1) & 1 = 1 then
      update r_prefix_ref set
      prefixcode = case SUBSTR(v_bitmap,1,1) & 1 when 1 then v_c1 else prefixcode end,Destcode = case SUBSTR(v_bitmap,1,1) & 2 when 2 then v_c2 else Destcode end,oldDestcode = case SUBSTR(v_bitmap,1,1) & 4 when 4 then v_c3 else oldDestcode end,Country = case SUBSTR(v_bitmap,1,1) & 8 when 8 then v_c4 else Country end,Type = case SUBSTR(v_bitmap,1,1) & 16 when 16 then v_c5 else Type end,operator = case SUBSTR(v_bitmap,1,1) & 32 when 32 then v_c6 else operator end,prefixlen = case SUBSTR(v_bitmap,1,1) & 64 when 64 then v_c7 else prefixlen end
      where prefixcode = v_pkc1;
   else
      update r_prefix_ref set
      Destcode = case SUBSTR(v_bitmap,1,1) & 2 when 2 then v_c2 else Destcode end,oldDestcode = case SUBSTR(v_bitmap,1,1) & 4 when 4 then v_c3 else oldDestcode end,Country = case SUBSTR(v_bitmap,1,1) & 8 when 8 then v_c4 else Country end,Type = case SUBSTR(v_bitmap,1,1) & 16 when 16 then v_c5 else Type end,operator = case SUBSTR(v_bitmap,1,1) & 32 when 32 then v_c6 else operator end,prefixlen = case SUBSTR(v_bitmap,1,1) & 64 when 64 then v_c7 else prefixlen end
      where prefixcode = v_pkc1;
   end if;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSupd_r_timecls` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSupd_r_timecls`(v_c1 INT,v_c2 VARCHAR(1),v_c3 INT,v_c4 VARCHAR(1),v_c5 INT,v_c6 INT,v_c7 INT,v_pkc1 INT
,v_bitmap BINARY(1))
BEGIN

   if SUBSTR(v_bitmap,1,1) & 1 = 1 then
      update r_timecls set
      id = case SUBSTR(v_bitmap,1,1) & 1 when 1 then v_c1 else id end,state = case SUBSTR(v_bitmap,1,1) & 2 when 2 then v_c2 else state end,tintid = case SUBSTR(v_bitmap,1,1) & 4 when 4 then v_c3 else tintid end,cls = case SUBSTR(v_bitmap,1,1) & 8 when 8 then v_c4 else cls end,
      dc = case SUBSTR(v_bitmap,1,1) & 16 when 16 then v_c5 else dc end,
      tc = case SUBSTR(v_bitmap,1,1) & 32 when 32 then v_c6 else tc end,
      sc = case SUBSTR(v_bitmap,1,1) & 64 when 64 then v_c7 else sc end
      where id = v_pkc1;
   else
      update r_timecls set
      state = case SUBSTR(v_bitmap,1,1) & 2 when 2 then v_c2 else state end,tintid = case SUBSTR(v_bitmap,1,1) & 4 when 4 then v_c3 else tintid end,cls = case SUBSTR(v_bitmap,1,1) & 8 when 8 then v_c4 else cls end,dc = case SUBSTR(v_bitmap,1,1) & 16 when 16 then v_c5 else dc end,
      tc = case SUBSTR(v_bitmap,1,1) & 32 when 32 then v_c6 else tc end,
      sc = case SUBSTR(v_bitmap,1,1) & 64 when 64 then v_c7 else sc end
      where id = v_pkc1;
   end if;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSupd_r_timecode` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSupd_r_timecode`(v_c1 INT,v_c2 INT,v_c3 INT,v_pkc1 INT
,v_bitmap BINARY(1))
BEGIN

   if SUBSTR(v_bitmap,1,1) & 1 = 1 then
      update r_timecode set
      id = case SUBSTR(v_bitmap,1,1) & 1 when 1 then v_c1 else id end,h1 = case SUBSTR(v_bitmap,1,1) & 2 when 2 then v_c2 else h1 end,
      h2 = case SUBSTR(v_bitmap,1,1) & 4 when 4 then v_c3 else h2 end
      where id = v_pkc1;
   else
      update r_timecode set
      h1 = case SUBSTR(v_bitmap,1,1) & 2 when 2 then v_c2 else h1 end,h2 = case SUBSTR(v_bitmap,1,1) & 4 when 4 then v_c3 else h2 end
      where id = v_pkc1;
   end if;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_MSupd_XlatInterDomain` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_MSupd_XlatInterDomain`(v_c1 VARCHAR(4),v_c2 VARCHAR(4),v_c3 VARCHAR(4),v_c4 VARCHAR(15),v_c5 VARCHAR(20),v_c6 VARCHAR(20),v_c7 INT,v_c8 VARCHAR(64),v_pkc1 VARCHAR(4),v_pkc2 VARCHAR(4),v_pkc3 VARCHAR(4),v_pkc4 VARCHAR(15),v_pkc5 VARCHAR(20)
,v_bitmap BINARY(2))
BEGIN

   if SUBSTR(v_bitmap,1,1) & 1 = 1 or SUBSTR(v_bitmap,1,1) & 2 = 2 or SUBSTR(v_bitmap,1,1) & 4 = 4 or SUBSTR(v_bitmap,1,1) & 8 = 8 or SUBSTR(v_bitmap,1,1) & 16 = 16 then

      update XlatInterDomain set
      sitecode_in = case SUBSTR(v_bitmap,1,1) & 1 when 1 then v_c1 else sitecode_in end,switchcode_in = case SUBSTR(v_bitmap,1,1) & 2 when 2 then v_c2 else switchcode_in end,sitecode_out = case SUBSTR(v_bitmap,1,1) & 4 when 4 then v_c3 else sitecode_out end,operator_out = case SUBSTR(v_bitmap,1,1) & 8 when 8 then v_c4 else operator_out end,prefix = case SUBSTR(v_bitmap,1,1) & 16 when 16 then v_c5 else prefix end,xlatpfx = case SUBSTR(v_bitmap,1,1) & 32 when 32 then v_c6 else xlatpfx end,prefixlen = case SUBSTR(v_bitmap,1,1) & 64 when 64 then v_c7 else prefixlen end,
      comment = case SUBSTR(v_bitmap,1,1) & 128 when 128 then v_c8 else comment end
      where sitecode_in = v_pkc1 and switchcode_in = v_pkc2 and sitecode_out = v_pkc3 and operator_out = v_pkc4 and prefix = v_pkc5;
      if ROW_COUNT() = 0 then
         if v_microsoftversion > 0x07320000 then
            CALL sp_MSreplraiserror(20598);
         end if;
      end if;
   else
      update XlatInterDomain set
      xlatpfx = case SUBSTR(v_bitmap,1,1) & 32 when 32 then v_c6 else xlatpfx end,prefixlen = case SUBSTR(v_bitmap,1,1) & 64 when 64 then v_c7 else prefixlen end,comment = case SUBSTR(v_bitmap,1,1) & 128 when 128 then v_c8 else comment end
      where sitecode_in = v_pkc1 and switchcode_in = v_pkc2 and sitecode_out = v_pkc3 and operator_out = v_pkc4 and prefix = v_pkc5;
      if ROW_COUNT() = 0 then
         if v_microsoftversion > 0x07320000 then
            CALL sp_MSreplraiserror(20598);
         end if;
      end if;
   end if;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `testblah` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `testblah`()
begin


   insert into blahblah(`date`, comment) values(CURRENT_TIMESTAMP, 'blahblahblah');
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `testCallOut` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `testCallOut`(v_sitecode VARCHAR(3),  
v_operator VARCHAR(32),  
v_prefix  VARCHAR(32),  
v_switchcode VARCHAR(10),  
v_interface VARCHAR(20))
begin

   
   DECLARE v_strquery VARCHAR(8000);
   set v_strquery =CONCAT( 'select sitecode,switchcode,operator,interface,prefix,xlatpfx XlatPrefix,isactive status from   
  callout where sitecode = ''', v_sitecode, ''' and operator = ''', v_operator,  '''');  
   if v_prefix is not null then
      set v_strquery =CONCAT( v_strquery, ' and prefix = left(''', v_prefix,  ''', CHAR_LENGTH(prefix))');
   end if;  
   if v_switchcode is not null then
      set v_strquery =CONCAT( v_strquery, ' and switchcode = ''', v_switchcode,  '''');
   end if;  
   if v_interface is not null then
      set v_strquery =CONCAT( v_strquery, ' and interface = ''', v_interface,  '''');
   end if;  
   set v_strquery =CONCAT( v_strquery,  ' order by sitecode,operator,switchcode,interface,prefix desc');  
   SET @SWV_Stmt = v_strquery;
   PREPARE SWT_Stmt FROM @SWV_Stmt;
   EXECUTE SWT_Stmt;
   DEALLOCATE PREPARE SWT_Stmt;  
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `upd_monitor` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `upd_monitor`(v_cdate VARCHAR(10),
 v_swc VARCHAR(5),
 v_chnl VARCHAR(8),
 v_tt INT,
 v_costb FLOAT)
begin


   update monitor set talktime_sec = talktime_sec+v_tt,talktime_min = talktime_min+round(v_tt/60+0.5,0),
   costb = costb+v_costb
   where calldate   = v_cdate
   and   switchcode = v_swc
   and   channel    = v_chnl;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `upd_monitor_id` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `upd_monitor_id`(v_id INT,
 v_tt INT,
 v_costb FLOAT)
begin


   update monitor set talktime_sec = talktime_sec+v_tt,talktime_min = talktime_min+round(v_tt/60+0.5,0),
   costb = costb+v_costb
   where id = v_id; 
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `up_insert_india_did_route` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `up_insert_india_did_route`(
 p_didfrom varchar(30),
 p_didto varchar(30),
 p_group varchar(20),
 p_cost float
 )
sp_return:begin
 
     if ifnull(p_didfrom,'')='' then
 		select -1 as errcode , 'DID is mandatory';
         leave sp_return;
     end if;
     
     if ifnull(p_didto,'')='' then
		set p_didto = p_didfrom;
     End if;
 
         while p_didfrom <= p_didto do
 			
             insert into india_did_route(did, `group`, cost) 
             values(p_didfrom,p_group, p_cost);
             
 			set p_didfrom = p_didfrom + 1;
         End while;

     select 0 as errcode , 'DID Inserted';
     
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `view_monitor_all` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `view_monitor_all`(v_key VARCHAR(25))
begin


   IF v_key is null then
      set v_key = '';
   END IF;
   if v_key = 'channel' then
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select calldate,switchcode,channel,sum(talktime_sec) as tt_sec ,sum(talktime_min) as tt_min , cast(sum(costb) as DECIMAL(10,2)) as cost_b from monitor 
      group by calldate,switchcode,channel
      order by calldate desc,cost_b desc;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   else
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select calldate,operator,sum(talktime_sec) as tt_sec ,sum(talktime_min) as tt_min , cast(sum(costb) as DECIMAL(10,2)) as cost_b from monitor 
      group by calldate,operator
      order by calldate desc,cost_b desc;
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
   end if;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `xaccount_expiry` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `xaccount_expiry`(v_mm VARCHAR(2), v_yyyy VARCHAR(4))
begin


   DECLARE v_firstdate DATETIME(3);
   DECLARE v_lastdate DATETIME(3);
   DECLARE v_somesql VARCHAR(1000);
   DECLARE v_theaccexp VARCHAR(64);
   DECLARE v_theaccexpwas VARCHAR(64);



   set v_firstdate = cast(CONCAT_WS('',v_yyyy,'-',v_mm,'-01') as DATETIME(3));
   set v_lastdate = TIMESTAMPADD(SECOND,-1,TIMESTAMPADD(MONTH,1,v_firstdate));
	
	
   set v_theaccexp = CONCAT_WS('','_',v_yyyy,v_mm,'AccountExpiry');

   if exists(select * from sysobjects where name = v_theaccexp) then
	
      SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
      select   CONCAT_WS('',v_theaccexp,IFNULL(char(ascii(max(SWF_SUBSTRING(name, CHAR_LENGTH(v_theaccexp)+1, CHAR_LENGTH(name))))+1),'a')) INTO v_theaccexpwas from sysobjects  where type = 'u' and name like CONCAT_WS('',v_theaccexp,'%');
      SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
      set v_somesql =CONCAT( 'CALL sp_rename ', v_theaccexp, ', ',  v_theaccexpwas,  ') ');
	
      SET @SWV_Stmt = v_somesql;
      PREPARE SWT_Stmt FROM @SWV_Stmt;
      EXECUTE SWT_Stmt;
      DEALLOCATE PREPARE SWT_Stmt;
   end if;
	
   set v_somesql =CONCAT( 'declare @firstdate DATETIME(3),@lastdate DATETIME(3) set @firstdate = cast(''', v_yyyy, '-', v_mm, '-01'' as datetime)
	set @lastdate = dateadd(ss, -1, dateadd(m, 1, @firstdate) )

	select telcocode, custcode, batchcode, status, count(telcocode) nbofcards, sum(balance) balance
	into
		', v_theaccexp,  '
	from 
		account t1, x_firstusg t2 
	where
		t1.balance+t1.totalcons between t2.lowvalue and t2.highvalue
		and TIMESTAMPADD(DAY,t2.daysvalid,t1.firstusg) between @firstdate and @lastdate
	group by telcocode,custcode,batchcode,status

	');
	
   SET @SWV_Stmt = v_somesql;
   PREPARE SWT_Stmt FROM @SWV_Stmt;
   SET @firstdate = v_firstdate;
   SET @lastdate = v_lastdate;
   SET @firstdate = v_firstdate;
   SET @lastdate = v_lastdate;
   SET @firstdate = v_firstdate;
   SET @firstdate = v_firstdate;
   SET @lastdate = v_lastdate;
   EXECUTE SWT_Stmt;
   DEALLOCATE PREPARE SWT_Stmt;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `xcls11_get_route` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `xcls11_get_route`(v_pDDI            VARCHAR(32)
   ,v_pDate          DATETIME(3)
   ,v_pSrcInt        VARCHAR(7)    
   ,v_pSrcIntGroup   VARCHAR(64)   
   ,v_pSrcIntDom     VARCHAR(64)   
   ,v_pCLI           VARCHAR(32))
begin

   
   IF v_pCLI is null then
      set v_pCLI = '';
   END IF;
   SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
   select isactive, routecls, dprefixcode prefixcode, universe, `domain`, pdomain, `group`, interface, userinfo, hint, timecls, priority, cost, flag
   from(select x.isactive, x.routecls, x.cprefixcode cli, x.dprefixcode, ty.universe, ty.`domain` `domain`, ty.pdomain, ty.`group` `group`, ty.name interface,
   ty.hint, ty.userinfo, x.cls timecls, x.priority, x.cost, x.flag
      from(select a.* from rs02_route a 
         where (v_pCLI = '' or a.cprefixcode = v_pCLI)
         and (a.dpc = SUBSTR(v_pDDI,1,2))
         and a.dprefixcode =(select  prefixcode
            from r_prefix1 
            where (pc = SUBSTR(v_pDDI,1,2))
            and v_pDDI like CONCAT(prefixcode,'%')
            order by prefixlen desc LIMIT 1)
         and sc = 0) x, r_interface ty,
   r_domain d,
   r_timecode t, r_daycode td,
   r_info curr 
      where x.tintid = ty.id and ty.state = 'I'
      and (v_pSrcInt = '' or (x.sintid = 0) or (x.sintid =(select  id from r_interface  where name = v_pSrcInt and `domain` = v_pSrcIntDom LIMIT 1)))
      and ty.`domain` = d.name
      and x.dc = td.id
      and td.d1 <= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
      and td.d2 >= 1+(v_datefirst+DAYOFWEEK(v_pDate) -2)%7
      and x.tc = t.id
      and t.h1 <=(((24+EXTRACT(HOUR FROM v_pDate)+d.timezone -curr.timezone)%24)*100+EXTRACT(MONTH FROM v_pDate))
      and t.h2 >(((24+EXTRACT(HOUR FROM v_pDate)+d.timezone -curr.timezone)%24)*100+EXTRACT(MONTH FROM v_pDate))) z
   order by z.priority;
   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-21  9:52:59
