-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: esp_mcm
-- ------------------------------------------------------
-- Server version	8.0.44-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `esp_mcm`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `esp_mcm` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `esp_mcm`;

--
-- Table structure for table `MVNO_HUBSPOT_DND_REGISTER`
--

DROP TABLE IF EXISTS `MVNO_HUBSPOT_DND_REGISTER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MVNO_HUBSPOT_DND_REGISTER` (
  `mobileno` varchar(20) NOT NULL,
  `iccid` varchar(20) DEFAULT NULL,
  `Is_stop_mark_email` int DEFAULT NULL,
  `Is_stop_mark_sms` int DEFAULT NULL,
  `Is_stop_all_email` int DEFAULT NULL,
  `Is_remove_data` int DEFAULT NULL,
  `create_date` datetime(3) DEFAULT NULL,
  `create_by` varchar(150) DEFAULT NULL,
  `last_update` datetime(3) DEFAULT NULL,
  `updated_by` varchar(250) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `mvno_bun_act_register`
--

DROP TABLE IF EXISTS `mvno_bun_act_register`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mvno_bun_act_register` (
  `mobileno` varchar(20) NOT NULL,
  `iccid` varchar(20) DEFAULT NULL,
  `status` int DEFAULT NULL,
  `number_of_bundles_purchased` int DEFAULT NULL,
  `number_of_active_bundles` int DEFAULT NULL,
  `first_bundle_name` varchar(150) DEFAULT NULL,
  `first_time_purchased_bundle_category` varchar(150) DEFAULT NULL,
  `first_bundle_purchase_amount` float DEFAULT NULL,
  `first_bundle_purchase_date` datetime(3) DEFAULT NULL,
  `first_bundle_purchase_method` varchar(150) DEFAULT NULL,
  `first_time_bundle_purchase_payment_method_used` varchar(150) DEFAULT NULL,
  `first_bundle_status` varchar(150) DEFAULT NULL,
  `latest_bundle_renewal_attempt_date` datetime(3) DEFAULT NULL,
  `latest_bundle_renewal_attempt_failure_reason` varchar(150) DEFAULT NULL,
  `latest_bundle_renewal_attempt_status` varchar(150) DEFAULT NULL,
  `latest_bundle_name_being_purchased` varchar(150) DEFAULT NULL,
  `National_addon_Bundle_national_mins_total_allowance` float DEFAULT NULL,
  `National_Bundle_data_allowance` float DEFAULT NULL,
  `National_Bundle_data_used_allowance_percentage` float DEFAULT NULL,
  `National_Bundle_international_mins_total_allowance` float DEFAULT NULL,
  `National_Bundle_international_mins_used_allowance_percentage` float DEFAULT NULL,
  `National_Bundle_national_mins_total_allowance` float DEFAULT NULL,
  `National_Bundle_national_mins_used_allowance_percentage` float DEFAULT NULL,
  `National_Bundle_sms_allowance` float DEFAULT NULL,
  `National_Bundle_sms_used_allowance_percentage` float DEFAULT NULL,
  `National_Bundle_vectone_to_vectone_minutes_allowance` float DEFAULT NULL,
  `AIO_Bundle_data_allowance` float DEFAULT NULL,
  `AIO_Bundle_data_used_allowance_percentage` float DEFAULT NULL,
  `AIO_Bundle_international_mins_total_allowance` float DEFAULT NULL,
  `AIO_Bundle_international_mins_used_allowance_percentage` float DEFAULT NULL,
  `AIO_Bundle_national_mins_total_allowance` float DEFAULT NULL,
  `AIO_Bundle_national_mins_used_allowance_percentage` float DEFAULT NULL,
  `AIO_Bundle_sms_allowance` float DEFAULT NULL,
  `AIO_Bundle_sms_used_allowance_percentage` float DEFAULT NULL,
  `AIO_Bundle_vectone_to_vectone_minutes_allowance` float DEFAULT NULL,
  `AIO_Bundle_vectone_to_vectone_minutes_used_allowance_percentage` float DEFAULT NULL,
  `current_addon_Data_bundle_id` int DEFAULT NULL,
  `current_addon_Data_bundle_name` varchar(150) DEFAULT NULL,
  `current_addon_international_bundle_id` int DEFAULT NULL,
  `current_addon_international_bundle_name` varchar(150) DEFAULT NULL,
  `current_addon_national_bundle_id` int DEFAULT NULL,
  `current_addon_national_bundle_name` varchar(150) DEFAULT NULL,
  `current_AIO_bundle_id` int DEFAULT NULL,
  `current_AIO_bundle_name` varchar(150) DEFAULT NULL,
  `current_AIO_bundle_renewal_date` datetime(3) DEFAULT NULL,
  `current_Data_bundle_id` int DEFAULT NULL,
  `current_Data_bundle_name` varchar(150) DEFAULT NULL,
  `current_data_bundle_renewal_date` datetime(3) DEFAULT NULL,
  `current_international_bundle_id` int DEFAULT NULL,
  `current_international_bundle_name` varchar(150) DEFAULT NULL,
  `current_International_bundle_renewal_date` datetime(3) DEFAULT NULL,
  `current_national_bundle_id` int DEFAULT NULL,
  `current_national_bundle_name` varchar(150) DEFAULT NULL,
  `current_national_bundle_renewal_date` datetime(3) DEFAULT NULL,
  `current_SIMONLY_bundle_id` int DEFAULT NULL,
  `current_SIMONLY_bundle_name` varchar(150) DEFAULT NULL,
  `Data_addon_Bundle_data_allowance` float DEFAULT NULL,
  `Data_addon_Bundle_data_used_allowance_percentage` float DEFAULT NULL,
  `Data_addon_Bundle_international_mins_used_allowance_percentage` float DEFAULT NULL,
  `Data_Bundle_data_allowance` float DEFAULT NULL,
  `Data_Bundle_data_used_allowance_percentage` float DEFAULT NULL,
  `Data_Bundle_international_mins_total_allowance` float DEFAULT NULL,
  `Data_Bundle_international_mins_used_allowance_percentage` float DEFAULT NULL,
  `Data_Bundle_national_mins_total_allowance` float DEFAULT NULL,
  `Data_Bundle_national_mins_used_allowance_percentage` float DEFAULT NULL,
  `Data_Bundle_sms_allowance` float DEFAULT NULL,
  `Data_Bundle_sms_used_allowance_percentage` float DEFAULT NULL,
  `Data_Bundle_vectone_to_vectone_minutes_allowance` float DEFAULT NULL,
  `Data_Bundle_vectone_to_vectone_minutes_used_allowance_percentage` float DEFAULT NULL,
  `International_addon_Bundle_international_mins_total_allowance` float DEFAULT NULL,
  `International_Bundle_data_allowance` float DEFAULT NULL,
  `International_Bundle_data_used_allowance_percentage` float DEFAULT NULL,
  `International_Bundle_international_mins_total_allowance` float DEFAULT NULL,
  `International_Bundle_national_mins_total_allowance` float DEFAULT NULL,
  `International_Bundle_national_mins_used_allowance_percentage` float DEFAULT NULL,
  `International_Bundle_sms_allowance` float DEFAULT NULL,
  `International_Bundle_sms_used_allowance_percentage` float DEFAULT NULL,
  `International_Bundle_vectone_to_vectone_minutes_allowance` float DEFAULT NULL,
  `latest_sim_with_bundle_name_being_purchased` varchar(150) DEFAULT NULL,
  `latest_sim_only_with_bundle_name_being_purchased` varchar(150) DEFAULT NULL,
  `National_addon_Bundle_national_mins_used_allowance_percentage` float DEFAULT NULL,
  `revenue_from_bundle` float DEFAULT NULL,
  `simonly_Bundle_data_allowance` float DEFAULT NULL,
  `simonly_Bundle_data_used_allowance_percentage` float DEFAULT NULL,
  `simonly_Bundle_international_mins_total_allowance` float DEFAULT NULL,
  `simonly_Bundle_international_mins_used_allowance_percentage` float DEFAULT NULL,
  `simonly_Bundle_national_mins_total_allowance` float DEFAULT NULL,
  `simonly_Bundle_national_mins_used_allowance_percentage` float DEFAULT NULL,
  `simonly_Bundle_sms_allowance` float DEFAULT NULL,
  `simonly_Bundle_sms_used_allowance_percentage` float DEFAULT NULL,
  `simonly_Bundle_vectone_to_vectone_minutes_allowance` float DEFAULT NULL,
  `current_national_bundle_most_international_mins_used_country` float DEFAULT NULL,
  `current_AIO_bundle_most_international_mins_used_country` float DEFAULT NULL,
  `current_SIMONly_bundle_most_international_mins_used_country` float DEFAULT NULL,
  `National_Bundle_most_international_mins_used_country_percentage` float DEFAULT NULL,
  `AIO_Bundle_most_international_mins_used_country_percentage` float DEFAULT NULL,
  `Data_Bundle_most_international_mins_used_country` float DEFAULT NULL,
  `Data_Bundle_most_international_mins_used_country_percentage` float DEFAULT NULL,
  `current_SIMONly_bundle_most_international_mins_used_country_per` float DEFAULT NULL,
  `previously_subscribed_for_country_specific_bundles_` varchar(150) DEFAULT NULL,
  `most_subscribed_country_specific_bundle_name` varchar(150) DEFAULT NULL,
  `Has_active_national_bundle` varchar(150) DEFAULT NULL,
  `Has_active_AIO_bundle` varchar(150) DEFAULT NULL,
  `Has_active_International_bundle` varchar(150) DEFAULT NULL,
  `Has_active_data_bundle` varchar(150) DEFAULT NULL,
  `Has_active_roaming_bundle` varchar(150) DEFAULT NULL,
  `current_roam_bun_name` varchar(250) DEFAULT NULL,
  `current_roam_bun_id` int DEFAULT NULL,
  `current_roam_bun_startdate` datetime(3) DEFAULT NULL,
  `current_roam_bun_enddate` datetime(3) DEFAULT NULL,
  `current_roam_bun_renewal_date` datetime(3) DEFAULT NULL,
  `roam_bun_data_allowance` float DEFAULT NULL,
  `roam_bun_data_used_allowance_percentage` float DEFAULT NULL,
  `roam_bun_national_mins_total_allowance` float DEFAULT NULL,
  `roam_bun_national_mins_used_allowance_percentage` float DEFAULT NULL,
  `roam_bun_international_mins_total_allowance` float DEFAULT NULL,
  `roam_bun_international_mins_used_allowance_percentage` float DEFAULT NULL,
  `roam_bun_sms_allowance` float DEFAULT NULL,
  `roam_bun_sms_used_allowance_percentage` float DEFAULT NULL,
  `roam_bun_most_international_mins_used_country` float DEFAULT NULL,
  `roam_bun_most_international_mins_used_country_percentage` float DEFAULT NULL,
  `roam_bun_vectone_to_vectone_minutes_allowance` float DEFAULT NULL,
  `roam_bun_vectone_to_vectone_minutes_used_allowance_percentage` float DEFAULT NULL,
  `latest_bundle_id_being_purchased` int DEFAULT NULL,
  `Has_active_SIMONLY_bundle` varchar(150) DEFAULT NULL,
  `current_SIMONLY_bundle_renewal_date` datetime(3) DEFAULT NULL,
  `latest_bundle_purchase_date` datetime(3) DEFAULT NULL,
  `latest_bundle_payment_mode` varchar(150) DEFAULT NULL,
  `latest_bundle_payment_method` varchar(150) DEFAULT NULL,
  `latest_bundle_payment_reference_number` varchar(150) DEFAULT NULL,
  `current_addon_Data_enddate` datetime(3) DEFAULT NULL,
  `current_addon_Data_startdate` datetime(3) DEFAULT NULL,
  `current_addon_international_enddate` datetime(3) DEFAULT NULL,
  `current_addon_international_startdate` datetime(3) DEFAULT NULL,
  `current_addon_national_enddate` datetime(3) DEFAULT NULL,
  `current_addon_national_startdate` datetime(3) DEFAULT NULL,
  `current_AIO_enddate` datetime(3) DEFAULT NULL,
  `current_AIO_startdate` datetime(3) DEFAULT NULL,
  `current_Data_enddate` datetime(3) DEFAULT NULL,
  `current_Data_startdate` datetime(3) DEFAULT NULL,
  `current_international_enddate` datetime(3) DEFAULT NULL,
  `current_international_startdate` datetime(3) DEFAULT NULL,
  `current_national_enddate` datetime(3) DEFAULT NULL,
  `current_national_startdate` datetime(3) DEFAULT NULL,
  `current_SIMONLY_enddate` datetime(3) DEFAULT NULL,
  `current_SIMONLY_startdate` datetime(3) DEFAULT NULL,
  `current_data_roaming_addon_name` varchar(150) DEFAULT NULL,
  `current_data_roaming_addon_id` int DEFAULT NULL,
  `current_data_roaming_addon_startdate` datetime(3) DEFAULT NULL,
  `current_data_roaming_addon_enddate` datetime(3) DEFAULT NULL,
  `data_roaming_addon_data_total_allowance` float DEFAULT NULL,
  `data_roaming_addon_data_used_allowance_percentage` float DEFAULT NULL,
  `number_of_addons_purchased` int DEFAULT NULL,
  `number_of_active_addons` int DEFAULT NULL,
  `latest_addon_being_purchased` varchar(150) DEFAULT NULL,
  `Has_active_national_addon` varchar(150) DEFAULT NULL,
  `Has_active_international_addon` varchar(150) DEFAULT NULL,
  `Has_active_data_roaming_addon` varchar(150) DEFAULT NULL,
  `Has_active_data_addon` varchar(150) DEFAULT NULL,
  `roaming_status` varchar(150) DEFAULT NULL,
  `auto_renewal` varchar(150) DEFAULT NULL,
  `auto_renewal_disable_by` varchar(150) DEFAULT NULL,
  `auto_renewal_disable_date` datetime(3) DEFAULT NULL,
  `auto_renewal_enable_by` varchar(150) DEFAULT NULL,
  `auto_renewal_enable_date` datetime(3) DEFAULT NULL,
  `nat_call_package_id` int DEFAULT NULL,
  `int_call_package_id` int DEFAULT NULL,
  `data_package_id` int DEFAULT NULL,
  `sms_package_id` int DEFAULT NULL,
  `v2v_pack_id` int DEFAULT NULL,
  `hubspot_contact_id` varchar(20) DEFAULT NULL,
  `nat_bun_data_package_Id` int DEFAULT NULL,
  `nat_bun_sms_package_Id` int DEFAULT NULL,
  `nat_bun_v2v_package_Id` int DEFAULT NULL,
  `inter_bun_nat_package_Id` int DEFAULT NULL,
  `inter_bun_sms_package_Id` int DEFAULT NULL,
  `inter_bun_data_package_Id` int DEFAULT NULL,
  `inter_bun_v2v_package_Id` int DEFAULT NULL,
  `AIO_bun_nat_package_Id` int DEFAULT NULL,
  `AIO_bun_inter_package_Id` int DEFAULT NULL,
  `AIO_bun_sms_package_Id` int DEFAULT NULL,
  `AIO_bun_data_package_Id` int DEFAULT NULL,
  `AIO_bun_v2v_package_Id` int DEFAULT NULL,
  `nat_bun_inter_package_Id` int DEFAULT NULL,
  `v2v_sms_pack_id` int DEFAULT NULL,
  `v2v_sms_pack_assigned` float DEFAULT NULL,
  `v2v_sms_pack_used` float DEFAULT NULL,
  `customer_type` varchar(25) DEFAULT NULL,
  `free_credit` float DEFAULT NULL,
  `Has_LLOM` varchar(20) DEFAULT NULL,
  `has_Vectone_Xtra` varchar(25) DEFAULT NULL,
  `current_balance` float DEFAULT NULL,
  `create_modify_date` datetime(3) DEFAULT NULL,
  `llom_exp_date` datetime(3) DEFAULT NULL,
  `is_smart_rate` int DEFAULT NULL,
  `smart_rate_end_date` datetime(3) DEFAULT NULL,
  `simonly_excessusage` varchar(50) DEFAULT NULL,
  `landlinenumber` varchar(25) DEFAULT NULL,
  `existing_customer_my_vectone_charge_back` varchar(50) DEFAULT NULL,
  `types_of_bundle` varchar(250) DEFAULT NULL,
  `cc_no` varchar(4) DEFAULT NULL,
  `cc_no_expirydate` varchar(10) DEFAULT NULL,
  `cc_card_type` varchar(100) DEFAULT NULL,
  `plan_upgrade` varchar(50) DEFAULT NULL,
  `plan_change_date` datetime(3) DEFAULT NULL,
  `plan_downgrade` varchar(50) DEFAULT NULL,
  `change_plan_requested_name` varchar(250) DEFAULT NULL,
  `latest_paym_payment_status` varchar(250) DEFAULT NULL,
  `latest_paym_payment_date` datetime(3) DEFAULT NULL,
  `latest_purchase_attempt_payment_method` varchar(250) DEFAULT NULL,
  `Data_Rollover` varchar(250) DEFAULT NULL,
  `Rollover_Data_allowance` float DEFAULT NULL,
  `simonly_call_allow_used_per` float DEFAULT NULL,
  `simonly_Data_allow_used_per` float DEFAULT NULL,
  `purchased_addon` varchar(250) DEFAULT NULL,
  `addon_enddate` datetime(3) DEFAULT NULL,
  `Intl_addon_Bundle_intl_mins_used_allowance_percentage` float DEFAULT NULL,
  `Intl_Bundle_intl_mins_used_allowance_percentage` float DEFAULT NULL,
  `Intl_Bundle_vectone_to_vectone_minutes_used_allowance_percentage` float DEFAULT NULL,
  `Natl_Bundle_vectone_to_vectone_minutes_used_allowance_percentage` float DEFAULT NULL,
  `simonly_Bundle_vec_to_vec_minutes_used_allowance_percentage` float DEFAULT NULL,
  `current_intl_bundle_most_international_mins_used_country` float DEFAULT NULL,
  `Intl_Bundle_most_international_mins_used_country_percentage` float DEFAULT NULL,
  `roaming_Bundle_vect_to_vect_minutes_used_allowance_percentage` float DEFAULT NULL,
  PRIMARY KEY (`mobileno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `temp_exra_col_hubspot`
--

DROP TABLE IF EXISTS `temp_exra_col_hubspot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `temp_exra_col_hubspot` (
  `mobileno` varchar(20) DEFAULT NULL,
  `iccid` varchar(20) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `freesimid` int DEFAULT NULL,
  `custcode` varchar(8) DEFAULT NULL,
  `batchcode` int DEFAULT NULL,
  `serialcode` int DEFAULT NULL,
  `email_verification_status` varchar(50) DEFAULT NULL,
  `Country` varchar(100) DEFAULT NULL,
  `country_code` varchar(10) DEFAULT NULL,
  `alternate_email_id` varchar(150) DEFAULT NULL,
  `first_referral_date` datetime(3) DEFAULT NULL,
  `last_referral_date` datetime(3) DEFAULT NULL,
  `number_of_referrals_made` int DEFAULT NULL,
  `referred_someone` varchar(10) DEFAULT NULL,
  `referred_someone_first_time` varchar(10) DEFAULT NULL,
  `referee_subscriber_id` int DEFAULT NULL,
  `portin_current_network_name` varchar(50) DEFAULT NULL,
  `portin_request_completion_status` varchar(200) DEFAULT NULL,
  `portin_request_failure_reason` varchar(200) DEFAULT NULL,
  `portout_network_name` varchar(100) DEFAULT NULL,
  `reason_for_portout` varchar(50) DEFAULT NULL,
  `latest_purchase_attempt_payment_mode` varchar(100) DEFAULT NULL,
  `total_purchase_amount_of_the_customer` double DEFAULT NULL,
  `avg_customer_wait_time_between_purchases` int DEFAULT NULL,
  `latest_purchase_attempt_date` datetime(3) DEFAULT NULL,
  `latest_purchase_attempt_payment_status` varchar(10) DEFAULT NULL,
  `latest_purchase_attempt_payment_method` varchar(100) DEFAULT NULL,
  `latest_product_being_purchased` varchar(20) DEFAULT NULL,
  `latest_attempt_payment_reference_number` varchar(100) DEFAULT NULL,
  `latest_payment_attempt_failure_reason` varchar(500) DEFAULT NULL,
  `hs_analytics_source` varchar(250) DEFAULT NULL,
  `hs_language` varchar(10) DEFAULT NULL,
  `lifecyclestage` varchar(50) DEFAULT NULL,
  `Registered_to_myaccount` varchar(10) DEFAULT NULL,
  `Smart_Rates_user` varchar(25) DEFAULT NULL,
  `lastcalldate` datetime(3) DEFAULT NULL,
  `lastsmsdate` datetime(3) DEFAULT NULL,
  `lastgprsdate` datetime(3) DEFAULT NULL,
  `latest_buying_stage` varchar(250) DEFAULT NULL,
  `hs_lead_status` varchar(100) DEFAULT NULL,
  `arpu` varchar(150) DEFAULT NULL,
  `no_of_times_top_up_20_and_above` int DEFAULT NULL,
  `first_topup_status` varchar(5) DEFAULT NULL,
  `International_Topup_Country_Name` varchar(15) DEFAULT NULL,
  `latest_topup_amount_being_purchased` double DEFAULT NULL,
  `frequent_topup_method` varchar(25) DEFAULT NULL,
  `Latest_SIM_with_Topup_Amount_Being_Purchased` float DEFAULT NULL,
  `sim_country` varchar(10) DEFAULT NULL,
  `sim_order_status` varchar(15) DEFAULT NULL,
  `SIM_ordered_by` varchar(10) DEFAULT NULL,
  `Latest_Preloaded_SIM_Amount_Being_Purchased` varchar(155) DEFAULT NULL,
  `latest_topup_payment_method_used` varchar(50) DEFAULT NULL,
  `latest_bundle_payment_mode` varchar(50) DEFAULT NULL,
  `revenue_from_topup` float DEFAULT NULL,
  `latest_topup_amount` float DEFAULT NULL,
  `latest_topup_date` datetime(3) DEFAULT NULL,
  `latest_topup_method_used` varchar(20) DEFAULT NULL,
  `latest_bundle_purchase_payment_method_used` varchar(50) DEFAULT NULL,
  `latest_bundle_payment_reference_number` varchar(50) DEFAULT NULL,
  `latest_bundle_name_being_purchased` varchar(50) DEFAULT NULL,
  `latest_bundle_id_being_purchased` varchar(20) DEFAULT NULL,
  `latest_bundle_name_being_purchased_date` datetime(3) DEFAULT NULL,
  `count_top_ups_made` int DEFAULT NULL,
  `count_top_ups_made_in_90days` int DEFAULT NULL,
  `Revenue_from_bundle` float DEFAULT NULL,
  `create_modify_date` datetime(3) DEFAULT NULL,
  `idpk` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idpk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `topup_activity_register`
--

DROP TABLE IF EXISTS `topup_activity_register`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `topup_activity_register` (
  `mobileno` varchar(20) NOT NULL,
  `auto_topup` int DEFAULT NULL,
  `auto_topup_disable_by` varchar(150) DEFAULT NULL,
  `auto_topup_disable_date` datetime(3) DEFAULT NULL,
  `auto_topup_enable_by` varchar(150) DEFAULT NULL,
  `auto_topup_enable_date` datetime(3) DEFAULT NULL,
  `no_of_topup` int DEFAULT NULL,
  `first_topup_amount` float DEFAULT NULL,
  `first_topup_method_used` varchar(150) DEFAULT NULL,
  `first_time_topup_date` datetime(3) DEFAULT NULL,
  `latest_auto_topup_attempt_date` datetime(3) DEFAULT NULL,
  `latest_auto_topup_attempt_failure_reason` varchar(100) DEFAULT NULL,
  `latest_auto_topup_attempt_status` varchar(150) DEFAULT NULL,
  `status` int DEFAULT NULL,
  `insert_date` datetime(3) DEFAULT NULL,
  `last_topup_date` datetime(3) DEFAULT NULL,
  `latest_topup_amount` float DEFAULT NULL,
  `latest_topup_type` varchar(250) DEFAULT NULL,
  `last_topup_vou_method` varchar(100) DEFAULT NULL,
  `lat_topup_method_used` varchar(100) DEFAULT NULL,
  `last_topup_payment_ref` varchar(100) DEFAULT NULL,
  `total_revenue` float DEFAULT NULL,
  `int_topup_network_name` varchar(100) DEFAULT NULL,
  `lat_int_topup_amount` float DEFAULT NULL,
  `lat_int_topup_comp_status` varchar(100) DEFAULT NULL,
  `no_int_topup_made` int DEFAULT NULL,
  `int_total_topup_amount` float DEFAULT NULL,
  `int_topup_failure_reason` varchar(500) DEFAULT NULL,
  `iccid` varchar(20) DEFAULT NULL,
  `sim_login_date` datetime(3) DEFAULT NULL,
  `sim_dispatch_date` datetime(3) DEFAULT NULL,
  `sim_last_login_date` datetime(3) DEFAULT NULL,
  `sim_inserted` varchar(10) DEFAULT NULL,
  `sim_type` varchar(250) DEFAULT NULL,
  `freesimid` int DEFAULT NULL,
  `subscriberid` int DEFAULT NULL,
  `firstname` varchar(150) DEFAULT NULL,
  `lastname` varchar(150) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `houseno` varchar(100) DEFAULT NULL,
  `address1` text,
  `address2` text,
  `city` varchar(150) DEFAULT NULL,
  `state` varchar(250) DEFAULT NULL,
  `postcode` varchar(100) DEFAULT NULL,
  `dob` datetime(3) DEFAULT NULL,
  `hubspot_contact_id` varchar(20) DEFAULT NULL,
  `mobilephone` varchar(50) DEFAULT NULL,
  `ordersim_url` varchar(1000) DEFAULT NULL,
  `email_verification_status` varchar(50) DEFAULT NULL,
  `Country` varchar(100) DEFAULT NULL,
  `country_code` varchar(10) DEFAULT NULL,
  `alternate_email_id` varchar(150) DEFAULT NULL,
  `first_referral_date` datetime(3) DEFAULT NULL,
  `last_referral_date` datetime(3) DEFAULT NULL,
  `number_of_referrals_made` int DEFAULT NULL,
  `referred_someone` varchar(10) DEFAULT NULL,
  `referred_someone_first_time` varchar(10) DEFAULT NULL,
  `referee_subscriber_id` int DEFAULT NULL,
  `portin_current_network_name` varchar(50) DEFAULT NULL,
  `portin_request_completion_status` varchar(200) DEFAULT NULL,
  `portin_request_failure_reason` varchar(200) DEFAULT NULL,
  `portout_network_name` varchar(100) DEFAULT NULL,
  `reason_for_portout` varchar(50) DEFAULT NULL,
  `latest_purchase_attempt_payment_mode` varchar(100) DEFAULT NULL,
  `total_purchase_amount_of_the_customer` float DEFAULT NULL,
  `avg_customer_wait_time_between_purchases` int DEFAULT NULL,
  `latest_purchase_attempt_date` datetime(3) DEFAULT NULL,
  `latest_purchase_attempt_payment_status` varchar(10) DEFAULT NULL,
  `latest_purchase_attempt_payment_method` varchar(100) DEFAULT NULL,
  `latest_product_being_purchased` varchar(20) DEFAULT NULL,
  `latest_attempt_payment_reference_number` varchar(100) DEFAULT NULL,
  `latest_payment_attempt_failure_reason` varchar(500) DEFAULT NULL,
  `hs_analytics_source` varchar(250) DEFAULT NULL,
  `hs_language` varchar(10) DEFAULT NULL,
  `lifecyclestage` varchar(50) DEFAULT NULL,
  `Registered_to_myaccount` varchar(10) DEFAULT NULL,
  `Smart_Rates_user` varchar(25) DEFAULT NULL,
  `lastcalldate` datetime(3) DEFAULT NULL,
  `lastsmsdate` datetime(3) DEFAULT NULL,
  `lastgprsdate` datetime(3) DEFAULT NULL,
  `latest_buying_stage` varchar(250) DEFAULT NULL,
  `hs_lead_status` varchar(100) DEFAULT NULL,
  `arpu` float DEFAULT NULL,
  `no_of_times_top_up_20_and_above` int DEFAULT NULL,
  `first_topup_status` varchar(5) DEFAULT NULL,
  `International_Topup_Country_Name` varchar(15) DEFAULT NULL,
  `latest_topup_amount_being_purchased` float DEFAULT NULL,
  `frequent_topup_method` varchar(25) DEFAULT NULL,
  `Latest_SIM_with_Topup_Amount_Being_Purchased` float DEFAULT NULL,
  `sim_country` varchar(10) DEFAULT NULL,
  `sim_order_status` varchar(15) DEFAULT NULL,
  `SIM_ordered_by` varchar(10) DEFAULT NULL,
  `Latest_Preloaded_SIM_Amount_Being_Purchased` varchar(155) DEFAULT NULL,
  `latest_bundle_payment_mode` varchar(100) DEFAULT NULL,
  `create_modify_date` datetime(3) DEFAULT NULL,
  `first_time_topup_payment_method_used` varchar(150) DEFAULT NULL,
  `customer_type` varchar(150) DEFAULT NULL,
  `latest_sim_with_bundle_name_being_purchased` varchar(250) DEFAULT NULL,
  `email_verify` int DEFAULT NULL,
  `is_myaccount` int DEFAULT NULL,
  `no_topup_20_above` varchar(250) DEFAULT NULL,
  `topup_count_90_days` varchar(250) DEFAULT NULL,
  `freq_topup_method` varchar(250) DEFAULT NULL,
  `credit_allowance_used` int DEFAULT NULL,
  `sim_swap_status` varchar(50) DEFAULT NULL,
  `requested_for_sim_swap` varchar(50) DEFAULT NULL,
  `portin_request` varchar(500) DEFAULT NULL,
  `portin_status` varchar(500) DEFAULT NULL,
  `lat_product_vou_attempt_status` varchar(150) DEFAULT NULL,
  `lat_product_vou_failed_reason` varchar(250) DEFAULT NULL,
  `is_non_vectone` int DEFAULT NULL,
  `customer_request_for_refund` varchar(50) DEFAULT NULL,
  `refund_reference_number` varchar(100) DEFAULT NULL,
  `refund_status` varchar(50) DEFAULT NULL,
  `Bundle_Prefernce` longtext,
  `Topup_Preference` longtext,
  `price_range_Pref` longtext,
  `types_of_quarries` varchar(500) DEFAULT NULL,
  `top_up_sub_query` varchar(500) DEFAULT NULL,
  `bundle_sub_query` varchar(500) DEFAULT NULL,
  `sub_query2` varchar(500) DEFAULT NULL,
  `refund_amount_To` varchar(250) DEFAULT NULL,
  `refund_amount` float DEFAULT NULL,
  PRIMARY KEY (`mobileno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping events for database 'esp_mcm'
--

--
-- Dumping routines for database 'esp_mcm'
--
/*!50003 DROP PROCEDURE IF EXISTS `HUBSPOT_GET_ACTIVITY_DETAILS` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dbdev`@`%` PROCEDURE `HUBSPOT_GET_ACTIVITY_DETAILS`()
BEGIN
   		
   		
   
   
   	drop temporary table if exists temp_hubspot_activity_register_info;
   	create temporary table temp_hubspot_activity_register_info as 
   	SELECT  ifnull(a.mobileno,b.mobileno) as phone,
   			ifnull(a.iccid,b.iccid) as iccid,
   			case when a.auto_topup=1 then 'Enabled' else 'Disabled' end as auto_topup,
   			'Vectone' as brand_name,
   			a.auto_topup_disable_by, 
   			a.auto_topup_disable_date,
   			a.auto_topup_enable_by,
   			a.auto_topup_enable_date,
   			a.no_of_topup as number_of_topups_made,
   			a.first_topup_amount,
   			a.first_time_topup_payment_method_used as first_time_topup_payment_method_used,
   			a.first_topup_method_used,
   			a.first_time_topup_date,
   			a.latest_auto_topup_attempt_date,
   			a.latest_auto_topup_attempt_failure_reason,
   			case
   			  when a.latest_auto_topup_attempt_status is null then latest_auto_topup_attempt_status
   			 when a.latest_auto_topup_attempt_status='ACCEPT' then 'Success' else 'Failed' end as latest_auto_topup_attempt_status,
   			a.last_topup_date as latest_topup_date,
   			a.latest_topup_amount,
   			a.latest_topup_type,
   			case when a.last_topup_vou_method like '%Physical%' then 'Physical voucher'
   					when a.last_topup_vou_method like '%EVoucher%' then 'Evoucher'
   					when a.last_topup_vou_method like '%online%' then 'Online'
   					when a.last_topup_vou_method like '%Opera%' then 'Operator topup'end as latest_topup_method_used1,
   			a.lat_topup_method_used as latest_topup_payment_method_used,
   			a.last_topup_payment_ref as latest_topup_payment_reference_number,
   			a.total_revenue as revenue_from_topup,
   			a.int_topup_network_name as international_topup_network_name,
   			a.lat_int_topup_amount as latest_international_topup_amount,
   			a.lat_int_topup_comp_status as latest_international_topup_request_completion_status,
   			a.no_int_topup_made as number_of_international_topups_made,
   			a.int_total_topup_amount as total_amount_of_international_topup_made,
   			a.int_topup_failure_reason as latest_international_topup_request_failure_reason,
   			a.sim_login_date as sim_inserted_date,
   			a.sim_dispatch_date as sim_dispatch_date,
   			case when a.sim_inserted = 'Y' then 'Yes' 
   				 when a.sim_inserted = 'N' then 'No'
   				 else 'No' end as sim_inserted,
   			a.sim_type as sim_type,
   			a.sim_last_login_date as last_location_update_date,
   			a.freesimid,
   			a.subscriberid,
   			a.firstname,
   			a.lastname,
   			lower(a.email) as email,
   			a.houseno,
   			a.address1,
   			a.address2,
   			a.city,
   			a.state,
   			a.postcode as ZIP,
   			a.dob as date_of_birth,
   			a.mobilephone,
   			b.number_of_bundles_purchased,
   			b.number_of_active_bundles,
   			b.first_bundle_name,
   			case	when b.first_time_purchased_bundle_category=290 then 'UK plans' 
   					when b.first_time_purchased_bundle_category=352 then 'All in one plans' 
   					when b.first_time_purchased_bundle_category=349 then 'Data plans' 
   					when b.first_time_purchased_bundle_category=354 then 'International Plans' END as first_time_purchased_bundle_category,
   			b.first_bundle_purchase_amount,
   			b.first_bundle_purchase_date,
   			case when b.first_bundle_purchase_method like '%online%' then 'Online'
   			when  b.first_bundle_purchase_method like '%Pay%by%balance%' then 'pay by balance' ELSE null end as first_bundle_purchase_method,
   			case	when b.first_bundle_purchase_method like '%credit%' then 'Credit/Debit card' 
   					when b.first_bundle_purchase_method like '%Paypal%' then 'PayPal' 
   					when b.first_bundle_purchase_method like '%RealX%' then 'RealX' 
   					when b.first_bundle_purchase_method like '%Paysafe%' then 'Paysafe'  
   					else 'Others' end as first_time_bundle_purchase_payment_method_used,
   			ifnull(b.first_bundle_status,'No') as  first_bundle_status, 
   			b.latest_bundle_renewal_attempt_date,
   			b.latest_bundle_renewal_attempt_failure_reason,
   			b.latest_bundle_renewal_attempt_status,
   			b.latest_bundle_name_being_purchased,
   			b.National_addon_Bundle_national_mins_total_allowance,
   			b.National_Bundle_data_allowance,
   			b.National_Bundle_data_used_allowance_percentage,
   			b.National_Bundle_international_mins_total_allowance,
   			b.National_Bundle_international_mins_used_allowance_percentage,
   			b.National_Bundle_national_mins_total_allowance,
   			b.National_Bundle_national_mins_used_allowance_percentage,
   			b.National_Bundle_sms_allowance,
   			b.National_Bundle_sms_used_allowance_percentage,
   			b.National_Bundle_vectone_to_vectone_minutes_allowance,
   			b.AIO_Bundle_data_allowance,
   			b.AIO_Bundle_data_used_allowance_percentage,
   			b.AIO_Bundle_international_mins_total_allowance,
   			b.AIO_Bundle_international_mins_used_allowance_percentage,
   			b.AIO_Bundle_national_mins_total_allowance,
   			b.AIO_Bundle_national_mins_used_allowance_percentage,
   			b.AIO_Bundle_sms_allowance,
   			b.AIO_Bundle_sms_used_allowance_percentage,
   			b.AIO_Bundle_vectone_to_vectone_minutes_allowance,
   			b.AIO_Bundle_vectone_to_vectone_minutes_used_allowance_percentage,
   			b.current_addon_Data_bundle_id,
   			b.current_addon_Data_bundle_name,
   			b.current_addon_international_bundle_id,
   			b.current_addon_international_bundle_name,
   			b.current_addon_national_bundle_id,
   			b.current_addon_national_bundle_name,
   			b.current_AIO_bundle_id,
   			b.current_AIO_bundle_name,
   			b.current_AIO_bundle_renewal_date,
   			b.current_Data_bundle_id,
   			b.current_Data_bundle_name,
   			b.current_data_bundle_renewal_date,
   			b.current_international_bundle_id,
   			b.current_international_bundle_name,
   			b.current_International_bundle_renewal_date,
   			b.current_national_bundle_id,
   			b.current_national_bundle_name,
   			b.current_national_bundle_renewal_date,
   			b.current_SIMONLY_bundle_id,
   			b.current_SIMONLY_bundle_name,
   			b.Data_addon_Bundle_data_allowance,
   			b.Data_addon_Bundle_data_used_allowance_percentage,
   			b.Data_Bundle_data_allowance,
   			b.Data_Bundle_data_used_allowance_percentage,
   			b.Data_Bundle_international_mins_total_allowance,
   			b.Data_Bundle_international_mins_used_allowance_percentage,
   			b.Data_Bundle_national_mins_total_allowance,
   			b.Data_Bundle_national_mins_used_allowance_percentage,
   			b.Data_Bundle_sms_allowance,
   			b.Data_Bundle_sms_used_allowance_percentage,
   			b.Data_Bundle_vectone_to_vectone_minutes_allowance,
   			b.Data_Bundle_vectone_to_vectone_minutes_used_allowance_percentage,
   			b.International_addon_Bundle_international_mins_total_allowance,
   			b.Intl_addon_Bundle_intl_mins_used_allowance_percentage ,
   			b.International_Bundle_data_allowance,
   			b.International_Bundle_data_used_allowance_percentage,
   			b.International_Bundle_international_mins_total_allowance,
   			b.Intl_Bundle_intl_mins_used_allowance_percentage,
   			b.International_Bundle_national_mins_total_allowance,
   			b.International_Bundle_national_mins_used_allowance_percentage,
   			b.International_Bundle_sms_allowance,
   			b.International_Bundle_sms_used_allowance_percentage,
   			b.International_Bundle_vectone_to_vectone_minutes_allowance,
   			b.Intl_Bundle_vectone_to_vectone_minutes_used_allowance_percentage,
   			b.latest_sim_with_bundle_name_being_purchased,
   			b.latest_sim_only_with_bundle_name_being_purchased,
   			b.National_addon_Bundle_national_mins_used_allowance_percentage,
   			b.Natl_Bundle_vectone_to_vectone_minutes_used_allowance_percentage,
   			b.revenue_from_bundle,
   			b.simonly_Bundle_data_allowance,
   			b.simonly_Bundle_data_used_allowance_percentage,
   			b.simonly_Bundle_international_mins_total_allowance,
   			b.simonly_Bundle_international_mins_used_allowance_percentage,
   			b.simonly_Bundle_national_mins_total_allowance,
   			b.simonly_Bundle_national_mins_used_allowance_percentage,
   			b.simonly_Bundle_sms_allowance,
   			b.simonly_Bundle_sms_used_allowance_percentage,
   			b.simonly_Bundle_vectone_to_vectone_minutes_allowance,
   			b.simonly_Bundle_vec_to_vec_minutes_used_allowance_percentage,
   			b.current_national_bundle_most_international_mins_used_country,
   			b.current_intl_bundle_most_international_mins_used_country,
   			b.current_AIO_bundle_most_international_mins_used_country,
   			b.current_SIMONly_bundle_most_international_mins_used_country,
   			b.National_Bundle_most_international_mins_used_country_percentage,
   			b.Intl_Bundle_most_international_mins_used_country_percentage,
   			b.AIO_Bundle_most_international_mins_used_country_percentage,
   			b.Data_Bundle_most_international_mins_used_country,
   			b.Data_Bundle_most_international_mins_used_country_percentage,
   			b.current_SIMONly_bundle_most_international_mins_used_country_per,
   			b.previously_subscribed_for_country_specific_bundles_,
   			b.most_subscribed_country_specific_bundle_name,
   			b.Has_active_national_bundle,
   			b.Has_active_AIO_bundle,
   			b.Has_active_International_bundle,
   			b.Has_active_data_bundle,
   			b.Has_active_roaming_bundle,
   			b.current_roam_bun_name as current_roaming_bundle_name,
   			b.current_roam_bun_id as current_roaming_bundle_id,
   			b.current_roam_bun_startdate as current_roaming_bundle_startdate,
   			b.current_roam_bun_enddate as current_roaming_bundle_enddate,
   			b.current_roam_bun_renewal_date as current_roaming_bundle_renewal_date,
   			b.roam_bun_data_allowance as roaming_Bundle_data_allowance,
   			b.roam_bun_data_used_allowance_percentage as roaming_Bundle_data_used_allowance_percentage,
   			b.roam_bun_national_mins_total_allowance as roaming_Bundle_national_mins_total_allowance,
   			b.roam_bun_national_mins_used_allowance_percentage as roaming_Bundle_national_mins_used_allowance_percentage,
   			b.roam_bun_international_mins_total_allowance as roaming_Bundle_international_mins_total_allowance,
   			b.roam_bun_international_mins_used_allowance_percentage as roaming_Bundle_international_mins_used_allowance_percentage,
   			b.roam_bun_sms_allowance as roaming_Bundle_sms_allowance,
   			b.roam_bun_sms_used_allowance_percentage as roaming_Bundle_sms_used_allowance_percentage,
   			b.roam_bun_most_international_mins_used_country as roaming_Bundle_most_international_mins_used_country,
   			b.roam_bun_most_international_mins_used_country_percentage as roaming_Bundle_most_international_mins_used_country_percentage,
   			b.roam_bun_vectone_to_vectone_minutes_allowance as roaming_Bundle_vectone_to_vectone_minutes_allowance,
   			b.roam_bun_vectone_to_vectone_minutes_used_allowance_percentage as roaming_Bundle_vect_to_vect_minutes_used_allowance_percentage,
   			b.latest_bundle_id_being_purchased,
   			b.Has_active_SIMONLY_bundle,
   			b.current_SIMONLY_bundle_renewal_date,
   			b.latest_bundle_purchase_date,
   			b.latest_bundle_payment_mode, 
   			b.latest_bundle_payment_method,
   			b.latest_bundle_payment_reference_number,
   			b.current_addon_Data_enddate,
   			b.current_addon_Data_startdate,
   			b.current_addon_international_enddate,
   			b.current_addon_international_startdate,
   			b.current_addon_national_enddate,
   			b.current_addon_national_startdate,
   			b.current_AIO_enddate,
   			b.current_AIO_startdate,
   			b.current_Data_enddate,
   			b.current_Data_startdate,
   			b.current_international_enddate,
   			b.current_international_startdate,
   			b.current_national_enddate,
   			b.current_national_startdate,
   			b.current_SIMONLY_enddate,
   			b.current_SIMONLY_startdate,
   			b.current_data_roaming_addon_name,
   			b.current_data_roaming_addon_id,
   			b.current_data_roaming_addon_startdate,
   			b.current_data_roaming_addon_enddate,
   			b.data_roaming_addon_data_total_allowance,
   			b.data_roaming_addon_data_used_allowance_percentage,
   			b.number_of_addons_purchased,
   			b.number_of_active_addons,
   			b.latest_addon_being_purchased,
   			b.Has_active_national_addon,
   			b.Has_active_international_addon,
   			b.Has_active_data_roaming_addon,
   			b.Has_active_data_addon,
   			b.roaming_status,
   			b.auto_renewal,
   			b.auto_renewal_disable_by,
   			b.auto_renewal_disable_date,
   			b.auto_renewal_enable_by,
   			b.auto_renewal_enable_date,
   			b.customer_type as customer_type,
   			a.email_verification_status,
   			b.free_credit as free_credit,
   			
   			case when b.Has_llom='Active' and b.llom_exp_date>=current_timestamp() then 'Active'
   				 when b.Has_llom='Active' and b.llom_exp_date<=current_timestamp() then 'Expired'
   				 when b.Has_llom='Inactive' THEN  'Inactive'
   				 when b.Has_llom='Renewed' and  b.llom_exp_date>=current_timestamp() then 'Renewed'
   				 when b.Has_llom='Renewed' and  b.llom_exp_date<=current_timestamp() then 'Expired'
   			else 'No' END as has_llom,
   			b.has_Vectone_Xtra as has_Vectone_Xtra, 
   			b.current_balance as current_balance,
   			a.first_topup_status,
   			ifnull(a.hubspot_contact_id,b.hubspot_contact_id) as hs_object_id,
   			a.Latest_SIM_with_Topup_Amount_Being_Purchased,
   			case when ifnull(a.is_myaccount,0)=1 then 'Yes' else 'No' end as registered_to_myaccount,
   			a.latest_purchase_attempt_date,
   			case when a.sim_dispatch_date>='2020-11-01' then case when ifnull(a.credit_allowance_used,0)=1 then 'Yes'
   			else 'No' end else 'Yes' end as credit_allowance_used,
   			TIMESTAMPADD(DAY,1,b.current_SIMONLY_bundle_renewal_date) as nextbillingdate,
   			case when a.latest_product_being_purchased='FREE SIM' THEN 'Free sim'
   			 when a.latest_product_being_purchased='BUNDLE SIM' then 'Sim with bundle'
   			  when a.latest_product_being_purchased='TOPUP SIM' then 'Sim with topup' 
   			  when a.latest_product_being_purchased='PAYMONTHLY SIM' then 'Sim only with bundle' 
   			  when a.latest_product_being_purchased in('CREDIT SIM','preloaded sim') then 'Preloaded sim' 
   			   else latest_product_being_purchased end as 
   			latest_product_being_purchased ,
   			ifnull(simonly_excessusage,'No')  as simonly_excessusage,
   			a.sim_swap_status,
   			ifnull(a.requested_for_sim_swap,'No')  as requested_for_sim_swap,
   			b.landlinenumber,
   			ifnull(b.existing_customer_my_vectone_charge_back,'No') as existing_customer_my_vectone_charge_back,
   			a.latest_attempt_payment_reference_number,
   			a.referred_someone,
   			a.referred_someone_first_time,
   			a.referee_subscriber_id,
   			a.portin_request as portin_request,
   			a.portin_status as portin_status,
   			a.portin_request_completion_status as portin_request_completion_status,
   			b.types_of_bundle,
   			a.lat_product_vou_attempt_status as latest_product_voucher_attempt_status,
   			a.lat_product_vou_failed_reason as latest_product_voucher_failed_reason,
   			ifnull(b.cc_no,'') as cc_no,
   			ifnull(b.cc_no_expirydate,'') as cc_no_expirydate,
   			ifnull(b.cc_card_type,'') as cc_card_type,
   			ifnull(b.plan_upgrade,'No')  as plan_upgrade,
   			ifnull(b.plan_downgrade,'No')  as plan_downgrade,
   			b.plan_change_date,
   			ifnull(b.change_plan_requested_name,'') as change_plan_requested_name,
   			case when ifnull(a.is_non_vectone,0)=1 then 'Non-Vectone' else 'Vectone' end as customer_difference,
   			ifnull(a.latest_purchase_attempt_payment_mode,'') as latest_purchase_attempt_payment_mode,
   			ifnull(a.Latest_purchase_attempt_payment_status,'') as latest_purchase_attempt_payment_status,
   			ifnull(a.customer_request_for_refund,'No') as customer_request_for_refund,
   			ifnull(refund_reference_number,'') as refund_reference_number,
   			ifnull(a.refund_status,'') as refund_status,
   			a.latest_topup_amount_being_purchased as latest_topup_amount_being_purchased,
   			case when a.auto_topup=1 then 2 else null end as Threshold_Value,
   			ifnull(Data_Rollover,'No')as data_rollover,
   			ifnull(Rollover_Data_allowance,0) AS sim_only_rollover_data_allowance,
   			NULL as bundle_preference,
   			NULL as topup_preference,
   			NULL as price_range,
   			NULL as types_of_quarries,
   			NULL as top_up_sub_query,
   			NULL as bundle_sub_query,
   			NULL AS sub_query2,
   			a.refund_amount_To as refund_amount_To,
   			a.refund_amount refund_amount,
   			b.simonly_call_allow_used_per  as call_sim_only_allowance_used,
   			case when ifnull(b.simonly_call_allow_used_per,0)>0 then 'UK Mins' else null end  as call_type_of_allowance_consumed,
   			ifnull(b.simonly_Data_allow_used_per,0) as data_sim_only_allowance_used,
   			case when ifnull(b.simonly_Data_allow_used_per,0)>0 then 'Data' else null end as Data_type_of_allowance_consumed,
   			case when ifnull(purchased_addon,'')='Yes' and addon_enddate>=current_timestamp() then 'Yes' else 'No' end as purchased_addon,
   			case when ifnull(b.simonly_Data_allow_used_per,0)>0 and ifnull(b.simonly_call_allow_used_per,0)>0 then 'UK Mins'
   			when ifnull(b.simonly_call_allow_used_per,0)>0 then 'UK Mins'
   				when ifnull(b.simonly_Data_allow_used_per,0)>0  then 'Data'
   				else null end type_of_allowance_consumed,
   			case 
   			when ifnull(b.simonly_Data_allow_used_per,0)>0 and ifnull(b.simonly_call_allow_used_per,0)>0 then ifnull(b.simonly_call_allow_used_per,0)
   			when ifnull(b.simonly_call_allow_used_per,0)>0 then b.simonly_call_allow_used_per
   				when ifnull(b.simonly_Data_allow_used_per,0)>0  then b.simonly_Data_allow_used_per
   				else null end sim_only_allowance_used
   
   	FROM topup_activity_register a 
   	join mvno_bun_act_register b on a.mobileno = b.mobileno
   	where (ifnull(a.status,1) <> 1  or ifnull(b.status,1) <> 1);
   	
   	drop temporary table if exists temp_hubspot_activity_register_info_final;
   	create temporary table temp_hubspot_activity_register_info_final as 
   	select a.phone
 ,a.iccid
 ,a.auto_topup
 ,a.brand_name
 ,a.auto_topup_disable_by
 ,a.auto_topup_disable_date
 ,a.auto_topup_enable_by
 ,a.auto_topup_enable_date
 ,a.number_of_topups_made
 ,a.first_topup_amount
 ,a.first_time_topup_payment_method_used
 ,a.first_topup_method_used
 ,a.first_time_topup_date
 ,a.latest_auto_topup_attempt_date
 ,a.latest_auto_topup_attempt_failure_reason
 ,a.latest_auto_topup_attempt_status
 ,a.latest_topup_date
 ,a.latest_topup_amount
 ,a.latest_topup_type
 ,a.latest_topup_method_used1
 ,a.latest_topup_payment_method_used
 ,a.latest_topup_payment_reference_number
 ,a.revenue_from_topup
 ,a.international_topup_network_name
 ,a.latest_international_topup_amount
 ,a.latest_international_topup_request_completion_status
 ,a.number_of_international_topups_made
 ,a.total_amount_of_international_topup_made
 ,a.latest_international_topup_request_failure_reason
 ,a.sim_inserted_date
 ,a.sim_dispatch_date
 ,a.sim_inserted
 ,a.sim_type
 ,a.last_location_update_date
 ,a.freesimid
 ,a.subscriberid
 ,a.firstname
 ,a.lastname
 ,a.email
 ,a.houseno
 ,a.address1
 ,a.address2
 ,a.city
 ,a.state
 ,a.ZIP
 ,a.date_of_birth
 ,a.mobilephone
 ,a.number_of_bundles_purchased
 ,a.number_of_active_bundles
 ,a.first_bundle_name
 ,a.first_time_purchased_bundle_category
 ,a.first_bundle_purchase_amount
 ,a.first_bundle_purchase_date
 ,a.first_bundle_purchase_method
 ,a.first_time_bundle_purchase_payment_method_used
 ,a.first_bundle_status
 ,a.latest_bundle_renewal_attempt_date
 ,a.latest_bundle_renewal_attempt_failure_reason
 ,a.latest_bundle_renewal_attempt_status
 ,a.latest_bundle_name_being_purchased
 ,a.National_addon_Bundle_national_mins_total_allowance
 ,a.National_Bundle_data_allowance
 ,a.National_Bundle_data_used_allowance_percentage
 ,a.National_Bundle_international_mins_total_allowance
 ,a.National_Bundle_international_mins_used_allowance_percentage
 ,a.National_Bundle_national_mins_total_allowance
 ,a.National_Bundle_national_mins_used_allowance_percentage
 ,a.National_Bundle_sms_allowance
 ,a.National_Bundle_sms_used_allowance_percentage
 ,a.National_Bundle_vectone_to_vectone_minutes_allowance
 ,a.AIO_Bundle_data_allowance
 ,a.AIO_Bundle_data_used_allowance_percentage
 ,a.AIO_Bundle_international_mins_total_allowance
 ,a.AIO_Bundle_international_mins_used_allowance_percentage
 ,a.AIO_Bundle_national_mins_total_allowance
 ,a.AIO_Bundle_national_mins_used_allowance_percentage
 ,a.AIO_Bundle_sms_allowance
 ,a.AIO_Bundle_sms_used_allowance_percentage
 ,a.AIO_Bundle_vectone_to_vectone_minutes_allowance
 ,a.AIO_Bundle_vectone_to_vectone_minutes_used_allowance_percentage
 ,a.current_addon_Data_bundle_id
 ,a.current_addon_Data_bundle_name
 ,a.current_addon_international_bundle_id
 ,a.current_addon_international_bundle_name
 ,a.current_addon_national_bundle_id
 ,a.current_addon_national_bundle_name
 ,a.current_AIO_bundle_id
 ,a.current_AIO_bundle_name
 ,a.current_AIO_bundle_renewal_date
 ,a.current_Data_bundle_id
 ,a.current_Data_bundle_name
 ,a.current_data_bundle_renewal_date
 ,a.current_international_bundle_id
 ,a.current_international_bundle_name
 ,a.current_International_bundle_renewal_date
 ,a.current_national_bundle_id
 ,a.current_national_bundle_name
 ,a.current_national_bundle_renewal_date
 ,a.current_SIMONLY_bundle_id
 ,a.current_SIMONLY_bundle_name
 ,a.Data_addon_Bundle_data_allowance
 ,a.Data_addon_Bundle_data_used_allowance_percentage
 ,a.Data_Bundle_data_allowance
 ,a.Data_Bundle_data_used_allowance_percentage
 ,a.Data_Bundle_international_mins_total_allowance
 ,a.Data_Bundle_international_mins_used_allowance_percentage
 ,a.Data_Bundle_national_mins_total_allowance
 ,a.Data_Bundle_national_mins_used_allowance_percentage
 ,a.Data_Bundle_sms_allowance
 ,a.Data_Bundle_sms_used_allowance_percentage
 ,a.Data_Bundle_vectone_to_vectone_minutes_allowance
 ,a.Data_Bundle_vectone_to_vectone_minutes_used_allowance_percentage
 ,a.International_addon_Bundle_international_mins_total_allowance
 ,a.Intl_addon_Bundle_intl_mins_used_allowance_percentage
 ,a.International_Bundle_data_allowance
 ,a.International_Bundle_data_used_allowance_percentage
 ,a.International_Bundle_international_mins_total_allowance
 ,a.Intl_Bundle_intl_mins_used_allowance_percentage
 ,a.International_Bundle_national_mins_total_allowance
 ,a.International_Bundle_national_mins_used_allowance_percentage
 ,a.International_Bundle_sms_allowance
 ,a.International_Bundle_sms_used_allowance_percentage
 ,a.International_Bundle_vectone_to_vectone_minutes_allowance
 ,a.Intl_Bundle_vectone_to_vectone_minutes_used_allowance_percentage
 ,a.latest_sim_with_bundle_name_being_purchased
 ,a.latest_sim_only_with_bundle_name_being_purchased
 ,a.National_addon_Bundle_national_mins_used_allowance_percentage
 ,a.Natl_Bundle_vectone_to_vectone_minutes_used_allowance_percentage
 ,a.revenue_from_bundle
 ,a.simonly_Bundle_data_allowance
 ,a.simonly_Bundle_data_used_allowance_percentage
 ,a.simonly_Bundle_international_mins_total_allowance
 ,a.simonly_Bundle_international_mins_used_allowance_percentage
 ,a.simonly_Bundle_national_mins_total_allowance
 ,a.simonly_Bundle_national_mins_used_allowance_percentage
 ,a.simonly_Bundle_sms_allowance
 ,a.simonly_Bundle_sms_used_allowance_percentage
 ,a.simonly_Bundle_vectone_to_vectone_minutes_allowance
 ,a.simonly_Bundle_vec_to_vec_minutes_used_allowance_percentage
 ,a.current_national_bundle_most_international_mins_used_country
 ,a.current_intl_bundle_most_international_mins_used_country
 ,a.current_AIO_bundle_most_international_mins_used_country
 ,a.current_SIMONly_bundle_most_international_mins_used_country
 ,a.National_Bundle_most_international_mins_used_country_percentage
 ,a.Intl_Bundle_most_international_mins_used_country_percentage
 ,a.AIO_Bundle_most_international_mins_used_country_percentage
 ,a.Data_Bundle_most_international_mins_used_country
 ,a.Data_Bundle_most_international_mins_used_country_percentage
 ,a.current_SIMONly_bundle_most_international_mins_used_country_per
 ,a.previously_subscribed_for_country_specific_bundles_
 ,a.most_subscribed_country_specific_bundle_name
 ,a.Has_active_national_bundle
 ,a.Has_active_AIO_bundle
 ,a.Has_active_International_bundle
 ,a.Has_active_data_bundle
 ,a.Has_active_roaming_bundle
 ,a.current_roaming_bundle_name
 ,a.current_roaming_bundle_id
 ,a.current_roaming_bundle_startdate
 ,a.current_roaming_bundle_enddate
 ,a.current_roaming_bundle_renewal_date
 ,a.roaming_Bundle_data_allowance
 ,a.roaming_Bundle_data_used_allowance_percentage
 ,a.roaming_Bundle_national_mins_total_allowance
 ,a.roaming_Bundle_national_mins_used_allowance_percentage
 ,a.roaming_Bundle_international_mins_total_allowance
 ,a.roaming_Bundle_international_mins_used_allowance_percentage
 ,a.roaming_Bundle_sms_allowance
 ,a.roaming_Bundle_sms_used_allowance_percentage
 ,a.roaming_Bundle_most_international_mins_used_country
 ,a.roaming_Bundle_most_international_mins_used_country_percentage
 ,a.roaming_Bundle_vectone_to_vectone_minutes_allowance
 ,a.roaming_Bundle_vect_to_vect_minutes_used_allowance_percentage
 ,a.latest_bundle_id_being_purchased
 ,a.Has_active_SIMONLY_bundle
 ,a.current_SIMONLY_bundle_renewal_date
 ,a.latest_bundle_purchase_date
 ,a.latest_bundle_payment_mode
 ,a.latest_bundle_payment_method
 ,a.latest_bundle_payment_reference_number
 ,a.current_addon_Data_enddate
 ,a.current_addon_Data_startdate
 ,a.current_addon_international_enddate
 ,a.current_addon_international_startdate
 ,a.current_addon_national_enddate
 ,a.current_addon_national_startdate
 ,a.current_AIO_enddate
 ,a.current_AIO_startdate
 ,a.current_Data_enddate
 ,a.current_Data_startdate
 ,a.current_international_enddate
 ,a.current_international_startdate
 ,a.current_national_enddate
 ,a.current_national_startdate
 ,a.current_SIMONLY_enddate
 ,a.current_SIMONLY_startdate
 ,a.current_data_roaming_addon_name
 ,a.current_data_roaming_addon_id
 ,a.current_data_roaming_addon_startdate
 ,a.current_data_roaming_addon_enddate
 ,a.data_roaming_addon_data_total_allowance
 ,a.data_roaming_addon_data_used_allowance_percentage
 ,a.number_of_addons_purchased
 ,a.number_of_active_addons
 ,a.latest_addon_being_purchased
 ,a.Has_active_national_addon
 ,a.Has_active_international_addon
 ,a.Has_active_data_roaming_addon
 ,a.Has_active_data_addon
 ,a.roaming_status
 ,a.auto_renewal
 ,a.auto_renewal_disable_by
 ,a.auto_renewal_disable_date
 ,a.auto_renewal_enable_by
 ,a.auto_renewal_enable_date
 ,a.customer_type
 ,a.email_verification_status
 ,a.free_credit
 ,a.has_llom
 ,a.has_Vectone_Xtra
 ,a.current_balance
 ,a.first_topup_status
 ,a.hs_object_id
 ,a.Latest_SIM_with_Topup_Amount_Being_Purchased
 ,a.registered_to_myaccount
 ,a.latest_purchase_attempt_date
 ,a.credit_allowance_used
 ,a.nextbillingdate
 ,a.latest_product_being_purchased
 ,a.simonly_excessusage
 ,a.sim_swap_status
 ,a.requested_for_sim_swap
 ,a.landlinenumber
 ,a.existing_customer_my_vectone_charge_back
 ,a.latest_attempt_payment_reference_number
 ,a.referred_someone
 ,a.referred_someone_first_time
 ,a.referee_subscriber_id
 ,a.portin_request
 ,a.portin_status
 ,a.portin_request_completion_status
 ,a.types_of_bundle
 ,a.latest_product_voucher_attempt_status
 ,a.latest_product_voucher_failed_reason
 ,a.cc_no
 ,a.cc_no_expirydate
 ,a.cc_card_type
 ,a.plan_upgrade
 ,a.plan_downgrade
 ,a.plan_change_date
 ,a.change_plan_requested_name
 ,a.customer_difference
 ,a.latest_purchase_attempt_payment_mode
 ,a.latest_purchase_attempt_payment_status
 ,a.customer_request_for_refund
 ,a.refund_reference_number
 ,a.refund_status
 ,a.latest_topup_amount_being_purchased
 ,a.Threshold_Value
 ,a.data_rollover
 ,a.sim_only_rollover_data_allowance
 ,a.bundle_preference
 ,a.topup_preference
 ,a.price_range
 ,a.types_of_quarries
 ,a.top_up_sub_query
 ,a.bundle_sub_query
 ,a.sub_query2
 ,a.refund_amount_To
 ,a.refund_amount
 ,a.call_sim_only_allowance_used
 ,a.call_type_of_allowance_consumed
 ,a.data_sim_only_allowance_used
 ,a.Data_type_of_allowance_consumed
 ,a.purchased_addon
 ,a.type_of_allowance_consumed
 ,a.sim_only_allowance_used,
   		b.alternate_email_id,
   		b.first_referral_date,
   		b.last_referral_date,
   		b.number_of_referrals_made,
   		b.portin_current_network_name,
   		b.portin_request_failure_reason,
   		b.portout_network_name,
   		b.reason_for_portout,
   		b.total_purchase_amount_of_the_customer,
   		b.avg_customer_wait_time_between_purchases,
   		b.latest_purchase_attempt_payment_method,
   		b.latest_payment_attempt_failure_reason,   
   		b.hs_language,
   		b.lifecyclestage, 
   		b.Smart_Rates_user,
   		b.lastcalldate,
   		b.lastsmsdate,
   		b.lastgprsdate,
   		b.latest_buying_stage,
   		b.hs_lead_status,
   		b.no_of_times_top_up_20_and_above, 
   		b.international_topup_country_name,
   		b.frequent_topup_method, 
   		b.sim_country,
   		case when a.sim_dispatch_date is not null and ifnull(sim_inserted,'')<>'Y' then 'Dispatched'
   			 WHEN ifnull(sim_inserted,'')='Y' then 'Inserted' else 'Ordered' end AS sim_order_status,
   		b.SIM_ordered_by,
   		b.Latest_Preloaded_SIM_Amount_Being_Purchased,
   		0 AS unsubscribed_from_all_email 
   	from temp_hubspot_activity_register_info a 
   	left join temp_exra_col_hubspot b  on a.phone = b.mobileno;
   	
   	DELETE a from temp_hubspot_activity_register_info_final  a 
   	JOIN MVNO_HUBSPOT_DND_REGISTER b on a.phone=b.mobileno AND 
   	ifnull(b.Is_stop_all_email,1)=1;  
   	
   	select * from temp_hubspot_activity_register_info_final a 
   	where (phone is not null or phone <> '')  limit 750;
   		
   	drop table temp_hubspot_activity_register_info;
   	drop table temp_hubspot_activity_register_info_final;
   
   END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-21  9:50:55
