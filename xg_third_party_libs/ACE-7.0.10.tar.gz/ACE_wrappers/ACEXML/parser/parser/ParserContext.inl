// -*- C++ -*-
#include <algorithm>

ACEXML_INLINE
ACEXML_Parser_Context::ACEXML_Parser_Context()
  : instream_ (0),
    locator_ (0)
{

}

ACEXML_INLINE
ACEXML_Parser_Context::ACEXML_Parser_Context (ACEXML_InputSource* instream,
                                              ACEXML_LocatorImpl* locator)
  : instream_ (instream),
    locator_ (locator)
{

}

ACEXML_INLINE
ACEXML_Parser_Context::ACEXML_Parser_Context (const ACEXML_Parser_Context& src)
  : instream_ (src.instream_),
    locator_ (src.locator_)
{

}

ACEXML_INLINE bool
ACEXML_Parser_Context::operator!= (const ACEXML_Parser_Context& src)
{
  return (this->instream_ != src.instream_ && this->locator_ != src.locator_);
}

ACEXML_INLINE ACEXML_Parser_Context&
ACEXML_Parser_Context::operator= (const ACEXML_Parser_Context& src)
{
  ACEXML_Parser_Context tmp (src);
  std::swap (this->instream_, tmp.instream_);
  std::swap (this->locator_, tmp.locator_);
  return *this;
}


ACEXML_INLINE ACEXML_InputSource*
ACEXML_Parser_Context::getInputSource ()
{
  return this->instream_;
}

ACEXML_INLINE ACEXML_LocatorImpl*
ACEXML_Parser_Context::getLocator ()
{
  return this->locator_;
}

ACEXML_INLINE void
ACEXML_Parser_Context::setInputSource (ACEXML_InputSource* ip)
{
  this->instream_ = ip;
}

ACEXML_INLINE void
ACEXML_Parser_Context::setLocator (ACEXML_LocatorImpl* locator)
{
  this->locator_ = locator;
}

ACEXML_INLINE void
ACEXML_Parser_Context::reset ()
{
  this->instream_ = 0;
  this->locator_ = 0;
}
